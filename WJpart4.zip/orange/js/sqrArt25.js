function sqrsA1() {
    if(document.getElementById("imgSqrs1").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1").src = "img/sqrs/blSqr.png"
};
};
function sqrsA2() {
    if(document.getElementById("imgSqrs2").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs2").src = "img/sqrs/blSqr.png"
};
};
function sqrsA3() {
    if(document.getElementById("imgSqrs3").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs3").src = "img/sqrs/blSqr.png"
};
};
function sqrsA4() {
    if(document.getElementById("imgSqrs4").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs4").src = "img/sqrs/blSqr.png"
};
};
function sqrsA5() {
    if(document.getElementById("imgSqrs5").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs5").src = "img/sqrs/blSqr.png"
};
};
function sqrsA6() {
    if(document.getElementById("imgSqrs6").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs6").src = "img/sqrs/blSqr.png"
};
};
function sqrsA7() {
    if(document.getElementById("imgSqrs7").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs7").src = "img/sqrs/blSqr.png"
};
};
function sqrsA8() {
    if(document.getElementById("imgSqrs8").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs8").src = "img/sqrs/blSqr.png"
};
};
function sqrsA9() {
    if(document.getElementById("imgSqrs9").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs9").src = "img/sqrs/blSqr.png"
};
};
function sqrsA10() {
    if(document.getElementById("imgSqrs10").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs10").src = "img/sqrs/blSqr.png"
};
};
function sqrsA11() {
    if(document.getElementById("imgSqrs11").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs11").src = "img/sqrs/blSqr.png"
};
};
function sqrsA12() {
    if(document.getElementById("imgSqrs12").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs12").src = "img/sqrs/blSqr.png"
};
};
function sqrsA13() {
    if(document.getElementById("imgSqrs13").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs13").src = "img/sqrs/blSqr.png"
};
};
function sqrsA14() {
    if(document.getElementById("imgSqrs14").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs14").src = "img/sqrs/blSqr.png"
};
};
function sqrsA15() {
    if(document.getElementById("imgSqrs15").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs15").src = "img/sqrs/blSqr.png"
};
};
function sqrsA16() {
    if(document.getElementById("imgSqrs16").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs16").src = "img/sqrs/blSqr.png"
};
};
function sqrsA17() {
    if(document.getElementById("imgSqrs17").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs17").src = "img/sqrs/blSqr.png"
};
};
function sqrsA18() {
    if(document.getElementById("imgSqrs18").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs18").src = "img/sqrs/blSqr.png"
};
};
function sqrsA19() {
    if(document.getElementById("imgSqrs19").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs19").src = "img/sqrs/blSqr.png"
};
};
function sqrsA20() {
    if(document.getElementById("imgSqrs20").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs20").src = "img/sqrs/blSqr.png"
};
};
function sqrsA21() {
    if(document.getElementById("imgSqrs21").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs21").src = "img/sqrs/blSqr.png"
};
};
function sqrsA22() {
    if(document.getElementById("imgSqrs22").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs22").src = "img/sqrs/blSqr.png"
};
};
function sqrsA23() {
    if(document.getElementById("imgSqrs23").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs23").src = "img/sqrs/blSqr.png"
};
};
function sqrsA24() {
    if(document.getElementById("imgSqrs24").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs24").src = "img/sqrs/blSqr.png"
};
};
function sqrsA25() {
    if(document.getElementById("imgSqrs25").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs25").src = "img/sqrs/blSqr.png"
};
};
function sqrsA26() {
    if(document.getElementById("imgSqrs26").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs26").src = "img/sqrs/blSqr.png"
};
};
function sqrsA27() {
    if(document.getElementById("imgSqrs27").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs27").src = "img/sqrs/blSqr.png"
};
};
function sqrsA28() {
    if(document.getElementById("imgSqrs28").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs28").src = "img/sqrs/blSqr.png"
};
};
function sqrsA29() {
    if(document.getElementById("imgSqrs29").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs29").src = "img/sqrs/blSqr.png"
};
};
function sqrsA30() {
    if(document.getElementById("imgSqrs30").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs30").src = "img/sqrs/blSqr.png"
};
};
function sqrsA31() {
    if(document.getElementById("imgSqrs31").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs31").src = "img/sqrs/blSqr.png"
};
};
function sqrsA32() {
    if(document.getElementById("imgSqrs32").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs32").src = "img/sqrs/blSqr.png"
};
};
function sqrsA33() {
    if(document.getElementById("imgSqrs33").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs33").src = "img/sqrs/blSqr.png"
};
};
function sqrsA34() {
    if(document.getElementById("imgSqrs34").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs34").src = "img/sqrs/blSqr.png"
};
};
function sqrsA35() {
    if(document.getElementById("imgSqrs35").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs35").src = "img/sqrs/blSqr.png"
};
};
function sqrsA36() {
    if(document.getElementById("imgSqrs36").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs36").src = "img/sqrs/blSqr.png"
};
};
function sqrsA37() {
    if(document.getElementById("imgSqrs37").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs37").src = "img/sqrs/blSqr.png"
};
};
function sqrsA38() {
    if(document.getElementById("imgSqrs38").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs38").src = "img/sqrs/blSqr.png"
};
};
function sqrsA39() {
    if(document.getElementById("imgSqrs39").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs39").src = "img/sqrs/blSqr.png"
};
};
function sqrsA40() {
    if(document.getElementById("imgSqrs40").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs40").src = "img/sqrs/blSqr.png"
};
};
function sqrsA41() {
    if(document.getElementById("imgSqrs41").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs41").src = "img/sqrs/blSqr.png"
};
};
function sqrsA42() {
    if(document.getElementById("imgSqrs42").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs42").src = "img/sqrs/blSqr.png"
};
};
function sqrsA43() {
    if(document.getElementById("imgSqrs43").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs43").src = "img/sqrs/blSqr.png"
};
};
function sqrsA44() {
    if(document.getElementById("imgSqrs44").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs44").src = "img/sqrs/blSqr.png"
};
};
function sqrsA45() {
    if(document.getElementById("imgSqrs45").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs45").src = "img/sqrs/blSqr.png"
};
};
function sqrsA46() {
    if(document.getElementById("imgSqrs46").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs46").src = "img/sqrs/blSqr.png"
};
};
function sqrsA47() {
    if(document.getElementById("imgSqrs47").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs47").src = "img/sqrs/blSqr.png"
};
};
function sqrsA48() {
    if(document.getElementById("imgSqrs48").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs48").src = "img/sqrs/blSqr.png"
};
};
function sqrsA49() {
    if(document.getElementById("imgSqrs49").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs49").src = "img/sqrs/blSqr.png"
};
};
function sqrsA50() {
    if(document.getElementById("imgSqrs50").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs50").src = "img/sqrs/blSqr.png"
};
};
function sqrsB51() {
    if(document.getElementById("imgSqrs51").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs51").src = "img/sqrs/blSqr.png"
};
};
function sqrsB52() {
    if(document.getElementById("imgSqrs52").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs52").src = "img/sqrs/blSqr.png"
};
};
function sqrsB53() {
    if(document.getElementById("imgSqrs53").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs53").src = "img/sqrs/blSqr.png"
};
};
function sqrsB54() {
    if(document.getElementById("imgSqrs54").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs54").src = "img/sqrs/blSqr.png"
};
};
function sqrsB55() {
    if(document.getElementById("imgSqrs55").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs55").src = "img/sqrs/blSqr.png"
};
};
function sqrsB56() {
    if(document.getElementById("imgSqrs56").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs56").src = "img/sqrs/blSqr.png"
};
};
function sqrsB57() {
    if(document.getElementById("imgSqrs57").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs57").src = "img/sqrs/blSqr.png"
};
};
function sqrsB58() {
    if(document.getElementById("imgSqrs58").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs58").src = "img/sqrs/blSqr.png"
};
};
function sqrsB59() {
    if(document.getElementById("imgSqrs59").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs59").src = "img/sqrs/blSqr.png"
};
};
function sqrsB60() {
    if(document.getElementById("imgSqrs60").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs60").src = "img/sqrs/blSqr.png"
};
};
function sqrsB61() {
    if(document.getElementById("imgSqrs61").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs61").src = "img/sqrs/blSqr.png"
};
};
function sqrsB62() {
    if(document.getElementById("imgSqrs62").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs62").src = "img/sqrs/blSqr.png"
};
};
function sqrsB63() {
    if(document.getElementById("imgSqrs63").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs63").src = "img/sqrs/blSqr.png"
};
};
function sqrsB64() {
    if(document.getElementById("imgSqrs64").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs64").src = "img/sqrs/blSqr.png"
};
};
function sqrsB65() {
    if(document.getElementById("imgSqrs65").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs65").src = "img/sqrs/blSqr.png"
};
};
function sqrsB66() {
    if(document.getElementById("imgSqrs66").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs66").src = "img/sqrs/blSqr.png"
};
};
function sqrsB67() {
    if(document.getElementById("imgSqrs67").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs67").src = "img/sqrs/blSqr.png"
};
};
function sqrsB68() {
    if(document.getElementById("imgSqrs68").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs68").src = "img/sqrs/blSqr.png"
};
};
function sqrsB69() {
    if(document.getElementById("imgSqrs69").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs69").src = "img/sqrs/blSqr.png"
};
};
function sqrsB70() {
    if(document.getElementById("imgSqrs70").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs70").src = "img/sqrs/blSqr.png"
};
};
function sqrsB71() {
    if(document.getElementById("imgSqrs71").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs71").src = "img/sqrs/blSqr.png"
};
};
function sqrsB72() {
    if(document.getElementById("imgSqrs72").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs72").src = "img/sqrs/blSqr.png"
};
};
function sqrsB73() {
    if(document.getElementById("imgSqrs73").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs73").src = "img/sqrs/blSqr.png"
};
};
function sqrsB74() {
    if(document.getElementById("imgSqrs74").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs74").src = "img/sqrs/blSqr.png"
};
};
function sqrsB75() {
    if(document.getElementById("imgSqrs75").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs75").src = "img/sqrs/blSqr.png"
};
};
function sqrsB76() {
    if(document.getElementById("imgSqrs76").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs76").src = "img/sqrs/blSqr.png"
};
};
function sqrsB77() {
    if(document.getElementById("imgSqrs77").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs77").src = "img/sqrs/blSqr.png"
};
};
function sqrsB78() {
    if(document.getElementById("imgSqrs78").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs78").src = "img/sqrs/blSqr.png"
};
};
function sqrsB79() {
    if(document.getElementById("imgSqrs79").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs79").src = "img/sqrs/blSqr.png"
};
};
function sqrsB80() {
    if(document.getElementById("imgSqrs80").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs80").src = "img/sqrs/blSqr.png"
};
};
function sqrsB81() {
    if(document.getElementById("imgSqrs81").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs81").src = "img/sqrs/blSqr.png"
};
};
function sqrsB82() {
    if(document.getElementById("imgSqrs82").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs82").src = "img/sqrs/blSqr.png"
};
};
function sqrsB83() {
    if(document.getElementById("imgSqrs83").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs83").src = "img/sqrs/blSqr.png"
};
};
function sqrsB84() {
    if(document.getElementById("imgSqrs84").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs84").src = "img/sqrs/blSqr.png"
};
};
function sqrsB85() {
    if(document.getElementById("imgSqrs85").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs85").src = "img/sqrs/blSqr.png"
};
};
function sqrsB86() {
    if(document.getElementById("imgSqrs86").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs86").src = "img/sqrs/blSqr.png"
};
};
function sqrsB87() {
    if(document.getElementById("imgSqrs87").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs87").src = "img/sqrs/blSqr.png"
};
};
function sqrsB88() {
    if(document.getElementById("imgSqrs88").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs88").src = "img/sqrs/blSqr.png"
};
};
function sqrsB89() {
    if(document.getElementById("imgSqrs89").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs89").src = "img/sqrs/blSqr.png"
};
};
function sqrsB90() {
    if(document.getElementById("imgSqrs90").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs90").src = "img/sqrs/blSqr.png"
};
};
function sqrsB91() {
    if(document.getElementById("imgSqrs91").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs91").src = "img/sqrs/blSqr.png"
};
};
function sqrsB92() {
    if(document.getElementById("imgSqrs92").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs92").src = "img/sqrs/blSqr.png"
};
};
function sqrsB93() {
    if(document.getElementById("imgSqrs93").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs93").src = "img/sqrs/blSqr.png"
};
};
function sqrsB94() {
    if(document.getElementById("imgSqrs94").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs94").src = "img/sqrs/blSqr.png"
};
};
function sqrsB95() {
    if(document.getElementById("imgSqrs95").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs95").src = "img/sqrs/blSqr.png"
};
};
function sqrsB96() {
    if(document.getElementById("imgSqrs96").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs96").src = "img/sqrs/blSqr.png"
};
};
function sqrsB97() {
    if(document.getElementById("imgSqrs97").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs97").src = "img/sqrs/blSqr.png"
};
};
function sqrsB98() {
    if(document.getElementById("imgSqrs98").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs98").src = "img/sqrs/blSqr.png"
};
};
function sqrsB99() {
    if(document.getElementById("imgSqrs99").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs99").src = "img/sqrs/blSqr.png"
};
};
function sqrsB100() {
    if(document.getElementById("imgSqrs100").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs100").src = "img/sqrs/blSqr.png"
};
};
function sqrsC101() {
    if(document.getElementById("imgSqrs101").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs101").src = "img/sqrs/blSqr.png"
};
};
function sqrsC102() {
    if(document.getElementById("imgSqrs102").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs102").src = "img/sqrs/blSqr.png"
};
};
function sqrsC103() {
    if(document.getElementById("imgSqrs103").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs103").src = "img/sqrs/blSqr.png"
};
};
function sqrsC104() {
    if(document.getElementById("imgSqrs104").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs104").src = "img/sqrs/blSqr.png"
};
};
function sqrsC105() {
    if(document.getElementById("imgSqrs105").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs105").src = "img/sqrs/blSqr.png"
};
};
function sqrsC106() {
    if(document.getElementById("imgSqrs106").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs106").src = "img/sqrs/blSqr.png"
};
};
function sqrsC107() {
    if(document.getElementById("imgSqrs107").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs107").src = "img/sqrs/blSqr.png"
};
};
function sqrsC108() {
    if(document.getElementById("imgSqrs108").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs108").src = "img/sqrs/blSqr.png"
};
};
function sqrsC109() {
    if(document.getElementById("imgSqrs109").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs109").src = "img/sqrs/blSqr.png"
};
};
function sqrsC110() {
    if(document.getElementById("imgSqrs110").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs110").src = "img/sqrs/blSqr.png"
};
};
function sqrsC111() {
    if(document.getElementById("imgSqrs111").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs111").src = "img/sqrs/blSqr.png"
};
};
function sqrsC112() {
    if(document.getElementById("imgSqrs112").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs112").src = "img/sqrs/blSqr.png"
};
};
function sqrsC113() {
    if(document.getElementById("imgSqrs113").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs113").src = "img/sqrs/blSqr.png"
};
};
function sqrsC114() {
    if(document.getElementById("imgSqrs114").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs114").src = "img/sqrs/blSqr.png"
};
};
function sqrsC115() {
    if(document.getElementById("imgSqrs115").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs115").src = "img/sqrs/blSqr.png"
};
};
function sqrsC116() {
    if(document.getElementById("imgSqrs116").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs116").src = "img/sqrs/blSqr.png"
};
};
function sqrsC117() {
    if(document.getElementById("imgSqrs117").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs117").src = "img/sqrs/blSqr.png"
};
};
function sqrsC118() {
    if(document.getElementById("imgSqrs118").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs118").src = "img/sqrs/blSqr.png"
};
};
function sqrsC119() {
    if(document.getElementById("imgSqrs119").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs119").src = "img/sqrs/blSqr.png"
};
};
function sqrsC120() {
    if(document.getElementById("imgSqrs120").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs120").src = "img/sqrs/blSqr.png"
};
};
function sqrsC121() {
    if(document.getElementById("imgSqrs121").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs121").src = "img/sqrs/blSqr.png"
};
};
function sqrsC122() {
    if(document.getElementById("imgSqrs122").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs122").src = "img/sqrs/blSqr.png"
};
};
function sqrsC123() {
    if(document.getElementById("imgSqrs123").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs123").src = "img/sqrs/blSqr.png"
};
};
function sqrsC124() {
    if(document.getElementById("imgSqrs124").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs124").src = "img/sqrs/blSqr.png"
};
};
function sqrsC125() {
    if(document.getElementById("imgSqrs125").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs125").src = "img/sqrs/blSqr.png"
};
};
function sqrsC126() {
    if(document.getElementById("imgSqrs126").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs126").src = "img/sqrs/blSqr.png"
};
};
function sqrsC127() {
    if(document.getElementById("imgSqrs127").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs127").src = "img/sqrs/blSqr.png"
};
};
function sqrsC128() {
    if(document.getElementById("imgSqrs128").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs128").src = "img/sqrs/blSqr.png"
};
};
function sqrsC129() {
    if(document.getElementById("imgSqrs129").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs129").src = "img/sqrs/blSqr.png"
};
};
function sqrsC130() {
    if(document.getElementById("imgSqrs130").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs130").src = "img/sqrs/blSqr.png"
};
};
function sqrsC131() {
    if(document.getElementById("imgSqrs131").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs131").src = "img/sqrs/blSqr.png"
};
};
function sqrsC132() {
    if(document.getElementById("imgSqrs132").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs132").src = "img/sqrs/blSqr.png"
};
};
function sqrsC133() {
    if(document.getElementById("imgSqrs133").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs133").src = "img/sqrs/blSqr.png"
};
};
function sqrsC134() {
    if(document.getElementById("imgSqrs134").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs134").src = "img/sqrs/blSqr.png"
};
};
function sqrsC135() {
    if(document.getElementById("imgSqrs135").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs135").src = "img/sqrs/blSqr.png"
};
};
function sqrsC136() {
    if(document.getElementById("imgSqrs136").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs136").src = "img/sqrs/blSqr.png"
};
};
function sqrsC137() {
    if(document.getElementById("imgSqrs137").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs137").src = "img/sqrs/blSqr.png"
};
};
function sqrsC138() {
    if(document.getElementById("imgSqrs138").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs138").src = "img/sqrs/blSqr.png"
};
};
function sqrsC139() {
    if(document.getElementById("imgSqrs139").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs139").src = "img/sqrs/blSqr.png"
};
};
function sqrsC140() {
    if(document.getElementById("imgSqrs140").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs140").src = "img/sqrs/blSqr.png"
};
};
function sqrsC141() {
    if(document.getElementById("imgSqrs141").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs141").src = "img/sqrs/blSqr.png"
};
};
function sqrsC142() {
    if(document.getElementById("imgSqrs142").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs142").src = "img/sqrs/blSqr.png"
};
};
function sqrsC143() {
    if(document.getElementById("imgSqrs143").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs143").src = "img/sqrs/blSqr.png"
};
};
function sqrsC144() {
    if(document.getElementById("imgSqrs144").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs144").src = "img/sqrs/blSqr.png"
};
};
function sqrsC145() {
    if(document.getElementById("imgSqrs145").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs145").src = "img/sqrs/blSqr.png"
};
};
function sqrsC146() {
    if(document.getElementById("imgSqrs146").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs146").src = "img/sqrs/blSqr.png"
};
};
function sqrsC147() {
    if(document.getElementById("imgSqrs147").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs147").src = "img/sqrs/blSqr.png"
};
};
function sqrsC148() {
    if(document.getElementById("imgSqrs148").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs148").src = "img/sqrs/blSqr.png"
};
};
function sqrsC149() {
    if(document.getElementById("imgSqrs149").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs149").src = "img/sqrs/blSqr.png"
};
};
function sqrsC150() {
    if(document.getElementById("imgSqrs150").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs150").src = "img/sqrs/blSqr.png"
};
};
function sqrsD151() {
    if(document.getElementById("imgSqrs151").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs151").src = "img/sqrs/blSqr.png"
};
};
function sqrsD152() {
    if(document.getElementById("imgSqrs152").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs152").src = "img/sqrs/blSqr.png"
};
};
function sqrsD153() {
    if(document.getElementById("imgSqrs153").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs153").src = "img/sqrs/blSqr.png"
};
};
function sqrsD154() {
    if(document.getElementById("imgSqrs154").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs154").src = "img/sqrs/blSqr.png"
};
};
function sqrsD155() {
    if(document.getElementById("imgSqrs155").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs155").src = "img/sqrs/blSqr.png"
};
};
function sqrsD156() {
    if(document.getElementById("imgSqrs156").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs156").src = "img/sqrs/blSqr.png"
};
};
function sqrsD157() {
    if(document.getElementById("imgSqrs157").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs157").src = "img/sqrs/blSqr.png"
};
};
function sqrsD158() {
    if(document.getElementById("imgSqrs158").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs158").src = "img/sqrs/blSqr.png"
};
};
function sqrsD159() {
    if(document.getElementById("imgSqrs159").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs159").src = "img/sqrs/blSqr.png"
};
};
function sqrsD160() {
    if(document.getElementById("imgSqrs160").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs160").src = "img/sqrs/blSqr.png"
};
};
function sqrsD161() {
    if(document.getElementById("imgSqrs161").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs161").src = "img/sqrs/blSqr.png"
};
};
function sqrsD162() {
    if(document.getElementById("imgSqrs162").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs162").src = "img/sqrs/blSqr.png"
};
};
function sqrsD163() {
    if(document.getElementById("imgSqrs163").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs163").src = "img/sqrs/blSqr.png"
};
};
function sqrsD164() {
    if(document.getElementById("imgSqrs164").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs164").src = "img/sqrs/blSqr.png"
};
};
function sqrsD165() {
    if(document.getElementById("imgSqrs165").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs165").src = "img/sqrs/blSqr.png"
};
};
function sqrsD166() {
    if(document.getElementById("imgSqrs166").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs166").src = "img/sqrs/blSqr.png"
};
};
function sqrsD167() {
    if(document.getElementById("imgSqrs167").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs167").src = "img/sqrs/blSqr.png"
};
};
function sqrsD168() {
    if(document.getElementById("imgSqrs168").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs168").src = "img/sqrs/blSqr.png"
};
};
function sqrsD169() {
    if(document.getElementById("imgSqrs169").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs169").src = "img/sqrs/blSqr.png"
};
};
function sqrsD170() {
    if(document.getElementById("imgSqrs170").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs170").src = "img/sqrs/blSqr.png"
};
};
function sqrsD171() {
    if(document.getElementById("imgSqrs171").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs171").src = "img/sqrs/blSqr.png"
};
};
function sqrsD172() {
    if(document.getElementById("imgSqrs172").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs172").src = "img/sqrs/blSqr.png"
};
};
function sqrsD173() {
    if(document.getElementById("imgSqrs173").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs173").src = "img/sqrs/blSqr.png"
};
};
function sqrsD174() {
    if(document.getElementById("imgSqrs174").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs174").src = "img/sqrs/blSqr.png"
};
};
function sqrsD175() {
    if(document.getElementById("imgSqrs175").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs175").src = "img/sqrs/blSqr.png"
};
};
function sqrsD176() {
    if(document.getElementById("imgSqrs176").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs176").src = "img/sqrs/blSqr.png"
};
};
function sqrsD177() {
    if(document.getElementById("imgSqrs177").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs177").src = "img/sqrs/blSqr.png"
};
};
function sqrsD178() {
    if(document.getElementById("imgSqrs178").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs178").src = "img/sqrs/blSqr.png"
};
};
function sqrsD179() {
    if(document.getElementById("imgSqrs179").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs179").src = "img/sqrs/blSqr.png"
};
};
function sqrsD180() {
    if(document.getElementById("imgSqrs180").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs180").src = "img/sqrs/blSqr.png"
};
};
function sqrsD181() {
    if(document.getElementById("imgSqrs181").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs181").src = "img/sqrs/blSqr.png"
};
};
function sqrsD182() {
    if(document.getElementById("imgSqrs182").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs182").src = "img/sqrs/blSqr.png"
};
};
function sqrsD183() {
    if(document.getElementById("imgSqrs183").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs183").src = "img/sqrs/blSqr.png"
};
};
function sqrsD184() {
    if(document.getElementById("imgSqrs184").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs184").src = "img/sqrs/blSqr.png"
};
};
function sqrsD185() {
    if(document.getElementById("imgSqrs185").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs185").src = "img/sqrs/blSqr.png"
};
};
function sqrsD186() {
    if(document.getElementById("imgSqrs186").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs186").src = "img/sqrs/blSqr.png"
};
};
function sqrsD187() {
    if(document.getElementById("imgSqrs187").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs187").src = "img/sqrs/blSqr.png"
};
};
function sqrsD188() {
    if(document.getElementById("imgSqrs188").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs188").src = "img/sqrs/blSqr.png"
};
};
function sqrsD189() {
    if(document.getElementById("imgSqrs189").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs189").src = "img/sqrs/blSqr.png"
};
};
function sqrsD190() {
    if(document.getElementById("imgSqrs190").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs190").src = "img/sqrs/blSqr.png"
};
};
function sqrsD191() {
    if(document.getElementById("imgSqrs191").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs191").src = "img/sqrs/blSqr.png"
};
};
function sqrsD192() {
    if(document.getElementById("imgSqrs192").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs192").src = "img/sqrs/blSqr.png"
};
};
function sqrsD193() {
    if(document.getElementById("imgSqrs193").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs193").src = "img/sqrs/blSqr.png"
};
};
function sqrsD194() {
    if(document.getElementById("imgSqrs194").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs194").src = "img/sqrs/blSqr.png"
};
};
function sqrsD195() {
    if(document.getElementById("imgSqrs195").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs195").src = "img/sqrs/blSqr.png"
};
};
function sqrsD196() {
    if(document.getElementById("imgSqrs196").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs196").src = "img/sqrs/blSqr.png"
};
};
function sqrsD197() {
    if(document.getElementById("imgSqrs197").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs197").src = "img/sqrs/blSqr.png"
};
};
function sqrsD198() {
    if(document.getElementById("imgSqrs198").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs198").src = "img/sqrs/blSqr.png"
};
};
function sqrsD199() {
    if(document.getElementById("imgSqrs199").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs199").src = "img/sqrs/blSqr.png"
};
};
function sqrsD200() {
    if(document.getElementById("imgSqrs200").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs200").src = "img/sqrs/blSqr.png"
};
};
function sqrsE201() {
    if(document.getElementById("imgSqrs201").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs201").src = "img/sqrs/blSqr.png"
};
};
function sqrsE202() {
    if(document.getElementById("imgSqrs202").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs202").src = "img/sqrs/blSqr.png"
};
};
function sqrsE203() {
    if(document.getElementById("imgSqrs203").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs203").src = "img/sqrs/blSqr.png"
};
};
function sqrsE204() {
    if(document.getElementById("imgSqrs204").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs204").src = "img/sqrs/blSqr.png"
};
};
function sqrsE205() {
    if(document.getElementById("imgSqrs205").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs205").src = "img/sqrs/blSqr.png"
};
};
function sqrsE206() {
    if(document.getElementById("imgSqrs206").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs206").src = "img/sqrs/blSqr.png"
};
};
function sqrsE207() {
    if(document.getElementById("imgSqrs207").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs207").src = "img/sqrs/blSqr.png"
};
};
function sqrsE208() {
    if(document.getElementById("imgSqrs208").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs208").src = "img/sqrs/blSqr.png"
};
};
function sqrsE209() {
    if(document.getElementById("imgSqrs209").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs209").src = "img/sqrs/blSqr.png"
};
};
function sqrsE210() {
    if(document.getElementById("imgSqrs210").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs210").src = "img/sqrs/blSqr.png"
};
};
function sqrsE211() {
    if(document.getElementById("imgSqrs211").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs211").src = "img/sqrs/blSqr.png"
};
};
function sqrsE212() {
    if(document.getElementById("imgSqrs212").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs212").src = "img/sqrs/blSqr.png"
};
};
function sqrsE213() {
    if(document.getElementById("imgSqrs213").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs213").src = "img/sqrs/blSqr.png"
};
};
function sqrsE214() {
    if(document.getElementById("imgSqrs214").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs214").src = "img/sqrs/blSqr.png"
};
};
function sqrsE215() {
    if(document.getElementById("imgSqrs215").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs215").src = "img/sqrs/blSqr.png"
};
};
function sqrsE216() {
    if(document.getElementById("imgSqrs216").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs216").src = "img/sqrs/blSqr.png"
};
};
function sqrsE217() {
    if(document.getElementById("imgSqrs217").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs217").src = "img/sqrs/blSqr.png"
};
};
function sqrsE218() {
    if(document.getElementById("imgSqrs218").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs218").src = "img/sqrs/blSqr.png"
};
};
function sqrsE219() {
    if(document.getElementById("imgSqrs219").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs219").src = "img/sqrs/blSqr.png"
};
};
function sqrsE220() {
    if(document.getElementById("imgSqrs220").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs220").src = "img/sqrs/blSqr.png"
};
};
function sqrsE221() {
    if(document.getElementById("imgSqrs221").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs221").src = "img/sqrs/blSqr.png"
};
};
function sqrsE222() {
    if(document.getElementById("imgSqrs222").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs222").src = "img/sqrs/blSqr.png"
};
};
function sqrsE223() {
    if(document.getElementById("imgSqrs223").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs223").src = "img/sqrs/blSqr.png"
};
};
function sqrsE224() {
    if(document.getElementById("imgSqrs224").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs224").src = "img/sqrs/blSqr.png"
};
};
function sqrsE225() {
    if(document.getElementById("imgSqrs225").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs225").src = "img/sqrs/blSqr.png"
};
};
function sqrsE226() {
    if(document.getElementById("imgSqrs226").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs226").src = "img/sqrs/blSqr.png"
};
};
function sqrsE227() {
    if(document.getElementById("imgSqrs227").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs227").src = "img/sqrs/blSqr.png"
};
};
function sqrsE228() {
    if(document.getElementById("imgSqrs228").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs228").src = "img/sqrs/blSqr.png"
};
};
function sqrsE229() {
    if(document.getElementById("imgSqrs229").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs229").src = "img/sqrs/blSqr.png"
};
};
function sqrsE230() {
    if(document.getElementById("imgSqrs230").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs230").src = "img/sqrs/blSqr.png"
};
};
function sqrsE231() {
    if(document.getElementById("imgSqrs231").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs231").src = "img/sqrs/blSqr.png"
};
};
function sqrsE232() {
    if(document.getElementById("imgSqrs232").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs232").src = "img/sqrs/blSqr.png"
};
};
function sqrsE233() {
    if(document.getElementById("imgSqrs233").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs233").src = "img/sqrs/blSqr.png"
};
};
function sqrsE234() {
    if(document.getElementById("imgSqrs234").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs234").src = "img/sqrs/blSqr.png"
};
};
function sqrsE235() {
    if(document.getElementById("imgSqrs235").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs235").src = "img/sqrs/blSqr.png"
};
};
function sqrsE236() {
    if(document.getElementById("imgSqrs236").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs236").src = "img/sqrs/blSqr.png"
};
};
function sqrsE237() {
    if(document.getElementById("imgSqrs237").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs237").src = "img/sqrs/blSqr.png"
};
};
function sqrsE238() {
    if(document.getElementById("imgSqrs238").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs238").src = "img/sqrs/blSqr.png"
};
};
function sqrsE239() {
    if(document.getElementById("imgSqrs239").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs239").src = "img/sqrs/blSqr.png"
};
};
function sqrsE240() {
    if(document.getElementById("imgSqrs240").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs240").src = "img/sqrs/blSqr.png"
};
};
function sqrsE241() {
    if(document.getElementById("imgSqrs241").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs241").src = "img/sqrs/blSqr.png"
};
};
function sqrsE242() {
    if(document.getElementById("imgSqrs242").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs242").src = "img/sqrs/blSqr.png"
};
};
function sqrsE243() {
    if(document.getElementById("imgSqrs243").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs243").src = "img/sqrs/blSqr.png"
};
};
function sqrsE244() {
    if(document.getElementById("imgSqrs244").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs244").src = "img/sqrs/blSqr.png"
};
};
function sqrsE245() {
    if(document.getElementById("imgSqrs245").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs245").src = "img/sqrs/blSqr.png"
};
};
function sqrsE246() {
    if(document.getElementById("imgSqrs246").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs246").src = "img/sqrs/blSqr.png"
};
};
function sqrsE247() {
    if(document.getElementById("imgSqrs247").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs247").src = "img/sqrs/blSqr.png"
};
};
function sqrsE248() {
    if(document.getElementById("imgSqrs248").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs248").src = "img/sqrs/blSqr.png"
};
};
function sqrsE249() {
    if(document.getElementById("imgSqrs249").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs249").src = "img/sqrs/blSqr.png"
};
};
function sqrsE250() {
    if(document.getElementById("imgSqrs250").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs250").src = "img/sqrs/blSqr.png"
};
};
function sqrsF251() {
    if(document.getElementById("imgSqrs251").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs251").src = "img/sqrs/blSqr.png"
};
};
function sqrsF252() {
    if(document.getElementById("imgSqrs252").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs252").src = "img/sqrs/blSqr.png"
};
};
function sqrsF253() {
    if(document.getElementById("imgSqrs253").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs253").src = "img/sqrs/blSqr.png"
};
};
function sqrsF254() {
    if(document.getElementById("imgSqrs254").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs254").src = "img/sqrs/blSqr.png"
};
};
function sqrsF255() {
    if(document.getElementById("imgSqrs255").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs255").src = "img/sqrs/blSqr.png"
};
};
function sqrsF256() {
    if(document.getElementById("imgSqrs256").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs256").src = "img/sqrs/blSqr.png"
};
};
function sqrsF257() {
    if(document.getElementById("imgSqrs257").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs257").src = "img/sqrs/blSqr.png"
};
};
function sqrsF258() {
    if(document.getElementById("imgSqrs258").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs258").src = "img/sqrs/blSqr.png"
};
};
function sqrsF259() {
    if(document.getElementById("imgSqrs259").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs259").src = "img/sqrs/blSqr.png"
};
};
function sqrsF260() {
    if(document.getElementById("imgSqrs260").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs260").src = "img/sqrs/blSqr.png"
};
};
function sqrsF261() {
    if(document.getElementById("imgSqrs261").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs261").src = "img/sqrs/blSqr.png"
};
};
function sqrsF262() {
    if(document.getElementById("imgSqrs262").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs262").src = "img/sqrs/blSqr.png"
};
};
function sqrsF263() {
    if(document.getElementById("imgSqrs263").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs263").src = "img/sqrs/blSqr.png"
};
};
function sqrsF264() {
    if(document.getElementById("imgSqrs264").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs264").src = "img/sqrs/blSqr.png"
};
};
function sqrsF265() {
    if(document.getElementById("imgSqrs265").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs265").src = "img/sqrs/blSqr.png"
};
};
function sqrsF266() {
    if(document.getElementById("imgSqrs266").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs266").src = "img/sqrs/blSqr.png"
};
};
function sqrsF267() {
    if(document.getElementById("imgSqrs267").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs267").src = "img/sqrs/blSqr.png"
};
};
function sqrsF268() {
    if(document.getElementById("imgSqrs268").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs268").src = "img/sqrs/blSqr.png"
};
};
function sqrsF269() {
    if(document.getElementById("imgSqrs269").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs269").src = "img/sqrs/blSqr.png"
};
};
function sqrsF270() {
    if(document.getElementById("imgSqrs270").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs270").src = "img/sqrs/blSqr.png"
};
};
function sqrsF271() {
    if(document.getElementById("imgSqrs271").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs271").src = "img/sqrs/blSqr.png"
};
};
function sqrsF272() {
    if(document.getElementById("imgSqrs272").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs272").src = "img/sqrs/blSqr.png"
};
};
function sqrsF273() {
    if(document.getElementById("imgSqrs273").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs273").src = "img/sqrs/blSqr.png"
};
};
function sqrsF274() {
    if(document.getElementById("imgSqrs274").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs274").src = "img/sqrs/blSqr.png"
};
};
function sqrsF275() {
    if(document.getElementById("imgSqrs275").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs275").src = "img/sqrs/blSqr.png"
};
};
function sqrsF276() {
    if(document.getElementById("imgSqrs276").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs276").src = "img/sqrs/blSqr.png"
};
};
function sqrsF277() {
    if(document.getElementById("imgSqrs277").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs277").src = "img/sqrs/blSqr.png"
};
};
function sqrsF278() {
    if(document.getElementById("imgSqrs278").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs278").src = "img/sqrs/blSqr.png"
};
};
function sqrsF279() {
    if(document.getElementById("imgSqrs279").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs279").src = "img/sqrs/blSqr.png"
};
};
function sqrsF280() {
    if(document.getElementById("imgSqrs280").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs280").src = "img/sqrs/blSqr.png"
};
};
function sqrsF281() {
    if(document.getElementById("imgSqrs281").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs281").src = "img/sqrs/blSqr.png"
};
};
function sqrsF282() {
    if(document.getElementById("imgSqrs282").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs282").src = "img/sqrs/blSqr.png"
};
};
function sqrsF283() {
    if(document.getElementById("imgSqrs283").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs283").src = "img/sqrs/blSqr.png"
};
};
function sqrsF284() {
    if(document.getElementById("imgSqrs284").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs284").src = "img/sqrs/blSqr.png"
};
};
function sqrsF285() {
    if(document.getElementById("imgSqrs285").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs285").src = "img/sqrs/blSqr.png"
};
};
function sqrsF286() {
    if(document.getElementById("imgSqrs286").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs286").src = "img/sqrs/blSqr.png"
};
};
function sqrsF287() {
    if(document.getElementById("imgSqrs287").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs287").src = "img/sqrs/blSqr.png"
};
};
function sqrsF288() {
    if(document.getElementById("imgSqrs288").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs288").src = "img/sqrs/blSqr.png"
};
};
function sqrsF289() {
    if(document.getElementById("imgSqrs289").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs289").src = "img/sqrs/blSqr.png"
};
};
function sqrsF290() {
    if(document.getElementById("imgSqrs290").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs290").src = "img/sqrs/blSqr.png"
};
};
function sqrsF291() {
    if(document.getElementById("imgSqrs291").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs291").src = "img/sqrs/blSqr.png"
};
};
function sqrsF292() {
    if(document.getElementById("imgSqrs292").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs292").src = "img/sqrs/blSqr.png"
};
};
function sqrsF293() {
    if(document.getElementById("imgSqrs293").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs293").src = "img/sqrs/blSqr.png"
};
};
function sqrsF294() {
    if(document.getElementById("imgSqrs294").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs294").src = "img/sqrs/blSqr.png"
};
};
function sqrsF295() {
    if(document.getElementById("imgSqrs295").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs295").src = "img/sqrs/blSqr.png"
};
};
function sqrsF296() {
    if(document.getElementById("imgSqrs296").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs296").src = "img/sqrs/blSqr.png"
};
};
function sqrsF297() {
    if(document.getElementById("imgSqrs297").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs297").src = "img/sqrs/blSqr.png"
};
};
function sqrsF298() {
    if(document.getElementById("imgSqrs298").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs298").src = "img/sqrs/blSqr.png"
};
};
function sqrsF299() {
    if(document.getElementById("imgSqrs299").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs299").src = "img/sqrs/blSqr.png"
};
};
function sqrsF300() {
    if(document.getElementById("imgSqrs300").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs300").src = "img/sqrs/blSqr.png"
};
};
function sqrsG301() {
    if(document.getElementById("imgSqrs301").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs301").src = "img/sqrs/blSqr.png"
};
};
function sqrsG302() {
    if(document.getElementById("imgSqrs302").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs302").src = "img/sqrs/blSqr.png"
};
};
function sqrsG303() {
    if(document.getElementById("imgSqrs303").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs303").src = "img/sqrs/blSqr.png"
};
};
function sqrsG304() {
    if(document.getElementById("imgSqrs304").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs304").src = "img/sqrs/blSqr.png"
};
};
function sqrsG305() {
    if(document.getElementById("imgSqrs305").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs305").src = "img/sqrs/blSqr.png"
};
};
function sqrsG306() {
    if(document.getElementById("imgSqrs306").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs306").src = "img/sqrs/blSqr.png"
};
};
function sqrsG307() {
    if(document.getElementById("imgSqrs307").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs307").src = "img/sqrs/blSqr.png"
};
};
function sqrsG308() {
    if(document.getElementById("imgSqrs308").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs308").src = "img/sqrs/blSqr.png"
};
};
function sqrsG309() {
    if(document.getElementById("imgSqrs309").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs309").src = "img/sqrs/blSqr.png"
};
};
function sqrsG310() {
    if(document.getElementById("imgSqrs310").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs310").src = "img/sqrs/blSqr.png"
};
};
function sqrsG311() {
    if(document.getElementById("imgSqrs311").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs311").src = "img/sqrs/blSqr.png"
};
};
function sqrsG312() {
    if(document.getElementById("imgSqrs312").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs312").src = "img/sqrs/blSqr.png"
};
};
function sqrsG313() {
    if(document.getElementById("imgSqrs313").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs313").src = "img/sqrs/blSqr.png"
};
};
function sqrsG314() {
    if(document.getElementById("imgSqrs314").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs314").src = "img/sqrs/blSqr.png"
};
};
function sqrsG315() {
    if(document.getElementById("imgSqrs315").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs315").src = "img/sqrs/blSqr.png"
};
};
function sqrsG316() {
    if(document.getElementById("imgSqrs316").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs316").src = "img/sqrs/blSqr.png"
};
};
function sqrsG317() {
    if(document.getElementById("imgSqrs317").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs317").src = "img/sqrs/blSqr.png"
};
};
function sqrsG318() {
    if(document.getElementById("imgSqrs318").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs318").src = "img/sqrs/blSqr.png"
};
};
function sqrsG319() {
    if(document.getElementById("imgSqrs319").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs319").src = "img/sqrs/blSqr.png"
};
};
function sqrsG320() {
    if(document.getElementById("imgSqrs320").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs320").src = "img/sqrs/blSqr.png"
};
};
function sqrsG321() {
    if(document.getElementById("imgSqrs321").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs321").src = "img/sqrs/blSqr.png"
};
};
function sqrsG322() {
    if(document.getElementById("imgSqrs322").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs322").src = "img/sqrs/blSqr.png"
};
};
function sqrsG323() {
    if(document.getElementById("imgSqrs323").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs323").src = "img/sqrs/blSqr.png"
};
};
function sqrsG324() {
    if(document.getElementById("imgSqrs324").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs324").src = "img/sqrs/blSqr.png"
};
};
function sqrsG325() {
    if(document.getElementById("imgSqrs325").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs325").src = "img/sqrs/blSqr.png"
};
};
function sqrsG326() {
    if(document.getElementById("imgSqrs326").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs326").src = "img/sqrs/blSqr.png"
};
};
function sqrsG327() {
    if(document.getElementById("imgSqrs327").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs327").src = "img/sqrs/blSqr.png"
};
};
function sqrsG328() {
    if(document.getElementById("imgSqrs328").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs328").src = "img/sqrs/blSqr.png"
};
};
function sqrsG329() {
    if(document.getElementById("imgSqrs329").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs329").src = "img/sqrs/blSqr.png"
};
};
function sqrsG330() {
    if(document.getElementById("imgSqrs330").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs330").src = "img/sqrs/blSqr.png"
};
};
function sqrsG331() {
    if(document.getElementById("imgSqrs331").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs331").src = "img/sqrs/blSqr.png"
};
};
function sqrsG332() {
    if(document.getElementById("imgSqrs332").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs332").src = "img/sqrs/blSqr.png"
};
};
function sqrsG333() {
    if(document.getElementById("imgSqrs333").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs333").src = "img/sqrs/blSqr.png"
};
};
function sqrsG334() {
    if(document.getElementById("imgSqrs334").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs334").src = "img/sqrs/blSqr.png"
};
};
function sqrsG335() {
    if(document.getElementById("imgSqrs335").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs335").src = "img/sqrs/blSqr.png"
};
};
function sqrsG336() {
    if(document.getElementById("imgSqrs336").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs336").src = "img/sqrs/blSqr.png"
};
};
function sqrsG337() {
    if(document.getElementById("imgSqrs337").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs337").src = "img/sqrs/blSqr.png"
};
};
function sqrsG338() {
    if(document.getElementById("imgSqrs338").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs338").src = "img/sqrs/blSqr.png"
};
};
function sqrsG339() {
    if(document.getElementById("imgSqrs339").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs339").src = "img/sqrs/blSqr.png"
};
};
function sqrsG340() {
    if(document.getElementById("imgSqrs340").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs340").src = "img/sqrs/blSqr.png"
};
};
function sqrsG341() {
    if(document.getElementById("imgSqrs341").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs341").src = "img/sqrs/blSqr.png"
};
};
function sqrsG342() {
    if(document.getElementById("imgSqrs342").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs342").src = "img/sqrs/blSqr.png"
};
};
function sqrsG343() {
    if(document.getElementById("imgSqrs343").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs343").src = "img/sqrs/blSqr.png"
};
};
function sqrsG344() {
    if(document.getElementById("imgSqrs344").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs344").src = "img/sqrs/blSqr.png"
};
};
function sqrsG345() {
    if(document.getElementById("imgSqrs345").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs345").src = "img/sqrs/blSqr.png"
};
};
function sqrsG346() {
    if(document.getElementById("imgSqrs346").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs346").src = "img/sqrs/blSqr.png"
};
};
function sqrsG347() {
    if(document.getElementById("imgSqrs347").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs347").src = "img/sqrs/blSqr.png"
};
};
function sqrsG348() {
    if(document.getElementById("imgSqrs348").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs348").src = "img/sqrs/blSqr.png"
};
};
function sqrsG349() {
    if(document.getElementById("imgSqrs349").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs349").src = "img/sqrs/blSqr.png"
};
};
function sqrsG350() {
    if(document.getElementById("imgSqrs350").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs350").src = "img/sqrs/blSqr.png"
};
};
function sqrsH351() {
    if(document.getElementById("imgSqrs351").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs351").src = "img/sqrs/blSqr.png"
};
};
function sqrsH352() {
    if(document.getElementById("imgSqrs352").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs352").src = "img/sqrs/blSqr.png"
};
};
function sqrsH353() {
    if(document.getElementById("imgSqrs353").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs353").src = "img/sqrs/blSqr.png"
};
};
function sqrsH354() {
    if(document.getElementById("imgSqrs354").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs354").src = "img/sqrs/blSqr.png"
};
};
function sqrsH355() {
    if(document.getElementById("imgSqrs355").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs355").src = "img/sqrs/blSqr.png"
};
};
function sqrsH356() {
    if(document.getElementById("imgSqrs356").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs356").src = "img/sqrs/blSqr.png"
};
};
function sqrsH357() {
    if(document.getElementById("imgSqrs357").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs357").src = "img/sqrs/blSqr.png"
};
};
function sqrsH358() {
    if(document.getElementById("imgSqrs358").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs358").src = "img/sqrs/blSqr.png"
};
};
function sqrsH359() {
    if(document.getElementById("imgSqrs359").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs359").src = "img/sqrs/blSqr.png"
};
};
function sqrsH360() {
    if(document.getElementById("imgSqrs360").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs360").src = "img/sqrs/blSqr.png"
};
};
function sqrsH361() {
    if(document.getElementById("imgSqrs361").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs361").src = "img/sqrs/blSqr.png"
};
};
function sqrsH362() {
    if(document.getElementById("imgSqrs362").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs362").src = "img/sqrs/blSqr.png"
};
};
function sqrsH363() {
    if(document.getElementById("imgSqrs363").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs363").src = "img/sqrs/blSqr.png"
};
};
function sqrsH364() {
    if(document.getElementById("imgSqrs364").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs364").src = "img/sqrs/blSqr.png"
};
};
function sqrsH365() {
    if(document.getElementById("imgSqrs365").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs365").src = "img/sqrs/blSqr.png"
};
};
function sqrsH366() {
    if(document.getElementById("imgSqrs366").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs366").src = "img/sqrs/blSqr.png"
};
};
function sqrsH367() {
    if(document.getElementById("imgSqrs367").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs367").src = "img/sqrs/blSqr.png"
};
};
function sqrsH368() {
    if(document.getElementById("imgSqrs368").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs368").src = "img/sqrs/blSqr.png"
};
};
function sqrsH369() {
    if(document.getElementById("imgSqrs369").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs369").src = "img/sqrs/blSqr.png"
};
};
function sqrsH370() {
    if(document.getElementById("imgSqrs370").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs370").src = "img/sqrs/blSqr.png"
};
};
function sqrsH371() {
    if(document.getElementById("imgSqrs371").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs371").src = "img/sqrs/blSqr.png"
};
};
function sqrsH372() {
    if(document.getElementById("imgSqrs372").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs372").src = "img/sqrs/blSqr.png"
};
};
function sqrsH373() {
    if(document.getElementById("imgSqrs373").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs373").src = "img/sqrs/blSqr.png"
};
};
function sqrsH374() {
    if(document.getElementById("imgSqrs374").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs374").src = "img/sqrs/blSqr.png"
};
};
function sqrsH375() {
    if(document.getElementById("imgSqrs375").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs375").src = "img/sqrs/blSqr.png"
};
};
function sqrsH376() {
    if(document.getElementById("imgSqrs376").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs376").src = "img/sqrs/blSqr.png"
};
};
function sqrsH377() {
    if(document.getElementById("imgSqrs377").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs377").src = "img/sqrs/blSqr.png"
};
};
function sqrsH378() {
    if(document.getElementById("imgSqrs378").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs378").src = "img/sqrs/blSqr.png"
};
};
function sqrsH379() {
    if(document.getElementById("imgSqrs379").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs379").src = "img/sqrs/blSqr.png"
};
};
function sqrsH380() {
    if(document.getElementById("imgSqrs380").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs380").src = "img/sqrs/blSqr.png"
};
};
function sqrsH381() {
    if(document.getElementById("imgSqrs381").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs381").src = "img/sqrs/blSqr.png"
};
};
function sqrsH382() {
    if(document.getElementById("imgSqrs382").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs382").src = "img/sqrs/blSqr.png"
};
};
function sqrsH383() {
    if(document.getElementById("imgSqrs383").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs383").src = "img/sqrs/blSqr.png"
};
};
function sqrsH384() {
    if(document.getElementById("imgSqrs384").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs384").src = "img/sqrs/blSqr.png"
};
};
function sqrsH385() {
    if(document.getElementById("imgSqrs385").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs385").src = "img/sqrs/blSqr.png"
};
};
function sqrsH386() {
    if(document.getElementById("imgSqrs386").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs386").src = "img/sqrs/blSqr.png"
};
};
function sqrsH387() {
    if(document.getElementById("imgSqrs387").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs387").src = "img/sqrs/blSqr.png"
};
};
function sqrsH388() {
    if(document.getElementById("imgSqrs388").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs388").src = "img/sqrs/blSqr.png"
};
};
function sqrsH389() {
    if(document.getElementById("imgSqrs389").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs389").src = "img/sqrs/blSqr.png"
};
};
function sqrsH390() {
    if(document.getElementById("imgSqrs390").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs390").src = "img/sqrs/blSqr.png"
};
};
function sqrsH391() {
    if(document.getElementById("imgSqrs391").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs391").src = "img/sqrs/blSqr.png"
};
};
function sqrsH392() {
    if(document.getElementById("imgSqrs392").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs392").src = "img/sqrs/blSqr.png"
};
};
function sqrsH393() {
    if(document.getElementById("imgSqrs393").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs393").src = "img/sqrs/blSqr.png"
};
};
function sqrsH394() {
    if(document.getElementById("imgSqrs394").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs394").src = "img/sqrs/blSqr.png"
};
};
function sqrsH395() {
    if(document.getElementById("imgSqrs395").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs395").src = "img/sqrs/blSqr.png"
};
};
function sqrsH396() {
    if(document.getElementById("imgSqrs396").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs396").src = "img/sqrs/blSqr.png"
};
};
function sqrsH397() {
    if(document.getElementById("imgSqrs397").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs397").src = "img/sqrs/blSqr.png"
};
};
function sqrsH398() {
    if(document.getElementById("imgSqrs398").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs398").src = "img/sqrs/blSqr.png"
};
};
function sqrsH399() {
    if(document.getElementById("imgSqrs399").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs399").src = "img/sqrs/blSqr.png"
};
};
function sqrsH400() {
    if(document.getElementById("imgSqrs400").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs400").src = "img/sqrs/blSqr.png"
};
};
function sqrsI401() {
    if(document.getElementById("imgSqrs401").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs401").src = "img/sqrs/blSqr.png"
};
};
function sqrsI402() {
    if(document.getElementById("imgSqrs402").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs402").src = "img/sqrs/blSqr.png"
};
};
function sqrsI403() {
    if(document.getElementById("imgSqrs403").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs403").src = "img/sqrs/blSqr.png"
};
};
function sqrsI404() {
    if(document.getElementById("imgSqrs404").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs404").src = "img/sqrs/blSqr.png"
};
};
function sqrsI405() {
    if(document.getElementById("imgSqrs405").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs405").src = "img/sqrs/blSqr.png"
};
};
function sqrsI406() {
    if(document.getElementById("imgSqrs406").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs406").src = "img/sqrs/blSqr.png"
};
};
function sqrsI407() {
    if(document.getElementById("imgSqrs407").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs407").src = "img/sqrs/blSqr.png"
};
};
function sqrsI408() {
    if(document.getElementById("imgSqrs408").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs408").src = "img/sqrs/blSqr.png"
};
};
function sqrsI409() {
    if(document.getElementById("imgSqrs409").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs409").src = "img/sqrs/blSqr.png"
};
};
function sqrsI410() {
    if(document.getElementById("imgSqrs410").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs410").src = "img/sqrs/blSqr.png"
};
};
function sqrsI411() {
    if(document.getElementById("imgSqrs411").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs411").src = "img/sqrs/blSqr.png"
};
};
function sqrsI412() {
    if(document.getElementById("imgSqrs412").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs412").src = "img/sqrs/blSqr.png"
};
};
function sqrsI413() {
    if(document.getElementById("imgSqrs413").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs413").src = "img/sqrs/blSqr.png"
};
};
function sqrsI414() {
    if(document.getElementById("imgSqrs414").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs414").src = "img/sqrs/blSqr.png"
};
};
function sqrsI415() {
    if(document.getElementById("imgSqrs415").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs415").src = "img/sqrs/blSqr.png"
};
};
function sqrsI416() {
    if(document.getElementById("imgSqrs416").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs416").src = "img/sqrs/blSqr.png"
};
};
function sqrsI417() {
    if(document.getElementById("imgSqrs417").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs417").src = "img/sqrs/blSqr.png"
};
};
function sqrsI418() {
    if(document.getElementById("imgSqrs418").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs418").src = "img/sqrs/blSqr.png"
};
};
function sqrsI419() {
    if(document.getElementById("imgSqrs419").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs419").src = "img/sqrs/blSqr.png"
};
};
function sqrsI420() {
    if(document.getElementById("imgSqrs420").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs420").src = "img/sqrs/blSqr.png"
};
};
function sqrsI421() {
    if(document.getElementById("imgSqrs421").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs421").src = "img/sqrs/blSqr.png"
};
};
function sqrsI422() {
    if(document.getElementById("imgSqrs422").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs422").src = "img/sqrs/blSqr.png"
};
};
function sqrsI423() {
    if(document.getElementById("imgSqrs423").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs423").src = "img/sqrs/blSqr.png"
};
};
function sqrsI424() {
    if(document.getElementById("imgSqrs424").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs424").src = "img/sqrs/blSqr.png"
};
};
function sqrsI425() {
    if(document.getElementById("imgSqrs425").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs425").src = "img/sqrs/blSqr.png"
};
};
function sqrsI426() {
    if(document.getElementById("imgSqrs426").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs426").src = "img/sqrs/blSqr.png"
};
};
function sqrsI427() {
    if(document.getElementById("imgSqrs427").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs427").src = "img/sqrs/blSqr.png"
};
};
function sqrsI428() {
    if(document.getElementById("imgSqrs428").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs428").src = "img/sqrs/blSqr.png"
};
};
function sqrsI429() {
    if(document.getElementById("imgSqrs429").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs429").src = "img/sqrs/blSqr.png"
};
};
function sqrsI430() {
    if(document.getElementById("imgSqrs430").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs430").src = "img/sqrs/blSqr.png"
};
};
function sqrsI431() {
    if(document.getElementById("imgSqrs431").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs431").src = "img/sqrs/blSqr.png"
};
};
function sqrsI432() {
    if(document.getElementById("imgSqrs432").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs432").src = "img/sqrs/blSqr.png"
};
};
function sqrsI433() {
    if(document.getElementById("imgSqrs433").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs433").src = "img/sqrs/blSqr.png"
};
};
function sqrsI434() {
    if(document.getElementById("imgSqrs434").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs434").src = "img/sqrs/blSqr.png"
};
};
function sqrsI435() {
    if(document.getElementById("imgSqrs435").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs435").src = "img/sqrs/blSqr.png"
};
};
function sqrsI436() {
    if(document.getElementById("imgSqrs436").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs436").src = "img/sqrs/blSqr.png"
};
};
function sqrsI437() {
    if(document.getElementById("imgSqrs437").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs437").src = "img/sqrs/blSqr.png"
};
};
function sqrsI438() {
    if(document.getElementById("imgSqrs438").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs438").src = "img/sqrs/blSqr.png"
};
};
function sqrsI439() {
    if(document.getElementById("imgSqrs439").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs439").src = "img/sqrs/blSqr.png"
};
};
function sqrsI440() {
    if(document.getElementById("imgSqrs440").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs440").src = "img/sqrs/blSqr.png"
};
};
function sqrsI441() {
    if(document.getElementById("imgSqrs441").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs441").src = "img/sqrs/blSqr.png"
};
};
function sqrsI442() {
    if(document.getElementById("imgSqrs442").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs442").src = "img/sqrs/blSqr.png"
};
};
function sqrsI443() {
    if(document.getElementById("imgSqrs443").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs443").src = "img/sqrs/blSqr.png"
};
};
function sqrsI444() {
    if(document.getElementById("imgSqrs444").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs444").src = "img/sqrs/blSqr.png"
};
};
function sqrsI445() {
    if(document.getElementById("imgSqrs445").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs445").src = "img/sqrs/blSqr.png"
};
};
function sqrsI446() {
    if(document.getElementById("imgSqrs446").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs446").src = "img/sqrs/blSqr.png"
};
};
function sqrsI447() {
    if(document.getElementById("imgSqrs447").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs447").src = "img/sqrs/blSqr.png"
};
};
function sqrsI448() {
    if(document.getElementById("imgSqrs448").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs448").src = "img/sqrs/blSqr.png"
};
};
function sqrsI449() {
    if(document.getElementById("imgSqrs449").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs449").src = "img/sqrs/blSqr.png"
};
};
function sqrsI450() {
    if(document.getElementById("imgSqrs450").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs450").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ451() {
    if(document.getElementById("imgSqrs451").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs451").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ452() {
    if(document.getElementById("imgSqrs452").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs452").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ453() {
    if(document.getElementById("imgSqrs453").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs453").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ454() {
    if(document.getElementById("imgSqrs454").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs454").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ455() {
    if(document.getElementById("imgSqrs455").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs455").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ456() {
    if(document.getElementById("imgSqrs456").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs456").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ457() {
    if(document.getElementById("imgSqrs457").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs457").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ458() {
    if(document.getElementById("imgSqrs458").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs458").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ459() {
    if(document.getElementById("imgSqrs459").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs459").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ460() {
    if(document.getElementById("imgSqrs460").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs460").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ461() {
    if(document.getElementById("imgSqrs461").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs461").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ462() {
    if(document.getElementById("imgSqrs462").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs462").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ463() {
    if(document.getElementById("imgSqrs463").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs463").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ464() {
    if(document.getElementById("imgSqrs464").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs464").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ465() {
    if(document.getElementById("imgSqrs465").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs465").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ466() {
    if(document.getElementById("imgSqrs466").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs466").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ467() {
    if(document.getElementById("imgSqrs467").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs467").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ468() {
    if(document.getElementById("imgSqrs468").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs468").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ469() {
    if(document.getElementById("imgSqrs469").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs469").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ470() {
    if(document.getElementById("imgSqrs470").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs470").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ471() {
    if(document.getElementById("imgSqrs471").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs471").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ472() {
    if(document.getElementById("imgSqrs472").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs472").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ473() {
    if(document.getElementById("imgSqrs473").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs473").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ474() {
    if(document.getElementById("imgSqrs474").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs474").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ475() {
    if(document.getElementById("imgSqrs475").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs475").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ476() {
    if(document.getElementById("imgSqrs476").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs476").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ477() {
    if(document.getElementById("imgSqrs477").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs477").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ478() {
    if(document.getElementById("imgSqrs478").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs478").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ479() {
    if(document.getElementById("imgSqrs479").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs479").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ480() {
    if(document.getElementById("imgSqrs480").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs480").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ481() {
    if(document.getElementById("imgSqrs481").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs481").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ482() {
    if(document.getElementById("imgSqrs482").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs482").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ483() {
    if(document.getElementById("imgSqrs483").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs483").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ484() {
    if(document.getElementById("imgSqrs484").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs484").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ485() {
    if(document.getElementById("imgSqrs485").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs485").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ486() {
    if(document.getElementById("imgSqrs486").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs486").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ487() {
    if(document.getElementById("imgSqrs487").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs487").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ488() {
    if(document.getElementById("imgSqrs488").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs488").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ489() {
    if(document.getElementById("imgSqrs489").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs489").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ490() {
    if(document.getElementById("imgSqrs490").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs490").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ491() {
    if(document.getElementById("imgSqrs491").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs491").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ492() {
    if(document.getElementById("imgSqrs492").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs492").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ493() {
    if(document.getElementById("imgSqrs493").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs493").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ494() {
    if(document.getElementById("imgSqrs494").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs494").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ495() {
    if(document.getElementById("imgSqrs495").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs495").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ496() {
    if(document.getElementById("imgSqrs496").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs496").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ497() {
    if(document.getElementById("imgSqrs497").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs497").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ498() {
    if(document.getElementById("imgSqrs498").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs498").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ499() {
    if(document.getElementById("imgSqrs499").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs499").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ500() {
    if(document.getElementById("imgSqrs500").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs500").src = "img/sqrs/blSqr.png"
};
};
function sqrsK501() {
    if(document.getElementById("imgSqrs501").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs501").src = "img/sqrs/blSqr.png"
};
};
function sqrsK502() {
    if(document.getElementById("imgSqrs502").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs502").src = "img/sqrs/blSqr.png"
};
};
function sqrsK503() {
    if(document.getElementById("imgSqrs503").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs503").src = "img/sqrs/blSqr.png"
};
};
function sqrsK504() {
    if(document.getElementById("imgSqrs504").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs504").src = "img/sqrs/blSqr.png"
};
};
function sqrsK505() {
    if(document.getElementById("imgSqrs505").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs505").src = "img/sqrs/blSqr.png"
};
};
function sqrsK506() {
    if(document.getElementById("imgSqrs506").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs506").src = "img/sqrs/blSqr.png"
};
};
function sqrsK507() {
    if(document.getElementById("imgSqrs507").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs507").src = "img/sqrs/blSqr.png"
};
};
function sqrsK508() {
    if(document.getElementById("imgSqrs508").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs508").src = "img/sqrs/blSqr.png"
};
};
function sqrsK509() {
    if(document.getElementById("imgSqrs509").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs509").src = "img/sqrs/blSqr.png"
};
};
function sqrsK510() {
    if(document.getElementById("imgSqrs510").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs510").src = "img/sqrs/blSqr.png"
};
};
function sqrsK511() {
    if(document.getElementById("imgSqrs511").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs511").src = "img/sqrs/blSqr.png"
};
};
function sqrsK512() {
    if(document.getElementById("imgSqrs512").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs512").src = "img/sqrs/blSqr.png"
};
};
function sqrsK513() {
    if(document.getElementById("imgSqrs513").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs513").src = "img/sqrs/blSqr.png"
};
};
function sqrsK514() {
    if(document.getElementById("imgSqrs514").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs514").src = "img/sqrs/blSqr.png"
};
};
function sqrsK515() {
    if(document.getElementById("imgSqrs515").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs515").src = "img/sqrs/blSqr.png"
};
};
function sqrsK516() {
    if(document.getElementById("imgSqrs516").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs516").src = "img/sqrs/blSqr.png"
};
};
function sqrsK517() {
    if(document.getElementById("imgSqrs517").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs517").src = "img/sqrs/blSqr.png"
};
};
function sqrsK518() {
    if(document.getElementById("imgSqrs518").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs518").src = "img/sqrs/blSqr.png"
};
};
function sqrsK519() {
    if(document.getElementById("imgSqrs519").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs519").src = "img/sqrs/blSqr.png"
};
};
function sqrsK520() {
    if(document.getElementById("imgSqrs520").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs520").src = "img/sqrs/blSqr.png"
};
};
function sqrsK521() {
    if(document.getElementById("imgSqrs521").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs521").src = "img/sqrs/blSqr.png"
};
};
function sqrsK522() {
    if(document.getElementById("imgSqrs522").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs522").src = "img/sqrs/blSqr.png"
};
};
function sqrsK523() {
    if(document.getElementById("imgSqrs523").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs523").src = "img/sqrs/blSqr.png"
};
};
function sqrsK524() {
    if(document.getElementById("imgSqrs524").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs524").src = "img/sqrs/blSqr.png"
};
};
function sqrsK525() {
    if(document.getElementById("imgSqrs525").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs525").src = "img/sqrs/blSqr.png"
};
};
function sqrsK526() {
    if(document.getElementById("imgSqrs526").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs526").src = "img/sqrs/blSqr.png"
};
};
function sqrsK527() {
    if(document.getElementById("imgSqrs527").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs527").src = "img/sqrs/blSqr.png"
};
};
function sqrsK528() {
    if(document.getElementById("imgSqrs528").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs528").src = "img/sqrs/blSqr.png"
};
};
function sqrsK529() {
    if(document.getElementById("imgSqrs529").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs529").src = "img/sqrs/blSqr.png"
};
};
function sqrsK530() {
    if(document.getElementById("imgSqrs530").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs530").src = "img/sqrs/blSqr.png"
};
};
function sqrsK531() {
    if(document.getElementById("imgSqrs531").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs531").src = "img/sqrs/blSqr.png"
};
};
function sqrsK532() {
    if(document.getElementById("imgSqrs532").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs532").src = "img/sqrs/blSqr.png"
};
};
function sqrsK533() {
    if(document.getElementById("imgSqrs533").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs533").src = "img/sqrs/blSqr.png"
};
};
function sqrsK534() {
    if(document.getElementById("imgSqrs534").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs534").src = "img/sqrs/blSqr.png"
};
};
function sqrsK535() {
    if(document.getElementById("imgSqrs535").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs535").src = "img/sqrs/blSqr.png"
};
};
function sqrsK536() {
    if(document.getElementById("imgSqrs536").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs536").src = "img/sqrs/blSqr.png"
};
};
function sqrsK537() {
    if(document.getElementById("imgSqrs537").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs537").src = "img/sqrs/blSqr.png"
};
};
function sqrsK538() {
    if(document.getElementById("imgSqrs538").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs538").src = "img/sqrs/blSqr.png"
};
};
function sqrsK539() {
    if(document.getElementById("imgSqrs539").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs539").src = "img/sqrs/blSqr.png"
};
};
function sqrsK540() {
    if(document.getElementById("imgSqrs540").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs540").src = "img/sqrs/blSqr.png"
};
};
function sqrsK541() {
    if(document.getElementById("imgSqrs541").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs541").src = "img/sqrs/blSqr.png"
};
};
function sqrsK542() {
    if(document.getElementById("imgSqrs542").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs542").src = "img/sqrs/blSqr.png"
};
};
function sqrsK543() {
    if(document.getElementById("imgSqrs543").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs543").src = "img/sqrs/blSqr.png"
};
};
function sqrsK544() {
    if(document.getElementById("imgSqrs544").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs544").src = "img/sqrs/blSqr.png"
};
};
function sqrsK545() {
    if(document.getElementById("imgSqrs545").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs545").src = "img/sqrs/blSqr.png"
};
};
function sqrsK546() {
    if(document.getElementById("imgSqrs546").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs546").src = "img/sqrs/blSqr.png"
};
};
function sqrsK547() {
    if(document.getElementById("imgSqrs547").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs547").src = "img/sqrs/blSqr.png"
};
};
function sqrsK548() {
    if(document.getElementById("imgSqrs548").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs548").src = "img/sqrs/blSqr.png"
};
};
function sqrsK549() {
    if(document.getElementById("imgSqrs549").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs549").src = "img/sqrs/blSqr.png"
};
};
function sqrsK550() {
    if(document.getElementById("imgSqrs550").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs550").src = "img/sqrs/blSqr.png"
};
};
function sqrsL551() {
    if(document.getElementById("imgSqrs551").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs551").src = "img/sqrs/blSqr.png"
};
};
function sqrsL552() {
    if(document.getElementById("imgSqrs552").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs552").src = "img/sqrs/blSqr.png"
};
};
function sqrsL553() {
    if(document.getElementById("imgSqrs553").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs553").src = "img/sqrs/blSqr.png"
};
};
function sqrsL554() {
    if(document.getElementById("imgSqrs554").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs554").src = "img/sqrs/blSqr.png"
};
};
function sqrsL555() {
    if(document.getElementById("imgSqrs555").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs555").src = "img/sqrs/blSqr.png"
};
};
function sqrsL556() {
    if(document.getElementById("imgSqrs556").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs556").src = "img/sqrs/blSqr.png"
};
};
function sqrsL557() {
    if(document.getElementById("imgSqrs557").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs557").src = "img/sqrs/blSqr.png"
};
};
function sqrsL558() {
    if(document.getElementById("imgSqrs558").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs558").src = "img/sqrs/blSqr.png"
};
};
function sqrsL559() {
    if(document.getElementById("imgSqrs559").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs559").src = "img/sqrs/blSqr.png"
};
};
function sqrsL560() {
    if(document.getElementById("imgSqrs560").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs560").src = "img/sqrs/blSqr.png"
};
};
function sqrsL561() {
    if(document.getElementById("imgSqrs561").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs561").src = "img/sqrs/blSqr.png"
};
};
function sqrsL562() {
    if(document.getElementById("imgSqrs562").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs562").src = "img/sqrs/blSqr.png"
};
};
function sqrsL563() {
    if(document.getElementById("imgSqrs563").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs563").src = "img/sqrs/blSqr.png"
};
};
function sqrsL564() {
    if(document.getElementById("imgSqrs564").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs564").src = "img/sqrs/blSqr.png"
};
};
function sqrsL565() {
    if(document.getElementById("imgSqrs565").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs565").src = "img/sqrs/blSqr.png"
};
};
function sqrsL566() {
    if(document.getElementById("imgSqrs566").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs566").src = "img/sqrs/blSqr.png"
};
};
function sqrsL567() {
    if(document.getElementById("imgSqrs567").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs567").src = "img/sqrs/blSqr.png"
};
};
function sqrsL568() {
    if(document.getElementById("imgSqrs568").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs568").src = "img/sqrs/blSqr.png"
};
};
function sqrsL569() {
    if(document.getElementById("imgSqrs569").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs569").src = "img/sqrs/blSqr.png"
};
};
function sqrsL570() {
    if(document.getElementById("imgSqrs570").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs570").src = "img/sqrs/blSqr.png"
};
};
function sqrsL571() {
    if(document.getElementById("imgSqrs571").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs571").src = "img/sqrs/blSqr.png"
};
};
function sqrsL572() {
    if(document.getElementById("imgSqrs572").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs572").src = "img/sqrs/blSqr.png"
};
};
function sqrsL573() {
    if(document.getElementById("imgSqrs573").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs573").src = "img/sqrs/blSqr.png"
};
};
function sqrsL574() {
    if(document.getElementById("imgSqrs574").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs574").src = "img/sqrs/blSqr.png"
};
};
function sqrsL575() {
    if(document.getElementById("imgSqrs575").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs575").src = "img/sqrs/blSqr.png"
};
};
function sqrsL576() {
    if(document.getElementById("imgSqrs576").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs576").src = "img/sqrs/blSqr.png"
};
};
function sqrsL577() {
    if(document.getElementById("imgSqrs577").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs577").src = "img/sqrs/blSqr.png"
};
};
function sqrsL578() {
    if(document.getElementById("imgSqrs578").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs578").src = "img/sqrs/blSqr.png"
};
};
function sqrsL579() {
    if(document.getElementById("imgSqrs579").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs579").src = "img/sqrs/blSqr.png"
};
};
function sqrsL580() {
    if(document.getElementById("imgSqrs580").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs580").src = "img/sqrs/blSqr.png"
};
};
function sqrsL581() {
    if(document.getElementById("imgSqrs581").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs581").src = "img/sqrs/blSqr.png"
};
};
function sqrsL582() {
    if(document.getElementById("imgSqrs582").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs582").src = "img/sqrs/blSqr.png"
};
};
function sqrsL583() {
    if(document.getElementById("imgSqrs583").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs583").src = "img/sqrs/blSqr.png"
};
};
function sqrsL584() {
    if(document.getElementById("imgSqrs584").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs584").src = "img/sqrs/blSqr.png"
};
};
function sqrsL585() {
    if(document.getElementById("imgSqrs585").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs585").src = "img/sqrs/blSqr.png"
};
};
function sqrsL586() {
    if(document.getElementById("imgSqrs586").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs586").src = "img/sqrs/blSqr.png"
};
};
function sqrsL587() {
    if(document.getElementById("imgSqrs587").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs587").src = "img/sqrs/blSqr.png"
};
};
function sqrsL588() {
    if(document.getElementById("imgSqrs588").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs588").src = "img/sqrs/blSqr.png"
};
};
function sqrsL589() {
    if(document.getElementById("imgSqrs589").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs589").src = "img/sqrs/blSqr.png"
};
};
function sqrsL590() {
    if(document.getElementById("imgSqrs590").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs590").src = "img/sqrs/blSqr.png"
};
};
function sqrsL591() {
    if(document.getElementById("imgSqrs591").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs591").src = "img/sqrs/blSqr.png"
};
};
function sqrsL592() {
    if(document.getElementById("imgSqrs592").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs592").src = "img/sqrs/blSqr.png"
};
};
function sqrsL593() {
    if(document.getElementById("imgSqrs593").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs593").src = "img/sqrs/blSqr.png"
};
};
function sqrsL594() {
    if(document.getElementById("imgSqrs594").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs594").src = "img/sqrs/blSqr.png"
};
};
function sqrsL595() {
    if(document.getElementById("imgSqrs595").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs595").src = "img/sqrs/blSqr.png"
};
};
function sqrsL596() {
    if(document.getElementById("imgSqrs596").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs596").src = "img/sqrs/blSqr.png"
};
};
function sqrsL597() {
    if(document.getElementById("imgSqrs597").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs597").src = "img/sqrs/blSqr.png"
};
};
function sqrsL598() {
    if(document.getElementById("imgSqrs598").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs598").src = "img/sqrs/blSqr.png"
};
};
function sqrsL599() {
    if(document.getElementById("imgSqrs599").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs599").src = "img/sqrs/blSqr.png"
};
};
function sqrsL600() {
    if(document.getElementById("imgSqrs600").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs600").src = "img/sqrs/blSqr.png"
};
};
function sqrsM601() {
    if(document.getElementById("imgSqrs601").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs601").src = "img/sqrs/blSqr.png"
};
};
function sqrsM602() {
    if(document.getElementById("imgSqrs602").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs602").src = "img/sqrs/blSqr.png"
};
};
function sqrsM603() {
    if(document.getElementById("imgSqrs603").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs603").src = "img/sqrs/blSqr.png"
};
};
function sqrsM604() {
    if(document.getElementById("imgSqrs604").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs604").src = "img/sqrs/blSqr.png"
};
};
function sqrsM605() {
    if(document.getElementById("imgSqrs605").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs605").src = "img/sqrs/blSqr.png"
};
};
function sqrsM606() {
    if(document.getElementById("imgSqrs606").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs606").src = "img/sqrs/blSqr.png"
};
};
function sqrsM607() {
    if(document.getElementById("imgSqrs607").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs607").src = "img/sqrs/blSqr.png"
};
};
function sqrsM608() {
    if(document.getElementById("imgSqrs608").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs608").src = "img/sqrs/blSqr.png"
};
};
function sqrsM609() {
    if(document.getElementById("imgSqrs609").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs609").src = "img/sqrs/blSqr.png"
};
};
function sqrsM610() {
    if(document.getElementById("imgSqrs610").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs610").src = "img/sqrs/blSqr.png"
};
};
function sqrsM611() {
    if(document.getElementById("imgSqrs611").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs611").src = "img/sqrs/blSqr.png"
};
};
function sqrsM612() {
    if(document.getElementById("imgSqrs612").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs612").src = "img/sqrs/blSqr.png"
};
};
function sqrsM613() {
    if(document.getElementById("imgSqrs613").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs613").src = "img/sqrs/blSqr.png"
};
};
function sqrsM614() {
    if(document.getElementById("imgSqrs614").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs614").src = "img/sqrs/blSqr.png"
};
};
function sqrsM615() {
    if(document.getElementById("imgSqrs615").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs615").src = "img/sqrs/blSqr.png"
};
};
function sqrsM616() {
    if(document.getElementById("imgSqrs616").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs616").src = "img/sqrs/blSqr.png"
};
};
function sqrsM617() {
    if(document.getElementById("imgSqrs617").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs617").src = "img/sqrs/blSqr.png"
};
};
function sqrsM618() {
    if(document.getElementById("imgSqrs618").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs618").src = "img/sqrs/blSqr.png"
};
};
function sqrsM619() {
    if(document.getElementById("imgSqrs619").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs619").src = "img/sqrs/blSqr.png"
};
};
function sqrsM620() {
    if(document.getElementById("imgSqrs620").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs620").src = "img/sqrs/blSqr.png"
};
};
function sqrsM621() {
    if(document.getElementById("imgSqrs621").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs621").src = "img/sqrs/blSqr.png"
};
};
function sqrsM622() {
    if(document.getElementById("imgSqrs622").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs622").src = "img/sqrs/blSqr.png"
};
};
function sqrsM623() {
    if(document.getElementById("imgSqrs623").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs623").src = "img/sqrs/blSqr.png"
};
};
function sqrsM624() {
    if(document.getElementById("imgSqrs624").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs624").src = "img/sqrs/blSqr.png"
};
};
function sqrsM625() {
    if(document.getElementById("imgSqrs625").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs625").src = "img/sqrs/blSqr.png"
};
};

function sqrsA1() {
    if(document.getElementById("imgSqrs1").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1").src = "img/sqrs/blSqr.png"
};
};
function sqrsA2() {
    if(document.getElementById("imgSqrs2").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs2").src = "img/sqrs/blSqr.png"
};
};
function sqrsA3() {
    if(document.getElementById("imgSqrs3").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs3").src = "img/sqrs/blSqr.png"
};
};
function sqrsA4() {
    if(document.getElementById("imgSqrs4").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs4").src = "img/sqrs/blSqr.png"
};
};
function sqrsA5() {
    if(document.getElementById("imgSqrs5").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs5").src = "img/sqrs/blSqr.png"
};
};
function sqrsA6() {
    if(document.getElementById("imgSqrs6").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs6").src = "img/sqrs/blSqr.png"
};
};
function sqrsA7() {
    if(document.getElementById("imgSqrs7").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs7").src = "img/sqrs/blSqr.png"
};
};
function sqrsA8() {
    if(document.getElementById("imgSqrs8").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs8").src = "img/sqrs/blSqr.png"
};
};
function sqrsA9() {
    if(document.getElementById("imgSqrs9").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs9").src = "img/sqrs/blSqr.png"
};
};
function sqrsA10() {
    if(document.getElementById("imgSqrs10").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs10").src = "img/sqrs/blSqr.png"
};
};
function sqrsA11() {
    if(document.getElementById("imgSqrs11").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs11").src = "img/sqrs/blSqr.png"
};
};
function sqrsA12() {
    if(document.getElementById("imgSqrs12").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs12").src = "img/sqrs/blSqr.png"
};
};
function sqrsA13() {
    if(document.getElementById("imgSqrs13").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs13").src = "img/sqrs/blSqr.png"
};
};
function sqrsA14() {
    if(document.getElementById("imgSqrs14").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs14").src = "img/sqrs/blSqr.png"
};
};
function sqrsA15() {
    if(document.getElementById("imgSqrs15").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs15").src = "img/sqrs/blSqr.png"
};
};
function sqrsA16() {
    if(document.getElementById("imgSqrs16").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs16").src = "img/sqrs/blSqr.png"
};
};
function sqrsA17() {
    if(document.getElementById("imgSqrs17").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs17").src = "img/sqrs/blSqr.png"
};
};
function sqrsA18() {
    if(document.getElementById("imgSqrs18").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs18").src = "img/sqrs/blSqr.png"
};
};
function sqrsA19() {
    if(document.getElementById("imgSqrs19").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs19").src = "img/sqrs/blSqr.png"
};
};
function sqrsA20() {
    if(document.getElementById("imgSqrs20").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs20").src = "img/sqrs/blSqr.png"
};
};
function sqrsA21() {
    if(document.getElementById("imgSqrs21").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs21").src = "img/sqrs/blSqr.png"
};
};
function sqrsA22() {
    if(document.getElementById("imgSqrs22").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs22").src = "img/sqrs/blSqr.png"
};
};
function sqrsA23() {
    if(document.getElementById("imgSqrs23").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs23").src = "img/sqrs/blSqr.png"
};
};
function sqrsA24() {
    if(document.getElementById("imgSqrs24").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs24").src = "img/sqrs/blSqr.png"
};
};
function sqrsA25() {
    if(document.getElementById("imgSqrs25").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs25").src = "img/sqrs/blSqr.png"
};
};
function sqrsA26() {
    if(document.getElementById("imgSqrs26").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs26").src = "img/sqrs/blSqr.png"
};
};
function sqrsA27() {
    if(document.getElementById("imgSqrs27").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs27").src = "img/sqrs/blSqr.png"
};
};
function sqrsA28() {
    if(document.getElementById("imgSqrs28").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs28").src = "img/sqrs/blSqr.png"
};
};
function sqrsA29() {
    if(document.getElementById("imgSqrs29").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs29").src = "img/sqrs/blSqr.png"
};
};
function sqrsA30() {
    if(document.getElementById("imgSqrs30").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs30").src = "img/sqrs/blSqr.png"
};
};
function sqrsA31() {
    if(document.getElementById("imgSqrs31").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs31").src = "img/sqrs/blSqr.png"
};
};
function sqrsA32() {
    if(document.getElementById("imgSqrs32").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs32").src = "img/sqrs/blSqr.png"
};
};
function sqrsA33() {
    if(document.getElementById("imgSqrs33").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs33").src = "img/sqrs/blSqr.png"
};
};
function sqrsA34() {
    if(document.getElementById("imgSqrs34").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs34").src = "img/sqrs/blSqr.png"
};
};
function sqrsA35() {
    if(document.getElementById("imgSqrs35").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs35").src = "img/sqrs/blSqr.png"
};
};
function sqrsA36() {
    if(document.getElementById("imgSqrs36").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs36").src = "img/sqrs/blSqr.png"
};
};
function sqrsA37() {
    if(document.getElementById("imgSqrs37").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs37").src = "img/sqrs/blSqr.png"
};
};
function sqrsA38() {
    if(document.getElementById("imgSqrs38").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs38").src = "img/sqrs/blSqr.png"
};
};
function sqrsA39() {
    if(document.getElementById("imgSqrs39").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs39").src = "img/sqrs/blSqr.png"
};
};
function sqrsA40() {
    if(document.getElementById("imgSqrs40").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs40").src = "img/sqrs/blSqr.png"
};
};
function sqrsA41() {
    if(document.getElementById("imgSqrs41").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs41").src = "img/sqrs/blSqr.png"
};
};
function sqrsA42() {
    if(document.getElementById("imgSqrs42").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs42").src = "img/sqrs/blSqr.png"
};
};
function sqrsA43() {
    if(document.getElementById("imgSqrs43").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs43").src = "img/sqrs/blSqr.png"
};
};
function sqrsA44() {
    if(document.getElementById("imgSqrs44").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs44").src = "img/sqrs/blSqr.png"
};
};
function sqrsA45() {
    if(document.getElementById("imgSqrs45").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs45").src = "img/sqrs/blSqr.png"
};
};
function sqrsA46() {
    if(document.getElementById("imgSqrs46").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs46").src = "img/sqrs/blSqr.png"
};
};
function sqrsA47() {
    if(document.getElementById("imgSqrs47").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs47").src = "img/sqrs/blSqr.png"
};
};
function sqrsA48() {
    if(document.getElementById("imgSqrs48").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs48").src = "img/sqrs/blSqr.png"
};
};
function sqrsA49() {
    if(document.getElementById("imgSqrs49").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs49").src = "img/sqrs/blSqr.png"
};
};
function sqrsA50() {
    if(document.getElementById("imgSqrs50").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs50").src = "img/sqrs/blSqr.png"
};
};
function sqrsB51() {
    if(document.getElementById("imgSqrs51").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs51").src = "img/sqrs/blSqr.png"
};
};
function sqrsB52() {
    if(document.getElementById("imgSqrs52").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs52").src = "img/sqrs/blSqr.png"
};
};
function sqrsB53() {
    if(document.getElementById("imgSqrs53").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs53").src = "img/sqrs/blSqr.png"
};
};
function sqrsB54() {
    if(document.getElementById("imgSqrs54").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs54").src = "img/sqrs/blSqr.png"
};
};
function sqrsB55() {
    if(document.getElementById("imgSqrs55").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs55").src = "img/sqrs/blSqr.png"
};
};
function sqrsB56() {
    if(document.getElementById("imgSqrs56").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs56").src = "img/sqrs/blSqr.png"
};
};
function sqrsB57() {
    if(document.getElementById("imgSqrs57").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs57").src = "img/sqrs/blSqr.png"
};
};
function sqrsB58() {
    if(document.getElementById("imgSqrs58").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs58").src = "img/sqrs/blSqr.png"
};
};
function sqrsB59() {
    if(document.getElementById("imgSqrs59").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs59").src = "img/sqrs/blSqr.png"
};
};
function sqrsB60() {
    if(document.getElementById("imgSqrs60").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs60").src = "img/sqrs/blSqr.png"
};
};
function sqrsB61() {
    if(document.getElementById("imgSqrs61").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs61").src = "img/sqrs/blSqr.png"
};
};
function sqrsB62() {
    if(document.getElementById("imgSqrs62").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs62").src = "img/sqrs/blSqr.png"
};
};
function sqrsB63() {
    if(document.getElementById("imgSqrs63").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs63").src = "img/sqrs/blSqr.png"
};
};
function sqrsB64() {
    if(document.getElementById("imgSqrs64").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs64").src = "img/sqrs/blSqr.png"
};
};
function sqrsB65() {
    if(document.getElementById("imgSqrs65").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs65").src = "img/sqrs/blSqr.png"
};
};
function sqrsB66() {
    if(document.getElementById("imgSqrs66").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs66").src = "img/sqrs/blSqr.png"
};
};
function sqrsB67() {
    if(document.getElementById("imgSqrs67").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs67").src = "img/sqrs/blSqr.png"
};
};
function sqrsB68() {
    if(document.getElementById("imgSqrs68").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs68").src = "img/sqrs/blSqr.png"
};
};
function sqrsB69() {
    if(document.getElementById("imgSqrs69").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs69").src = "img/sqrs/blSqr.png"
};
};
function sqrsB70() {
    if(document.getElementById("imgSqrs70").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs70").src = "img/sqrs/blSqr.png"
};
};
function sqrsB71() {
    if(document.getElementById("imgSqrs71").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs71").src = "img/sqrs/blSqr.png"
};
};
function sqrsB72() {
    if(document.getElementById("imgSqrs72").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs72").src = "img/sqrs/blSqr.png"
};
};
function sqrsB73() {
    if(document.getElementById("imgSqrs73").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs73").src = "img/sqrs/blSqr.png"
};
};
function sqrsB74() {
    if(document.getElementById("imgSqrs74").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs74").src = "img/sqrs/blSqr.png"
};
};
function sqrsB75() {
    if(document.getElementById("imgSqrs75").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs75").src = "img/sqrs/blSqr.png"
};
};
function sqrsB76() {
    if(document.getElementById("imgSqrs76").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs76").src = "img/sqrs/blSqr.png"
};
};
function sqrsB77() {
    if(document.getElementById("imgSqrs77").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs77").src = "img/sqrs/blSqr.png"
};
};
function sqrsB78() {
    if(document.getElementById("imgSqrs78").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs78").src = "img/sqrs/blSqr.png"
};
};
function sqrsB79() {
    if(document.getElementById("imgSqrs79").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs79").src = "img/sqrs/blSqr.png"
};
};
function sqrsB80() {
    if(document.getElementById("imgSqrs80").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs80").src = "img/sqrs/blSqr.png"
};
};
function sqrsB81() {
    if(document.getElementById("imgSqrs81").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs81").src = "img/sqrs/blSqr.png"
};
};
function sqrsB82() {
    if(document.getElementById("imgSqrs82").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs82").src = "img/sqrs/blSqr.png"
};
};
function sqrsB83() {
    if(document.getElementById("imgSqrs83").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs83").src = "img/sqrs/blSqr.png"
};
};
function sqrsB84() {
    if(document.getElementById("imgSqrs84").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs84").src = "img/sqrs/blSqr.png"
};
};
function sqrsB85() {
    if(document.getElementById("imgSqrs85").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs85").src = "img/sqrs/blSqr.png"
};
};
function sqrsB86() {
    if(document.getElementById("imgSqrs86").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs86").src = "img/sqrs/blSqr.png"
};
};
function sqrsB87() {
    if(document.getElementById("imgSqrs87").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs87").src = "img/sqrs/blSqr.png"
};
};
function sqrsB88() {
    if(document.getElementById("imgSqrs88").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs88").src = "img/sqrs/blSqr.png"
};
};
function sqrsB89() {
    if(document.getElementById("imgSqrs89").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs89").src = "img/sqrs/blSqr.png"
};
};
function sqrsB90() {
    if(document.getElementById("imgSqrs90").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs90").src = "img/sqrs/blSqr.png"
};
};
function sqrsB91() {
    if(document.getElementById("imgSqrs91").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs91").src = "img/sqrs/blSqr.png"
};
};
function sqrsB92() {
    if(document.getElementById("imgSqrs92").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs92").src = "img/sqrs/blSqr.png"
};
};
function sqrsB93() {
    if(document.getElementById("imgSqrs93").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs93").src = "img/sqrs/blSqr.png"
};
};
function sqrsB94() {
    if(document.getElementById("imgSqrs94").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs94").src = "img/sqrs/blSqr.png"
};
};
function sqrsB95() {
    if(document.getElementById("imgSqrs95").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs95").src = "img/sqrs/blSqr.png"
};
};
function sqrsB96() {
    if(document.getElementById("imgSqrs96").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs96").src = "img/sqrs/blSqr.png"
};
};
function sqrsB97() {
    if(document.getElementById("imgSqrs97").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs97").src = "img/sqrs/blSqr.png"
};
};
function sqrsB98() {
    if(document.getElementById("imgSqrs98").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs98").src = "img/sqrs/blSqr.png"
};
};
function sqrsB99() {
    if(document.getElementById("imgSqrs99").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs99").src = "img/sqrs/blSqr.png"
};
};
function sqrsB100() {
    if(document.getElementById("imgSqrs100").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs100").src = "img/sqrs/blSqr.png"
};
};
function sqrsC101() {
    if(document.getElementById("imgSqrs101").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs101").src = "img/sqrs/blSqr.png"
};
};
function sqrsC102() {
    if(document.getElementById("imgSqrs102").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs102").src = "img/sqrs/blSqr.png"
};
};
function sqrsC103() {
    if(document.getElementById("imgSqrs103").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs103").src = "img/sqrs/blSqr.png"
};
};
function sqrsC104() {
    if(document.getElementById("imgSqrs104").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs104").src = "img/sqrs/blSqr.png"
};
};
function sqrsC105() {
    if(document.getElementById("imgSqrs105").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs105").src = "img/sqrs/blSqr.png"
};
};
function sqrsC106() {
    if(document.getElementById("imgSqrs106").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs106").src = "img/sqrs/blSqr.png"
};
};
function sqrsC107() {
    if(document.getElementById("imgSqrs107").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs107").src = "img/sqrs/blSqr.png"
};
};
function sqrsC108() {
    if(document.getElementById("imgSqrs108").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs108").src = "img/sqrs/blSqr.png"
};
};
function sqrsC109() {
    if(document.getElementById("imgSqrs109").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs109").src = "img/sqrs/blSqr.png"
};
};
function sqrsC110() {
    if(document.getElementById("imgSqrs110").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs110").src = "img/sqrs/blSqr.png"
};
};
function sqrsC111() {
    if(document.getElementById("imgSqrs111").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs111").src = "img/sqrs/blSqr.png"
};
};
function sqrsC112() {
    if(document.getElementById("imgSqrs112").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs112").src = "img/sqrs/blSqr.png"
};
};
function sqrsC113() {
    if(document.getElementById("imgSqrs113").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs113").src = "img/sqrs/blSqr.png"
};
};
function sqrsC114() {
    if(document.getElementById("imgSqrs114").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs114").src = "img/sqrs/blSqr.png"
};
};
function sqrsC115() {
    if(document.getElementById("imgSqrs115").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs115").src = "img/sqrs/blSqr.png"
};
};
function sqrsC116() {
    if(document.getElementById("imgSqrs116").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs116").src = "img/sqrs/blSqr.png"
};
};
function sqrsC117() {
    if(document.getElementById("imgSqrs117").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs117").src = "img/sqrs/blSqr.png"
};
};
function sqrsC118() {
    if(document.getElementById("imgSqrs118").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs118").src = "img/sqrs/blSqr.png"
};
};
function sqrsC119() {
    if(document.getElementById("imgSqrs119").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs119").src = "img/sqrs/blSqr.png"
};
};
function sqrsC120() {
    if(document.getElementById("imgSqrs120").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs120").src = "img/sqrs/blSqr.png"
};
};
function sqrsC121() {
    if(document.getElementById("imgSqrs121").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs121").src = "img/sqrs/blSqr.png"
};
};
function sqrsC122() {
    if(document.getElementById("imgSqrs122").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs122").src = "img/sqrs/blSqr.png"
};
};
function sqrsC123() {
    if(document.getElementById("imgSqrs123").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs123").src = "img/sqrs/blSqr.png"
};
};
function sqrsC124() {
    if(document.getElementById("imgSqrs124").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs124").src = "img/sqrs/blSqr.png"
};
};
function sqrsC125() {
    if(document.getElementById("imgSqrs125").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs125").src = "img/sqrs/blSqr.png"
};
};
function sqrsC126() {
    if(document.getElementById("imgSqrs126").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs126").src = "img/sqrs/blSqr.png"
};
};
function sqrsC127() {
    if(document.getElementById("imgSqrs127").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs127").src = "img/sqrs/blSqr.png"
};
};
function sqrsC128() {
    if(document.getElementById("imgSqrs128").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs128").src = "img/sqrs/blSqr.png"
};
};
function sqrsC129() {
    if(document.getElementById("imgSqrs129").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs129").src = "img/sqrs/blSqr.png"
};
};
function sqrsC130() {
    if(document.getElementById("imgSqrs130").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs130").src = "img/sqrs/blSqr.png"
};
};
function sqrsC131() {
    if(document.getElementById("imgSqrs131").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs131").src = "img/sqrs/blSqr.png"
};
};
function sqrsC132() {
    if(document.getElementById("imgSqrs132").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs132").src = "img/sqrs/blSqr.png"
};
};
function sqrsC133() {
    if(document.getElementById("imgSqrs133").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs133").src = "img/sqrs/blSqr.png"
};
};
function sqrsC134() {
    if(document.getElementById("imgSqrs134").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs134").src = "img/sqrs/blSqr.png"
};
};
function sqrsC135() {
    if(document.getElementById("imgSqrs135").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs135").src = "img/sqrs/blSqr.png"
};
};
function sqrsC136() {
    if(document.getElementById("imgSqrs136").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs136").src = "img/sqrs/blSqr.png"
};
};
function sqrsC137() {
    if(document.getElementById("imgSqrs137").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs137").src = "img/sqrs/blSqr.png"
};
};
function sqrsC138() {
    if(document.getElementById("imgSqrs138").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs138").src = "img/sqrs/blSqr.png"
};
};
function sqrsC139() {
    if(document.getElementById("imgSqrs139").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs139").src = "img/sqrs/blSqr.png"
};
};
function sqrsC140() {
    if(document.getElementById("imgSqrs140").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs140").src = "img/sqrs/blSqr.png"
};
};
function sqrsC141() {
    if(document.getElementById("imgSqrs141").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs141").src = "img/sqrs/blSqr.png"
};
};
function sqrsC142() {
    if(document.getElementById("imgSqrs142").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs142").src = "img/sqrs/blSqr.png"
};
};
function sqrsC143() {
    if(document.getElementById("imgSqrs143").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs143").src = "img/sqrs/blSqr.png"
};
};
function sqrsC144() {
    if(document.getElementById("imgSqrs144").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs144").src = "img/sqrs/blSqr.png"
};
};
function sqrsC145() {
    if(document.getElementById("imgSqrs145").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs145").src = "img/sqrs/blSqr.png"
};
};
function sqrsC146() {
    if(document.getElementById("imgSqrs146").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs146").src = "img/sqrs/blSqr.png"
};
};
function sqrsC147() {
    if(document.getElementById("imgSqrs147").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs147").src = "img/sqrs/blSqr.png"
};
};
function sqrsC148() {
    if(document.getElementById("imgSqrs148").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs148").src = "img/sqrs/blSqr.png"
};
};
function sqrsC149() {
    if(document.getElementById("imgSqrs149").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs149").src = "img/sqrs/blSqr.png"
};
};
function sqrsC150() {
    if(document.getElementById("imgSqrs150").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs150").src = "img/sqrs/blSqr.png"
};
};
function sqrsD151() {
    if(document.getElementById("imgSqrs151").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs151").src = "img/sqrs/blSqr.png"
};
};
function sqrsD152() {
    if(document.getElementById("imgSqrs152").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs152").src = "img/sqrs/blSqr.png"
};
};
function sqrsD153() {
    if(document.getElementById("imgSqrs153").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs153").src = "img/sqrs/blSqr.png"
};
};
function sqrsD154() {
    if(document.getElementById("imgSqrs154").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs154").src = "img/sqrs/blSqr.png"
};
};
function sqrsD155() {
    if(document.getElementById("imgSqrs155").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs155").src = "img/sqrs/blSqr.png"
};
};
function sqrsD156() {
    if(document.getElementById("imgSqrs156").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs156").src = "img/sqrs/blSqr.png"
};
};
function sqrsD157() {
    if(document.getElementById("imgSqrs157").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs157").src = "img/sqrs/blSqr.png"
};
};
function sqrsD158() {
    if(document.getElementById("imgSqrs158").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs158").src = "img/sqrs/blSqr.png"
};
};
function sqrsD159() {
    if(document.getElementById("imgSqrs159").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs159").src = "img/sqrs/blSqr.png"
};
};
function sqrsD160() {
    if(document.getElementById("imgSqrs160").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs160").src = "img/sqrs/blSqr.png"
};
};
function sqrsD161() {
    if(document.getElementById("imgSqrs161").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs161").src = "img/sqrs/blSqr.png"
};
};
function sqrsD162() {
    if(document.getElementById("imgSqrs162").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs162").src = "img/sqrs/blSqr.png"
};
};
function sqrsD163() {
    if(document.getElementById("imgSqrs163").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs163").src = "img/sqrs/blSqr.png"
};
};
function sqrsD164() {
    if(document.getElementById("imgSqrs164").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs164").src = "img/sqrs/blSqr.png"
};
};
function sqrsD165() {
    if(document.getElementById("imgSqrs165").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs165").src = "img/sqrs/blSqr.png"
};
};
function sqrsD166() {
    if(document.getElementById("imgSqrs166").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs166").src = "img/sqrs/blSqr.png"
};
};
function sqrsD167() {
    if(document.getElementById("imgSqrs167").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs167").src = "img/sqrs/blSqr.png"
};
};
function sqrsD168() {
    if(document.getElementById("imgSqrs168").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs168").src = "img/sqrs/blSqr.png"
};
};
function sqrsD169() {
    if(document.getElementById("imgSqrs169").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs169").src = "img/sqrs/blSqr.png"
};
};
function sqrsD170() {
    if(document.getElementById("imgSqrs170").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs170").src = "img/sqrs/blSqr.png"
};
};
function sqrsD171() {
    if(document.getElementById("imgSqrs171").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs171").src = "img/sqrs/blSqr.png"
};
};
function sqrsD172() {
    if(document.getElementById("imgSqrs172").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs172").src = "img/sqrs/blSqr.png"
};
};
function sqrsD173() {
    if(document.getElementById("imgSqrs173").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs173").src = "img/sqrs/blSqr.png"
};
};
function sqrsD174() {
    if(document.getElementById("imgSqrs174").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs174").src = "img/sqrs/blSqr.png"
};
};
function sqrsD175() {
    if(document.getElementById("imgSqrs175").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs175").src = "img/sqrs/blSqr.png"
};
};
function sqrsD176() {
    if(document.getElementById("imgSqrs176").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs176").src = "img/sqrs/blSqr.png"
};
};
function sqrsD177() {
    if(document.getElementById("imgSqrs177").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs177").src = "img/sqrs/blSqr.png"
};
};
function sqrsD178() {
    if(document.getElementById("imgSqrs178").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs178").src = "img/sqrs/blSqr.png"
};
};
function sqrsD179() {
    if(document.getElementById("imgSqrs179").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs179").src = "img/sqrs/blSqr.png"
};
};
function sqrsD180() {
    if(document.getElementById("imgSqrs180").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs180").src = "img/sqrs/blSqr.png"
};
};
function sqrsD181() {
    if(document.getElementById("imgSqrs181").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs181").src = "img/sqrs/blSqr.png"
};
};
function sqrsD182() {
    if(document.getElementById("imgSqrs182").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs182").src = "img/sqrs/blSqr.png"
};
};
function sqrsD183() {
    if(document.getElementById("imgSqrs183").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs183").src = "img/sqrs/blSqr.png"
};
};
function sqrsD184() {
    if(document.getElementById("imgSqrs184").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs184").src = "img/sqrs/blSqr.png"
};
};
function sqrsD185() {
    if(document.getElementById("imgSqrs185").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs185").src = "img/sqrs/blSqr.png"
};
};
function sqrsD186() {
    if(document.getElementById("imgSqrs186").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs186").src = "img/sqrs/blSqr.png"
};
};
function sqrsD187() {
    if(document.getElementById("imgSqrs187").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs187").src = "img/sqrs/blSqr.png"
};
};
function sqrsD188() {
    if(document.getElementById("imgSqrs188").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs188").src = "img/sqrs/blSqr.png"
};
};
function sqrsD189() {
    if(document.getElementById("imgSqrs189").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs189").src = "img/sqrs/blSqr.png"
};
};
function sqrsD190() {
    if(document.getElementById("imgSqrs190").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs190").src = "img/sqrs/blSqr.png"
};
};
function sqrsD191() {
    if(document.getElementById("imgSqrs191").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs191").src = "img/sqrs/blSqr.png"
};
};
function sqrsD192() {
    if(document.getElementById("imgSqrs192").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs192").src = "img/sqrs/blSqr.png"
};
};
function sqrsD193() {
    if(document.getElementById("imgSqrs193").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs193").src = "img/sqrs/blSqr.png"
};
};
function sqrsD194() {
    if(document.getElementById("imgSqrs194").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs194").src = "img/sqrs/blSqr.png"
};
};
function sqrsD195() {
    if(document.getElementById("imgSqrs195").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs195").src = "img/sqrs/blSqr.png"
};
};
function sqrsD196() {
    if(document.getElementById("imgSqrs196").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs196").src = "img/sqrs/blSqr.png"
};
};
function sqrsD197() {
    if(document.getElementById("imgSqrs197").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs197").src = "img/sqrs/blSqr.png"
};
};
function sqrsD198() {
    if(document.getElementById("imgSqrs198").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs198").src = "img/sqrs/blSqr.png"
};
};
function sqrsD199() {
    if(document.getElementById("imgSqrs199").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs199").src = "img/sqrs/blSqr.png"
};
};
function sqrsD200() {
    if(document.getElementById("imgSqrs200").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs200").src = "img/sqrs/blSqr.png"
};
};
function sqrsE201() {
    if(document.getElementById("imgSqrs201").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs201").src = "img/sqrs/blSqr.png"
};
};
function sqrsE202() {
    if(document.getElementById("imgSqrs202").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs202").src = "img/sqrs/blSqr.png"
};
};
function sqrsE203() {
    if(document.getElementById("imgSqrs203").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs203").src = "img/sqrs/blSqr.png"
};
};
function sqrsE204() {
    if(document.getElementById("imgSqrs204").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs204").src = "img/sqrs/blSqr.png"
};
};
function sqrsE205() {
    if(document.getElementById("imgSqrs205").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs205").src = "img/sqrs/blSqr.png"
};
};
function sqrsE206() {
    if(document.getElementById("imgSqrs206").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs206").src = "img/sqrs/blSqr.png"
};
};
function sqrsE207() {
    if(document.getElementById("imgSqrs207").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs207").src = "img/sqrs/blSqr.png"
};
};
function sqrsE208() {
    if(document.getElementById("imgSqrs208").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs208").src = "img/sqrs/blSqr.png"
};
};
function sqrsE209() {
    if(document.getElementById("imgSqrs209").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs209").src = "img/sqrs/blSqr.png"
};
};
function sqrsE210() {
    if(document.getElementById("imgSqrs210").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs210").src = "img/sqrs/blSqr.png"
};
};
function sqrsE211() {
    if(document.getElementById("imgSqrs211").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs211").src = "img/sqrs/blSqr.png"
};
};
function sqrsE212() {
    if(document.getElementById("imgSqrs212").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs212").src = "img/sqrs/blSqr.png"
};
};
function sqrsE213() {
    if(document.getElementById("imgSqrs213").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs213").src = "img/sqrs/blSqr.png"
};
};
function sqrsE214() {
    if(document.getElementById("imgSqrs214").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs214").src = "img/sqrs/blSqr.png"
};
};
function sqrsE215() {
    if(document.getElementById("imgSqrs215").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs215").src = "img/sqrs/blSqr.png"
};
};
function sqrsE216() {
    if(document.getElementById("imgSqrs216").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs216").src = "img/sqrs/blSqr.png"
};
};
function sqrsE217() {
    if(document.getElementById("imgSqrs217").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs217").src = "img/sqrs/blSqr.png"
};
};
function sqrsE218() {
    if(document.getElementById("imgSqrs218").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs218").src = "img/sqrs/blSqr.png"
};
};
function sqrsE219() {
    if(document.getElementById("imgSqrs219").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs219").src = "img/sqrs/blSqr.png"
};
};
function sqrsE220() {
    if(document.getElementById("imgSqrs220").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs220").src = "img/sqrs/blSqr.png"
};
};
function sqrsE221() {
    if(document.getElementById("imgSqrs221").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs221").src = "img/sqrs/blSqr.png"
};
};
function sqrsE222() {
    if(document.getElementById("imgSqrs222").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs222").src = "img/sqrs/blSqr.png"
};
};
function sqrsE223() {
    if(document.getElementById("imgSqrs223").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs223").src = "img/sqrs/blSqr.png"
};
};
function sqrsE224() {
    if(document.getElementById("imgSqrs224").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs224").src = "img/sqrs/blSqr.png"
};
};
function sqrsE225() {
    if(document.getElementById("imgSqrs225").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs225").src = "img/sqrs/blSqr.png"
};
};
function sqrsE226() {
    if(document.getElementById("imgSqrs226").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs226").src = "img/sqrs/blSqr.png"
};
};
function sqrsE227() {
    if(document.getElementById("imgSqrs227").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs227").src = "img/sqrs/blSqr.png"
};
};
function sqrsE228() {
    if(document.getElementById("imgSqrs228").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs228").src = "img/sqrs/blSqr.png"
};
};
function sqrsE229() {
    if(document.getElementById("imgSqrs229").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs229").src = "img/sqrs/blSqr.png"
};
};
function sqrsE230() {
    if(document.getElementById("imgSqrs230").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs230").src = "img/sqrs/blSqr.png"
};
};
function sqrsE231() {
    if(document.getElementById("imgSqrs231").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs231").src = "img/sqrs/blSqr.png"
};
};
function sqrsE232() {
    if(document.getElementById("imgSqrs232").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs232").src = "img/sqrs/blSqr.png"
};
};
function sqrsE233() {
    if(document.getElementById("imgSqrs233").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs233").src = "img/sqrs/blSqr.png"
};
};
function sqrsE234() {
    if(document.getElementById("imgSqrs234").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs234").src = "img/sqrs/blSqr.png"
};
};
function sqrsE235() {
    if(document.getElementById("imgSqrs235").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs235").src = "img/sqrs/blSqr.png"
};
};
function sqrsE236() {
    if(document.getElementById("imgSqrs236").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs236").src = "img/sqrs/blSqr.png"
};
};
function sqrsE237() {
    if(document.getElementById("imgSqrs237").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs237").src = "img/sqrs/blSqr.png"
};
};
function sqrsE238() {
    if(document.getElementById("imgSqrs238").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs238").src = "img/sqrs/blSqr.png"
};
};
function sqrsE239() {
    if(document.getElementById("imgSqrs239").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs239").src = "img/sqrs/blSqr.png"
};
};
function sqrsE240() {
    if(document.getElementById("imgSqrs240").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs240").src = "img/sqrs/blSqr.png"
};
};
function sqrsE241() {
    if(document.getElementById("imgSqrs241").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs241").src = "img/sqrs/blSqr.png"
};
};
function sqrsE242() {
    if(document.getElementById("imgSqrs242").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs242").src = "img/sqrs/blSqr.png"
};
};
function sqrsE243() {
    if(document.getElementById("imgSqrs243").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs243").src = "img/sqrs/blSqr.png"
};
};
function sqrsE244() {
    if(document.getElementById("imgSqrs244").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs244").src = "img/sqrs/blSqr.png"
};
};
function sqrsE245() {
    if(document.getElementById("imgSqrs245").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs245").src = "img/sqrs/blSqr.png"
};
};
function sqrsE246() {
    if(document.getElementById("imgSqrs246").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs246").src = "img/sqrs/blSqr.png"
};
};
function sqrsE247() {
    if(document.getElementById("imgSqrs247").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs247").src = "img/sqrs/blSqr.png"
};
};
function sqrsE248() {
    if(document.getElementById("imgSqrs248").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs248").src = "img/sqrs/blSqr.png"
};
};
function sqrsE249() {
    if(document.getElementById("imgSqrs249").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs249").src = "img/sqrs/blSqr.png"
};
};
function sqrsE250() {
    if(document.getElementById("imgSqrs250").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs250").src = "img/sqrs/blSqr.png"
};
};
function sqrsF251() {
    if(document.getElementById("imgSqrs251").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs251").src = "img/sqrs/blSqr.png"
};
};
function sqrsF252() {
    if(document.getElementById("imgSqrs252").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs252").src = "img/sqrs/blSqr.png"
};
};
function sqrsF253() {
    if(document.getElementById("imgSqrs253").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs253").src = "img/sqrs/blSqr.png"
};
};
function sqrsF254() {
    if(document.getElementById("imgSqrs254").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs254").src = "img/sqrs/blSqr.png"
};
};
function sqrsF255() {
    if(document.getElementById("imgSqrs255").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs255").src = "img/sqrs/blSqr.png"
};
};
function sqrsF256() {
    if(document.getElementById("imgSqrs256").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs256").src = "img/sqrs/blSqr.png"
};
};
function sqrsF257() {
    if(document.getElementById("imgSqrs257").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs257").src = "img/sqrs/blSqr.png"
};
};
function sqrsF258() {
    if(document.getElementById("imgSqrs258").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs258").src = "img/sqrs/blSqr.png"
};
};
function sqrsF259() {
    if(document.getElementById("imgSqrs259").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs259").src = "img/sqrs/blSqr.png"
};
};
function sqrsF260() {
    if(document.getElementById("imgSqrs260").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs260").src = "img/sqrs/blSqr.png"
};
};
function sqrsF261() {
    if(document.getElementById("imgSqrs261").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs261").src = "img/sqrs/blSqr.png"
};
};
function sqrsF262() {
    if(document.getElementById("imgSqrs262").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs262").src = "img/sqrs/blSqr.png"
};
};
function sqrsF263() {
    if(document.getElementById("imgSqrs263").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs263").src = "img/sqrs/blSqr.png"
};
};
function sqrsF264() {
    if(document.getElementById("imgSqrs264").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs264").src = "img/sqrs/blSqr.png"
};
};
function sqrsF265() {
    if(document.getElementById("imgSqrs265").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs265").src = "img/sqrs/blSqr.png"
};
};
function sqrsF266() {
    if(document.getElementById("imgSqrs266").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs266").src = "img/sqrs/blSqr.png"
};
};
function sqrsF267() {
    if(document.getElementById("imgSqrs267").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs267").src = "img/sqrs/blSqr.png"
};
};
function sqrsF268() {
    if(document.getElementById("imgSqrs268").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs268").src = "img/sqrs/blSqr.png"
};
};
function sqrsF269() {
    if(document.getElementById("imgSqrs269").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs269").src = "img/sqrs/blSqr.png"
};
};
function sqrsF270() {
    if(document.getElementById("imgSqrs270").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs270").src = "img/sqrs/blSqr.png"
};
};
function sqrsF271() {
    if(document.getElementById("imgSqrs271").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs271").src = "img/sqrs/blSqr.png"
};
};
function sqrsF272() {
    if(document.getElementById("imgSqrs272").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs272").src = "img/sqrs/blSqr.png"
};
};
function sqrsF273() {
    if(document.getElementById("imgSqrs273").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs273").src = "img/sqrs/blSqr.png"
};
};
function sqrsF274() {
    if(document.getElementById("imgSqrs274").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs274").src = "img/sqrs/blSqr.png"
};
};
function sqrsF275() {
    if(document.getElementById("imgSqrs275").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs275").src = "img/sqrs/blSqr.png"
};
};
function sqrsF276() {
    if(document.getElementById("imgSqrs276").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs276").src = "img/sqrs/blSqr.png"
};
};
function sqrsF277() {
    if(document.getElementById("imgSqrs277").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs277").src = "img/sqrs/blSqr.png"
};
};
function sqrsF278() {
    if(document.getElementById("imgSqrs278").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs278").src = "img/sqrs/blSqr.png"
};
};
function sqrsF279() {
    if(document.getElementById("imgSqrs279").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs279").src = "img/sqrs/blSqr.png"
};
};
function sqrsF280() {
    if(document.getElementById("imgSqrs280").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs280").src = "img/sqrs/blSqr.png"
};
};
function sqrsF281() {
    if(document.getElementById("imgSqrs281").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs281").src = "img/sqrs/blSqr.png"
};
};
function sqrsF282() {
    if(document.getElementById("imgSqrs282").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs282").src = "img/sqrs/blSqr.png"
};
};
function sqrsF283() {
    if(document.getElementById("imgSqrs283").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs283").src = "img/sqrs/blSqr.png"
};
};
function sqrsF284() {
    if(document.getElementById("imgSqrs284").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs284").src = "img/sqrs/blSqr.png"
};
};
function sqrsF285() {
    if(document.getElementById("imgSqrs285").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs285").src = "img/sqrs/blSqr.png"
};
};
function sqrsF286() {
    if(document.getElementById("imgSqrs286").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs286").src = "img/sqrs/blSqr.png"
};
};
function sqrsF287() {
    if(document.getElementById("imgSqrs287").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs287").src = "img/sqrs/blSqr.png"
};
};
function sqrsF288() {
    if(document.getElementById("imgSqrs288").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs288").src = "img/sqrs/blSqr.png"
};
};
function sqrsF289() {
    if(document.getElementById("imgSqrs289").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs289").src = "img/sqrs/blSqr.png"
};
};
function sqrsF290() {
    if(document.getElementById("imgSqrs290").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs290").src = "img/sqrs/blSqr.png"
};
};
function sqrsF291() {
    if(document.getElementById("imgSqrs291").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs291").src = "img/sqrs/blSqr.png"
};
};
function sqrsF292() {
    if(document.getElementById("imgSqrs292").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs292").src = "img/sqrs/blSqr.png"
};
};
function sqrsF293() {
    if(document.getElementById("imgSqrs293").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs293").src = "img/sqrs/blSqr.png"
};
};
function sqrsF294() {
    if(document.getElementById("imgSqrs294").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs294").src = "img/sqrs/blSqr.png"
};
};
function sqrsF295() {
    if(document.getElementById("imgSqrs295").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs295").src = "img/sqrs/blSqr.png"
};
};
function sqrsF296() {
    if(document.getElementById("imgSqrs296").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs296").src = "img/sqrs/blSqr.png"
};
};
function sqrsF297() {
    if(document.getElementById("imgSqrs297").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs297").src = "img/sqrs/blSqr.png"
};
};
function sqrsF298() {
    if(document.getElementById("imgSqrs298").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs298").src = "img/sqrs/blSqr.png"
};
};
function sqrsF299() {
    if(document.getElementById("imgSqrs299").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs299").src = "img/sqrs/blSqr.png"
};
};
function sqrsF300() {
    if(document.getElementById("imgSqrs300").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs300").src = "img/sqrs/blSqr.png"
};
};
function sqrsG301() {
    if(document.getElementById("imgSqrs301").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs301").src = "img/sqrs/blSqr.png"
};
};
function sqrsG302() {
    if(document.getElementById("imgSqrs302").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs302").src = "img/sqrs/blSqr.png"
};
};
function sqrsG303() {
    if(document.getElementById("imgSqrs303").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs303").src = "img/sqrs/blSqr.png"
};
};
function sqrsG304() {
    if(document.getElementById("imgSqrs304").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs304").src = "img/sqrs/blSqr.png"
};
};
function sqrsG305() {
    if(document.getElementById("imgSqrs305").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs305").src = "img/sqrs/blSqr.png"
};
};
function sqrsG306() {
    if(document.getElementById("imgSqrs306").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs306").src = "img/sqrs/blSqr.png"
};
};
function sqrsG307() {
    if(document.getElementById("imgSqrs307").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs307").src = "img/sqrs/blSqr.png"
};
};
function sqrsG308() {
    if(document.getElementById("imgSqrs308").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs308").src = "img/sqrs/blSqr.png"
};
};
function sqrsG309() {
    if(document.getElementById("imgSqrs309").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs309").src = "img/sqrs/blSqr.png"
};
};
function sqrsG310() {
    if(document.getElementById("imgSqrs310").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs310").src = "img/sqrs/blSqr.png"
};
};
function sqrsG311() {
    if(document.getElementById("imgSqrs311").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs311").src = "img/sqrs/blSqr.png"
};
};
function sqrsG312() {
    if(document.getElementById("imgSqrs312").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs312").src = "img/sqrs/blSqr.png"
};
};
function sqrsG313() {
    if(document.getElementById("imgSqrs313").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs313").src = "img/sqrs/blSqr.png"
};
};
function sqrsG314() {
    if(document.getElementById("imgSqrs314").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs314").src = "img/sqrs/blSqr.png"
};
};
function sqrsG315() {
    if(document.getElementById("imgSqrs315").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs315").src = "img/sqrs/blSqr.png"
};
};
function sqrsG316() {
    if(document.getElementById("imgSqrs316").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs316").src = "img/sqrs/blSqr.png"
};
};
function sqrsG317() {
    if(document.getElementById("imgSqrs317").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs317").src = "img/sqrs/blSqr.png"
};
};
function sqrsG318() {
    if(document.getElementById("imgSqrs318").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs318").src = "img/sqrs/blSqr.png"
};
};
function sqrsG319() {
    if(document.getElementById("imgSqrs319").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs319").src = "img/sqrs/blSqr.png"
};
};
function sqrsG320() {
    if(document.getElementById("imgSqrs320").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs320").src = "img/sqrs/blSqr.png"
};
};
function sqrsG321() {
    if(document.getElementById("imgSqrs321").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs321").src = "img/sqrs/blSqr.png"
};
};
function sqrsG322() {
    if(document.getElementById("imgSqrs322").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs322").src = "img/sqrs/blSqr.png"
};
};
function sqrsG323() {
    if(document.getElementById("imgSqrs323").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs323").src = "img/sqrs/blSqr.png"
};
};
function sqrsG324() {
    if(document.getElementById("imgSqrs324").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs324").src = "img/sqrs/blSqr.png"
};
};
function sqrsG325() {
    if(document.getElementById("imgSqrs325").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs325").src = "img/sqrs/blSqr.png"
};
};
function sqrsG326() {
    if(document.getElementById("imgSqrs326").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs326").src = "img/sqrs/blSqr.png"
};
};
function sqrsG327() {
    if(document.getElementById("imgSqrs327").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs327").src = "img/sqrs/blSqr.png"
};
};
function sqrsG328() {
    if(document.getElementById("imgSqrs328").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs328").src = "img/sqrs/blSqr.png"
};
};
function sqrsG329() {
    if(document.getElementById("imgSqrs329").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs329").src = "img/sqrs/blSqr.png"
};
};
function sqrsG330() {
    if(document.getElementById("imgSqrs330").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs330").src = "img/sqrs/blSqr.png"
};
};
function sqrsG331() {
    if(document.getElementById("imgSqrs331").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs331").src = "img/sqrs/blSqr.png"
};
};
function sqrsG332() {
    if(document.getElementById("imgSqrs332").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs332").src = "img/sqrs/blSqr.png"
};
};
function sqrsG333() {
    if(document.getElementById("imgSqrs333").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs333").src = "img/sqrs/blSqr.png"
};
};
function sqrsG334() {
    if(document.getElementById("imgSqrs334").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs334").src = "img/sqrs/blSqr.png"
};
};
function sqrsG335() {
    if(document.getElementById("imgSqrs335").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs335").src = "img/sqrs/blSqr.png"
};
};
function sqrsG336() {
    if(document.getElementById("imgSqrs336").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs336").src = "img/sqrs/blSqr.png"
};
};
function sqrsG337() {
    if(document.getElementById("imgSqrs337").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs337").src = "img/sqrs/blSqr.png"
};
};
function sqrsG338() {
    if(document.getElementById("imgSqrs338").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs338").src = "img/sqrs/blSqr.png"
};
};
function sqrsG339() {
    if(document.getElementById("imgSqrs339").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs339").src = "img/sqrs/blSqr.png"
};
};
function sqrsG340() {
    if(document.getElementById("imgSqrs340").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs340").src = "img/sqrs/blSqr.png"
};
};
function sqrsG341() {
    if(document.getElementById("imgSqrs341").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs341").src = "img/sqrs/blSqr.png"
};
};
function sqrsG342() {
    if(document.getElementById("imgSqrs342").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs342").src = "img/sqrs/blSqr.png"
};
};
function sqrsG343() {
    if(document.getElementById("imgSqrs343").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs343").src = "img/sqrs/blSqr.png"
};
};
function sqrsG344() {
    if(document.getElementById("imgSqrs344").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs344").src = "img/sqrs/blSqr.png"
};
};
function sqrsG345() {
    if(document.getElementById("imgSqrs345").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs345").src = "img/sqrs/blSqr.png"
};
};
function sqrsG346() {
    if(document.getElementById("imgSqrs346").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs346").src = "img/sqrs/blSqr.png"
};
};
function sqrsG347() {
    if(document.getElementById("imgSqrs347").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs347").src = "img/sqrs/blSqr.png"
};
};
function sqrsG348() {
    if(document.getElementById("imgSqrs348").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs348").src = "img/sqrs/blSqr.png"
};
};
function sqrsG349() {
    if(document.getElementById("imgSqrs349").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs349").src = "img/sqrs/blSqr.png"
};
};
function sqrsG350() {
    if(document.getElementById("imgSqrs350").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs350").src = "img/sqrs/blSqr.png"
};
};
function sqrsH351() {
    if(document.getElementById("imgSqrs351").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs351").src = "img/sqrs/blSqr.png"
};
};
function sqrsH352() {
    if(document.getElementById("imgSqrs352").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs352").src = "img/sqrs/blSqr.png"
};
};
function sqrsH353() {
    if(document.getElementById("imgSqrs353").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs353").src = "img/sqrs/blSqr.png"
};
};
function sqrsH354() {
    if(document.getElementById("imgSqrs354").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs354").src = "img/sqrs/blSqr.png"
};
};
function sqrsH355() {
    if(document.getElementById("imgSqrs355").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs355").src = "img/sqrs/blSqr.png"
};
};
function sqrsH356() {
    if(document.getElementById("imgSqrs356").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs356").src = "img/sqrs/blSqr.png"
};
};
function sqrsH357() {
    if(document.getElementById("imgSqrs357").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs357").src = "img/sqrs/blSqr.png"
};
};
function sqrsH358() {
    if(document.getElementById("imgSqrs358").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs358").src = "img/sqrs/blSqr.png"
};
};
function sqrsH359() {
    if(document.getElementById("imgSqrs359").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs359").src = "img/sqrs/blSqr.png"
};
};
function sqrsH360() {
    if(document.getElementById("imgSqrs360").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs360").src = "img/sqrs/blSqr.png"
};
};
function sqrsH361() {
    if(document.getElementById("imgSqrs361").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs361").src = "img/sqrs/blSqr.png"
};
};
function sqrsH362() {
    if(document.getElementById("imgSqrs362").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs362").src = "img/sqrs/blSqr.png"
};
};
function sqrsH363() {
    if(document.getElementById("imgSqrs363").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs363").src = "img/sqrs/blSqr.png"
};
};
function sqrsH364() {
    if(document.getElementById("imgSqrs364").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs364").src = "img/sqrs/blSqr.png"
};
};
function sqrsH365() {
    if(document.getElementById("imgSqrs365").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs365").src = "img/sqrs/blSqr.png"
};
};
function sqrsH366() {
    if(document.getElementById("imgSqrs366").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs366").src = "img/sqrs/blSqr.png"
};
};
function sqrsH367() {
    if(document.getElementById("imgSqrs367").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs367").src = "img/sqrs/blSqr.png"
};
};
function sqrsH368() {
    if(document.getElementById("imgSqrs368").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs368").src = "img/sqrs/blSqr.png"
};
};
function sqrsH369() {
    if(document.getElementById("imgSqrs369").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs369").src = "img/sqrs/blSqr.png"
};
};
function sqrsH370() {
    if(document.getElementById("imgSqrs370").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs370").src = "img/sqrs/blSqr.png"
};
};
function sqrsH371() {
    if(document.getElementById("imgSqrs371").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs371").src = "img/sqrs/blSqr.png"
};
};
function sqrsH372() {
    if(document.getElementById("imgSqrs372").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs372").src = "img/sqrs/blSqr.png"
};
};
function sqrsH373() {
    if(document.getElementById("imgSqrs373").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs373").src = "img/sqrs/blSqr.png"
};
};
function sqrsH374() {
    if(document.getElementById("imgSqrs374").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs374").src = "img/sqrs/blSqr.png"
};
};
function sqrsH375() {
    if(document.getElementById("imgSqrs375").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs375").src = "img/sqrs/blSqr.png"
};
};
function sqrsH376() {
    if(document.getElementById("imgSqrs376").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs376").src = "img/sqrs/blSqr.png"
};
};
function sqrsH377() {
    if(document.getElementById("imgSqrs377").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs377").src = "img/sqrs/blSqr.png"
};
};
function sqrsH378() {
    if(document.getElementById("imgSqrs378").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs378").src = "img/sqrs/blSqr.png"
};
};
function sqrsH379() {
    if(document.getElementById("imgSqrs379").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs379").src = "img/sqrs/blSqr.png"
};
};
function sqrsH380() {
    if(document.getElementById("imgSqrs380").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs380").src = "img/sqrs/blSqr.png"
};
};
function sqrsH381() {
    if(document.getElementById("imgSqrs381").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs381").src = "img/sqrs/blSqr.png"
};
};
function sqrsH382() {
    if(document.getElementById("imgSqrs382").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs382").src = "img/sqrs/blSqr.png"
};
};
function sqrsH383() {
    if(document.getElementById("imgSqrs383").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs383").src = "img/sqrs/blSqr.png"
};
};
function sqrsH384() {
    if(document.getElementById("imgSqrs384").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs384").src = "img/sqrs/blSqr.png"
};
};
function sqrsH385() {
    if(document.getElementById("imgSqrs385").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs385").src = "img/sqrs/blSqr.png"
};
};
function sqrsH386() {
    if(document.getElementById("imgSqrs386").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs386").src = "img/sqrs/blSqr.png"
};
};
function sqrsH387() {
    if(document.getElementById("imgSqrs387").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs387").src = "img/sqrs/blSqr.png"
};
};
function sqrsH388() {
    if(document.getElementById("imgSqrs388").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs388").src = "img/sqrs/blSqr.png"
};
};
function sqrsH389() {
    if(document.getElementById("imgSqrs389").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs389").src = "img/sqrs/blSqr.png"
};
};
function sqrsH390() {
    if(document.getElementById("imgSqrs390").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs390").src = "img/sqrs/blSqr.png"
};
};
function sqrsH391() {
    if(document.getElementById("imgSqrs391").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs391").src = "img/sqrs/blSqr.png"
};
};
function sqrsH392() {
    if(document.getElementById("imgSqrs392").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs392").src = "img/sqrs/blSqr.png"
};
};
function sqrsH393() {
    if(document.getElementById("imgSqrs393").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs393").src = "img/sqrs/blSqr.png"
};
};
function sqrsH394() {
    if(document.getElementById("imgSqrs394").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs394").src = "img/sqrs/blSqr.png"
};
};
function sqrsH395() {
    if(document.getElementById("imgSqrs395").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs395").src = "img/sqrs/blSqr.png"
};
};
function sqrsH396() {
    if(document.getElementById("imgSqrs396").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs396").src = "img/sqrs/blSqr.png"
};
};
function sqrsH397() {
    if(document.getElementById("imgSqrs397").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs397").src = "img/sqrs/blSqr.png"
};
};
function sqrsH398() {
    if(document.getElementById("imgSqrs398").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs398").src = "img/sqrs/blSqr.png"
};
};
function sqrsH399() {
    if(document.getElementById("imgSqrs399").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs399").src = "img/sqrs/blSqr.png"
};
};
function sqrsH400() {
    if(document.getElementById("imgSqrs400").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs400").src = "img/sqrs/blSqr.png"
};
};
function sqrsI401() {
    if(document.getElementById("imgSqrs401").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs401").src = "img/sqrs/blSqr.png"
};
};
function sqrsI402() {
    if(document.getElementById("imgSqrs402").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs402").src = "img/sqrs/blSqr.png"
};
};
function sqrsI403() {
    if(document.getElementById("imgSqrs403").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs403").src = "img/sqrs/blSqr.png"
};
};
function sqrsI404() {
    if(document.getElementById("imgSqrs404").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs404").src = "img/sqrs/blSqr.png"
};
};
function sqrsI405() {
    if(document.getElementById("imgSqrs405").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs405").src = "img/sqrs/blSqr.png"
};
};
function sqrsI406() {
    if(document.getElementById("imgSqrs406").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs406").src = "img/sqrs/blSqr.png"
};
};
function sqrsI407() {
    if(document.getElementById("imgSqrs407").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs407").src = "img/sqrs/blSqr.png"
};
};
function sqrsI408() {
    if(document.getElementById("imgSqrs408").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs408").src = "img/sqrs/blSqr.png"
};
};
function sqrsI409() {
    if(document.getElementById("imgSqrs409").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs409").src = "img/sqrs/blSqr.png"
};
};
function sqrsI410() {
    if(document.getElementById("imgSqrs410").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs410").src = "img/sqrs/blSqr.png"
};
};
function sqrsI411() {
    if(document.getElementById("imgSqrs411").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs411").src = "img/sqrs/blSqr.png"
};
};
function sqrsI412() {
    if(document.getElementById("imgSqrs412").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs412").src = "img/sqrs/blSqr.png"
};
};
function sqrsI413() {
    if(document.getElementById("imgSqrs413").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs413").src = "img/sqrs/blSqr.png"
};
};
function sqrsI414() {
    if(document.getElementById("imgSqrs414").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs414").src = "img/sqrs/blSqr.png"
};
};
function sqrsI415() {
    if(document.getElementById("imgSqrs415").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs415").src = "img/sqrs/blSqr.png"
};
};
function sqrsI416() {
    if(document.getElementById("imgSqrs416").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs416").src = "img/sqrs/blSqr.png"
};
};
function sqrsI417() {
    if(document.getElementById("imgSqrs417").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs417").src = "img/sqrs/blSqr.png"
};
};
function sqrsI418() {
    if(document.getElementById("imgSqrs418").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs418").src = "img/sqrs/blSqr.png"
};
};
function sqrsI419() {
    if(document.getElementById("imgSqrs419").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs419").src = "img/sqrs/blSqr.png"
};
};
function sqrsI420() {
    if(document.getElementById("imgSqrs420").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs420").src = "img/sqrs/blSqr.png"
};
};
function sqrsI421() {
    if(document.getElementById("imgSqrs421").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs421").src = "img/sqrs/blSqr.png"
};
};
function sqrsI422() {
    if(document.getElementById("imgSqrs422").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs422").src = "img/sqrs/blSqr.png"
};
};
function sqrsI423() {
    if(document.getElementById("imgSqrs423").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs423").src = "img/sqrs/blSqr.png"
};
};
function sqrsI424() {
    if(document.getElementById("imgSqrs424").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs424").src = "img/sqrs/blSqr.png"
};
};
function sqrsI425() {
    if(document.getElementById("imgSqrs425").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs425").src = "img/sqrs/blSqr.png"
};
};
function sqrsI426() {
    if(document.getElementById("imgSqrs426").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs426").src = "img/sqrs/blSqr.png"
};
};
function sqrsI427() {
    if(document.getElementById("imgSqrs427").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs427").src = "img/sqrs/blSqr.png"
};
};
function sqrsI428() {
    if(document.getElementById("imgSqrs428").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs428").src = "img/sqrs/blSqr.png"
};
};
function sqrsI429() {
    if(document.getElementById("imgSqrs429").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs429").src = "img/sqrs/blSqr.png"
};
};
function sqrsI430() {
    if(document.getElementById("imgSqrs430").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs430").src = "img/sqrs/blSqr.png"
};
};
function sqrsI431() {
    if(document.getElementById("imgSqrs431").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs431").src = "img/sqrs/blSqr.png"
};
};
function sqrsI432() {
    if(document.getElementById("imgSqrs432").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs432").src = "img/sqrs/blSqr.png"
};
};
function sqrsI433() {
    if(document.getElementById("imgSqrs433").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs433").src = "img/sqrs/blSqr.png"
};
};
function sqrsI434() {
    if(document.getElementById("imgSqrs434").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs434").src = "img/sqrs/blSqr.png"
};
};
function sqrsI435() {
    if(document.getElementById("imgSqrs435").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs435").src = "img/sqrs/blSqr.png"
};
};
function sqrsI436() {
    if(document.getElementById("imgSqrs436").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs436").src = "img/sqrs/blSqr.png"
};
};
function sqrsI437() {
    if(document.getElementById("imgSqrs437").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs437").src = "img/sqrs/blSqr.png"
};
};
function sqrsI438() {
    if(document.getElementById("imgSqrs438").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs438").src = "img/sqrs/blSqr.png"
};
};
function sqrsI439() {
    if(document.getElementById("imgSqrs439").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs439").src = "img/sqrs/blSqr.png"
};
};
function sqrsI440() {
    if(document.getElementById("imgSqrs440").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs440").src = "img/sqrs/blSqr.png"
};
};
function sqrsI441() {
    if(document.getElementById("imgSqrs441").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs441").src = "img/sqrs/blSqr.png"
};
};
function sqrsI442() {
    if(document.getElementById("imgSqrs442").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs442").src = "img/sqrs/blSqr.png"
};
};
function sqrsI443() {
    if(document.getElementById("imgSqrs443").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs443").src = "img/sqrs/blSqr.png"
};
};
function sqrsI444() {
    if(document.getElementById("imgSqrs444").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs444").src = "img/sqrs/blSqr.png"
};
};
function sqrsI445() {
    if(document.getElementById("imgSqrs445").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs445").src = "img/sqrs/blSqr.png"
};
};
function sqrsI446() {
    if(document.getElementById("imgSqrs446").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs446").src = "img/sqrs/blSqr.png"
};
};
function sqrsI447() {
    if(document.getElementById("imgSqrs447").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs447").src = "img/sqrs/blSqr.png"
};
};
function sqrsI448() {
    if(document.getElementById("imgSqrs448").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs448").src = "img/sqrs/blSqr.png"
};
};
function sqrsI449() {
    if(document.getElementById("imgSqrs449").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs449").src = "img/sqrs/blSqr.png"
};
};
function sqrsI450() {
    if(document.getElementById("imgSqrs450").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs450").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ451() {
    if(document.getElementById("imgSqrs451").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs451").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ452() {
    if(document.getElementById("imgSqrs452").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs452").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ453() {
    if(document.getElementById("imgSqrs453").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs453").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ454() {
    if(document.getElementById("imgSqrs454").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs454").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ455() {
    if(document.getElementById("imgSqrs455").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs455").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ456() {
    if(document.getElementById("imgSqrs456").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs456").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ457() {
    if(document.getElementById("imgSqrs457").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs457").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ458() {
    if(document.getElementById("imgSqrs458").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs458").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ459() {
    if(document.getElementById("imgSqrs459").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs459").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ460() {
    if(document.getElementById("imgSqrs460").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs460").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ461() {
    if(document.getElementById("imgSqrs461").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs461").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ462() {
    if(document.getElementById("imgSqrs462").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs462").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ463() {
    if(document.getElementById("imgSqrs463").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs463").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ464() {
    if(document.getElementById("imgSqrs464").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs464").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ465() {
    if(document.getElementById("imgSqrs465").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs465").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ466() {
    if(document.getElementById("imgSqrs466").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs466").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ467() {
    if(document.getElementById("imgSqrs467").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs467").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ468() {
    if(document.getElementById("imgSqrs468").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs468").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ469() {
    if(document.getElementById("imgSqrs469").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs469").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ470() {
    if(document.getElementById("imgSqrs470").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs470").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ471() {
    if(document.getElementById("imgSqrs471").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs471").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ472() {
    if(document.getElementById("imgSqrs472").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs472").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ473() {
    if(document.getElementById("imgSqrs473").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs473").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ474() {
    if(document.getElementById("imgSqrs474").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs474").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ475() {
    if(document.getElementById("imgSqrs475").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs475").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ476() {
    if(document.getElementById("imgSqrs476").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs476").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ477() {
    if(document.getElementById("imgSqrs477").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs477").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ478() {
    if(document.getElementById("imgSqrs478").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs478").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ479() {
    if(document.getElementById("imgSqrs479").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs479").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ480() {
    if(document.getElementById("imgSqrs480").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs480").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ481() {
    if(document.getElementById("imgSqrs481").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs481").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ482() {
    if(document.getElementById("imgSqrs482").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs482").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ483() {
    if(document.getElementById("imgSqrs483").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs483").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ484() {
    if(document.getElementById("imgSqrs484").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs484").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ485() {
    if(document.getElementById("imgSqrs485").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs485").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ486() {
    if(document.getElementById("imgSqrs486").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs486").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ487() {
    if(document.getElementById("imgSqrs487").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs487").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ488() {
    if(document.getElementById("imgSqrs488").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs488").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ489() {
    if(document.getElementById("imgSqrs489").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs489").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ490() {
    if(document.getElementById("imgSqrs490").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs490").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ491() {
    if(document.getElementById("imgSqrs491").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs491").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ492() {
    if(document.getElementById("imgSqrs492").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs492").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ493() {
    if(document.getElementById("imgSqrs493").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs493").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ494() {
    if(document.getElementById("imgSqrs494").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs494").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ495() {
    if(document.getElementById("imgSqrs495").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs495").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ496() {
    if(document.getElementById("imgSqrs496").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs496").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ497() {
    if(document.getElementById("imgSqrs497").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs497").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ498() {
    if(document.getElementById("imgSqrs498").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs498").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ499() {
    if(document.getElementById("imgSqrs499").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs499").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ500() {
    if(document.getElementById("imgSqrs500").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs500").src = "img/sqrs/blSqr.png"
};
};
function sqrsK501() {
    if(document.getElementById("imgSqrs501").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs501").src = "img/sqrs/blSqr.png"
};
};
function sqrsK502() {
    if(document.getElementById("imgSqrs502").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs502").src = "img/sqrs/blSqr.png"
};
};
function sqrsK503() {
    if(document.getElementById("imgSqrs503").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs503").src = "img/sqrs/blSqr.png"
};
};
function sqrsK504() {
    if(document.getElementById("imgSqrs504").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs504").src = "img/sqrs/blSqr.png"
};
};
function sqrsK505() {
    if(document.getElementById("imgSqrs505").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs505").src = "img/sqrs/blSqr.png"
};
};
function sqrsK506() {
    if(document.getElementById("imgSqrs506").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs506").src = "img/sqrs/blSqr.png"
};
};
function sqrsK507() {
    if(document.getElementById("imgSqrs507").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs507").src = "img/sqrs/blSqr.png"
};
};
function sqrsK508() {
    if(document.getElementById("imgSqrs508").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs508").src = "img/sqrs/blSqr.png"
};
};
function sqrsK509() {
    if(document.getElementById("imgSqrs509").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs509").src = "img/sqrs/blSqr.png"
};
};
function sqrsK510() {
    if(document.getElementById("imgSqrs510").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs510").src = "img/sqrs/blSqr.png"
};
};
function sqrsK511() {
    if(document.getElementById("imgSqrs511").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs511").src = "img/sqrs/blSqr.png"
};
};
function sqrsK512() {
    if(document.getElementById("imgSqrs512").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs512").src = "img/sqrs/blSqr.png"
};
};
function sqrsK513() {
    if(document.getElementById("imgSqrs513").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs513").src = "img/sqrs/blSqr.png"
};
};
function sqrsK514() {
    if(document.getElementById("imgSqrs514").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs514").src = "img/sqrs/blSqr.png"
};
};
function sqrsK515() {
    if(document.getElementById("imgSqrs515").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs515").src = "img/sqrs/blSqr.png"
};
};
function sqrsK516() {
    if(document.getElementById("imgSqrs516").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs516").src = "img/sqrs/blSqr.png"
};
};
function sqrsK517() {
    if(document.getElementById("imgSqrs517").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs517").src = "img/sqrs/blSqr.png"
};
};
function sqrsK518() {
    if(document.getElementById("imgSqrs518").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs518").src = "img/sqrs/blSqr.png"
};
};
function sqrsK519() {
    if(document.getElementById("imgSqrs519").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs519").src = "img/sqrs/blSqr.png"
};
};
function sqrsK520() {
    if(document.getElementById("imgSqrs520").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs520").src = "img/sqrs/blSqr.png"
};
};
function sqrsK521() {
    if(document.getElementById("imgSqrs521").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs521").src = "img/sqrs/blSqr.png"
};
};
function sqrsK522() {
    if(document.getElementById("imgSqrs522").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs522").src = "img/sqrs/blSqr.png"
};
};
function sqrsK523() {
    if(document.getElementById("imgSqrs523").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs523").src = "img/sqrs/blSqr.png"
};
};
function sqrsK524() {
    if(document.getElementById("imgSqrs524").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs524").src = "img/sqrs/blSqr.png"
};
};
function sqrsK525() {
    if(document.getElementById("imgSqrs525").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs525").src = "img/sqrs/blSqr.png"
};
};
function sqrsK526() {
    if(document.getElementById("imgSqrs526").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs526").src = "img/sqrs/blSqr.png"
};
};
function sqrsK527() {
    if(document.getElementById("imgSqrs527").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs527").src = "img/sqrs/blSqr.png"
};
};
function sqrsK528() {
    if(document.getElementById("imgSqrs528").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs528").src = "img/sqrs/blSqr.png"
};
};
function sqrsK529() {
    if(document.getElementById("imgSqrs529").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs529").src = "img/sqrs/blSqr.png"
};
};
function sqrsK530() {
    if(document.getElementById("imgSqrs530").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs530").src = "img/sqrs/blSqr.png"
};
};
function sqrsK531() {
    if(document.getElementById("imgSqrs531").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs531").src = "img/sqrs/blSqr.png"
};
};
function sqrsK532() {
    if(document.getElementById("imgSqrs532").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs532").src = "img/sqrs/blSqr.png"
};
};
function sqrsK533() {
    if(document.getElementById("imgSqrs533").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs533").src = "img/sqrs/blSqr.png"
};
};
function sqrsK534() {
    if(document.getElementById("imgSqrs534").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs534").src = "img/sqrs/blSqr.png"
};
};
function sqrsK535() {
    if(document.getElementById("imgSqrs535").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs535").src = "img/sqrs/blSqr.png"
};
};
function sqrsK536() {
    if(document.getElementById("imgSqrs536").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs536").src = "img/sqrs/blSqr.png"
};
};
function sqrsK537() {
    if(document.getElementById("imgSqrs537").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs537").src = "img/sqrs/blSqr.png"
};
};
function sqrsK538() {
    if(document.getElementById("imgSqrs538").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs538").src = "img/sqrs/blSqr.png"
};
};
function sqrsK539() {
    if(document.getElementById("imgSqrs539").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs539").src = "img/sqrs/blSqr.png"
};
};
function sqrsK540() {
    if(document.getElementById("imgSqrs540").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs540").src = "img/sqrs/blSqr.png"
};
};
function sqrsK541() {
    if(document.getElementById("imgSqrs541").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs541").src = "img/sqrs/blSqr.png"
};
};
function sqrsK542() {
    if(document.getElementById("imgSqrs542").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs542").src = "img/sqrs/blSqr.png"
};
};
function sqrsK543() {
    if(document.getElementById("imgSqrs543").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs543").src = "img/sqrs/blSqr.png"
};
};
function sqrsK544() {
    if(document.getElementById("imgSqrs544").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs544").src = "img/sqrs/blSqr.png"
};
};
function sqrsK545() {
    if(document.getElementById("imgSqrs545").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs545").src = "img/sqrs/blSqr.png"
};
};
function sqrsK546() {
    if(document.getElementById("imgSqrs546").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs546").src = "img/sqrs/blSqr.png"
};
};
function sqrsK547() {
    if(document.getElementById("imgSqrs547").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs547").src = "img/sqrs/blSqr.png"
};
};
function sqrsK548() {
    if(document.getElementById("imgSqrs548").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs548").src = "img/sqrs/blSqr.png"
};
};
function sqrsK549() {
    if(document.getElementById("imgSqrs549").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs549").src = "img/sqrs/blSqr.png"
};
};
function sqrsK550() {
    if(document.getElementById("imgSqrs550").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs550").src = "img/sqrs/blSqr.png"
};
};
function sqrsL551() {
    if(document.getElementById("imgSqrs551").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs551").src = "img/sqrs/blSqr.png"
};
};
function sqrsL552() {
    if(document.getElementById("imgSqrs552").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs552").src = "img/sqrs/blSqr.png"
};
};
function sqrsL553() {
    if(document.getElementById("imgSqrs553").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs553").src = "img/sqrs/blSqr.png"
};
};
function sqrsL554() {
    if(document.getElementById("imgSqrs554").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs554").src = "img/sqrs/blSqr.png"
};
};
function sqrsL555() {
    if(document.getElementById("imgSqrs555").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs555").src = "img/sqrs/blSqr.png"
};
};
function sqrsL556() {
    if(document.getElementById("imgSqrs556").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs556").src = "img/sqrs/blSqr.png"
};
};
function sqrsL557() {
    if(document.getElementById("imgSqrs557").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs557").src = "img/sqrs/blSqr.png"
};
};
function sqrsL558() {
    if(document.getElementById("imgSqrs558").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs558").src = "img/sqrs/blSqr.png"
};
};
function sqrsL559() {
    if(document.getElementById("imgSqrs559").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs559").src = "img/sqrs/blSqr.png"
};
};
function sqrsL560() {
    if(document.getElementById("imgSqrs560").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs560").src = "img/sqrs/blSqr.png"
};
};
function sqrsL561() {
    if(document.getElementById("imgSqrs561").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs561").src = "img/sqrs/blSqr.png"
};
};
function sqrsL562() {
    if(document.getElementById("imgSqrs562").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs562").src = "img/sqrs/blSqr.png"
};
};
function sqrsL563() {
    if(document.getElementById("imgSqrs563").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs563").src = "img/sqrs/blSqr.png"
};
};
function sqrsL564() {
    if(document.getElementById("imgSqrs564").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs564").src = "img/sqrs/blSqr.png"
};
};
function sqrsL565() {
    if(document.getElementById("imgSqrs565").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs565").src = "img/sqrs/blSqr.png"
};
};
function sqrsL566() {
    if(document.getElementById("imgSqrs566").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs566").src = "img/sqrs/blSqr.png"
};
};
function sqrsL567() {
    if(document.getElementById("imgSqrs567").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs567").src = "img/sqrs/blSqr.png"
};
};
function sqrsL568() {
    if(document.getElementById("imgSqrs568").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs568").src = "img/sqrs/blSqr.png"
};
};
function sqrsL569() {
    if(document.getElementById("imgSqrs569").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs569").src = "img/sqrs/blSqr.png"
};
};
function sqrsL570() {
    if(document.getElementById("imgSqrs570").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs570").src = "img/sqrs/blSqr.png"
};
};
function sqrsL571() {
    if(document.getElementById("imgSqrs571").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs571").src = "img/sqrs/blSqr.png"
};
};
function sqrsL572() {
    if(document.getElementById("imgSqrs572").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs572").src = "img/sqrs/blSqr.png"
};
};
function sqrsL573() {
    if(document.getElementById("imgSqrs573").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs573").src = "img/sqrs/blSqr.png"
};
};
function sqrsL574() {
    if(document.getElementById("imgSqrs574").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs574").src = "img/sqrs/blSqr.png"
};
};
function sqrsL575() {
    if(document.getElementById("imgSqrs575").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs575").src = "img/sqrs/blSqr.png"
};
};
function sqrsL576() {
    if(document.getElementById("imgSqrs576").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs576").src = "img/sqrs/blSqr.png"
};
};
function sqrsL577() {
    if(document.getElementById("imgSqrs577").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs577").src = "img/sqrs/blSqr.png"
};
};
function sqrsL578() {
    if(document.getElementById("imgSqrs578").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs578").src = "img/sqrs/blSqr.png"
};
};
function sqrsL579() {
    if(document.getElementById("imgSqrs579").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs579").src = "img/sqrs/blSqr.png"
};
};
function sqrsL580() {
    if(document.getElementById("imgSqrs580").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs580").src = "img/sqrs/blSqr.png"
};
};
function sqrsL581() {
    if(document.getElementById("imgSqrs581").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs581").src = "img/sqrs/blSqr.png"
};
};
function sqrsL582() {
    if(document.getElementById("imgSqrs582").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs582").src = "img/sqrs/blSqr.png"
};
};
function sqrsL583() {
    if(document.getElementById("imgSqrs583").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs583").src = "img/sqrs/blSqr.png"
};
};
function sqrsL584() {
    if(document.getElementById("imgSqrs584").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs584").src = "img/sqrs/blSqr.png"
};
};
function sqrsL585() {
    if(document.getElementById("imgSqrs585").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs585").src = "img/sqrs/blSqr.png"
};
};
function sqrsL586() {
    if(document.getElementById("imgSqrs586").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs586").src = "img/sqrs/blSqr.png"
};
};
function sqrsL587() {
    if(document.getElementById("imgSqrs587").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs587").src = "img/sqrs/blSqr.png"
};
};
function sqrsL588() {
    if(document.getElementById("imgSqrs588").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs588").src = "img/sqrs/blSqr.png"
};
};
function sqrsL589() {
    if(document.getElementById("imgSqrs589").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs589").src = "img/sqrs/blSqr.png"
};
};
function sqrsL590() {
    if(document.getElementById("imgSqrs590").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs590").src = "img/sqrs/blSqr.png"
};
};
function sqrsL591() {
    if(document.getElementById("imgSqrs591").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs591").src = "img/sqrs/blSqr.png"
};
};
function sqrsL592() {
    if(document.getElementById("imgSqrs592").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs592").src = "img/sqrs/blSqr.png"
};
};
function sqrsL593() {
    if(document.getElementById("imgSqrs593").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs593").src = "img/sqrs/blSqr.png"
};
};
function sqrsL594() {
    if(document.getElementById("imgSqrs594").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs594").src = "img/sqrs/blSqr.png"
};
};
function sqrsL595() {
    if(document.getElementById("imgSqrs595").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs595").src = "img/sqrs/blSqr.png"
};
};
function sqrsL596() {
    if(document.getElementById("imgSqrs596").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs596").src = "img/sqrs/blSqr.png"
};
};
function sqrsL597() {
    if(document.getElementById("imgSqrs597").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs597").src = "img/sqrs/blSqr.png"
};
};
function sqrsL598() {
    if(document.getElementById("imgSqrs598").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs598").src = "img/sqrs/blSqr.png"
};
};
function sqrsL599() {
    if(document.getElementById("imgSqrs599").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs599").src = "img/sqrs/blSqr.png"
};
};
function sqrsL600() {
    if(document.getElementById("imgSqrs600").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs600").src = "img/sqrs/blSqr.png"
};
};
function sqrsM601() {
    if(document.getElementById("imgSqrs601").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs601").src = "img/sqrs/blSqr.png"
};
};
function sqrsM602() {
    if(document.getElementById("imgSqrs602").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs602").src = "img/sqrs/blSqr.png"
};
};
function sqrsM603() {
    if(document.getElementById("imgSqrs603").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs603").src = "img/sqrs/blSqr.png"
};
};
function sqrsM604() {
    if(document.getElementById("imgSqrs604").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs604").src = "img/sqrs/blSqr.png"
};
};
function sqrsM605() {
    if(document.getElementById("imgSqrs605").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs605").src = "img/sqrs/blSqr.png"
};
};
function sqrsM606() {
    if(document.getElementById("imgSqrs606").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs606").src = "img/sqrs/blSqr.png"
};
};
function sqrsM607() {
    if(document.getElementById("imgSqrs607").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs607").src = "img/sqrs/blSqr.png"
};
};
function sqrsM608() {
    if(document.getElementById("imgSqrs608").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs608").src = "img/sqrs/blSqr.png"
};
};
function sqrsM609() {
    if(document.getElementById("imgSqrs609").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs609").src = "img/sqrs/blSqr.png"
};
};
function sqrsM610() {
    if(document.getElementById("imgSqrs610").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs610").src = "img/sqrs/blSqr.png"
};
};
function sqrsM611() {
    if(document.getElementById("imgSqrs611").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs611").src = "img/sqrs/blSqr.png"
};
};
function sqrsM612() {
    if(document.getElementById("imgSqrs612").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs612").src = "img/sqrs/blSqr.png"
};
};
function sqrsM613() {
    if(document.getElementById("imgSqrs613").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs613").src = "img/sqrs/blSqr.png"
};
};
function sqrsM614() {
    if(document.getElementById("imgSqrs614").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs614").src = "img/sqrs/blSqr.png"
};
};
function sqrsM615() {
    if(document.getElementById("imgSqrs615").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs615").src = "img/sqrs/blSqr.png"
};
};
function sqrsM616() {
    if(document.getElementById("imgSqrs616").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs616").src = "img/sqrs/blSqr.png"
};
};
function sqrsM617() {
    if(document.getElementById("imgSqrs617").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs617").src = "img/sqrs/blSqr.png"
};
};
function sqrsM618() {
    if(document.getElementById("imgSqrs618").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs618").src = "img/sqrs/blSqr.png"
};
};
function sqrsM619() {
    if(document.getElementById("imgSqrs619").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs619").src = "img/sqrs/blSqr.png"
};
};
function sqrsM620() {
    if(document.getElementById("imgSqrs620").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs620").src = "img/sqrs/blSqr.png"
};
};
function sqrsM621() {
    if(document.getElementById("imgSqrs621").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs621").src = "img/sqrs/blSqr.png"
};
};
function sqrsM622() {
    if(document.getElementById("imgSqrs622").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs622").src = "img/sqrs/blSqr.png"
};
};
function sqrsM623() {
    if(document.getElementById("imgSqrs623").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs623").src = "img/sqrs/blSqr.png"
};
};
function sqrsM624() {
    if(document.getElementById("imgSqrs624").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs624").src = "img/sqrs/blSqr.png"
};
};
function sqrsM625() {
    if(document.getElementById("imgSqrs625").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs625").src = "img/sqrs/blSqr.png"
};
};

function sqrsA1b() {
    if(document.getElementById("imgSqrs1").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1").src = "img/sqrs/wSqr.png"
};
};
function sqrsA2b() {
    if(document.getElementById("imgSqrs2").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2").src = "img/sqrs/wSqr.png"
};
};
function sqrsA3b() {
    if(document.getElementById("imgSqrs3").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs3").src = "img/sqrs/wSqr.png"
};
};
function sqrsA4b() {
    if(document.getElementById("imgSqrs4").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs4").src = "img/sqrs/wSqr.png"
};
};
function sqrsA5b() {
    if(document.getElementById("imgSqrs5").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs5").src = "img/sqrs/wSqr.png"
};
};
function sqrsA6b() {
    if(document.getElementById("imgSqrs6").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs6").src = "img/sqrs/wSqr.png"
};
};
function sqrsA7b() {
    if(document.getElementById("imgSqrs7").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs7").src = "img/sqrs/wSqr.png"
};
};
function sqrsA8b() {
    if(document.getElementById("imgSqrs8").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs8").src = "img/sqrs/wSqr.png"
};
};
function sqrsA9b() {
    if(document.getElementById("imgSqrs9").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs9").src = "img/sqrs/wSqr.png"
};
};
function sqrsA10b() {
    if(document.getElementById("imgSqrs10").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs10").src = "img/sqrs/wSqr.png"
};
};
function sqrsA11b() {
    if(document.getElementById("imgSqrs11").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs11").src = "img/sqrs/wSqr.png"
};
};
function sqrsA12b() {
    if(document.getElementById("imgSqrs12").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs12").src = "img/sqrs/wSqr.png"
};
};
function sqrsA13b() {
    if(document.getElementById("imgSqrs13").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs13").src = "img/sqrs/wSqr.png"
};
};
function sqrsA14b() {
    if(document.getElementById("imgSqrs14").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs14").src = "img/sqrs/wSqr.png"
};
};
function sqrsA15b() {
    if(document.getElementById("imgSqrs15").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs15").src = "img/sqrs/wSqr.png"
};
};
function sqrsA16b() {
    if(document.getElementById("imgSqrs16").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs16").src = "img/sqrs/wSqr.png"
};
};
function sqrsA17b() {
    if(document.getElementById("imgSqrs17").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs17").src = "img/sqrs/wSqr.png"
};
};
function sqrsA18b() {
    if(document.getElementById("imgSqrs18").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs18").src = "img/sqrs/wSqr.png"
};
};
function sqrsA19b() {
    if(document.getElementById("imgSqrs19").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs19").src = "img/sqrs/wSqr.png"
};
};
function sqrsA20b() {
    if(document.getElementById("imgSqrs20").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs20").src = "img/sqrs/wSqr.png"
};
};
function sqrsA21b() {
    if(document.getElementById("imgSqrs21").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs21").src = "img/sqrs/wSqr.png"
};
};
function sqrsA22b() {
    if(document.getElementById("imgSqrs22").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs22").src = "img/sqrs/wSqr.png"
};
};
function sqrsA23b() {
    if(document.getElementById("imgSqrs23").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs23").src = "img/sqrs/wSqr.png"
};
};
function sqrsA24b() {
    if(document.getElementById("imgSqrs24").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs24").src = "img/sqrs/wSqr.png"
};
};
function sqrsA25b() {
    if(document.getElementById("imgSqrs25").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs25").src = "img/sqrs/wSqr.png"
};
};
function sqrsA26b() {
    if(document.getElementById("imgSqrs26").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs26").src = "img/sqrs/wSqr.png"
};
};
function sqrsA27b() {
    if(document.getElementById("imgSqrs27").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs27").src = "img/sqrs/wSqr.png"
};
};
function sqrsA28b() {
    if(document.getElementById("imgSqrs28").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs28").src = "img/sqrs/wSqr.png"
};
};
function sqrsA29b() {
    if(document.getElementById("imgSqrs29").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs29").src = "img/sqrs/wSqr.png"
};
};
function sqrsA30b() {
    if(document.getElementById("imgSqrs30").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs30").src = "img/sqrs/wSqr.png"
};
};
function sqrsA31b() {
    if(document.getElementById("imgSqrs31").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs31").src = "img/sqrs/wSqr.png"
};
};
function sqrsA32b() {
    if(document.getElementById("imgSqrs32").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs32").src = "img/sqrs/wSqr.png"
};
};
function sqrsA33b() {
    if(document.getElementById("imgSqrs33").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs33").src = "img/sqrs/wSqr.png"
};
};
function sqrsA34b() {
    if(document.getElementById("imgSqrs34").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs34").src = "img/sqrs/wSqr.png"
};
};
function sqrsA35b() {
    if(document.getElementById("imgSqrs35").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs35").src = "img/sqrs/wSqr.png"
};
};
function sqrsA36b() {
    if(document.getElementById("imgSqrs36").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs36").src = "img/sqrs/wSqr.png"
};
};
function sqrsA37b() {
    if(document.getElementById("imgSqrs37").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs37").src = "img/sqrs/wSqr.png"
};
};
function sqrsA38b() {
    if(document.getElementById("imgSqrs38").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs38").src = "img/sqrs/wSqr.png"
};
};
function sqrsA39b() {
    if(document.getElementById("imgSqrs39").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs39").src = "img/sqrs/wSqr.png"
};
};
function sqrsA40b() {
    if(document.getElementById("imgSqrs40").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs40").src = "img/sqrs/wSqr.png"
};
};
function sqrsA41b() {
    if(document.getElementById("imgSqrs41").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs41").src = "img/sqrs/wSqr.png"
};
};
function sqrsA42b() {
    if(document.getElementById("imgSqrs42").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs42").src = "img/sqrs/wSqr.png"
};
};
function sqrsA43b() {
    if(document.getElementById("imgSqrs43").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs43").src = "img/sqrs/wSqr.png"
};
};
function sqrsA44b() {
    if(document.getElementById("imgSqrs44").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs44").src = "img/sqrs/wSqr.png"
};
};
function sqrsA45b() {
    if(document.getElementById("imgSqrs45").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs45").src = "img/sqrs/wSqr.png"
};
};
function sqrsA46b() {
    if(document.getElementById("imgSqrs46").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs46").src = "img/sqrs/wSqr.png"
};
};
function sqrsA47b() {
    if(document.getElementById("imgSqrs47").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs47").src = "img/sqrs/wSqr.png"
};
};
function sqrsA48b() {
    if(document.getElementById("imgSqrs48").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs48").src = "img/sqrs/wSqr.png"
};
};
function sqrsA49b() {
    if(document.getElementById("imgSqrs49").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs49").src = "img/sqrs/wSqr.png"
};
};
function sqrsA50b() {
    if(document.getElementById("imgSqrs50").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs50").src = "img/sqrs/wSqr.png"
};
};
function sqrsB51b() {
    if(document.getElementById("imgSqrs51").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs51").src = "img/sqrs/wSqr.png"
};
};
function sqrsB52b() {
    if(document.getElementById("imgSqrs52").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs52").src = "img/sqrs/wSqr.png"
};
};
function sqrsB53b() {
    if(document.getElementById("imgSqrs53").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs53").src = "img/sqrs/wSqr.png"
};
};
function sqrsB54b() {
    if(document.getElementById("imgSqrs54").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs54").src = "img/sqrs/wSqr.png"
};
};
function sqrsB55b() {
    if(document.getElementById("imgSqrs55").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs55").src = "img/sqrs/wSqr.png"
};
};
function sqrsB56b() {
    if(document.getElementById("imgSqrs56").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs56").src = "img/sqrs/wSqr.png"
};
};
function sqrsB57b() {
    if(document.getElementById("imgSqrs57").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs57").src = "img/sqrs/wSqr.png"
};
};
function sqrsB58b() {
    if(document.getElementById("imgSqrs58").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs58").src = "img/sqrs/wSqr.png"
};
};
function sqrsB59b() {
    if(document.getElementById("imgSqrs59").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs59").src = "img/sqrs/wSqr.png"
};
};
function sqrsB60b() {
    if(document.getElementById("imgSqrs60").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs60").src = "img/sqrs/wSqr.png"
};
};
function sqrsB61b() {
    if(document.getElementById("imgSqrs61").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs61").src = "img/sqrs/wSqr.png"
};
};
function sqrsB62b() {
    if(document.getElementById("imgSqrs62").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs62").src = "img/sqrs/wSqr.png"
};
};
function sqrsB63b() {
    if(document.getElementById("imgSqrs63").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs63").src = "img/sqrs/wSqr.png"
};
};
function sqrsB64b() {
    if(document.getElementById("imgSqrs64").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs64").src = "img/sqrs/wSqr.png"
};
};
function sqrsB65b() {
    if(document.getElementById("imgSqrs65").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs65").src = "img/sqrs/wSqr.png"
};
};
function sqrsB66b() {
    if(document.getElementById("imgSqrs66").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs66").src = "img/sqrs/wSqr.png"
};
};
function sqrsB67b() {
    if(document.getElementById("imgSqrs67").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs67").src = "img/sqrs/wSqr.png"
};
};
function sqrsB68b() {
    if(document.getElementById("imgSqrs68").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs68").src = "img/sqrs/wSqr.png"
};
};
function sqrsB69b() {
    if(document.getElementById("imgSqrs69").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs69").src = "img/sqrs/wSqr.png"
};
};
function sqrsB70b() {
    if(document.getElementById("imgSqrs70").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs70").src = "img/sqrs/wSqr.png"
};
};
function sqrsB71b() {
    if(document.getElementById("imgSqrs71").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs71").src = "img/sqrs/wSqr.png"
};
};
function sqrsB72b() {
    if(document.getElementById("imgSqrs72").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs72").src = "img/sqrs/wSqr.png"
};
};
function sqrsB73b() {
    if(document.getElementById("imgSqrs73").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs73").src = "img/sqrs/wSqr.png"
};
};
function sqrsB74b() {
    if(document.getElementById("imgSqrs74").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs74").src = "img/sqrs/wSqr.png"
};
};
function sqrsB75b() {
    if(document.getElementById("imgSqrs75").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs75").src = "img/sqrs/wSqr.png"
};
};
function sqrsB76b() {
    if(document.getElementById("imgSqrs76").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs76").src = "img/sqrs/wSqr.png"
};
};
function sqrsB77b() {
    if(document.getElementById("imgSqrs77").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs77").src = "img/sqrs/wSqr.png"
};
};
function sqrsB78b() {
    if(document.getElementById("imgSqrs78").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs78").src = "img/sqrs/wSqr.png"
};
};
function sqrsB79b() {
    if(document.getElementById("imgSqrs79").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs79").src = "img/sqrs/wSqr.png"
};
};
function sqrsB80b() {
    if(document.getElementById("imgSqrs80").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs80").src = "img/sqrs/wSqr.png"
};
};
function sqrsB81b() {
    if(document.getElementById("imgSqrs81").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs81").src = "img/sqrs/wSqr.png"
};
};
function sqrsB82b() {
    if(document.getElementById("imgSqrs82").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs82").src = "img/sqrs/wSqr.png"
};
};
function sqrsB83b() {
    if(document.getElementById("imgSqrs83").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs83").src = "img/sqrs/wSqr.png"
};
};
function sqrsB84b() {
    if(document.getElementById("imgSqrs84").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs84").src = "img/sqrs/wSqr.png"
};
};
function sqrsB85b() {
    if(document.getElementById("imgSqrs85").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs85").src = "img/sqrs/wSqr.png"
};
};
function sqrsB86b() {
    if(document.getElementById("imgSqrs86").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs86").src = "img/sqrs/wSqr.png"
};
};
function sqrsB87b() {
    if(document.getElementById("imgSqrs87").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs87").src = "img/sqrs/wSqr.png"
};
};
function sqrsB88b() {
    if(document.getElementById("imgSqrs88").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs88").src = "img/sqrs/wSqr.png"
};
};
function sqrsB89b() {
    if(document.getElementById("imgSqrs89").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs89").src = "img/sqrs/wSqr.png"
};
};
function sqrsB90b() {
    if(document.getElementById("imgSqrs90").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs90").src = "img/sqrs/wSqr.png"
};
};
function sqrsB91b() {
    if(document.getElementById("imgSqrs91").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs91").src = "img/sqrs/wSqr.png"
};
};
function sqrsB92b() {
    if(document.getElementById("imgSqrs92").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs92").src = "img/sqrs/wSqr.png"
};
};
function sqrsB93b() {
    if(document.getElementById("imgSqrs93").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs93").src = "img/sqrs/wSqr.png"
};
};
function sqrsB94b() {
    if(document.getElementById("imgSqrs94").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs94").src = "img/sqrs/wSqr.png"
};
};
function sqrsB95b() {
    if(document.getElementById("imgSqrs95").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs95").src = "img/sqrs/wSqr.png"
};
};
function sqrsB96b() {
    if(document.getElementById("imgSqrs96").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs96").src = "img/sqrs/wSqr.png"
};
};
function sqrsB97b() {
    if(document.getElementById("imgSqrs97").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs97").src = "img/sqrs/wSqr.png"
};
};
function sqrsB98b() {
    if(document.getElementById("imgSqrs98").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs98").src = "img/sqrs/wSqr.png"
};
};
function sqrsB99b() {
    if(document.getElementById("imgSqrs99").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs99").src = "img/sqrs/wSqr.png"
};
};
function sqrsB100b() {
    if(document.getElementById("imgSqrs100").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs100").src = "img/sqrs/wSqr.png"
};
};
function sqrsC101b() {
    if(document.getElementById("imgSqrs101").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs101").src = "img/sqrs/wSqr.png"
};
};
function sqrsC102b() {
    if(document.getElementById("imgSqrs102").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs102").src = "img/sqrs/wSqr.png"
};
};
function sqrsC103b() {
    if(document.getElementById("imgSqrs103").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs103").src = "img/sqrs/wSqr.png"
};
};
function sqrsC104b() {
    if(document.getElementById("imgSqrs104").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs104").src = "img/sqrs/wSqr.png"
};
};
function sqrsC105b() {
    if(document.getElementById("imgSqrs105").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs105").src = "img/sqrs/wSqr.png"
};
};
function sqrsC106b() {
    if(document.getElementById("imgSqrs106").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs106").src = "img/sqrs/wSqr.png"
};
};
function sqrsC107b() {
    if(document.getElementById("imgSqrs107").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs107").src = "img/sqrs/wSqr.png"
};
};
function sqrsC108b() {
    if(document.getElementById("imgSqrs108").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs108").src = "img/sqrs/wSqr.png"
};
};
function sqrsC109b() {
    if(document.getElementById("imgSqrs109").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs109").src = "img/sqrs/wSqr.png"
};
};
function sqrsC110b() {
    if(document.getElementById("imgSqrs110").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs110").src = "img/sqrs/wSqr.png"
};
};
function sqrsC111b() {
    if(document.getElementById("imgSqrs111").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs111").src = "img/sqrs/wSqr.png"
};
};
function sqrsC112b() {
    if(document.getElementById("imgSqrs112").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs112").src = "img/sqrs/wSqr.png"
};
};
function sqrsC113b() {
    if(document.getElementById("imgSqrs113").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs113").src = "img/sqrs/wSqr.png"
};
};
function sqrsC114b() {
    if(document.getElementById("imgSqrs114").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs114").src = "img/sqrs/wSqr.png"
};
};
function sqrsC115b() {
    if(document.getElementById("imgSqrs115").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs115").src = "img/sqrs/wSqr.png"
};
};
function sqrsC116b() {
    if(document.getElementById("imgSqrs116").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs116").src = "img/sqrs/wSqr.png"
};
};
function sqrsC117b() {
    if(document.getElementById("imgSqrs117").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs117").src = "img/sqrs/wSqr.png"
};
};
function sqrsC118b() {
    if(document.getElementById("imgSqrs118").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs118").src = "img/sqrs/wSqr.png"
};
};
function sqrsC119b() {
    if(document.getElementById("imgSqrs119").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs119").src = "img/sqrs/wSqr.png"
};
};
function sqrsC120b() {
    if(document.getElementById("imgSqrs120").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs120").src = "img/sqrs/wSqr.png"
};
};
function sqrsC121b() {
    if(document.getElementById("imgSqrs121").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs121").src = "img/sqrs/wSqr.png"
};
};
function sqrsC122b() {
    if(document.getElementById("imgSqrs122").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs122").src = "img/sqrs/wSqr.png"
};
};
function sqrsC123b() {
    if(document.getElementById("imgSqrs123").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs123").src = "img/sqrs/wSqr.png"
};
};
function sqrsC124b() {
    if(document.getElementById("imgSqrs124").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs124").src = "img/sqrs/wSqr.png"
};
};
function sqrsC125b() {
    if(document.getElementById("imgSqrs125").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs125").src = "img/sqrs/wSqr.png"
};
};
function sqrsC126b() {
    if(document.getElementById("imgSqrs126").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs126").src = "img/sqrs/wSqr.png"
};
};
function sqrsC127b() {
    if(document.getElementById("imgSqrs127").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs127").src = "img/sqrs/wSqr.png"
};
};
function sqrsC128b() {
    if(document.getElementById("imgSqrs128").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs128").src = "img/sqrs/wSqr.png"
};
};
function sqrsC129b() {
    if(document.getElementById("imgSqrs129").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs129").src = "img/sqrs/wSqr.png"
};
};
function sqrsC130b() {
    if(document.getElementById("imgSqrs130").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs130").src = "img/sqrs/wSqr.png"
};
};
function sqrsC131b() {
    if(document.getElementById("imgSqrs131").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs131").src = "img/sqrs/wSqr.png"
};
};
function sqrsC132b() {
    if(document.getElementById("imgSqrs132").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs132").src = "img/sqrs/wSqr.png"
};
};
function sqrsC133b() {
    if(document.getElementById("imgSqrs133").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs133").src = "img/sqrs/wSqr.png"
};
};
function sqrsC134b() {
    if(document.getElementById("imgSqrs134").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs134").src = "img/sqrs/wSqr.png"
};
};
function sqrsC135b() {
    if(document.getElementById("imgSqrs135").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs135").src = "img/sqrs/wSqr.png"
};
};
function sqrsC136b() {
    if(document.getElementById("imgSqrs136").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs136").src = "img/sqrs/wSqr.png"
};
};
function sqrsC137b() {
    if(document.getElementById("imgSqrs137").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs137").src = "img/sqrs/wSqr.png"
};
};
function sqrsC138b() {
    if(document.getElementById("imgSqrs138").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs138").src = "img/sqrs/wSqr.png"
};
};
function sqrsC139b() {
    if(document.getElementById("imgSqrs139").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs139").src = "img/sqrs/wSqr.png"
};
};
function sqrsC140b() {
    if(document.getElementById("imgSqrs140").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs140").src = "img/sqrs/wSqr.png"
};
};
function sqrsC141b() {
    if(document.getElementById("imgSqrs141").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs141").src = "img/sqrs/wSqr.png"
};
};
function sqrsC142b() {
    if(document.getElementById("imgSqrs142").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs142").src = "img/sqrs/wSqr.png"
};
};
function sqrsC143b() {
    if(document.getElementById("imgSqrs143").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs143").src = "img/sqrs/wSqr.png"
};
};
function sqrsC144b() {
    if(document.getElementById("imgSqrs144").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs144").src = "img/sqrs/wSqr.png"
};
};
function sqrsC145b() {
    if(document.getElementById("imgSqrs145").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs145").src = "img/sqrs/wSqr.png"
};
};
function sqrsC146b() {
    if(document.getElementById("imgSqrs146").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs146").src = "img/sqrs/wSqr.png"
};
};
function sqrsC147b() {
    if(document.getElementById("imgSqrs147").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs147").src = "img/sqrs/wSqr.png"
};
};
function sqrsC148b() {
    if(document.getElementById("imgSqrs148").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs148").src = "img/sqrs/wSqr.png"
};
};
function sqrsC149b() {
    if(document.getElementById("imgSqrs149").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs149").src = "img/sqrs/wSqr.png"
};
};
function sqrsC150b() {
    if(document.getElementById("imgSqrs150").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs150").src = "img/sqrs/wSqr.png"
};
};
function sqrsD151b() {
    if(document.getElementById("imgSqrs151").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs151").src = "img/sqrs/wSqr.png"
};
};
function sqrsD152b() {
    if(document.getElementById("imgSqrs152").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs152").src = "img/sqrs/wSqr.png"
};
};
function sqrsD153b() {
    if(document.getElementById("imgSqrs153").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs153").src = "img/sqrs/wSqr.png"
};
};
function sqrsD154b() {
    if(document.getElementById("imgSqrs154").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs154").src = "img/sqrs/wSqr.png"
};
};
function sqrsD155b() {
    if(document.getElementById("imgSqrs155").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs155").src = "img/sqrs/wSqr.png"
};
};
function sqrsD156b() {
    if(document.getElementById("imgSqrs156").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs156").src = "img/sqrs/wSqr.png"
};
};
function sqrsD157b() {
    if(document.getElementById("imgSqrs157").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs157").src = "img/sqrs/wSqr.png"
};
};
function sqrsD158b() {
    if(document.getElementById("imgSqrs158").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs158").src = "img/sqrs/wSqr.png"
};
};
function sqrsD159b() {
    if(document.getElementById("imgSqrs159").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs159").src = "img/sqrs/wSqr.png"
};
};
function sqrsD160b() {
    if(document.getElementById("imgSqrs160").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs160").src = "img/sqrs/wSqr.png"
};
};
function sqrsD161b() {
    if(document.getElementById("imgSqrs161").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs161").src = "img/sqrs/wSqr.png"
};
};
function sqrsD162b() {
    if(document.getElementById("imgSqrs162").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs162").src = "img/sqrs/wSqr.png"
};
};
function sqrsD163b() {
    if(document.getElementById("imgSqrs163").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs163").src = "img/sqrs/wSqr.png"
};
};
function sqrsD164b() {
    if(document.getElementById("imgSqrs164").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs164").src = "img/sqrs/wSqr.png"
};
};
function sqrsD165b() {
    if(document.getElementById("imgSqrs165").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs165").src = "img/sqrs/wSqr.png"
};
};
function sqrsD166b() {
    if(document.getElementById("imgSqrs166").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs166").src = "img/sqrs/wSqr.png"
};
};
function sqrsD167b() {
    if(document.getElementById("imgSqrs167").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs167").src = "img/sqrs/wSqr.png"
};
};
function sqrsD168b() {
    if(document.getElementById("imgSqrs168").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs168").src = "img/sqrs/wSqr.png"
};
};
function sqrsD169b() {
    if(document.getElementById("imgSqrs169").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs169").src = "img/sqrs/wSqr.png"
};
};
function sqrsD170b() {
    if(document.getElementById("imgSqrs170").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs170").src = "img/sqrs/wSqr.png"
};
};
function sqrsD171b() {
    if(document.getElementById("imgSqrs171").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs171").src = "img/sqrs/wSqr.png"
};
};
function sqrsD172b() {
    if(document.getElementById("imgSqrs172").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs172").src = "img/sqrs/wSqr.png"
};
};
function sqrsD173b() {
    if(document.getElementById("imgSqrs173").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs173").src = "img/sqrs/wSqr.png"
};
};
function sqrsD174b() {
    if(document.getElementById("imgSqrs174").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs174").src = "img/sqrs/wSqr.png"
};
};
function sqrsD175b() {
    if(document.getElementById("imgSqrs175").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs175").src = "img/sqrs/wSqr.png"
};
};
function sqrsD176b() {
    if(document.getElementById("imgSqrs176").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs176").src = "img/sqrs/wSqr.png"
};
};
function sqrsD177b() {
    if(document.getElementById("imgSqrs177").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs177").src = "img/sqrs/wSqr.png"
};
};
function sqrsD178b() {
    if(document.getElementById("imgSqrs178").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs178").src = "img/sqrs/wSqr.png"
};
};
function sqrsD179b() {
    if(document.getElementById("imgSqrs179").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs179").src = "img/sqrs/wSqr.png"
};
};
function sqrsD180b() {
    if(document.getElementById("imgSqrs180").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs180").src = "img/sqrs/wSqr.png"
};
};
function sqrsD181b() {
    if(document.getElementById("imgSqrs181").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs181").src = "img/sqrs/wSqr.png"
};
};
function sqrsD182b() {
    if(document.getElementById("imgSqrs182").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs182").src = "img/sqrs/wSqr.png"
};
};
function sqrsD183b() {
    if(document.getElementById("imgSqrs183").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs183").src = "img/sqrs/wSqr.png"
};
};
function sqrsD184b() {
    if(document.getElementById("imgSqrs184").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs184").src = "img/sqrs/wSqr.png"
};
};
function sqrsD185b() {
    if(document.getElementById("imgSqrs185").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs185").src = "img/sqrs/wSqr.png"
};
};
function sqrsD186b() {
    if(document.getElementById("imgSqrs186").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs186").src = "img/sqrs/wSqr.png"
};
};
function sqrsD187b() {
    if(document.getElementById("imgSqrs187").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs187").src = "img/sqrs/wSqr.png"
};
};
function sqrsD188b() {
    if(document.getElementById("imgSqrs188").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs188").src = "img/sqrs/wSqr.png"
};
};
function sqrsD189b() {
    if(document.getElementById("imgSqrs189").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs189").src = "img/sqrs/wSqr.png"
};
};
function sqrsD190b() {
    if(document.getElementById("imgSqrs190").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs190").src = "img/sqrs/wSqr.png"
};
};
function sqrsD191b() {
    if(document.getElementById("imgSqrs191").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs191").src = "img/sqrs/wSqr.png"
};
};
function sqrsD192b() {
    if(document.getElementById("imgSqrs192").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs192").src = "img/sqrs/wSqr.png"
};
};
function sqrsD193b() {
    if(document.getElementById("imgSqrs193").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs193").src = "img/sqrs/wSqr.png"
};
};
function sqrsD194b() {
    if(document.getElementById("imgSqrs194").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs194").src = "img/sqrs/wSqr.png"
};
};
function sqrsD195b() {
    if(document.getElementById("imgSqrs195").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs195").src = "img/sqrs/wSqr.png"
};
};
function sqrsD196b() {
    if(document.getElementById("imgSqrs196").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs196").src = "img/sqrs/wSqr.png"
};
};
function sqrsD197b() {
    if(document.getElementById("imgSqrs197").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs197").src = "img/sqrs/wSqr.png"
};
};
function sqrsD198b() {
    if(document.getElementById("imgSqrs198").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs198").src = "img/sqrs/wSqr.png"
};
};
function sqrsD199b() {
    if(document.getElementById("imgSqrs199").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs199").src = "img/sqrs/wSqr.png"
};
};
function sqrsD200b() {
    if(document.getElementById("imgSqrs200").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs200").src = "img/sqrs/wSqr.png"
};
};
function sqrsE201b() {
    if(document.getElementById("imgSqrs201").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs201").src = "img/sqrs/wSqr.png"
};
};
function sqrsE202b() {
    if(document.getElementById("imgSqrs202").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs202").src = "img/sqrs/wSqr.png"
};
};
function sqrsE203b() {
    if(document.getElementById("imgSqrs203").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs203").src = "img/sqrs/wSqr.png"
};
};
function sqrsE204b() {
    if(document.getElementById("imgSqrs204").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs204").src = "img/sqrs/wSqr.png"
};
};
function sqrsE205b() {
    if(document.getElementById("imgSqrs205").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs205").src = "img/sqrs/wSqr.png"
};
};
function sqrsE206b() {
    if(document.getElementById("imgSqrs206").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs206").src = "img/sqrs/wSqr.png"
};
};
function sqrsE207b() {
    if(document.getElementById("imgSqrs207").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs207").src = "img/sqrs/wSqr.png"
};
};
function sqrsE208b() {
    if(document.getElementById("imgSqrs208").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs208").src = "img/sqrs/wSqr.png"
};
};
function sqrsE209b() {
    if(document.getElementById("imgSqrs209").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs209").src = "img/sqrs/wSqr.png"
};
};
function sqrsE210b() {
    if(document.getElementById("imgSqrs210").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs210").src = "img/sqrs/wSqr.png"
};
};
function sqrsE211b() {
    if(document.getElementById("imgSqrs211").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs211").src = "img/sqrs/wSqr.png"
};
};
function sqrsE212b() {
    if(document.getElementById("imgSqrs212").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs212").src = "img/sqrs/wSqr.png"
};
};
function sqrsE213b() {
    if(document.getElementById("imgSqrs213").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs213").src = "img/sqrs/wSqr.png"
};
};
function sqrsE214b() {
    if(document.getElementById("imgSqrs214").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs214").src = "img/sqrs/wSqr.png"
};
};
function sqrsE215b() {
    if(document.getElementById("imgSqrs215").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs215").src = "img/sqrs/wSqr.png"
};
};
function sqrsE216b() {
    if(document.getElementById("imgSqrs216").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs216").src = "img/sqrs/wSqr.png"
};
};
function sqrsE217b() {
    if(document.getElementById("imgSqrs217").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs217").src = "img/sqrs/wSqr.png"
};
};
function sqrsE218b() {
    if(document.getElementById("imgSqrs218").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs218").src = "img/sqrs/wSqr.png"
};
};
function sqrsE219b() {
    if(document.getElementById("imgSqrs219").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs219").src = "img/sqrs/wSqr.png"
};
};
function sqrsE220b() {
    if(document.getElementById("imgSqrs220").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs220").src = "img/sqrs/wSqr.png"
};
};
function sqrsE221b() {
    if(document.getElementById("imgSqrs221").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs221").src = "img/sqrs/wSqr.png"
};
};
function sqrsE222b() {
    if(document.getElementById("imgSqrs222").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs222").src = "img/sqrs/wSqr.png"
};
};
function sqrsE223b() {
    if(document.getElementById("imgSqrs223").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs223").src = "img/sqrs/wSqr.png"
};
};
function sqrsE224b() {
    if(document.getElementById("imgSqrs224").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs224").src = "img/sqrs/wSqr.png"
};
};
function sqrsE225b() {
    if(document.getElementById("imgSqrs225").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs225").src = "img/sqrs/wSqr.png"
};
};
function sqrsE226b() {
    if(document.getElementById("imgSqrs226").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs226").src = "img/sqrs/wSqr.png"
};
};
function sqrsE227b() {
    if(document.getElementById("imgSqrs227").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs227").src = "img/sqrs/wSqr.png"
};
};
function sqrsE228b() {
    if(document.getElementById("imgSqrs228").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs228").src = "img/sqrs/wSqr.png"
};
};
function sqrsE229b() {
    if(document.getElementById("imgSqrs229").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs229").src = "img/sqrs/wSqr.png"
};
};
function sqrsE230b() {
    if(document.getElementById("imgSqrs230").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs230").src = "img/sqrs/wSqr.png"
};
};
function sqrsE231b() {
    if(document.getElementById("imgSqrs231").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs231").src = "img/sqrs/wSqr.png"
};
};
function sqrsE232b() {
    if(document.getElementById("imgSqrs232").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs232").src = "img/sqrs/wSqr.png"
};
};
function sqrsE233b() {
    if(document.getElementById("imgSqrs233").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs233").src = "img/sqrs/wSqr.png"
};
};
function sqrsE234b() {
    if(document.getElementById("imgSqrs234").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs234").src = "img/sqrs/wSqr.png"
};
};
function sqrsE235b() {
    if(document.getElementById("imgSqrs235").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs235").src = "img/sqrs/wSqr.png"
};
};
function sqrsE236b() {
    if(document.getElementById("imgSqrs236").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs236").src = "img/sqrs/wSqr.png"
};
};
function sqrsE237b() {
    if(document.getElementById("imgSqrs237").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs237").src = "img/sqrs/wSqr.png"
};
};
function sqrsE238b() {
    if(document.getElementById("imgSqrs238").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs238").src = "img/sqrs/wSqr.png"
};
};
function sqrsE239b() {
    if(document.getElementById("imgSqrs239").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs239").src = "img/sqrs/wSqr.png"
};
};
function sqrsE240b() {
    if(document.getElementById("imgSqrs240").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs240").src = "img/sqrs/wSqr.png"
};
};
function sqrsE241b() {
    if(document.getElementById("imgSqrs241").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs241").src = "img/sqrs/wSqr.png"
};
};
function sqrsE242b() {
    if(document.getElementById("imgSqrs242").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs242").src = "img/sqrs/wSqr.png"
};
};
function sqrsE243b() {
    if(document.getElementById("imgSqrs243").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs243").src = "img/sqrs/wSqr.png"
};
};
function sqrsE244b() {
    if(document.getElementById("imgSqrs244").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs244").src = "img/sqrs/wSqr.png"
};
};
function sqrsE245b() {
    if(document.getElementById("imgSqrs245").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs245").src = "img/sqrs/wSqr.png"
};
};
function sqrsE246b() {
    if(document.getElementById("imgSqrs246").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs246").src = "img/sqrs/wSqr.png"
};
};
function sqrsE247b() {
    if(document.getElementById("imgSqrs247").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs247").src = "img/sqrs/wSqr.png"
};
};
function sqrsE248b() {
    if(document.getElementById("imgSqrs248").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs248").src = "img/sqrs/wSqr.png"
};
};
function sqrsE249b() {
    if(document.getElementById("imgSqrs249").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs249").src = "img/sqrs/wSqr.png"
};
};
function sqrsE250b() {
    if(document.getElementById("imgSqrs250").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs250").src = "img/sqrs/wSqr.png"
};
};
function sqrsF251b() {
    if(document.getElementById("imgSqrs251").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs251").src = "img/sqrs/wSqr.png"
};
};
function sqrsF252b() {
    if(document.getElementById("imgSqrs252").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs252").src = "img/sqrs/wSqr.png"
};
};
function sqrsF253b() {
    if(document.getElementById("imgSqrs253").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs253").src = "img/sqrs/wSqr.png"
};
};
function sqrsF254b() {
    if(document.getElementById("imgSqrs254").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs254").src = "img/sqrs/wSqr.png"
};
};
function sqrsF255b() {
    if(document.getElementById("imgSqrs255").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs255").src = "img/sqrs/wSqr.png"
};
};
function sqrsF256b() {
    if(document.getElementById("imgSqrs256").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs256").src = "img/sqrs/wSqr.png"
};
};
function sqrsF257b() {
    if(document.getElementById("imgSqrs257").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs257").src = "img/sqrs/wSqr.png"
};
};
function sqrsF258b() {
    if(document.getElementById("imgSqrs258").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs258").src = "img/sqrs/wSqr.png"
};
};
function sqrsF259b() {
    if(document.getElementById("imgSqrs259").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs259").src = "img/sqrs/wSqr.png"
};
};
function sqrsF260b() {
    if(document.getElementById("imgSqrs260").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs260").src = "img/sqrs/wSqr.png"
};
};
function sqrsF261b() {
    if(document.getElementById("imgSqrs261").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs261").src = "img/sqrs/wSqr.png"
};
};
function sqrsF262b() {
    if(document.getElementById("imgSqrs262").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs262").src = "img/sqrs/wSqr.png"
};
};
function sqrsF263b() {
    if(document.getElementById("imgSqrs263").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs263").src = "img/sqrs/wSqr.png"
};
};
function sqrsF264b() {
    if(document.getElementById("imgSqrs264").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs264").src = "img/sqrs/wSqr.png"
};
};
function sqrsF265b() {
    if(document.getElementById("imgSqrs265").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs265").src = "img/sqrs/wSqr.png"
};
};
function sqrsF266b() {
    if(document.getElementById("imgSqrs266").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs266").src = "img/sqrs/wSqr.png"
};
};
function sqrsF267b() {
    if(document.getElementById("imgSqrs267").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs267").src = "img/sqrs/wSqr.png"
};
};
function sqrsF268b() {
    if(document.getElementById("imgSqrs268").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs268").src = "img/sqrs/wSqr.png"
};
};
function sqrsF269b() {
    if(document.getElementById("imgSqrs269").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs269").src = "img/sqrs/wSqr.png"
};
};
function sqrsF270b() {
    if(document.getElementById("imgSqrs270").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs270").src = "img/sqrs/wSqr.png"
};
};
function sqrsF271b() {
    if(document.getElementById("imgSqrs271").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs271").src = "img/sqrs/wSqr.png"
};
};
function sqrsF272b() {
    if(document.getElementById("imgSqrs272").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs272").src = "img/sqrs/wSqr.png"
};
};
function sqrsF273b() {
    if(document.getElementById("imgSqrs273").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs273").src = "img/sqrs/wSqr.png"
};
};
function sqrsF274b() {
    if(document.getElementById("imgSqrs274").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs274").src = "img/sqrs/wSqr.png"
};
};
function sqrsF275b() {
    if(document.getElementById("imgSqrs275").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs275").src = "img/sqrs/wSqr.png"
};
};
function sqrsF276b() {
    if(document.getElementById("imgSqrs276").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs276").src = "img/sqrs/wSqr.png"
};
};
function sqrsF277b() {
    if(document.getElementById("imgSqrs277").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs277").src = "img/sqrs/wSqr.png"
};
};
function sqrsF278b() {
    if(document.getElementById("imgSqrs278").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs278").src = "img/sqrs/wSqr.png"
};
};
function sqrsF279b() {
    if(document.getElementById("imgSqrs279").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs279").src = "img/sqrs/wSqr.png"
};
};
function sqrsF280b() {
    if(document.getElementById("imgSqrs280").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs280").src = "img/sqrs/wSqr.png"
};
};
function sqrsF281b() {
    if(document.getElementById("imgSqrs281").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs281").src = "img/sqrs/wSqr.png"
};
};
function sqrsF282b() {
    if(document.getElementById("imgSqrs282").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs282").src = "img/sqrs/wSqr.png"
};
};
function sqrsF283b() {
    if(document.getElementById("imgSqrs283").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs283").src = "img/sqrs/wSqr.png"
};
};
function sqrsF284b() {
    if(document.getElementById("imgSqrs284").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs284").src = "img/sqrs/wSqr.png"
};
};
function sqrsF285b() {
    if(document.getElementById("imgSqrs285").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs285").src = "img/sqrs/wSqr.png"
};
};
function sqrsF286b() {
    if(document.getElementById("imgSqrs286").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs286").src = "img/sqrs/wSqr.png"
};
};
function sqrsF287b() {
    if(document.getElementById("imgSqrs287").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs287").src = "img/sqrs/wSqr.png"
};
};
function sqrsF288b() {
    if(document.getElementById("imgSqrs288").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs288").src = "img/sqrs/wSqr.png"
};
};
function sqrsF289b() {
    if(document.getElementById("imgSqrs289").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs289").src = "img/sqrs/wSqr.png"
};
};
function sqrsF290b() {
    if(document.getElementById("imgSqrs290").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs290").src = "img/sqrs/wSqr.png"
};
};
function sqrsF291b() {
    if(document.getElementById("imgSqrs291").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs291").src = "img/sqrs/wSqr.png"
};
};
function sqrsF292b() {
    if(document.getElementById("imgSqrs292").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs292").src = "img/sqrs/wSqr.png"
};
};
function sqrsF293b() {
    if(document.getElementById("imgSqrs293").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs293").src = "img/sqrs/wSqr.png"
};
};
function sqrsF294b() {
    if(document.getElementById("imgSqrs294").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs294").src = "img/sqrs/wSqr.png"
};
};
function sqrsF295b() {
    if(document.getElementById("imgSqrs295").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs295").src = "img/sqrs/wSqr.png"
};
};
function sqrsF296b() {
    if(document.getElementById("imgSqrs296").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs296").src = "img/sqrs/wSqr.png"
};
};
function sqrsF297b() {
    if(document.getElementById("imgSqrs297").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs297").src = "img/sqrs/wSqr.png"
};
};
function sqrsF298b() {
    if(document.getElementById("imgSqrs298").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs298").src = "img/sqrs/wSqr.png"
};
};
function sqrsF299b() {
    if(document.getElementById("imgSqrs299").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs299").src = "img/sqrs/wSqr.png"
};
};
function sqrsF300b() {
    if(document.getElementById("imgSqrs300").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs300").src = "img/sqrs/wSqr.png"
};
};
function sqrsG301b() {
    if(document.getElementById("imgSqrs301").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs301").src = "img/sqrs/wSqr.png"
};
};
function sqrsG302b() {
    if(document.getElementById("imgSqrs302").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs302").src = "img/sqrs/wSqr.png"
};
};
function sqrsG303b() {
    if(document.getElementById("imgSqrs303").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs303").src = "img/sqrs/wSqr.png"
};
};
function sqrsG304b() {
    if(document.getElementById("imgSqrs304").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs304").src = "img/sqrs/wSqr.png"
};
};
function sqrsG305b() {
    if(document.getElementById("imgSqrs305").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs305").src = "img/sqrs/wSqr.png"
};
};
function sqrsG306b() {
    if(document.getElementById("imgSqrs306").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs306").src = "img/sqrs/wSqr.png"
};
};
function sqrsG307b() {
    if(document.getElementById("imgSqrs307").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs307").src = "img/sqrs/wSqr.png"
};
};
function sqrsG308b() {
    if(document.getElementById("imgSqrs308").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs308").src = "img/sqrs/wSqr.png"
};
};
function sqrsG309b() {
    if(document.getElementById("imgSqrs309").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs309").src = "img/sqrs/wSqr.png"
};
};
function sqrsG310b() {
    if(document.getElementById("imgSqrs310").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs310").src = "img/sqrs/wSqr.png"
};
};
function sqrsG311b() {
    if(document.getElementById("imgSqrs311").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs311").src = "img/sqrs/wSqr.png"
};
};
function sqrsG312b() {
    if(document.getElementById("imgSqrs312").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs312").src = "img/sqrs/wSqr.png"
};
};
function sqrsG313b() {
    if(document.getElementById("imgSqrs313").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs313").src = "img/sqrs/wSqr.png"
};
};
function sqrsG314b() {
    if(document.getElementById("imgSqrs314").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs314").src = "img/sqrs/wSqr.png"
};
};
function sqrsG315b() {
    if(document.getElementById("imgSqrs315").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs315").src = "img/sqrs/wSqr.png"
};
};
function sqrsG316b() {
    if(document.getElementById("imgSqrs316").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs316").src = "img/sqrs/wSqr.png"
};
};
function sqrsG317b() {
    if(document.getElementById("imgSqrs317").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs317").src = "img/sqrs/wSqr.png"
};
};
function sqrsG318b() {
    if(document.getElementById("imgSqrs318").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs318").src = "img/sqrs/wSqr.png"
};
};
function sqrsG319b() {
    if(document.getElementById("imgSqrs319").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs319").src = "img/sqrs/wSqr.png"
};
};
function sqrsG320b() {
    if(document.getElementById("imgSqrs320").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs320").src = "img/sqrs/wSqr.png"
};
};
function sqrsG321b() {
    if(document.getElementById("imgSqrs321").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs321").src = "img/sqrs/wSqr.png"
};
};
function sqrsG322b() {
    if(document.getElementById("imgSqrs322").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs322").src = "img/sqrs/wSqr.png"
};
};
function sqrsG323b() {
    if(document.getElementById("imgSqrs323").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs323").src = "img/sqrs/wSqr.png"
};
};
function sqrsG324b() {
    if(document.getElementById("imgSqrs324").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs324").src = "img/sqrs/wSqr.png"
};
};
function sqrsG325b() {
    if(document.getElementById("imgSqrs325").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs325").src = "img/sqrs/wSqr.png"
};
};
function sqrsG326b() {
    if(document.getElementById("imgSqrs326").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs326").src = "img/sqrs/wSqr.png"
};
};
function sqrsG327b() {
    if(document.getElementById("imgSqrs327").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs327").src = "img/sqrs/wSqr.png"
};
};
function sqrsG328b() {
    if(document.getElementById("imgSqrs328").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs328").src = "img/sqrs/wSqr.png"
};
};
function sqrsG329b() {
    if(document.getElementById("imgSqrs329").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs329").src = "img/sqrs/wSqr.png"
};
};
function sqrsG330b() {
    if(document.getElementById("imgSqrs330").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs330").src = "img/sqrs/wSqr.png"
};
};
function sqrsG331b() {
    if(document.getElementById("imgSqrs331").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs331").src = "img/sqrs/wSqr.png"
};
};
function sqrsG332b() {
    if(document.getElementById("imgSqrs332").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs332").src = "img/sqrs/wSqr.png"
};
};
function sqrsG333b() {
    if(document.getElementById("imgSqrs333").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs333").src = "img/sqrs/wSqr.png"
};
};
function sqrsG334b() {
    if(document.getElementById("imgSqrs334").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs334").src = "img/sqrs/wSqr.png"
};
};
function sqrsG335b() {
    if(document.getElementById("imgSqrs335").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs335").src = "img/sqrs/wSqr.png"
};
};
function sqrsG336b() {
    if(document.getElementById("imgSqrs336").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs336").src = "img/sqrs/wSqr.png"
};
};
function sqrsG337b() {
    if(document.getElementById("imgSqrs337").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs337").src = "img/sqrs/wSqr.png"
};
};
function sqrsG338b() {
    if(document.getElementById("imgSqrs338").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs338").src = "img/sqrs/wSqr.png"
};
};
function sqrsG339b() {
    if(document.getElementById("imgSqrs339").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs339").src = "img/sqrs/wSqr.png"
};
};
function sqrsG340b() {
    if(document.getElementById("imgSqrs340").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs340").src = "img/sqrs/wSqr.png"
};
};
function sqrsG341b() {
    if(document.getElementById("imgSqrs341").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs341").src = "img/sqrs/wSqr.png"
};
};
function sqrsG342b() {
    if(document.getElementById("imgSqrs342").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs342").src = "img/sqrs/wSqr.png"
};
};
function sqrsG343b() {
    if(document.getElementById("imgSqrs343").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs343").src = "img/sqrs/wSqr.png"
};
};
function sqrsG344b() {
    if(document.getElementById("imgSqrs344").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs344").src = "img/sqrs/wSqr.png"
};
};
function sqrsG345b() {
    if(document.getElementById("imgSqrs345").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs345").src = "img/sqrs/wSqr.png"
};
};
function sqrsG346b() {
    if(document.getElementById("imgSqrs346").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs346").src = "img/sqrs/wSqr.png"
};
};
function sqrsG347b() {
    if(document.getElementById("imgSqrs347").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs347").src = "img/sqrs/wSqr.png"
};
};
function sqrsG348b() {
    if(document.getElementById("imgSqrs348").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs348").src = "img/sqrs/wSqr.png"
};
};
function sqrsG349b() {
    if(document.getElementById("imgSqrs349").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs349").src = "img/sqrs/wSqr.png"
};
};
function sqrsG350b() {
    if(document.getElementById("imgSqrs350").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs350").src = "img/sqrs/wSqr.png"
};
};
function sqrsH351b() {
    if(document.getElementById("imgSqrs351").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs351").src = "img/sqrs/wSqr.png"
};
};
function sqrsH352b() {
    if(document.getElementById("imgSqrs352").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs352").src = "img/sqrs/wSqr.png"
};
};
function sqrsH353b() {
    if(document.getElementById("imgSqrs353").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs353").src = "img/sqrs/wSqr.png"
};
};
function sqrsH354b() {
    if(document.getElementById("imgSqrs354").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs354").src = "img/sqrs/wSqr.png"
};
};
function sqrsH355b() {
    if(document.getElementById("imgSqrs355").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs355").src = "img/sqrs/wSqr.png"
};
};
function sqrsH356b() {
    if(document.getElementById("imgSqrs356").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs356").src = "img/sqrs/wSqr.png"
};
};
function sqrsH357b() {
    if(document.getElementById("imgSqrs357").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs357").src = "img/sqrs/wSqr.png"
};
};
function sqrsH358b() {
    if(document.getElementById("imgSqrs358").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs358").src = "img/sqrs/wSqr.png"
};
};
function sqrsH359b() {
    if(document.getElementById("imgSqrs359").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs359").src = "img/sqrs/wSqr.png"
};
};
function sqrsH360b() {
    if(document.getElementById("imgSqrs360").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs360").src = "img/sqrs/wSqr.png"
};
};
function sqrsH361b() {
    if(document.getElementById("imgSqrs361").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs361").src = "img/sqrs/wSqr.png"
};
};
function sqrsH362b() {
    if(document.getElementById("imgSqrs362").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs362").src = "img/sqrs/wSqr.png"
};
};
function sqrsH363b() {
    if(document.getElementById("imgSqrs363").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs363").src = "img/sqrs/wSqr.png"
};
};
function sqrsH364b() {
    if(document.getElementById("imgSqrs364").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs364").src = "img/sqrs/wSqr.png"
};
};
function sqrsH365b() {
    if(document.getElementById("imgSqrs365").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs365").src = "img/sqrs/wSqr.png"
};
};
function sqrsH366b() {
    if(document.getElementById("imgSqrs366").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs366").src = "img/sqrs/wSqr.png"
};
};
function sqrsH367b() {
    if(document.getElementById("imgSqrs367").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs367").src = "img/sqrs/wSqr.png"
};
};
function sqrsH368b() {
    if(document.getElementById("imgSqrs368").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs368").src = "img/sqrs/wSqr.png"
};
};
function sqrsH369b() {
    if(document.getElementById("imgSqrs369").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs369").src = "img/sqrs/wSqr.png"
};
};
function sqrsH370b() {
    if(document.getElementById("imgSqrs370").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs370").src = "img/sqrs/wSqr.png"
};
};
function sqrsH371b() {
    if(document.getElementById("imgSqrs371").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs371").src = "img/sqrs/wSqr.png"
};
};
function sqrsH372b() {
    if(document.getElementById("imgSqrs372").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs372").src = "img/sqrs/wSqr.png"
};
};
function sqrsH373b() {
    if(document.getElementById("imgSqrs373").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs373").src = "img/sqrs/wSqr.png"
};
};
function sqrsH374b() {
    if(document.getElementById("imgSqrs374").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs374").src = "img/sqrs/wSqr.png"
};
};
function sqrsH375b() {
    if(document.getElementById("imgSqrs375").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs375").src = "img/sqrs/wSqr.png"
};
};
function sqrsH376b() {
    if(document.getElementById("imgSqrs376").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs376").src = "img/sqrs/wSqr.png"
};
};
function sqrsH377b() {
    if(document.getElementById("imgSqrs377").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs377").src = "img/sqrs/wSqr.png"
};
};
function sqrsH378b() {
    if(document.getElementById("imgSqrs378").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs378").src = "img/sqrs/wSqr.png"
};
};
function sqrsH379b() {
    if(document.getElementById("imgSqrs379").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs379").src = "img/sqrs/wSqr.png"
};
};
function sqrsH380b() {
    if(document.getElementById("imgSqrs380").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs380").src = "img/sqrs/wSqr.png"
};
};
function sqrsH381b() {
    if(document.getElementById("imgSqrs381").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs381").src = "img/sqrs/wSqr.png"
};
};
function sqrsH382b() {
    if(document.getElementById("imgSqrs382").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs382").src = "img/sqrs/wSqr.png"
};
};
function sqrsH383b() {
    if(document.getElementById("imgSqrs383").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs383").src = "img/sqrs/wSqr.png"
};
};
function sqrsH384b() {
    if(document.getElementById("imgSqrs384").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs384").src = "img/sqrs/wSqr.png"
};
};
function sqrsH385b() {
    if(document.getElementById("imgSqrs385").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs385").src = "img/sqrs/wSqr.png"
};
};
function sqrsH386b() {
    if(document.getElementById("imgSqrs386").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs386").src = "img/sqrs/wSqr.png"
};
};
function sqrsH387b() {
    if(document.getElementById("imgSqrs387").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs387").src = "img/sqrs/wSqr.png"
};
};
function sqrsH388b() {
    if(document.getElementById("imgSqrs388").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs388").src = "img/sqrs/wSqr.png"
};
};
function sqrsH389b() {
    if(document.getElementById("imgSqrs389").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs389").src = "img/sqrs/wSqr.png"
};
};
function sqrsH390b() {
    if(document.getElementById("imgSqrs390").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs390").src = "img/sqrs/wSqr.png"
};
};
function sqrsH391b() {
    if(document.getElementById("imgSqrs391").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs391").src = "img/sqrs/wSqr.png"
};
};
function sqrsH392b() {
    if(document.getElementById("imgSqrs392").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs392").src = "img/sqrs/wSqr.png"
};
};
function sqrsH393b() {
    if(document.getElementById("imgSqrs393").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs393").src = "img/sqrs/wSqr.png"
};
};
function sqrsH394b() {
    if(document.getElementById("imgSqrs394").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs394").src = "img/sqrs/wSqr.png"
};
};
function sqrsH395b() {
    if(document.getElementById("imgSqrs395").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs395").src = "img/sqrs/wSqr.png"
};
};
function sqrsH396b() {
    if(document.getElementById("imgSqrs396").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs396").src = "img/sqrs/wSqr.png"
};
};
function sqrsH397b() {
    if(document.getElementById("imgSqrs397").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs397").src = "img/sqrs/wSqr.png"
};
};
function sqrsH398b() {
    if(document.getElementById("imgSqrs398").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs398").src = "img/sqrs/wSqr.png"
};
};
function sqrsH399b() {
    if(document.getElementById("imgSqrs399").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs399").src = "img/sqrs/wSqr.png"
};
};
function sqrsH400b() {
    if(document.getElementById("imgSqrs400").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs400").src = "img/sqrs/wSqr.png"
};
};
function sqrsI401b() {
    if(document.getElementById("imgSqrs401").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs401").src = "img/sqrs/wSqr.png"
};
};
function sqrsI402b() {
    if(document.getElementById("imgSqrs402").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs402").src = "img/sqrs/wSqr.png"
};
};
function sqrsI403b() {
    if(document.getElementById("imgSqrs403").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs403").src = "img/sqrs/wSqr.png"
};
};
function sqrsI404b() {
    if(document.getElementById("imgSqrs404").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs404").src = "img/sqrs/wSqr.png"
};
};
function sqrsI405b() {
    if(document.getElementById("imgSqrs405").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs405").src = "img/sqrs/wSqr.png"
};
};
function sqrsI406b() {
    if(document.getElementById("imgSqrs406").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs406").src = "img/sqrs/wSqr.png"
};
};
function sqrsI407b() {
    if(document.getElementById("imgSqrs407").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs407").src = "img/sqrs/wSqr.png"
};
};
function sqrsI408b() {
    if(document.getElementById("imgSqrs408").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs408").src = "img/sqrs/wSqr.png"
};
};
function sqrsI409b() {
    if(document.getElementById("imgSqrs409").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs409").src = "img/sqrs/wSqr.png"
};
};
function sqrsI410b() {
    if(document.getElementById("imgSqrs410").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs410").src = "img/sqrs/wSqr.png"
};
};
function sqrsI411b() {
    if(document.getElementById("imgSqrs411").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs411").src = "img/sqrs/wSqr.png"
};
};
function sqrsI412b() {
    if(document.getElementById("imgSqrs412").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs412").src = "img/sqrs/wSqr.png"
};
};
function sqrsI413b() {
    if(document.getElementById("imgSqrs413").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs413").src = "img/sqrs/wSqr.png"
};
};
function sqrsI414b() {
    if(document.getElementById("imgSqrs414").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs414").src = "img/sqrs/wSqr.png"
};
};
function sqrsI415b() {
    if(document.getElementById("imgSqrs415").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs415").src = "img/sqrs/wSqr.png"
};
};
function sqrsI416b() {
    if(document.getElementById("imgSqrs416").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs416").src = "img/sqrs/wSqr.png"
};
};
function sqrsI417b() {
    if(document.getElementById("imgSqrs417").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs417").src = "img/sqrs/wSqr.png"
};
};
function sqrsI418b() {
    if(document.getElementById("imgSqrs418").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs418").src = "img/sqrs/wSqr.png"
};
};
function sqrsI419b() {
    if(document.getElementById("imgSqrs419").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs419").src = "img/sqrs/wSqr.png"
};
};
function sqrsI420b() {
    if(document.getElementById("imgSqrs420").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs420").src = "img/sqrs/wSqr.png"
};
};
function sqrsI421b() {
    if(document.getElementById("imgSqrs421").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs421").src = "img/sqrs/wSqr.png"
};
};
function sqrsI422b() {
    if(document.getElementById("imgSqrs422").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs422").src = "img/sqrs/wSqr.png"
};
};
function sqrsI423b() {
    if(document.getElementById("imgSqrs423").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs423").src = "img/sqrs/wSqr.png"
};
};
function sqrsI424b() {
    if(document.getElementById("imgSqrs424").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs424").src = "img/sqrs/wSqr.png"
};
};
function sqrsI425b() {
    if(document.getElementById("imgSqrs425").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs425").src = "img/sqrs/wSqr.png"
};
};
function sqrsI426b() {
    if(document.getElementById("imgSqrs426").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs426").src = "img/sqrs/wSqr.png"
};
};
function sqrsI427b() {
    if(document.getElementById("imgSqrs427").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs427").src = "img/sqrs/wSqr.png"
};
};
function sqrsI428b() {
    if(document.getElementById("imgSqrs428").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs428").src = "img/sqrs/wSqr.png"
};
};
function sqrsI429b() {
    if(document.getElementById("imgSqrs429").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs429").src = "img/sqrs/wSqr.png"
};
};
function sqrsI430b() {
    if(document.getElementById("imgSqrs430").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs430").src = "img/sqrs/wSqr.png"
};
};
function sqrsI431b() {
    if(document.getElementById("imgSqrs431").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs431").src = "img/sqrs/wSqr.png"
};
};
function sqrsI432b() {
    if(document.getElementById("imgSqrs432").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs432").src = "img/sqrs/wSqr.png"
};
};
function sqrsI433b() {
    if(document.getElementById("imgSqrs433").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs433").src = "img/sqrs/wSqr.png"
};
};
function sqrsI434b() {
    if(document.getElementById("imgSqrs434").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs434").src = "img/sqrs/wSqr.png"
};
};
function sqrsI435b() {
    if(document.getElementById("imgSqrs435").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs435").src = "img/sqrs/wSqr.png"
};
};
function sqrsI436b() {
    if(document.getElementById("imgSqrs436").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs436").src = "img/sqrs/wSqr.png"
};
};
function sqrsI437b() {
    if(document.getElementById("imgSqrs437").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs437").src = "img/sqrs/wSqr.png"
};
};
function sqrsI438b() {
    if(document.getElementById("imgSqrs438").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs438").src = "img/sqrs/wSqr.png"
};
};
function sqrsI439b() {
    if(document.getElementById("imgSqrs439").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs439").src = "img/sqrs/wSqr.png"
};
};
function sqrsI440b() {
    if(document.getElementById("imgSqrs440").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs440").src = "img/sqrs/wSqr.png"
};
};
function sqrsI441b() {
    if(document.getElementById("imgSqrs441").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs441").src = "img/sqrs/wSqr.png"
};
};
function sqrsI442b() {
    if(document.getElementById("imgSqrs442").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs442").src = "img/sqrs/wSqr.png"
};
};
function sqrsI443b() {
    if(document.getElementById("imgSqrs443").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs443").src = "img/sqrs/wSqr.png"
};
};
function sqrsI444b() {
    if(document.getElementById("imgSqrs444").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs444").src = "img/sqrs/wSqr.png"
};
};
function sqrsI445b() {
    if(document.getElementById("imgSqrs445").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs445").src = "img/sqrs/wSqr.png"
};
};
function sqrsI446b() {
    if(document.getElementById("imgSqrs446").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs446").src = "img/sqrs/wSqr.png"
};
};
function sqrsI447b() {
    if(document.getElementById("imgSqrs447").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs447").src = "img/sqrs/wSqr.png"
};
};
function sqrsI448b() {
    if(document.getElementById("imgSqrs448").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs448").src = "img/sqrs/wSqr.png"
};
};
function sqrsI449b() {
    if(document.getElementById("imgSqrs449").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs449").src = "img/sqrs/wSqr.png"
};
};
function sqrsI450b() {
    if(document.getElementById("imgSqrs450").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs450").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ451b() {
    if(document.getElementById("imgSqrs451").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs451").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ452b() {
    if(document.getElementById("imgSqrs452").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs452").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ453b() {
    if(document.getElementById("imgSqrs453").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs453").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ454b() {
    if(document.getElementById("imgSqrs454").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs454").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ455b() {
    if(document.getElementById("imgSqrs455").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs455").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ456b() {
    if(document.getElementById("imgSqrs456").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs456").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ457b() {
    if(document.getElementById("imgSqrs457").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs457").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ458b() {
    if(document.getElementById("imgSqrs458").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs458").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ459b() {
    if(document.getElementById("imgSqrs459").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs459").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ460b() {
    if(document.getElementById("imgSqrs460").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs460").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ461b() {
    if(document.getElementById("imgSqrs461").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs461").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ462b() {
    if(document.getElementById("imgSqrs462").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs462").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ463b() {
    if(document.getElementById("imgSqrs463").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs463").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ464b() {
    if(document.getElementById("imgSqrs464").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs464").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ465b() {
    if(document.getElementById("imgSqrs465").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs465").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ466b() {
    if(document.getElementById("imgSqrs466").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs466").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ467b() {
    if(document.getElementById("imgSqrs467").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs467").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ468b() {
    if(document.getElementById("imgSqrs468").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs468").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ469b() {
    if(document.getElementById("imgSqrs469").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs469").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ470b() {
    if(document.getElementById("imgSqrs470").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs470").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ471b() {
    if(document.getElementById("imgSqrs471").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs471").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ472b() {
    if(document.getElementById("imgSqrs472").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs472").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ473b() {
    if(document.getElementById("imgSqrs473").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs473").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ474b() {
    if(document.getElementById("imgSqrs474").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs474").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ475b() {
    if(document.getElementById("imgSqrs475").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs475").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ476b() {
    if(document.getElementById("imgSqrs476").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs476").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ477b() {
    if(document.getElementById("imgSqrs477").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs477").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ478b() {
    if(document.getElementById("imgSqrs478").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs478").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ479b() {
    if(document.getElementById("imgSqrs479").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs479").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ480b() {
    if(document.getElementById("imgSqrs480").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs480").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ481b() {
    if(document.getElementById("imgSqrs481").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs481").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ482b() {
    if(document.getElementById("imgSqrs482").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs482").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ483b() {
    if(document.getElementById("imgSqrs483").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs483").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ484b() {
    if(document.getElementById("imgSqrs484").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs484").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ485b() {
    if(document.getElementById("imgSqrs485").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs485").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ486b() {
    if(document.getElementById("imgSqrs486").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs486").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ487b() {
    if(document.getElementById("imgSqrs487").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs487").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ488b() {
    if(document.getElementById("imgSqrs488").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs488").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ489b() {
    if(document.getElementById("imgSqrs489").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs489").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ490b() {
    if(document.getElementById("imgSqrs490").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs490").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ491b() {
    if(document.getElementById("imgSqrs491").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs491").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ492b() {
    if(document.getElementById("imgSqrs492").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs492").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ493b() {
    if(document.getElementById("imgSqrs493").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs493").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ494b() {
    if(document.getElementById("imgSqrs494").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs494").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ495b() {
    if(document.getElementById("imgSqrs495").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs495").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ496b() {
    if(document.getElementById("imgSqrs496").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs496").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ497b() {
    if(document.getElementById("imgSqrs497").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs497").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ498b() {
    if(document.getElementById("imgSqrs498").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs498").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ499b() {
    if(document.getElementById("imgSqrs499").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs499").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ500b() {
    if(document.getElementById("imgSqrs500").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs500").src = "img/sqrs/wSqr.png"
};
};
function sqrsK501b() {
    if(document.getElementById("imgSqrs501").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs501").src = "img/sqrs/wSqr.png"
};
};
function sqrsK502b() {
    if(document.getElementById("imgSqrs502").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs502").src = "img/sqrs/wSqr.png"
};
};
function sqrsK503b() {
    if(document.getElementById("imgSqrs503").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs503").src = "img/sqrs/wSqr.png"
};
};
function sqrsK504b() {
    if(document.getElementById("imgSqrs504").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs504").src = "img/sqrs/wSqr.png"
};
};
function sqrsK505b() {
    if(document.getElementById("imgSqrs505").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs505").src = "img/sqrs/wSqr.png"
};
};
function sqrsK506b() {
    if(document.getElementById("imgSqrs506").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs506").src = "img/sqrs/wSqr.png"
};
};
function sqrsK507b() {
    if(document.getElementById("imgSqrs507").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs507").src = "img/sqrs/wSqr.png"
};
};
function sqrsK508b() {
    if(document.getElementById("imgSqrs508").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs508").src = "img/sqrs/wSqr.png"
};
};
function sqrsK509b() {
    if(document.getElementById("imgSqrs509").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs509").src = "img/sqrs/wSqr.png"
};
};
function sqrsK510b() {
    if(document.getElementById("imgSqrs510").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs510").src = "img/sqrs/wSqr.png"
};
};
function sqrsK511b() {
    if(document.getElementById("imgSqrs511").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs511").src = "img/sqrs/wSqr.png"
};
};
function sqrsK512b() {
    if(document.getElementById("imgSqrs512").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs512").src = "img/sqrs/wSqr.png"
};
};
function sqrsK513b() {
    if(document.getElementById("imgSqrs513").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs513").src = "img/sqrs/wSqr.png"
};
};
function sqrsK514b() {
    if(document.getElementById("imgSqrs514").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs514").src = "img/sqrs/wSqr.png"
};
};
function sqrsK515b() {
    if(document.getElementById("imgSqrs515").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs515").src = "img/sqrs/wSqr.png"
};
};
function sqrsK516b() {
    if(document.getElementById("imgSqrs516").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs516").src = "img/sqrs/wSqr.png"
};
};
function sqrsK517b() {
    if(document.getElementById("imgSqrs517").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs517").src = "img/sqrs/wSqr.png"
};
};
function sqrsK518b() {
    if(document.getElementById("imgSqrs518").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs518").src = "img/sqrs/wSqr.png"
};
};
function sqrsK519b() {
    if(document.getElementById("imgSqrs519").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs519").src = "img/sqrs/wSqr.png"
};
};
function sqrsK520b() {
    if(document.getElementById("imgSqrs520").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs520").src = "img/sqrs/wSqr.png"
};
};
function sqrsK521b() {
    if(document.getElementById("imgSqrs521").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs521").src = "img/sqrs/wSqr.png"
};
};
function sqrsK522b() {
    if(document.getElementById("imgSqrs522").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs522").src = "img/sqrs/wSqr.png"
};
};
function sqrsK523b() {
    if(document.getElementById("imgSqrs523").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs523").src = "img/sqrs/wSqr.png"
};
};
function sqrsK524b() {
    if(document.getElementById("imgSqrs524").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs524").src = "img/sqrs/wSqr.png"
};
};
function sqrsK525b() {
    if(document.getElementById("imgSqrs525").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs525").src = "img/sqrs/wSqr.png"
};
};
function sqrsK526b() {
    if(document.getElementById("imgSqrs526").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs526").src = "img/sqrs/wSqr.png"
};
};
function sqrsK527b() {
    if(document.getElementById("imgSqrs527").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs527").src = "img/sqrs/wSqr.png"
};
};
function sqrsK528b() {
    if(document.getElementById("imgSqrs528").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs528").src = "img/sqrs/wSqr.png"
};
};
function sqrsK529b() {
    if(document.getElementById("imgSqrs529").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs529").src = "img/sqrs/wSqr.png"
};
};
function sqrsK530b() {
    if(document.getElementById("imgSqrs530").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs530").src = "img/sqrs/wSqr.png"
};
};
function sqrsK531b() {
    if(document.getElementById("imgSqrs531").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs531").src = "img/sqrs/wSqr.png"
};
};
function sqrsK532b() {
    if(document.getElementById("imgSqrs532").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs532").src = "img/sqrs/wSqr.png"
};
};
function sqrsK533b() {
    if(document.getElementById("imgSqrs533").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs533").src = "img/sqrs/wSqr.png"
};
};
function sqrsK534b() {
    if(document.getElementById("imgSqrs534").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs534").src = "img/sqrs/wSqr.png"
};
};
function sqrsK535b() {
    if(document.getElementById("imgSqrs535").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs535").src = "img/sqrs/wSqr.png"
};
};
function sqrsK536b() {
    if(document.getElementById("imgSqrs536").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs536").src = "img/sqrs/wSqr.png"
};
};
function sqrsK537b() {
    if(document.getElementById("imgSqrs537").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs537").src = "img/sqrs/wSqr.png"
};
};
function sqrsK538b() {
    if(document.getElementById("imgSqrs538").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs538").src = "img/sqrs/wSqr.png"
};
};
function sqrsK539b() {
    if(document.getElementById("imgSqrs539").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs539").src = "img/sqrs/wSqr.png"
};
};
function sqrsK540b() {
    if(document.getElementById("imgSqrs540").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs540").src = "img/sqrs/wSqr.png"
};
};
function sqrsK541b() {
    if(document.getElementById("imgSqrs541").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs541").src = "img/sqrs/wSqr.png"
};
};
function sqrsK542b() {
    if(document.getElementById("imgSqrs542").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs542").src = "img/sqrs/wSqr.png"
};
};
function sqrsK543b() {
    if(document.getElementById("imgSqrs543").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs543").src = "img/sqrs/wSqr.png"
};
};
function sqrsK544b() {
    if(document.getElementById("imgSqrs544").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs544").src = "img/sqrs/wSqr.png"
};
};
function sqrsK545b() {
    if(document.getElementById("imgSqrs545").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs545").src = "img/sqrs/wSqr.png"
};
};
function sqrsK546b() {
    if(document.getElementById("imgSqrs546").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs546").src = "img/sqrs/wSqr.png"
};
};
function sqrsK547b() {
    if(document.getElementById("imgSqrs547").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs547").src = "img/sqrs/wSqr.png"
};
};
function sqrsK548b() {
    if(document.getElementById("imgSqrs548").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs548").src = "img/sqrs/wSqr.png"
};
};
function sqrsK549b() {
    if(document.getElementById("imgSqrs549").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs549").src = "img/sqrs/wSqr.png"
};
};
function sqrsK550b() {
    if(document.getElementById("imgSqrs550").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs550").src = "img/sqrs/wSqr.png"
};
};
function sqrsL551b() {
    if(document.getElementById("imgSqrs551").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs551").src = "img/sqrs/wSqr.png"
};
};
function sqrsL552b() {
    if(document.getElementById("imgSqrs552").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs552").src = "img/sqrs/wSqr.png"
};
};
function sqrsL553b() {
    if(document.getElementById("imgSqrs553").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs553").src = "img/sqrs/wSqr.png"
};
};
function sqrsL554b() {
    if(document.getElementById("imgSqrs554").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs554").src = "img/sqrs/wSqr.png"
};
};
function sqrsL555b() {
    if(document.getElementById("imgSqrs555").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs555").src = "img/sqrs/wSqr.png"
};
};
function sqrsL556b() {
    if(document.getElementById("imgSqrs556").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs556").src = "img/sqrs/wSqr.png"
};
};
function sqrsL557b() {
    if(document.getElementById("imgSqrs557").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs557").src = "img/sqrs/wSqr.png"
};
};
function sqrsL558b() {
    if(document.getElementById("imgSqrs558").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs558").src = "img/sqrs/wSqr.png"
};
};
function sqrsL559b() {
    if(document.getElementById("imgSqrs559").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs559").src = "img/sqrs/wSqr.png"
};
};
function sqrsL560b() {
    if(document.getElementById("imgSqrs560").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs560").src = "img/sqrs/wSqr.png"
};
};
function sqrsL561b() {
    if(document.getElementById("imgSqrs561").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs561").src = "img/sqrs/wSqr.png"
};
};
function sqrsL562b() {
    if(document.getElementById("imgSqrs562").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs562").src = "img/sqrs/wSqr.png"
};
};
function sqrsL563b() {
    if(document.getElementById("imgSqrs563").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs563").src = "img/sqrs/wSqr.png"
};
};
function sqrsL564b() {
    if(document.getElementById("imgSqrs564").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs564").src = "img/sqrs/wSqr.png"
};
};
function sqrsL565b() {
    if(document.getElementById("imgSqrs565").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs565").src = "img/sqrs/wSqr.png"
};
};
function sqrsL566b() {
    if(document.getElementById("imgSqrs566").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs566").src = "img/sqrs/wSqr.png"
};
};
function sqrsL567b() {
    if(document.getElementById("imgSqrs567").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs567").src = "img/sqrs/wSqr.png"
};
};
function sqrsL568b() {
    if(document.getElementById("imgSqrs568").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs568").src = "img/sqrs/wSqr.png"
};
};
function sqrsL569b() {
    if(document.getElementById("imgSqrs569").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs569").src = "img/sqrs/wSqr.png"
};
};
function sqrsL570b() {
    if(document.getElementById("imgSqrs570").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs570").src = "img/sqrs/wSqr.png"
};
};
function sqrsL571b() {
    if(document.getElementById("imgSqrs571").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs571").src = "img/sqrs/wSqr.png"
};
};
function sqrsL572b() {
    if(document.getElementById("imgSqrs572").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs572").src = "img/sqrs/wSqr.png"
};
};
function sqrsL573b() {
    if(document.getElementById("imgSqrs573").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs573").src = "img/sqrs/wSqr.png"
};
};
function sqrsL574b() {
    if(document.getElementById("imgSqrs574").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs574").src = "img/sqrs/wSqr.png"
};
};
function sqrsL575b() {
    if(document.getElementById("imgSqrs575").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs575").src = "img/sqrs/wSqr.png"
};
};
function sqrsL576b() {
    if(document.getElementById("imgSqrs576").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs576").src = "img/sqrs/wSqr.png"
};
};
function sqrsL577b() {
    if(document.getElementById("imgSqrs577").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs577").src = "img/sqrs/wSqr.png"
};
};
function sqrsL578b() {
    if(document.getElementById("imgSqrs578").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs578").src = "img/sqrs/wSqr.png"
};
};
function sqrsL579b() {
    if(document.getElementById("imgSqrs579").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs579").src = "img/sqrs/wSqr.png"
};
};
function sqrsL580b() {
    if(document.getElementById("imgSqrs580").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs580").src = "img/sqrs/wSqr.png"
};
};
function sqrsL581b() {
    if(document.getElementById("imgSqrs581").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs581").src = "img/sqrs/wSqr.png"
};
};
function sqrsL582b() {
    if(document.getElementById("imgSqrs582").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs582").src = "img/sqrs/wSqr.png"
};
};
function sqrsL583b() {
    if(document.getElementById("imgSqrs583").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs583").src = "img/sqrs/wSqr.png"
};
};
function sqrsL584b() {
    if(document.getElementById("imgSqrs584").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs584").src = "img/sqrs/wSqr.png"
};
};
function sqrsL585b() {
    if(document.getElementById("imgSqrs585").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs585").src = "img/sqrs/wSqr.png"
};
};
function sqrsL586b() {
    if(document.getElementById("imgSqrs586").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs586").src = "img/sqrs/wSqr.png"
};
};
function sqrsL587b() {
    if(document.getElementById("imgSqrs587").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs587").src = "img/sqrs/wSqr.png"
};
};
function sqrsL588b() {
    if(document.getElementById("imgSqrs588").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs588").src = "img/sqrs/wSqr.png"
};
};
function sqrsL589b() {
    if(document.getElementById("imgSqrs589").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs589").src = "img/sqrs/wSqr.png"
};
};
function sqrsL590b() {
    if(document.getElementById("imgSqrs590").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs590").src = "img/sqrs/wSqr.png"
};
};
function sqrsL591b() {
    if(document.getElementById("imgSqrs591").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs591").src = "img/sqrs/wSqr.png"
};
};
function sqrsL592b() {
    if(document.getElementById("imgSqrs592").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs592").src = "img/sqrs/wSqr.png"
};
};
function sqrsL593b() {
    if(document.getElementById("imgSqrs593").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs593").src = "img/sqrs/wSqr.png"
};
};
function sqrsL594b() {
    if(document.getElementById("imgSqrs594").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs594").src = "img/sqrs/wSqr.png"
};
};
function sqrsL595b() {
    if(document.getElementById("imgSqrs595").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs595").src = "img/sqrs/wSqr.png"
};
};
function sqrsL596b() {
    if(document.getElementById("imgSqrs596").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs596").src = "img/sqrs/wSqr.png"
};
};
function sqrsL597b() {
    if(document.getElementById("imgSqrs597").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs597").src = "img/sqrs/wSqr.png"
};
};
function sqrsL598b() {
    if(document.getElementById("imgSqrs598").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs598").src = "img/sqrs/wSqr.png"
};
};
function sqrsL599b() {
    if(document.getElementById("imgSqrs599").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs599").src = "img/sqrs/wSqr.png"
};
};
function sqrsL600b() {
    if(document.getElementById("imgSqrs600").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs600").src = "img/sqrs/wSqr.png"
};
};
function sqrsM601b() {
    if(document.getElementById("imgSqrs601").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs601").src = "img/sqrs/wSqr.png"
};
};
function sqrsM602b() {
    if(document.getElementById("imgSqrs602").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs602").src = "img/sqrs/wSqr.png"
};
};
function sqrsM603b() {
    if(document.getElementById("imgSqrs603").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs603").src = "img/sqrs/wSqr.png"
};
};
function sqrsM604b() {
    if(document.getElementById("imgSqrs604").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs604").src = "img/sqrs/wSqr.png"
};
};
function sqrsM605b() {
    if(document.getElementById("imgSqrs605").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs605").src = "img/sqrs/wSqr.png"
};
};
function sqrsM606b() {
    if(document.getElementById("imgSqrs606").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs606").src = "img/sqrs/wSqr.png"
};
};
function sqrsM607b() {
    if(document.getElementById("imgSqrs607").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs607").src = "img/sqrs/wSqr.png"
};
};
function sqrsM608b() {
    if(document.getElementById("imgSqrs608").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs608").src = "img/sqrs/wSqr.png"
};
};
function sqrsM609b() {
    if(document.getElementById("imgSqrs609").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs609").src = "img/sqrs/wSqr.png"
};
};
function sqrsM610b() {
    if(document.getElementById("imgSqrs610").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs610").src = "img/sqrs/wSqr.png"
};
};
function sqrsM611b() {
    if(document.getElementById("imgSqrs611").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs611").src = "img/sqrs/wSqr.png"
};
};
function sqrsM612b() {
    if(document.getElementById("imgSqrs612").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs612").src = "img/sqrs/wSqr.png"
};
};
function sqrsM613b() {
    if(document.getElementById("imgSqrs613").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs613").src = "img/sqrs/wSqr.png"
};
};
function sqrsM614b() {
    if(document.getElementById("imgSqrs614").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs614").src = "img/sqrs/wSqr.png"
};
};
function sqrsM615b() {
    if(document.getElementById("imgSqrs615").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs615").src = "img/sqrs/wSqr.png"
};
};
function sqrsM616b() {
    if(document.getElementById("imgSqrs616").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs616").src = "img/sqrs/wSqr.png"
};
};
function sqrsM617b() {
    if(document.getElementById("imgSqrs617").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs617").src = "img/sqrs/wSqr.png"
};
};
function sqrsM618b() {
    if(document.getElementById("imgSqrs618").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs618").src = "img/sqrs/wSqr.png"
};
};
function sqrsM619b() {
    if(document.getElementById("imgSqrs619").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs619").src = "img/sqrs/wSqr.png"
};
};
function sqrsM620b() {
    if(document.getElementById("imgSqrs620").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs620").src = "img/sqrs/wSqr.png"
};
};
function sqrsM621b() {
    if(document.getElementById("imgSqrs621").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs621").src = "img/sqrs/wSqr.png"
};
};
function sqrsM622b() {
    if(document.getElementById("imgSqrs622").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs622").src = "img/sqrs/wSqr.png"
};
};
function sqrsM623b() {
    if(document.getElementById("imgSqrs623").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs623").src = "img/sqrs/wSqr.png"
};
};
function sqrsM624b() {
    if(document.getElementById("imgSqrs624").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs624").src = "img/sqrs/wSqr.png"
};
};
function sqrsM625b() {
    if(document.getElementById("imgSqrs625").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs625").src = "img/sqrs/wSqr.png"
};
};