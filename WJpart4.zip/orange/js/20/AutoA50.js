function autoA50() {
    let a1 = Math.floor((Math.random() * 50) + 1);
	let a2 = Math.floor(((Math.random() * 50) + 1) + 50);
	let a3 = Math.floor(((Math.random() * 50) + 1) + 100);
	let a4 = Math.floor(((Math.random() * 50) + 1) + 150);
	let a5 = Math.floor(((Math.random() * 50) + 1) + 200);
	let a6 = Math.floor(((Math.random() * 50) + 1) + 250);
	let a7 = Math.floor(((Math.random() * 50) + 1) + 300);
	let a8 = Math.floor(((Math.random() * 50) + 1) + 350);
	let a9 = Math.floor(((Math.random() * 50) + 1) + 400);
	let a10 = Math.floor(((Math.random() * 50) + 1) + 450);
	let a11 = Math.floor(((Math.random() * 50) + 1) + 500);
	let a12 = Math.floor(((Math.random() * 50) + 1) + 550);
	let a13 = Math.floor(((Math.random() * 50) + 1) + 600);
    let a14 = Math.floor(((Math.random() * 50) + 1) + 650);
	let a15 = Math.floor(((Math.random() * 50) + 1) + 700);
	let a16 = Math.floor(((Math.random() * 50) + 1) + 750);
	let a17 = Math.floor(((Math.random() * 50) + 1) + 800);
	let a18 = Math.floor(((Math.random() * 50) + 1) + 850);
	let a19 = Math.floor(((Math.random() * 50) + 1) + 900);
	let a20 = Math.floor(((Math.random() * 50) + 1) + 950);
	let a21 = Math.floor(((Math.random() * 50) + 1) + 1000);
	let a22 = Math.floor(((Math.random() * 50) + 1) + 1050);
	let a23 = Math.floor(((Math.random() * 50) + 1) + 1100);
	let a24 = Math.floor(((Math.random() * 50) + 1) + 1150);
	let a25 = Math.floor(((Math.random() * 50) + 1) + 1200);
	let a26 = Math.floor(((Math.random() * 50) + 1) + 1250);
	let a27 = a25 + 100
    let a28 = a24 + 200
	let a29 = a23 + 300
	let a30 = a22 + 400
	let a31 = a21 + 500
	let a32 = a20 + 600
	let a33 = a19 + 700
	let a34 = a18 + 800
	let a35 = a17 + 900
	let a36 = a16 + 1000
	let a37 = a15 + 1100
	let a38 = a14 + 1200
	let a39 = a13 + 1300
    let a40 = a12 + 1400
	let a41 = a11 + 1500
	let a42 = a10 + 1600
	let a43 = a9 + 1700
	let a44 = a8 + 1800
	let a45 = a7 + 1900
	let a46 = a6 + 2000
	let a47 = a5 + 2100
	let a48 = a4 + 2200
	let a49 = a3 + 2300
	let a50 = a2 + 2400
	
	var s1 = a1;
	var s2 = a2;
	var s3 = a3;
	var s4 = a4;
	var s5 = a5;
	var s6 = a6;
 	var s7 = a7;
	var s8 = a8;
	var s9 = a9;
	var s10 = a10;
	var s11 = a11;
	var s12 = a12;
	var s13 = a13;
	var s14 = a14;
	var s15 = a15;
	var s16 = a16;
	var s17 = a17;
	var s18 = a18;
	var s19 = a19;
	var s20 = a20;
	var s21 = a21;
	var s22 = a22;
	var s23 = a23;
	var s24 = a24;
	var s25 = a25;
	var s26 = a26;
	var s27 = a27;
    var s28 = a28;
	var s29 = a29;
	var s30 = a30;
	var s31 = a31;
	var s32 = a32;
	var s33 = a33;
	var s34 = a34;
	var s35 = a35;
	var s36 = a36;
	var s37 = a37;
	var s38 = a38;
	var s39 = a39;
	var s40 = a40;
	var s41 = a41;
	var s42 = a42;
	var s43 = a43;
	var s44 = a44;
	var s45 = a45;
	var s46 = a46;
	var s47 = a47;
	var s48 = a48;
	var s49 = a49;
	var s50 = a50;
	var t1 = 'imgSqrs' + s1;
	var t2 = 'imgSqrs' + s2;
	var t3 = 'imgSqrs' + s3;
	var t4 = 'imgSqrs' + s4;
	var t5 = 'imgSqrs' + s5;
	var t6 = 'imgSqrs' + s6;
	var t7 = 'imgSqrs' + s7;
	var t8 = 'imgSqrs' + s8;
	var t9 = 'imgSqrs' + s9;
	var t10 = 'imgSqrs' + s10;
	var t11 = 'imgSqrs' + s11;
	var t12 = 'imgSqrs' + s12;
	var t13 = 'imgSqrs' + s13;
	var t14 = 'imgSqrs' + s14;
	var t15 = 'imgSqrs' + s15;
	var t16 = 'imgSqrs' + s16;
	var t17 = 'imgSqrs' + s17;
	var t18 = 'imgSqrs' + s18;
	var t19 = 'imgSqrs' + s19;
	var t20 = 'imgSqrs' + s20;
	var t21 = 'imgSqrs' + s21;
	var t22 = 'imgSqrs' + s22;
	var t23 = 'imgSqrs' + s23;
	var t24 = 'imgSqrs' + s24;
	var t25 = 'imgSqrs' + s25;
	var t26 = 'imgSqrs' + s26;
	var t27 = 'imgSqrs' + s27;
	var t28 = 'imgSqrs' + s28;
	var t29 = 'imgSqrs' + s29;
	var t30 = 'imgSqrs' + s30;
	var t31 = 'imgSqrs' + s31;
	var t32 = 'imgSqrs' + s32;
	var t33 = 'imgSqrs' + s33;
	var t34 = 'imgSqrs' + s34;
	var t35 = 'imgSqrs' + s35;
	var t36 = 'imgSqrs' + s36;
	var t37 = 'imgSqrs' + s37;
	var t38 = 'imgSqrs' + s38;
	var t39 = 'imgSqrs' + s39;
	var t40 = 'imgSqrs' + s40;
	var t41 = 'imgSqrs' + s41;
	var t42 = 'imgSqrs' + s42;
	var t43 = 'imgSqrs' + s43;
	var t44 = 'imgSqrs' + s44;
	var t45 = 'imgSqrs' + s45;
	var t46 = 'imgSqrs' + s46;
	var t47 = 'imgSqrs' + s47;
	var t48 = 'imgSqrs' + s48;
	var t49 = 'imgSqrs' + s49;
	var t50 = 'imgSqrs' + s50;
	
	if(document.getElementById(t1).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t1).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t2).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t2).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t3).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t3).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t4).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t4).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t5).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t5).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t6).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t6).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t7).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t7).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t8).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t8).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t9).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t9).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t10).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t10).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t11).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t11).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t12).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t12).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t13).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t13).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};
    if(document.getElementById(t14).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t14).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t15).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t15).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t16).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t16).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t17).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t17).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t18).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t18).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t19).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t19).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t20).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t20).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t21).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t21).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t22).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t22).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t23).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t23).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t24).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t24).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t25).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t25).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t26).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t26).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t27).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t27).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t28).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t28).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t29).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t29).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t30).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t30).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t31).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t31).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

    if(document.getElementById(t32).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
	    document.getElementById(t32).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};
    if(document.getElementById(t33).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
	    document.getElementById(t33).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};	
    if(document.getElementById(t34).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png"){
	    document.getElementById(t34).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};
    if(document.getElementById(t35).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t35).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};
    if(document.getElementById(t36).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t36).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};
    if(document.getElementById(t37).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t37).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};
    if(document.getElementById(t38).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t38).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};
    if(document.getElementById(t39).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t39).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};
    if(document.getElementById(t40).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t40).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};
    if(document.getElementById(t41).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t41).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};
    if(document.getElementById(t42).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t42).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};
    if(document.getElementById(t43).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t43).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};
    if(document.getElementById(t44).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t44).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};
    if(document.getElementById(t45).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t45).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};
    if(document.getElementById(t46).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t46).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};
    if(document.getElementById(t47).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t47).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};
    if(document.getElementById(t48).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t48).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};
    if(document.getElementById(t49).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t49).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};
    if(document.getElementById(t50).src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
		document.getElementById(t50).src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
	};

};