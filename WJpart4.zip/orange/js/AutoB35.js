function autoB35() {
    let a1 = Math.floor((Math.random() * 35) + 1);
	let a2 = Math.floor(((Math.random() * 35) + 1) + 35);
	let a3 = Math.floor(((Math.random() * 35) + 1) + 70);
	let a4 = Math.floor(((Math.random() * 35) + 1) + 105);
	let a5 = Math.floor(((Math.random() * 35) + 1) + 140);
	let a6 = Math.floor(((Math.random() * 35) + 1) + 175);
	let a7 = Math.floor(((Math.random() * 35) + 1) + 210);
	let a8 = Math.floor(((Math.random() * 35) + 1) + 245);
	let a9 = Math.floor(((Math.random() * 35) + 1) + 280);
	let a10 = Math.floor(((Math.random() * 35) + 1) + 315);
	let a11 = Math.floor(((Math.random() * 35) + 1) + 350);
	let a12 = Math.floor(((Math.random() * 35) + 1) + 385);
	let a13 = Math.floor(((Math.random() * 35) + 1) + 420);
    let a14 = Math.floor(((Math.random() * 35) + 1) + 455);
	let a15 = Math.floor(((Math.random() * 35) + 1) + 490);
	let a16 = Math.floor(((Math.random() * 35) + 1) + 525);
	let a17 = Math.floor(((Math.random() * 35) + 1) + 560);
	let a18 = Math.floor(((Math.random() * 35) + 1) + 595);
	let a19 = a17 + 70
    let a20 = a16 + 140
	let a21 = a15 + 210
	let a22 = a14 + 280
	let a23 = a13 + 350
	let a24 = a12 + 420
	let a25 = a11 + 490
	let a26 = a10 + 560
	let a27 = a9 + 630
	let a28 = a8 + 700
	let a29 = a7 + 770
	let a30 = a6 + 840
	let a31 = a5 + 910
    let a32 = a4 + 980
	let a33 = a3 + 1050
	let a34 = a2 + 1120
	let a35 = a1 + 1190
	
	var s1 = a1;
	var s2 = a2;
	var s3 = a3;
	var s4 = a4;
	var s5 = a5;
	var s6 = a6;
 	var s7 = a7;
	var s8 = a8;
	var s9 = a9;
	var s10 = a10;
	var s11 = a11;
	var s12 = a12;
	var s13 = a13;
	var s14 = a14;
	var s15 = a15;
	var s16 = a16;
	var s17 = a17;
	var s18 = a18;
	var s19 = a19;
	var s20 = a20;
	var s21 = a21;
	var s22 = a22;
	var s23 = a23;
	var s24 = a24;
	var s25 = a25;
	var s26 = a26;
	var s27 = a27;
    var s28 = a28;
	var s29 = a29;
	var s30 = a30;
	var s31 = a31;
	var s32 = a32;
	var s33 = a33;
	var s34 = a34;
	var s35 = a35;
	var t1 = 'imgSqrs' + s1;
	var t2 = 'imgSqrs' + s2;
	var t3 = 'imgSqrs' + s3;
	var t4 = 'imgSqrs' + s4;
	var t5 = 'imgSqrs' + s5;
	var t6 = 'imgSqrs' + s6;
	var t7 = 'imgSqrs' + s7;
	var t8 = 'imgSqrs' + s8;
	var t9 = 'imgSqrs' + s9;
	var t10 = 'imgSqrs' + s10;
	var t11 = 'imgSqrs' + s11;
	var t12 = 'imgSqrs' + s12;
	var t13 = 'imgSqrs' + s13;
	var t14 = 'imgSqrs' + s14;
	var t15 = 'imgSqrs' + s15;
	var t16 = 'imgSqrs' + s16;
	var t17 = 'imgSqrs' + s17;
	var t18 = 'imgSqrs' + s18;
	var t19 = 'imgSqrs' + s19;
	var t20 = 'imgSqrs' + s20;
	var t21 = 'imgSqrs' + s21;
	var t22 = 'imgSqrs' + s22;
	var t23 = 'imgSqrs' + s23;
	var t24 = 'imgSqrs' + s24;
	var t25 = 'imgSqrs' + s25;
	var t26 = 'imgSqrs' + s26;
	var t27 = 'imgSqrs' + s27;
	var t28 = 'imgSqrs' + s28;
	var t29 = 'imgSqrs' + s29;
	var t30 = 'imgSqrs' + s30;
	var t31 = 'imgSqrs' + s31;
	var t32 = 'imgSqrs' + s32;
	var t33 = 'imgSqrs' + s33;
	var t34 = 'imgSqrs' + s34;
	var t35 = 'imgSqrs' + s35;
	
	if(document.getElementById(t1).src = "img/sqrs/blSqr.png") {
		document.getElementById(t1).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t2).src = "img/sqrs/blSqr.png") {
		document.getElementById(t2).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t3).src = "img/sqrs/blSqr.png") {
		document.getElementById(t3).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t4).src = "img/sqrs/blSqr.png") {
		document.getElementById(t4).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t5).src = "img/sqrs/blSqr.png") {
		document.getElementById(t5).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t6).src = "img/sqrs/blSqr.png") {
		document.getElementById(t6).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t7).src = "img/sqrs/blSqr.png") {
		document.getElementById(t7).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t8).src = "img/sqrs/blSqr.png") {
		document.getElementById(t8).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t9).src = "img/sqrs/blSqr.png") {
		document.getElementById(t9).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t10).src = "img/sqrs/blSqr.png") {
		document.getElementById(t10).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t11).src = "img/sqrs/blSqr.png") {
		document.getElementById(t11).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t12).src = "img/sqrs/blSqr.png") {
		document.getElementById(t12).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t13).src = "img/sqrs/blSqr.png") {
		document.getElementById(t13).src = "img/sqrs/wSqr.png"
	};
    if(document.getElementById(t14).src = "img/sqrs/blSqr.png") {
		document.getElementById(t14).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t15).src = "img/sqrs/blSqr.png") {
		document.getElementById(t15).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t16).src = "img/sqrs/blSqr.png") {
		document.getElementById(t16).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t17).src = "img/sqrs/blSqr.png") {
		document.getElementById(t17).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t18).src = "img/sqrs/blSqr.png") {
		document.getElementById(t18).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t19).src = "img/sqrs/blSqr.png") {
		document.getElementById(t19).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t20).src = "img/sqrs/blSqr.png") {
		document.getElementById(t20).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t21).src = "img/sqrs/blSqr.png") {
		document.getElementById(t21).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t22).src = "img/sqrs/blSqr.png") {
		document.getElementById(t22).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t23).src = "img/sqrs/blSqr.png") {
		document.getElementById(t23).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t24).src = "img/sqrs/blSqr.png") {
		document.getElementById(t24).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t25).src = "img/sqrs/blSqr.png") {
		document.getElementById(t25).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t26).src = "img/sqrs/blSqr.png") {
		document.getElementById(t26).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t27).src = "img/sqrs/blSqr.png") {
		document.getElementById(t27).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t28).src = "img/sqrs/blSqr.png") {
		document.getElementById(t28).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t29).src = "img/sqrs/blSqr.png") {
		document.getElementById(t29).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t30).src = "img/sqrs/blSqr.png") {
		document.getElementById(t30).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t31).src = "img/sqrs/blSqr.png") {
		document.getElementById(t31).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t32).src = "img/sqrs/blSqr.png") {
	    document.getElementById(t32).src = "img/sqrs/wSqr.png"
	};
    if(document.getElementById(t33).src = "img/sqrs/blSqr.png") {
	    document.getElementById(t33).src = "img/sqrs/wSqr.png"
	};	
    if(document.getElementById(t34).src = "img/sqrs/blSqr.png"){
	    document.getElementById(t34).src = "img/sqrs/wSqr.png"
	};
    if(document.getElementById(t35).src = "img/sqrs/blSqr.png") {
		document.getElementById(t35).src = "img/sqrs/wSqr.png"
	};
};