function aZsqrsA1() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA2() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA3() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs3").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs3").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA4() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs4").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs4").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA5() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs5").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs5").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA6() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs6").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs6").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA7() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs7").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs7").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA8() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs8").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs8").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA9() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs9").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs9").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA10() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs10").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs10").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA11() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs11").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs11").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA12() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs12").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs12").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA13() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs13").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs13").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA14() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs14").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs14").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA15() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs15").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs15").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA16() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs16").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs16").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA17() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs17").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs17").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA18() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs18").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs18").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA19() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs19").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs19").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA20() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs20").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs20").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA21() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs21").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs21").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA22() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs22").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs22").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA23() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs23").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs23").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA24() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs24").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs24").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA25() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs25").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs25").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA26() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs26").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs26").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA27() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs27").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs27").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA28() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs28").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs28").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA29() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs29").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs29").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA30() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs30").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs30").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA31() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs31").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs31").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA32() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs32").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs32").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA33() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs33").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs33").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA34() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs34").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs34").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA35() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs35").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs35").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA36() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs36").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs36").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA37() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs37").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs37").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA38() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs38").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs38").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA39() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs39").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs39").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA40() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs40").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs40").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA41() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs41").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs41").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA42() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs42").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs42").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA43() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs43").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs43").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA44() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs44").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs44").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA45() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs45").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs45").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA46() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs46").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs46").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA47() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs47").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs47").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA48() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs48").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs48").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA49() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs49").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs49").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA50() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs50").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs50").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB51() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs51").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs51").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB52() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs52").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs52").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB53() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs53").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs53").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB54() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs54").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs54").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB55() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs55").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs55").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB56() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs56").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs56").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB57() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs57").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs57").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB58() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs58").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs58").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB59() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs59").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs59").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB60() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs60").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs60").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB61() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs61").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs61").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB62() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs62").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs62").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB63() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs63").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs63").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB64() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs64").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs64").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB65() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs65").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs65").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB66() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs66").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs66").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB67() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs67").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs67").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB68() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs68").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs68").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB69() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs69").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs69").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB70() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs70").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs70").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB71() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs71").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs71").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB72() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs72").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs72").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB73() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs73").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs73").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB74() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs74").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs74").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB75() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs75").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs75").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB76() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs76").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs76").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB77() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs77").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs77").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB78() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs78").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs78").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB79() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs79").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs79").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB80() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs80").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs80").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB81() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs81").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs81").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB82() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs82").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs82").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB83() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs83").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs83").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB84() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs84").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs84").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB85() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs85").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs85").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB86() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs86").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs86").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB87() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs87").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs87").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB88() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs88").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs88").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB89() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs89").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs89").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB90() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs90").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs90").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB91() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs91").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs91").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB92() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs92").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs92").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB93() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs93").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs93").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB94() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs94").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs94").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB95() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs95").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs95").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB96() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs96").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs96").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB97() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs97").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs97").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB98() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs98").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs98").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB99() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs99").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs99").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB100() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs100").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs100").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC101() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs101").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs101").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC102() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs102").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs102").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC103() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs103").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs103").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC104() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs104").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs104").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC105() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs105").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs105").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC106() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs106").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs106").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC107() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs107").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs107").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC108() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs108").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs108").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC109() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs109").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs109").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC110() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs110").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs110").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC111() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs111").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs111").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC112() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs112").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs112").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC113() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs113").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs113").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC114() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs114").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs114").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC115() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs115").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs115").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC116() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs116").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs116").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC117() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs117").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs117").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC118() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs118").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs118").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC119() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs119").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs119").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC120() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs120").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs120").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC121() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs121").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs121").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC122() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs122").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs122").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC123() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs123").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs123").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC124() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs124").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs124").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC125() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs125").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs125").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC126() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs126").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs126").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC127() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs127").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs127").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC128() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs128").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs128").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC129() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs129").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs129").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC130() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs130").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs130").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC131() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs131").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs131").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC132() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs132").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs132").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC133() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs133").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs133").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC134() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs134").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs134").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC135() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs135").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs135").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC136() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs136").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs136").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC137() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs137").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs137").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC138() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs138").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs138").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC139() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs139").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs139").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC140() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs140").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs140").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC141() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs141").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs141").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC142() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs142").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs142").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC143() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs143").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs143").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC144() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs144").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs144").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC145() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs145").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs145").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC146() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs146").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs146").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC147() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs147").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs147").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC148() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs148").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs148").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC149() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs149").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs149").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC150() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs150").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs150").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD151() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs151").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs151").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD152() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs152").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs152").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD153() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs153").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs153").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD154() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs154").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs154").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD155() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs155").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs155").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD156() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs156").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs156").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD157() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs157").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs157").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD158() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs158").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs158").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD159() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs159").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs159").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD160() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs160").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs160").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD161() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs161").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs161").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD162() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs162").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs162").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD163() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs163").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs163").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD164() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs164").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs164").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD165() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs165").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs165").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD166() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs166").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs166").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD167() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs167").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs167").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD168() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs168").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs168").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD169() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs169").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs169").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD170() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs170").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs170").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD171() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs171").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs171").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD172() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs172").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs172").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD173() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs173").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs173").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD174() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs174").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs174").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD175() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs175").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs175").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD176() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs176").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs176").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD177() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs177").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs177").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD178() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs178").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs178").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD179() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs179").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs179").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD180() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs180").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs180").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD181() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs181").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs181").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD182() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs182").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs182").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD183() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs183").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs183").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD184() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs184").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs184").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD185() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs185").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs185").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD186() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs186").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs186").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD187() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs187").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs187").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD188() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs188").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs188").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD189() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs189").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs189").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD190() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs190").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs190").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD191() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs191").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs191").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD192() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs192").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs192").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD193() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs193").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs193").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD194() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs194").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs194").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD195() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs195").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs195").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD196() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs196").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs196").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD197() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs197").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs197").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD198() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs198").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs198").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD199() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs199").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs199").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD200() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs200").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs200").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE201() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs201").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs201").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE202() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs202").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs202").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE203() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs203").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs203").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE204() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs204").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs204").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE205() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs205").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs205").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE206() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs206").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs206").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE207() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs207").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs207").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE208() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs208").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs208").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE209() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs209").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs209").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE210() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs210").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs210").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE211() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs211").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs211").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE212() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs212").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs212").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE213() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs213").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs213").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE214() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs214").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs214").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE215() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs215").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs215").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE216() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs216").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs216").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE217() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs217").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs217").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE218() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs218").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs218").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE219() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs219").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs219").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE220() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs220").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs220").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE221() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs221").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs221").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE222() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs222").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs222").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE223() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs223").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs223").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE224() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs224").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs224").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE225() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs225").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs225").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE226() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs226").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs226").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE227() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs227").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs227").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE228() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs228").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs228").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE229() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs229").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs229").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE230() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs230").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs230").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE231() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs231").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs231").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE232() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs232").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs232").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE233() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs233").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs233").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE234() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs234").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs234").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE235() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs235").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs235").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE236() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs236").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs236").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE237() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs237").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs237").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE238() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs238").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs238").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE239() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs239").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs239").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE240() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs240").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs240").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE241() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs241").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs241").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE242() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs242").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs242").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE243() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs243").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs243").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE244() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs244").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs244").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE245() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs245").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs245").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE246() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs246").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs246").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE247() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs247").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs247").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE248() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs248").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs248").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE249() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs249").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs249").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE250() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs250").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs250").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF251() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs251").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs251").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF252() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs252").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs252").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF253() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs253").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs253").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF254() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs254").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs254").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF255() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs255").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs255").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF256() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs256").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs256").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF257() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs257").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs257").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF258() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs258").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs258").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF259() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs259").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs259").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF260() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs260").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs260").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF261() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs261").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs261").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF262() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs262").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs262").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF263() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs263").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs263").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF264() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs264").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs264").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF265() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs265").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs265").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF266() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs266").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs266").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF267() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs267").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs267").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF268() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs268").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs268").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF269() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs269").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs269").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF270() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs270").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs270").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF271() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs271").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs271").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF272() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs272").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs272").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF273() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs273").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs273").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF274() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs274").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs274").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF275() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs275").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs275").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF276() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs276").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs276").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF277() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs277").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs277").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF278() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs278").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs278").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF279() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs279").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs279").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF280() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs280").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs280").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF281() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs281").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs281").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF282() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs282").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs282").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF283() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs283").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs283").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF284() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs284").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs284").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF285() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs285").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs285").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF286() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs286").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs286").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF287() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs287").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs287").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF288() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs288").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs288").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF289() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs289").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs289").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF290() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs290").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs290").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF291() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs291").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs291").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF292() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs292").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs292").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF293() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs293").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs293").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF294() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs294").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs294").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF295() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs295").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs295").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF296() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs296").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs296").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF297() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs297").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs297").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF298() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs298").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs298").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF299() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs299").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs299").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF300() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs300").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs300").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG301() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs301").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs301").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG302() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs302").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs302").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG303() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs303").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs303").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG304() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs304").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs304").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG305() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs305").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs305").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG306() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs306").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs306").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG307() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs307").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs307").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG308() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs308").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs308").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG309() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs309").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs309").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG310() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs310").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs310").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG311() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs311").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs311").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG312() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs312").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs312").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG313() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs313").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs313").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG314() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs314").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs314").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG315() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs315").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs315").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG316() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs316").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs316").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG317() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs317").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs317").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG318() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs318").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs318").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG319() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs319").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs319").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG320() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs320").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs320").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG321() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs321").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs321").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG322() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs322").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs322").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG323() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs323").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs323").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG324() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs324").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs324").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG325() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs325").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs325").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG326() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs326").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs326").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG327() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs327").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs327").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG328() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs328").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs328").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG329() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs329").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs329").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG330() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs330").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs330").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG331() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs331").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs331").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG332() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs332").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs332").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG333() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs333").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs333").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG334() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs334").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs334").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG335() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs335").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs335").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG336() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs336").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs336").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG337() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs337").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs337").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG338() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs338").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs338").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG339() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs339").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs339").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG340() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs340").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs340").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG341() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs341").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs341").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG342() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs342").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs342").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG343() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs343").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs343").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG344() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs344").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs344").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG345() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs345").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs345").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG346() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs346").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs346").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG347() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs347").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs347").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG348() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs348").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs348").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG349() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs349").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs349").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG350() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs350").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs350").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH351() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs351").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs351").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH352() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs352").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs352").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH353() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs353").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs353").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH354() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs354").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs354").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH355() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs355").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs355").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH356() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs356").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs356").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH357() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs357").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs357").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH358() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs358").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs358").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH359() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs359").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs359").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH360() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs360").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs360").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH361() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs361").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs361").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH362() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs362").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs362").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH363() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs363").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs363").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH364() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs364").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs364").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH365() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs365").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs365").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH366() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs366").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs366").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH367() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs367").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs367").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH368() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs368").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs368").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH369() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs369").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs369").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH370() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs370").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs370").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH371() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs371").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs371").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH372() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs372").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs372").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH373() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs373").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs373").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH374() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs374").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs374").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH375() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs375").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs375").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH376() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs376").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs376").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH377() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs377").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs377").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH378() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs378").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs378").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH379() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs379").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs379").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH380() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs380").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs380").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH381() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs381").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs381").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH382() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs382").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs382").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH383() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs383").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs383").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH384() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs384").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs384").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH385() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs385").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs385").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH386() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs386").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs386").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH387() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs387").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs387").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH388() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs388").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs388").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH389() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs389").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs389").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH390() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs390").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs390").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH391() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs391").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs391").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH392() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs392").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs392").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH393() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs393").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs393").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH394() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs394").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs394").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH395() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs395").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs395").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH396() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs396").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs396").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH397() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs397").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs397").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH398() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs398").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs398").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH399() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs399").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs399").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH400() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs400").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs400").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI401() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs401").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs401").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI402() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs402").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs402").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI403() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs403").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs403").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI404() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs404").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs404").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI405() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs405").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs405").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI406() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs406").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs406").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI407() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs407").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs407").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI408() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs408").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs408").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI409() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs409").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs409").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI410() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs410").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs410").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI411() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs411").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs411").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI412() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs412").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs412").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI413() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs413").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs413").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI414() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs414").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs414").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI415() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs415").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs415").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI416() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs416").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs416").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI417() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs417").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs417").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI418() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs418").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs418").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI419() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs419").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs419").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI420() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs420").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs420").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI421() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs421").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs421").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI422() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs422").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs422").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI423() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs423").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs423").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI424() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs424").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs424").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI425() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs425").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs425").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI426() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs426").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs426").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI427() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs427").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs427").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI428() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs428").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs428").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI429() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs429").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs429").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI430() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs430").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs430").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI431() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs431").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs431").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI432() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs432").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs432").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI433() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs433").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs433").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI434() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs434").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs434").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI435() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs435").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs435").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI436() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs436").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs436").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI437() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs437").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs437").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI438() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs438").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs438").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI439() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs439").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs439").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI440() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs440").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs440").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI441() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs441").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs441").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI442() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs442").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs442").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI443() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs443").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs443").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI444() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs444").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs444").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI445() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs445").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs445").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI446() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs446").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs446").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI447() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs447").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs447").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI448() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs448").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs448").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI449() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs449").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs449").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI450() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs450").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs450").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ451() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs451").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs451").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ452() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs452").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs452").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ453() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs453").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs453").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ454() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs454").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs454").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ455() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs455").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs455").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ456() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs456").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs456").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ457() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs457").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs457").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ458() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs458").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs458").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ459() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs459").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs459").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ460() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs460").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs460").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ461() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs461").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs461").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ462() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs462").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs462").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ463() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs463").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs463").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ464() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs464").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs464").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ465() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs465").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs465").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ466() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs466").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs466").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ467() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs467").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs467").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ468() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs468").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs468").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ469() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs469").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs469").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ470() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs470").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs470").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ471() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs471").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs471").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ472() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs472").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs472").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ473() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs473").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs473").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ474() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs474").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs474").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ475() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs475").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs475").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ476() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs476").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs476").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ477() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs477").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs477").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ478() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs478").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs478").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ479() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs479").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs479").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ480() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs480").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs480").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ481() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs481").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs481").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ482() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs482").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs482").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ483() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs483").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs483").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ484() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs484").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs484").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ485() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs485").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs485").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ486() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs486").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs486").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ487() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs487").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs487").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ488() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs488").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs488").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ489() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs489").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs489").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ490() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs490").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs490").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ491() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs491").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs491").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ492() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs492").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs492").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ493() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs493").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs493").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ494() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs494").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs494").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ495() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs495").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs495").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ496() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs496").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs496").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ497() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs497").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs497").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ498() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs498").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs498").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ499() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs499").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs499").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ500() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs500").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs500").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK501() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs501").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs501").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK502() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs502").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs502").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK503() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs503").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs503").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK504() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs504").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs504").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK505() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs505").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs505").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK506() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs506").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs506").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK507() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs507").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs507").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK508() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs508").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs508").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK509() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs509").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs509").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK510() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs510").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs510").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK511() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs511").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs511").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK512() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs512").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs512").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK513() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs513").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs513").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK514() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs514").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs514").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK515() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs515").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs515").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK516() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs516").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs516").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK517() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs517").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs517").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK518() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs518").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs518").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK519() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs519").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs519").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK520() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs520").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs520").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK521() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs521").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs521").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK522() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs522").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs522").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK523() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs523").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs523").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK524() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs524").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs524").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK525() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs525").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs525").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK526() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs526").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs526").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK527() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs527").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs527").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK528() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs528").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs528").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK529() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs529").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs529").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK530() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs530").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs530").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK531() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs531").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs531").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK532() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs532").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs532").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK533() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs533").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs533").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK534() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs534").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs534").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK535() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs535").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs535").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK536() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs536").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs536").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK537() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs537").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs537").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK538() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs538").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs538").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK539() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs539").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs539").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK540() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs540").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs540").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK541() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs541").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs541").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK542() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs542").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs542").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK543() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs543").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs543").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK544() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs544").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs544").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK545() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs545").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs545").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK546() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs546").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs546").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK547() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs547").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs547").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK548() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs548").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs548").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK549() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs549").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs549").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK550() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs550").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs550").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL551() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs551").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs551").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL552() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs552").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs552").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL553() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs553").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs553").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL554() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs554").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs554").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL555() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs555").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs555").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL556() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs556").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs556").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL557() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs557").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs557").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL558() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs558").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs558").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL559() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs559").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs559").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL560() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs560").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs560").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL561() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs561").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs561").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL562() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs562").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs562").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL563() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs563").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs563").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL564() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs564").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs564").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL565() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs565").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs565").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL566() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs566").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs566").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL567() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs567").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs567").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL568() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs568").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs568").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL569() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs569").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs569").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL570() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs570").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs570").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL571() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs571").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs571").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL572() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs572").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs572").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL573() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs573").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs573").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL574() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs574").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs574").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL575() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs575").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs575").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL576() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs576").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs576").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL577() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs577").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs577").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL578() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs578").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs578").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL579() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs579").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs579").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL580() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs580").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs580").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL581() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs581").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs581").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL582() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs582").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs582").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL583() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs583").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs583").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL584() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs584").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs584").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL585() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs585").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs585").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL586() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs586").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs586").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL587() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs587").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs587").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL588() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs588").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs588").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL589() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs589").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs589").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL590() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs590").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs590").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL591() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs591").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs591").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL592() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs592").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs592").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL593() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs593").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs593").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL594() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs594").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs594").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL595() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs595").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs595").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL596() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs596").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs596").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL597() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs597").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs597").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL598() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs598").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs598").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL599() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs599").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs599").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL600() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs600").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs600").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM601() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs601").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs601").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM602() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs602").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs602").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM603() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs603").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs603").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM604() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs604").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs604").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM605() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs605").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs605").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM606() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs606").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs606").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM607() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs607").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs607").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM608() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs608").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs608").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM609() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs609").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs609").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM610() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs610").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs610").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM611() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs611").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs611").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM612() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs612").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs612").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM613() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs613").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs613").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM614() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs614").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs614").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM615() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs615").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs615").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM616() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs616").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs616").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM617() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs617").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs617").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM618() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs618").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs618").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM619() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs619").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs619").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM620() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs620").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs620").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM621() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs621").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs621").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM622() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs622").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs622").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM623() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs623").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs623").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM624() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs624").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs624").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM625() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs625").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs625").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM626() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs626").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs626").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM627() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs627").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs627").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM628() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs628").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs628").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM629() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs629").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs629").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM630() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs630").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs630").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM631() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs631").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs631").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM632() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs632").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs632").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM633() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs633").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs633").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM634() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs634").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs634").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM635() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs635").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs635").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM636() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs636").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs636").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM637() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs637").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs637").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM638() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs638").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs638").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM639() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs639").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs639").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM640() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs640").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs640").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM641() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs641").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs641").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM642() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs642").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs642").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM643() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs643").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs643").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM644() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs644").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs644").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM645() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs645").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs645").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM646() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs646").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs646").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM647() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs647").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs647").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM648() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs648").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs648").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM649() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs649").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs649").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM650() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs650").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs650").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN651() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs651").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs651").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN652() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs652").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs652").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN653() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs653").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs653").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN654() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs654").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs654").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN655() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs655").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs655").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN656() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs656").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs656").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN657() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs657").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs657").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN658() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs658").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs658").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN659() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs659").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs659").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN660() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs660").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs660").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN661() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs661").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs661").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN662() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs662").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs662").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN663() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs663").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs663").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN664() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs664").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs664").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN665() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs665").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs665").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN666() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs666").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs666").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN667() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs667").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs667").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN668() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs668").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs668").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN669() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs669").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs669").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN670() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs670").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs670").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN671() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs671").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs671").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN672() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs672").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs672").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN673() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs673").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs673").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN674() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs674").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs674").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN675() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs675").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs675").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN676() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs676").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs676").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN677() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs677").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs677").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN678() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs678").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs678").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN679() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs679").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs679").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN680() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs680").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs680").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN681() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs681").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs681").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN682() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs682").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs682").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN683() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs683").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs683").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN684() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs684").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs684").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN685() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs685").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs685").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN686() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs686").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs686").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN687() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs687").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs687").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN688() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs688").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs688").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN689() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs689").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs689").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN690() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs690").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs690").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN691() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs691").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs691").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN692() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs692").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs692").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN693() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs693").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs693").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN694() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs694").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs694").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN695() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs695").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs695").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN696() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs696").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs696").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN697() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs697").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs697").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN698() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs698").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs698").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN699() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs699").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs699").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsN700() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs700").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs700").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO701() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs701").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs701").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO702() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs702").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs702").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO703() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs703").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs703").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO704() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs704").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs704").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO705() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs705").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs705").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO706() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs706").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs706").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO707() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs707").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs707").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO708() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs708").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs708").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO709() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs709").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs709").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO710() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs710").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs710").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO711() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs711").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs711").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO712() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs712").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs712").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO713() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs713").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs713").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO714() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs714").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs714").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO715() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs715").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs715").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO716() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs716").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs716").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO717() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs717").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs717").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO718() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs718").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs718").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO719() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs719").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs719").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO720() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs720").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs720").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO721() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs721").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs721").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO722() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs722").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs722").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO723() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs723").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs723").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO724() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs724").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs724").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO725() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs725").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs725").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO726() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs726").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs726").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO727() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs727").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs727").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO728() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs728").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs728").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO729() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs729").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs729").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO730() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs730").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs730").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO731() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs731").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs731").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO732() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs732").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs732").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO733() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs733").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs733").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO734() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs734").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs734").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO735() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs735").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs735").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO736() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs736").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs736").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO737() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs737").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs737").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO738() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs738").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs738").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO739() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs739").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs739").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO740() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs740").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs740").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO741() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs741").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs741").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO742() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs742").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs742").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO743() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs743").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs743").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO744() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs744").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs744").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO745() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs745").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs745").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO746() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs746").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs746").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO747() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs747").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs747").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO748() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs748").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs748").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO749() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs749").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs749").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsO750() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs750").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs750").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP751() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs751").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs751").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP752() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs752").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs752").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP753() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs753").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs753").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP754() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs754").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs754").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP755() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs755").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs755").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP756() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs756").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs756").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP757() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs757").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs757").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP758() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs758").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs758").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP759() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs759").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs759").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP760() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs760").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs760").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP761() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs761").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs761").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP762() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs762").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs762").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP763() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs763").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs763").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP764() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs764").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs764").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP765() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs765").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs765").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP766() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs766").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs766").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP767() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs767").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs767").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP768() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs768").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs768").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP769() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs769").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs769").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP770() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs770").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs770").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP771() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs771").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs771").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP772() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs772").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs772").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP773() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs773").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs773").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP774() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs774").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs774").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP775() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs775").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs775").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP776() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs776").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs776").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP777() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs777").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs777").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP778() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs778").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs778").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP779() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs779").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs779").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP780() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs780").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs780").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP781() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs781").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs781").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP782() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs782").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs782").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP783() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs783").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs783").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP784() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs784").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs784").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP785() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs785").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs785").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP786() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs786").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs786").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP787() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs787").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs787").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP788() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs788").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs788").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP789() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs789").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs789").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP790() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs790").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs790").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP791() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs791").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs791").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP792() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs792").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs792").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP793() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs793").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs793").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP794() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs794").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs794").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP795() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs795").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs795").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP796() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs796").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs796").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP797() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs797").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs797").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP798() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs798").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs798").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP799() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs799").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs799").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsP800() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs800").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs800").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ801() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs801").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs801").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ802() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs802").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs802").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ803() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs803").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs803").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ804() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs804").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs804").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ805() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs805").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs805").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ806() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs806").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs806").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ807() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs807").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs807").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ808() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs808").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs808").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ809() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs809").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs809").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ810() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs810").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs810").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ811() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs811").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs811").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ812() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs812").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs812").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ813() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs813").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs813").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ814() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs814").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs814").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ815() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs815").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs815").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ816() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs816").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs816").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ817() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs817").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs817").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ818() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs818").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs818").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ819() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs819").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs819").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ820() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs820").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs820").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ821() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs821").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs821").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ822() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs822").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs822").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ823() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs823").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs823").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ824() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs824").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs824").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ825() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs825").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs825").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ826() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs826").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs826").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ827() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs827").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs827").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ828() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs828").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs828").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ829() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs829").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs829").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ830() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs830").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs830").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ831() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs831").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs831").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ832() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs832").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs832").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ833() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs833").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs833").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ834() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs834").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs834").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ835() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs835").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs835").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ836() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs836").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs836").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ837() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs837").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs837").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ838() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs838").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs838").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ839() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs839").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs839").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ840() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs840").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs840").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ841() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs841").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs841").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ842() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs842").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs842").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ843() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs843").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs843").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ844() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs844").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs844").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ845() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs845").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs845").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ846() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs846").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs846").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ847() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs847").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs847").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ848() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs848").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs848").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ849() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs849").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs849").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsQ850() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs850").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs850").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR851() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs851").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs851").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR852() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs852").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs852").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR853() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs853").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs853").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR854() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs854").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs854").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR855() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs855").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs855").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR856() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs856").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs856").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR857() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs857").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs857").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR858() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs858").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs858").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR859() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs859").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs859").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR860() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs860").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs860").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR861() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs861").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs861").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR862() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs862").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs862").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR863() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs863").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs863").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR864() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs864").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs864").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR865() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs865").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs865").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR866() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs866").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs866").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR867() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs867").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs867").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR868() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs868").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs868").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR869() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs869").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs869").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR870() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs870").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs870").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR871() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs871").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs871").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR872() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs872").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs872").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR873() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs873").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs873").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR874() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs874").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs874").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR875() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs875").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs875").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR876() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs876").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs876").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR877() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs877").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs877").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR878() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs878").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs878").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR879() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs879").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs879").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR880() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs880").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs880").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR881() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs881").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs881").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR882() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs882").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs882").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR883() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs883").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs883").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR884() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs884").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs884").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR885() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs885").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs885").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR886() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs886").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs886").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR887() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs887").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs887").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR888() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs888").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs888").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR889() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs889").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs889").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR890() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs890").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs890").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR891() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs891").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs891").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR892() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs892").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs892").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR893() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs893").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs893").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR894() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs894").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs894").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR895() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs895").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs895").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR896() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs896").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs896").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR897() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs897").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs897").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR898() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs898").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs898").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR899() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs899").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs899").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsR900() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs900").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs900").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS901() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs901").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs901").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS902() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs902").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs902").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS903() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs903").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs903").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS904() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs904").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs904").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS905() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs905").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs905").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS906() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs906").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs906").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS907() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs907").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs907").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS908() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs908").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs908").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS909() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs909").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs909").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS910() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs910").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs910").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS911() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs911").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs911").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS912() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs912").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs912").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS913() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs913").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs913").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS914() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs914").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs914").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS915() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs915").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs915").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS916() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs916").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs916").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS917() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs917").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs917").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS918() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs918").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs918").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS919() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs919").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs919").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS920() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs920").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs920").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS921() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs921").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs921").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS922() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs922").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs922").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS923() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs923").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs923").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS924() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs924").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs924").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS925() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs925").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs925").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS926() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs926").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs926").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS927() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs927").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs927").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS928() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs928").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs928").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS929() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs929").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs929").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS930() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs930").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs930").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS931() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs931").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs931").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS932() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs932").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs932").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS933() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs933").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs933").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS934() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs934").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs934").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS935() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs935").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs935").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS936() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs936").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs936").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS937() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs937").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs937").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS938() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs938").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs938").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS939() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs939").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs939").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS940() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs940").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs940").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS941() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs941").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs941").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS942() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs942").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs942").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS943() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs943").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs943").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS944() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs944").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs944").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS945() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs945").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs945").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS946() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs946").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs946").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS947() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs947").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs947").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS948() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs948").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs948").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS949() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs949").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs949").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsS950() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs950").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs950").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT951() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs951").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs951").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT952() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs952").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs952").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT953() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs953").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs953").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT954() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs954").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs954").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT955() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs955").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs955").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT956() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs956").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs956").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT957() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs957").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs957").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT958() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs958").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs958").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT959() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs959").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs959").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT960() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs960").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs960").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT961() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs961").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs961").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT962() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs962").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs962").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT963() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs963").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs963").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT964() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs964").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs964").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT965() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs965").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs965").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT966() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs966").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs966").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT967() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs967").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs967").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT968() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs968").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs968").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT969() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs969").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs969").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT970() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs970").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs970").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT971() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs971").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs971").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT972() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs972").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs972").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT973() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs973").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs973").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT974() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs974").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs974").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT975() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs975").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs975").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT976() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs976").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs976").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT977() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs977").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs977").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT978() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs978").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs978").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT979() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs979").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs979").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT980() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs980").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs980").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT981() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs981").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs981").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT982() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs982").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs982").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT983() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs983").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs983").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT984() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs984").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs984").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT985() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs985").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs985").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT986() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs986").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs986").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT987() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs987").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs987").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT988() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs988").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs988").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT989() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs989").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs989").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT990() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs990").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs990").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT991() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs991").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs991").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT992() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs992").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs992").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT993() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs993").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs993").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT994() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs994").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs994").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT995() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs995").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs995").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT996() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs996").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs996").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT997() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs997").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs997").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT998() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs998").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs998").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT999() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs999").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs999").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsT1000() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1000").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1000").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1001() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1001").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1001").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1002() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1002").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1002").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1003() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1003").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1003").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1004() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1004").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1004").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1005() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1005").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1005").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1006() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1006").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1006").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1007() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1007").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1007").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1008() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1008").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1008").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1009() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1009").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1009").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1010() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1010").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1010").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1011() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1011").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1011").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1012() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1012").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1012").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1013() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1013").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1013").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1014() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1014").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1014").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1015() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1015").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1015").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1016() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1016").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1016").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1017() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1017").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1017").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1018() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1018").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1018").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1019() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1019").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1019").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1020() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1020").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1020").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1021() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1021").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1021").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1022() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1022").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1022").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1023() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1023").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1023").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1024() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1024").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1024").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1025() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1025").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1025").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1026() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1026").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1026").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1027() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1027").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1027").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1028() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1028").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1028").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1029() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1029").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1029").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1030() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1030").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1030").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1031() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1031").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1031").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1032() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1032").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1032").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1033() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1033").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1033").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1034() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1034").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1034").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1035() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1035").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1035").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1036() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1036").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1036").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1037() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1037").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1037").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1038() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1038").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1038").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1039() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1039").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1039").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1040() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1040").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1040").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1041() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1041").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1041").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1042() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1042").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1042").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1043() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1043").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1043").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1044() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1044").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1044").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1045() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1045").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1045").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1046() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1046").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1046").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1047() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1047").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1047").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1048() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1048").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1048").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1049() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1049").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1049").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsU1050() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1050").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1050").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1051() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1051").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1051").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1052() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1052").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1052").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1053() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1053").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1053").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1054() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1054").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1054").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1055() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1055").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1055").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1056() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1056").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1056").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1057() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1057").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1057").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1058() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1058").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1058").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1059() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1059").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1059").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1060() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1060").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1060").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1061() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1061").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1061").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1062() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1062").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1062").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1063() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1063").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1063").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1064() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1064").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1064").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1065() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1065").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1065").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1066() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1066").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1066").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1067() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1067").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1067").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1068() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1068").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1068").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1069() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1069").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1069").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1070() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1070").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1070").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1071() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1071").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1071").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1072() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1072").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1072").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1073() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1073").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1073").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1074() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1074").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1074").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1075() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1075").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1075").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1076() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1076").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1076").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1077() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1077").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1077").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1078() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1078").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1078").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1079() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1079").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1079").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1080() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1080").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1080").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1081() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1081").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1081").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1082() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1082").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1082").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1083() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1083").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1083").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1084() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1084").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1084").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1085() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1085").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1085").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1086() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1086").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1086").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1087() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1087").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1087").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1088() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1088").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1088").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1089() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1089").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1089").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1090() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1090").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1090").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1091() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1091").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1091").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1092() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1092").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1092").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1093() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1093").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1093").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1094() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1094").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1094").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1095() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1095").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1095").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1096() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1096").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1096").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1097() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1097").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1097").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1098() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1098").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1098").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1099() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1099").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1099").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsV1100() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1100").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1100").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1101() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1101").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1101").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1102() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1102").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1102").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1103() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1103").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1103").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1104() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1104").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1104").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1105() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1105").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1105").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1106() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1106").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1106").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1107() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1107").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1107").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1108() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1108").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1108").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1109() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1109").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1109").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1110() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1110").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1110").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1111() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1111").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1111").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1112() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1112").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1112").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1113() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1113").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1113").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1114() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1114").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1114").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1115() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1115").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1115").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1116() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1116").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1116").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1117() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1117").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1117").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1118() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1118").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1118").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1119() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1119").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1119").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1120() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1120").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1120").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1121() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1121").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1121").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1122() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1122").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1122").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1123() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1123").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1123").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1124() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1124").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1124").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1125() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1125").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1125").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1126() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1126").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1126").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1127() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1127").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1127").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1128() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1128").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1128").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1129() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1129").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1129").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1130() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1130").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1130").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1131() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1131").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1131").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1132() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1132").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1132").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1133() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1133").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1133").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1134() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1134").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1134").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1135() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1135").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1135").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1136() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1136").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1136").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1137() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1137").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1137").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1138() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1138").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1138").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1139() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1139").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1139").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1140() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1140").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1140").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1141() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1141").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1141").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1142() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1142").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1142").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1143() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1143").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1143").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1144() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1144").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1144").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1145() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1145").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1145").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1146() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1146").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1146").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1147() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1147").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1147").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1148() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1148").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1148").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1149() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1149").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1149").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsW1150() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1150").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1150").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1151() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1151").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1151").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1152() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1152").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1152").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1153() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1153").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1153").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1154() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1154").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1154").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1155() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1155").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1155").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1156() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1156").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1156").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1157() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1157").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1157").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1158() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1158").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1158").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1159() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1159").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1159").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1160() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1160").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1160").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1161() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1161").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1161").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1162() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1162").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1162").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1163() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1163").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1163").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1164() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1164").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1164").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1165() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1165").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1165").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1166() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1166").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1166").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1167() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1167").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1167").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1168() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1168").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1168").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1169() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1169").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1169").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1170() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1170").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1170").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1171() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1171").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1171").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1172() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1172").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1172").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1173() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1173").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1173").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1174() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1174").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1174").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1175() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1175").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1175").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1176() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1176").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1176").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1177() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1177").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1177").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1178() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1178").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1178").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1179() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1179").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1179").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1180() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1180").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1180").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1181() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1181").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1181").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1182() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1182").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1182").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1183() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1183").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1183").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1184() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1184").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1184").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1185() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1185").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1185").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1186() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1186").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1186").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1187() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1187").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1187").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1188() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1188").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1188").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1189() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1189").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1189").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1190() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1190").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1190").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1191() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1191").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1191").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1192() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1192").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1192").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1193() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1193").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1193").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1194() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1194").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1194").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1195() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1195").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1195").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1196() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1196").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1196").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1197() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1197").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1197").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1198() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1198").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1198").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1199() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1199").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1199").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsX1200() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1200").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1200").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1201() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1201").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1201").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1202() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1202").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1202").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1203() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1203").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1203").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1204() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1204").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1204").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1205() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1205").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1205").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1206() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1206").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1206").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1207() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1207").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1207").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1208() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1208").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1208").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1209() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1209").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1209").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1210() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1210").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1210").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1211() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1211").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1211").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1212() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1212").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1212").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1213() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1213").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1213").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1214() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1214").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1214").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1215() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1215").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1215").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1216() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1216").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1216").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1217() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1217").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1217").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1218() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1218").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1218").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1219() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1219").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1219").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1220() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1220").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1220").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1221() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1221").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1221").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1222() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1222").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1222").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1223() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1223").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1223").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1224() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1224").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1224").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1225() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1225").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1225").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1226() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1226").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1226").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1227() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1227").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1227").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1228() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1228").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1228").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1229() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1229").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1229").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1230() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1230").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1230").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1231() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1231").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1231").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1232() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1232").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1232").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1233() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1233").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1233").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1234() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1234").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1234").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1235() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1235").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1235").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1236() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1236").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1236").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1237() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1237").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1237").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1238() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1238").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1238").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1239() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1239").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1239").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1240() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1240").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1240").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1241() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1241").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1241").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1242() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1242").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1242").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1243() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1243").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1243").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1244() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1244").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1244").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1245() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1245").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1245").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1246() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1246").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1246").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1247() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1247").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1247").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1248() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1248").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1248").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1249() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1249").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1249").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsY1250() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1250").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1250").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1251() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1251").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1251").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1252() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1252").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1252").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1253() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1253").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1253").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1254() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1254").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1254").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1255() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1255").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1255").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1256() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1256").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1256").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1257() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1257").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1257").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1258() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1258").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1258").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1259() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1259").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1259").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1260() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1260").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1260").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1261() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1261").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1261").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1262() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1262").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1262").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1263() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1263").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1263").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1264() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1264").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1264").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1265() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1265").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1265").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1266() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1266").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1266").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1267() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1267").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1267").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1268() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1268").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1268").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1269() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1269").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1269").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1270() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1270").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1270").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1271() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1271").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1271").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1272() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1272").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1272").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1273() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1273").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1273").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1274() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1274").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1274").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1275() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1275").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1275").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1276() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1276").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1276").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1277() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1277").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1277").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1278() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1278").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1278").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1279() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1279").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1279").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1280() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1280").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1280").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1281() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1281").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1281").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1282() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1282").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1282").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1283() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1283").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1283").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1284() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1284").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1284").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1285() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1285").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1285").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1286() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1286").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1286").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1287() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1287").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1287").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1288() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1288").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1288").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1289() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1289").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1289").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1290() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1290").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1290").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1291() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1291").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1291").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1292() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1292").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1292").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1293() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1293").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1293").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1294() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1294").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1294").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1295() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1295").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1295").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1296() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1296").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1296").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1297() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1297").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1297").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1298() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1298").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1298").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1299() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1299").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1299").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsAA1300() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1300").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1300").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1301() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1301").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1301").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1302() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1302").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1302").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1303() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1303").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1303").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1304() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1304").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1304").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1305() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1305").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1305").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1306() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1306").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1306").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1307() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1307").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1307").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1308() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1308").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1308").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1309() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1309").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1309").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1310() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1310").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1310").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1311() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1311").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1311").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1312() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1312").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1312").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1313() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1313").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1313").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1314() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1314").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1314").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1315() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1315").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1315").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1316() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1316").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1316").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1317() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1317").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1317").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1318() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1318").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1318").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1319() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1319").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1319").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1320() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1320").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1320").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1321() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1321").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1321").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1322() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1322").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1322").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1323() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1323").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1323").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1324() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1324").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1324").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB1325() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1325").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1325").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1326() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1326").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1326").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1327() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1327").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1327").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1328() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1328").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1328").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1329() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1329").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1329").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1330() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1330").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1330").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1331() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1331").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1331").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1332() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1332").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1332").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1333() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1333").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1333").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1334() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1334").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1334").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1335() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1335").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1335").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1336() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1336").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1336").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1337() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1337").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1337").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1338() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1338").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1338").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1339() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1339").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1339").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1340() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1340").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1340").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1341() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1341").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1341").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1342() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1342").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1342").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1343() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1343").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1343").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1344() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1344").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1344").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1345() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1345").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1345").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1346() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1346").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1346").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1347() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1347").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1347").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1348() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1348").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1348").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1349() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1349").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1349").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsBA1350() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1350").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1350").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1351() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1351").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1351").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1352() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1352").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1352").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1353() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1353").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1353").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1354() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1354").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1354").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1355() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1355").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1355").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1356() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1356").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1356").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1357() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1357").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1357").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1358() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1358").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1358").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1359() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1359").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1359").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1360() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1360").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1360").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1361() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1361").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1361").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1362() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1362").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1362").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1363() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1363").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1363").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1364() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1364").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1364").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1365() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1365").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1365").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1366() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1366").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1366").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1367() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1367").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1367").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1368() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1368").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1368").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1369() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1369").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1369").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1370() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1370").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1370").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1371() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1371").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1371").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1372() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1372").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1372").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1373() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1373").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1373").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1374() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1374").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1374").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1375() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1375").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1375").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1376() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1376").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1376").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1377() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1377").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1377").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1378() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1378").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1378").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1379() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1379").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1379").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1380() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1380").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1380").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1381() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1381").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1381").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1382() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1382").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1382").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1383() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1383").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1383").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1384() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1384").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1384").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1385() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1385").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1385").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1386() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1386").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1386").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1387() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1387").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1387").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1388() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1388").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1388").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1389() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1389").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1389").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1390() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1390").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1390").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1391() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1391").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1391").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1392() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1392").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1392").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1393() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1393").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1393").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1394() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1394").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1394").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1395() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1395").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1395").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1396() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1396").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1396").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1397() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1397").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1397").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1398() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1398").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1398").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1399() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1399").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1399").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsCA1400() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1400").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1400").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1401() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1401").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1401").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1402() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1402").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1402").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1403() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1403").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1403").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1404() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1404").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1404").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1405() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1405").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1405").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1406() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1406").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1406").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1407() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1407").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1407").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1408() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1408").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1408").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1409() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1409").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1409").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1410() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1410").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1410").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1411() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1411").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1411").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1412() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1412").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1412").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1413() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1413").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1413").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1414() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1414").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1414").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1415() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1415").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1415").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1416() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1416").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1416").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1417() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1417").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1417").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1418() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1418").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1418").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1419() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1419").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1419").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1420() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1420").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1420").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1421() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1421").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1421").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1422() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1422").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1422").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1423() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1423").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1423").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1424() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1424").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1424").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1425() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1425").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1425").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1426() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1426").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1426").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1427() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1427").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1427").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1428() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1428").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1428").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1429() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1429").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1429").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1430() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1430").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1430").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1431() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1431").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1431").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1432() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1432").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1432").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1433() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1433").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1433").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1434() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1434").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1434").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1435() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1435").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1435").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1436() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1436").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1436").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1437() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1437").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1437").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1438() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1438").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1438").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1439() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1439").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1439").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1440() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1440").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1440").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1441() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1441").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1441").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1442() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1442").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1442").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1443() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1443").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1443").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1444() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1444").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1444").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1445() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1445").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1445").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1446() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1446").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1446").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1447() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1447").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1447").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1448() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1448").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1448").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1449() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1449").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1449").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsDA1450() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1450").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1450").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1451() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1451").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1451").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1452() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1452").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1452").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1453() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1453").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1453").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1454() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1454").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1454").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1455() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1455").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1455").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1456() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1456").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1456").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1457() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1457").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1457").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1458() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1458").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1458").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1459() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1459").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1459").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1460() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1460").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1460").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1461() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1461").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1461").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1462() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1462").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1462").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1463() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1463").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1463").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1464() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1464").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1464").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1465() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1465").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1465").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1466() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1466").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1466").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1467() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1467").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1467").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1468() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1468").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1468").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1469() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1469").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1469").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1470() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1470").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1470").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1471() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1471").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1471").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1472() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1472").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1472").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1473() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1473").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1473").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1474() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1474").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1474").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1475() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1475").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1475").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1476() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1476").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1476").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1477() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1477").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1477").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1478() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1478").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1478").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1479() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1479").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1479").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1480() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1480").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1480").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1481() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1481").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1481").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1482() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1482").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1482").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1483() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1483").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1483").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1484() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1484").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1484").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1485() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1485").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1485").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1486() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1486").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1486").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1487() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1487").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1487").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1488() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1488").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1488").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1489() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1489").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1489").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1490() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1490").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1490").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1491() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1491").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1491").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1492() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1492").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1492").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1493() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1493").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1493").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1494() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1494").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1494").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1495() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1495").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1495").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1496() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1496").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1496").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1497() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1497").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1497").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1498() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1498").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1498").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1499() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1499").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1499").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsEA1500() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1500").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1500").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1501() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1501").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1501").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1502() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1502").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1502").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1503() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1503").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1503").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1504() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1504").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1504").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1505() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1505").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1505").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1506() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1506").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1506").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1507() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1507").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1507").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1508() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1508").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1508").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1509() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1509").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1509").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1510() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1510").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1510").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1511() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1511").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1511").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1512() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1512").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1512").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1513() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1513").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1513").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1514() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1514").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1514").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1515() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1515").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1515").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1516() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1516").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1516").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1517() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1517").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1517").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1518() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1518").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1518").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1519() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1519").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1519").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1520() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1520").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1520").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1521() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1521").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1521").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1522() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1522").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1522").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1523() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1523").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1523").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1524() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1524").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1524").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1525() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1525").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1525").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1526() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1526").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1526").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1527() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1527").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1527").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1528() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1528").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1528").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1529() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1529").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1529").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1530() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1530").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1530").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1531() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1531").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1531").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1532() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1532").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1532").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1533() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1533").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1533").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1534() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1534").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1534").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1535() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1535").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1535").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1536() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1536").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1536").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1537() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1537").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1537").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1538() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1538").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1538").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1539() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1539").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1539").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1540() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1540").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1540").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1541() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1541").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1541").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1542() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1542").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1542").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1543() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1543").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1543").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1544() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1544").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1544").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1545() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1545").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1545").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1546() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1546").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1546").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1547() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1547").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1547").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1548() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1548").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1548").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1549() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1549").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1549").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsFA1550() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1550").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1550").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1551() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1551").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1551").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1552() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1552").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1552").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1553() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1553").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1553").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1554() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1554").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1554").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1555() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1555").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1555").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1556() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1556").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1556").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1557() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1557").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1557").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1558() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1558").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1558").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1559() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1559").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1559").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1560() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1560").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1560").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1561() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1561").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1561").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1562() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1562").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1562").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1563() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1563").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1563").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1564() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1564").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1564").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1565() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1565").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1565").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1566() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1566").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1566").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1567() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1567").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1567").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1568() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1568").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1568").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1569() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1569").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1569").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1570() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1570").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1570").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1571() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1571").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1571").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1572() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1572").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1572").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1573() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1573").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1573").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1574() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1574").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1574").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1575() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1575").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1575").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1576() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1576").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1576").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1577() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1577").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1577").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1578() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1578").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1578").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1579() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1579").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1579").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1580() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1580").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1580").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1581() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1581").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1581").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1582() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1582").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1582").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1583() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1583").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1583").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1584() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1584").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1584").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1585() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1585").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1585").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1586() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1586").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1586").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1587() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1587").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1587").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1588() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1588").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1588").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1589() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1589").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1589").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1590() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1590").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1590").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1591() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1591").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1591").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1592() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1592").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1592").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1593() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1593").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1593").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1594() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1594").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1594").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1595() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1595").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1595").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1596() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1596").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1596").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1597() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1597").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1597").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1598() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1598").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1598").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1599() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1599").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1599").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsGA1600() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1600").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1600").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1601() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1601").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1601").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1602() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1602").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1602").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1603() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1603").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1603").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1604() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1604").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1604").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1605() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1605").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1605").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1606() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1606").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1606").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1607() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1607").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1607").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1608() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1608").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1608").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1609() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1609").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1609").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1610() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1610").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1610").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1611() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1611").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1611").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1612() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1612").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1612").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1613() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1613").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1613").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1614() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1614").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1614").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1615() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1615").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1615").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1616() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1616").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1616").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1617() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1617").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1617").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1618() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1618").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1618").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1619() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1619").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1619").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1620() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1620").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1620").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1621() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1621").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1621").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1622() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1622").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1622").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1623() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1623").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1623").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1624() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1624").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1624").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1625() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1625").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1625").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1626() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1626").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1626").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1627() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1627").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1627").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1628() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1628").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1628").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1629() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1629").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1629").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1630() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1630").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1630").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1631() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1631").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1631").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1632() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1632").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1632").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1633() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1633").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1633").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1634() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1634").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1634").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1635() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1635").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1635").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1636() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1636").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1636").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1637() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1637").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1637").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1638() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1638").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1638").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1639() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1639").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1639").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1640() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1640").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1640").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1641() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1641").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1641").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1642() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1642").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1642").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1643() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1643").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1643").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1644() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1644").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1644").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1645() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1645").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1645").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1646() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1646").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1646").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1647() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1647").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1647").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1648() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1648").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1648").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1649() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1649").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1649").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsHA1650() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1650").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1650").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1651() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1651").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1651").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1652() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1652").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1652").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1653() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1653").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1653").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1654() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1654").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1654").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1655() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1655").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1655").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1656() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1656").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1656").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1657() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1657").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1657").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1658() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1658").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1658").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1659() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1659").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1659").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1660() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1660").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1660").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1661() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1661").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1661").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1662() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1662").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1662").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1663() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1663").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1663").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1664() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1664").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1664").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1665() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1665").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1665").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1666() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1666").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1666").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1667() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1667").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1667").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1668() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1668").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1668").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1669() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1669").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1669").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1670() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1670").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1670").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1671() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1671").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1671").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1672() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1672").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1672").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1673() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1673").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1673").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1674() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1674").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1674").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1675() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1675").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1675").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1676() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1676").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1676").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1677() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1677").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1677").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1678() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1678").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1678").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1679() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1679").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1679").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1680() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1680").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1680").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1681() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1681").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1681").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1682() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1682").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1682").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1683() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1683").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1683").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1684() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1684").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1684").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1685() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1685").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1685").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1686() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1686").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1686").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1687() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1687").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1687").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1688() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1688").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1688").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1689() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1689").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1689").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1690() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1690").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1690").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1691() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1691").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1691").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1692() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1692").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1692").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1693() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1693").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1693").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1694() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1694").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1694").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1695() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1695").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1695").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1696() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1696").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1696").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1697() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1697").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1697").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1698() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1698").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1698").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1699() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1699").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1699").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsIA1700() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1700").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1700").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1701() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1701").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1701").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1702() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1702").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1702").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1703() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1703").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1703").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1704() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1704").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1704").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1705() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1705").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1705").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1706() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1706").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1706").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1707() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1707").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1707").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1708() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1708").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1708").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1709() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1709").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1709").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1710() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1710").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1710").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1711() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1711").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1711").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1712() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1712").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1712").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1713() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1713").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1713").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1714() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1714").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1714").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1715() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1715").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1715").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1716() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1716").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1716").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1717() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1717").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1717").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1718() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1718").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1718").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1719() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1719").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1719").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1720() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1720").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1720").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1721() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1721").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1721").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1722() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1722").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1722").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1723() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1723").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1723").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1724() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1724").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1724").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1725() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1725").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1725").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1726() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1726").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1726").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1727() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1727").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1727").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1728() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1728").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1728").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1729() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1729").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1729").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1730() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1730").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1730").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1731() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1731").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1731").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1732() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1732").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1732").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1733() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1733").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1733").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1734() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1734").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1734").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1735() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1735").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1735").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1736() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1736").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1736").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1737() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1737").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1737").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1738() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1738").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1738").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1739() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1739").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1739").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1740() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1740").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1740").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1741() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1741").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1741").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1742() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1742").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1742").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1743() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1743").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1743").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1744() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1744").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1744").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1745() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1745").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1745").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1746() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1746").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1746").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1747() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1747").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1747").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1748() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1748").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1748").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1749() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1749").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1749").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJA1750() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1750").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1750").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1751() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1751").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1751").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1752() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1752").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1752").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1753() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1753").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1753").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1754() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1754").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1754").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1755() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1755").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1755").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1756() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1756").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1756").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1757() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1757").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1757").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1758() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1758").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1758").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1759() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1759").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1759").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1760() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1760").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1760").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1761() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1761").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1761").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1762() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1762").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1762").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1763() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1763").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1763").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1764() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1764").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1764").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1765() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1765").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1765").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1766() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1766").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1766").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1767() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1767").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1767").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1768() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1768").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1768").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1769() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1769").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1769").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1770() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1770").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1770").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1771() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1771").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1771").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1772() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1772").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1772").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1773() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1773").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1773").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1774() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1774").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1774").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1775() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1775").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1775").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1776() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1776").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1776").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1777() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1777").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1777").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1778() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1778").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1778").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1779() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1779").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1779").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1780() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1780").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1780").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1781() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1781").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1781").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1782() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1782").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1782").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1783() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1783").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1783").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1784() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1784").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1784").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1785() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1785").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1785").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1786() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1786").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1786").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1787() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1787").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1787").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1788() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1788").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1788").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1789() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1789").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1789").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1790() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1790").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1790").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1791() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1791").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1791").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1792() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1792").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1792").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1793() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1793").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1793").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1794() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1794").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1794").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1795() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1795").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1795").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1796() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1796").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1796").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1797() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1797").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1797").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1798() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1798").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1798").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1799() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1799").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1799").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsKA1800() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1800").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1800").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1801() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1801").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1801").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1802() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1802").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1802").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1803() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1803").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1803").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1804() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1804").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1804").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1805() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1805").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1805").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1806() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1806").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1806").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1807() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1807").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1807").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1808() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1808").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1808").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1809() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1809").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1809").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1810() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1810").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1810").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1811() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1811").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1811").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1812() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1812").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1812").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1813() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1813").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1813").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1814() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1814").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1814").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1815() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1815").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1815").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1816() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1816").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1816").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1817() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1817").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1817").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1818() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1818").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1818").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1819() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1819").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1819").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1820() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1820").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1820").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1821() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1821").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1821").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1822() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1822").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1822").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1823() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1823").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1823").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1824() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1824").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1824").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1825() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1825").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1825").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1826() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1826").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1826").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1827() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1827").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1827").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1828() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1828").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1828").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1829() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1829").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1829").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1830() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1830").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1830").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1831() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1831").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1831").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1832() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1832").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1832").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1833() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1833").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1833").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1834() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1834").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1834").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1835() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1835").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1835").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1836() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1836").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1836").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1837() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1837").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1837").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1838() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1838").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1838").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1839() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1839").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1839").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1840() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1840").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1840").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1841() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1841").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1841").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1842() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1842").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1842").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1843() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1843").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1843").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1844() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1844").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1844").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1845() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1845").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1845").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1846() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1846").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1846").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1847() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1847").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1847").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1848() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1848").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1848").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1849() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1849").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1849").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsLA1850() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1850").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1850").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1851() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1851").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1851").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1852() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1852").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1852").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1853() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1853").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1853").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1854() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1854").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1854").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1855() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1855").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1855").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1856() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1856").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1856").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1857() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1857").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1857").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1858() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1858").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1858").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1859() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1859").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1859").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1860() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1860").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1860").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1861() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1861").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1861").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1862() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1862").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1862").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1863() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1863").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1863").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1864() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1864").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1864").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1865() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1865").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1865").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1866() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1866").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1866").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1867() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1867").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1867").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1868() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1868").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1868").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1869() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1869").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1869").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1870() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1870").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1870").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1871() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1871").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1871").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1872() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1872").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1872").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1873() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1873").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1873").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1874() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1874").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1874").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1875() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1875").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1875").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1876() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1876").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1876").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1877() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1877").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1877").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1878() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1878").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1878").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1879() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1879").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1879").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1880() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1880").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1880").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1881() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1881").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1881").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1882() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1882").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1882").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1883() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1883").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1883").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1884() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1884").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1884").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1885() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1885").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1885").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1886() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1886").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1886").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1887() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1887").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1887").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1888() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1888").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1888").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1889() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1889").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1889").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1890() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1890").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1890").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1891() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1891").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1891").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1892() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1892").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1892").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1893() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1893").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1893").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1894() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1894").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1894").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1895() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1895").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1895").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1896() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1896").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1896").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1897() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1897").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1897").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1898() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1898").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1898").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1899() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1899").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1899").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsMA1900() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1900").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1900").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1901() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1901").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1901").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1902() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1902").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1902").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1903() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1903").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1903").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1904() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1904").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1904").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1905() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1905").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1905").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1906() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1906").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1906").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1907() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1907").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1907").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1908() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1908").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1908").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1909() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1909").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1909").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1910() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1910").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1910").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1911() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1911").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1911").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1912() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1912").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1912").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1913() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1913").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1913").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1914() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1914").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1914").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1915() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1915").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1915").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1916() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1916").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1916").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1917() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1917").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1917").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1918() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1918").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1918").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1919() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1919").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1919").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1920() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1920").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1920").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1921() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1921").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1921").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1922() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1922").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1922").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1923() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1923").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1923").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1924() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1924").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1924").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1925() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1925").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1925").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1926() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1926").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1926").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1927() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1927").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1927").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1928() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1928").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1928").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1929() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1929").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1929").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1930() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1930").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1930").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1931() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1931").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1931").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1932() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1932").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1932").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1933() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1933").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1933").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1934() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1934").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1934").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1935() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1935").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1935").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1936() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1936").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1936").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1937() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1937").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1937").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1938() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1938").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1938").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1939() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1939").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1939").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1940() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1940").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1940").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1941() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1941").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1941").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1942() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1942").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1942").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1943() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1943").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1943").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1944() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1944").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1944").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1945() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1945").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1945").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1946() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1946").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1946").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1947() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1947").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1947").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1948() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1948").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1948").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1949() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1949").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1949").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsNA1950() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1950").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1950").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1951() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1951").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1951").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1952() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1952").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1952").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1953() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1953").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1953").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1954() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1954").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1954").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1955() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1955").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1955").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1956() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1956").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1956").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1957() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1957").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1957").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1958() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1958").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1958").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1959() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1959").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1959").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1960() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1960").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1960").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1961() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1961").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1961").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1962() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1962").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1962").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1963() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1963").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1963").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1964() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1964").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1964").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1965() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1965").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1965").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1966() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1966").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1966").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1967() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1967").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1967").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1968() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1968").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1968").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1969() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1969").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1969").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1970() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1970").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1970").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1971() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1971").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1971").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1972() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1972").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1972").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1973() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1973").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1973").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1974() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1974").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1974").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1975() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1975").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1975").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1976() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1976").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1976").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1977() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1977").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1977").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1978() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1978").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1978").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1979() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1979").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1979").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1980() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1980").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1980").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1981() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1981").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1981").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1982() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1982").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1982").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1983() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1983").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1983").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1984() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1984").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1984").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1985() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1985").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1985").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1986() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1986").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1986").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1987() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1987").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1987").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1988() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1988").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1988").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1989() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1989").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1989").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1990() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1990").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1990").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1991() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1991").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1991").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1992() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1992").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1992").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1993() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1993").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1993").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1994() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1994").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1994").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1995() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1995").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1995").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1996() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1996").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1996").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1997() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1997").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1997").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1998() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1998").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1998").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA1999() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1999").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1999").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsOA2000() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2000").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2000").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsPA2001() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2001").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2001").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsPA2002() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2002").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2002").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsPA2003() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2003").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2003").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsPA2004() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2004").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2004").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsPA2005() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2005").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2005").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsPA2006() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2006").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2006").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsPA2007() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2007").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2007").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsPA2008() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2008").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2008").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsPA2009() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2009").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2009").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsPA2010() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2010").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2010").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsPA2011() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2011").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2011").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsPA2012() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2012").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2012").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsPA2013() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2013").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2013").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsPA2014() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2014").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2014").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsPA2015() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2015").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2015").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsPA2016() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2016").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2016").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsPA2017() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2017").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2017").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsPA2018() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2018").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2018").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsPA2019() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2019").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2019").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsPA2020() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2020").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2020").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsPA2021() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2021").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2021").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsPA2022() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2022").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2022").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsPA2023() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2023").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2023").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsPA2024() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2024").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2024").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsPA2025() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2025").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2025").src = "img/sqrs/wSqr.png"
};};};