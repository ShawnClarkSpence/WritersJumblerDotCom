function aZsqrsA1() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs1").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA2() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs2").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA3() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs3").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs3").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA4() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs4").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs4").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA5() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs5").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs5").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA6() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs6").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs6").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA7() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs7").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs7").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA8() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs8").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs8").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA9() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs9").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs9").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA10() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs10").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs10").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA11() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs11").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs11").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA12() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs12").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs12").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA13() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs13").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs13").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA14() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs14").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs14").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA15() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs15").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs15").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA16() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs16").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs16").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA17() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs17").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs17").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA18() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs18").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs18").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA19() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs19").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs19").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA20() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs20").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs20").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA21() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs21").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs21").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA22() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs22").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs22").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA23() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs23").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs23").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA24() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs24").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs24").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA25() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs25").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs25").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA26() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs26").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs26").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA27() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs27").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs27").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA28() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs28").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs28").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA29() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs29").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs29").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA30() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs30").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs30").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA31() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs31").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs31").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA32() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs32").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs32").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA33() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs33").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs33").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA34() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs34").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs34").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA35() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs35").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs35").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA36() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs36").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs36").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA37() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs37").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs37").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA38() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs38").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs38").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA39() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs39").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs39").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA40() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs40").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs40").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA41() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs41").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs41").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA42() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs42").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs42").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA43() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs43").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs43").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA44() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs44").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs44").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA45() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs45").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs45").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA46() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs46").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs46").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA47() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs47").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs47").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA48() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs48").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs48").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA49() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs49").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs49").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA50() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs50").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs50").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB51() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs51").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs51").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB52() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs52").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs52").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB53() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs53").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs53").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB54() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs54").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs54").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB55() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs55").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs55").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB56() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs56").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs56").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB57() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs57").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs57").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB58() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs58").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs58").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB59() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs59").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs59").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB60() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs60").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs60").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB61() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs61").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs61").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB62() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs62").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs62").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB63() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs63").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs63").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB64() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs64").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs64").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB65() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs65").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs65").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB66() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs66").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs66").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB67() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs67").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs67").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB68() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs68").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs68").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB69() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs69").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs69").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB70() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs70").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs70").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB71() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs71").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs71").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB72() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs72").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs72").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB73() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs73").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs73").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB74() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs74").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs74").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB75() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs75").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs75").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB76() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs76").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs76").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB77() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs77").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs77").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB78() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs78").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs78").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB79() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs79").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs79").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB80() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs80").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs80").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB81() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs81").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs81").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB82() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs82").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs82").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB83() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs83").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs83").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB84() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs84").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs84").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB85() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs85").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs85").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB86() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs86").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs86").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB87() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs87").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs87").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB88() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs88").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs88").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB89() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs89").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs89").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB90() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs90").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs90").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB91() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs91").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs91").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB92() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs92").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs92").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB93() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs93").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs93").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB94() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs94").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs94").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB95() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs95").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs95").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB96() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs96").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs96").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB97() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs97").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs97").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB98() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs98").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs98").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB99() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs99").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs99").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB100() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs100").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs100").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC101() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs101").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs101").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC102() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs102").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs102").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC103() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs103").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs103").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC104() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs104").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs104").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC105() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs105").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs105").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC106() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs106").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs106").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC107() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs107").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs107").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC108() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs108").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs108").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC109() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs109").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs109").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC110() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs110").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs110").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC111() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs111").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs111").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC112() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs112").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs112").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC113() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs113").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs113").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC114() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs114").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs114").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC115() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs115").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs115").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC116() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs116").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs116").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC117() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs117").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs117").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC118() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs118").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs118").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC119() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs119").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs119").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC120() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs120").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs120").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC121() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs121").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs121").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC122() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs122").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs122").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC123() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs123").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs123").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC124() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs124").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs124").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC125() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs125").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs125").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC126() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs126").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs126").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC127() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs127").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs127").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC128() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs128").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs128").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC129() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs129").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs129").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC130() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs130").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs130").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC131() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs131").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs131").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC132() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs132").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs132").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC133() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs133").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs133").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC134() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs134").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs134").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC135() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs135").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs135").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC136() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs136").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs136").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC137() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs137").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs137").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC138() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs138").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs138").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC139() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs139").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs139").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC140() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs140").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs140").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC141() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs141").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs141").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC142() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs142").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs142").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC143() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs143").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs143").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC144() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs144").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs144").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC145() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs145").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs145").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC146() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs146").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs146").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC147() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs147").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs147").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC148() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs148").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs148").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC149() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs149").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs149").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC150() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs150").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs150").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD151() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs151").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs151").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD152() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs152").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs152").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD153() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs153").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs153").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD154() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs154").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs154").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD155() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs155").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs155").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD156() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs156").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs156").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD157() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs157").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs157").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD158() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs158").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs158").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD159() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs159").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs159").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD160() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs160").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs160").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD161() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs161").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs161").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD162() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs162").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs162").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD163() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs163").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs163").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD164() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs164").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs164").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD165() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs165").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs165").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD166() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs166").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs166").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD167() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs167").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs167").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD168() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs168").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs168").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD169() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs169").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs169").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD170() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs170").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs170").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD171() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs171").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs171").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD172() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs172").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs172").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD173() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs173").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs173").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD174() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs174").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs174").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD175() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs175").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs175").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD176() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs176").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs176").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD177() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs177").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs177").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD178() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs178").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs178").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD179() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs179").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs179").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD180() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs180").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs180").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD181() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs181").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs181").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD182() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs182").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs182").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD183() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs183").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs183").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD184() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs184").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs184").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD185() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs185").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs185").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD186() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs186").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs186").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD187() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs187").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs187").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD188() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs188").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs188").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD189() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs189").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs189").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD190() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs190").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs190").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD191() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs191").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs191").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD192() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs192").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs192").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD193() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs193").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs193").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD194() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs194").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs194").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD195() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs195").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs195").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD196() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs196").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs196").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD197() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs197").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs197").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD198() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs198").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs198").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD199() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs199").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs199").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD200() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs200").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs200").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE201() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs201").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs201").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE202() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs202").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs202").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE203() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs203").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs203").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE204() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs204").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs204").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE205() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs205").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs205").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE206() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs206").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs206").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE207() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs207").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs207").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE208() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs208").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs208").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE209() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs209").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs209").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE210() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs210").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs210").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE211() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs211").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs211").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE212() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs212").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs212").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE213() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs213").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs213").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE214() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs214").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs214").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE215() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs215").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs215").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE216() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs216").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs216").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE217() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs217").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs217").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE218() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs218").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs218").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE219() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs219").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs219").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE220() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs220").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs220").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE221() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs221").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs221").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE222() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs222").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs222").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE223() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs223").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs223").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE224() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs224").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs224").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE225() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs225").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs225").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE226() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs226").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs226").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE227() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs227").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs227").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE228() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs228").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs228").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE229() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs229").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs229").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE230() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs230").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs230").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE231() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs231").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs231").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE232() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs232").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs232").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE233() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs233").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs233").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE234() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs234").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs234").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE235() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs235").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs235").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE236() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs236").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs236").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE237() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs237").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs237").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE238() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs238").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs238").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE239() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs239").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs239").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE240() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs240").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs240").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE241() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs241").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs241").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE242() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs242").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs242").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE243() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs243").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs243").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE244() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs244").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs244").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE245() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs245").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs245").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE246() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs246").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs246").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE247() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs247").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs247").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE248() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs248").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs248").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE249() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs249").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs249").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE250() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs250").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs250").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF251() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs251").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs251").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF252() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs252").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs252").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF253() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs253").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs253").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF254() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs254").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs254").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF255() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs255").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs255").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF256() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs256").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs256").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF257() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs257").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs257").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF258() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs258").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs258").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF259() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs259").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs259").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF260() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs260").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs260").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF261() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs261").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs261").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF262() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs262").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs262").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF263() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs263").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs263").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF264() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs264").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs264").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF265() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs265").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs265").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF266() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs266").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs266").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF267() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs267").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs267").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF268() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs268").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs268").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF269() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs269").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs269").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF270() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs270").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs270").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF271() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs271").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs271").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF272() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs272").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs272").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF273() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs273").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs273").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF274() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs274").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs274").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF275() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs275").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs275").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF276() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs276").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs276").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF277() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs277").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs277").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF278() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs278").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs278").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF279() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs279").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs279").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF280() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs280").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs280").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF281() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs281").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs281").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF282() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs282").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs282").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF283() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs283").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs283").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF284() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs284").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs284").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF285() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs285").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs285").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF286() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs286").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs286").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF287() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs287").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs287").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF288() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs288").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs288").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF289() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs289").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs289").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF290() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs290").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs290").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF291() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs291").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs291").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF292() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs292").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs292").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF293() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs293").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs293").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF294() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs294").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs294").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF295() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs295").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs295").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF296() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs296").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs296").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF297() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs297").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs297").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF298() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs298").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs298").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF299() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs299").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs299").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF300() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs300").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs300").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG301() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs301").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs301").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG302() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs302").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs302").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG303() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs303").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs303").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG304() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs304").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs304").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG305() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs305").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs305").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG306() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs306").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs306").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG307() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs307").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs307").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG308() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs308").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs308").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG309() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs309").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs309").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG310() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs310").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs310").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG311() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs311").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs311").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG312() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs312").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs312").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG313() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs313").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs313").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG314() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs314").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs314").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG315() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs315").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs315").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG316() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs316").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs316").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG317() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs317").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs317").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG318() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs318").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs318").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG319() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs319").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs319").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG320() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs320").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs320").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG321() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs321").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs321").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG322() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs322").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs322").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG323() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs323").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs323").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG324() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs324").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs324").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG325() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs325").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs325").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG326() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs326").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs326").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG327() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs327").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs327").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG328() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs328").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs328").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG329() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs329").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs329").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG330() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs330").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs330").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG331() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs331").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs331").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG332() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs332").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs332").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG333() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs333").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs333").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG334() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs334").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs334").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG335() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs335").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs335").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG336() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs336").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs336").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG337() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs337").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs337").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG338() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs338").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs338").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG339() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs339").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs339").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG340() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs340").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs340").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG341() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs341").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs341").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG342() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs342").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs342").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG343() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs343").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs343").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG344() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs344").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs344").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG345() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs345").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs345").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG346() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs346").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs346").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG347() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs347").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs347").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG348() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs348").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs348").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG349() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs349").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs349").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG350() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs350").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs350").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH351() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs351").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs351").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH352() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs352").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs352").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH353() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs353").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs353").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH354() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs354").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs354").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH355() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs355").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs355").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH356() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs356").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs356").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH357() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs357").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs357").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH358() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs358").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs358").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH359() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs359").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs359").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH360() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs360").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs360").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH361() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs361").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs361").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH362() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs362").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs362").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH363() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs363").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs363").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH364() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs364").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs364").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH365() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs365").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs365").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH366() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs366").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs366").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH367() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs367").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs367").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH368() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs368").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs368").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH369() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs369").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs369").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH370() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs370").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs370").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH371() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs371").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs371").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH372() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs372").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs372").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH373() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs373").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs373").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH374() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs374").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs374").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH375() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs375").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs375").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH376() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs376").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs376").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH377() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs377").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs377").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH378() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs378").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs378").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH379() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs379").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs379").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH380() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs380").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs380").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH381() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs381").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs381").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH382() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs382").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs382").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH383() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs383").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs383").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH384() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs384").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs384").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH385() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs385").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs385").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH386() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs386").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs386").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH387() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs387").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs387").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH388() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs388").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs388").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH389() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs389").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs389").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH390() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs390").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs390").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH391() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs391").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs391").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH392() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs392").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs392").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH393() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs393").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs393").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH394() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs394").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs394").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH395() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs395").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs395").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH396() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs396").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs396").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH397() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs397").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs397").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH398() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs398").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs398").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH399() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs399").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs399").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH400() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs400").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs400").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI401() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs401").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs401").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI402() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs402").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs402").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI403() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs403").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs403").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI404() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs404").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs404").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI405() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs405").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs405").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI406() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs406").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs406").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI407() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs407").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs407").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI408() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs408").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs408").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI409() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs409").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs409").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI410() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs410").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs410").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI411() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs411").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs411").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI412() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs412").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs412").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI413() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs413").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs413").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI414() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs414").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs414").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI415() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs415").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs415").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI416() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs416").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs416").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI417() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs417").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs417").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI418() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs418").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs418").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI419() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs419").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs419").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI420() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs420").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs420").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI421() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs421").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs421").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI422() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs422").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs422").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI423() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs423").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs423").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI424() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs424").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs424").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI425() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs425").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs425").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI426() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs426").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs426").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI427() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs427").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs427").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI428() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs428").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs428").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI429() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs429").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs429").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI430() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs430").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs430").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI431() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs431").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs431").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI432() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs432").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs432").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI433() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs433").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs433").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI434() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs434").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs434").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI435() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs435").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs435").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI436() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs436").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs436").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI437() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs437").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs437").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI438() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs438").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs438").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI439() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs439").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs439").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI440() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs440").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs440").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI441() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs441").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs441").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI442() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs442").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs442").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI443() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs443").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs443").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI444() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs444").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs444").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI445() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs445").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs445").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI446() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs446").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs446").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI447() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs447").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs447").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI448() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs448").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs448").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI449() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs449").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs449").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsI450() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs450").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs450").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ451() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs451").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs451").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ452() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs452").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs452").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ453() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs453").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs453").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ454() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs454").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs454").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ455() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs455").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs455").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ456() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs456").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs456").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ457() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs457").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs457").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ458() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs458").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs458").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ459() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs459").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs459").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ460() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs460").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs460").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ461() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs461").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs461").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ462() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs462").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs462").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ463() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs463").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs463").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ464() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs464").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs464").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ465() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs465").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs465").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ466() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs466").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs466").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ467() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs467").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs467").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ468() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs468").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs468").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ469() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs469").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs469").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ470() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs470").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs470").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ471() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs471").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs471").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ472() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs472").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs472").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ473() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs473").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs473").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ474() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs474").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs474").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ475() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs475").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs475").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ476() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs476").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs476").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ477() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs477").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs477").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ478() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs478").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs478").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ479() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs479").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs479").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ480() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs480").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs480").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ481() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs481").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs481").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ482() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs482").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs482").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ483() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs483").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs483").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ484() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs484").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs484").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ485() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs485").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs485").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ486() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs486").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs486").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ487() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs487").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs487").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ488() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs488").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs488").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ489() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs489").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs489").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ490() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs490").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs490").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ491() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs491").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs491").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ492() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs492").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs492").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ493() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs493").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs493").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ494() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs494").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs494").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ495() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs495").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs495").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ496() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs496").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs496").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ497() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs497").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs497").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ498() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs498").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs498").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ499() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs499").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs499").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsJ500() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs500").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs500").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK501() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs501").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs501").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK502() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs502").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs502").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK503() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs503").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs503").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK504() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs504").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs504").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK505() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs505").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs505").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK506() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs506").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs506").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK507() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs507").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs507").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK508() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs508").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs508").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK509() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs509").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs509").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK510() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs510").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs510").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK511() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs511").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs511").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK512() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs512").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs512").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK513() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs513").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs513").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK514() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs514").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs514").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK515() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs515").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs515").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK516() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs516").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs516").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK517() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs517").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs517").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK518() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs518").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs518").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK519() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs519").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs519").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK520() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs520").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs520").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK521() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs521").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs521").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK522() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs522").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs522").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK523() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs523").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs523").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK524() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs524").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs524").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK525() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs525").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs525").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK526() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs526").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs526").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK527() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs527").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs527").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK528() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs528").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs528").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK529() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs529").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs529").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK530() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs530").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs530").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK531() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs531").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs531").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK532() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs532").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs532").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK533() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs533").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs533").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK534() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs534").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs534").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK535() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs535").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs535").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK536() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs536").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs536").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK537() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs537").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs537").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK538() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs538").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs538").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK539() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs539").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs539").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK540() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs540").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs540").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK541() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs541").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs541").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK542() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs542").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs542").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK543() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs543").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs543").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK544() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs544").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs544").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK545() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs545").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs545").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK546() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs546").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs546").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK547() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs547").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs547").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK548() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs548").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs548").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK549() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs549").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs549").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsK550() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs550").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs550").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL551() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs551").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs551").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL552() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs552").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs552").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL553() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs553").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs553").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL554() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs554").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs554").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL555() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs555").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs555").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL556() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs556").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs556").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL557() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs557").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs557").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL558() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs558").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs558").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL559() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs559").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs559").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL560() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs560").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs560").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL561() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs561").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs561").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL562() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs562").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs562").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL563() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs563").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs563").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL564() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs564").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs564").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL565() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs565").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs565").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL566() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs566").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs566").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL567() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs567").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs567").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL568() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs568").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs568").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL569() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs569").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs569").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL570() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs570").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs570").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL571() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs571").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs571").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL572() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs572").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs572").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL573() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs573").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs573").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL574() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs574").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs574").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL575() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs575").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs575").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL576() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs576").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs576").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL577() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs577").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs577").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL578() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs578").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs578").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL579() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs579").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs579").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL580() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs580").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs580").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL581() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs581").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs581").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL582() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs582").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs582").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL583() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs583").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs583").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL584() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs584").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs584").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL585() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs585").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs585").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL586() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs586").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs586").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL587() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs587").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs587").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL588() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs588").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs588").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL589() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs589").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs589").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL590() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs590").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs590").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL591() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs591").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs591").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL592() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs592").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs592").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL593() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs593").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs593").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL594() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs594").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs594").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL595() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs595").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs595").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL596() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs596").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs596").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL597() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs597").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs597").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL598() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs598").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs598").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL599() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs599").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs599").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsL600() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs600").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs600").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM601() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs601").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs601").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM602() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs602").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs602").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM603() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs603").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs603").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM604() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs604").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs604").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM605() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs605").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs605").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM606() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs606").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs606").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM607() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs607").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs607").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM608() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs608").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs608").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM609() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs609").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs609").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM610() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs610").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs610").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM611() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs611").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs611").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM612() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs612").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs612").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM613() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs613").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs613").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM614() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs614").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs614").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM615() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs615").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs615").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM616() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs616").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs616").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM617() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs617").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs617").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM618() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs618").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs618").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM619() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs619").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs619").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM620() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs620").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs620").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM621() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs621").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs621").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM622() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs622").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs622").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM623() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs623").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs623").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM624() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs624").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs624").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsM625() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqrs625").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs625").src = "img/sqrs/wSqr.png"
};};};
