function asqrsA1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1").src = "img/sqrs/blSqr.png"
};};};
function asqrsA2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs2").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs2").src = "img/sqrs/blSqr.png"
};};};
function asqrsA3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs3").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs3").src = "img/sqrs/blSqr.png"
};};};
function asqrsA4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs4").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs4").src = "img/sqrs/blSqr.png"
};};};
function asqrsA5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs5").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs5").src = "img/sqrs/blSqr.png"
};};};
function asqrsA6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs6").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs6").src = "img/sqrs/blSqr.png"
};};};
function asqrsA7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs7").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs7").src = "img/sqrs/blSqr.png"
};};};
function asqrsA8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs8").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs8").src = "img/sqrs/blSqr.png"
};};};
function asqrsA9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs9").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs9").src = "img/sqrs/blSqr.png"
};};};
function asqrsA10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs10").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs10").src = "img/sqrs/blSqr.png"
};};};
function asqrsA11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs11").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs11").src = "img/sqrs/blSqr.png"
};};};
function asqrsA12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs12").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs12").src = "img/sqrs/blSqr.png"
};};};
function asqrsA13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs13").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs13").src = "img/sqrs/blSqr.png"
};};};
function asqrsA14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs14").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs14").src = "img/sqrs/blSqr.png"
};};};
function asqrsA15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs15").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs15").src = "img/sqrs/blSqr.png"
};};};
function asqrsA16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs16").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs16").src = "img/sqrs/blSqr.png"
};};};
function asqrsA17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs17").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs17").src = "img/sqrs/blSqr.png"
};};};
function asqrsA18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs18").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs18").src = "img/sqrs/blSqr.png"
};};};
function asqrsA19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs19").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs19").src = "img/sqrs/blSqr.png"
};};};
function asqrsA20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs20").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs20").src = "img/sqrs/blSqr.png"
};};};
function asqrsA21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs21").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs21").src = "img/sqrs/blSqr.png"
};};};
function asqrsA22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs22").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs22").src = "img/sqrs/blSqr.png"
};};};
function asqrsA23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs23").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs23").src = "img/sqrs/blSqr.png"
};};};
function asqrsA24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs24").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs24").src = "img/sqrs/blSqr.png"
};};};
function asqrsA25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs25").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs25").src = "img/sqrs/blSqr.png"
};};};
function asqrsB1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs26").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs26").src = "img/sqrs/blSqr.png"
};};};
function asqrsB2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs27").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs27").src = "img/sqrs/blSqr.png"
};};};
function asqrsB3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs28").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs28").src = "img/sqrs/blSqr.png"
};};};
function asqrsB4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs29").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs29").src = "img/sqrs/blSqr.png"
};};};
function asqrsB5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs30").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs30").src = "img/sqrs/blSqr.png"
};};};
function asqrsB6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs31").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs31").src = "img/sqrs/blSqr.png"
};};};
function asqrsB7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs32").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs32").src = "img/sqrs/blSqr.png"
};};};
function asqrsB8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs33").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs33").src = "img/sqrs/blSqr.png"
};};};
function asqrsB9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs34").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs34").src = "img/sqrs/blSqr.png"
};};};
function asqrsB10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs35").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs35").src = "img/sqrs/blSqr.png"
};};};
function asqrsB11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs36").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs36").src = "img/sqrs/blSqr.png"
};};};
function asqrsB12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs37").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs37").src = "img/sqrs/blSqr.png"
};};};
function asqrsB13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs38").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs38").src = "img/sqrs/blSqr.png"
};};};
function asqrsB14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs39").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs39").src = "img/sqrs/blSqr.png"
};};};
function asqrsB15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs40").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs40").src = "img/sqrs/blSqr.png"
};};};
function asqrsB16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs41").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs41").src = "img/sqrs/blSqr.png"
};};};
function asqrsB17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs42").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs42").src = "img/sqrs/blSqr.png"
};};};
function asqrsB18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs43").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs43").src = "img/sqrs/blSqr.png"
};};};
function asqrsB19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs44").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs44").src = "img/sqrs/blSqr.png"
};};};
function asqrsB20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs45").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs45").src = "img/sqrs/blSqr.png"
};};};
function asqrsB21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs46").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs46").src = "img/sqrs/blSqr.png"
};};};
function asqrsB22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs47").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs47").src = "img/sqrs/blSqr.png"
};};};
function asqrsB23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs48").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs48").src = "img/sqrs/blSqr.png"
};};};
function asqrsB24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs49").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs49").src = "img/sqrs/blSqr.png"
};};};
function asqrsB25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs50").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs50").src = "img/sqrs/blSqr.png"
};};};
function asqrsC1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs51").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs51").src = "img/sqrs/blSqr.png"
};};};
function asqrsC2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs52").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs52").src = "img/sqrs/blSqr.png"
};};};
function asqrsC3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs53").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs53").src = "img/sqrs/blSqr.png"
};};};
function asqrsC4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs54").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs54").src = "img/sqrs/blSqr.png"
};};};
function asqrsC5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs55").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs55").src = "img/sqrs/blSqr.png"
};};};
function asqrsC6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs56").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs56").src = "img/sqrs/blSqr.png"
};};};
function asqrsC7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs57").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs57").src = "img/sqrs/blSqr.png"
};};};
function asqrsC8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs58").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs58").src = "img/sqrs/blSqr.png"
};};};
function asqrsC9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs59").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs59").src = "img/sqrs/blSqr.png"
};};};
function asqrsC10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs60").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs60").src = "img/sqrs/blSqr.png"
};};};
function asqrsC11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs61").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs61").src = "img/sqrs/blSqr.png"
};};};
function asqrsC12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs62").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs62").src = "img/sqrs/blSqr.png"
};};};
function asqrsC13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs63").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs63").src = "img/sqrs/blSqr.png"
};};};
function asqrsC14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs64").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs64").src = "img/sqrs/blSqr.png"
};};};
function asqrsC15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs65").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs65").src = "img/sqrs/blSqr.png"
};};};
function asqrsC16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs66").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs66").src = "img/sqrs/blSqr.png"
};};};
function asqrsC17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs67").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs67").src = "img/sqrs/blSqr.png"
};};};
function asqrsC18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs68").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs68").src = "img/sqrs/blSqr.png"
};};};
function asqrsC19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs69").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs69").src = "img/sqrs/blSqr.png"
};};};
function asqrsC20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs70").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs70").src = "img/sqrs/blSqr.png"
};};};
function asqrsC21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs71").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs71").src = "img/sqrs/blSqr.png"
};};};
function asqrsC22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs72").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs72").src = "img/sqrs/blSqr.png"
};};};
function asqrsC23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs73").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs73").src = "img/sqrs/blSqr.png"
};};};
function asqrsC24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs74").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs74").src = "img/sqrs/blSqr.png"
};};};
function asqrsC25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs75").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs75").src = "img/sqrs/blSqr.png"
};};};
function asqrsD1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs76").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs76").src = "img/sqrs/blSqr.png"
};};};
function asqrsD2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs77").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs77").src = "img/sqrs/blSqr.png"
};};};
function asqrsD3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs78").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs78").src = "img/sqrs/blSqr.png"
};};};
function asqrsD4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs79").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs79").src = "img/sqrs/blSqr.png"
};};};
function asqrsD5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs80").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs80").src = "img/sqrs/blSqr.png"
};};};
function asqrsD6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs81").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs81").src = "img/sqrs/blSqr.png"
};};};
function asqrsD7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs82").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs82").src = "img/sqrs/blSqr.png"
};};};
function asqrsD8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs83").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs83").src = "img/sqrs/blSqr.png"
};};};
function asqrsD9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs84").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs84").src = "img/sqrs/blSqr.png"
};};};
function asqrsD10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs85").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs85").src = "img/sqrs/blSqr.png"
};};};
function asqrsD11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs86").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs86").src = "img/sqrs/blSqr.png"
};};};
function asqrsD12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs87").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs87").src = "img/sqrs/blSqr.png"
};};};
function asqrsD13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs88").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs88").src = "img/sqrs/blSqr.png"
};};};
function asqrsD14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs89").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs89").src = "img/sqrs/blSqr.png"
};};};
function asqrsD15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs90").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs90").src = "img/sqrs/blSqr.png"
};};};
function asqrsD16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs91").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs91").src = "img/sqrs/blSqr.png"
};};};
function asqrsD17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs92").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs92").src = "img/sqrs/blSqr.png"
};};};
function asqrsD18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs93").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs93").src = "img/sqrs/blSqr.png"
};};};
function asqrsD19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs94").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs94").src = "img/sqrs/blSqr.png"
};};};
function asqrsD20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs95").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs95").src = "img/sqrs/blSqr.png"
};};};
function asqrsD21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs96").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs96").src = "img/sqrs/blSqr.png"
};};};
function asqrsD22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs97").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs97").src = "img/sqrs/blSqr.png"
};};};
function asqrsD23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs98").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs98").src = "img/sqrs/blSqr.png"
};};};
function asqrsD24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs99").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs99").src = "img/sqrs/blSqr.png"
};};};
function asqrsD25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs100").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs100").src = "img/sqrs/blSqr.png"
};};};
function asqrsE1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs101").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs101").src = "img/sqrs/blSqr.png"
};};};
function asqrsE2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs102").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs102").src = "img/sqrs/blSqr.png"
};};};
function asqrsE3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs103").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs103").src = "img/sqrs/blSqr.png"
};};};
function asqrsE4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs104").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs104").src = "img/sqrs/blSqr.png"
};};};
function asqrsE5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs105").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs105").src = "img/sqrs/blSqr.png"
};};};
function asqrsE6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs106").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs106").src = "img/sqrs/blSqr.png"
};};};
function asqrsE7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs107").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs107").src = "img/sqrs/blSqr.png"
};};};
function asqrsE8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs108").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs108").src = "img/sqrs/blSqr.png"
};};};
function asqrsE9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs109").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs109").src = "img/sqrs/blSqr.png"
};};};
function asqrsE10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs110").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs110").src = "img/sqrs/blSqr.png"
};};};
function asqrsE11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs111").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs111").src = "img/sqrs/blSqr.png"
};};};
function asqrsE12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs112").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs112").src = "img/sqrs/blSqr.png"
};};};
function asqrsE13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs113").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs113").src = "img/sqrs/blSqr.png"
};};};
function asqrsE14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs114").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs114").src = "img/sqrs/blSqr.png"
};};};
function asqrsE15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs115").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs115").src = "img/sqrs/blSqr.png"
};};};
function asqrsE16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs116").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs116").src = "img/sqrs/blSqr.png"
};};};
function asqrsE17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs117").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs117").src = "img/sqrs/blSqr.png"
};};};
function asqrsE18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs118").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs118").src = "img/sqrs/blSqr.png"
};};};
function asqrsE19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs119").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs119").src = "img/sqrs/blSqr.png"
};};};
function asqrsE20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs120").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs120").src = "img/sqrs/blSqr.png"
};};};
function asqrsE21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs121").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs121").src = "img/sqrs/blSqr.png"
};};};
function asqrsE22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs122").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs122").src = "img/sqrs/blSqr.png"
};};};
function asqrsE23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs123").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs123").src = "img/sqrs/blSqr.png"
};};};
function asqrsE24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs124").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs124").src = "img/sqrs/blSqr.png"
};};};
function asqrsE25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs125").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs125").src = "img/sqrs/blSqr.png"
};};};
function asqrsF1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs126").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs126").src = "img/sqrs/blSqr.png"
};};};
function asqrsF2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs127").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs127").src = "img/sqrs/blSqr.png"
};};};
function asqrsF3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs128").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs128").src = "img/sqrs/blSqr.png"
};};};
function asqrsF4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs129").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs129").src = "img/sqrs/blSqr.png"
};};};
function asqrsF5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs130").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs130").src = "img/sqrs/blSqr.png"
};};};
function asqrsF6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs131").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs131").src = "img/sqrs/blSqr.png"
};};};
function asqrsF7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs132").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs132").src = "img/sqrs/blSqr.png"
};};};
function asqrsF8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs133").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs133").src = "img/sqrs/blSqr.png"
};};};
function asqrsF9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs134").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs134").src = "img/sqrs/blSqr.png"
};};};
function asqrsF10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs135").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs135").src = "img/sqrs/blSqr.png"
};};};
function asqrsF11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs136").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs136").src = "img/sqrs/blSqr.png"
};};};
function asqrsF12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs137").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs137").src = "img/sqrs/blSqr.png"
};};};
function asqrsF13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs138").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs138").src = "img/sqrs/blSqr.png"
};};};
function asqrsF14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs139").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs139").src = "img/sqrs/blSqr.png"
};};};
function asqrsF15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs140").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs140").src = "img/sqrs/blSqr.png"
};};};
function asqrsF16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs141").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs141").src = "img/sqrs/blSqr.png"
};};};
function asqrsF17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs142").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs142").src = "img/sqrs/blSqr.png"
};};};
function asqrsF18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs143").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs143").src = "img/sqrs/blSqr.png"
};};};
function asqrsF19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs144").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs144").src = "img/sqrs/blSqr.png"
};};};
function asqrsF20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs145").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs145").src = "img/sqrs/blSqr.png"
};};};
function asqrsF21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs146").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs146").src = "img/sqrs/blSqr.png"
};};};
function asqrsF22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs147").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs147").src = "img/sqrs/blSqr.png"
};};};
function asqrsF23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs148").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs148").src = "img/sqrs/blSqr.png"
};};};
function asqrsF24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs149").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs149").src = "img/sqrs/blSqr.png"
};};};
function asqrsF25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs150").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs150").src = "img/sqrs/blSqr.png"
};};};
function asqrsG1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs151").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs151").src = "img/sqrs/blSqr.png"
};};};
function asqrsG2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs152").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs152").src = "img/sqrs/blSqr.png"
};};};
function asqrsG3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs153").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs153").src = "img/sqrs/blSqr.png"
};};};
function asqrsG4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs154").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs154").src = "img/sqrs/blSqr.png"
};};};
function asqrsG5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs155").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs155").src = "img/sqrs/blSqr.png"
};};};
function asqrsG6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs156").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs156").src = "img/sqrs/blSqr.png"
};};};
function asqrsG7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs157").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs157").src = "img/sqrs/blSqr.png"
};};};
function asqrsG8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs158").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs158").src = "img/sqrs/blSqr.png"
};};};
function asqrsG9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs159").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs159").src = "img/sqrs/blSqr.png"
};};};
function asqrsG10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs160").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs160").src = "img/sqrs/blSqr.png"
};};};
function asqrsG11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs161").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs161").src = "img/sqrs/blSqr.png"
};};};
function asqrsG12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs162").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs162").src = "img/sqrs/blSqr.png"
};};};
function asqrsG13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs163").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs163").src = "img/sqrs/blSqr.png"
};};};
function asqrsG14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs164").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs164").src = "img/sqrs/blSqr.png"
};};};
function asqrsG15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs165").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs165").src = "img/sqrs/blSqr.png"
};};};
function asqrsG16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs166").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs166").src = "img/sqrs/blSqr.png"
};};};
function asqrsG17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs167").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs167").src = "img/sqrs/blSqr.png"
};};};
function asqrsG18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs168").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs168").src = "img/sqrs/blSqr.png"
};};};
function asqrsG19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs169").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs169").src = "img/sqrs/blSqr.png"
};};};
function asqrsG20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs170").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs170").src = "img/sqrs/blSqr.png"
};};};
function asqrsG21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs171").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs171").src = "img/sqrs/blSqr.png"
};};};
function asqrsG22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs172").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs172").src = "img/sqrs/blSqr.png"
};};};
function asqrsG23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs173").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs173").src = "img/sqrs/blSqr.png"
};};};
function asqrsG24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs174").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs174").src = "img/sqrs/blSqr.png"
};};};
function asqrsG25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs175").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs175").src = "img/sqrs/blSqr.png"
};};};
function asqrsH1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs176").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs176").src = "img/sqrs/blSqr.png"
};};};
function asqrsH2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs177").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs177").src = "img/sqrs/blSqr.png"
};};};
function asqrsH3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs178").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs178").src = "img/sqrs/blSqr.png"
};};};
function asqrsH4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs179").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs179").src = "img/sqrs/blSqr.png"
};};};
function asqrsH5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs180").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs180").src = "img/sqrs/blSqr.png"
};};};
function asqrsH6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs181").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs181").src = "img/sqrs/blSqr.png"
};};};
function asqrsH7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs182").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs182").src = "img/sqrs/blSqr.png"
};};};
function asqrsH8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs183").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs183").src = "img/sqrs/blSqr.png"
};};};
function asqrsH9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs184").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs184").src = "img/sqrs/blSqr.png"
};};};
function asqrsH10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs185").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs185").src = "img/sqrs/blSqr.png"
};};};
function asqrsH11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs186").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs186").src = "img/sqrs/blSqr.png"
};};};
function asqrsH12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs187").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs187").src = "img/sqrs/blSqr.png"
};};};
function asqrsH13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs188").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs188").src = "img/sqrs/blSqr.png"
};};};
function asqrsH14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs189").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs189").src = "img/sqrs/blSqr.png"
};};};
function asqrsH15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs190").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs190").src = "img/sqrs/blSqr.png"
};};};
function asqrsH16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs191").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs191").src = "img/sqrs/blSqr.png"
};};};
function asqrsH17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs192").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs192").src = "img/sqrs/blSqr.png"
};};};
function asqrsH18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs193").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs193").src = "img/sqrs/blSqr.png"
};};};
function asqrsH19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs194").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs194").src = "img/sqrs/blSqr.png"
};};};
function asqrsH20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs195").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs195").src = "img/sqrs/blSqr.png"
};};};
function asqrsH21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs196").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs196").src = "img/sqrs/blSqr.png"
};};};
function asqrsH22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs197").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs197").src = "img/sqrs/blSqr.png"
};};};
function asqrsH23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs198").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs198").src = "img/sqrs/blSqr.png"
};};};
function asqrsH24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs199").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs199").src = "img/sqrs/blSqr.png"
};};};
function asqrsH25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs200").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs200").src = "img/sqrs/blSqr.png"
};};};
function asqrsI1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs201").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs201").src = "img/sqrs/blSqr.png"
};};};
function asqrsI2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs202").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs202").src = "img/sqrs/blSqr.png"
};};};
function asqrsI3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs203").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs203").src = "img/sqrs/blSqr.png"
};};};
function asqrsI4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs204").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs204").src = "img/sqrs/blSqr.png"
};};};
function asqrsI5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs205").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs205").src = "img/sqrs/blSqr.png"
};};};
function asqrsI6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs206").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs206").src = "img/sqrs/blSqr.png"
};};};
function asqrsI7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs207").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs207").src = "img/sqrs/blSqr.png"
};};};
function asqrsI8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs208").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs208").src = "img/sqrs/blSqr.png"
};};};
function asqrsI9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs209").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs209").src = "img/sqrs/blSqr.png"
};};};
function asqrsI10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs210").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs210").src = "img/sqrs/blSqr.png"
};};};
function asqrsI11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs211").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs211").src = "img/sqrs/blSqr.png"
};};};
function asqrsI12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs212").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs212").src = "img/sqrs/blSqr.png"
};};};
function asqrsI13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs213").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs213").src = "img/sqrs/blSqr.png"
};};};
function asqrsI14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs214").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs214").src = "img/sqrs/blSqr.png"
};};};
function asqrsI15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs215").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs215").src = "img/sqrs/blSqr.png"
};};};
function asqrsI16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs216").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs216").src = "img/sqrs/blSqr.png"
};};};
function asqrsI17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs217").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs217").src = "img/sqrs/blSqr.png"
};};};
function asqrsI18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs218").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs218").src = "img/sqrs/blSqr.png"
};};};
function asqrsI19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs219").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs219").src = "img/sqrs/blSqr.png"
};};};
function asqrsI20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs220").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs220").src = "img/sqrs/blSqr.png"
};};};
function asqrsI21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs221").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs221").src = "img/sqrs/blSqr.png"
};};};
function asqrsI22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs222").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs222").src = "img/sqrs/blSqr.png"
};};};
function asqrsI23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs223").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs223").src = "img/sqrs/blSqr.png"
};};};
function asqrsI24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs224").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs224").src = "img/sqrs/blSqr.png"
};};};
function asqrsI25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs225").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs225").src = "img/sqrs/blSqr.png"
};};};
function asqrsJ1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs226").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs226").src = "img/sqrs/blSqr.png"
};};};
function asqrsJ2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs227").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs227").src = "img/sqrs/blSqr.png"
};};};
function asqrsJ3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs228").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs228").src = "img/sqrs/blSqr.png"
};};};
function asqrsJ4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs229").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs229").src = "img/sqrs/blSqr.png"
};};};
function asqrsJ5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs230").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs230").src = "img/sqrs/blSqr.png"
};};};
function asqrsJ6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs231").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs231").src = "img/sqrs/blSqr.png"
};};};
function asqrsJ7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs232").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs232").src = "img/sqrs/blSqr.png"
};};};
function asqrsJ8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs233").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs233").src = "img/sqrs/blSqr.png"
};};};
function asqrsJ9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs234").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs234").src = "img/sqrs/blSqr.png"
};};};
function asqrsJ10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs235").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs235").src = "img/sqrs/blSqr.png"
};};};
function asqrsJ11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs236").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs236").src = "img/sqrs/blSqr.png"
};};};
function asqrsJ12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs237").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs237").src = "img/sqrs/blSqr.png"
};};};
function asqrsJ13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs238").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs238").src = "img/sqrs/blSqr.png"
};};};
function asqrsJ14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs239").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs239").src = "img/sqrs/blSqr.png"
};};};
function asqrsJ15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs240").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs240").src = "img/sqrs/blSqr.png"
};};};
function asqrsJ16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs241").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs241").src = "img/sqrs/blSqr.png"
};};};
function asqrsJ17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs242").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs242").src = "img/sqrs/blSqr.png"
};};};
function asqrsJ18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs243").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs243").src = "img/sqrs/blSqr.png"
};};};
function asqrsJ19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs244").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs244").src = "img/sqrs/blSqr.png"
};};};
function asqrsJ20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs245").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs245").src = "img/sqrs/blSqr.png"
};};};
function asqrsJ21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs246").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs246").src = "img/sqrs/blSqr.png"
};};};
function asqrsJ22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs247").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs247").src = "img/sqrs/blSqr.png"
};};};
function asqrsJ23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs248").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs248").src = "img/sqrs/blSqr.png"
};};};
function asqrsJ24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs249").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs249").src = "img/sqrs/blSqr.png"
};};};
function asqrsJ25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs250").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs250").src = "img/sqrs/blSqr.png"
};};};
function asqrsK1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs251").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs251").src = "img/sqrs/blSqr.png"
};};};
function asqrsK2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs252").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs252").src = "img/sqrs/blSqr.png"
};};};
function asqrsK3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs253").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs253").src = "img/sqrs/blSqr.png"
};};};
function asqrsK4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs254").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs254").src = "img/sqrs/blSqr.png"
};};};
function asqrsK5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs255").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs255").src = "img/sqrs/blSqr.png"
};};};
function asqrsK6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs256").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs256").src = "img/sqrs/blSqr.png"
};};};
function asqrsK7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs257").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs257").src = "img/sqrs/blSqr.png"
};};};
function asqrsK8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs258").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs258").src = "img/sqrs/blSqr.png"
};};};
function asqrsK9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs259").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs259").src = "img/sqrs/blSqr.png"
};};};
function asqrsK10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs260").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs260").src = "img/sqrs/blSqr.png"
};};};
function asqrsK11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs261").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs261").src = "img/sqrs/blSqr.png"
};};};
function asqrsK12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs262").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs262").src = "img/sqrs/blSqr.png"
};};};
function asqrsK13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs263").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs263").src = "img/sqrs/blSqr.png"
};};};
function asqrsK14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs264").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs264").src = "img/sqrs/blSqr.png"
};};};
function asqrsK15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs265").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs265").src = "img/sqrs/blSqr.png"
};};};
function asqrsK16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs266").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs266").src = "img/sqrs/blSqr.png"
};};};
function asqrsK17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs267").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs267").src = "img/sqrs/blSqr.png"
};};};
function asqrsK18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs268").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs268").src = "img/sqrs/blSqr.png"
};};};
function asqrsK19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs269").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs269").src = "img/sqrs/blSqr.png"
};};};
function asqrsK20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs270").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs270").src = "img/sqrs/blSqr.png"
};};};
function asqrsK21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs271").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs271").src = "img/sqrs/blSqr.png"
};};};
function asqrsK22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs272").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs272").src = "img/sqrs/blSqr.png"
};};};
function asqrsK23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs273").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs273").src = "img/sqrs/blSqr.png"
};};};
function asqrsK24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs274").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs274").src = "img/sqrs/blSqr.png"
};};};
function asqrsK25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs275").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs275").src = "img/sqrs/blSqr.png"
};};};
function asqrsL1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs276").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs276").src = "img/sqrs/blSqr.png"
};};};
function asqrsL2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs277").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs277").src = "img/sqrs/blSqr.png"
};};};
function asqrsL3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs278").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs278").src = "img/sqrs/blSqr.png"
};};};
function asqrsL4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs279").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs279").src = "img/sqrs/blSqr.png"
};};};
function asqrsL5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs280").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs280").src = "img/sqrs/blSqr.png"
};};};
function asqrsL6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs281").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs281").src = "img/sqrs/blSqr.png"
};};};
function asqrsL7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs282").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs282").src = "img/sqrs/blSqr.png"
};};};
function asqrsL8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs283").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs283").src = "img/sqrs/blSqr.png"
};};};
function asqrsL9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs284").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs284").src = "img/sqrs/blSqr.png"
};};};
function asqrsL10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs285").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs285").src = "img/sqrs/blSqr.png"
};};};
function asqrsL11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs286").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs286").src = "img/sqrs/blSqr.png"
};};};
function asqrsL12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs287").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs287").src = "img/sqrs/blSqr.png"
};};};
function asqrsL13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs288").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs288").src = "img/sqrs/blSqr.png"
};};};
function asqrsL14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs289").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs289").src = "img/sqrs/blSqr.png"
};};};
function asqrsL15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs290").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs290").src = "img/sqrs/blSqr.png"
};};};
function asqrsL16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs291").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs291").src = "img/sqrs/blSqr.png"
};};};
function asqrsL17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs292").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs292").src = "img/sqrs/blSqr.png"
};};};
function asqrsL18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs293").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs293").src = "img/sqrs/blSqr.png"
};};};
function asqrsL19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs294").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs294").src = "img/sqrs/blSqr.png"
};};};
function asqrsL20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs295").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs295").src = "img/sqrs/blSqr.png"
};};};
function asqrsL21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs296").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs296").src = "img/sqrs/blSqr.png"
};};};
function asqrsL22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs297").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs297").src = "img/sqrs/blSqr.png"
};};};
function asqrsL23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs298").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs298").src = "img/sqrs/blSqr.png"
};};};
function asqrsL24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs299").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs299").src = "img/sqrs/blSqr.png"
};};};
function asqrsL25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs300").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs300").src = "img/sqrs/blSqr.png"
};};};
function asqrsM1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs301").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs301").src = "img/sqrs/blSqr.png"
};};};
function asqrsM2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs302").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs302").src = "img/sqrs/blSqr.png"
};};};
function asqrsM3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs303").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs303").src = "img/sqrs/blSqr.png"
};};};
function asqrsM4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs304").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs304").src = "img/sqrs/blSqr.png"
};};};
function asqrsM5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs305").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs305").src = "img/sqrs/blSqr.png"
};};};
function asqrsM6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs306").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs306").src = "img/sqrs/blSqr.png"
};};};
function asqrsM7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs307").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs307").src = "img/sqrs/blSqr.png"
};};};
function asqrsM8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs308").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs308").src = "img/sqrs/blSqr.png"
};};};
function asqrsM9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs309").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs309").src = "img/sqrs/blSqr.png"
};};};
function asqrsM10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs310").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs310").src = "img/sqrs/blSqr.png"
};};};
function asqrsM11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs311").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs311").src = "img/sqrs/blSqr.png"
};};};
function asqrsM12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs312").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs312").src = "img/sqrs/blSqr.png"
};};};
function asqrsM13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs313").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs313").src = "img/sqrs/blSqr.png"
};};};
function asqrsM14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs314").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs314").src = "img/sqrs/blSqr.png"
};};};
function asqrsM15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs315").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs315").src = "img/sqrs/blSqr.png"
};};};
function asqrsM16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs316").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs316").src = "img/sqrs/blSqr.png"
};};};
function asqrsM17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs317").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs317").src = "img/sqrs/blSqr.png"
};};};
function asqrsM18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs318").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs318").src = "img/sqrs/blSqr.png"
};};};
function asqrsM19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs319").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs319").src = "img/sqrs/blSqr.png"
};};};
function asqrsM20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs320").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs320").src = "img/sqrs/blSqr.png"
};};};
function asqrsM21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs321").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs321").src = "img/sqrs/blSqr.png"
};};};
function asqrsM22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs322").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs322").src = "img/sqrs/blSqr.png"
};};};
function asqrsM23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs323").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs323").src = "img/sqrs/blSqr.png"
};};};
function asqrsM24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs324").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs324").src = "img/sqrs/blSqr.png"
};};};
function asqrsM25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs325").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs325").src = "img/sqrs/blSqr.png"
};};};
function asqrsN1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs326").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs326").src = "img/sqrs/blSqr.png"
};};};
function asqrsN2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs327").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs327").src = "img/sqrs/blSqr.png"
};};};
function asqrsN3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs328").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs328").src = "img/sqrs/blSqr.png"
};};};
function asqrsN4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs329").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs329").src = "img/sqrs/blSqr.png"
};};};
function asqrsN5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs330").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs330").src = "img/sqrs/blSqr.png"
};};};
function asqrsN6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs331").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs331").src = "img/sqrs/blSqr.png"
};};};
function asqrsN7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs332").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs332").src = "img/sqrs/blSqr.png"
};};};
function asqrsN8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs333").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs333").src = "img/sqrs/blSqr.png"
};};};
function asqrsN9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs334").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs334").src = "img/sqrs/blSqr.png"
};};};
function asqrsN10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs335").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs335").src = "img/sqrs/blSqr.png"
};};};
function asqrsN11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs336").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs336").src = "img/sqrs/blSqr.png"
};};};
function asqrsN12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs337").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs337").src = "img/sqrs/blSqr.png"
};};};
function asqrsN13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs338").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs338").src = "img/sqrs/blSqr.png"
};};};
function asqrsN14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs339").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs339").src = "img/sqrs/blSqr.png"
};};};
function asqrsN15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs340").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs340").src = "img/sqrs/blSqr.png"
};};};
function asqrsN16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs341").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs341").src = "img/sqrs/blSqr.png"
};};};
function asqrsN17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs342").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs342").src = "img/sqrs/blSqr.png"
};};};
function asqrsN18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs343").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs343").src = "img/sqrs/blSqr.png"
};};};
function asqrsN19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs344").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs344").src = "img/sqrs/blSqr.png"
};};};
function asqrsN20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs345").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs345").src = "img/sqrs/blSqr.png"
};};};
function asqrsN21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs346").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs346").src = "img/sqrs/blSqr.png"
};};};
function asqrsN22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs347").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs347").src = "img/sqrs/blSqr.png"
};};};
function asqrsN23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs348").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs348").src = "img/sqrs/blSqr.png"
};};};
function asqrsN24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs349").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs349").src = "img/sqrs/blSqr.png"
};};};
function asqrsN25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs350").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs350").src = "img/sqrs/blSqr.png"
};};};
function asqrsO1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs351").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs351").src = "img/sqrs/blSqr.png"
};};};
function asqrsO2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs352").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs352").src = "img/sqrs/blSqr.png"
};};};
function asqrsO3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs353").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs353").src = "img/sqrs/blSqr.png"
};};};
function asqrsO4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs354").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs354").src = "img/sqrs/blSqr.png"
};};};
function asqrsO5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs355").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs355").src = "img/sqrs/blSqr.png"
};};};
function asqrsO6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs356").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs356").src = "img/sqrs/blSqr.png"
};};};
function asqrsO7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs357").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs357").src = "img/sqrs/blSqr.png"
};};};
function asqrsO8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs358").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs358").src = "img/sqrs/blSqr.png"
};};};
function asqrsO9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs359").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs359").src = "img/sqrs/blSqr.png"
};};};
function asqrsO10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs360").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs360").src = "img/sqrs/blSqr.png"
};};};
function asqrsO11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs361").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs361").src = "img/sqrs/blSqr.png"
};};};
function asqrsO12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs362").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs362").src = "img/sqrs/blSqr.png"
};};};
function asqrsO13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs363").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs363").src = "img/sqrs/blSqr.png"
};};};
function asqrsO14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs364").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs364").src = "img/sqrs/blSqr.png"
};};};
function asqrsO15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs365").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs365").src = "img/sqrs/blSqr.png"
};};};
function asqrsO16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs366").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs366").src = "img/sqrs/blSqr.png"
};};};
function asqrsO17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs367").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs367").src = "img/sqrs/blSqr.png"
};};};
function asqrsO18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs368").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs368").src = "img/sqrs/blSqr.png"
};};};
function asqrsO19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs369").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs369").src = "img/sqrs/blSqr.png"
};};};
function asqrsO20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs370").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs370").src = "img/sqrs/blSqr.png"
};};};
function asqrsO21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs371").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs371").src = "img/sqrs/blSqr.png"
};};};
function asqrsO22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs372").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs372").src = "img/sqrs/blSqr.png"
};};};
function asqrsO23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs373").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs373").src = "img/sqrs/blSqr.png"
};};};
function asqrsO24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs374").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs374").src = "img/sqrs/blSqr.png"
};};};
function asqrsO25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs375").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs375").src = "img/sqrs/blSqr.png"
};};};
function asqrsP1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs376").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs376").src = "img/sqrs/blSqr.png"
};};};
function asqrsP2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs377").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs377").src = "img/sqrs/blSqr.png"
};};};
function asqrsP3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs378").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs378").src = "img/sqrs/blSqr.png"
};};};
function asqrsP4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs379").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs379").src = "img/sqrs/blSqr.png"
};};};
function asqrsP5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs380").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs380").src = "img/sqrs/blSqr.png"
};};};
function asqrsP6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs381").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs381").src = "img/sqrs/blSqr.png"
};};};
function asqrsP7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs382").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs382").src = "img/sqrs/blSqr.png"
};};};
function asqrsP8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs383").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs383").src = "img/sqrs/blSqr.png"
};};};
function asqrsP9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs384").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs384").src = "img/sqrs/blSqr.png"
};};};
function asqrsP10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs385").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs385").src = "img/sqrs/blSqr.png"
};};};
function asqrsP11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs386").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs386").src = "img/sqrs/blSqr.png"
};};};
function asqrsP12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs387").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs387").src = "img/sqrs/blSqr.png"
};};};
function asqrsP13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs388").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs388").src = "img/sqrs/blSqr.png"
};};};
function asqrsP14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs389").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs389").src = "img/sqrs/blSqr.png"
};};};
function asqrsP15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs390").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs390").src = "img/sqrs/blSqr.png"
};};};
function asqrsP16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs391").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs391").src = "img/sqrs/blSqr.png"
};};};
function asqrsP17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs392").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs392").src = "img/sqrs/blSqr.png"
};};};
function asqrsP18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs393").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs393").src = "img/sqrs/blSqr.png"
};};};
function asqrsP19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs394").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs394").src = "img/sqrs/blSqr.png"
};};};
function asqrsP20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs395").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs395").src = "img/sqrs/blSqr.png"
};};};
function asqrsP21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs396").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs396").src = "img/sqrs/blSqr.png"
};};};
function asqrsP22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs397").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs397").src = "img/sqrs/blSqr.png"
};};};
function asqrsP23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs398").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs398").src = "img/sqrs/blSqr.png"
};};};
function asqrsP24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs399").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs399").src = "img/sqrs/blSqr.png"
};};};
function asqrsP25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs400").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs400").src = "img/sqrs/blSqr.png"
};};};
function asqrsQ1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs401").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs401").src = "img/sqrs/blSqr.png"
};};};
function asqrsQ2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs402").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs402").src = "img/sqrs/blSqr.png"
};};};
function asqrsQ3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs403").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs403").src = "img/sqrs/blSqr.png"
};};};
function asqrsQ4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs404").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs404").src = "img/sqrs/blSqr.png"
};};};
function asqrsQ5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs405").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs405").src = "img/sqrs/blSqr.png"
};};};
function asqrsQ6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs406").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs406").src = "img/sqrs/blSqr.png"
};};};
function asqrsQ7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs407").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs407").src = "img/sqrs/blSqr.png"
};};};
function asqrsQ8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs408").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs408").src = "img/sqrs/blSqr.png"
};};};
function asqrsQ9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs409").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs409").src = "img/sqrs/blSqr.png"
};};};
function asqrsQ10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs410").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs410").src = "img/sqrs/blSqr.png"
};};};
function asqrsQ11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs411").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs411").src = "img/sqrs/blSqr.png"
};};};
function asqrsQ12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs412").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs412").src = "img/sqrs/blSqr.png"
};};};
function asqrsQ13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs413").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs413").src = "img/sqrs/blSqr.png"
};};};
function asqrsQ14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs414").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs414").src = "img/sqrs/blSqr.png"
};};};
function asqrsQ15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs415").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs415").src = "img/sqrs/blSqr.png"
};};};
function asqrsQ16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs416").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs416").src = "img/sqrs/blSqr.png"
};};};
function asqrsQ17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs417").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs417").src = "img/sqrs/blSqr.png"
};};};
function asqrsQ18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs418").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs418").src = "img/sqrs/blSqr.png"
};};};
function asqrsQ19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs419").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs419").src = "img/sqrs/blSqr.png"
};};};
function asqrsQ20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs420").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs420").src = "img/sqrs/blSqr.png"
};};};
function asqrsQ21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs421").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs421").src = "img/sqrs/blSqr.png"
};};};
function asqrsQ22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs422").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs422").src = "img/sqrs/blSqr.png"
};};};
function asqrsQ23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs423").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs423").src = "img/sqrs/blSqr.png"
};};};
function asqrsQ24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs424").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs424").src = "img/sqrs/blSqr.png"
};};};
function asqrsQ25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs425").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs425").src = "img/sqrs/blSqr.png"
};};};
function asqrsR1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs426").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs426").src = "img/sqrs/blSqr.png"
};};};
function asqrsR2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs427").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs427").src = "img/sqrs/blSqr.png"
};};};
function asqrsR3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs428").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs428").src = "img/sqrs/blSqr.png"
};};};
function asqrsR4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs429").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs429").src = "img/sqrs/blSqr.png"
};};};
function asqrsR5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs430").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs430").src = "img/sqrs/blSqr.png"
};};};
function asqrsR6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs431").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs431").src = "img/sqrs/blSqr.png"
};};};
function asqrsR7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs432").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs432").src = "img/sqrs/blSqr.png"
};};};
function asqrsR8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs433").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs433").src = "img/sqrs/blSqr.png"
};};};
function asqrsR9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs434").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs434").src = "img/sqrs/blSqr.png"
};};};
function asqrsR10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs435").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs435").src = "img/sqrs/blSqr.png"
};};};
function asqrsR11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs436").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs436").src = "img/sqrs/blSqr.png"
};};};
function asqrsR12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs437").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs437").src = "img/sqrs/blSqr.png"
};};};
function asqrsR13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs438").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs438").src = "img/sqrs/blSqr.png"
};};};
function asqrsR14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs439").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs439").src = "img/sqrs/blSqr.png"
};};};
function asqrsR15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs440").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs440").src = "img/sqrs/blSqr.png"
};};};
function asqrsR16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs441").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs441").src = "img/sqrs/blSqr.png"
};};};
function asqrsR17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs442").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs442").src = "img/sqrs/blSqr.png"
};};};
function asqrsR18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs443").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs443").src = "img/sqrs/blSqr.png"
};};};
function asqrsR19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs444").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs444").src = "img/sqrs/blSqr.png"
};};};
function asqrsR20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs445").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs445").src = "img/sqrs/blSqr.png"
};};};
function asqrsR21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs446").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs446").src = "img/sqrs/blSqr.png"
};};};
function asqrsR22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs447").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs447").src = "img/sqrs/blSqr.png"
};};};
function asqrsR23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs448").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs448").src = "img/sqrs/blSqr.png"
};};};
function asqrsR24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs449").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs449").src = "img/sqrs/blSqr.png"
};};};
function asqrsR25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs450").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs450").src = "img/sqrs/blSqr.png"
};};};
function aSqrs1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs451").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs451").src = "img/sqrs/blSqr.png"
};};};
function aSqrs2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs452").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs452").src = "img/sqrs/blSqr.png"
};};};
function aSqrs3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs453").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs453").src = "img/sqrs/blSqr.png"
};};};
function aSqrs4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs454").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs454").src = "img/sqrs/blSqr.png"
};};};
function aSqrs5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs455").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs455").src = "img/sqrs/blSqr.png"
};};};
function aSqrs6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs456").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs456").src = "img/sqrs/blSqr.png"
};};};
function aSqrs7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs457").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs457").src = "img/sqrs/blSqr.png"
};};};
function aSqrs8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs458").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs458").src = "img/sqrs/blSqr.png"
};};};
function aSqrs9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs459").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs459").src = "img/sqrs/blSqr.png"
};};};
function aSqrs10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs460").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs460").src = "img/sqrs/blSqr.png"
};};};
function aSqrs11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs461").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs461").src = "img/sqrs/blSqr.png"
};};};
function aSqrs12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs462").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs462").src = "img/sqrs/blSqr.png"
};};};
function aSqrs13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs463").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs463").src = "img/sqrs/blSqr.png"
};};};
function aSqrs14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs464").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs464").src = "img/sqrs/blSqr.png"
};};};
function aSqrs15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs465").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs465").src = "img/sqrs/blSqr.png"
};};};
function aSqrs16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs466").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs466").src = "img/sqrs/blSqr.png"
};};};
function aSqrs17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs467").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs467").src = "img/sqrs/blSqr.png"
};};};
function aSqrs18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs468").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs468").src = "img/sqrs/blSqr.png"
};};};
function aSqrs19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs469").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs469").src = "img/sqrs/blSqr.png"
};};};
function aSqrs20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs470").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs470").src = "img/sqrs/blSqr.png"
};};};
function aSqrs21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs471").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs471").src = "img/sqrs/blSqr.png"
};};};
function aSqrs22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs472").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs472").src = "img/sqrs/blSqr.png"
};};};
function aSqrs23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs473").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs473").src = "img/sqrs/blSqr.png"
};};};
function aSqrs24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs474").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs474").src = "img/sqrs/blSqr.png"
};};};
function aSqrs25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs475").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs475").src = "img/sqrs/blSqr.png"
};};};
function asqrsT1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs476").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs476").src = "img/sqrs/blSqr.png"
};};};
function asqrsT2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs477").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs477").src = "img/sqrs/blSqr.png"
};};};
function asqrsT3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs478").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs478").src = "img/sqrs/blSqr.png"
};};};
function asqrsT4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs479").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs479").src = "img/sqrs/blSqr.png"
};};};
function asqrsT5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs480").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs480").src = "img/sqrs/blSqr.png"
};};};
function asqrsT6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs481").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs481").src = "img/sqrs/blSqr.png"
};};};
function asqrsT7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs482").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs482").src = "img/sqrs/blSqr.png"
};};};
function asqrsT8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs483").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs483").src = "img/sqrs/blSqr.png"
};};};
function asqrsT9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs484").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs484").src = "img/sqrs/blSqr.png"
};};};
function asqrsT10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs485").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs485").src = "img/sqrs/blSqr.png"
};};};
function asqrsT11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs486").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs486").src = "img/sqrs/blSqr.png"
};};};
function asqrsT12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs487").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs487").src = "img/sqrs/blSqr.png"
};};};
function asqrsT13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs488").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs488").src = "img/sqrs/blSqr.png"
};};};
function asqrsT14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs489").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs489").src = "img/sqrs/blSqr.png"
};};};
function asqrsT15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs490").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs490").src = "img/sqrs/blSqr.png"
};};};
function asqrsT16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs491").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs491").src = "img/sqrs/blSqr.png"
};};};
function asqrsT17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs492").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs492").src = "img/sqrs/blSqr.png"
};};};
function asqrsT18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs493").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs493").src = "img/sqrs/blSqr.png"
};};};
function asqrsT19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs494").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs494").src = "img/sqrs/blSqr.png"
};};};
function asqrsT20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs495").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs495").src = "img/sqrs/blSqr.png"
};};};
function asqrsT21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs496").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs496").src = "img/sqrs/blSqr.png"
};};};
function asqrsT22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs497").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs497").src = "img/sqrs/blSqr.png"
};};};
function asqrsT23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs498").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs498").src = "img/sqrs/blSqr.png"
};};};
function asqrsT24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs499").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs499").src = "img/sqrs/blSqr.png"
};};};
function asqrsT25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs500").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs500").src = "img/sqrs/blSqr.png"
};};};
function asqrsU1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs501").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs501").src = "img/sqrs/blSqr.png"
};};};
function asqrsU2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs502").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs502").src = "img/sqrs/blSqr.png"
};};};
function asqrsU3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs503").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs503").src = "img/sqrs/blSqr.png"
};};};
function asqrsU4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs504").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs504").src = "img/sqrs/blSqr.png"
};};};
function asqrsU5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs505").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs505").src = "img/sqrs/blSqr.png"
};};};
function asqrsU6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs506").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs506").src = "img/sqrs/blSqr.png"
};};};
function asqrsU7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs507").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs507").src = "img/sqrs/blSqr.png"
};};};
function asqrsU8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs508").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs508").src = "img/sqrs/blSqr.png"
};};};
function asqrsU9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs509").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs509").src = "img/sqrs/blSqr.png"
};};};
function asqrsU10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs510").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs510").src = "img/sqrs/blSqr.png"
};};};
function asqrsU11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs511").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs511").src = "img/sqrs/blSqr.png"
};};};
function asqrsU12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs512").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs512").src = "img/sqrs/blSqr.png"
};};};
function asqrsU13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs513").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs513").src = "img/sqrs/blSqr.png"
};};};
function asqrsU14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs514").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs514").src = "img/sqrs/blSqr.png"
};};};
function asqrsU15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs515").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs515").src = "img/sqrs/blSqr.png"
};};};
function asqrsU16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs516").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs516").src = "img/sqrs/blSqr.png"
};};};
function asqrsU17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs517").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs517").src = "img/sqrs/blSqr.png"
};};};
function asqrsU18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs518").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs518").src = "img/sqrs/blSqr.png"
};};};
function asqrsU19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs519").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs519").src = "img/sqrs/blSqr.png"
};};};
function asqrsU20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs520").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs520").src = "img/sqrs/blSqr.png"
};};};
function asqrsU21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs521").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs521").src = "img/sqrs/blSqr.png"
};};};
function asqrsU22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs522").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs522").src = "img/sqrs/blSqr.png"
};};};
function asqrsU23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs523").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs523").src = "img/sqrs/blSqr.png"
};};};
function asqrsU24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs524").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs524").src = "img/sqrs/blSqr.png"
};};};
function asqrsU25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs525").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs525").src = "img/sqrs/blSqr.png"
};};};
function asqrsV1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs526").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs526").src = "img/sqrs/blSqr.png"
};};};
function asqrsV2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs527").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs527").src = "img/sqrs/blSqr.png"
};};};
function asqrsV3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs528").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs528").src = "img/sqrs/blSqr.png"
};};};
function asqrsV4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs529").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs529").src = "img/sqrs/blSqr.png"
};};};
function asqrsV5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs530").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs530").src = "img/sqrs/blSqr.png"
};};};
function asqrsV6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs531").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs531").src = "img/sqrs/blSqr.png"
};};};
function asqrsV7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs532").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs532").src = "img/sqrs/blSqr.png"
};};};
function asqrsV8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs533").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs533").src = "img/sqrs/blSqr.png"
};};};
function asqrsV9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs534").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs534").src = "img/sqrs/blSqr.png"
};};};
function asqrsV10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs535").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs535").src = "img/sqrs/blSqr.png"
};};};
function asqrsV11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs536").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs536").src = "img/sqrs/blSqr.png"
};};};
function asqrsV12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs537").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs537").src = "img/sqrs/blSqr.png"
};};};
function asqrsV13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs538").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs538").src = "img/sqrs/blSqr.png"
};};};
function asqrsV14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs539").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs539").src = "img/sqrs/blSqr.png"
};};};
function asqrsV15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs540").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs540").src = "img/sqrs/blSqr.png"
};};};
function asqrsV16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs541").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs541").src = "img/sqrs/blSqr.png"
};};};
function asqrsV17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs542").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs542").src = "img/sqrs/blSqr.png"
};};};
function asqrsV18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs543").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs543").src = "img/sqrs/blSqr.png"
};};};
function asqrsV19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs544").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs544").src = "img/sqrs/blSqr.png"
};};};
function asqrsV20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs545").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs545").src = "img/sqrs/blSqr.png"
};};};
function asqrsV21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs546").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs546").src = "img/sqrs/blSqr.png"
};};};
function asqrsV22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs547").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs547").src = "img/sqrs/blSqr.png"
};};};
function asqrsV23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs548").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs548").src = "img/sqrs/blSqr.png"
};};};
function asqrsV24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs549").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs549").src = "img/sqrs/blSqr.png"
};};};
function asqrsV25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs550").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs550").src = "img/sqrs/blSqr.png"
};};};
function asqrsW1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs551").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs551").src = "img/sqrs/blSqr.png"
};};};
function asqrsW2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs552").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs552").src = "img/sqrs/blSqr.png"
};};};
function asqrsW3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs553").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs553").src = "img/sqrs/blSqr.png"
};};};
function asqrsW4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs554").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs554").src = "img/sqrs/blSqr.png"
};};};
function asqrsW5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs555").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs555").src = "img/sqrs/blSqr.png"
};};};
function asqrsW6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs556").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs556").src = "img/sqrs/blSqr.png"
};};};
function asqrsW7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs557").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs557").src = "img/sqrs/blSqr.png"
};};};
function asqrsW8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs558").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs558").src = "img/sqrs/blSqr.png"
};};};
function asqrsW9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs559").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs559").src = "img/sqrs/blSqr.png"
};};};
function asqrsW10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs560").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs560").src = "img/sqrs/blSqr.png"
};};};
function asqrsW11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs561").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs561").src = "img/sqrs/blSqr.png"
};};};
function asqrsW12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs562").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs562").src = "img/sqrs/blSqr.png"
};};};
function asqrsW13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs563").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs563").src = "img/sqrs/blSqr.png"
};};};
function asqrsW14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs564").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs564").src = "img/sqrs/blSqr.png"
};};};
function asqrsW15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs565").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs565").src = "img/sqrs/blSqr.png"
};};};
function asqrsW16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs566").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs566").src = "img/sqrs/blSqr.png"
};};};
function asqrsW17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs567").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs567").src = "img/sqrs/blSqr.png"
};};};
function asqrsW18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs568").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs568").src = "img/sqrs/blSqr.png"
};};};
function asqrsW19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs569").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs569").src = "img/sqrs/blSqr.png"
};};};
function asqrsW20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs570").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs570").src = "img/sqrs/blSqr.png"
};};};
function asqrsW21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs571").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs571").src = "img/sqrs/blSqr.png"
};};};
function asqrsW22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs572").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs572").src = "img/sqrs/blSqr.png"
};};};
function asqrsW23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs573").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs573").src = "img/sqrs/blSqr.png"
};};};
function asqrsW24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs574").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs574").src = "img/sqrs/blSqr.png"
};};};
function asqrsW25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs575").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs575").src = "img/sqrs/blSqr.png"
};};};
function asqrsX1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs576").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs576").src = "img/sqrs/blSqr.png"
};};};
function asqrsX2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs577").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs577").src = "img/sqrs/blSqr.png"
};};};
function asqrsX3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs578").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs578").src = "img/sqrs/blSqr.png"
};};};
function asqrsX4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs579").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs579").src = "img/sqrs/blSqr.png"
};};};
function asqrsX5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs580").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs580").src = "img/sqrs/blSqr.png"
};};};
function asqrsX6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs581").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs581").src = "img/sqrs/blSqr.png"
};};};
function asqrsX7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs582").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs582").src = "img/sqrs/blSqr.png"
};};};
function asqrsX8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs583").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs583").src = "img/sqrs/blSqr.png"
};};};
function asqrsX9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs584").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs584").src = "img/sqrs/blSqr.png"
};};};
function asqrsX10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs585").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs585").src = "img/sqrs/blSqr.png"
};};};
function asqrsX11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs586").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs586").src = "img/sqrs/blSqr.png"
};};};
function asqrsX12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs587").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs587").src = "img/sqrs/blSqr.png"
};};};
function asqrsX13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs588").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs588").src = "img/sqrs/blSqr.png"
};};};
function asqrsX14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs589").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs589").src = "img/sqrs/blSqr.png"
};};};
function asqrsX15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs590").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs590").src = "img/sqrs/blSqr.png"
};};};
function asqrsX16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs591").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs591").src = "img/sqrs/blSqr.png"
};};};
function asqrsX17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs592").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs592").src = "img/sqrs/blSqr.png"
};};};
function asqrsX18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs593").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs593").src = "img/sqrs/blSqr.png"
};};};
function asqrsX19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs594").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs594").src = "img/sqrs/blSqr.png"
};};};
function asqrsX20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs595").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs595").src = "img/sqrs/blSqr.png"
};};};
function asqrsX21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs596").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs596").src = "img/sqrs/blSqr.png"
};};};
function asqrsX22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs597").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs597").src = "img/sqrs/blSqr.png"
};};};
function asqrsX23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs598").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs598").src = "img/sqrs/blSqr.png"
};};};
function asqrsX24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs599").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs599").src = "img/sqrs/blSqr.png"
};};};
function asqrsX25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs600").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs600").src = "img/sqrs/blSqr.png"
};};};
function asqrsY1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs601").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs601").src = "img/sqrs/blSqr.png"
};};};
function asqrsY2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs602").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs602").src = "img/sqrs/blSqr.png"
};};};
function asqrsY3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs603").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs603").src = "img/sqrs/blSqr.png"
};};};
function asqrsY4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs604").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs604").src = "img/sqrs/blSqr.png"
};};};
function asqrsY5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs605").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs605").src = "img/sqrs/blSqr.png"
};};};
function asqrsY6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs606").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs606").src = "img/sqrs/blSqr.png"
};};};
function asqrsY7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs607").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs607").src = "img/sqrs/blSqr.png"
};};};
function asqrsY8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs608").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs608").src = "img/sqrs/blSqr.png"
};};};
function asqrsY9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs609").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs609").src = "img/sqrs/blSqr.png"
};};};
function asqrsY10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs610").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs610").src = "img/sqrs/blSqr.png"
};};};
function asqrsY11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs611").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs611").src = "img/sqrs/blSqr.png"
};};};
function asqrsY12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs612").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs612").src = "img/sqrs/blSqr.png"
};};};
function asqrsY13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs613").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs613").src = "img/sqrs/blSqr.png"
};};};
function asqrsY14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs614").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs614").src = "img/sqrs/blSqr.png"
};};};
function asqrsY15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs615").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs615").src = "img/sqrs/blSqr.png"
};};};
function asqrsY16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs616").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs616").src = "img/sqrs/blSqr.png"
};};};
function asqrsY17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs617").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs617").src = "img/sqrs/blSqr.png"
};};};
function asqrsY18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs618").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs618").src = "img/sqrs/blSqr.png"
};};};
function asqrsY19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs619").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs619").src = "img/sqrs/blSqr.png"
};};};
function asqrsY20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs620").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs620").src = "img/sqrs/blSqr.png"
};};};
function asqrsY21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs621").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs621").src = "img/sqrs/blSqr.png"
};};};
function asqrsY22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs622").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs622").src = "img/sqrs/blSqr.png"
};};};
function asqrsY23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs623").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs623").src = "img/sqrs/blSqr.png"
};};};
function asqrsY24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs624").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs624").src = "img/sqrs/blSqr.png"
};};};
function asqrsY25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs625").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs625").src = "img/sqrs/blSqr.png"
};};};