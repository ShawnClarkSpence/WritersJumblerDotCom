function asqrsA1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1").src = "img/sqrs/blSqr.png"
};};};

function asqrsA2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs2").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs2").src = "img/sqrs/blSqr.png"
};};};

function asqrsA3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs3").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs3").src = "img/sqrs/blSqr.png"
};};};

function asqrsA4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs4").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs4").src = "img/sqrs/blSqr.png"
};};};

function asqrsA5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs5").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs5").src = "img/sqrs/blSqr.png"
};};};

function asqrsA6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs6").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs6").src = "img/sqrs/blSqr.png"
};};};

function asqrsA7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs7").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs7").src = "img/sqrs/blSqr.png"
};};};

function asqrsA8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs8").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs8").src = "img/sqrs/blSqr.png"
};};};

function asqrsA9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs9").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs9").src = "img/sqrs/blSqr.png"
};};};

function asqrsA10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs10").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs10").src = "img/sqrs/blSqr.png"
};};};

function asqrsA11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs11").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs11").src = "img/sqrs/blSqr.png"
};};};

function asqrsA12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs12").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs12").src = "img/sqrs/blSqr.png"
};};};

function asqrsA13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs13").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs13").src = "img/sqrs/blSqr.png"
};};};

function asqrsA14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs14").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs14").src = "img/sqrs/blSqr.png"
};};};

function asqrsA15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs15").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs15").src = "img/sqrs/blSqr.png"
};};};

function asqrsA16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs16").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs16").src = "img/sqrs/blSqr.png"
};};};

function asqrsA17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs17").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs17").src = "img/sqrs/blSqr.png"
};};};

function asqrsA18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs18").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs18").src = "img/sqrs/blSqr.png"
};};};

function asqrsA19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs19").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs19").src = "img/sqrs/blSqr.png"
};};};

function asqrsA20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs20").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs20").src = "img/sqrs/blSqr.png"
};};};

function asqrsA21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs21").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs21").src = "img/sqrs/blSqr.png"
};};};

function asqrsA22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs22").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs22").src = "img/sqrs/blSqr.png"
};};};

function asqrsA23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs23").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs23").src = "img/sqrs/blSqr.png"
};};};

function asqrsA24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs24").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs24").src = "img/sqrs/blSqr.png"
};};};

function asqrsA25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs25").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs25").src = "img/sqrs/blSqr.png"
};};};

function asqrsA26() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs26").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs26").src = "img/sqrs/blSqr.png"
};};};

function asqrsA27() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs27").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs27").src = "img/sqrs/blSqr.png"
};};};

function asqrsA28() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs28").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs28").src = "img/sqrs/blSqr.png"
};};};

function asqrsA29() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs29").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs29").src = "img/sqrs/blSqr.png"
};};};

function asqrsA30() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs30").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs30").src = "img/sqrs/blSqr.png"
};};};

function asqrsA31() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs31").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs31").src = "img/sqrs/blSqr.png"
};};};

function asqrsA32() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs32").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs32").src = "img/sqrs/blSqr.png"
};};};

function asqrsA33() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs33").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs33").src = "img/sqrs/blSqr.png"
};};};

function asqrsA34() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs34").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs34").src = "img/sqrs/blSqr.png"
};};};

function asqrsA35() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs35").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs35").src = "img/sqrs/blSqr.png"
};};};

function asqrsA36() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs36").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs36").src = "img/sqrs/blSqr.png"
};};};

function asqrsA37() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs37").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs37").src = "img/sqrs/blSqr.png"
};};};

function asqrsA38() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs38").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs38").src = "img/sqrs/blSqr.png"
};};};

function asqrsA39() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs39").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs39").src = "img/sqrs/blSqr.png"
};};};

function asqrsA40() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs40").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs40").src = "img/sqrs/blSqr.png"
};};};

function asqrsA41() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs41").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs41").src = "img/sqrs/blSqr.png"
};};};

function asqrsA42() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs42").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs42").src = "img/sqrs/blSqr.png"
};};};

function asqrsA43() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs43").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs43").src = "img/sqrs/blSqr.png"
};};};

function asqrsA44() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs44").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs44").src = "img/sqrs/blSqr.png"
};};};

function asqrsA45() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs45").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs45").src = "img/sqrs/blSqr.png"
};};};

function asqrsA46() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs46").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs46").src = "img/sqrs/blSqr.png"
};};};

function asqrsA47() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs47").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs47").src = "img/sqrs/blSqr.png"
};};};

function asqrsA48() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs48").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs48").src = "img/sqrs/blSqr.png"
};};};

function asqrsA49() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs49").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs49").src = "img/sqrs/blSqr.png"
};};};

function asqrsA50() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs50").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs50").src = "img/sqrs/blSqr.png"
};};};

function asqrsB51() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs51").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs51").src = "img/sqrs/blSqr.png"
};};};

function asqrsB52() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs52").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs52").src = "img/sqrs/blSqr.png"
};};};

function asqrsB53() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs53").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs53").src = "img/sqrs/blSqr.png"
};};};

function asqrsB54() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs54").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs54").src = "img/sqrs/blSqr.png"
};};};

function asqrsB55() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs55").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs55").src = "img/sqrs/blSqr.png"
};};};

function asqrsB56() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs56").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs56").src = "img/sqrs/blSqr.png"
};};};

function asqrsB57() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs57").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs57").src = "img/sqrs/blSqr.png"
};};};

function asqrsB58() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs58").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs58").src = "img/sqrs/blSqr.png"
};};};

function asqrsB59() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs59").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs59").src = "img/sqrs/blSqr.png"
};};};

function asqrsB60() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs60").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs60").src = "img/sqrs/blSqr.png"
};};};

function asqrsB61() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs61").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs61").src = "img/sqrs/blSqr.png"
};};};

function asqrsB62() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs62").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs62").src = "img/sqrs/blSqr.png"
};};};

function asqrsB63() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs63").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs63").src = "img/sqrs/blSqr.png"
};};};

function asqrsB64() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs64").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs64").src = "img/sqrs/blSqr.png"
};};};

function asqrsB65() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs65").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs65").src = "img/sqrs/blSqr.png"
};};};

function asqrsB66() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs66").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs66").src = "img/sqrs/blSqr.png"
};};};

function asqrsB67() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs67").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs67").src = "img/sqrs/blSqr.png"
};};};

function asqrsB68() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs68").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs68").src = "img/sqrs/blSqr.png"
};};};

function asqrsB69() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs69").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs69").src = "img/sqrs/blSqr.png"
};};};

function asqrsB70() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs70").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs70").src = "img/sqrs/blSqr.png"
};};};

function asqrsB71() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs71").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs71").src = "img/sqrs/blSqr.png"
};};};

function asqrsB72() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs72").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs72").src = "img/sqrs/blSqr.png"
};};};

function asqrsB73() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs73").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs73").src = "img/sqrs/blSqr.png"
};};};

function asqrsB74() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs74").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs74").src = "img/sqrs/blSqr.png"
};};};

function asqrsB75() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs75").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs75").src = "img/sqrs/blSqr.png"
};};};

function asqrsB76() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs76").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs76").src = "img/sqrs/blSqr.png"
};};};

function asqrsB77() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs77").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs77").src = "img/sqrs/blSqr.png"
};};};

function asqrsB78() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs78").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs78").src = "img/sqrs/blSqr.png"
};};};

function asqrsB79() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs79").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs79").src = "img/sqrs/blSqr.png"
};};};

function asqrsB80() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs80").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs80").src = "img/sqrs/blSqr.png"
};};};

function asqrsB81() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs81").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs81").src = "img/sqrs/blSqr.png"
};};};

function asqrsB82() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs82").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs82").src = "img/sqrs/blSqr.png"
};};};

function asqrsB83() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs83").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs83").src = "img/sqrs/blSqr.png"
};};};

function asqrsB84() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs84").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs84").src = "img/sqrs/blSqr.png"
};};};

function asqrsB85() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs85").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs85").src = "img/sqrs/blSqr.png"
};};};

function asqrsB86() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs86").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs86").src = "img/sqrs/blSqr.png"
};};};

function asqrsB87() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs87").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs87").src = "img/sqrs/blSqr.png"
};};};

function asqrsB88() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs88").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs88").src = "img/sqrs/blSqr.png"
};};};

function asqrsB89() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs89").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs89").src = "img/sqrs/blSqr.png"
};};};

function asqrsB90() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs90").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs90").src = "img/sqrs/blSqr.png"
};};};

function asqrsB91() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs91").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs91").src = "img/sqrs/blSqr.png"
};};};

function asqrsB92() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs92").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs92").src = "img/sqrs/blSqr.png"
};};};

function asqrsB93() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs93").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs93").src = "img/sqrs/blSqr.png"
};};};

function asqrsB94() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs94").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs94").src = "img/sqrs/blSqr.png"
};};};

function asqrsB95() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs95").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs95").src = "img/sqrs/blSqr.png"
};};};

function asqrsB96() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs96").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs96").src = "img/sqrs/blSqr.png"
};};};

function asqrsB97() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs97").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs97").src = "img/sqrs/blSqr.png"
};};};

function asqrsB98() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs98").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs98").src = "img/sqrs/blSqr.png"
};};};

function asqrsB99() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs99").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs99").src = "img/sqrs/blSqr.png"
};};};

function asqrsB100() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs100").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs100").src = "img/sqrs/blSqr.png"
};};};

function asqrsC101() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs101").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs101").src = "img/sqrs/blSqr.png"
};};};

function asqrsC102() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs102").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs102").src = "img/sqrs/blSqr.png"
};};};

function asqrsC103() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs103").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs103").src = "img/sqrs/blSqr.png"
};};};

function asqrsC104() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs104").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs104").src = "img/sqrs/blSqr.png"
};};};

function asqrsC105() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs105").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs105").src = "img/sqrs/blSqr.png"
};};};

function asqrsC106() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs106").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs106").src = "img/sqrs/blSqr.png"
};};};

function asqrsC107() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs107").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs107").src = "img/sqrs/blSqr.png"
};};};

function asqrsC108() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs108").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs108").src = "img/sqrs/blSqr.png"
};};};

function asqrsC109() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs109").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs109").src = "img/sqrs/blSqr.png"
};};};

function asqrsC110() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs110").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs110").src = "img/sqrs/blSqr.png"
};};};

function asqrsC111() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs111").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs111").src = "img/sqrs/blSqr.png"
};};};

function asqrsC112() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs112").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs112").src = "img/sqrs/blSqr.png"
};};};

function asqrsC113() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs113").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs113").src = "img/sqrs/blSqr.png"
};};};

function asqrsC114() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs114").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs114").src = "img/sqrs/blSqr.png"
};};};

function asqrsC115() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs115").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs115").src = "img/sqrs/blSqr.png"
};};};

function asqrsC116() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs116").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs116").src = "img/sqrs/blSqr.png"
};};};

function asqrsC117() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs117").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs117").src = "img/sqrs/blSqr.png"
};};};

function asqrsC118() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs118").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs118").src = "img/sqrs/blSqr.png"
};};};

function asqrsC119() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs119").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs119").src = "img/sqrs/blSqr.png"
};};};

function asqrsC120() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs120").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs120").src = "img/sqrs/blSqr.png"
};};};

function asqrsC121() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs121").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs121").src = "img/sqrs/blSqr.png"
};};};

function asqrsC122() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs122").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs122").src = "img/sqrs/blSqr.png"
};};};

function asqrsC123() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs123").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs123").src = "img/sqrs/blSqr.png"
};};};

function asqrsC124() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs124").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs124").src = "img/sqrs/blSqr.png"
};};};

function asqrsC125() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs125").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs125").src = "img/sqrs/blSqr.png"
};};};

function asqrsC126() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs126").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs126").src = "img/sqrs/blSqr.png"
};};};

function asqrsC127() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs127").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs127").src = "img/sqrs/blSqr.png"
};};};

function asqrsC128() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs128").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs128").src = "img/sqrs/blSqr.png"
};};};

function asqrsC129() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs129").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs129").src = "img/sqrs/blSqr.png"
};};};

function asqrsC130() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs130").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs130").src = "img/sqrs/blSqr.png"
};};};

function asqrsC131() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs131").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs131").src = "img/sqrs/blSqr.png"
};};};

function asqrsC132() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs132").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs132").src = "img/sqrs/blSqr.png"
};};};

function asqrsC133() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs133").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs133").src = "img/sqrs/blSqr.png"
};};};

function asqrsC134() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs134").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs134").src = "img/sqrs/blSqr.png"
};};};

function asqrsC135() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs135").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs135").src = "img/sqrs/blSqr.png"
};};};

function asqrsC136() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs136").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs136").src = "img/sqrs/blSqr.png"
};};};

function asqrsC137() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs137").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs137").src = "img/sqrs/blSqr.png"
};};};

function asqrsC138() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs138").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs138").src = "img/sqrs/blSqr.png"
};};};

function asqrsC139() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs139").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs139").src = "img/sqrs/blSqr.png"
};};};

function asqrsC140() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs140").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs140").src = "img/sqrs/blSqr.png"
};};};

function asqrsC141() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs141").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs141").src = "img/sqrs/blSqr.png"
};};};

function asqrsC142() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs142").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs142").src = "img/sqrs/blSqr.png"
};};};

function asqrsC143() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs143").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs143").src = "img/sqrs/blSqr.png"
};};};

function asqrsC144() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs144").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs144").src = "img/sqrs/blSqr.png"
};};};

function asqrsC145() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs145").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs145").src = "img/sqrs/blSqr.png"
};};};

function asqrsC146() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs146").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs146").src = "img/sqrs/blSqr.png"
};};};

function asqrsC147() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs147").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs147").src = "img/sqrs/blSqr.png"
};};};

function asqrsC148() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs148").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs148").src = "img/sqrs/blSqr.png"
};};};

function asqrsC149() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs149").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs149").src = "img/sqrs/blSqr.png"
};};};

function asqrsC150() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs150").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs150").src = "img/sqrs/blSqr.png"
};};};

function asqrsD151() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs151").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs151").src = "img/sqrs/blSqr.png"
};};};

function asqrsD152() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs152").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs152").src = "img/sqrs/blSqr.png"
};};};

function asqrsD153() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs153").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs153").src = "img/sqrs/blSqr.png"
};};};

function asqrsD154() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs154").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs154").src = "img/sqrs/blSqr.png"
};};};

function asqrsD155() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs155").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs155").src = "img/sqrs/blSqr.png"
};};};

function asqrsD156() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs156").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs156").src = "img/sqrs/blSqr.png"
};};};

function asqrsD157() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs157").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs157").src = "img/sqrs/blSqr.png"
};};};

function asqrsD158() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs158").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs158").src = "img/sqrs/blSqr.png"
};};};

function asqrsD159() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs159").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs159").src = "img/sqrs/blSqr.png"
};};};

function asqrsD160() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs160").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs160").src = "img/sqrs/blSqr.png"
};};};

function asqrsD161() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs161").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs161").src = "img/sqrs/blSqr.png"
};};};

function asqrsD162() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs162").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs162").src = "img/sqrs/blSqr.png"
};};};

function asqrsD163() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs163").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs163").src = "img/sqrs/blSqr.png"
};};};

function asqrsD164() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs164").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs164").src = "img/sqrs/blSqr.png"
};};};

function asqrsD165() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs165").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs165").src = "img/sqrs/blSqr.png"
};};};

function asqrsD166() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs166").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs166").src = "img/sqrs/blSqr.png"
};};};

function asqrsD167() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs167").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs167").src = "img/sqrs/blSqr.png"
};};};

function asqrsD168() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs168").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs168").src = "img/sqrs/blSqr.png"
};};};

function asqrsD169() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs169").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs169").src = "img/sqrs/blSqr.png"
};};};

function asqrsD170() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs170").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs170").src = "img/sqrs/blSqr.png"
};};};

function asqrsD171() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs171").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs171").src = "img/sqrs/blSqr.png"
};};};

function asqrsD172() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs172").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs172").src = "img/sqrs/blSqr.png"
};};};

function asqrsD173() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs173").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs173").src = "img/sqrs/blSqr.png"
};};};

function asqrsD174() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs174").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs174").src = "img/sqrs/blSqr.png"
};};};

function asqrsD175() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs175").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs175").src = "img/sqrs/blSqr.png"
};};};

function asqrsD176() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs176").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs176").src = "img/sqrs/blSqr.png"
};};};

function asqrsD177() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs177").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs177").src = "img/sqrs/blSqr.png"
};};};

function asqrsD178() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs178").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs178").src = "img/sqrs/blSqr.png"
};};};

function asqrsD179() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs179").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs179").src = "img/sqrs/blSqr.png"
};};};

function asqrsD180() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs180").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs180").src = "img/sqrs/blSqr.png"
};};};

function asqrsD181() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs181").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs181").src = "img/sqrs/blSqr.png"
};};};

function asqrsD182() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs182").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs182").src = "img/sqrs/blSqr.png"
};};};

function asqrsD183() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs183").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs183").src = "img/sqrs/blSqr.png"
};};};

function asqrsD184() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs184").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs184").src = "img/sqrs/blSqr.png"
};};};

function asqrsD185() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs185").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs185").src = "img/sqrs/blSqr.png"
};};};

function asqrsD186() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs186").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs186").src = "img/sqrs/blSqr.png"
};};};

function asqrsD187() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs187").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs187").src = "img/sqrs/blSqr.png"
};};};

function asqrsD188() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs188").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs188").src = "img/sqrs/blSqr.png"
};};};

function asqrsD189() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs189").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs189").src = "img/sqrs/blSqr.png"
};};};

function asqrsD190() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs190").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs190").src = "img/sqrs/blSqr.png"
};};};

function asqrsD191() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs191").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs191").src = "img/sqrs/blSqr.png"
};};};

function asqrsD192() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs192").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs192").src = "img/sqrs/blSqr.png"
};};};

function asqrsD193() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs193").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs193").src = "img/sqrs/blSqr.png"
};};};

function asqrsD194() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs194").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs194").src = "img/sqrs/blSqr.png"
};};};

function asqrsD195() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs195").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs195").src = "img/sqrs/blSqr.png"
};};};

function asqrsD196() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs196").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs196").src = "img/sqrs/blSqr.png"
};};};

function asqrsD197() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs197").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs197").src = "img/sqrs/blSqr.png"
};};};

function asqrsD198() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs198").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs198").src = "img/sqrs/blSqr.png"
};};};

function asqrsD199() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs199").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs199").src = "img/sqrs/blSqr.png"
};};};

function asqrsD200() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs200").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs200").src = "img/sqrs/blSqr.png"
};};};

function asqrsE201() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs201").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs201").src = "img/sqrs/blSqr.png"
};};};

function asqrsE202() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs202").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs202").src = "img/sqrs/blSqr.png"
};};};

function asqrsE203() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs203").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs203").src = "img/sqrs/blSqr.png"
};};};

function asqrsE204() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs204").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs204").src = "img/sqrs/blSqr.png"
};};};

function asqrsE205() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs205").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs205").src = "img/sqrs/blSqr.png"
};};};

function asqrsE206() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs206").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs206").src = "img/sqrs/blSqr.png"
};};};

function asqrsE207() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs207").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs207").src = "img/sqrs/blSqr.png"
};};};

function asqrsE208() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs208").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs208").src = "img/sqrs/blSqr.png"
};};};

function asqrsE209() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs209").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs209").src = "img/sqrs/blSqr.png"
};};};

function asqrsE210() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs210").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs210").src = "img/sqrs/blSqr.png"
};};};

function asqrsE211() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs211").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs211").src = "img/sqrs/blSqr.png"
};};};

function asqrsE212() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs212").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs212").src = "img/sqrs/blSqr.png"
};};};

function asqrsE213() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs213").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs213").src = "img/sqrs/blSqr.png"
};};};

function asqrsE214() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs214").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs214").src = "img/sqrs/blSqr.png"
};};};

function asqrsE215() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs215").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs215").src = "img/sqrs/blSqr.png"
};};};

function asqrsE216() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs216").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs216").src = "img/sqrs/blSqr.png"
};};};

function asqrsE217() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs217").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs217").src = "img/sqrs/blSqr.png"
};};};

function asqrsE218() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs218").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs218").src = "img/sqrs/blSqr.png"
};};};

function asqrsE219() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs219").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs219").src = "img/sqrs/blSqr.png"
};};};

function asqrsE220() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs220").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs220").src = "img/sqrs/blSqr.png"
};};};

function asqrsE221() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs221").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs221").src = "img/sqrs/blSqr.png"
};};};

function asqrsE222() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs222").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs222").src = "img/sqrs/blSqr.png"
};};};

function asqrsE223() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs223").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs223").src = "img/sqrs/blSqr.png"
};};};

function asqrsE224() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs224").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs224").src = "img/sqrs/blSqr.png"
};};};

function asqrsE225() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs225").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs225").src = "img/sqrs/blSqr.png"
};};};

function asqrsE226() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs226").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs226").src = "img/sqrs/blSqr.png"
};};};

function asqrsE227() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs227").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs227").src = "img/sqrs/blSqr.png"
};};};

function asqrsE228() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs228").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs228").src = "img/sqrs/blSqr.png"
};};};

function asqrsE229() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs229").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs229").src = "img/sqrs/blSqr.png"
};};};

function asqrsE230() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs230").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs230").src = "img/sqrs/blSqr.png"
};};};

function asqrsE231() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs231").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs231").src = "img/sqrs/blSqr.png"
};};};

function asqrsE232() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs232").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs232").src = "img/sqrs/blSqr.png"
};};};

function asqrsE233() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs233").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs233").src = "img/sqrs/blSqr.png"
};};};

function asqrsE234() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs234").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs234").src = "img/sqrs/blSqr.png"
};};};

function asqrsE235() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs235").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs235").src = "img/sqrs/blSqr.png"
};};};

function asqrsE236() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs236").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs236").src = "img/sqrs/blSqr.png"
};};};

function asqrsE237() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs237").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs237").src = "img/sqrs/blSqr.png"
};};};

function asqrsE238() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs238").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs238").src = "img/sqrs/blSqr.png"
};};};

function asqrsE239() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs239").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs239").src = "img/sqrs/blSqr.png"
};};};

function asqrsE240() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs240").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs240").src = "img/sqrs/blSqr.png"
};};};

function asqrsE241() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs241").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs241").src = "img/sqrs/blSqr.png"
};};};

function asqrsE242() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs242").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs242").src = "img/sqrs/blSqr.png"
};};};

function asqrsE243() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs243").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs243").src = "img/sqrs/blSqr.png"
};};};

function asqrsE244() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs244").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs244").src = "img/sqrs/blSqr.png"
};};};

function asqrsE245() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs245").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs245").src = "img/sqrs/blSqr.png"
};};};

function asqrsE246() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs246").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs246").src = "img/sqrs/blSqr.png"
};};};

function asqrsE247() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs247").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs247").src = "img/sqrs/blSqr.png"
};};};

function asqrsE248() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs248").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs248").src = "img/sqrs/blSqr.png"
};};};

function asqrsE249() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs249").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs249").src = "img/sqrs/blSqr.png"
};};};

function asqrsE250() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs250").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs250").src = "img/sqrs/blSqr.png"
};};};

function asqrsF251() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs251").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs251").src = "img/sqrs/blSqr.png"
};};};

function asqrsF252() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs252").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs252").src = "img/sqrs/blSqr.png"
};};};

function asqrsF253() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs253").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs253").src = "img/sqrs/blSqr.png"
};};};

function asqrsF254() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs254").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs254").src = "img/sqrs/blSqr.png"
};};};

function asqrsF255() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs255").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs255").src = "img/sqrs/blSqr.png"
};};};

function asqrsF256() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs256").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs256").src = "img/sqrs/blSqr.png"
};};};

function asqrsF257() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs257").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs257").src = "img/sqrs/blSqr.png"
};};};

function asqrsF258() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs258").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs258").src = "img/sqrs/blSqr.png"
};};};

function asqrsF259() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs259").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs259").src = "img/sqrs/blSqr.png"
};};};

function asqrsF260() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs260").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs260").src = "img/sqrs/blSqr.png"
};};};

function asqrsF261() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs261").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs261").src = "img/sqrs/blSqr.png"
};};};

function asqrsF262() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs262").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs262").src = "img/sqrs/blSqr.png"
};};};

function asqrsF263() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs263").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs263").src = "img/sqrs/blSqr.png"
};};};

function asqrsF264() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs264").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs264").src = "img/sqrs/blSqr.png"
};};};

function asqrsF265() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs265").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs265").src = "img/sqrs/blSqr.png"
};};};

function asqrsF266() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs266").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs266").src = "img/sqrs/blSqr.png"
};};};

function asqrsF267() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs267").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs267").src = "img/sqrs/blSqr.png"
};};};

function asqrsF268() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs268").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs268").src = "img/sqrs/blSqr.png"
};};};

function asqrsF269() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs269").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs269").src = "img/sqrs/blSqr.png"
};};};

function asqrsF270() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs270").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs270").src = "img/sqrs/blSqr.png"
};};};

function asqrsF271() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs271").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs271").src = "img/sqrs/blSqr.png"
};};};

function asqrsF272() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs272").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs272").src = "img/sqrs/blSqr.png"
};};};

function asqrsF273() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs273").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs273").src = "img/sqrs/blSqr.png"
};};};

function asqrsF274() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs274").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs274").src = "img/sqrs/blSqr.png"
};};};

function asqrsF275() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs275").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs275").src = "img/sqrs/blSqr.png"
};};};

function asqrsF276() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs276").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs276").src = "img/sqrs/blSqr.png"
};};};

function asqrsF277() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs277").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs277").src = "img/sqrs/blSqr.png"
};};};

function asqrsF278() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs278").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs278").src = "img/sqrs/blSqr.png"
};};};

function asqrsF279() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs279").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs279").src = "img/sqrs/blSqr.png"
};};};

function asqrsF280() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs280").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs280").src = "img/sqrs/blSqr.png"
};};};

function asqrsF281() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs281").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs281").src = "img/sqrs/blSqr.png"
};};};

function asqrsF282() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs282").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs282").src = "img/sqrs/blSqr.png"
};};};

function asqrsF283() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs283").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs283").src = "img/sqrs/blSqr.png"
};};};

function asqrsF284() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs284").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs284").src = "img/sqrs/blSqr.png"
};};};

function asqrsF285() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs285").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs285").src = "img/sqrs/blSqr.png"
};};};

function asqrsF286() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs286").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs286").src = "img/sqrs/blSqr.png"
};};};

function asqrsF287() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs287").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs287").src = "img/sqrs/blSqr.png"
};};};

function asqrsF288() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs288").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs288").src = "img/sqrs/blSqr.png"
};};};

function asqrsF289() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs289").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs289").src = "img/sqrs/blSqr.png"
};};};

function asqrsF290() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs290").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs290").src = "img/sqrs/blSqr.png"
};};};

function asqrsF291() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs291").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs291").src = "img/sqrs/blSqr.png"
};};};

function asqrsF292() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs292").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs292").src = "img/sqrs/blSqr.png"
};};};

function asqrsF293() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs293").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs293").src = "img/sqrs/blSqr.png"
};};};

function asqrsF294() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs294").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs294").src = "img/sqrs/blSqr.png"
};};};

function asqrsF295() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs295").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs295").src = "img/sqrs/blSqr.png"
};};};

function asqrsF296() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs296").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs296").src = "img/sqrs/blSqr.png"
};};};

function asqrsF297() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs297").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs297").src = "img/sqrs/blSqr.png"
};};};

function asqrsF298() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs298").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs298").src = "img/sqrs/blSqr.png"
};};};

function asqrsF299() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs299").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs299").src = "img/sqrs/blSqr.png"
};};};

function asqrsF300() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs300").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs300").src = "img/sqrs/blSqr.png"
};};};

function asqrsG301() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs301").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs301").src = "img/sqrs/blSqr.png"
};};};

function asqrsG302() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs302").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs302").src = "img/sqrs/blSqr.png"
};};};

function asqrsG303() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs303").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs303").src = "img/sqrs/blSqr.png"
};};};

function asqrsG304() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs304").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs304").src = "img/sqrs/blSqr.png"
};};};

function asqrsG305() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs305").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs305").src = "img/sqrs/blSqr.png"
};};};

function asqrsG306() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs306").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs306").src = "img/sqrs/blSqr.png"
};};};

function asqrsG307() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs307").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs307").src = "img/sqrs/blSqr.png"
};};};

function asqrsG308() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs308").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs308").src = "img/sqrs/blSqr.png"
};};};

function asqrsG309() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs309").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs309").src = "img/sqrs/blSqr.png"
};};};

function asqrsG310() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs310").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs310").src = "img/sqrs/blSqr.png"
};};};

function asqrsG311() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs311").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs311").src = "img/sqrs/blSqr.png"
};};};

function asqrsG312() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs312").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs312").src = "img/sqrs/blSqr.png"
};};};

function asqrsG313() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs313").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs313").src = "img/sqrs/blSqr.png"
};};};

function asqrsG314() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs314").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs314").src = "img/sqrs/blSqr.png"
};};};

function asqrsG315() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs315").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs315").src = "img/sqrs/blSqr.png"
};};};

function asqrsG316() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs316").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs316").src = "img/sqrs/blSqr.png"
};};};

function asqrsG317() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs317").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs317").src = "img/sqrs/blSqr.png"
};};};

function asqrsG318() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs318").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs318").src = "img/sqrs/blSqr.png"
};};};

function asqrsG319() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs319").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs319").src = "img/sqrs/blSqr.png"
};};};

function asqrsG320() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs320").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs320").src = "img/sqrs/blSqr.png"
};};};

function asqrsG321() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs321").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs321").src = "img/sqrs/blSqr.png"
};};};

function asqrsG322() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs322").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs322").src = "img/sqrs/blSqr.png"
};};};

function asqrsG323() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs323").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs323").src = "img/sqrs/blSqr.png"
};};};

function asqrsG324() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs324").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs324").src = "img/sqrs/blSqr.png"
};};};

function asqrsG325() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs325").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs325").src = "img/sqrs/blSqr.png"
};};};

function asqrsG326() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs326").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs326").src = "img/sqrs/blSqr.png"
};};};

function asqrsG327() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs327").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs327").src = "img/sqrs/blSqr.png"
};};};

function asqrsG328() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs328").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs328").src = "img/sqrs/blSqr.png"
};};};

function asqrsG329() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs329").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs329").src = "img/sqrs/blSqr.png"
};};};

function asqrsG330() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs330").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs330").src = "img/sqrs/blSqr.png"
};};};

function asqrsG331() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs331").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs331").src = "img/sqrs/blSqr.png"
};};};

function asqrsG332() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs332").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs332").src = "img/sqrs/blSqr.png"
};};};

function asqrsG333() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs333").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs333").src = "img/sqrs/blSqr.png"
};};};

function asqrsG334() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs334").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs334").src = "img/sqrs/blSqr.png"
};};};

function asqrsG335() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs335").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs335").src = "img/sqrs/blSqr.png"
};};};

function asqrsG336() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs336").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs336").src = "img/sqrs/blSqr.png"
};};};

function asqrsG337() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs337").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs337").src = "img/sqrs/blSqr.png"
};};};

function asqrsG338() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs338").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs338").src = "img/sqrs/blSqr.png"
};};};

function asqrsG339() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs339").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs339").src = "img/sqrs/blSqr.png"
};};};

function asqrsG340() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs340").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs340").src = "img/sqrs/blSqr.png"
};};};

function asqrsG341() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs341").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs341").src = "img/sqrs/blSqr.png"
};};};

function asqrsG342() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs342").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs342").src = "img/sqrs/blSqr.png"
};};};

function asqrsG343() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs343").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs343").src = "img/sqrs/blSqr.png"
};};};

function asqrsG344() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs344").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs344").src = "img/sqrs/blSqr.png"
};};};

function asqrsG345() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs345").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs345").src = "img/sqrs/blSqr.png"
};};};

function asqrsG346() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs346").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs346").src = "img/sqrs/blSqr.png"
};};};

function asqrsG347() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs347").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs347").src = "img/sqrs/blSqr.png"
};};};

function asqrsG348() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs348").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs348").src = "img/sqrs/blSqr.png"
};};};

function asqrsG349() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs349").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs349").src = "img/sqrs/blSqr.png"
};};};

function asqrsG350() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs350").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs350").src = "img/sqrs/blSqr.png"
};};};

function asqrsH351() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs351").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs351").src = "img/sqrs/blSqr.png"
};};};

function asqrsH352() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs352").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs352").src = "img/sqrs/blSqr.png"
};};};

function asqrsH353() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs353").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs353").src = "img/sqrs/blSqr.png"
};};};

function asqrsH354() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs354").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs354").src = "img/sqrs/blSqr.png"
};};};

function asqrsH355() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs355").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs355").src = "img/sqrs/blSqr.png"
};};};

function asqrsH356() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs356").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs356").src = "img/sqrs/blSqr.png"
};};};

function asqrsH357() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs357").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs357").src = "img/sqrs/blSqr.png"
};};};

function asqrsH358() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs358").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs358").src = "img/sqrs/blSqr.png"
};};};

function asqrsH359() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs359").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs359").src = "img/sqrs/blSqr.png"
};};};

function asqrsH360() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs360").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs360").src = "img/sqrs/blSqr.png"
};};};

function asqrsH361() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs361").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs361").src = "img/sqrs/blSqr.png"
};};};

function asqrsH362() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs362").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs362").src = "img/sqrs/blSqr.png"
};};};

function asqrsH363() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs363").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs363").src = "img/sqrs/blSqr.png"
};};};

function asqrsH364() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs364").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs364").src = "img/sqrs/blSqr.png"
};};};

function asqrsH365() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs365").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs365").src = "img/sqrs/blSqr.png"
};};};

function asqrsH366() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs366").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs366").src = "img/sqrs/blSqr.png"
};};};

function asqrsH367() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs367").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs367").src = "img/sqrs/blSqr.png"
};};};

function asqrsH368() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs368").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs368").src = "img/sqrs/blSqr.png"
};};};

function asqrsH369() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs369").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs369").src = "img/sqrs/blSqr.png"
};};};

function asqrsH370() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs370").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs370").src = "img/sqrs/blSqr.png"
};};};

function asqrsH371() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs371").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs371").src = "img/sqrs/blSqr.png"
};};};

function asqrsH372() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs372").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs372").src = "img/sqrs/blSqr.png"
};};};

function asqrsH373() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs373").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs373").src = "img/sqrs/blSqr.png"
};};};

function asqrsH374() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs374").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs374").src = "img/sqrs/blSqr.png"
};};};

function asqrsH375() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs375").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs375").src = "img/sqrs/blSqr.png"
};};};

function asqrsH376() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs376").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs376").src = "img/sqrs/blSqr.png"
};};};

function asqrsH377() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs377").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs377").src = "img/sqrs/blSqr.png"
};};};

function asqrsH378() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs378").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs378").src = "img/sqrs/blSqr.png"
};};};

function asqrsH379() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs379").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs379").src = "img/sqrs/blSqr.png"
};};};

function asqrsH380() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs380").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs380").src = "img/sqrs/blSqr.png"
};};};

function asqrsH381() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs381").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs381").src = "img/sqrs/blSqr.png"
};};};

function asqrsH382() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs382").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs382").src = "img/sqrs/blSqr.png"
};};};

function asqrsH383() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs383").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs383").src = "img/sqrs/blSqr.png"
};};};

function asqrsH384() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs384").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs384").src = "img/sqrs/blSqr.png"
};};};

function asqrsH385() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs385").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs385").src = "img/sqrs/blSqr.png"
};};};

function asqrsH386() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs386").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs386").src = "img/sqrs/blSqr.png"
};};};

function asqrsH387() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs387").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs387").src = "img/sqrs/blSqr.png"
};};};

function asqrsH388() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs388").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs388").src = "img/sqrs/blSqr.png"
};};};

function asqrsH389() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs389").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs389").src = "img/sqrs/blSqr.png"
};};};

function asqrsH390() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs390").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs390").src = "img/sqrs/blSqr.png"
};};};

function asqrsH391() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs391").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs391").src = "img/sqrs/blSqr.png"
};};};

function asqrsH392() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs392").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs392").src = "img/sqrs/blSqr.png"
};};};

function asqrsH393() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs393").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs393").src = "img/sqrs/blSqr.png"
};};};

function asqrsH394() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs394").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs394").src = "img/sqrs/blSqr.png"
};};};

function asqrsH395() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs395").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs395").src = "img/sqrs/blSqr.png"
};};};

function asqrsH396() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs396").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs396").src = "img/sqrs/blSqr.png"
};};};

function asqrsH397() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs397").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs397").src = "img/sqrs/blSqr.png"
};};};

function asqrsH398() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs398").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs398").src = "img/sqrs/blSqr.png"
};};};

function asqrsH399() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs399").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs399").src = "img/sqrs/blSqr.png"
};};};

function asqrsH400() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs400").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs400").src = "img/sqrs/blSqr.png"
};};};

function asqrsI401() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs401").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs401").src = "img/sqrs/blSqr.png"
};};};

function asqrsI402() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs402").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs402").src = "img/sqrs/blSqr.png"
};};};

function asqrsI403() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs403").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs403").src = "img/sqrs/blSqr.png"
};};};

function asqrsI404() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs404").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs404").src = "img/sqrs/blSqr.png"
};};};

function asqrsI405() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs405").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs405").src = "img/sqrs/blSqr.png"
};};};

function asqrsI406() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs406").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs406").src = "img/sqrs/blSqr.png"
};};};

function asqrsI407() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs407").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs407").src = "img/sqrs/blSqr.png"
};};};

function asqrsI408() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs408").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs408").src = "img/sqrs/blSqr.png"
};};};

function asqrsI409() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs409").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs409").src = "img/sqrs/blSqr.png"
};};};

function asqrsI410() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs410").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs410").src = "img/sqrs/blSqr.png"
};};};

function asqrsI411() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs411").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs411").src = "img/sqrs/blSqr.png"
};};};

function asqrsI412() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs412").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs412").src = "img/sqrs/blSqr.png"
};};};

function asqrsI413() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs413").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs413").src = "img/sqrs/blSqr.png"
};};};

function asqrsI414() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs414").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs414").src = "img/sqrs/blSqr.png"
};};};

function asqrsI415() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs415").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs415").src = "img/sqrs/blSqr.png"
};};};

function asqrsI416() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs416").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs416").src = "img/sqrs/blSqr.png"
};};};

function asqrsI417() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs417").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs417").src = "img/sqrs/blSqr.png"
};};};

function asqrsI418() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs418").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs418").src = "img/sqrs/blSqr.png"
};};};

function asqrsI419() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs419").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs419").src = "img/sqrs/blSqr.png"
};};};

function asqrsI420() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs420").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs420").src = "img/sqrs/blSqr.png"
};};};

function asqrsI421() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs421").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs421").src = "img/sqrs/blSqr.png"
};};};

function asqrsI422() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs422").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs422").src = "img/sqrs/blSqr.png"
};};};

function asqrsI423() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs423").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs423").src = "img/sqrs/blSqr.png"
};};};

function asqrsI424() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs424").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs424").src = "img/sqrs/blSqr.png"
};};};

function asqrsI425() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs425").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs425").src = "img/sqrs/blSqr.png"
};};};

function asqrsI426() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs426").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs426").src = "img/sqrs/blSqr.png"
};};};

function asqrsI427() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs427").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs427").src = "img/sqrs/blSqr.png"
};};};

function asqrsI428() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs428").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs428").src = "img/sqrs/blSqr.png"
};};};

function asqrsI429() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs429").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs429").src = "img/sqrs/blSqr.png"
};};};

function asqrsI430() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs430").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs430").src = "img/sqrs/blSqr.png"
};};};

function asqrsI431() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs431").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs431").src = "img/sqrs/blSqr.png"
};};};

function asqrsI432() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs432").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs432").src = "img/sqrs/blSqr.png"
};};};

function asqrsI433() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs433").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs433").src = "img/sqrs/blSqr.png"
};};};

function asqrsI434() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs434").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs434").src = "img/sqrs/blSqr.png"
};};};

function asqrsI435() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs435").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs435").src = "img/sqrs/blSqr.png"
};};};

function asqrsI436() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs436").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs436").src = "img/sqrs/blSqr.png"
};};};

function asqrsI437() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs437").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs437").src = "img/sqrs/blSqr.png"
};};};

function asqrsI438() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs438").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs438").src = "img/sqrs/blSqr.png"
};};};

function asqrsI439() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs439").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs439").src = "img/sqrs/blSqr.png"
};};};

function asqrsI440() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs440").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs440").src = "img/sqrs/blSqr.png"
};};};

function asqrsI441() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs441").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs441").src = "img/sqrs/blSqr.png"
};};};

function asqrsI442() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs442").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs442").src = "img/sqrs/blSqr.png"
};};};

function asqrsI443() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs443").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs443").src = "img/sqrs/blSqr.png"
};};};

function asqrsI444() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs444").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs444").src = "img/sqrs/blSqr.png"
};};};

function asqrsI445() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs445").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs445").src = "img/sqrs/blSqr.png"
};};};

function asqrsI446() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs446").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs446").src = "img/sqrs/blSqr.png"
};};};

function asqrsI447() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs447").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs447").src = "img/sqrs/blSqr.png"
};};};

function asqrsI448() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs448").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs448").src = "img/sqrs/blSqr.png"
};};};

function asqrsI449() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs449").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs449").src = "img/sqrs/blSqr.png"
};};};

function asqrsI450() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs450").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs450").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ451() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs451").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs451").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ452() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs452").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs452").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ453() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs453").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs453").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ454() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs454").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs454").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ455() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs455").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs455").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ456() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs456").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs456").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ457() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs457").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs457").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ458() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs458").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs458").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ459() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs459").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs459").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ460() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs460").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs460").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ461() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs461").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs461").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ462() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs462").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs462").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ463() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs463").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs463").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ464() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs464").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs464").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ465() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs465").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs465").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ466() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs466").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs466").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ467() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs467").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs467").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ468() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs468").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs468").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ469() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs469").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs469").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ470() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs470").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs470").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ471() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs471").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs471").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ472() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs472").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs472").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ473() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs473").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs473").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ474() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs474").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs474").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ475() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs475").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs475").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ476() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs476").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs476").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ477() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs477").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs477").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ478() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs478").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs478").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ479() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs479").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs479").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ480() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs480").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs480").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ481() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs481").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs481").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ482() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs482").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs482").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ483() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs483").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs483").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ484() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs484").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs484").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ485() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs485").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs485").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ486() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs486").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs486").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ487() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs487").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs487").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ488() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs488").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs488").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ489() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs489").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs489").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ490() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs490").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs490").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ491() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs491").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs491").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ492() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs492").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs492").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ493() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs493").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs493").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ494() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs494").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs494").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ495() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs495").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs495").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ496() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs496").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs496").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ497() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs497").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs497").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ498() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs498").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs498").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ499() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs499").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs499").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ500() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs500").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs500").src = "img/sqrs/blSqr.png"
};};};

function asqrsK501() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs501").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs501").src = "img/sqrs/blSqr.png"
};};};

function asqrsK502() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs502").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs502").src = "img/sqrs/blSqr.png"
};};};

function asqrsK503() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs503").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs503").src = "img/sqrs/blSqr.png"
};};};

function asqrsK504() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs504").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs504").src = "img/sqrs/blSqr.png"
};};};

function asqrsK505() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs505").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs505").src = "img/sqrs/blSqr.png"
};};};

function asqrsK506() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs506").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs506").src = "img/sqrs/blSqr.png"
};};};

function asqrsK507() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs507").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs507").src = "img/sqrs/blSqr.png"
};};};

function asqrsK508() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs508").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs508").src = "img/sqrs/blSqr.png"
};};};

function asqrsK509() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs509").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs509").src = "img/sqrs/blSqr.png"
};};};

function asqrsK510() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs510").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs510").src = "img/sqrs/blSqr.png"
};};};

function asqrsK511() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs511").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs511").src = "img/sqrs/blSqr.png"
};};};

function asqrsK512() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs512").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs512").src = "img/sqrs/blSqr.png"
};};};

function asqrsK513() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs513").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs513").src = "img/sqrs/blSqr.png"
};};};

function asqrsK514() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs514").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs514").src = "img/sqrs/blSqr.png"
};};};

function asqrsK515() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs515").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs515").src = "img/sqrs/blSqr.png"
};};};

function asqrsK516() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs516").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs516").src = "img/sqrs/blSqr.png"
};};};

function asqrsK517() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs517").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs517").src = "img/sqrs/blSqr.png"
};};};

function asqrsK518() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs518").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs518").src = "img/sqrs/blSqr.png"
};};};

function asqrsK519() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs519").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs519").src = "img/sqrs/blSqr.png"
};};};

function asqrsK520() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs520").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs520").src = "img/sqrs/blSqr.png"
};};};

function asqrsK521() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs521").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs521").src = "img/sqrs/blSqr.png"
};};};

function asqrsK522() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs522").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs522").src = "img/sqrs/blSqr.png"
};};};

function asqrsK523() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs523").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs523").src = "img/sqrs/blSqr.png"
};};};

function asqrsK524() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs524").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs524").src = "img/sqrs/blSqr.png"
};};};

function asqrsK525() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs525").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs525").src = "img/sqrs/blSqr.png"
};};};

function asqrsK526() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs526").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs526").src = "img/sqrs/blSqr.png"
};};};

function asqrsK527() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs527").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs527").src = "img/sqrs/blSqr.png"
};};};

function asqrsK528() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs528").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs528").src = "img/sqrs/blSqr.png"
};};};

function asqrsK529() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs529").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs529").src = "img/sqrs/blSqr.png"
};};};

function asqrsK530() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs530").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs530").src = "img/sqrs/blSqr.png"
};};};

function asqrsK531() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs531").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs531").src = "img/sqrs/blSqr.png"
};};};

function asqrsK532() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs532").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs532").src = "img/sqrs/blSqr.png"
};};};

function asqrsK533() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs533").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs533").src = "img/sqrs/blSqr.png"
};};};

function asqrsK534() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs534").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs534").src = "img/sqrs/blSqr.png"
};};};

function asqrsK535() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs535").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs535").src = "img/sqrs/blSqr.png"
};};};

function asqrsK536() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs536").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs536").src = "img/sqrs/blSqr.png"
};};};

function asqrsK537() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs537").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs537").src = "img/sqrs/blSqr.png"
};};};

function asqrsK538() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs538").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs538").src = "img/sqrs/blSqr.png"
};};};

function asqrsK539() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs539").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs539").src = "img/sqrs/blSqr.png"
};};};

function asqrsK540() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs540").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs540").src = "img/sqrs/blSqr.png"
};};};

function asqrsK541() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs541").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs541").src = "img/sqrs/blSqr.png"
};};};

function asqrsK542() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs542").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs542").src = "img/sqrs/blSqr.png"
};};};

function asqrsK543() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs543").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs543").src = "img/sqrs/blSqr.png"
};};};

function asqrsK544() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs544").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs544").src = "img/sqrs/blSqr.png"
};};};

function asqrsK545() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs545").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs545").src = "img/sqrs/blSqr.png"
};};};

function asqrsK546() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs546").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs546").src = "img/sqrs/blSqr.png"
};};};

function asqrsK547() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs547").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs547").src = "img/sqrs/blSqr.png"
};};};

function asqrsK548() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs548").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs548").src = "img/sqrs/blSqr.png"
};};};

function asqrsK549() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs549").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs549").src = "img/sqrs/blSqr.png"
};};};

function asqrsK550() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs550").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs550").src = "img/sqrs/blSqr.png"
};};};

function asqrsL551() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs551").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs551").src = "img/sqrs/blSqr.png"
};};};

function asqrsL552() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs552").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs552").src = "img/sqrs/blSqr.png"
};};};

function asqrsL553() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs553").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs553").src = "img/sqrs/blSqr.png"
};};};

function asqrsL554() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs554").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs554").src = "img/sqrs/blSqr.png"
};};};

function asqrsL555() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs555").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs555").src = "img/sqrs/blSqr.png"
};};};

function asqrsL556() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs556").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs556").src = "img/sqrs/blSqr.png"
};};};

function asqrsL557() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs557").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs557").src = "img/sqrs/blSqr.png"
};};};

function asqrsL558() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs558").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs558").src = "img/sqrs/blSqr.png"
};};};

function asqrsL559() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs559").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs559").src = "img/sqrs/blSqr.png"
};};};

function asqrsL560() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs560").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs560").src = "img/sqrs/blSqr.png"
};};};

function asqrsL561() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs561").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs561").src = "img/sqrs/blSqr.png"
};};};

function asqrsL562() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs562").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs562").src = "img/sqrs/blSqr.png"
};};};

function asqrsL563() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs563").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs563").src = "img/sqrs/blSqr.png"
};};};

function asqrsL564() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs564").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs564").src = "img/sqrs/blSqr.png"
};};};

function asqrsL565() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs565").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs565").src = "img/sqrs/blSqr.png"
};};};

function asqrsL566() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs566").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs566").src = "img/sqrs/blSqr.png"
};};};

function asqrsL567() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs567").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs567").src = "img/sqrs/blSqr.png"
};};};

function asqrsL568() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs568").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs568").src = "img/sqrs/blSqr.png"
};};};

function asqrsL569() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs569").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs569").src = "img/sqrs/blSqr.png"
};};};

function asqrsL570() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs570").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs570").src = "img/sqrs/blSqr.png"
};};};

function asqrsL571() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs571").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs571").src = "img/sqrs/blSqr.png"
};};};

function asqrsL572() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs572").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs572").src = "img/sqrs/blSqr.png"
};};};

function asqrsL573() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs573").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs573").src = "img/sqrs/blSqr.png"
};};};

function asqrsL574() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs574").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs574").src = "img/sqrs/blSqr.png"
};};};

function asqrsL575() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs575").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs575").src = "img/sqrs/blSqr.png"
};};};

function asqrsL576() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs576").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs576").src = "img/sqrs/blSqr.png"
};};};

function asqrsL577() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs577").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs577").src = "img/sqrs/blSqr.png"
};};};

function asqrsL578() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs578").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs578").src = "img/sqrs/blSqr.png"
};};};

function asqrsL579() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs579").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs579").src = "img/sqrs/blSqr.png"
};};};

function asqrsL580() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs580").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs580").src = "img/sqrs/blSqr.png"
};};};

function asqrsL581() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs581").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs581").src = "img/sqrs/blSqr.png"
};};};

function asqrsL582() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs582").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs582").src = "img/sqrs/blSqr.png"
};};};

function asqrsL583() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs583").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs583").src = "img/sqrs/blSqr.png"
};};};

function asqrsL584() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs584").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs584").src = "img/sqrs/blSqr.png"
};};};

function asqrsL585() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs585").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs585").src = "img/sqrs/blSqr.png"
};};};

function asqrsL586() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs586").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs586").src = "img/sqrs/blSqr.png"
};};};

function asqrsL587() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs587").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs587").src = "img/sqrs/blSqr.png"
};};};

function asqrsL588() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs588").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs588").src = "img/sqrs/blSqr.png"
};};};

function asqrsL589() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs589").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs589").src = "img/sqrs/blSqr.png"
};};};

function asqrsL590() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs590").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs590").src = "img/sqrs/blSqr.png"
};};};

function asqrsL591() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs591").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs591").src = "img/sqrs/blSqr.png"
};};};

function asqrsL592() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs592").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs592").src = "img/sqrs/blSqr.png"
};};};

function asqrsL593() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs593").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs593").src = "img/sqrs/blSqr.png"
};};};

function asqrsL594() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs594").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs594").src = "img/sqrs/blSqr.png"
};};};

function asqrsL595() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs595").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs595").src = "img/sqrs/blSqr.png"
};};};

function asqrsL596() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs596").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs596").src = "img/sqrs/blSqr.png"
};};};

function asqrsL597() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs597").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs597").src = "img/sqrs/blSqr.png"
};};};

function asqrsL598() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs598").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs598").src = "img/sqrs/blSqr.png"
};};};

function asqrsL599() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs599").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs599").src = "img/sqrs/blSqr.png"
};};};

function asqrsL600() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs600").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs600").src = "img/sqrs/blSqr.png"
};};};

function asqrsM601() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs601").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs601").src = "img/sqrs/blSqr.png"
};};};

function asqrsM602() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs602").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs602").src = "img/sqrs/blSqr.png"
};};};

function asqrsM603() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs603").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs603").src = "img/sqrs/blSqr.png"
};};};

function asqrsM604() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs604").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs604").src = "img/sqrs/blSqr.png"
};};};

function asqrsM605() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs605").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs605").src = "img/sqrs/blSqr.png"
};};};

function asqrsM606() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs606").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs606").src = "img/sqrs/blSqr.png"
};};};

function asqrsM607() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs607").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs607").src = "img/sqrs/blSqr.png"
};};};

function asqrsM608() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs608").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs608").src = "img/sqrs/blSqr.png"
};};};

function asqrsM609() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs609").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs609").src = "img/sqrs/blSqr.png"
};};};

function asqrsM610() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs610").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs610").src = "img/sqrs/blSqr.png"
};};};

function asqrsM611() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs611").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs611").src = "img/sqrs/blSqr.png"
};};};

function asqrsM612() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs612").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs612").src = "img/sqrs/blSqr.png"
};};};

function asqrsM613() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs613").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs613").src = "img/sqrs/blSqr.png"
};};};

function asqrsM614() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs614").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs614").src = "img/sqrs/blSqr.png"
};};};

function asqrsM615() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs615").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs615").src = "img/sqrs/blSqr.png"
};};};

function asqrsM616() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs616").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs616").src = "img/sqrs/blSqr.png"
};};};

function asqrsM617() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs617").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs617").src = "img/sqrs/blSqr.png"
};};};

function asqrsM618() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs618").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs618").src = "img/sqrs/blSqr.png"
};};};

function asqrsM619() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs619").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs619").src = "img/sqrs/blSqr.png"
};};};

function asqrsM620() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs620").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs620").src = "img/sqrs/blSqr.png"
};};};

function asqrsM621() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs621").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs621").src = "img/sqrs/blSqr.png"
};};};

function asqrsM622() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs622").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs622").src = "img/sqrs/blSqr.png"
};};};

function asqrsM623() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs623").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs623").src = "img/sqrs/blSqr.png"
};};};

function asqrsM624() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs624").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs624").src = "img/sqrs/blSqr.png"
};};};

function asqrsM625() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs625").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs625").src = "img/sqrs/blSqr.png"
};};};

function asqrsM626() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs626").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs626").src = "img/sqrs/blSqr.png"
};};};

function asqrsM627() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs627").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs627").src = "img/sqrs/blSqr.png"
};};};

function asqrsM628() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs628").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs628").src = "img/sqrs/blSqr.png"
};};};

function asqrsM629() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs629").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs629").src = "img/sqrs/blSqr.png"
};};};

function asqrsM630() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs630").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs630").src = "img/sqrs/blSqr.png"
};};};

function asqrsM631() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs631").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs631").src = "img/sqrs/blSqr.png"
};};};

function asqrsM632() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs632").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs632").src = "img/sqrs/blSqr.png"
};};};

function asqrsM633() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs633").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs633").src = "img/sqrs/blSqr.png"
};};};

function asqrsM634() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs634").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs634").src = "img/sqrs/blSqr.png"
};};};

function asqrsM635() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs635").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs635").src = "img/sqrs/blSqr.png"
};};};

function asqrsM636() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs636").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs636").src = "img/sqrs/blSqr.png"
};};};

function asqrsM637() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs637").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs637").src = "img/sqrs/blSqr.png"
};};};

function asqrsM638() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs638").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs638").src = "img/sqrs/blSqr.png"
};};};

function asqrsM639() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs639").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs639").src = "img/sqrs/blSqr.png"
};};};

function asqrsM640() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs640").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs640").src = "img/sqrs/blSqr.png"
};};};

function asqrsM641() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs641").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs641").src = "img/sqrs/blSqr.png"
};};};

function asqrsM642() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs642").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs642").src = "img/sqrs/blSqr.png"
};};};

function asqrsM643() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs643").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs643").src = "img/sqrs/blSqr.png"
};};};

function asqrsM644() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs644").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs644").src = "img/sqrs/blSqr.png"
};};};

function asqrsM645() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs645").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs645").src = "img/sqrs/blSqr.png"
};};};

function asqrsM646() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs646").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs646").src = "img/sqrs/blSqr.png"
};};};

function asqrsM647() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs647").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs647").src = "img/sqrs/blSqr.png"
};};};

function asqrsM648() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs648").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs648").src = "img/sqrs/blSqr.png"
};};};

function asqrsM649() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs649").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs649").src = "img/sqrs/blSqr.png"
};};};

function asqrsM650() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs650").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs650").src = "img/sqrs/blSqr.png"
};};};

function asqrsN651() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs651").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs651").src = "img/sqrs/blSqr.png"
};};};

function asqrsN652() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs652").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs652").src = "img/sqrs/blSqr.png"
};};};

function asqrsN653() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs653").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs653").src = "img/sqrs/blSqr.png"
};};};

function asqrsN654() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs654").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs654").src = "img/sqrs/blSqr.png"
};};};

function asqrsN655() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs655").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs655").src = "img/sqrs/blSqr.png"
};};};

function asqrsN656() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs656").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs656").src = "img/sqrs/blSqr.png"
};};};

function asqrsN657() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs657").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs657").src = "img/sqrs/blSqr.png"
};};};

function asqrsN658() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs658").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs658").src = "img/sqrs/blSqr.png"
};};};

function asqrsN659() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs659").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs659").src = "img/sqrs/blSqr.png"
};};};

function asqrsN660() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs660").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs660").src = "img/sqrs/blSqr.png"
};};};

function asqrsN661() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs661").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs661").src = "img/sqrs/blSqr.png"
};};};

function asqrsN662() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs662").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs662").src = "img/sqrs/blSqr.png"
};};};

function asqrsN663() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs663").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs663").src = "img/sqrs/blSqr.png"
};};};

function asqrsN664() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs664").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs664").src = "img/sqrs/blSqr.png"
};};};

function asqrsN665() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs665").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs665").src = "img/sqrs/blSqr.png"
};};};

function asqrsN666() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs666").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs666").src = "img/sqrs/blSqr.png"
};};};

function asqrsN667() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs667").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs667").src = "img/sqrs/blSqr.png"
};};};

function asqrsN668() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs668").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs668").src = "img/sqrs/blSqr.png"
};};};

function asqrsN669() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs669").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs669").src = "img/sqrs/blSqr.png"
};};};

function asqrsN670() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs670").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs670").src = "img/sqrs/blSqr.png"
};};};

function asqrsN671() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs671").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs671").src = "img/sqrs/blSqr.png"
};};};

function asqrsN672() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs672").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs672").src = "img/sqrs/blSqr.png"
};};};

function asqrsN673() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs673").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs673").src = "img/sqrs/blSqr.png"
};};};

function asqrsN674() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs674").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs674").src = "img/sqrs/blSqr.png"
};};};

function asqrsN675() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs675").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs675").src = "img/sqrs/blSqr.png"
};};};

function asqrsN676() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs676").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs676").src = "img/sqrs/blSqr.png"
};};};

function asqrsN677() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs677").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs677").src = "img/sqrs/blSqr.png"
};};};

function asqrsN678() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs678").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs678").src = "img/sqrs/blSqr.png"
};};};

function asqrsN679() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs679").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs679").src = "img/sqrs/blSqr.png"
};};};

function asqrsN680() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs680").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs680").src = "img/sqrs/blSqr.png"
};};};

function asqrsN681() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs681").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs681").src = "img/sqrs/blSqr.png"
};};};

function asqrsN682() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs682").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs682").src = "img/sqrs/blSqr.png"
};};};

function asqrsN683() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs683").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs683").src = "img/sqrs/blSqr.png"
};};};

function asqrsN684() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs684").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs684").src = "img/sqrs/blSqr.png"
};};};

function asqrsN685() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs685").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs685").src = "img/sqrs/blSqr.png"
};};};

function asqrsN686() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs686").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs686").src = "img/sqrs/blSqr.png"
};};};

function asqrsN687() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs687").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs687").src = "img/sqrs/blSqr.png"
};};};

function asqrsN688() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs688").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs688").src = "img/sqrs/blSqr.png"
};};};

function asqrsN689() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs689").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs689").src = "img/sqrs/blSqr.png"
};};};

function asqrsN690() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs690").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs690").src = "img/sqrs/blSqr.png"
};};};

function asqrsN691() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs691").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs691").src = "img/sqrs/blSqr.png"
};};};

function asqrsN692() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs692").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs692").src = "img/sqrs/blSqr.png"
};};};

function asqrsN693() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs693").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs693").src = "img/sqrs/blSqr.png"
};};};

function asqrsN694() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs694").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs694").src = "img/sqrs/blSqr.png"
};};};

function asqrsN695() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs695").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs695").src = "img/sqrs/blSqr.png"
};};};

function asqrsN696() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs696").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs696").src = "img/sqrs/blSqr.png"
};};};

function asqrsN697() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs697").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs697").src = "img/sqrs/blSqr.png"
};};};

function asqrsN698() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs698").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs698").src = "img/sqrs/blSqr.png"
};};};

function asqrsN699() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs699").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs699").src = "img/sqrs/blSqr.png"
};};};

function asqrsN700() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs700").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs700").src = "img/sqrs/blSqr.png"
};};};

function asqrsO701() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs701").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs701").src = "img/sqrs/blSqr.png"
};};};

function asqrsO702() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs702").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs702").src = "img/sqrs/blSqr.png"
};};};

function asqrsO703() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs703").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs703").src = "img/sqrs/blSqr.png"
};};};

function asqrsO704() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs704").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs704").src = "img/sqrs/blSqr.png"
};};};

function asqrsO705() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs705").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs705").src = "img/sqrs/blSqr.png"
};};};

function asqrsO706() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs706").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs706").src = "img/sqrs/blSqr.png"
};};};

function asqrsO707() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs707").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs707").src = "img/sqrs/blSqr.png"
};};};

function asqrsO708() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs708").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs708").src = "img/sqrs/blSqr.png"
};};};

function asqrsO709() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs709").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs709").src = "img/sqrs/blSqr.png"
};};};

function asqrsO710() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs710").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs710").src = "img/sqrs/blSqr.png"
};};};

function asqrsO711() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs711").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs711").src = "img/sqrs/blSqr.png"
};};};

function asqrsO712() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs712").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs712").src = "img/sqrs/blSqr.png"
};};};

function asqrsO713() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs713").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs713").src = "img/sqrs/blSqr.png"
};};};

function asqrsO714() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs714").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs714").src = "img/sqrs/blSqr.png"
};};};

function asqrsO715() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs715").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs715").src = "img/sqrs/blSqr.png"
};};};

function asqrsO716() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs716").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs716").src = "img/sqrs/blSqr.png"
};};};

function asqrsO717() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs717").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs717").src = "img/sqrs/blSqr.png"
};};};

function asqrsO718() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs718").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs718").src = "img/sqrs/blSqr.png"
};};};

function asqrsO719() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs719").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs719").src = "img/sqrs/blSqr.png"
};};};

function asqrsO720() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs720").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs720").src = "img/sqrs/blSqr.png"
};};};

function asqrsO721() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs721").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs721").src = "img/sqrs/blSqr.png"
};};};

function asqrsO722() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs722").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs722").src = "img/sqrs/blSqr.png"
};};};

function asqrsO723() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs723").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs723").src = "img/sqrs/blSqr.png"
};};};

function asqrsO724() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs724").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs724").src = "img/sqrs/blSqr.png"
};};};

function asqrsO725() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs725").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs725").src = "img/sqrs/blSqr.png"
};};};

function asqrsO726() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs726").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs726").src = "img/sqrs/blSqr.png"
};};};

function asqrsO727() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs727").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs727").src = "img/sqrs/blSqr.png"
};};};

function asqrsO728() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs728").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs728").src = "img/sqrs/blSqr.png"
};};};

function asqrsO729() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs729").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs729").src = "img/sqrs/blSqr.png"
};};};

function asqrsO730() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs730").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs730").src = "img/sqrs/blSqr.png"
};};};

function asqrsO731() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs731").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs731").src = "img/sqrs/blSqr.png"
};};};

function asqrsO732() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs732").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs732").src = "img/sqrs/blSqr.png"
};};};

function asqrsO733() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs733").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs733").src = "img/sqrs/blSqr.png"
};};};

function asqrsO734() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs734").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs734").src = "img/sqrs/blSqr.png"
};};};

function asqrsO735() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs735").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs735").src = "img/sqrs/blSqr.png"
};};};

function asqrsO736() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs736").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs736").src = "img/sqrs/blSqr.png"
};};};

function asqrsO737() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs737").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs737").src = "img/sqrs/blSqr.png"
};};};

function asqrsO738() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs738").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs738").src = "img/sqrs/blSqr.png"
};};};

function asqrsO739() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs739").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs739").src = "img/sqrs/blSqr.png"
};};};

function asqrsO740() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs740").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs740").src = "img/sqrs/blSqr.png"
};};};

function asqrsO741() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs741").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs741").src = "img/sqrs/blSqr.png"
};};};

function asqrsO742() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs742").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs742").src = "img/sqrs/blSqr.png"
};};};

function asqrsO743() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs743").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs743").src = "img/sqrs/blSqr.png"
};};};

function asqrsO744() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs744").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs744").src = "img/sqrs/blSqr.png"
};};};

function asqrsO745() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs745").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs745").src = "img/sqrs/blSqr.png"
};};};

function asqrsO746() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs746").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs746").src = "img/sqrs/blSqr.png"
};};};

function asqrsO747() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs747").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs747").src = "img/sqrs/blSqr.png"
};};};

function asqrsO748() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs748").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs748").src = "img/sqrs/blSqr.png"
};};};

function asqrsO749() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs749").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs749").src = "img/sqrs/blSqr.png"
};};};

function asqrsO750() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs750").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs750").src = "img/sqrs/blSqr.png"
};};};

function asqrsP751() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs751").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs751").src = "img/sqrs/blSqr.png"
};};};

function asqrsP752() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs752").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs752").src = "img/sqrs/blSqr.png"
};};};

function asqrsP753() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs753").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs753").src = "img/sqrs/blSqr.png"
};};};

function asqrsP754() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs754").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs754").src = "img/sqrs/blSqr.png"
};};};

function asqrsP755() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs755").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs755").src = "img/sqrs/blSqr.png"
};};};

function asqrsP756() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs756").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs756").src = "img/sqrs/blSqr.png"
};};};

function asqrsP757() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs757").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs757").src = "img/sqrs/blSqr.png"
};};};

function asqrsP758() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs758").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs758").src = "img/sqrs/blSqr.png"
};};};

function asqrsP759() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs759").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs759").src = "img/sqrs/blSqr.png"
};};};

function asqrsP760() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs760").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs760").src = "img/sqrs/blSqr.png"
};};};

function asqrsP761() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs761").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs761").src = "img/sqrs/blSqr.png"
};};};

function asqrsP762() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs762").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs762").src = "img/sqrs/blSqr.png"
};};};

function asqrsP763() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs763").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs763").src = "img/sqrs/blSqr.png"
};};};

function asqrsP764() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs764").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs764").src = "img/sqrs/blSqr.png"
};};};

function asqrsP765() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs765").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs765").src = "img/sqrs/blSqr.png"
};};};

function asqrsP766() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs766").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs766").src = "img/sqrs/blSqr.png"
};};};

function asqrsP767() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs767").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs767").src = "img/sqrs/blSqr.png"
};};};

function asqrsP768() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs768").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs768").src = "img/sqrs/blSqr.png"
};};};

function asqrsP769() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs769").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs769").src = "img/sqrs/blSqr.png"
};};};

function asqrsP770() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs770").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs770").src = "img/sqrs/blSqr.png"
};};};

function asqrsP771() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs771").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs771").src = "img/sqrs/blSqr.png"
};};};

function asqrsP772() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs772").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs772").src = "img/sqrs/blSqr.png"
};};};

function asqrsP773() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs773").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs773").src = "img/sqrs/blSqr.png"
};};};

function asqrsP774() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs774").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs774").src = "img/sqrs/blSqr.png"
};};};

function asqrsP775() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs775").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs775").src = "img/sqrs/blSqr.png"
};};};

function asqrsP776() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs776").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs776").src = "img/sqrs/blSqr.png"
};};};

function asqrsP777() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs777").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs777").src = "img/sqrs/blSqr.png"
};};};

function asqrsP778() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs778").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs778").src = "img/sqrs/blSqr.png"
};};};

function asqrsP779() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs779").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs779").src = "img/sqrs/blSqr.png"
};};};

function asqrsP780() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs780").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs780").src = "img/sqrs/blSqr.png"
};};};

function asqrsP781() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs781").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs781").src = "img/sqrs/blSqr.png"
};};};

function asqrsP782() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs782").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs782").src = "img/sqrs/blSqr.png"
};};};

function asqrsP783() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs783").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs783").src = "img/sqrs/blSqr.png"
};};};

function asqrsP784() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs784").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs784").src = "img/sqrs/blSqr.png"
};};};

function asqrsP785() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs785").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs785").src = "img/sqrs/blSqr.png"
};};};

function asqrsP786() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs786").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs786").src = "img/sqrs/blSqr.png"
};};};

function asqrsP787() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs787").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs787").src = "img/sqrs/blSqr.png"
};};};

function asqrsP788() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs788").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs788").src = "img/sqrs/blSqr.png"
};};};

function asqrsP789() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs789").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs789").src = "img/sqrs/blSqr.png"
};};};

function asqrsP790() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs790").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs790").src = "img/sqrs/blSqr.png"
};};};

function asqrsP791() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs791").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs791").src = "img/sqrs/blSqr.png"
};};};

function asqrsP792() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs792").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs792").src = "img/sqrs/blSqr.png"
};};};

function asqrsP793() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs793").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs793").src = "img/sqrs/blSqr.png"
};};};

function asqrsP794() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs794").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs794").src = "img/sqrs/blSqr.png"
};};};

function asqrsP795() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs795").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs795").src = "img/sqrs/blSqr.png"
};};};

function asqrsP796() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs796").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs796").src = "img/sqrs/blSqr.png"
};};};

function asqrsP797() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs797").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs797").src = "img/sqrs/blSqr.png"
};};};

function asqrsP798() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs798").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs798").src = "img/sqrs/blSqr.png"
};};};

function asqrsP799() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs799").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs799").src = "img/sqrs/blSqr.png"
};};};

function asqrsP800() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs800").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs800").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ801() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs801").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs801").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ802() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs802").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs802").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ803() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs803").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs803").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ804() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs804").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs804").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ805() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs805").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs805").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ806() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs806").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs806").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ807() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs807").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs807").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ808() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs808").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs808").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ809() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs809").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs809").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ810() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs810").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs810").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ811() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs811").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs811").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ812() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs812").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs812").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ813() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs813").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs813").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ814() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs814").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs814").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ815() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs815").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs815").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ816() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs816").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs816").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ817() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs817").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs817").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ818() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs818").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs818").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ819() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs819").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs819").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ820() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs820").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs820").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ821() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs821").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs821").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ822() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs822").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs822").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ823() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs823").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs823").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ824() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs824").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs824").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ825() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs825").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs825").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ826() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs826").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs826").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ827() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs827").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs827").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ828() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs828").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs828").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ829() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs829").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs829").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ830() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs830").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs830").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ831() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs831").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs831").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ832() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs832").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs832").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ833() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs833").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs833").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ834() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs834").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs834").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ835() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs835").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs835").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ836() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs836").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs836").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ837() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs837").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs837").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ838() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs838").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs838").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ839() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs839").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs839").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ840() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs840").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs840").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ841() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs841").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs841").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ842() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs842").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs842").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ843() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs843").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs843").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ844() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs844").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs844").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ845() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs845").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs845").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ846() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs846").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs846").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ847() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs847").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs847").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ848() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs848").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs848").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ849() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs849").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs849").src = "img/sqrs/blSqr.png"
};};};

function asqrsQ850() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs850").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs850").src = "img/sqrs/blSqr.png"
};};};

function asqrsR851() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs851").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs851").src = "img/sqrs/blSqr.png"
};};};

function asqrsR852() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs852").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs852").src = "img/sqrs/blSqr.png"
};};};

function asqrsR853() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs853").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs853").src = "img/sqrs/blSqr.png"
};};};

function asqrsR854() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs854").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs854").src = "img/sqrs/blSqr.png"
};};};

function asqrsR855() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs855").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs855").src = "img/sqrs/blSqr.png"
};};};

function asqrsR856() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs856").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs856").src = "img/sqrs/blSqr.png"
};};};

function asqrsR857() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs857").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs857").src = "img/sqrs/blSqr.png"
};};};

function asqrsR858() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs858").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs858").src = "img/sqrs/blSqr.png"
};};};

function asqrsR859() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs859").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs859").src = "img/sqrs/blSqr.png"
};};};

function asqrsR860() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs860").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs860").src = "img/sqrs/blSqr.png"
};};};

function asqrsR861() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs861").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs861").src = "img/sqrs/blSqr.png"
};};};

function asqrsR862() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs862").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs862").src = "img/sqrs/blSqr.png"
};};};

function asqrsR863() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs863").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs863").src = "img/sqrs/blSqr.png"
};};};

function asqrsR864() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs864").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs864").src = "img/sqrs/blSqr.png"
};};};

function asqrsR865() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs865").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs865").src = "img/sqrs/blSqr.png"
};};};

function asqrsR866() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs866").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs866").src = "img/sqrs/blSqr.png"
};};};

function asqrsR867() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs867").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs867").src = "img/sqrs/blSqr.png"
};};};

function asqrsR868() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs868").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs868").src = "img/sqrs/blSqr.png"
};};};

function asqrsR869() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs869").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs869").src = "img/sqrs/blSqr.png"
};};};

function asqrsR870() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs870").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs870").src = "img/sqrs/blSqr.png"
};};};

function asqrsR871() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs871").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs871").src = "img/sqrs/blSqr.png"
};};};

function asqrsR872() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs872").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs872").src = "img/sqrs/blSqr.png"
};};};

function asqrsR873() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs873").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs873").src = "img/sqrs/blSqr.png"
};};};

function asqrsR874() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs874").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs874").src = "img/sqrs/blSqr.png"
};};};

function asqrsR875() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs875").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs875").src = "img/sqrs/blSqr.png"
};};};

function asqrsR876() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs876").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs876").src = "img/sqrs/blSqr.png"
};};};

function asqrsR877() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs877").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs877").src = "img/sqrs/blSqr.png"
};};};

function asqrsR878() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs878").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs878").src = "img/sqrs/blSqr.png"
};};};

function asqrsR879() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs879").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs879").src = "img/sqrs/blSqr.png"
};};};

function asqrsR880() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs880").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs880").src = "img/sqrs/blSqr.png"
};};};

function asqrsR881() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs881").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs881").src = "img/sqrs/blSqr.png"
};};};

function asqrsR882() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs882").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs882").src = "img/sqrs/blSqr.png"
};};};

function asqrsR883() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs883").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs883").src = "img/sqrs/blSqr.png"
};};};

function asqrsR884() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs884").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs884").src = "img/sqrs/blSqr.png"
};};};

function asqrsR885() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs885").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs885").src = "img/sqrs/blSqr.png"
};};};

function asqrsR886() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs886").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs886").src = "img/sqrs/blSqr.png"
};};};

function asqrsR887() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs887").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs887").src = "img/sqrs/blSqr.png"
};};};

function asqrsR888() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs888").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs888").src = "img/sqrs/blSqr.png"
};};};

function asqrsR889() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs889").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs889").src = "img/sqrs/blSqr.png"
};};};

function asqrsR890() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs890").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs890").src = "img/sqrs/blSqr.png"
};};};

function asqrsR891() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs891").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs891").src = "img/sqrs/blSqr.png"
};};};

function asqrsR892() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs892").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs892").src = "img/sqrs/blSqr.png"
};};};

function asqrsR893() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs893").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs893").src = "img/sqrs/blSqr.png"
};};};

function asqrsR894() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs894").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs894").src = "img/sqrs/blSqr.png"
};};};

function asqrsR895() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs895").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs895").src = "img/sqrs/blSqr.png"
};};};

function asqrsR896() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs896").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs896").src = "img/sqrs/blSqr.png"
};};};

function asqrsR897() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs897").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs897").src = "img/sqrs/blSqr.png"
};};};

function asqrsR898() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs898").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs898").src = "img/sqrs/blSqr.png"
};};};

function asqrsR899() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs899").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs899").src = "img/sqrs/blSqr.png"
};};};

function asqrsR900() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs900").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs900").src = "img/sqrs/blSqr.png"
};};};

function asqrsS901() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs901").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs901").src = "img/sqrs/blSqr.png"
};};};

function asqrsS902() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs902").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs902").src = "img/sqrs/blSqr.png"
};};};

function asqrsS903() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs903").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs903").src = "img/sqrs/blSqr.png"
};};};

function asqrsS904() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs904").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs904").src = "img/sqrs/blSqr.png"
};};};

function asqrsS905() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs905").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs905").src = "img/sqrs/blSqr.png"
};};};

function asqrsS906() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs906").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs906").src = "img/sqrs/blSqr.png"
};};};

function asqrsS907() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs907").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs907").src = "img/sqrs/blSqr.png"
};};};

function asqrsS908() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs908").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs908").src = "img/sqrs/blSqr.png"
};};};

function asqrsS909() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs909").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs909").src = "img/sqrs/blSqr.png"
};};};

function asqrsS910() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs910").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs910").src = "img/sqrs/blSqr.png"
};};};

function asqrsS911() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs911").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs911").src = "img/sqrs/blSqr.png"
};};};

function asqrsS912() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs912").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs912").src = "img/sqrs/blSqr.png"
};};};

function asqrsS913() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs913").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs913").src = "img/sqrs/blSqr.png"
};};};

function asqrsS914() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs914").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs914").src = "img/sqrs/blSqr.png"
};};};

function asqrsS915() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs915").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs915").src = "img/sqrs/blSqr.png"
};};};

function asqrsS916() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs916").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs916").src = "img/sqrs/blSqr.png"
};};};

function asqrsS917() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs917").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs917").src = "img/sqrs/blSqr.png"
};};};

function asqrsS918() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs918").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs918").src = "img/sqrs/blSqr.png"
};};};

function asqrsS919() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs919").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs919").src = "img/sqrs/blSqr.png"
};};};

function asqrsS920() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs920").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs920").src = "img/sqrs/blSqr.png"
};};};

function asqrsS921() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs921").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs921").src = "img/sqrs/blSqr.png"
};};};

function asqrsS922() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs922").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs922").src = "img/sqrs/blSqr.png"
};};};

function asqrsS923() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs923").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs923").src = "img/sqrs/blSqr.png"
};};};

function asqrsS924() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs924").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs924").src = "img/sqrs/blSqr.png"
};};};

function asqrsS925() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs925").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs925").src = "img/sqrs/blSqr.png"
};};};

function asqrsS926() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs926").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs926").src = "img/sqrs/blSqr.png"
};};};

function asqrsS927() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs927").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs927").src = "img/sqrs/blSqr.png"
};};};

function asqrsS928() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs928").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs928").src = "img/sqrs/blSqr.png"
};};};

function asqrsS929() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs929").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs929").src = "img/sqrs/blSqr.png"
};};};

function asqrsS930() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs930").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs930").src = "img/sqrs/blSqr.png"
};};};

function asqrsS931() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs931").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs931").src = "img/sqrs/blSqr.png"
};};};

function asqrsS932() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs932").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs932").src = "img/sqrs/blSqr.png"
};};};

function asqrsS933() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs933").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs933").src = "img/sqrs/blSqr.png"
};};};

function asqrsS934() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs934").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs934").src = "img/sqrs/blSqr.png"
};};};

function asqrsS935() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs935").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs935").src = "img/sqrs/blSqr.png"
};};};

function asqrsS936() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs936").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs936").src = "img/sqrs/blSqr.png"
};};};

function asqrsS937() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs937").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs937").src = "img/sqrs/blSqr.png"
};};};

function asqrsS938() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs938").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs938").src = "img/sqrs/blSqr.png"
};};};

function asqrsS939() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs939").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs939").src = "img/sqrs/blSqr.png"
};};};

function asqrsS940() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs940").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs940").src = "img/sqrs/blSqr.png"
};};};

function asqrsS941() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs941").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs941").src = "img/sqrs/blSqr.png"
};};};

function asqrsS942() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs942").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs942").src = "img/sqrs/blSqr.png"
};};};

function asqrsS943() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs943").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs943").src = "img/sqrs/blSqr.png"
};};};

function asqrsS944() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs944").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs944").src = "img/sqrs/blSqr.png"
};};};

function asqrsS945() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs945").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs945").src = "img/sqrs/blSqr.png"
};};};

function asqrsS946() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs946").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs946").src = "img/sqrs/blSqr.png"
};};};

function asqrsS947() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs947").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs947").src = "img/sqrs/blSqr.png"
};};};

function asqrsS948() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs948").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs948").src = "img/sqrs/blSqr.png"
};};};

function asqrsS949() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs949").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs949").src = "img/sqrs/blSqr.png"
};};};

function asqrsS950() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs950").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs950").src = "img/sqrs/blSqr.png"
};};};

function asqrsT951() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs951").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs951").src = "img/sqrs/blSqr.png"
};};};

function asqrsT952() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs952").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs952").src = "img/sqrs/blSqr.png"
};};};

function asqrsT953() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs953").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs953").src = "img/sqrs/blSqr.png"
};};};

function asqrsT954() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs954").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs954").src = "img/sqrs/blSqr.png"
};};};

function asqrsT955() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs955").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs955").src = "img/sqrs/blSqr.png"
};};};

function asqrsT956() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs956").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs956").src = "img/sqrs/blSqr.png"
};};};

function asqrsT957() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs957").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs957").src = "img/sqrs/blSqr.png"
};};};

function asqrsT958() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs958").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs958").src = "img/sqrs/blSqr.png"
};};};

function asqrsT959() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs959").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs959").src = "img/sqrs/blSqr.png"
};};};

function asqrsT960() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs960").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs960").src = "img/sqrs/blSqr.png"
};};};

function asqrsT961() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs961").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs961").src = "img/sqrs/blSqr.png"
};};};

function asqrsT962() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs962").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs962").src = "img/sqrs/blSqr.png"
};};};

function asqrsT963() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs963").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs963").src = "img/sqrs/blSqr.png"
};};};

function asqrsT964() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs964").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs964").src = "img/sqrs/blSqr.png"
};};};

function asqrsT965() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs965").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs965").src = "img/sqrs/blSqr.png"
};};};

function asqrsT966() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs966").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs966").src = "img/sqrs/blSqr.png"
};};};

function asqrsT967() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs967").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs967").src = "img/sqrs/blSqr.png"
};};};

function asqrsT968() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs968").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs968").src = "img/sqrs/blSqr.png"
};};};

function asqrsT969() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs969").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs969").src = "img/sqrs/blSqr.png"
};};};

function asqrsT970() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs970").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs970").src = "img/sqrs/blSqr.png"
};};};

function asqrsT971() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs971").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs971").src = "img/sqrs/blSqr.png"
};};};

function asqrsT972() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs972").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs972").src = "img/sqrs/blSqr.png"
};};};

function asqrsT973() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs973").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs973").src = "img/sqrs/blSqr.png"
};};};

function asqrsT974() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs974").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs974").src = "img/sqrs/blSqr.png"
};};};

function asqrsT975() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs975").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs975").src = "img/sqrs/blSqr.png"
};};};

function asqrsT976() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs976").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs976").src = "img/sqrs/blSqr.png"
};};};

function asqrsT977() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs977").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs977").src = "img/sqrs/blSqr.png"
};};};

function asqrsT978() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs978").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs978").src = "img/sqrs/blSqr.png"
};};};

function asqrsT979() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs979").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs979").src = "img/sqrs/blSqr.png"
};};};

function asqrsT980() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs980").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs980").src = "img/sqrs/blSqr.png"
};};};

function asqrsT981() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs981").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs981").src = "img/sqrs/blSqr.png"
};};};

function asqrsT982() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs982").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs982").src = "img/sqrs/blSqr.png"
};};};

function asqrsT983() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs983").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs983").src = "img/sqrs/blSqr.png"
};};};

function asqrsT984() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs984").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs984").src = "img/sqrs/blSqr.png"
};};};

function asqrsT985() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs985").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs985").src = "img/sqrs/blSqr.png"
};};};

function asqrsT986() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs986").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs986").src = "img/sqrs/blSqr.png"
};};};

function asqrsT987() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs987").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs987").src = "img/sqrs/blSqr.png"
};};};

function asqrsT988() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs988").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs988").src = "img/sqrs/blSqr.png"
};};};

function asqrsT989() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs989").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs989").src = "img/sqrs/blSqr.png"
};};};

function asqrsT990() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs990").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs990").src = "img/sqrs/blSqr.png"
};};};

function asqrsT991() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs991").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs991").src = "img/sqrs/blSqr.png"
};};};

function asqrsT992() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs992").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs992").src = "img/sqrs/blSqr.png"
};};};

function asqrsT993() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs993").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs993").src = "img/sqrs/blSqr.png"
};};};

function asqrsT994() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs994").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs994").src = "img/sqrs/blSqr.png"
};};};

function asqrsT995() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs995").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs995").src = "img/sqrs/blSqr.png"
};};};

function asqrsT996() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs996").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs996").src = "img/sqrs/blSqr.png"
};};};

function asqrsT997() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs997").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs997").src = "img/sqrs/blSqr.png"
};};};

function asqrsT998() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs998").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs998").src = "img/sqrs/blSqr.png"
};};};

function asqrsT999() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs999").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs999").src = "img/sqrs/blSqr.png"
};};};

function asqrsT1000() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1000").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1000").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1001() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1001").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1001").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1002() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1002").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1002").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1003() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1003").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1003").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1004() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1004").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1004").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1005() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1005").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1005").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1006() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1006").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1006").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1007() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1007").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1007").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1008() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1008").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1008").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1009() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1009").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1009").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1010() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1010").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1010").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1011() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1011").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1011").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1012() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1012").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1012").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1013() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1013").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1013").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1014() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1014").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1014").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1015() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1015").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1015").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1016() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1016").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1016").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1017() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1017").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1017").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1018() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1018").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1018").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1019() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1019").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1019").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1020() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1020").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1020").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1021() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1021").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1021").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1022() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1022").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1022").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1023() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1023").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1023").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1024() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1024").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1024").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1025() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1025").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1025").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1026() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1026").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1026").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1027() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1027").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1027").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1028() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1028").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1028").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1029() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1029").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1029").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1030() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1030").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1030").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1031() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1031").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1031").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1032() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1032").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1032").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1033() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1033").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1033").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1034() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1034").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1034").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1035() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1035").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1035").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1036() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1036").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1036").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1037() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1037").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1037").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1038() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1038").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1038").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1039() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1039").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1039").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1040() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1040").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1040").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1041() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1041").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1041").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1042() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1042").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1042").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1043() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1043").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1043").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1044() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1044").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1044").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1045() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1045").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1045").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1046() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1046").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1046").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1047() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1047").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1047").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1048() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1048").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1048").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1049() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1049").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1049").src = "img/sqrs/blSqr.png"
};};};

function asqrsU1050() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1050").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1050").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1051() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1051").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1051").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1052() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1052").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1052").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1053() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1053").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1053").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1054() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1054").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1054").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1055() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1055").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1055").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1056() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1056").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1056").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1057() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1057").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1057").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1058() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1058").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1058").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1059() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1059").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1059").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1060() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1060").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1060").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1061() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1061").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1061").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1062() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1062").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1062").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1063() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1063").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1063").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1064() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1064").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1064").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1065() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1065").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1065").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1066() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1066").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1066").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1067() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1067").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1067").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1068() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1068").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1068").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1069() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1069").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1069").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1070() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1070").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1070").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1071() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1071").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1071").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1072() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1072").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1072").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1073() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1073").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1073").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1074() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1074").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1074").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1075() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1075").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1075").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1076() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1076").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1076").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1077() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1077").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1077").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1078() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1078").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1078").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1079() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1079").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1079").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1080() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1080").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1080").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1081() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1081").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1081").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1082() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1082").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1082").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1083() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1083").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1083").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1084() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1084").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1084").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1085() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1085").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1085").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1086() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1086").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1086").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1087() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1087").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1087").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1088() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1088").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1088").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1089() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1089").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1089").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1090() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1090").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1090").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1091() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1091").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1091").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1092() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1092").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1092").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1093() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1093").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1093").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1094() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1094").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1094").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1095() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1095").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1095").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1096() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1096").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1096").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1097() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1097").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1097").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1098() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1098").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1098").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1099() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1099").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1099").src = "img/sqrs/blSqr.png"
};};};

function asqrsV1100() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1100").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1100").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1101() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1101").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1101").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1102() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1102").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1102").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1103() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1103").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1103").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1104() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1104").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1104").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1105() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1105").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1105").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1106() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1106").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1106").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1107() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1107").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1107").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1108() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1108").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1108").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1109() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1109").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1109").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1110() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1110").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1110").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1111() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1111").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1111").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1112() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1112").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1112").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1113() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1113").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1113").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1114() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1114").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1114").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1115() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1115").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1115").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1116() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1116").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1116").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1117() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1117").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1117").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1118() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1118").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1118").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1119() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1119").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1119").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1120() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1120").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1120").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1121() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1121").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1121").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1122() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1122").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1122").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1123() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1123").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1123").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1124() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1124").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1124").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1125() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1125").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1125").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1126() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1126").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1126").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1127() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1127").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1127").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1128() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1128").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1128").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1129() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1129").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1129").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1130() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1130").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1130").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1131() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1131").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1131").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1132() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1132").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1132").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1133() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1133").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1133").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1134() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1134").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1134").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1135() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1135").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1135").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1136() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1136").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1136").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1137() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1137").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1137").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1138() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1138").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1138").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1139() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1139").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1139").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1140() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1140").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1140").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1141() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1141").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1141").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1142() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1142").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1142").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1143() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1143").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1143").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1144() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1144").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1144").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1145() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1145").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1145").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1146() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1146").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1146").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1147() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1147").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1147").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1148() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1148").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1148").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1149() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1149").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1149").src = "img/sqrs/blSqr.png"
};};};

function asqrsW1150() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1150").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1150").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1151() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1151").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1151").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1152() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1152").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1152").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1153() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1153").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1153").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1154() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1154").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1154").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1155() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1155").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1155").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1156() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1156").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1156").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1157() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1157").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1157").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1158() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1158").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1158").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1159() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1159").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1159").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1160() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1160").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1160").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1161() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1161").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1161").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1162() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1162").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1162").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1163() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1163").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1163").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1164() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1164").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1164").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1165() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1165").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1165").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1166() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1166").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1166").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1167() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1167").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1167").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1168() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1168").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1168").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1169() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1169").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1169").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1170() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1170").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1170").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1171() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1171").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1171").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1172() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1172").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1172").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1173() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1173").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1173").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1174() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1174").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1174").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1175() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1175").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1175").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1176() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1176").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1176").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1177() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1177").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1177").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1178() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1178").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1178").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1179() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1179").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1179").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1180() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1180").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1180").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1181() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1181").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1181").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1182() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1182").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1182").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1183() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1183").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1183").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1184() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1184").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1184").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1185() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1185").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1185").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1186() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1186").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1186").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1187() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1187").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1187").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1188() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1188").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1188").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1189() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1189").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1189").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1190() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1190").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1190").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1191() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1191").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1191").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1192() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1192").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1192").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1193() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1193").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1193").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1194() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1194").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1194").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1195() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1195").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1195").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1196() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1196").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1196").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1197() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1197").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1197").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1198() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1198").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1198").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1199() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1199").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1199").src = "img/sqrs/blSqr.png"
};};};

function asqrsX1200() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1200").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1200").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1201() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1201").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1201").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1202() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1202").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1202").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1203() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1203").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1203").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1204() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1204").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1204").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1205() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1205").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1205").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1206() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1206").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1206").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1207() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1207").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1207").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1208() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1208").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1208").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1209() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1209").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1209").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1210() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1210").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1210").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1211() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1211").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1211").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1212() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1212").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1212").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1213() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1213").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1213").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1214() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1214").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1214").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1215() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1215").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1215").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1216() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1216").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1216").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1217() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1217").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1217").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1218() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1218").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1218").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1219() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1219").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1219").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1220() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1220").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1220").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1221() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1221").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1221").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1222() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1222").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1222").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1223() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1223").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1223").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1224() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1224").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1224").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1225() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1225").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1225").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1226() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1226").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1226").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1227() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1227").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1227").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1228() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1228").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1228").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1229() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1229").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1229").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1230() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1230").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1230").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1231() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1231").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1231").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1232() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1232").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1232").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1233() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1233").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1233").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1234() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1234").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1234").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1235() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1235").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1235").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1236() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1236").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1236").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1237() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1237").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1237").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1238() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1238").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1238").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1239() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1239").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1239").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1240() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1240").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1240").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1241() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1241").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1241").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1242() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1242").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1242").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1243() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1243").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1243").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1244() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1244").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1244").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1245() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1245").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1245").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1246() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1246").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1246").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1247() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1247").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1247").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1248() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1248").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1248").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1249() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1249").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1249").src = "img/sqrs/blSqr.png"
};};};

function asqrsY1250() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1250").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1250").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1251() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1251").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1251").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1252() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1252").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1252").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1253() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1253").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1253").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1254() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1254").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1254").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1255() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1255").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1255").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1256() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1256").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1256").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1257() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1257").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1257").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1258() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1258").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1258").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1259() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1259").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1259").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1260() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1260").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1260").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1261() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1261").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1261").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1262() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1262").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1262").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1263() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1263").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1263").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1264() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1264").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1264").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1265() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1265").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1265").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1266() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1266").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1266").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1267() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1267").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1267").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1268() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1268").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1268").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1269() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1269").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1269").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1270() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1270").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1270").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1271() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1271").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1271").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1272() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1272").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1272").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1273() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1273").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1273").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1274() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1274").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1274").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1275() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1275").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1275").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1276() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1276").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1276").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1277() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1277").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1277").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1278() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1278").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1278").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1279() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1279").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1279").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1280() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1280").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1280").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1281() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1281").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1281").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1282() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1282").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1282").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1283() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1283").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1283").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1284() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1284").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1284").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1285() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1285").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1285").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1286() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1286").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1286").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1287() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1287").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1287").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1288() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1288").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1288").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1289() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1289").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1289").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1290() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1290").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1290").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1291() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1291").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1291").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1292() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1292").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1292").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1293() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1293").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1293").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1294() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1294").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1294").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1295() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1295").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1295").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1296() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1296").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1296").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1297() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1297").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1297").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1298() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1298").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1298").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1299() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1299").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1299").src = "img/sqrs/blSqr.png"
};};};

function asqrsAA1300() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1300").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1300").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1301() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1301").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1301").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1302() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1302").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1302").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1303() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1303").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1303").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1304() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1304").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1304").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1305() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1305").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1305").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1306() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1306").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1306").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1307() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1307").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1307").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1308() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1308").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1308").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1309() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1309").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1309").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1310() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1310").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1310").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1311() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1311").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1311").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1312() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1312").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1312").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1313() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1313").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1313").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1314() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1314").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1314").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1315() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1315").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1315").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1316() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1316").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1316").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1317() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1317").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1317").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1318() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1318").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1318").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1319() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1319").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1319").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1320() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1320").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1320").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1321() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1321").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1321").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1322() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1322").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1322").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1323() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1323").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1323").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1324() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1324").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1324").src = "img/sqrs/blSqr.png"
};};};

function asqrsB1325() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1325").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1325").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1326() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1326").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1326").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1327() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1327").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1327").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1328() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1328").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1328").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1329() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1329").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1329").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1330() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1330").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1330").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1331() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1331").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1331").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1332() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1332").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1332").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1333() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1333").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1333").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1334() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1334").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1334").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1335() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1335").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1335").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1336() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1336").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1336").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1337() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1337").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1337").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1338() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1338").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1338").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1339() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1339").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1339").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1340() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1340").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1340").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1341() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1341").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1341").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1342() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1342").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1342").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1343() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1343").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1343").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1344() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1344").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1344").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1345() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1345").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1345").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1346() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1346").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1346").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1347() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1347").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1347").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1348() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1348").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1348").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1349() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1349").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1349").src = "img/sqrs/blSqr.png"
};};};

function asqrsBA1350() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1350").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1350").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1351() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1351").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1351").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1352() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1352").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1352").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1353() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1353").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1353").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1354() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1354").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1354").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1355() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1355").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1355").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1356() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1356").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1356").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1357() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1357").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1357").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1358() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1358").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1358").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1359() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1359").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1359").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1360() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1360").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1360").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1361() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1361").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1361").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1362() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1362").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1362").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1363() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1363").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1363").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1364() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1364").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1364").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1365() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1365").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1365").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1366() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1366").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1366").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1367() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1367").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1367").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1368() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1368").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1368").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1369() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1369").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1369").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1370() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1370").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1370").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1371() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1371").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1371").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1372() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1372").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1372").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1373() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1373").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1373").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1374() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1374").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1374").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1375() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1375").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1375").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1376() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1376").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1376").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1377() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1377").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1377").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1378() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1378").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1378").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1379() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1379").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1379").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1380() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1380").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1380").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1381() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1381").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1381").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1382() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1382").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1382").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1383() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1383").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1383").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1384() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1384").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1384").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1385() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1385").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1385").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1386() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1386").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1386").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1387() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1387").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1387").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1388() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1388").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1388").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1389() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1389").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1389").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1390() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1390").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1390").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1391() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1391").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1391").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1392() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1392").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1392").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1393() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1393").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1393").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1394() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1394").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1394").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1395() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1395").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1395").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1396() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1396").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1396").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1397() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1397").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1397").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1398() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1398").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1398").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1399() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1399").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1399").src = "img/sqrs/blSqr.png"
};};};

function asqrsCA1400() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1400").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1400").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1401() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1401").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1401").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1402() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1402").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1402").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1403() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1403").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1403").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1404() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1404").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1404").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1405() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1405").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1405").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1406() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1406").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1406").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1407() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1407").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1407").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1408() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1408").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1408").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1409() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1409").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1409").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1410() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1410").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1410").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1411() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1411").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1411").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1412() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1412").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1412").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1413() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1413").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1413").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1414() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1414").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1414").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1415() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1415").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1415").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1416() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1416").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1416").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1417() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1417").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1417").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1418() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1418").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1418").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1419() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1419").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1419").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1420() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1420").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1420").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1421() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1421").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1421").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1422() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1422").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1422").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1423() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1423").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1423").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1424() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1424").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1424").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1425() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1425").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1425").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1426() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1426").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1426").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1427() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1427").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1427").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1428() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1428").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1428").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1429() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1429").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1429").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1430() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1430").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1430").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1431() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1431").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1431").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1432() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1432").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1432").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1433() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1433").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1433").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1434() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1434").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1434").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1435() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1435").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1435").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1436() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1436").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1436").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1437() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1437").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1437").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1438() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1438").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1438").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1439() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1439").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1439").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1440() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1440").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1440").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1441() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1441").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1441").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1442() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1442").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1442").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1443() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1443").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1443").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1444() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1444").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1444").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1445() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1445").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1445").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1446() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1446").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1446").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1447() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1447").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1447").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1448() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1448").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1448").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1449() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1449").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1449").src = "img/sqrs/blSqr.png"
};};};

function asqrsDA1450() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1450").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1450").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1451() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1451").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1451").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1452() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1452").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1452").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1453() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1453").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1453").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1454() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1454").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1454").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1455() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1455").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1455").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1456() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1456").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1456").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1457() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1457").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1457").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1458() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1458").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1458").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1459() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1459").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1459").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1460() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1460").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1460").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1461() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1461").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1461").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1462() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1462").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1462").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1463() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1463").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1463").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1464() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1464").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1464").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1465() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1465").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1465").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1466() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1466").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1466").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1467() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1467").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1467").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1468() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1468").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1468").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1469() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1469").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1469").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1470() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1470").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1470").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1471() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1471").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1471").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1472() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1472").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1472").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1473() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1473").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1473").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1474() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1474").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1474").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1475() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1475").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1475").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1476() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1476").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1476").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1477() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1477").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1477").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1478() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1478").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1478").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1479() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1479").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1479").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1480() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1480").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1480").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1481() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1481").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1481").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1482() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1482").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1482").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1483() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1483").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1483").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1484() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1484").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1484").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1485() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1485").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1485").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1486() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1486").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1486").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1487() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1487").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1487").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1488() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1488").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1488").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1489() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1489").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1489").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1490() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1490").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1490").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1491() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1491").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1491").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1492() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1492").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1492").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1493() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1493").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1493").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1494() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1494").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1494").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1495() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1495").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1495").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1496() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1496").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1496").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1497() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1497").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1497").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1498() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1498").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1498").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1499() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1499").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1499").src = "img/sqrs/blSqr.png"
};};};

function asqrsEA1500() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1500").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1500").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1501() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1501").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1501").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1502() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1502").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1502").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1503() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1503").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1503").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1504() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1504").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1504").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1505() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1505").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1505").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1506() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1506").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1506").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1507() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1507").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1507").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1508() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1508").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1508").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1509() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1509").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1509").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1510() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1510").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1510").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1511() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1511").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1511").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1512() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1512").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1512").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1513() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1513").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1513").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1514() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1514").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1514").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1515() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1515").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1515").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1516() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1516").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1516").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1517() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1517").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1517").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1518() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1518").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1518").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1519() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1519").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1519").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1520() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1520").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1520").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1521() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1521").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1521").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1522() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1522").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1522").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1523() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1523").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1523").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1524() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1524").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1524").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1525() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1525").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1525").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1526() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1526").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1526").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1527() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1527").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1527").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1528() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1528").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1528").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1529() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1529").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1529").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1530() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1530").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1530").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1531() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1531").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1531").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1532() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1532").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1532").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1533() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1533").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1533").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1534() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1534").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1534").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1535() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1535").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1535").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1536() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1536").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1536").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1537() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1537").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1537").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1538() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1538").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1538").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1539() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1539").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1539").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1540() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1540").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1540").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1541() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1541").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1541").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1542() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1542").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1542").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1543() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1543").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1543").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1544() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1544").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1544").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1545() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1545").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1545").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1546() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1546").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1546").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1547() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1547").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1547").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1548() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1548").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1548").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1549() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1549").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1549").src = "img/sqrs/blSqr.png"
};};};

function asqrsFA1550() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1550").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1550").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1551() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1551").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1551").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1552() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1552").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1552").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1553() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1553").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1553").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1554() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1554").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1554").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1555() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1555").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1555").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1556() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1556").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1556").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1557() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1557").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1557").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1558() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1558").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1558").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1559() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1559").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1559").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1560() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1560").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1560").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1561() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1561").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1561").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1562() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1562").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1562").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1563() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1563").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1563").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1564() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1564").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1564").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1565() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1565").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1565").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1566() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1566").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1566").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1567() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1567").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1567").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1568() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1568").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1568").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1569() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1569").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1569").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1570() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1570").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1570").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1571() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1571").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1571").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1572() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1572").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1572").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1573() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1573").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1573").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1574() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1574").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1574").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1575() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1575").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1575").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1576() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1576").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1576").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1577() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1577").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1577").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1578() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1578").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1578").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1579() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1579").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1579").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1580() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1580").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1580").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1581() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1581").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1581").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1582() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1582").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1582").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1583() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1583").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1583").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1584() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1584").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1584").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1585() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1585").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1585").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1586() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1586").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1586").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1587() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1587").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1587").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1588() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1588").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1588").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1589() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1589").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1589").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1590() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1590").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1590").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1591() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1591").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1591").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1592() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1592").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1592").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1593() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1593").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1593").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1594() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1594").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1594").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1595() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1595").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1595").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1596() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1596").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1596").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1597() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1597").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1597").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1598() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1598").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1598").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1599() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1599").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1599").src = "img/sqrs/blSqr.png"
};};};

function asqrsGA1600() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1600").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1600").src = "img/sqrs/blSqr.png"
};};};
