function square1(){

    var sQz1 = document.getElementById("imgSqrs1").src;

    value30Save1 = "zSqrArtSpecz1";

    localStorage.setItem(value30Save1, sQz1);
};

function square2(){

    var sQz2 = document.getElementById("imgSqrs2").src;

    value30Save2 = "zSqrArtSpecz2";

    localStorage.setItem(value30Save2, sQz2);
};

function square3(){

    var sQz3 = document.getElementById("imgSqrs3").src;

    value30Save3 = "zSqrArtSpecz3";

    localStorage.setItem(value30Save3, sQz3);
};

function square4(){

    var sQz4 = document.getElementById("imgSqrs4").src;

    value30Save4 = "zSqrArtSpecz4";

    localStorage.setItem(value30Save4, sQz4);
};

function square5(){

    var sQz5 = document.getElementById("imgSqrs5").src;

    value30Save5 = "zSqrArtSpecz5";

    localStorage.setItem(value30Save5, sQz5);
};

function square6(){

    var sQz6 = document.getElementById("imgSqrs6").src;

    value30Save6 = "zSqrArtSpecz6";

    localStorage.setItem(value30Save6, sQz6);
};

function square7(){

    var sQz7 = document.getElementById("imgSqrs7").src;

    value30Save7 = "zSqrArtSpecz7";

    localStorage.setItem(value30Save7, sQz7);
};

function square8(){

    var sQz8 = document.getElementById("imgSqrs8").src;

    value30Save8 = "zSqrArtSpecz8";

    localStorage.setItem(value30Save8, sQz8);
};

function square9(){

    var sQz9 = document.getElementById("imgSqrs9").src;

    value30Save9 = "zSqrArtSpecz9";

    localStorage.setItem(value30Save9, sQz9);
};

function square10(){

    var sQz10 = document.getElementById("imgSqrs10").src;

    value30Save10 = "zSqrArtSpecz10";

    localStorage.setItem(value30Save10, sQz10);
};

function square11(){

    var sQz11 = document.getElementById("imgSqrs11").src;

    value30Save11 = "zSqrArtSpecz11";

    localStorage.setItem(value30Save11, sQz11);
};

function square12(){

    var sQz12 = document.getElementById("imgSqrs12").src;

    value30Save12 = "zSqrArtSpecz12";

    localStorage.setItem(value30Save12, sQz12);
};

function square13(){

    var sQz13 = document.getElementById("imgSqrs13").src;

    value30Save13 = "zSqrArtSpecz13";

    localStorage.setItem(value30Save13, sQz13);
};

function square14(){

    var sQz14 = document.getElementById("imgSqrs14").src;

    value30Save14 = "zSqrArtSpecz14";

    localStorage.setItem(value30Save14, sQz14);
};

function square15(){

    var sQz15 = document.getElementById("imgSqrs15").src;

    value30Save15 = "zSqrArtSpecz15";

    localStorage.setItem(value30Save15, sQz15);
};

function square16(){

    var sQz16 = document.getElementById("imgSqrs16").src;

    value30Save16 = "zSqrArtSpecz16";

    localStorage.setItem(value30Save16, sQz16);
};

function square17(){

    var sQz17 = document.getElementById("imgSqrs17").src;

    value30Save17 = "zSqrArtSpecz17";

    localStorage.setItem(value30Save17, sQz17);
};

function square18(){

    var sQz18 = document.getElementById("imgSqrs18").src;

    value30Save18 = "zSqrArtSpecz18";

    localStorage.setItem(value30Save18, sQz18);
};

function square19(){

    var sQz19 = document.getElementById("imgSqrs19").src;

    value30Save19 = "zSqrArtSpecz19";

    localStorage.setItem(value30Save19, sQz19);
};

function square20(){

    var sQz20 = document.getElementById("imgSqrs20").src;

    value30Save20 = "zSqrArtSpecz20";

    localStorage.setItem(value30Save20, sQz20);
};

function square21(){

    var sQz21 = document.getElementById("imgSqrs21").src;

    value30Save21 = "zSqrArtSpecz21";

    localStorage.setItem(value30Save21, sQz21);
};

function square22(){

    var sQz22 = document.getElementById("imgSqrs22").src;

    value30Save22 = "zSqrArtSpecz22";

    localStorage.setItem(value30Save22, sQz22);
};

function square23(){

    var sQz23 = document.getElementById("imgSqrs23").src;

    value30Save23 = "zSqrArtSpecz23";

    localStorage.setItem(value30Save23, sQz23);
};

function square24(){

    var sQz24 = document.getElementById("imgSqrs24").src;

    value30Save24 = "zSqrArtSpecz24";

    localStorage.setItem(value30Save24, sQz24);
};

function square25(){

    var sQz25 = document.getElementById("imgSqrs25").src;

    value30Save25 = "zSqrArtSpecz25";

    localStorage.setItem(value30Save25, sQz25);
};

function square26(){

    var sQz26 = document.getElementById("imgSqrs26").src;

    value30Save26 = "zSqrArtSpecz26";

    localStorage.setItem(value30Save26, sQz26);
};

function square27(){

    var sQz27 = document.getElementById("imgSqrs27").src;

    value30Save27 = "zSqrArtSpecz27";

    localStorage.setItem(value30Save27, sQz27);
};

function square28(){

    var sQz28 = document.getElementById("imgSqrs28").src;

    value30Save28 = "zSqrArtSpecz28";

    localStorage.setItem(value30Save28, sQz28);
};

function square29(){

    var sQz29 = document.getElementById("imgSqrs29").src;

    value30Save29 = "zSqrArtSpecz29";

    localStorage.setItem(value30Save29, sQz29);
};

function square30(){

    var sQz30 = document.getElementById("imgSqrs30").src;

    value30Save30 = "zSqrArtSpecz30";

    localStorage.setItem(value30Save30, sQz30);
};

function square31(){

    var sQz31 = document.getElementById("imgSqrs31").src;

    value30Save31 = "zSqrArtSpecz31";

    localStorage.setItem(value30Save31, sQz31);
};

function square32(){

    var sQz32 = document.getElementById("imgSqrs32").src;

    value30Save32 = "zSqrArtSpecz32";

    localStorage.setItem(value30Save32, sQz32);
};

function square33(){

    var sQz33 = document.getElementById("imgSqrs33").src;

    value30Save33 = "zSqrArtSpecz33";

    localStorage.setItem(value30Save33, sQz33);
};

function square34(){

    var sQz34 = document.getElementById("imgSqrs34").src;

    value30Save34 = "zSqrArtSpecz34";

    localStorage.setItem(value30Save34, sQz34);
};

function square35(){

    var sQz35 = document.getElementById("imgSqrs35").src;

    value30Save35 = "zSqrArtSpecz35";

    localStorage.setItem(value30Save35, sQz35);
};

function square36(){

    var sQz36 = document.getElementById("imgSqrs36").src;

    value30Save36 = "zSqrArtSpecz36";

    localStorage.setItem(value30Save36, sQz36);
};

function square37(){

    var sQz37 = document.getElementById("imgSqrs37").src;

    value30Save37 = "zSqrArtSpecz37";

    localStorage.setItem(value30Save37, sQz37);
};

function square38(){

    var sQz38 = document.getElementById("imgSqrs38").src;

    value30Save38 = "zSqrArtSpecz38";

    localStorage.setItem(value30Save38, sQz38);
};

function square39(){

    var sQz39 = document.getElementById("imgSqrs39").src;

    value30Save39 = "zSqrArtSpecz39";

    localStorage.setItem(value30Save39, sQz39);
};

function square40(){

    var sQz40 = document.getElementById("imgSqrs40").src;

    value30Save40 = "zSqrArtSpecz40";

    localStorage.setItem(value30Save40, sQz40);
};

function square41(){

    var sQz41 = document.getElementById("imgSqrs41").src;

    value30Save41 = "zSqrArtSpecz41";

    localStorage.setItem(value30Save41, sQz41);
};

function square42(){

    var sQz42 = document.getElementById("imgSqrs42").src;

    value30Save42 = "zSqrArtSpecz42";

    localStorage.setItem(value30Save42, sQz42);
};

function square43(){

    var sQz43 = document.getElementById("imgSqrs43").src;

    value30Save43 = "zSqrArtSpecz43";

    localStorage.setItem(value30Save43, sQz43);
};

function square44(){

    var sQz44 = document.getElementById("imgSqrs44").src;

    value30Save44 = "zSqrArtSpecz44";

    localStorage.setItem(value30Save44, sQz44);
};

function square45(){

    var sQz45 = document.getElementById("imgSqrs45").src;

    value30Save45 = "zSqrArtSpecz45";

    localStorage.setItem(value30Save45, sQz45);
};

function square46(){

    var sQz46 = document.getElementById("imgSqrs46").src;

    value30Save46 = "zSqrArtSpecz46";

    localStorage.setItem(value30Save46, sQz46);
};

function square47(){

    var sQz47 = document.getElementById("imgSqrs47").src;

    value30Save47 = "zSqrArtSpecz47";

    localStorage.setItem(value30Save47, sQz47);
};

function square48(){

    var sQz48 = document.getElementById("imgSqrs48").src;

    value30Save48 = "zSqrArtSpecz48";

    localStorage.setItem(value30Save48, sQz48);
};

function square49(){

    var sQz49 = document.getElementById("imgSqrs49").src;

    value30Save49 = "zSqrArtSpecz49";

    localStorage.setItem(value30Save49, sQz49);
};

function square50(){

    var sQz50 = document.getElementById("imgSqrs50").src;

    value30Save50 = "zSqrArtSpecz50";

    localStorage.setItem(value30Save50, sQz50);
};

function square51(){

    var sQz51 = document.getElementById("imgSqrs51").src;

    value30Save51 = "zSqrArtSpecz51";

    localStorage.setItem(value30Save51, sQz51);
};

function square52(){

    var sQz52 = document.getElementById("imgSqrs52").src;

    value30Save52 = "zSqrArtSpecz52";

    localStorage.setItem(value30Save52, sQz52);
};

function square53(){

    var sQz53 = document.getElementById("imgSqrs53").src;

    value30Save53 = "zSqrArtSpecz53";

    localStorage.setItem(value30Save53, sQz53);
};

function square54(){

    var sQz54 = document.getElementById("imgSqrs54").src;

    value30Save54 = "zSqrArtSpecz54";

    localStorage.setItem(value30Save54, sQz54);
};

function square55(){

    var sQz55 = document.getElementById("imgSqrs55").src;

    value30Save55 = "zSqrArtSpecz55";

    localStorage.setItem(value30Save55, sQz55);
};

function square56(){

    var sQz56 = document.getElementById("imgSqrs56").src;

    value30Save56 = "zSqrArtSpecz56";

    localStorage.setItem(value30Save56, sQz56);
};

function square57(){

    var sQz57 = document.getElementById("imgSqrs57").src;

    value30Save57 = "zSqrArtSpecz57";

    localStorage.setItem(value30Save57, sQz57);
};

function square58(){

    var sQz58 = document.getElementById("imgSqrs58").src;

    value30Save58 = "zSqrArtSpecz58";

    localStorage.setItem(value30Save58, sQz58);
};

function square59(){

    var sQz59 = document.getElementById("imgSqrs59").src;

    value30Save59 = "zSqrArtSpecz59";

    localStorage.setItem(value30Save59, sQz59);
};

function square60(){

    var sQz60 = document.getElementById("imgSqrs60").src;

    value30Save60 = "zSqrArtSpecz60";

    localStorage.setItem(value30Save60, sQz60);
};

function square61(){

    var sQz61 = document.getElementById("imgSqrs61").src;

    value30Save61 = "zSqrArtSpecz61";

    localStorage.setItem(value30Save61, sQz61);
};

function square62(){

    var sQz62 = document.getElementById("imgSqrs62").src;

    value30Save62 = "zSqrArtSpecz62";

    localStorage.setItem(value30Save62, sQz62);
};

function square63(){

    var sQz63 = document.getElementById("imgSqrs63").src;

    value30Save63 = "zSqrArtSpecz63";

    localStorage.setItem(value30Save63, sQz63);
};

function square64(){

    var sQz64 = document.getElementById("imgSqrs64").src;

    value30Save64 = "zSqrArtSpecz64";

    localStorage.setItem(value30Save64, sQz64);
};

function square65(){

    var sQz65 = document.getElementById("imgSqrs65").src;

    value30Save65 = "zSqrArtSpecz65";

    localStorage.setItem(value30Save65, sQz65);
};

function square66(){

    var sQz66 = document.getElementById("imgSqrs66").src;

    value30Save66 = "zSqrArtSpecz66";

    localStorage.setItem(value30Save66, sQz66);
};

function square67(){

    var sQz67 = document.getElementById("imgSqrs67").src;

    value30Save67 = "zSqrArtSpecz67";

    localStorage.setItem(value30Save67, sQz67);
};

function square68(){

    var sQz68 = document.getElementById("imgSqrs68").src;

    value30Save68 = "zSqrArtSpecz68";

    localStorage.setItem(value30Save68, sQz68);
};

function square69(){

    var sQz69 = document.getElementById("imgSqrs69").src;

    value30Save69 = "zSqrArtSpecz69";

    localStorage.setItem(value30Save69, sQz69);
};

function square70(){

    var sQz70 = document.getElementById("imgSqrs70").src;

    value30Save70 = "zSqrArtSpecz70";

    localStorage.setItem(value30Save70, sQz70);
};

function square71(){

    var sQz71 = document.getElementById("imgSqrs71").src;

    value30Save71 = "zSqrArtSpecz71";

    localStorage.setItem(value30Save71, sQz71);
};

function square72(){

    var sQz72 = document.getElementById("imgSqrs72").src;

    value30Save72 = "zSqrArtSpecz72";

    localStorage.setItem(value30Save72, sQz72);
};

function square73(){

    var sQz73 = document.getElementById("imgSqrs73").src;

    value30Save73 = "zSqrArtSpecz73";

    localStorage.setItem(value30Save73, sQz73);
};

function square74(){

    var sQz74 = document.getElementById("imgSqrs74").src;

    value30Save74 = "zSqrArtSpecz74";

    localStorage.setItem(value30Save74, sQz74);
};

function square75(){

    var sQz75 = document.getElementById("imgSqrs75").src;

    value30Save75 = "zSqrArtSpecz75";

    localStorage.setItem(value30Save75, sQz75);
};

function square76(){

    var sQz76 = document.getElementById("imgSqrs76").src;

    value30Save76 = "zSqrArtSpecz76";

    localStorage.setItem(value30Save76, sQz76);
};

function square77(){

    var sQz77 = document.getElementById("imgSqrs77").src;

    value30Save77 = "zSqrArtSpecz77";

    localStorage.setItem(value30Save77, sQz77);
};

function square78(){

    var sQz78 = document.getElementById("imgSqrs78").src;

    value30Save78 = "zSqrArtSpecz78";

    localStorage.setItem(value30Save78, sQz78);
};

function square79(){

    var sQz79 = document.getElementById("imgSqrs79").src;

    value30Save79 = "zSqrArtSpecz79";

    localStorage.setItem(value30Save79, sQz79);
};

function square80(){

    var sQz80 = document.getElementById("imgSqrs80").src;

    value30Save80 = "zSqrArtSpecz80";

    localStorage.setItem(value30Save80, sQz80);
};

function square81(){

    var sQz81 = document.getElementById("imgSqrs81").src;

    value30Save81 = "zSqrArtSpecz81";

    localStorage.setItem(value30Save81, sQz81);
};

function square82(){

    var sQz82 = document.getElementById("imgSqrs82").src;

    value30Save82 = "zSqrArtSpecz82";

    localStorage.setItem(value30Save82, sQz82);
};

function square83(){

    var sQz83 = document.getElementById("imgSqrs83").src;

    value30Save83 = "zSqrArtSpecz83";

    localStorage.setItem(value30Save83, sQz83);
};

function square84(){

    var sQz84 = document.getElementById("imgSqrs84").src;

    value30Save84 = "zSqrArtSpecz84";

    localStorage.setItem(value30Save84, sQz84);
};

function square85(){

    var sQz85 = document.getElementById("imgSqrs85").src;

    value30Save85 = "zSqrArtSpecz85";

    localStorage.setItem(value30Save85, sQz85);
};

function square86(){

    var sQz86 = document.getElementById("imgSqrs86").src;

    value30Save86 = "zSqrArtSpecz86";

    localStorage.setItem(value30Save86, sQz86);
};

function square87(){

    var sQz87 = document.getElementById("imgSqrs87").src;

    value30Save87 = "zSqrArtSpecz87";

    localStorage.setItem(value30Save87, sQz87);
};

function square88(){

    var sQz88 = document.getElementById("imgSqrs88").src;

    value30Save88 = "zSqrArtSpecz88";

    localStorage.setItem(value30Save88, sQz88);
};

function square89(){

    var sQz89 = document.getElementById("imgSqrs89").src;

    value30Save89 = "zSqrArtSpecz89";

    localStorage.setItem(value30Save89, sQz89);
};

function square90(){

    var sQz90 = document.getElementById("imgSqrs90").src;

    value30Save90 = "zSqrArtSpecz90";

    localStorage.setItem(value30Save90, sQz90);
};

function square91(){

    var sQz91 = document.getElementById("imgSqrs91").src;

    value30Save91 = "zSqrArtSpecz91";

    localStorage.setItem(value30Save91, sQz91);
};

function square92(){

    var sQz92 = document.getElementById("imgSqrs92").src;

    value30Save92 = "zSqrArtSpecz92";

    localStorage.setItem(value30Save92, sQz92);
};

function square93(){

    var sQz93 = document.getElementById("imgSqrs93").src;

    value30Save93 = "zSqrArtSpecz93";

    localStorage.setItem(value30Save93, sQz93);
};

function square94(){

    var sQz94 = document.getElementById("imgSqrs94").src;

    value30Save94 = "zSqrArtSpecz94";

    localStorage.setItem(value30Save94, sQz94);
};

function square95(){

    var sQz95 = document.getElementById("imgSqrs95").src;

    value30Save95 = "zSqrArtSpecz95";

    localStorage.setItem(value30Save95, sQz95);
};

function square96(){

    var sQz96 = document.getElementById("imgSqrs96").src;

    value30Save96 = "zSqrArtSpecz96";

    localStorage.setItem(value30Save96, sQz96);
};

function square97(){

    var sQz97 = document.getElementById("imgSqrs97").src;

    value30Save97 = "zSqrArtSpecz97";

    localStorage.setItem(value30Save97, sQz97);
};

function square98(){

    var sQz98 = document.getElementById("imgSqrs98").src;

    value30Save98 = "zSqrArtSpecz98";

    localStorage.setItem(value30Save98, sQz98);
};

function square99(){

    var sQz99 = document.getElementById("imgSqrs99").src;

    value30Save99 = "zSqrArtSpecz99";

    localStorage.setItem(value30Save99, sQz99);
};

function square100(){

    var sQz100 = document.getElementById("imgSqrs100").src;

    value30Save100 = "zSqrArtSpecz100";

    localStorage.setItem(value30Save100, sQz100);
};

function square101(){

    var sQz101 = document.getElementById("imgSqrs101").src;

    value30Save101 = "zSqrArtSpecz101";

    localStorage.setItem(value30Save101, sQz101);
};

function square102(){

    var sQz102 = document.getElementById("imgSqrs102").src;

    value30Save102 = "zSqrArtSpecz102";

    localStorage.setItem(value30Save102, sQz102);
};

function square103(){

    var sQz103 = document.getElementById("imgSqrs103").src;

    value30Save103 = "zSqrArtSpecz103";

    localStorage.setItem(value30Save103, sQz103);
};

function square104(){

    var sQz104 = document.getElementById("imgSqrs104").src;

    value30Save104 = "zSqrArtSpecz104";

    localStorage.setItem(value30Save104, sQz104);
};

function square105(){

    var sQz105 = document.getElementById("imgSqrs105").src;

    value30Save105 = "zSqrArtSpecz105";

    localStorage.setItem(value30Save105, sQz105);
};

function square106(){

    var sQz106 = document.getElementById("imgSqrs106").src;

    value30Save106 = "zSqrArtSpecz106";

    localStorage.setItem(value30Save106, sQz106);
};

function square107(){

    var sQz107 = document.getElementById("imgSqrs107").src;

    value30Save107 = "zSqrArtSpecz107";

    localStorage.setItem(value30Save107, sQz107);
};

function square108(){

    var sQz108 = document.getElementById("imgSqrs108").src;

    value30Save108 = "zSqrArtSpecz108";

    localStorage.setItem(value30Save108, sQz108);
};

function square109(){

    var sQz109 = document.getElementById("imgSqrs109").src;

    value30Save109 = "zSqrArtSpecz109";

    localStorage.setItem(value30Save109, sQz109);
};

function square110(){

    var sQz110 = document.getElementById("imgSqrs110").src;

    value30Save110 = "zSqrArtSpecz110";

    localStorage.setItem(value30Save110, sQz110);
};

function square111(){

    var sQz111 = document.getElementById("imgSqrs111").src;

    value30Save111 = "zSqrArtSpecz111";

    localStorage.setItem(value30Save111, sQz111);
};

function square112(){

    var sQz112 = document.getElementById("imgSqrs112").src;

    value30Save112 = "zSqrArtSpecz112";

    localStorage.setItem(value30Save112, sQz112);
};

function square113(){

    var sQz113 = document.getElementById("imgSqrs113").src;

    value30Save113 = "zSqrArtSpecz113";

    localStorage.setItem(value30Save113, sQz113);
};

function square114(){

    var sQz114 = document.getElementById("imgSqrs114").src;

    value30Save114 = "zSqrArtSpecz114";

    localStorage.setItem(value30Save114, sQz114);
};

function square115(){

    var sQz115 = document.getElementById("imgSqrs115").src;

    value30Save115 = "zSqrArtSpecz115";

    localStorage.setItem(value30Save115, sQz115);
};

function square116(){

    var sQz116 = document.getElementById("imgSqrs116").src;

    value30Save116 = "zSqrArtSpecz116";

    localStorage.setItem(value30Save116, sQz116);
};

function square117(){

    var sQz117 = document.getElementById("imgSqrs117").src;

    value30Save117 = "zSqrArtSpecz117";

    localStorage.setItem(value30Save117, sQz117);
};

function square118(){

    var sQz118 = document.getElementById("imgSqrs118").src;

    value30Save118 = "zSqrArtSpecz118";

    localStorage.setItem(value30Save118, sQz118);
};

function square119(){

    var sQz119 = document.getElementById("imgSqrs119").src;

    value30Save119 = "zSqrArtSpecz119";

    localStorage.setItem(value30Save119, sQz119);
};

function square120(){

    var sQz120 = document.getElementById("imgSqrs120").src;

    value30Save120 = "zSqrArtSpecz120";

    localStorage.setItem(value30Save120, sQz120);
};

function square121(){

    var sQz121 = document.getElementById("imgSqrs121").src;

    value30Save121 = "zSqrArtSpecz121";

    localStorage.setItem(value30Save121, sQz121);
};

function square122(){

    var sQz122 = document.getElementById("imgSqrs122").src;

    value30Save122 = "zSqrArtSpecz122";

    localStorage.setItem(value30Save122, sQz122);
};

function square123(){

    var sQz123 = document.getElementById("imgSqrs123").src;

    value30Save123 = "zSqrArtSpecz123";

    localStorage.setItem(value30Save123, sQz123);
};

function square124(){

    var sQz124 = document.getElementById("imgSqrs124").src;

    value30Save124 = "zSqrArtSpecz124";

    localStorage.setItem(value30Save124, sQz124);
};

function square125(){

    var sQz125 = document.getElementById("imgSqrs125").src;

    value30Save125 = "zSqrArtSpecz125";

    localStorage.setItem(value30Save125, sQz125);
};

function square126(){

    var sQz126 = document.getElementById("imgSqrs126").src;

    value30Save126 = "zSqrArtSpecz126";

    localStorage.setItem(value30Save126, sQz126);
};

function square127(){

    var sQz127 = document.getElementById("imgSqrs127").src;

    value30Save127 = "zSqrArtSpecz127";

    localStorage.setItem(value30Save127, sQz127);
};

function square128(){

    var sQz128 = document.getElementById("imgSqrs128").src;

    value30Save128 = "zSqrArtSpecz128";

    localStorage.setItem(value30Save128, sQz128);
};

function square129(){

    var sQz129 = document.getElementById("imgSqrs129").src;

    value30Save129 = "zSqrArtSpecz129";

    localStorage.setItem(value30Save129, sQz129);
};

function square130(){

    var sQz130 = document.getElementById("imgSqrs130").src;

    value30Save130 = "zSqrArtSpecz130";

    localStorage.setItem(value30Save130, sQz130);
};

function square131(){

    var sQz131 = document.getElementById("imgSqrs131").src;

    value30Save131 = "zSqrArtSpecz131";

    localStorage.setItem(value30Save131, sQz131);
};

function square132(){

    var sQz132 = document.getElementById("imgSqrs132").src;

    value30Save132 = "zSqrArtSpecz132";

    localStorage.setItem(value30Save132, sQz132);
};

function square133(){

    var sQz133 = document.getElementById("imgSqrs133").src;

    value30Save133 = "zSqrArtSpecz133";

    localStorage.setItem(value30Save133, sQz133);
};

function square134(){

    var sQz134 = document.getElementById("imgSqrs134").src;

    value30Save134 = "zSqrArtSpecz134";

    localStorage.setItem(value30Save134, sQz134);
};

function square135(){

    var sQz135 = document.getElementById("imgSqrs135").src;

    value30Save135 = "zSqrArtSpecz135";

    localStorage.setItem(value30Save135, sQz135);
};

function square136(){

    var sQz136 = document.getElementById("imgSqrs136").src;

    value30Save136 = "zSqrArtSpecz136";

    localStorage.setItem(value30Save136, sQz136);
};

function square137(){

    var sQz137 = document.getElementById("imgSqrs137").src;

    value30Save137 = "zSqrArtSpecz137";

    localStorage.setItem(value30Save137, sQz137);
};

function square138(){

    var sQz138 = document.getElementById("imgSqrs138").src;

    value30Save138 = "zSqrArtSpecz138";

    localStorage.setItem(value30Save138, sQz138);
};

function square139(){

    var sQz139 = document.getElementById("imgSqrs139").src;

    value30Save139 = "zSqrArtSpecz139";

    localStorage.setItem(value30Save139, sQz139);
};

function square140(){

    var sQz140 = document.getElementById("imgSqrs140").src;

    value30Save140 = "zSqrArtSpecz140";

    localStorage.setItem(value30Save140, sQz140);
};

function square141(){

    var sQz141 = document.getElementById("imgSqrs141").src;

    value30Save141 = "zSqrArtSpecz141";

    localStorage.setItem(value30Save141, sQz141);
};

function square142(){

    var sQz142 = document.getElementById("imgSqrs142").src;

    value30Save142 = "zSqrArtSpecz142";

    localStorage.setItem(value30Save142, sQz142);
};

function square143(){

    var sQz143 = document.getElementById("imgSqrs143").src;

    value30Save143 = "zSqrArtSpecz143";

    localStorage.setItem(value30Save143, sQz143);
};

function square144(){

    var sQz144 = document.getElementById("imgSqrs144").src;

    value30Save144 = "zSqrArtSpecz144";

    localStorage.setItem(value30Save144, sQz144);
};

function square145(){

    var sQz145 = document.getElementById("imgSqrs145").src;

    value30Save145 = "zSqrArtSpecz145";

    localStorage.setItem(value30Save145, sQz145);
};

function square146(){

    var sQz146 = document.getElementById("imgSqrs146").src;

    value30Save146 = "zSqrArtSpecz146";

    localStorage.setItem(value30Save146, sQz146);
};

function square147(){

    var sQz147 = document.getElementById("imgSqrs147").src;

    value30Save147 = "zSqrArtSpecz147";

    localStorage.setItem(value30Save147, sQz147);
};

function square148(){

    var sQz148 = document.getElementById("imgSqrs148").src;

    value30Save148 = "zSqrArtSpecz148";

    localStorage.setItem(value30Save148, sQz148);
};

function square149(){

    var sQz149 = document.getElementById("imgSqrs149").src;

    value30Save149 = "zSqrArtSpecz149";

    localStorage.setItem(value30Save149, sQz149);
};

function square150(){

    var sQz150 = document.getElementById("imgSqrs150").src;

    value30Save150 = "zSqrArtSpecz150";

    localStorage.setItem(value30Save150, sQz150);
};

function square151(){

    var sQz151 = document.getElementById("imgSqrs151").src;

    value30Save151 = "zSqrArtSpecz151";

    localStorage.setItem(value30Save151, sQz151);
};

function square152(){

    var sQz152 = document.getElementById("imgSqrs152").src;

    value30Save152 = "zSqrArtSpecz152";

    localStorage.setItem(value30Save152, sQz152);
};

function square153(){

    var sQz153 = document.getElementById("imgSqrs153").src;

    value30Save153 = "zSqrArtSpecz153";

    localStorage.setItem(value30Save153, sQz153);
};

function square154(){

    var sQz154 = document.getElementById("imgSqrs154").src;

    value30Save154 = "zSqrArtSpecz154";

    localStorage.setItem(value30Save154, sQz154);
};

function square155(){

    var sQz155 = document.getElementById("imgSqrs155").src;

    value30Save155 = "zSqrArtSpecz155";

    localStorage.setItem(value30Save155, sQz155);
};

function square156(){

    var sQz156 = document.getElementById("imgSqrs156").src;

    value30Save156 = "zSqrArtSpecz156";

    localStorage.setItem(value30Save156, sQz156);
};

function square157(){

    var sQz157 = document.getElementById("imgSqrs157").src;

    value30Save157 = "zSqrArtSpecz157";

    localStorage.setItem(value30Save157, sQz157);
};

function square158(){

    var sQz158 = document.getElementById("imgSqrs158").src;

    value30Save158 = "zSqrArtSpecz158";

    localStorage.setItem(value30Save158, sQz158);
};

function square159(){

    var sQz159 = document.getElementById("imgSqrs159").src;

    value30Save159 = "zSqrArtSpecz159";

    localStorage.setItem(value30Save159, sQz159);
};

function square160(){

    var sQz160 = document.getElementById("imgSqrs160").src;

    value30Save160 = "zSqrArtSpecz160";

    localStorage.setItem(value30Save160, sQz160);
};

function square161(){

    var sQz161 = document.getElementById("imgSqrs161").src;

    value30Save161 = "zSqrArtSpecz161";

    localStorage.setItem(value30Save161, sQz161);
};

function square162(){

    var sQz162 = document.getElementById("imgSqrs162").src;

    value30Save162 = "zSqrArtSpecz162";

    localStorage.setItem(value30Save162, sQz162);
};

function square163(){

    var sQz163 = document.getElementById("imgSqrs163").src;

    value30Save163 = "zSqrArtSpecz163";

    localStorage.setItem(value30Save163, sQz163);
};

function square164(){

    var sQz164 = document.getElementById("imgSqrs164").src;

    value30Save164 = "zSqrArtSpecz164";

    localStorage.setItem(value30Save164, sQz164);
};

function square165(){

    var sQz165 = document.getElementById("imgSqrs165").src;

    value30Save165 = "zSqrArtSpecz165";

    localStorage.setItem(value30Save165, sQz165);
};

function square166(){

    var sQz166 = document.getElementById("imgSqrs166").src;

    value30Save166 = "zSqrArtSpecz166";

    localStorage.setItem(value30Save166, sQz166);
};

function square167(){

    var sQz167 = document.getElementById("imgSqrs167").src;

    value30Save167 = "zSqrArtSpecz167";

    localStorage.setItem(value30Save167, sQz167);
};

function square168(){

    var sQz168 = document.getElementById("imgSqrs168").src;

    value30Save168 = "zSqrArtSpecz168";

    localStorage.setItem(value30Save168, sQz168);
};

function square169(){

    var sQz169 = document.getElementById("imgSqrs169").src;

    value30Save169 = "zSqrArtSpecz169";

    localStorage.setItem(value30Save169, sQz169);
};

function square170(){

    var sQz170 = document.getElementById("imgSqrs170").src;

    value30Save170 = "zSqrArtSpecz170";

    localStorage.setItem(value30Save170, sQz170);
};

function square171(){

    var sQz171 = document.getElementById("imgSqrs171").src;

    value30Save171 = "zSqrArtSpecz171";

    localStorage.setItem(value30Save171, sQz171);
};

function square172(){

    var sQz172 = document.getElementById("imgSqrs172").src;

    value30Save172 = "zSqrArtSpecz172";

    localStorage.setItem(value30Save172, sQz172);
};

function square173(){

    var sQz173 = document.getElementById("imgSqrs173").src;

    value30Save173 = "zSqrArtSpecz173";

    localStorage.setItem(value30Save173, sQz173);
};

function square174(){

    var sQz174 = document.getElementById("imgSqrs174").src;

    value30Save174 = "zSqrArtSpecz174";

    localStorage.setItem(value30Save174, sQz174);
};

function square175(){

    var sQz175 = document.getElementById("imgSqrs175").src;

    value30Save175 = "zSqrArtSpecz175";

    localStorage.setItem(value30Save175, sQz175);
};

function square176(){

    var sQz176 = document.getElementById("imgSqrs176").src;

    value30Save176 = "zSqrArtSpecz176";

    localStorage.setItem(value30Save176, sQz176);
};

function square177(){

    var sQz177 = document.getElementById("imgSqrs177").src;

    value30Save177 = "zSqrArtSpecz177";

    localStorage.setItem(value30Save177, sQz177);
};

function square178(){

    var sQz178 = document.getElementById("imgSqrs178").src;

    value30Save178 = "zSqrArtSpecz178";

    localStorage.setItem(value30Save178, sQz178);
};

function square179(){

    var sQz179 = document.getElementById("imgSqrs179").src;

    value30Save179 = "zSqrArtSpecz179";

    localStorage.setItem(value30Save179, sQz179);
};

function square180(){

    var sQz180 = document.getElementById("imgSqrs180").src;

    value30Save180 = "zSqrArtSpecz180";

    localStorage.setItem(value30Save180, sQz180);
};

function square181(){

    var sQz181 = document.getElementById("imgSqrs181").src;

    value30Save181 = "zSqrArtSpecz181";

    localStorage.setItem(value30Save181, sQz181);
};

function square182(){

    var sQz182 = document.getElementById("imgSqrs182").src;

    value30Save182 = "zSqrArtSpecz182";

    localStorage.setItem(value30Save182, sQz182);
};

function square183(){

    var sQz183 = document.getElementById("imgSqrs183").src;

    value30Save183 = "zSqrArtSpecz183";

    localStorage.setItem(value30Save183, sQz183);
};

function square184(){

    var sQz184 = document.getElementById("imgSqrs184").src;

    value30Save184 = "zSqrArtSpecz184";

    localStorage.setItem(value30Save184, sQz184);
};

function square185(){

    var sQz185 = document.getElementById("imgSqrs185").src;

    value30Save185 = "zSqrArtSpecz185";

    localStorage.setItem(value30Save185, sQz185);
};

function square186(){

    var sQz186 = document.getElementById("imgSqrs186").src;

    value30Save186 = "zSqrArtSpecz186";

    localStorage.setItem(value30Save186, sQz186);
};

function square187(){

    var sQz187 = document.getElementById("imgSqrs187").src;

    value30Save187 = "zSqrArtSpecz187";

    localStorage.setItem(value30Save187, sQz187);
};

function square188(){

    var sQz188 = document.getElementById("imgSqrs188").src;

    value30Save188 = "zSqrArtSpecz188";

    localStorage.setItem(value30Save188, sQz188);
};

function square189(){

    var sQz189 = document.getElementById("imgSqrs189").src;

    value30Save189 = "zSqrArtSpecz189";

    localStorage.setItem(value30Save189, sQz189);
};

function square190(){

    var sQz190 = document.getElementById("imgSqrs190").src;

    value30Save190 = "zSqrArtSpecz190";

    localStorage.setItem(value30Save190, sQz190);
};

function square191(){

    var sQz191 = document.getElementById("imgSqrs191").src;

    value30Save191 = "zSqrArtSpecz191";

    localStorage.setItem(value30Save191, sQz191);
};

function square192(){

    var sQz192 = document.getElementById("imgSqrs192").src;

    value30Save192 = "zSqrArtSpecz192";

    localStorage.setItem(value30Save192, sQz192);
};

function square193(){

    var sQz193 = document.getElementById("imgSqrs193").src;

    value30Save193 = "zSqrArtSpecz193";

    localStorage.setItem(value30Save193, sQz193);
};

function square194(){

    var sQz194 = document.getElementById("imgSqrs194").src;

    value30Save194 = "zSqrArtSpecz194";

    localStorage.setItem(value30Save194, sQz194);
};

function square195(){

    var sQz195 = document.getElementById("imgSqrs195").src;

    value30Save195 = "zSqrArtSpecz195";

    localStorage.setItem(value30Save195, sQz195);
};

function square196(){

    var sQz196 = document.getElementById("imgSqrs196").src;

    value30Save196 = "zSqrArtSpecz196";

    localStorage.setItem(value30Save196, sQz196);
};

function square197(){

    var sQz197 = document.getElementById("imgSqrs197").src;

    value30Save197 = "zSqrArtSpecz197";

    localStorage.setItem(value30Save197, sQz197);
};

function square198(){

    var sQz198 = document.getElementById("imgSqrs198").src;

    value30Save198 = "zSqrArtSpecz198";

    localStorage.setItem(value30Save198, sQz198);
};

function square199(){

    var sQz199 = document.getElementById("imgSqrs199").src;

    value30Save199 = "zSqrArtSpecz199";

    localStorage.setItem(value30Save199, sQz199);
};

function square200(){

    var sQz200 = document.getElementById("imgSqrs200").src;

    value30Save200 = "zSqrArtSpecz200";

    localStorage.setItem(value30Save200, sQz200);
};

function square201(){

    var sQz201 = document.getElementById("imgSqrs201").src;

    value30Save201 = "zSqrArtSpecz201";

    localStorage.setItem(value30Save201, sQz201);
};

function square202(){

    var sQz202 = document.getElementById("imgSqrs202").src;

    value30Save202 = "zSqrArtSpecz202";

    localStorage.setItem(value30Save202, sQz202);
};

function square203(){

    var sQz203 = document.getElementById("imgSqrs203").src;

    value30Save203 = "zSqrArtSpecz203";

    localStorage.setItem(value30Save203, sQz203);
};

function square204(){

    var sQz204 = document.getElementById("imgSqrs204").src;

    value30Save204 = "zSqrArtSpecz204";

    localStorage.setItem(value30Save204, sQz204);
};

function square205(){

    var sQz205 = document.getElementById("imgSqrs205").src;

    value30Save205 = "zSqrArtSpecz205";

    localStorage.setItem(value30Save205, sQz205);
};

function square206(){

    var sQz206 = document.getElementById("imgSqrs206").src;

    value30Save206 = "zSqrArtSpecz206";

    localStorage.setItem(value30Save206, sQz206);
};

function square207(){

    var sQz207 = document.getElementById("imgSqrs207").src;

    value30Save207 = "zSqrArtSpecz207";

    localStorage.setItem(value30Save207, sQz207);
};

function square208(){

    var sQz208 = document.getElementById("imgSqrs208").src;

    value30Save208 = "zSqrArtSpecz208";

    localStorage.setItem(value30Save208, sQz208);
};

function square209(){

    var sQz209 = document.getElementById("imgSqrs209").src;

    value30Save209 = "zSqrArtSpecz209";

    localStorage.setItem(value30Save209, sQz209);
};

function square210(){

    var sQz210 = document.getElementById("imgSqrs210").src;

    value30Save210 = "zSqrArtSpecz210";

    localStorage.setItem(value30Save210, sQz210);
};

function square211(){

    var sQz211 = document.getElementById("imgSqrs211").src;

    value30Save211 = "zSqrArtSpecz211";

    localStorage.setItem(value30Save211, sQz211);
};

function square212(){

    var sQz212 = document.getElementById("imgSqrs212").src;

    value30Save212 = "zSqrArtSpecz212";

    localStorage.setItem(value30Save212, sQz212);
};

function square213(){

    var sQz213 = document.getElementById("imgSqrs213").src;

    value30Save213 = "zSqrArtSpecz213";

    localStorage.setItem(value30Save213, sQz213);
};

function square214(){

    var sQz214 = document.getElementById("imgSqrs214").src;

    value30Save214 = "zSqrArtSpecz214";

    localStorage.setItem(value30Save214, sQz214);
};

function square215(){

    var sQz215 = document.getElementById("imgSqrs215").src;

    value30Save215 = "zSqrArtSpecz215";

    localStorage.setItem(value30Save215, sQz215);
};

function square216(){

    var sQz216 = document.getElementById("imgSqrs216").src;

    value30Save216 = "zSqrArtSpecz216";

    localStorage.setItem(value30Save216, sQz216);
};

function square217(){

    var sQz217 = document.getElementById("imgSqrs217").src;

    value30Save217 = "zSqrArtSpecz217";

    localStorage.setItem(value30Save217, sQz217);
};

function square218(){

    var sQz218 = document.getElementById("imgSqrs218").src;

    value30Save218 = "zSqrArtSpecz218";

    localStorage.setItem(value30Save218, sQz218);
};

function square219(){

    var sQz219 = document.getElementById("imgSqrs219").src;

    value30Save219 = "zSqrArtSpecz219";

    localStorage.setItem(value30Save219, sQz219);
};

function square220(){

    var sQz220 = document.getElementById("imgSqrs220").src;

    value30Save220 = "zSqrArtSpecz220";

    localStorage.setItem(value30Save220, sQz220);
};

function square221(){

    var sQz221 = document.getElementById("imgSqrs221").src;

    value30Save221 = "zSqrArtSpecz221";

    localStorage.setItem(value30Save221, sQz221);
};

function square222(){

    var sQz222 = document.getElementById("imgSqrs222").src;

    value30Save222 = "zSqrArtSpecz222";

    localStorage.setItem(value30Save222, sQz222);
};

function square223(){

    var sQz223 = document.getElementById("imgSqrs223").src;

    value30Save223 = "zSqrArtSpecz223";

    localStorage.setItem(value30Save223, sQz223);
};

function square224(){

    var sQz224 = document.getElementById("imgSqrs224").src;

    value30Save224 = "zSqrArtSpecz224";

    localStorage.setItem(value30Save224, sQz224);
};

function square225(){

    var sQz225 = document.getElementById("imgSqrs225").src;

    value30Save225 = "zSqrArtSpecz225";

    localStorage.setItem(value30Save225, sQz225);
};

function square226(){

    var sQz226 = document.getElementById("imgSqrs226").src;

    value30Save226 = "zSqrArtSpecz226";

    localStorage.setItem(value30Save226, sQz226);
};

function square227(){

    var sQz227 = document.getElementById("imgSqrs227").src;

    value30Save227 = "zSqrArtSpecz227";

    localStorage.setItem(value30Save227, sQz227);
};

function square228(){

    var sQz228 = document.getElementById("imgSqrs228").src;

    value30Save228 = "zSqrArtSpecz228";

    localStorage.setItem(value30Save228, sQz228);
};

function square229(){

    var sQz229 = document.getElementById("imgSqrs229").src;

    value30Save229 = "zSqrArtSpecz229";

    localStorage.setItem(value30Save229, sQz229);
};

function square230(){

    var sQz230 = document.getElementById("imgSqrs230").src;

    value30Save230 = "zSqrArtSpecz230";

    localStorage.setItem(value30Save230, sQz230);
};

function square231(){

    var sQz231 = document.getElementById("imgSqrs231").src;

    value30Save231 = "zSqrArtSpecz231";

    localStorage.setItem(value30Save231, sQz231);
};

function square232(){

    var sQz232 = document.getElementById("imgSqrs232").src;

    value30Save232 = "zSqrArtSpecz232";

    localStorage.setItem(value30Save232, sQz232);
};

function square233(){

    var sQz233 = document.getElementById("imgSqrs233").src;

    value30Save233 = "zSqrArtSpecz233";

    localStorage.setItem(value30Save233, sQz233);
};

function square234(){

    var sQz234 = document.getElementById("imgSqrs234").src;

    value30Save234 = "zSqrArtSpecz234";

    localStorage.setItem(value30Save234, sQz234);
};

function square235(){

    var sQz235 = document.getElementById("imgSqrs235").src;

    value30Save235 = "zSqrArtSpecz235";

    localStorage.setItem(value30Save235, sQz235);
};

function square236(){

    var sQz236 = document.getElementById("imgSqrs236").src;

    value30Save236 = "zSqrArtSpecz236";

    localStorage.setItem(value30Save236, sQz236);
};

function square237(){

    var sQz237 = document.getElementById("imgSqrs237").src;

    value30Save237 = "zSqrArtSpecz237";

    localStorage.setItem(value30Save237, sQz237);
};

function square238(){

    var sQz238 = document.getElementById("imgSqrs238").src;

    value30Save238 = "zSqrArtSpecz238";

    localStorage.setItem(value30Save238, sQz238);
};

function square239(){

    var sQz239 = document.getElementById("imgSqrs239").src;

    value30Save239 = "zSqrArtSpecz239";

    localStorage.setItem(value30Save239, sQz239);
};

function square240(){

    var sQz240 = document.getElementById("imgSqrs240").src;

    value30Save240 = "zSqrArtSpecz240";

    localStorage.setItem(value30Save240, sQz240);
};

function square241(){

    var sQz241 = document.getElementById("imgSqrs241").src;

    value30Save241 = "zSqrArtSpecz241";

    localStorage.setItem(value30Save241, sQz241);
};

function square242(){

    var sQz242 = document.getElementById("imgSqrs242").src;

    value30Save242 = "zSqrArtSpecz242";

    localStorage.setItem(value30Save242, sQz242);
};

function square243(){

    var sQz243 = document.getElementById("imgSqrs243").src;

    value30Save243 = "zSqrArtSpecz243";

    localStorage.setItem(value30Save243, sQz243);
};

function square244(){

    var sQz244 = document.getElementById("imgSqrs244").src;

    value30Save244 = "zSqrArtSpecz244";

    localStorage.setItem(value30Save244, sQz244);
};

function square245(){

    var sQz245 = document.getElementById("imgSqrs245").src;

    value30Save245 = "zSqrArtSpecz245";

    localStorage.setItem(value30Save245, sQz245);
};

function square246(){

    var sQz246 = document.getElementById("imgSqrs246").src;

    value30Save246 = "zSqrArtSpecz246";

    localStorage.setItem(value30Save246, sQz246);
};

function square247(){

    var sQz247 = document.getElementById("imgSqrs247").src;

    value30Save247 = "zSqrArtSpecz247";

    localStorage.setItem(value30Save247, sQz247);
};

function square248(){

    var sQz248 = document.getElementById("imgSqrs248").src;

    value30Save248 = "zSqrArtSpecz248";

    localStorage.setItem(value30Save248, sQz248);
};

function square249(){

    var sQz249 = document.getElementById("imgSqrs249").src;

    value30Save249 = "zSqrArtSpecz249";

    localStorage.setItem(value30Save249, sQz249);
};

function square250(){

    var sQz250 = document.getElementById("imgSqrs250").src;

    value30Save250 = "zSqrArtSpecz250";

    localStorage.setItem(value30Save250, sQz250);
};

function square251(){

    var sQz251 = document.getElementById("imgSqrs251").src;

    value30Save251 = "zSqrArtSpecz251";

    localStorage.setItem(value30Save251, sQz251);
};

function square252(){

    var sQz252 = document.getElementById("imgSqrs252").src;

    value30Save252 = "zSqrArtSpecz252";

    localStorage.setItem(value30Save252, sQz252);
};

function square253(){

    var sQz253 = document.getElementById("imgSqrs253").src;

    value30Save253 = "zSqrArtSpecz253";

    localStorage.setItem(value30Save253, sQz253);
};

function square254(){

    var sQz254 = document.getElementById("imgSqrs254").src;

    value30Save254 = "zSqrArtSpecz254";

    localStorage.setItem(value30Save254, sQz254);
};

function square255(){

    var sQz255 = document.getElementById("imgSqrs255").src;

    value30Save255 = "zSqrArtSpecz255";

    localStorage.setItem(value30Save255, sQz255);
};

function square256(){

    var sQz256 = document.getElementById("imgSqrs256").src;

    value30Save256 = "zSqrArtSpecz256";

    localStorage.setItem(value30Save256, sQz256);
};

function square257(){

    var sQz257 = document.getElementById("imgSqrs257").src;

    value30Save257 = "zSqrArtSpecz257";

    localStorage.setItem(value30Save257, sQz257);
};

function square258(){

    var sQz258 = document.getElementById("imgSqrs258").src;

    value30Save258 = "zSqrArtSpecz258";

    localStorage.setItem(value30Save258, sQz258);
};

function square259(){

    var sQz259 = document.getElementById("imgSqrs259").src;

    value30Save259 = "zSqrArtSpecz259";

    localStorage.setItem(value30Save259, sQz259);
};

function square260(){

    var sQz260 = document.getElementById("imgSqrs260").src;

    value30Save260 = "zSqrArtSpecz260";

    localStorage.setItem(value30Save260, sQz260);
};

function square261(){

    var sQz261 = document.getElementById("imgSqrs261").src;

    value30Save261 = "zSqrArtSpecz261";

    localStorage.setItem(value30Save261, sQz261);
};

function square262(){

    var sQz262 = document.getElementById("imgSqrs262").src;

    value30Save262 = "zSqrArtSpecz262";

    localStorage.setItem(value30Save262, sQz262);
};

function square263(){

    var sQz263 = document.getElementById("imgSqrs263").src;

    value30Save263 = "zSqrArtSpecz263";

    localStorage.setItem(value30Save263, sQz263);
};

function square264(){

    var sQz264 = document.getElementById("imgSqrs264").src;

    value30Save264 = "zSqrArtSpecz264";

    localStorage.setItem(value30Save264, sQz264);
};

function square265(){

    var sQz265 = document.getElementById("imgSqrs265").src;

    value30Save265 = "zSqrArtSpecz265";

    localStorage.setItem(value30Save265, sQz265);
};

function square266(){

    var sQz266 = document.getElementById("imgSqrs266").src;

    value30Save266 = "zSqrArtSpecz266";

    localStorage.setItem(value30Save266, sQz266);
};

function square267(){

    var sQz267 = document.getElementById("imgSqrs267").src;

    value30Save267 = "zSqrArtSpecz267";

    localStorage.setItem(value30Save267, sQz267);
};

function square268(){

    var sQz268 = document.getElementById("imgSqrs268").src;

    value30Save268 = "zSqrArtSpecz268";

    localStorage.setItem(value30Save268, sQz268);
};

function square269(){

    var sQz269 = document.getElementById("imgSqrs269").src;

    value30Save269 = "zSqrArtSpecz269";

    localStorage.setItem(value30Save269, sQz269);
};

function square270(){

    var sQz270 = document.getElementById("imgSqrs270").src;

    value30Save270 = "zSqrArtSpecz270";

    localStorage.setItem(value30Save270, sQz270);
};

function square271(){

    var sQz271 = document.getElementById("imgSqrs271").src;

    value30Save271 = "zSqrArtSpecz271";

    localStorage.setItem(value30Save271, sQz271);
};

function square272(){

    var sQz272 = document.getElementById("imgSqrs272").src;

    value30Save272 = "zSqrArtSpecz272";

    localStorage.setItem(value30Save272, sQz272);
};

function square273(){

    var sQz273 = document.getElementById("imgSqrs273").src;

    value30Save273 = "zSqrArtSpecz273";

    localStorage.setItem(value30Save273, sQz273);
};

function square274(){

    var sQz274 = document.getElementById("imgSqrs274").src;

    value30Save274 = "zSqrArtSpecz274";

    localStorage.setItem(value30Save274, sQz274);
};

function square275(){

    var sQz275 = document.getElementById("imgSqrs275").src;

    value30Save275 = "zSqrArtSpecz275";

    localStorage.setItem(value30Save275, sQz275);
};

function square276(){

    var sQz276 = document.getElementById("imgSqrs276").src;

    value30Save276 = "zSqrArtSpecz276";

    localStorage.setItem(value30Save276, sQz276);
};

function square277(){

    var sQz277 = document.getElementById("imgSqrs277").src;

    value30Save277 = "zSqrArtSpecz277";

    localStorage.setItem(value30Save277, sQz277);
};

function square278(){

    var sQz278 = document.getElementById("imgSqrs278").src;

    value30Save278 = "zSqrArtSpecz278";

    localStorage.setItem(value30Save278, sQz278);
};

function square279(){

    var sQz279 = document.getElementById("imgSqrs279").src;

    value30Save279 = "zSqrArtSpecz279";

    localStorage.setItem(value30Save279, sQz279);
};

function square280(){

    var sQz280 = document.getElementById("imgSqrs280").src;

    value30Save280 = "zSqrArtSpecz280";

    localStorage.setItem(value30Save280, sQz280);
};

function square281(){

    var sQz281 = document.getElementById("imgSqrs281").src;

    value30Save281 = "zSqrArtSpecz281";

    localStorage.setItem(value30Save281, sQz281);
};

function square282(){

    var sQz282 = document.getElementById("imgSqrs282").src;

    value30Save282 = "zSqrArtSpecz282";

    localStorage.setItem(value30Save282, sQz282);
};

function square283(){

    var sQz283 = document.getElementById("imgSqrs283").src;

    value30Save283 = "zSqrArtSpecz283";

    localStorage.setItem(value30Save283, sQz283);
};

function square284(){

    var sQz284 = document.getElementById("imgSqrs284").src;

    value30Save284 = "zSqrArtSpecz284";

    localStorage.setItem(value30Save284, sQz284);
};

function square285(){

    var sQz285 = document.getElementById("imgSqrs285").src;

    value30Save285 = "zSqrArtSpecz285";

    localStorage.setItem(value30Save285, sQz285);
};

function square286(){

    var sQz286 = document.getElementById("imgSqrs286").src;

    value30Save286 = "zSqrArtSpecz286";

    localStorage.setItem(value30Save286, sQz286);
};

function square287(){

    var sQz287 = document.getElementById("imgSqrs287").src;

    value30Save287 = "zSqrArtSpecz287";

    localStorage.setItem(value30Save287, sQz287);
};

function square288(){

    var sQz288 = document.getElementById("imgSqrs288").src;

    value30Save288 = "zSqrArtSpecz288";

    localStorage.setItem(value30Save288, sQz288);
};

function square289(){

    var sQz289 = document.getElementById("imgSqrs289").src;

    value30Save289 = "zSqrArtSpecz289";

    localStorage.setItem(value30Save289, sQz289);
};

function square290(){

    var sQz290 = document.getElementById("imgSqrs290").src;

    value30Save290 = "zSqrArtSpecz290";

    localStorage.setItem(value30Save290, sQz290);
};

function square291(){

    var sQz291 = document.getElementById("imgSqrs291").src;

    value30Save291 = "zSqrArtSpecz291";

    localStorage.setItem(value30Save291, sQz291);
};

function square292(){

    var sQz292 = document.getElementById("imgSqrs292").src;

    value30Save292 = "zSqrArtSpecz292";

    localStorage.setItem(value30Save292, sQz292);
};

function square293(){

    var sQz293 = document.getElementById("imgSqrs293").src;

    value30Save293 = "zSqrArtSpecz293";

    localStorage.setItem(value30Save293, sQz293);
};

function square294(){

    var sQz294 = document.getElementById("imgSqrs294").src;

    value30Save294 = "zSqrArtSpecz294";

    localStorage.setItem(value30Save294, sQz294);
};

function square295(){

    var sQz295 = document.getElementById("imgSqrs295").src;

    value30Save295 = "zSqrArtSpecz295";

    localStorage.setItem(value30Save295, sQz295);
};

function square296(){

    var sQz296 = document.getElementById("imgSqrs296").src;

    value30Save296 = "zSqrArtSpecz296";

    localStorage.setItem(value30Save296, sQz296);
};

function square297(){

    var sQz297 = document.getElementById("imgSqrs297").src;

    value30Save297 = "zSqrArtSpecz297";

    localStorage.setItem(value30Save297, sQz297);
};

function square298(){

    var sQz298 = document.getElementById("imgSqrs298").src;

    value30Save298 = "zSqrArtSpecz298";

    localStorage.setItem(value30Save298, sQz298);
};

function square299(){

    var sQz299 = document.getElementById("imgSqrs299").src;

    value30Save299 = "zSqrArtSpecz299";

    localStorage.setItem(value30Save299, sQz299);
};

function square300(){

    var sQz300 = document.getElementById("imgSqrs300").src;

    value30Save300 = "zSqrArtSpecz300";

    localStorage.setItem(value30Save300, sQz300);
};

function square301(){

    var sQz301 = document.getElementById("imgSqrs301").src;

    value30Save301 = "zSqrArtSpecz301";

    localStorage.setItem(value30Save301, sQz301);
};

function square302(){

    var sQz302 = document.getElementById("imgSqrs302").src;

    value30Save302 = "zSqrArtSpecz302";

    localStorage.setItem(value30Save302, sQz302);
};

function square303(){

    var sQz303 = document.getElementById("imgSqrs303").src;

    value30Save303 = "zSqrArtSpecz303";

    localStorage.setItem(value30Save303, sQz303);
};

function square304(){

    var sQz304 = document.getElementById("imgSqrs304").src;

    value30Save304 = "zSqrArtSpecz304";

    localStorage.setItem(value30Save304, sQz304);
};

function square305(){

    var sQz305 = document.getElementById("imgSqrs305").src;

    value30Save305 = "zSqrArtSpecz305";

    localStorage.setItem(value30Save305, sQz305);
};

function square306(){

    var sQz306 = document.getElementById("imgSqrs306").src;

    value30Save306 = "zSqrArtSpecz306";

    localStorage.setItem(value30Save306, sQz306);
};

function square307(){

    var sQz307 = document.getElementById("imgSqrs307").src;

    value30Save307 = "zSqrArtSpecz307";

    localStorage.setItem(value30Save307, sQz307);
};

function square308(){

    var sQz308 = document.getElementById("imgSqrs308").src;

    value30Save308 = "zSqrArtSpecz308";

    localStorage.setItem(value30Save308, sQz308);
};

function square309(){

    var sQz309 = document.getElementById("imgSqrs309").src;

    value30Save309 = "zSqrArtSpecz309";

    localStorage.setItem(value30Save309, sQz309);
};

function square310(){

    var sQz310 = document.getElementById("imgSqrs310").src;

    value30Save310 = "zSqrArtSpecz310";

    localStorage.setItem(value30Save310, sQz310);
};

function square311(){

    var sQz311 = document.getElementById("imgSqrs311").src;

    value30Save311 = "zSqrArtSpecz311";

    localStorage.setItem(value30Save311, sQz311);
};

function square312(){

    var sQz312 = document.getElementById("imgSqrs312").src;

    value30Save312 = "zSqrArtSpecz312";

    localStorage.setItem(value30Save312, sQz312);
};

function square313(){

    var sQz313 = document.getElementById("imgSqrs313").src;

    value30Save313 = "zSqrArtSpecz313";

    localStorage.setItem(value30Save313, sQz313);
};

function square314(){

    var sQz314 = document.getElementById("imgSqrs314").src;

    value30Save314 = "zSqrArtSpecz314";

    localStorage.setItem(value30Save314, sQz314);
};

function square315(){

    var sQz315 = document.getElementById("imgSqrs315").src;

    value30Save315 = "zSqrArtSpecz315";

    localStorage.setItem(value30Save315, sQz315);
};

function square316(){

    var sQz316 = document.getElementById("imgSqrs316").src;

    value30Save316 = "zSqrArtSpecz316";

    localStorage.setItem(value30Save316, sQz316);
};

function square317(){

    var sQz317 = document.getElementById("imgSqrs317").src;

    value30Save317 = "zSqrArtSpecz317";

    localStorage.setItem(value30Save317, sQz317);
};

function square318(){

    var sQz318 = document.getElementById("imgSqrs318").src;

    value30Save318 = "zSqrArtSpecz318";

    localStorage.setItem(value30Save318, sQz318);
};

function square319(){

    var sQz319 = document.getElementById("imgSqrs319").src;

    value30Save319 = "zSqrArtSpecz319";

    localStorage.setItem(value30Save319, sQz319);
};

function square320(){

    var sQz320 = document.getElementById("imgSqrs320").src;

    value30Save320 = "zSqrArtSpecz320";

    localStorage.setItem(value30Save320, sQz320);
};

function square321(){

    var sQz321 = document.getElementById("imgSqrs321").src;

    value30Save321 = "zSqrArtSpecz321";

    localStorage.setItem(value30Save321, sQz321);
};

function square322(){

    var sQz322 = document.getElementById("imgSqrs322").src;

    value30Save322 = "zSqrArtSpecz322";

    localStorage.setItem(value30Save322, sQz322);
};

function square323(){

    var sQz323 = document.getElementById("imgSqrs323").src;

    value30Save323 = "zSqrArtSpecz323";

    localStorage.setItem(value30Save323, sQz323);
};

function square324(){

    var sQz324 = document.getElementById("imgSqrs324").src;

    value30Save324 = "zSqrArtSpecz324";

    localStorage.setItem(value30Save324, sQz324);
};

function square325(){

    var sQz325 = document.getElementById("imgSqrs325").src;

    value30Save325 = "zSqrArtSpecz325";

    localStorage.setItem(value30Save325, sQz325);
};

function square326(){

    var sQz326 = document.getElementById("imgSqrs326").src;

    value30Save326 = "zSqrArtSpecz326";

    localStorage.setItem(value30Save326, sQz326);
};

function square327(){

    var sQz327 = document.getElementById("imgSqrs327").src;

    value30Save327 = "zSqrArtSpecz327";

    localStorage.setItem(value30Save327, sQz327);
};

function square328(){

    var sQz328 = document.getElementById("imgSqrs328").src;

    value30Save328 = "zSqrArtSpecz328";

    localStorage.setItem(value30Save328, sQz328);
};

function square329(){

    var sQz329 = document.getElementById("imgSqrs329").src;

    value30Save329 = "zSqrArtSpecz329";

    localStorage.setItem(value30Save329, sQz329);
};

function square330(){

    var sQz330 = document.getElementById("imgSqrs330").src;

    value30Save330 = "zSqrArtSpecz330";

    localStorage.setItem(value30Save330, sQz330);
};

function square331(){

    var sQz331 = document.getElementById("imgSqrs331").src;

    value30Save331 = "zSqrArtSpecz331";

    localStorage.setItem(value30Save331, sQz331);
};

function square332(){

    var sQz332 = document.getElementById("imgSqrs332").src;

    value30Save332 = "zSqrArtSpecz332";

    localStorage.setItem(value30Save332, sQz332);
};

function square333(){

    var sQz333 = document.getElementById("imgSqrs333").src;

    value30Save333 = "zSqrArtSpecz333";

    localStorage.setItem(value30Save333, sQz333);
};

function square334(){

    var sQz334 = document.getElementById("imgSqrs334").src;

    value30Save334 = "zSqrArtSpecz334";

    localStorage.setItem(value30Save334, sQz334);
};

function square335(){

    var sQz335 = document.getElementById("imgSqrs335").src;

    value30Save335 = "zSqrArtSpecz335";

    localStorage.setItem(value30Save335, sQz335);
};

function square336(){

    var sQz336 = document.getElementById("imgSqrs336").src;

    value30Save336 = "zSqrArtSpecz336";

    localStorage.setItem(value30Save336, sQz336);
};

function square337(){

    var sQz337 = document.getElementById("imgSqrs337").src;

    value30Save337 = "zSqrArtSpecz337";

    localStorage.setItem(value30Save337, sQz337);
};

function square338(){

    var sQz338 = document.getElementById("imgSqrs338").src;

    value30Save338 = "zSqrArtSpecz338";

    localStorage.setItem(value30Save338, sQz338);
};

function square339(){

    var sQz339 = document.getElementById("imgSqrs339").src;

    value30Save339 = "zSqrArtSpecz339";

    localStorage.setItem(value30Save339, sQz339);
};

function square340(){

    var sQz340 = document.getElementById("imgSqrs340").src;

    value30Save340 = "zSqrArtSpecz340";

    localStorage.setItem(value30Save340, sQz340);
};

function square341(){

    var sQz341 = document.getElementById("imgSqrs341").src;

    value30Save341 = "zSqrArtSpecz341";

    localStorage.setItem(value30Save341, sQz341);
};

function square342(){

    var sQz342 = document.getElementById("imgSqrs342").src;

    value30Save342 = "zSqrArtSpecz342";

    localStorage.setItem(value30Save342, sQz342);
};

function square343(){

    var sQz343 = document.getElementById("imgSqrs343").src;

    value30Save343 = "zSqrArtSpecz343";

    localStorage.setItem(value30Save343, sQz343);
};

function square344(){

    var sQz344 = document.getElementById("imgSqrs344").src;

    value30Save344 = "zSqrArtSpecz344";

    localStorage.setItem(value30Save344, sQz344);
};

function square345(){

    var sQz345 = document.getElementById("imgSqrs345").src;

    value30Save345 = "zSqrArtSpecz345";

    localStorage.setItem(value30Save345, sQz345);
};

function square346(){

    var sQz346 = document.getElementById("imgSqrs346").src;

    value30Save346 = "zSqrArtSpecz346";

    localStorage.setItem(value30Save346, sQz346);
};

function square347(){

    var sQz347 = document.getElementById("imgSqrs347").src;

    value30Save347 = "zSqrArtSpecz347";

    localStorage.setItem(value30Save347, sQz347);
};

function square348(){

    var sQz348 = document.getElementById("imgSqrs348").src;

    value30Save348 = "zSqrArtSpecz348";

    localStorage.setItem(value30Save348, sQz348);
};

function square349(){

    var sQz349 = document.getElementById("imgSqrs349").src;

    value30Save349 = "zSqrArtSpecz349";

    localStorage.setItem(value30Save349, sQz349);
};

function square350(){

    var sQz350 = document.getElementById("imgSqrs350").src;

    value30Save350 = "zSqrArtSpecz350";

    localStorage.setItem(value30Save350, sQz350);
};

function square351(){

    var sQz351 = document.getElementById("imgSqrs351").src;

    value30Save351 = "zSqrArtSpecz351";

    localStorage.setItem(value30Save351, sQz351);
};

function square352(){

    var sQz352 = document.getElementById("imgSqrs352").src;

    value30Save352 = "zSqrArtSpecz352";

    localStorage.setItem(value30Save352, sQz352);
};

function square353(){

    var sQz353 = document.getElementById("imgSqrs353").src;

    value30Save353 = "zSqrArtSpecz353";

    localStorage.setItem(value30Save353, sQz353);
};

function square354(){

    var sQz354 = document.getElementById("imgSqrs354").src;

    value30Save354 = "zSqrArtSpecz354";

    localStorage.setItem(value30Save354, sQz354);
};

function square355(){

    var sQz355 = document.getElementById("imgSqrs355").src;

    value30Save355 = "zSqrArtSpecz355";

    localStorage.setItem(value30Save355, sQz355);
};

function square356(){

    var sQz356 = document.getElementById("imgSqrs356").src;

    value30Save356 = "zSqrArtSpecz356";

    localStorage.setItem(value30Save356, sQz356);
};

function square357(){

    var sQz357 = document.getElementById("imgSqrs357").src;

    value30Save357 = "zSqrArtSpecz357";

    localStorage.setItem(value30Save357, sQz357);
};

function square358(){

    var sQz358 = document.getElementById("imgSqrs358").src;

    value30Save358 = "zSqrArtSpecz358";

    localStorage.setItem(value30Save358, sQz358);
};

function square359(){

    var sQz359 = document.getElementById("imgSqrs359").src;

    value30Save359 = "zSqrArtSpecz359";

    localStorage.setItem(value30Save359, sQz359);
};

function square360(){

    var sQz360 = document.getElementById("imgSqrs360").src;

    value30Save360 = "zSqrArtSpecz360";

    localStorage.setItem(value30Save360, sQz360);
};

function square361(){

    var sQz361 = document.getElementById("imgSqrs361").src;

    value30Save361 = "zSqrArtSpecz361";

    localStorage.setItem(value30Save361, sQz361);
};

function square362(){

    var sQz362 = document.getElementById("imgSqrs362").src;

    value30Save362 = "zSqrArtSpecz362";

    localStorage.setItem(value30Save362, sQz362);
};

function square363(){

    var sQz363 = document.getElementById("imgSqrs363").src;

    value30Save363 = "zSqrArtSpecz363";

    localStorage.setItem(value30Save363, sQz363);
};

function square364(){

    var sQz364 = document.getElementById("imgSqrs364").src;

    value30Save364 = "zSqrArtSpecz364";

    localStorage.setItem(value30Save364, sQz364);
};

function square365(){

    var sQz365 = document.getElementById("imgSqrs365").src;

    value30Save365 = "zSqrArtSpecz365";

    localStorage.setItem(value30Save365, sQz365);
};

function square366(){

    var sQz366 = document.getElementById("imgSqrs366").src;

    value30Save366 = "zSqrArtSpecz366";

    localStorage.setItem(value30Save366, sQz366);
};

function square367(){

    var sQz367 = document.getElementById("imgSqrs367").src;

    value30Save367 = "zSqrArtSpecz367";

    localStorage.setItem(value30Save367, sQz367);
};

function square368(){

    var sQz368 = document.getElementById("imgSqrs368").src;

    value30Save368 = "zSqrArtSpecz368";

    localStorage.setItem(value30Save368, sQz368);
};

function square369(){

    var sQz369 = document.getElementById("imgSqrs369").src;

    value30Save369 = "zSqrArtSpecz369";

    localStorage.setItem(value30Save369, sQz369);
};

function square370(){

    var sQz370 = document.getElementById("imgSqrs370").src;

    value30Save370 = "zSqrArtSpecz370";

    localStorage.setItem(value30Save370, sQz370);
};

function square371(){

    var sQz371 = document.getElementById("imgSqrs371").src;

    value30Save371 = "zSqrArtSpecz371";

    localStorage.setItem(value30Save371, sQz371);
};

function square372(){

    var sQz372 = document.getElementById("imgSqrs372").src;

    value30Save372 = "zSqrArtSpecz372";

    localStorage.setItem(value30Save372, sQz372);
};

function square373(){

    var sQz373 = document.getElementById("imgSqrs373").src;

    value30Save373 = "zSqrArtSpecz373";

    localStorage.setItem(value30Save373, sQz373);
};

function square374(){

    var sQz374 = document.getElementById("imgSqrs374").src;

    value30Save374 = "zSqrArtSpecz374";

    localStorage.setItem(value30Save374, sQz374);
};

function square375(){

    var sQz375 = document.getElementById("imgSqrs375").src;

    value30Save375 = "zSqrArtSpecz375";

    localStorage.setItem(value30Save375, sQz375);
};

function square376(){

    var sQz376 = document.getElementById("imgSqrs376").src;

    value30Save376 = "zSqrArtSpecz376";

    localStorage.setItem(value30Save376, sQz376);
};

function square377(){

    var sQz377 = document.getElementById("imgSqrs377").src;

    value30Save377 = "zSqrArtSpecz377";

    localStorage.setItem(value30Save377, sQz377);
};

function square378(){

    var sQz378 = document.getElementById("imgSqrs378").src;

    value30Save378 = "zSqrArtSpecz378";

    localStorage.setItem(value30Save378, sQz378);
};

function square379(){

    var sQz379 = document.getElementById("imgSqrs379").src;

    value30Save379 = "zSqrArtSpecz379";

    localStorage.setItem(value30Save379, sQz379);
};

function square380(){

    var sQz380 = document.getElementById("imgSqrs380").src;

    value30Save380 = "zSqrArtSpecz380";

    localStorage.setItem(value30Save380, sQz380);
};

function square381(){

    var sQz381 = document.getElementById("imgSqrs381").src;

    value30Save381 = "zSqrArtSpecz381";

    localStorage.setItem(value30Save381, sQz381);
};

function square382(){

    var sQz382 = document.getElementById("imgSqrs382").src;

    value30Save382 = "zSqrArtSpecz382";

    localStorage.setItem(value30Save382, sQz382);
};

function square383(){

    var sQz383 = document.getElementById("imgSqrs383").src;

    value30Save383 = "zSqrArtSpecz383";

    localStorage.setItem(value30Save383, sQz383);
};

function square384(){

    var sQz384 = document.getElementById("imgSqrs384").src;

    value30Save384 = "zSqrArtSpecz384";

    localStorage.setItem(value30Save384, sQz384);
};

function square385(){

    var sQz385 = document.getElementById("imgSqrs385").src;

    value30Save385 = "zSqrArtSpecz385";

    localStorage.setItem(value30Save385, sQz385);
};

function square386(){

    var sQz386 = document.getElementById("imgSqrs386").src;

    value30Save386 = "zSqrArtSpecz386";

    localStorage.setItem(value30Save386, sQz386);
};

function square387(){

    var sQz387 = document.getElementById("imgSqrs387").src;

    value30Save387 = "zSqrArtSpecz387";

    localStorage.setItem(value30Save387, sQz387);
};

function square388(){

    var sQz388 = document.getElementById("imgSqrs388").src;

    value30Save388 = "zSqrArtSpecz388";

    localStorage.setItem(value30Save388, sQz388);
};

function square389(){

    var sQz389 = document.getElementById("imgSqrs389").src;

    value30Save389 = "zSqrArtSpecz389";

    localStorage.setItem(value30Save389, sQz389);
};

function square390(){

    var sQz390 = document.getElementById("imgSqrs390").src;

    value30Save390 = "zSqrArtSpecz390";

    localStorage.setItem(value30Save390, sQz390);
};

function square391(){

    var sQz391 = document.getElementById("imgSqrs391").src;

    value30Save391 = "zSqrArtSpecz391";

    localStorage.setItem(value30Save391, sQz391);
};

function square392(){

    var sQz392 = document.getElementById("imgSqrs392").src;

    value30Save392 = "zSqrArtSpecz392";

    localStorage.setItem(value30Save392, sQz392);
};

function square393(){

    var sQz393 = document.getElementById("imgSqrs393").src;

    value30Save393 = "zSqrArtSpecz393";

    localStorage.setItem(value30Save393, sQz393);
};

function square394(){

    var sQz394 = document.getElementById("imgSqrs394").src;

    value30Save394 = "zSqrArtSpecz394";

    localStorage.setItem(value30Save394, sQz394);
};

function square395(){

    var sQz395 = document.getElementById("imgSqrs395").src;

    value30Save395 = "zSqrArtSpecz395";

    localStorage.setItem(value30Save395, sQz395);
};

function square396(){

    var sQz396 = document.getElementById("imgSqrs396").src;

    value30Save396 = "zSqrArtSpecz396";

    localStorage.setItem(value30Save396, sQz396);
};

function square397(){

    var sQz397 = document.getElementById("imgSqrs397").src;

    value30Save397 = "zSqrArtSpecz397";

    localStorage.setItem(value30Save397, sQz397);
};

function square398(){

    var sQz398 = document.getElementById("imgSqrs398").src;

    value30Save398 = "zSqrArtSpecz398";

    localStorage.setItem(value30Save398, sQz398);
};

function square399(){

    var sQz399 = document.getElementById("imgSqrs399").src;

    value30Save399 = "zSqrArtSpecz399";

    localStorage.setItem(value30Save399, sQz399);
};

function square400(){

    var sQz400 = document.getElementById("imgSqrs400").src;

    value30Save400 = "zSqrArtSpecz400";

    localStorage.setItem(value30Save400, sQz400);
};

function square401(){

    var sQz401 = document.getElementById("imgSqrs401").src;

    value30Save401 = "zSqrArtSpecz401";

    localStorage.setItem(value30Save401, sQz401);
};

function square402(){

    var sQz402 = document.getElementById("imgSqrs402").src;

    value30Save402 = "zSqrArtSpecz402";

    localStorage.setItem(value30Save402, sQz402);
};

function square403(){

    var sQz403 = document.getElementById("imgSqrs403").src;

    value30Save403 = "zSqrArtSpecz403";

    localStorage.setItem(value30Save403, sQz403);
};

function square404(){

    var sQz404 = document.getElementById("imgSqrs404").src;

    value30Save404 = "zSqrArtSpecz404";

    localStorage.setItem(value30Save404, sQz404);
};

function square405(){

    var sQz405 = document.getElementById("imgSqrs405").src;

    value30Save405 = "zSqrArtSpecz405";

    localStorage.setItem(value30Save405, sQz405);
};

function square406(){

    var sQz406 = document.getElementById("imgSqrs406").src;

    value30Save406 = "zSqrArtSpecz406";

    localStorage.setItem(value30Save406, sQz406);
};

function square407(){

    var sQz407 = document.getElementById("imgSqrs407").src;

    value30Save407 = "zSqrArtSpecz407";

    localStorage.setItem(value30Save407, sQz407);
};

function square408(){

    var sQz408 = document.getElementById("imgSqrs408").src;

    value30Save408 = "zSqrArtSpecz408";

    localStorage.setItem(value30Save408, sQz408);
};

function square409(){

    var sQz409 = document.getElementById("imgSqrs409").src;

    value30Save409 = "zSqrArtSpecz409";

    localStorage.setItem(value30Save409, sQz409);
};

function square410(){

    var sQz410 = document.getElementById("imgSqrs410").src;

    value30Save410 = "zSqrArtSpecz410";

    localStorage.setItem(value30Save410, sQz410);
};

function square411(){

    var sQz411 = document.getElementById("imgSqrs411").src;

    value30Save411 = "zSqrArtSpecz411";

    localStorage.setItem(value30Save411, sQz411);
};

function square412(){

    var sQz412 = document.getElementById("imgSqrs412").src;

    value30Save412 = "zSqrArtSpecz412";

    localStorage.setItem(value30Save412, sQz412);
};

function square413(){

    var sQz413 = document.getElementById("imgSqrs413").src;

    value30Save413 = "zSqrArtSpecz413";

    localStorage.setItem(value30Save413, sQz413);
};

function square414(){

    var sQz414 = document.getElementById("imgSqrs414").src;

    value30Save414 = "zSqrArtSpecz414";

    localStorage.setItem(value30Save414, sQz414);
};

function square415(){

    var sQz415 = document.getElementById("imgSqrs415").src;

    value30Save415 = "zSqrArtSpecz415";

    localStorage.setItem(value30Save415, sQz415);
};

function square416(){

    var sQz416 = document.getElementById("imgSqrs416").src;

    value30Save416 = "zSqrArtSpecz416";

    localStorage.setItem(value30Save416, sQz416);
};

function square417(){

    var sQz417 = document.getElementById("imgSqrs417").src;

    value30Save417 = "zSqrArtSpecz417";

    localStorage.setItem(value30Save417, sQz417);
};

function square418(){

    var sQz418 = document.getElementById("imgSqrs418").src;

    value30Save418 = "zSqrArtSpecz418";

    localStorage.setItem(value30Save418, sQz418);
};

function square419(){

    var sQz419 = document.getElementById("imgSqrs419").src;

    value30Save419 = "zSqrArtSpecz419";

    localStorage.setItem(value30Save419, sQz419);
};

function square420(){

    var sQz420 = document.getElementById("imgSqrs420").src;

    value30Save420 = "zSqrArtSpecz420";

    localStorage.setItem(value30Save420, sQz420);
};

function square421(){

    var sQz421 = document.getElementById("imgSqrs421").src;

    value30Save421 = "zSqrArtSpecz421";

    localStorage.setItem(value30Save421, sQz421);
};

function square422(){

    var sQz422 = document.getElementById("imgSqrs422").src;

    value30Save422 = "zSqrArtSpecz422";

    localStorage.setItem(value30Save422, sQz422);
};

function square423(){

    var sQz423 = document.getElementById("imgSqrs423").src;

    value30Save423 = "zSqrArtSpecz423";

    localStorage.setItem(value30Save423, sQz423);
};

function square424(){

    var sQz424 = document.getElementById("imgSqrs424").src;

    value30Save424 = "zSqrArtSpecz424";

    localStorage.setItem(value30Save424, sQz424);
};

function square425(){

    var sQz425 = document.getElementById("imgSqrs425").src;

    value30Save425 = "zSqrArtSpecz425";

    localStorage.setItem(value30Save425, sQz425);
};

function square426(){

    var sQz426 = document.getElementById("imgSqrs426").src;

    value30Save426 = "zSqrArtSpecz426";

    localStorage.setItem(value30Save426, sQz426);
};

function square427(){

    var sQz427 = document.getElementById("imgSqrs427").src;

    value30Save427 = "zSqrArtSpecz427";

    localStorage.setItem(value30Save427, sQz427);
};

function square428(){

    var sQz428 = document.getElementById("imgSqrs428").src;

    value30Save428 = "zSqrArtSpecz428";

    localStorage.setItem(value30Save428, sQz428);
};

function square429(){

    var sQz429 = document.getElementById("imgSqrs429").src;

    value30Save429 = "zSqrArtSpecz429";

    localStorage.setItem(value30Save429, sQz429);
};

function square430(){

    var sQz430 = document.getElementById("imgSqrs430").src;

    value30Save430 = "zSqrArtSpecz430";

    localStorage.setItem(value30Save430, sQz430);
};

function square431(){

    var sQz431 = document.getElementById("imgSqrs431").src;

    value30Save431 = "zSqrArtSpecz431";

    localStorage.setItem(value30Save431, sQz431);
};

function square432(){

    var sQz432 = document.getElementById("imgSqrs432").src;

    value30Save432 = "zSqrArtSpecz432";

    localStorage.setItem(value30Save432, sQz432);
};

function square433(){

    var sQz433 = document.getElementById("imgSqrs433").src;

    value30Save433 = "zSqrArtSpecz433";

    localStorage.setItem(value30Save433, sQz433);
};

function square434(){

    var sQz434 = document.getElementById("imgSqrs434").src;

    value30Save434 = "zSqrArtSpecz434";

    localStorage.setItem(value30Save434, sQz434);
};

function square435(){

    var sQz435 = document.getElementById("imgSqrs435").src;

    value30Save435 = "zSqrArtSpecz435";

    localStorage.setItem(value30Save435, sQz435);
};

function square436(){

    var sQz436 = document.getElementById("imgSqrs436").src;

    value30Save436 = "zSqrArtSpecz436";

    localStorage.setItem(value30Save436, sQz436);
};

function square437(){

    var sQz437 = document.getElementById("imgSqrs437").src;

    value30Save437 = "zSqrArtSpecz437";

    localStorage.setItem(value30Save437, sQz437);
};

function square438(){

    var sQz438 = document.getElementById("imgSqrs438").src;

    value30Save438 = "zSqrArtSpecz438";

    localStorage.setItem(value30Save438, sQz438);
};

function square439(){

    var sQz439 = document.getElementById("imgSqrs439").src;

    value30Save439 = "zSqrArtSpecz439";

    localStorage.setItem(value30Save439, sQz439);
};

function square440(){

    var sQz440 = document.getElementById("imgSqrs440").src;

    value30Save440 = "zSqrArtSpecz440";

    localStorage.setItem(value30Save440, sQz440);
};

function square441(){

    var sQz441 = document.getElementById("imgSqrs441").src;

    value30Save441 = "zSqrArtSpecz441";

    localStorage.setItem(value30Save441, sQz441);
};

function square442(){

    var sQz442 = document.getElementById("imgSqrs442").src;

    value30Save442 = "zSqrArtSpecz442";

    localStorage.setItem(value30Save442, sQz442);
};

function square443(){

    var sQz443 = document.getElementById("imgSqrs443").src;

    value30Save443 = "zSqrArtSpecz443";

    localStorage.setItem(value30Save443, sQz443);
};

function square444(){

    var sQz444 = document.getElementById("imgSqrs444").src;

    value30Save444 = "zSqrArtSpecz444";

    localStorage.setItem(value30Save444, sQz444);
};

function square445(){

    var sQz445 = document.getElementById("imgSqrs445").src;

    value30Save445 = "zSqrArtSpecz445";

    localStorage.setItem(value30Save445, sQz445);
};

function square446(){

    var sQz446 = document.getElementById("imgSqrs446").src;

    value30Save446 = "zSqrArtSpecz446";

    localStorage.setItem(value30Save446, sQz446);
};

function square447(){

    var sQz447 = document.getElementById("imgSqrs447").src;

    value30Save447 = "zSqrArtSpecz447";

    localStorage.setItem(value30Save447, sQz447);
};

function square448(){

    var sQz448 = document.getElementById("imgSqrs448").src;

    value30Save448 = "zSqrArtSpecz448";

    localStorage.setItem(value30Save448, sQz448);
};

function square449(){

    var sQz449 = document.getElementById("imgSqrs449").src;

    value30Save449 = "zSqrArtSpecz449";

    localStorage.setItem(value30Save449, sQz449);
};

function square450(){

    var sQz450 = document.getElementById("imgSqrs450").src;

    value30Save450 = "zSqrArtSpecz450";

    localStorage.setItem(value30Save450, sQz450);
};

function square451(){

    var sQz451 = document.getElementById("imgSqrs451").src;

    value30Save451 = "zSqrArtSpecz451";

    localStorage.setItem(value30Save451, sQz451);
};

function square452(){

    var sQz452 = document.getElementById("imgSqrs452").src;

    value30Save452 = "zSqrArtSpecz452";

    localStorage.setItem(value30Save452, sQz452);
};

function square453(){

    var sQz453 = document.getElementById("imgSqrs453").src;

    value30Save453 = "zSqrArtSpecz453";

    localStorage.setItem(value30Save453, sQz453);
};

function square454(){

    var sQz454 = document.getElementById("imgSqrs454").src;

    value30Save454 = "zSqrArtSpecz454";

    localStorage.setItem(value30Save454, sQz454);
};

function square455(){

    var sQz455 = document.getElementById("imgSqrs455").src;

    value30Save455 = "zSqrArtSpecz455";

    localStorage.setItem(value30Save455, sQz455);
};

function square456(){

    var sQz456 = document.getElementById("imgSqrs456").src;

    value30Save456 = "zSqrArtSpecz456";

    localStorage.setItem(value30Save456, sQz456);
};

function square457(){

    var sQz457 = document.getElementById("imgSqrs457").src;

    value30Save457 = "zSqrArtSpecz457";

    localStorage.setItem(value30Save457, sQz457);
};

function square458(){

    var sQz458 = document.getElementById("imgSqrs458").src;

    value30Save458 = "zSqrArtSpecz458";

    localStorage.setItem(value30Save458, sQz458);
};

function square459(){

    var sQz459 = document.getElementById("imgSqrs459").src;

    value30Save459 = "zSqrArtSpecz459";

    localStorage.setItem(value30Save459, sQz459);
};

function square460(){

    var sQz460 = document.getElementById("imgSqrs460").src;

    value30Save460 = "zSqrArtSpecz460";

    localStorage.setItem(value30Save460, sQz460);
};

function square461(){

    var sQz461 = document.getElementById("imgSqrs461").src;

    value30Save461 = "zSqrArtSpecz461";

    localStorage.setItem(value30Save461, sQz461);
};

function square462(){

    var sQz462 = document.getElementById("imgSqrs462").src;

    value30Save462 = "zSqrArtSpecz462";

    localStorage.setItem(value30Save462, sQz462);
};

function square463(){

    var sQz463 = document.getElementById("imgSqrs463").src;

    value30Save463 = "zSqrArtSpecz463";

    localStorage.setItem(value30Save463, sQz463);
};

function square464(){

    var sQz464 = document.getElementById("imgSqrs464").src;

    value30Save464 = "zSqrArtSpecz464";

    localStorage.setItem(value30Save464, sQz464);
};

function square465(){

    var sQz465 = document.getElementById("imgSqrs465").src;

    value30Save465 = "zSqrArtSpecz465";

    localStorage.setItem(value30Save465, sQz465);
};

function square466(){

    var sQz466 = document.getElementById("imgSqrs466").src;

    value30Save466 = "zSqrArtSpecz466";

    localStorage.setItem(value30Save466, sQz466);
};

function square467(){

    var sQz467 = document.getElementById("imgSqrs467").src;

    value30Save467 = "zSqrArtSpecz467";

    localStorage.setItem(value30Save467, sQz467);
};

function square468(){

    var sQz468 = document.getElementById("imgSqrs468").src;

    value30Save468 = "zSqrArtSpecz468";

    localStorage.setItem(value30Save468, sQz468);
};

function square469(){

    var sQz469 = document.getElementById("imgSqrs469").src;

    value30Save469 = "zSqrArtSpecz469";

    localStorage.setItem(value30Save469, sQz469);
};

function square470(){

    var sQz470 = document.getElementById("imgSqrs470").src;

    value30Save470 = "zSqrArtSpecz470";

    localStorage.setItem(value30Save470, sQz470);
};

function square471(){

    var sQz471 = document.getElementById("imgSqrs471").src;

    value30Save471 = "zSqrArtSpecz471";

    localStorage.setItem(value30Save471, sQz471);
};

function square472(){

    var sQz472 = document.getElementById("imgSqrs472").src;

    value30Save472 = "zSqrArtSpecz472";

    localStorage.setItem(value30Save472, sQz472);
};

function square473(){

    var sQz473 = document.getElementById("imgSqrs473").src;

    value30Save473 = "zSqrArtSpecz473";

    localStorage.setItem(value30Save473, sQz473);
};

function square474(){

    var sQz474 = document.getElementById("imgSqrs474").src;

    value30Save474 = "zSqrArtSpecz474";

    localStorage.setItem(value30Save474, sQz474);
};

function square475(){

    var sQz475 = document.getElementById("imgSqrs475").src;

    value30Save475 = "zSqrArtSpecz475";

    localStorage.setItem(value30Save475, sQz475);
};

function square476(){

    var sQz476 = document.getElementById("imgSqrs476").src;

    value30Save476 = "zSqrArtSpecz476";

    localStorage.setItem(value30Save476, sQz476);
};

function square477(){

    var sQz477 = document.getElementById("imgSqrs477").src;

    value30Save477 = "zSqrArtSpecz477";

    localStorage.setItem(value30Save477, sQz477);
};

function square478(){

    var sQz478 = document.getElementById("imgSqrs478").src;

    value30Save478 = "zSqrArtSpecz478";

    localStorage.setItem(value30Save478, sQz478);
};

function square479(){

    var sQz479 = document.getElementById("imgSqrs479").src;

    value30Save479 = "zSqrArtSpecz479";

    localStorage.setItem(value30Save479, sQz479);
};

function square480(){

    var sQz480 = document.getElementById("imgSqrs480").src;

    value30Save480 = "zSqrArtSpecz480";

    localStorage.setItem(value30Save480, sQz480);
};

function square481(){

    var sQz481 = document.getElementById("imgSqrs481").src;

    value30Save481 = "zSqrArtSpecz481";

    localStorage.setItem(value30Save481, sQz481);
};

function square482(){

    var sQz482 = document.getElementById("imgSqrs482").src;

    value30Save482 = "zSqrArtSpecz482";

    localStorage.setItem(value30Save482, sQz482);
};

function square483(){

    var sQz483 = document.getElementById("imgSqrs483").src;

    value30Save483 = "zSqrArtSpecz483";

    localStorage.setItem(value30Save483, sQz483);
};

function square484(){

    var sQz484 = document.getElementById("imgSqrs484").src;

    value30Save484 = "zSqrArtSpecz484";

    localStorage.setItem(value30Save484, sQz484);
};

function square485(){

    var sQz485 = document.getElementById("imgSqrs485").src;

    value30Save485 = "zSqrArtSpecz485";

    localStorage.setItem(value30Save485, sQz485);
};

function square486(){

    var sQz486 = document.getElementById("imgSqrs486").src;

    value30Save486 = "zSqrArtSpecz486";

    localStorage.setItem(value30Save486, sQz486);
};

function square487(){

    var sQz487 = document.getElementById("imgSqrs487").src;

    value30Save487 = "zSqrArtSpecz487";

    localStorage.setItem(value30Save487, sQz487);
};

function square488(){

    var sQz488 = document.getElementById("imgSqrs488").src;

    value30Save488 = "zSqrArtSpecz488";

    localStorage.setItem(value30Save488, sQz488);
};

function square489(){

    var sQz489 = document.getElementById("imgSqrs489").src;

    value30Save489 = "zSqrArtSpecz489";

    localStorage.setItem(value30Save489, sQz489);
};

function square490(){

    var sQz490 = document.getElementById("imgSqrs490").src;

    value30Save490 = "zSqrArtSpecz490";

    localStorage.setItem(value30Save490, sQz490);
};

function square491(){

    var sQz491 = document.getElementById("imgSqrs491").src;

    value30Save491 = "zSqrArtSpecz491";

    localStorage.setItem(value30Save491, sQz491);
};

function square492(){

    var sQz492 = document.getElementById("imgSqrs492").src;

    value30Save492 = "zSqrArtSpecz492";

    localStorage.setItem(value30Save492, sQz492);
};

function square493(){

    var sQz493 = document.getElementById("imgSqrs493").src;

    value30Save493 = "zSqrArtSpecz493";

    localStorage.setItem(value30Save493, sQz493);
};

function square494(){

    var sQz494 = document.getElementById("imgSqrs494").src;

    value30Save494 = "zSqrArtSpecz494";

    localStorage.setItem(value30Save494, sQz494);
};

function square495(){

    var sQz495 = document.getElementById("imgSqrs495").src;

    value30Save495 = "zSqrArtSpecz495";

    localStorage.setItem(value30Save495, sQz495);
};

function square496(){

    var sQz496 = document.getElementById("imgSqrs496").src;

    value30Save496 = "zSqrArtSpecz496";

    localStorage.setItem(value30Save496, sQz496);
};

function square497(){

    var sQz497 = document.getElementById("imgSqrs497").src;

    value30Save497 = "zSqrArtSpecz497";

    localStorage.setItem(value30Save497, sQz497);
};

function square498(){

    var sQz498 = document.getElementById("imgSqrs498").src;

    value30Save498 = "zSqrArtSpecz498";

    localStorage.setItem(value30Save498, sQz498);
};

function square499(){

    var sQz499 = document.getElementById("imgSqrs499").src;

    value30Save499 = "zSqrArtSpecz499";

    localStorage.setItem(value30Save499, sQz499);
};

function square500(){

    var sQz500 = document.getElementById("imgSqrs500").src;

    value30Save500 = "zSqrArtSpecz500";

    localStorage.setItem(value30Save500, sQz500);
};

function square501(){

    var sQz501 = document.getElementById("imgSqrs501").src;

    value30Save501 = "zSqrArtSpecz501";

    localStorage.setItem(value30Save501, sQz501);
};

function square502(){

    var sQz502 = document.getElementById("imgSqrs502").src;

    value30Save502 = "zSqrArtSpecz502";

    localStorage.setItem(value30Save502, sQz502);
};

function square503(){

    var sQz503 = document.getElementById("imgSqrs503").src;

    value30Save503 = "zSqrArtSpecz503";

    localStorage.setItem(value30Save503, sQz503);
};

function square504(){

    var sQz504 = document.getElementById("imgSqrs504").src;

    value30Save504 = "zSqrArtSpecz504";

    localStorage.setItem(value30Save504, sQz504);
};

function square505(){

    var sQz505 = document.getElementById("imgSqrs505").src;

    value30Save505 = "zSqrArtSpecz505";

    localStorage.setItem(value30Save505, sQz505);
};

function square506(){

    var sQz506 = document.getElementById("imgSqrs506").src;

    value30Save506 = "zSqrArtSpecz506";

    localStorage.setItem(value30Save506, sQz506);
};

function square507(){

    var sQz507 = document.getElementById("imgSqrs507").src;

    value30Save507 = "zSqrArtSpecz507";

    localStorage.setItem(value30Save507, sQz507);
};

function square508(){

    var sQz508 = document.getElementById("imgSqrs508").src;

    value30Save508 = "zSqrArtSpecz508";

    localStorage.setItem(value30Save508, sQz508);
};

function square509(){

    var sQz509 = document.getElementById("imgSqrs509").src;

    value30Save509 = "zSqrArtSpecz509";

    localStorage.setItem(value30Save509, sQz509);
};

function square510(){

    var sQz510 = document.getElementById("imgSqrs510").src;

    value30Save510 = "zSqrArtSpecz510";

    localStorage.setItem(value30Save510, sQz510);
};

function square511(){

    var sQz511 = document.getElementById("imgSqrs511").src;

    value30Save511 = "zSqrArtSpecz511";

    localStorage.setItem(value30Save511, sQz511);
};

function square512(){

    var sQz512 = document.getElementById("imgSqrs512").src;

    value30Save512 = "zSqrArtSpecz512";

    localStorage.setItem(value30Save512, sQz512);
};

function square513(){

    var sQz513 = document.getElementById("imgSqrs513").src;

    value30Save513 = "zSqrArtSpecz513";

    localStorage.setItem(value30Save513, sQz513);
};

function square514(){

    var sQz514 = document.getElementById("imgSqrs514").src;

    value30Save514 = "zSqrArtSpecz514";

    localStorage.setItem(value30Save514, sQz514);
};

function square515(){

    var sQz515 = document.getElementById("imgSqrs515").src;

    value30Save515 = "zSqrArtSpecz515";

    localStorage.setItem(value30Save515, sQz515);
};

function square516(){

    var sQz516 = document.getElementById("imgSqrs516").src;

    value30Save516 = "zSqrArtSpecz516";

    localStorage.setItem(value30Save516, sQz516);
};

function square517(){

    var sQz517 = document.getElementById("imgSqrs517").src;

    value30Save517 = "zSqrArtSpecz517";

    localStorage.setItem(value30Save517, sQz517);
};

function square518(){

    var sQz518 = document.getElementById("imgSqrs518").src;

    value30Save518 = "zSqrArtSpecz518";

    localStorage.setItem(value30Save518, sQz518);
};

function square519(){

    var sQz519 = document.getElementById("imgSqrs519").src;

    value30Save519 = "zSqrArtSpecz519";

    localStorage.setItem(value30Save519, sQz519);
};

function square520(){

    var sQz520 = document.getElementById("imgSqrs520").src;

    value30Save520 = "zSqrArtSpecz520";

    localStorage.setItem(value30Save520, sQz520);
};

function square521(){

    var sQz521 = document.getElementById("imgSqrs521").src;

    value30Save521 = "zSqrArtSpecz521";

    localStorage.setItem(value30Save521, sQz521);
};

function square522(){

    var sQz522 = document.getElementById("imgSqrs522").src;

    value30Save522 = "zSqrArtSpecz522";

    localStorage.setItem(value30Save522, sQz522);
};

function square523(){

    var sQz523 = document.getElementById("imgSqrs523").src;

    value30Save523 = "zSqrArtSpecz523";

    localStorage.setItem(value30Save523, sQz523);
};

function square524(){

    var sQz524 = document.getElementById("imgSqrs524").src;

    value30Save524 = "zSqrArtSpecz524";

    localStorage.setItem(value30Save524, sQz524);
};

function square525(){

    var sQz525 = document.getElementById("imgSqrs525").src;

    value30Save525 = "zSqrArtSpecz525";

    localStorage.setItem(value30Save525, sQz525);
};

function square526(){

    var sQz526 = document.getElementById("imgSqrs526").src;

    value30Save526 = "zSqrArtSpecz526";

    localStorage.setItem(value30Save526, sQz526);
};

function square527(){

    var sQz527 = document.getElementById("imgSqrs527").src;

    value30Save527 = "zSqrArtSpecz527";

    localStorage.setItem(value30Save527, sQz527);
};

function square528(){

    var sQz528 = document.getElementById("imgSqrs528").src;

    value30Save528 = "zSqrArtSpecz528";

    localStorage.setItem(value30Save528, sQz528);
};

function square529(){

    var sQz529 = document.getElementById("imgSqrs529").src;

    value30Save529 = "zSqrArtSpecz529";

    localStorage.setItem(value30Save529, sQz529);
};

function square530(){

    var sQz530 = document.getElementById("imgSqrs530").src;

    value30Save530 = "zSqrArtSpecz530";

    localStorage.setItem(value30Save530, sQz530);
};

function square531(){

    var sQz531 = document.getElementById("imgSqrs531").src;

    value30Save531 = "zSqrArtSpecz531";

    localStorage.setItem(value30Save531, sQz531);
};

function square532(){

    var sQz532 = document.getElementById("imgSqrs532").src;

    value30Save532 = "zSqrArtSpecz532";

    localStorage.setItem(value30Save532, sQz532);
};

function square533(){

    var sQz533 = document.getElementById("imgSqrs533").src;

    value30Save533 = "zSqrArtSpecz533";

    localStorage.setItem(value30Save533, sQz533);
};

function square534(){

    var sQz534 = document.getElementById("imgSqrs534").src;

    value30Save534 = "zSqrArtSpecz534";

    localStorage.setItem(value30Save534, sQz534);
};

function square535(){

    var sQz535 = document.getElementById("imgSqrs535").src;

    value30Save535 = "zSqrArtSpecz535";

    localStorage.setItem(value30Save535, sQz535);
};

function square536(){

    var sQz536 = document.getElementById("imgSqrs536").src;

    value30Save536 = "zSqrArtSpecz536";

    localStorage.setItem(value30Save536, sQz536);
};

function square537(){

    var sQz537 = document.getElementById("imgSqrs537").src;

    value30Save537 = "zSqrArtSpecz537";

    localStorage.setItem(value30Save537, sQz537);
};

function square538(){

    var sQz538 = document.getElementById("imgSqrs538").src;

    value30Save538 = "zSqrArtSpecz538";

    localStorage.setItem(value30Save538, sQz538);
};

function square539(){

    var sQz539 = document.getElementById("imgSqrs539").src;

    value30Save539 = "zSqrArtSpecz539";

    localStorage.setItem(value30Save539, sQz539);
};

function square540(){

    var sQz540 = document.getElementById("imgSqrs540").src;

    value30Save540 = "zSqrArtSpecz540";

    localStorage.setItem(value30Save540, sQz540);
};

function square541(){

    var sQz541 = document.getElementById("imgSqrs541").src;

    value30Save541 = "zSqrArtSpecz541";

    localStorage.setItem(value30Save541, sQz541);
};

function square542(){

    var sQz542 = document.getElementById("imgSqrs542").src;

    value30Save542 = "zSqrArtSpecz542";

    localStorage.setItem(value30Save542, sQz542);
};

function square543(){

    var sQz543 = document.getElementById("imgSqrs543").src;

    value30Save543 = "zSqrArtSpecz543";

    localStorage.setItem(value30Save543, sQz543);
};

function square544(){

    var sQz544 = document.getElementById("imgSqrs544").src;

    value30Save544 = "zSqrArtSpecz544";

    localStorage.setItem(value30Save544, sQz544);
};

function square545(){

    var sQz545 = document.getElementById("imgSqrs545").src;

    value30Save545 = "zSqrArtSpecz545";

    localStorage.setItem(value30Save545, sQz545);
};

function square546(){

    var sQz546 = document.getElementById("imgSqrs546").src;

    value30Save546 = "zSqrArtSpecz546";

    localStorage.setItem(value30Save546, sQz546);
};

function square547(){

    var sQz547 = document.getElementById("imgSqrs547").src;

    value30Save547 = "zSqrArtSpecz547";

    localStorage.setItem(value30Save547, sQz547);
};

function square548(){

    var sQz548 = document.getElementById("imgSqrs548").src;

    value30Save548 = "zSqrArtSpecz548";

    localStorage.setItem(value30Save548, sQz548);
};

function square549(){

    var sQz549 = document.getElementById("imgSqrs549").src;

    value30Save549 = "zSqrArtSpecz549";

    localStorage.setItem(value30Save549, sQz549);
};

function square550(){

    var sQz550 = document.getElementById("imgSqrs550").src;

    value30Save550 = "zSqrArtSpecz550";

    localStorage.setItem(value30Save550, sQz550);
};

function square551(){

    var sQz551 = document.getElementById("imgSqrs551").src;

    value30Save551 = "zSqrArtSpecz551";

    localStorage.setItem(value30Save551, sQz551);
};

function square552(){

    var sQz552 = document.getElementById("imgSqrs552").src;

    value30Save552 = "zSqrArtSpecz552";

    localStorage.setItem(value30Save552, sQz552);
};

function square553(){

    var sQz553 = document.getElementById("imgSqrs553").src;

    value30Save553 = "zSqrArtSpecz553";

    localStorage.setItem(value30Save553, sQz553);
};

function square554(){

    var sQz554 = document.getElementById("imgSqrs554").src;

    value30Save554 = "zSqrArtSpecz554";

    localStorage.setItem(value30Save554, sQz554);
};

function square555(){

    var sQz555 = document.getElementById("imgSqrs555").src;

    value30Save555 = "zSqrArtSpecz555";

    localStorage.setItem(value30Save555, sQz555);
};

function square556(){

    var sQz556 = document.getElementById("imgSqrs556").src;

    value30Save556 = "zSqrArtSpecz556";

    localStorage.setItem(value30Save556, sQz556);
};

function square557(){

    var sQz557 = document.getElementById("imgSqrs557").src;

    value30Save557 = "zSqrArtSpecz557";

    localStorage.setItem(value30Save557, sQz557);
};

function square558(){

    var sQz558 = document.getElementById("imgSqrs558").src;

    value30Save558 = "zSqrArtSpecz558";

    localStorage.setItem(value30Save558, sQz558);
};

function square559(){

    var sQz559 = document.getElementById("imgSqrs559").src;

    value30Save559 = "zSqrArtSpecz559";

    localStorage.setItem(value30Save559, sQz559);
};

function square560(){

    var sQz560 = document.getElementById("imgSqrs560").src;

    value30Save560 = "zSqrArtSpecz560";

    localStorage.setItem(value30Save560, sQz560);
};

function square561(){

    var sQz561 = document.getElementById("imgSqrs561").src;

    value30Save561 = "zSqrArtSpecz561";

    localStorage.setItem(value30Save561, sQz561);
};

function square562(){

    var sQz562 = document.getElementById("imgSqrs562").src;

    value30Save562 = "zSqrArtSpecz562";

    localStorage.setItem(value30Save562, sQz562);
};

function square563(){

    var sQz563 = document.getElementById("imgSqrs563").src;

    value30Save563 = "zSqrArtSpecz563";

    localStorage.setItem(value30Save563, sQz563);
};

function square564(){

    var sQz564 = document.getElementById("imgSqrs564").src;

    value30Save564 = "zSqrArtSpecz564";

    localStorage.setItem(value30Save564, sQz564);
};

function square565(){

    var sQz565 = document.getElementById("imgSqrs565").src;

    value30Save565 = "zSqrArtSpecz565";

    localStorage.setItem(value30Save565, sQz565);
};

function square566(){

    var sQz566 = document.getElementById("imgSqrs566").src;

    value30Save566 = "zSqrArtSpecz566";

    localStorage.setItem(value30Save566, sQz566);
};

function square567(){

    var sQz567 = document.getElementById("imgSqrs567").src;

    value30Save567 = "zSqrArtSpecz567";

    localStorage.setItem(value30Save567, sQz567);
};

function square568(){

    var sQz568 = document.getElementById("imgSqrs568").src;

    value30Save568 = "zSqrArtSpecz568";

    localStorage.setItem(value30Save568, sQz568);
};

function square569(){

    var sQz569 = document.getElementById("imgSqrs569").src;

    value30Save569 = "zSqrArtSpecz569";

    localStorage.setItem(value30Save569, sQz569);
};

function square570(){

    var sQz570 = document.getElementById("imgSqrs570").src;

    value30Save570 = "zSqrArtSpecz570";

    localStorage.setItem(value30Save570, sQz570);
};

function square571(){

    var sQz571 = document.getElementById("imgSqrs571").src;

    value30Save571 = "zSqrArtSpecz571";

    localStorage.setItem(value30Save571, sQz571);
};

function square572(){

    var sQz572 = document.getElementById("imgSqrs572").src;

    value30Save572 = "zSqrArtSpecz572";

    localStorage.setItem(value30Save572, sQz572);
};

function square573(){

    var sQz573 = document.getElementById("imgSqrs573").src;

    value30Save573 = "zSqrArtSpecz573";

    localStorage.setItem(value30Save573, sQz573);
};

function square574(){

    var sQz574 = document.getElementById("imgSqrs574").src;

    value30Save574 = "zSqrArtSpecz574";

    localStorage.setItem(value30Save574, sQz574);
};

function square575(){

    var sQz575 = document.getElementById("imgSqrs575").src;

    value30Save575 = "zSqrArtSpecz575";

    localStorage.setItem(value30Save575, sQz575);
};

function square576(){

    var sQz576 = document.getElementById("imgSqrs576").src;

    value30Save576 = "zSqrArtSpecz576";

    localStorage.setItem(value30Save576, sQz576);
};

function square577(){

    var sQz577 = document.getElementById("imgSqrs577").src;

    value30Save577 = "zSqrArtSpecz577";

    localStorage.setItem(value30Save577, sQz577);
};

function square578(){

    var sQz578 = document.getElementById("imgSqrs578").src;

    value30Save578 = "zSqrArtSpecz578";

    localStorage.setItem(value30Save578, sQz578);
};

function square579(){

    var sQz579 = document.getElementById("imgSqrs579").src;

    value30Save579 = "zSqrArtSpecz579";

    localStorage.setItem(value30Save579, sQz579);
};

function square580(){

    var sQz580 = document.getElementById("imgSqrs580").src;

    value30Save580 = "zSqrArtSpecz580";

    localStorage.setItem(value30Save580, sQz580);
};

function square581(){

    var sQz581 = document.getElementById("imgSqrs581").src;

    value30Save581 = "zSqrArtSpecz581";

    localStorage.setItem(value30Save581, sQz581);
};

function square582(){

    var sQz582 = document.getElementById("imgSqrs582").src;

    value30Save582 = "zSqrArtSpecz582";

    localStorage.setItem(value30Save582, sQz582);
};

function square583(){

    var sQz583 = document.getElementById("imgSqrs583").src;

    value30Save583 = "zSqrArtSpecz583";

    localStorage.setItem(value30Save583, sQz583);
};

function square584(){

    var sQz584 = document.getElementById("imgSqrs584").src;

    value30Save584 = "zSqrArtSpecz584";

    localStorage.setItem(value30Save584, sQz584);
};

function square585(){

    var sQz585 = document.getElementById("imgSqrs585").src;

    value30Save585 = "zSqrArtSpecz585";

    localStorage.setItem(value30Save585, sQz585);
};

function square586(){

    var sQz586 = document.getElementById("imgSqrs586").src;

    value30Save586 = "zSqrArtSpecz586";

    localStorage.setItem(value30Save586, sQz586);
};

function square587(){

    var sQz587 = document.getElementById("imgSqrs587").src;

    value30Save587 = "zSqrArtSpecz587";

    localStorage.setItem(value30Save587, sQz587);
};

function square588(){

    var sQz588 = document.getElementById("imgSqrs588").src;

    value30Save588 = "zSqrArtSpecz588";

    localStorage.setItem(value30Save588, sQz588);
};

function square589(){

    var sQz589 = document.getElementById("imgSqrs589").src;

    value30Save589 = "zSqrArtSpecz589";

    localStorage.setItem(value30Save589, sQz589);
};

function square590(){

    var sQz590 = document.getElementById("imgSqrs590").src;

    value30Save590 = "zSqrArtSpecz590";

    localStorage.setItem(value30Save590, sQz590);
};

function square591(){

    var sQz591 = document.getElementById("imgSqrs591").src;

    value30Save591 = "zSqrArtSpecz591";

    localStorage.setItem(value30Save591, sQz591);
};

function square592(){

    var sQz592 = document.getElementById("imgSqrs592").src;

    value30Save592 = "zSqrArtSpecz592";

    localStorage.setItem(value30Save592, sQz592);
};

function square593(){

    var sQz593 = document.getElementById("imgSqrs593").src;

    value30Save593 = "zSqrArtSpecz593";

    localStorage.setItem(value30Save593, sQz593);
};

function square594(){

    var sQz594 = document.getElementById("imgSqrs594").src;

    value30Save594 = "zSqrArtSpecz594";

    localStorage.setItem(value30Save594, sQz594);
};

function square595(){

    var sQz595 = document.getElementById("imgSqrs595").src;

    value30Save595 = "zSqrArtSpecz595";

    localStorage.setItem(value30Save595, sQz595);
};

function square596(){

    var sQz596 = document.getElementById("imgSqrs596").src;

    value30Save596 = "zSqrArtSpecz596";

    localStorage.setItem(value30Save596, sQz596);
};

function square597(){

    var sQz597 = document.getElementById("imgSqrs597").src;

    value30Save597 = "zSqrArtSpecz597";

    localStorage.setItem(value30Save597, sQz597);
};

function square598(){

    var sQz598 = document.getElementById("imgSqrs598").src;

    value30Save598 = "zSqrArtSpecz598";

    localStorage.setItem(value30Save598, sQz598);
};

function square599(){

    var sQz599 = document.getElementById("imgSqrs599").src;

    value30Save599 = "zSqrArtSpecz599";

    localStorage.setItem(value30Save599, sQz599);
};

function square600(){

    var sQz600 = document.getElementById("imgSqrs600").src;

    value30Save600 = "zSqrArtSpecz600";

    localStorage.setItem(value30Save600, sQz600);
};

function square601(){

    var sQz601 = document.getElementById("imgSqrs601").src;

    value30Save601 = "zSqrArtSpecz601";

    localStorage.setItem(value30Save601, sQz601);
};

function square602(){

    var sQz602 = document.getElementById("imgSqrs602").src;

    value30Save602 = "zSqrArtSpecz602";

    localStorage.setItem(value30Save602, sQz602);
};

function square603(){

    var sQz603 = document.getElementById("imgSqrs603").src;

    value30Save603 = "zSqrArtSpecz603";

    localStorage.setItem(value30Save603, sQz603);
};

function square604(){

    var sQz604 = document.getElementById("imgSqrs604").src;

    value30Save604 = "zSqrArtSpecz604";

    localStorage.setItem(value30Save604, sQz604);
};

function square605(){

    var sQz605 = document.getElementById("imgSqrs605").src;

    value30Save605 = "zSqrArtSpecz605";

    localStorage.setItem(value30Save605, sQz605);
};

function square606(){

    var sQz606 = document.getElementById("imgSqrs606").src;

    value30Save606 = "zSqrArtSpecz606";

    localStorage.setItem(value30Save606, sQz606);
};

function square607(){

    var sQz607 = document.getElementById("imgSqrs607").src;

    value30Save607 = "zSqrArtSpecz607";

    localStorage.setItem(value30Save607, sQz607);
};

function square608(){

    var sQz608 = document.getElementById("imgSqrs608").src;

    value30Save608 = "zSqrArtSpecz608";

    localStorage.setItem(value30Save608, sQz608);
};

function square609(){

    var sQz609 = document.getElementById("imgSqrs609").src;

    value30Save609 = "zSqrArtSpecz609";

    localStorage.setItem(value30Save609, sQz609);
};

function square610(){

    var sQz610 = document.getElementById("imgSqrs610").src;

    value30Save610 = "zSqrArtSpecz610";

    localStorage.setItem(value30Save610, sQz610);
};

function square611(){

    var sQz611 = document.getElementById("imgSqrs611").src;

    value30Save611 = "zSqrArtSpecz611";

    localStorage.setItem(value30Save611, sQz611);
};

function square612(){

    var sQz612 = document.getElementById("imgSqrs612").src;

    value30Save612 = "zSqrArtSpecz612";

    localStorage.setItem(value30Save612, sQz612);
};

function square613(){

    var sQz613 = document.getElementById("imgSqrs613").src;

    value30Save613 = "zSqrArtSpecz613";

    localStorage.setItem(value30Save613, sQz613);
};

function square614(){

    var sQz614 = document.getElementById("imgSqrs614").src;

    value30Save614 = "zSqrArtSpecz614";

    localStorage.setItem(value30Save614, sQz614);
};

function square615(){

    var sQz615 = document.getElementById("imgSqrs615").src;

    value30Save615 = "zSqrArtSpecz615";

    localStorage.setItem(value30Save615, sQz615);
};

function square616(){

    var sQz616 = document.getElementById("imgSqrs616").src;

    value30Save616 = "zSqrArtSpecz616";

    localStorage.setItem(value30Save616, sQz616);
};

function square617(){

    var sQz617 = document.getElementById("imgSqrs617").src;

    value30Save617 = "zSqrArtSpecz617";

    localStorage.setItem(value30Save617, sQz617);
};

function square618(){

    var sQz618 = document.getElementById("imgSqrs618").src;

    value30Save618 = "zSqrArtSpecz618";

    localStorage.setItem(value30Save618, sQz618);
};

function square619(){

    var sQz619 = document.getElementById("imgSqrs619").src;

    value30Save619 = "zSqrArtSpecz619";

    localStorage.setItem(value30Save619, sQz619);
};

function square620(){

    var sQz620 = document.getElementById("imgSqrs620").src;

    value30Save620 = "zSqrArtSpecz620";

    localStorage.setItem(value30Save620, sQz620);
};

function square621(){

    var sQz621 = document.getElementById("imgSqrs621").src;

    value30Save621 = "zSqrArtSpecz621";

    localStorage.setItem(value30Save621, sQz621);
};

function square622(){

    var sQz622 = document.getElementById("imgSqrs622").src;

    value30Save622 = "zSqrArtSpecz622";

    localStorage.setItem(value30Save622, sQz622);
};

function square623(){

    var sQz623 = document.getElementById("imgSqrs623").src;

    value30Save623 = "zSqrArtSpecz623";

    localStorage.setItem(value30Save623, sQz623);
};

function square624(){

    var sQz624 = document.getElementById("imgSqrs624").src;

    value30Save624 = "zSqrArtSpecz624";

    localStorage.setItem(value30Save624, sQz624);
};

function square625(){

    var sQz625 = document.getElementById("imgSqrs625").src;

    value30Save625 = "zSqrArtSpecz625";

    localStorage.setItem(value30Save625, sQz625);
};

function square626(){

    var sQz626 = document.getElementById("imgSqrs626").src;

    value30Save626 = "zSqrArtSpecz626";

    localStorage.setItem(value30Save626, sQz626);
};

function square627(){

    var sQz627 = document.getElementById("imgSqrs627").src;

    value30Save627 = "zSqrArtSpecz627";

    localStorage.setItem(value30Save627, sQz627);
};

function square628(){

    var sQz628 = document.getElementById("imgSqrs628").src;

    value30Save628 = "zSqrArtSpecz628";

    localStorage.setItem(value30Save628, sQz628);
};

function square629(){

    var sQz629 = document.getElementById("imgSqrs629").src;

    value30Save629 = "zSqrArtSpecz629";

    localStorage.setItem(value30Save629, sQz629);
};

function square630(){

    var sQz630 = document.getElementById("imgSqrs630").src;

    value30Save630 = "zSqrArtSpecz630";

    localStorage.setItem(value30Save630, sQz630);
};

function square631(){

    var sQz631 = document.getElementById("imgSqrs631").src;

    value30Save631 = "zSqrArtSpecz631";

    localStorage.setItem(value30Save631, sQz631);
};

function square632(){

    var sQz632 = document.getElementById("imgSqrs632").src;

    value30Save632 = "zSqrArtSpecz632";

    localStorage.setItem(value30Save632, sQz632);
};

function square633(){

    var sQz633 = document.getElementById("imgSqrs633").src;

    value30Save633 = "zSqrArtSpecz633";

    localStorage.setItem(value30Save633, sQz633);
};

function square634(){

    var sQz634 = document.getElementById("imgSqrs634").src;

    value30Save634 = "zSqrArtSpecz634";

    localStorage.setItem(value30Save634, sQz634);
};

function square635(){

    var sQz635 = document.getElementById("imgSqrs635").src;

    value30Save635 = "zSqrArtSpecz635";

    localStorage.setItem(value30Save635, sQz635);
};

function square636(){

    var sQz636 = document.getElementById("imgSqrs636").src;

    value30Save636 = "zSqrArtSpecz636";

    localStorage.setItem(value30Save636, sQz636);
};

function square637(){

    var sQz637 = document.getElementById("imgSqrs637").src;

    value30Save637 = "zSqrArtSpecz637";

    localStorage.setItem(value30Save637, sQz637);
};

function square638(){

    var sQz638 = document.getElementById("imgSqrs638").src;

    value30Save638 = "zSqrArtSpecz638";

    localStorage.setItem(value30Save638, sQz638);
};

function square639(){

    var sQz639 = document.getElementById("imgSqrs639").src;

    value30Save639 = "zSqrArtSpecz639";

    localStorage.setItem(value30Save639, sQz639);
};

function square640(){

    var sQz640 = document.getElementById("imgSqrs640").src;

    value30Save640 = "zSqrArtSpecz640";

    localStorage.setItem(value30Save640, sQz640);
};

function square641(){

    var sQz641 = document.getElementById("imgSqrs641").src;

    value30Save641 = "zSqrArtSpecz641";

    localStorage.setItem(value30Save641, sQz641);
};

function square642(){

    var sQz642 = document.getElementById("imgSqrs642").src;

    value30Save642 = "zSqrArtSpecz642";

    localStorage.setItem(value30Save642, sQz642);
};

function square643(){

    var sQz643 = document.getElementById("imgSqrs643").src;

    value30Save643 = "zSqrArtSpecz643";

    localStorage.setItem(value30Save643, sQz643);
};

function square644(){

    var sQz644 = document.getElementById("imgSqrs644").src;

    value30Save644 = "zSqrArtSpecz644";

    localStorage.setItem(value30Save644, sQz644);
};

function square645(){

    var sQz645 = document.getElementById("imgSqrs645").src;

    value30Save645 = "zSqrArtSpecz645";

    localStorage.setItem(value30Save645, sQz645);
};

function square646(){

    var sQz646 = document.getElementById("imgSqrs646").src;

    value30Save646 = "zSqrArtSpecz646";

    localStorage.setItem(value30Save646, sQz646);
};

function square647(){

    var sQz647 = document.getElementById("imgSqrs647").src;

    value30Save647 = "zSqrArtSpecz647";

    localStorage.setItem(value30Save647, sQz647);
};

function square648(){

    var sQz648 = document.getElementById("imgSqrs648").src;

    value30Save648 = "zSqrArtSpecz648";

    localStorage.setItem(value30Save648, sQz648);
};

function square649(){

    var sQz649 = document.getElementById("imgSqrs649").src;

    value30Save649 = "zSqrArtSpecz649";

    localStorage.setItem(value30Save649, sQz649);
};

function square650(){

    var sQz650 = document.getElementById("imgSqrs650").src;

    value30Save650 = "zSqrArtSpecz650";

    localStorage.setItem(value30Save650, sQz650);
};

function square651(){

    var sQz651 = document.getElementById("imgSqrs651").src;

    value30Save651 = "zSqrArtSpecz651";

    localStorage.setItem(value30Save651, sQz651);
};

function square652(){

    var sQz652 = document.getElementById("imgSqrs652").src;

    value30Save652 = "zSqrArtSpecz652";

    localStorage.setItem(value30Save652, sQz652);
};

function square653(){

    var sQz653 = document.getElementById("imgSqrs653").src;

    value30Save653 = "zSqrArtSpecz653";

    localStorage.setItem(value30Save653, sQz653);
};

function square654(){

    var sQz654 = document.getElementById("imgSqrs654").src;

    value30Save654 = "zSqrArtSpecz654";

    localStorage.setItem(value30Save654, sQz654);
};

function square655(){

    var sQz655 = document.getElementById("imgSqrs655").src;

    value30Save655 = "zSqrArtSpecz655";

    localStorage.setItem(value30Save655, sQz655);
};

function square656(){

    var sQz656 = document.getElementById("imgSqrs656").src;

    value30Save656 = "zSqrArtSpecz656";

    localStorage.setItem(value30Save656, sQz656);
};

function square657(){

    var sQz657 = document.getElementById("imgSqrs657").src;

    value30Save657 = "zSqrArtSpecz657";

    localStorage.setItem(value30Save657, sQz657);
};

function square658(){

    var sQz658 = document.getElementById("imgSqrs658").src;

    value30Save658 = "zSqrArtSpecz658";

    localStorage.setItem(value30Save658, sQz658);
};

function square659(){

    var sQz659 = document.getElementById("imgSqrs659").src;

    value30Save659 = "zSqrArtSpecz659";

    localStorage.setItem(value30Save659, sQz659);
};

function square660(){

    var sQz660 = document.getElementById("imgSqrs660").src;

    value30Save660 = "zSqrArtSpecz660";

    localStorage.setItem(value30Save660, sQz660);
};

function square661(){

    var sQz661 = document.getElementById("imgSqrs661").src;

    value30Save661 = "zSqrArtSpecz661";

    localStorage.setItem(value30Save661, sQz661);
};

function square662(){

    var sQz662 = document.getElementById("imgSqrs662").src;

    value30Save662 = "zSqrArtSpecz662";

    localStorage.setItem(value30Save662, sQz662);
};

function square663(){

    var sQz663 = document.getElementById("imgSqrs663").src;

    value30Save663 = "zSqrArtSpecz663";

    localStorage.setItem(value30Save663, sQz663);
};

function square664(){

    var sQz664 = document.getElementById("imgSqrs664").src;

    value30Save664 = "zSqrArtSpecz664";

    localStorage.setItem(value30Save664, sQz664);
};

function square665(){

    var sQz665 = document.getElementById("imgSqrs665").src;

    value30Save665 = "zSqrArtSpecz665";

    localStorage.setItem(value30Save665, sQz665);
};

function square666(){

    var sQz666 = document.getElementById("imgSqrs666").src;

    value30Save666 = "zSqrArtSpecz666";

    localStorage.setItem(value30Save666, sQz666);
};

function square667(){

    var sQz667 = document.getElementById("imgSqrs667").src;

    value30Save667 = "zSqrArtSpecz667";

    localStorage.setItem(value30Save667, sQz667);
};

function square668(){

    var sQz668 = document.getElementById("imgSqrs668").src;

    value30Save668 = "zSqrArtSpecz668";

    localStorage.setItem(value30Save668, sQz668);
};

function square669(){

    var sQz669 = document.getElementById("imgSqrs669").src;

    value30Save669 = "zSqrArtSpecz669";

    localStorage.setItem(value30Save669, sQz669);
};

function square670(){

    var sQz670 = document.getElementById("imgSqrs670").src;

    value30Save670 = "zSqrArtSpecz670";

    localStorage.setItem(value30Save670, sQz670);
};

function square671(){

    var sQz671 = document.getElementById("imgSqrs671").src;

    value30Save671 = "zSqrArtSpecz671";

    localStorage.setItem(value30Save671, sQz671);
};

function square672(){

    var sQz672 = document.getElementById("imgSqrs672").src;

    value30Save672 = "zSqrArtSpecz672";

    localStorage.setItem(value30Save672, sQz672);
};

function square673(){

    var sQz673 = document.getElementById("imgSqrs673").src;

    value30Save673 = "zSqrArtSpecz673";

    localStorage.setItem(value30Save673, sQz673);
};

function square674(){

    var sQz674 = document.getElementById("imgSqrs674").src;

    value30Save674 = "zSqrArtSpecz674";

    localStorage.setItem(value30Save674, sQz674);
};

function square675(){

    var sQz675 = document.getElementById("imgSqrs675").src;

    value30Save675 = "zSqrArtSpecz675";

    localStorage.setItem(value30Save675, sQz675);
};

function square676(){

    var sQz676 = document.getElementById("imgSqrs676").src;

    value30Save676 = "zSqrArtSpecz676";

    localStorage.setItem(value30Save676, sQz676);
};

function square677(){

    var sQz677 = document.getElementById("imgSqrs677").src;

    value30Save677 = "zSqrArtSpecz677";

    localStorage.setItem(value30Save677, sQz677);
};

function square678(){

    var sQz678 = document.getElementById("imgSqrs678").src;

    value30Save678 = "zSqrArtSpecz678";

    localStorage.setItem(value30Save678, sQz678);
};

function square679(){

    var sQz679 = document.getElementById("imgSqrs679").src;

    value30Save679 = "zSqrArtSpecz679";

    localStorage.setItem(value30Save679, sQz679);
};

function square680(){

    var sQz680 = document.getElementById("imgSqrs680").src;

    value30Save680 = "zSqrArtSpecz680";

    localStorage.setItem(value30Save680, sQz680);
};

function square681(){

    var sQz681 = document.getElementById("imgSqrs681").src;

    value30Save681 = "zSqrArtSpecz681";

    localStorage.setItem(value30Save681, sQz681);
};

function square682(){

    var sQz682 = document.getElementById("imgSqrs682").src;

    value30Save682 = "zSqrArtSpecz682";

    localStorage.setItem(value30Save682, sQz682);
};

function square683(){

    var sQz683 = document.getElementById("imgSqrs683").src;

    value30Save683 = "zSqrArtSpecz683";

    localStorage.setItem(value30Save683, sQz683);
};

function square684(){

    var sQz684 = document.getElementById("imgSqrs684").src;

    value30Save684 = "zSqrArtSpecz684";

    localStorage.setItem(value30Save684, sQz684);
};

function square685(){

    var sQz685 = document.getElementById("imgSqrs685").src;

    value30Save685 = "zSqrArtSpecz685";

    localStorage.setItem(value30Save685, sQz685);
};

function square686(){

    var sQz686 = document.getElementById("imgSqrs686").src;

    value30Save686 = "zSqrArtSpecz686";

    localStorage.setItem(value30Save686, sQz686);
};

function square687(){

    var sQz687 = document.getElementById("imgSqrs687").src;

    value30Save687 = "zSqrArtSpecz687";

    localStorage.setItem(value30Save687, sQz687);
};

function square688(){

    var sQz688 = document.getElementById("imgSqrs688").src;

    value30Save688 = "zSqrArtSpecz688";

    localStorage.setItem(value30Save688, sQz688);
};

function square689(){

    var sQz689 = document.getElementById("imgSqrs689").src;

    value30Save689 = "zSqrArtSpecz689";

    localStorage.setItem(value30Save689, sQz689);
};

function square690(){

    var sQz690 = document.getElementById("imgSqrs690").src;

    value30Save690 = "zSqrArtSpecz690";

    localStorage.setItem(value30Save690, sQz690);
};

function square691(){

    var sQz691 = document.getElementById("imgSqrs691").src;

    value30Save691 = "zSqrArtSpecz691";

    localStorage.setItem(value30Save691, sQz691);
};

function square692(){

    var sQz692 = document.getElementById("imgSqrs692").src;

    value30Save692 = "zSqrArtSpecz692";

    localStorage.setItem(value30Save692, sQz692);
};

function square693(){

    var sQz693 = document.getElementById("imgSqrs693").src;

    value30Save693 = "zSqrArtSpecz693";

    localStorage.setItem(value30Save693, sQz693);
};

function square694(){

    var sQz694 = document.getElementById("imgSqrs694").src;

    value30Save694 = "zSqrArtSpecz694";

    localStorage.setItem(value30Save694, sQz694);
};

function square695(){

    var sQz695 = document.getElementById("imgSqrs695").src;

    value30Save695 = "zSqrArtSpecz695";

    localStorage.setItem(value30Save695, sQz695);
};

function square696(){

    var sQz696 = document.getElementById("imgSqrs696").src;

    value30Save696 = "zSqrArtSpecz696";

    localStorage.setItem(value30Save696, sQz696);
};

function square697(){

    var sQz697 = document.getElementById("imgSqrs697").src;

    value30Save697 = "zSqrArtSpecz697";

    localStorage.setItem(value30Save697, sQz697);
};

function square698(){

    var sQz698 = document.getElementById("imgSqrs698").src;

    value30Save698 = "zSqrArtSpecz698";

    localStorage.setItem(value30Save698, sQz698);
};

function square699(){

    var sQz699 = document.getElementById("imgSqrs699").src;

    value30Save699 = "zSqrArtSpecz699";

    localStorage.setItem(value30Save699, sQz699);
};

function square700(){

    var sQz700 = document.getElementById("imgSqrs700").src;

    value30Save700 = "zSqrArtSpecz700";

    localStorage.setItem(value30Save700, sQz700);
};

function square701(){

    var sQz701 = document.getElementById("imgSqrs701").src;

    value30Save701 = "zSqrArtSpecz701";

    localStorage.setItem(value30Save701, sQz701);
};

function square702(){

    var sQz702 = document.getElementById("imgSqrs702").src;

    value30Save702 = "zSqrArtSpecz702";

    localStorage.setItem(value30Save702, sQz702);
};

function square703(){

    var sQz703 = document.getElementById("imgSqrs703").src;

    value30Save703 = "zSqrArtSpecz703";

    localStorage.setItem(value30Save703, sQz703);
};

function square704(){

    var sQz704 = document.getElementById("imgSqrs704").src;

    value30Save704 = "zSqrArtSpecz704";

    localStorage.setItem(value30Save704, sQz704);
};

function square705(){

    var sQz705 = document.getElementById("imgSqrs705").src;

    value30Save705 = "zSqrArtSpecz705";

    localStorage.setItem(value30Save705, sQz705);
};

function square706(){

    var sQz706 = document.getElementById("imgSqrs706").src;

    value30Save706 = "zSqrArtSpecz706";

    localStorage.setItem(value30Save706, sQz706);
};

function square707(){

    var sQz707 = document.getElementById("imgSqrs707").src;

    value30Save707 = "zSqrArtSpecz707";

    localStorage.setItem(value30Save707, sQz707);
};

function square708(){

    var sQz708 = document.getElementById("imgSqrs708").src;

    value30Save708 = "zSqrArtSpecz708";

    localStorage.setItem(value30Save708, sQz708);
};

function square709(){

    var sQz709 = document.getElementById("imgSqrs709").src;

    value30Save709 = "zSqrArtSpecz709";

    localStorage.setItem(value30Save709, sQz709);
};

function square710(){

    var sQz710 = document.getElementById("imgSqrs710").src;

    value30Save710 = "zSqrArtSpecz710";

    localStorage.setItem(value30Save710, sQz710);
};

function square711(){

    var sQz711 = document.getElementById("imgSqrs711").src;

    value30Save711 = "zSqrArtSpecz711";

    localStorage.setItem(value30Save711, sQz711);
};

function square712(){

    var sQz712 = document.getElementById("imgSqrs712").src;

    value30Save712 = "zSqrArtSpecz712";

    localStorage.setItem(value30Save712, sQz712);
};

function square713(){

    var sQz713 = document.getElementById("imgSqrs713").src;

    value30Save713 = "zSqrArtSpecz713";

    localStorage.setItem(value30Save713, sQz713);
};

function square714(){

    var sQz714 = document.getElementById("imgSqrs714").src;

    value30Save714 = "zSqrArtSpecz714";

    localStorage.setItem(value30Save714, sQz714);
};

function square715(){

    var sQz715 = document.getElementById("imgSqrs715").src;

    value30Save715 = "zSqrArtSpecz715";

    localStorage.setItem(value30Save715, sQz715);
};

function square716(){

    var sQz716 = document.getElementById("imgSqrs716").src;

    value30Save716 = "zSqrArtSpecz716";

    localStorage.setItem(value30Save716, sQz716);
};

function square717(){

    var sQz717 = document.getElementById("imgSqrs717").src;

    value30Save717 = "zSqrArtSpecz717";

    localStorage.setItem(value30Save717, sQz717);
};

function square718(){

    var sQz718 = document.getElementById("imgSqrs718").src;

    value30Save718 = "zSqrArtSpecz718";

    localStorage.setItem(value30Save718, sQz718);
};

function square719(){

    var sQz719 = document.getElementById("imgSqrs719").src;

    value30Save719 = "zSqrArtSpecz719";

    localStorage.setItem(value30Save719, sQz719);
};

function square720(){

    var sQz720 = document.getElementById("imgSqrs720").src;

    value30Save720 = "zSqrArtSpecz720";

    localStorage.setItem(value30Save720, sQz720);
};

function square721(){

    var sQz721 = document.getElementById("imgSqrs721").src;

    value30Save721 = "zSqrArtSpecz721";

    localStorage.setItem(value30Save721, sQz721);
};

function square722(){

    var sQz722 = document.getElementById("imgSqrs722").src;

    value30Save722 = "zSqrArtSpecz722";

    localStorage.setItem(value30Save722, sQz722);
};

function square723(){

    var sQz723 = document.getElementById("imgSqrs723").src;

    value30Save723 = "zSqrArtSpecz723";

    localStorage.setItem(value30Save723, sQz723);
};

function square724(){

    var sQz724 = document.getElementById("imgSqrs724").src;

    value30Save724 = "zSqrArtSpecz724";

    localStorage.setItem(value30Save724, sQz724);
};

function square725(){

    var sQz725 = document.getElementById("imgSqrs725").src;

    value30Save725 = "zSqrArtSpecz725";

    localStorage.setItem(value30Save725, sQz725);
};

function square726(){

    var sQz726 = document.getElementById("imgSqrs726").src;

    value30Save726 = "zSqrArtSpecz726";

    localStorage.setItem(value30Save726, sQz726);
};

function square727(){

    var sQz727 = document.getElementById("imgSqrs727").src;

    value30Save727 = "zSqrArtSpecz727";

    localStorage.setItem(value30Save727, sQz727);
};

function square728(){

    var sQz728 = document.getElementById("imgSqrs728").src;

    value30Save728 = "zSqrArtSpecz728";

    localStorage.setItem(value30Save728, sQz728);
};

function square729(){

    var sQz729 = document.getElementById("imgSqrs729").src;

    value30Save729 = "zSqrArtSpecz729";

    localStorage.setItem(value30Save729, sQz729);
};

function square730(){

    var sQz730 = document.getElementById("imgSqrs730").src;

    value30Save730 = "zSqrArtSpecz730";

    localStorage.setItem(value30Save730, sQz730);
};

function square731(){

    var sQz731 = document.getElementById("imgSqrs731").src;

    value30Save731 = "zSqrArtSpecz731";

    localStorage.setItem(value30Save731, sQz731);
};

function square732(){

    var sQz732 = document.getElementById("imgSqrs732").src;

    value30Save732 = "zSqrArtSpecz732";

    localStorage.setItem(value30Save732, sQz732);
};

function square733(){

    var sQz733 = document.getElementById("imgSqrs733").src;

    value30Save733 = "zSqrArtSpecz733";

    localStorage.setItem(value30Save733, sQz733);
};

function square734(){

    var sQz734 = document.getElementById("imgSqrs734").src;

    value30Save734 = "zSqrArtSpecz734";

    localStorage.setItem(value30Save734, sQz734);
};

function square735(){

    var sQz735 = document.getElementById("imgSqrs735").src;

    value30Save735 = "zSqrArtSpecz735";

    localStorage.setItem(value30Save735, sQz735);
};

function square736(){

    var sQz736 = document.getElementById("imgSqrs736").src;

    value30Save736 = "zSqrArtSpecz736";

    localStorage.setItem(value30Save736, sQz736);
};

function square737(){

    var sQz737 = document.getElementById("imgSqrs737").src;

    value30Save737 = "zSqrArtSpecz737";

    localStorage.setItem(value30Save737, sQz737);
};

function square738(){

    var sQz738 = document.getElementById("imgSqrs738").src;

    value30Save738 = "zSqrArtSpecz738";

    localStorage.setItem(value30Save738, sQz738);
};

function square739(){

    var sQz739 = document.getElementById("imgSqrs739").src;

    value30Save739 = "zSqrArtSpecz739";

    localStorage.setItem(value30Save739, sQz739);
};

function square740(){

    var sQz740 = document.getElementById("imgSqrs740").src;

    value30Save740 = "zSqrArtSpecz740";

    localStorage.setItem(value30Save740, sQz740);
};

function square741(){

    var sQz741 = document.getElementById("imgSqrs741").src;

    value30Save741 = "zSqrArtSpecz741";

    localStorage.setItem(value30Save741, sQz741);
};

function square742(){

    var sQz742 = document.getElementById("imgSqrs742").src;

    value30Save742 = "zSqrArtSpecz742";

    localStorage.setItem(value30Save742, sQz742);
};

function square743(){

    var sQz743 = document.getElementById("imgSqrs743").src;

    value30Save743 = "zSqrArtSpecz743";

    localStorage.setItem(value30Save743, sQz743);
};

function square744(){

    var sQz744 = document.getElementById("imgSqrs744").src;

    value30Save744 = "zSqrArtSpecz744";

    localStorage.setItem(value30Save744, sQz744);
};

function square745(){

    var sQz745 = document.getElementById("imgSqrs745").src;

    value30Save745 = "zSqrArtSpecz745";

    localStorage.setItem(value30Save745, sQz745);
};

function square746(){

    var sQz746 = document.getElementById("imgSqrs746").src;

    value30Save746 = "zSqrArtSpecz746";

    localStorage.setItem(value30Save746, sQz746);
};

function square747(){

    var sQz747 = document.getElementById("imgSqrs747").src;

    value30Save747 = "zSqrArtSpecz747";

    localStorage.setItem(value30Save747, sQz747);
};

function square748(){

    var sQz748 = document.getElementById("imgSqrs748").src;

    value30Save748 = "zSqrArtSpecz748";

    localStorage.setItem(value30Save748, sQz748);
};

function square749(){

    var sQz749 = document.getElementById("imgSqrs749").src;

    value30Save749 = "zSqrArtSpecz749";

    localStorage.setItem(value30Save749, sQz749);
};

function square750(){

    var sQz750 = document.getElementById("imgSqrs750").src;

    value30Save750 = "zSqrArtSpecz750";

    localStorage.setItem(value30Save750, sQz750);
};

function square751(){

    var sQz751 = document.getElementById("imgSqrs751").src;

    value30Save751 = "zSqrArtSpecz751";

    localStorage.setItem(value30Save751, sQz751);
};

function square752(){

    var sQz752 = document.getElementById("imgSqrs752").src;

    value30Save752 = "zSqrArtSpecz752";

    localStorage.setItem(value30Save752, sQz752);
};

function square753(){

    var sQz753 = document.getElementById("imgSqrs753").src;

    value30Save753 = "zSqrArtSpecz753";

    localStorage.setItem(value30Save753, sQz753);
};

function square754(){

    var sQz754 = document.getElementById("imgSqrs754").src;

    value30Save754 = "zSqrArtSpecz754";

    localStorage.setItem(value30Save754, sQz754);
};

function square755(){

    var sQz755 = document.getElementById("imgSqrs755").src;

    value30Save755 = "zSqrArtSpecz755";

    localStorage.setItem(value30Save755, sQz755);
};

function square756(){

    var sQz756 = document.getElementById("imgSqrs756").src;

    value30Save756 = "zSqrArtSpecz756";

    localStorage.setItem(value30Save756, sQz756);
};

function square757(){

    var sQz757 = document.getElementById("imgSqrs757").src;

    value30Save757 = "zSqrArtSpecz757";

    localStorage.setItem(value30Save757, sQz757);
};

function square758(){

    var sQz758 = document.getElementById("imgSqrs758").src;

    value30Save758 = "zSqrArtSpecz758";

    localStorage.setItem(value30Save758, sQz758);
};

function square759(){

    var sQz759 = document.getElementById("imgSqrs759").src;

    value30Save759 = "zSqrArtSpecz759";

    localStorage.setItem(value30Save759, sQz759);
};

function square760(){

    var sQz760 = document.getElementById("imgSqrs760").src;

    value30Save760 = "zSqrArtSpecz760";

    localStorage.setItem(value30Save760, sQz760);
};

function square761(){

    var sQz761 = document.getElementById("imgSqrs761").src;

    value30Save761 = "zSqrArtSpecz761";

    localStorage.setItem(value30Save761, sQz761);
};

function square762(){

    var sQz762 = document.getElementById("imgSqrs762").src;

    value30Save762 = "zSqrArtSpecz762";

    localStorage.setItem(value30Save762, sQz762);
};

function square763(){

    var sQz763 = document.getElementById("imgSqrs763").src;

    value30Save763 = "zSqrArtSpecz763";

    localStorage.setItem(value30Save763, sQz763);
};

function square764(){

    var sQz764 = document.getElementById("imgSqrs764").src;

    value30Save764 = "zSqrArtSpecz764";

    localStorage.setItem(value30Save764, sQz764);
};

function square765(){

    var sQz765 = document.getElementById("imgSqrs765").src;

    value30Save765 = "zSqrArtSpecz765";

    localStorage.setItem(value30Save765, sQz765);
};

function square766(){

    var sQz766 = document.getElementById("imgSqrs766").src;

    value30Save766 = "zSqrArtSpecz766";

    localStorage.setItem(value30Save766, sQz766);
};

function square767(){

    var sQz767 = document.getElementById("imgSqrs767").src;

    value30Save767 = "zSqrArtSpecz767";

    localStorage.setItem(value30Save767, sQz767);
};

function square768(){

    var sQz768 = document.getElementById("imgSqrs768").src;

    value30Save768 = "zSqrArtSpecz768";

    localStorage.setItem(value30Save768, sQz768);
};

function square769(){

    var sQz769 = document.getElementById("imgSqrs769").src;

    value30Save769 = "zSqrArtSpecz769";

    localStorage.setItem(value30Save769, sQz769);
};

function square770(){

    var sQz770 = document.getElementById("imgSqrs770").src;

    value30Save770 = "zSqrArtSpecz770";

    localStorage.setItem(value30Save770, sQz770);
};

function square771(){

    var sQz771 = document.getElementById("imgSqrs771").src;

    value30Save771 = "zSqrArtSpecz771";

    localStorage.setItem(value30Save771, sQz771);
};

function square772(){

    var sQz772 = document.getElementById("imgSqrs772").src;

    value30Save772 = "zSqrArtSpecz772";

    localStorage.setItem(value30Save772, sQz772);
};

function square773(){

    var sQz773 = document.getElementById("imgSqrs773").src;

    value30Save773 = "zSqrArtSpecz773";

    localStorage.setItem(value30Save773, sQz773);
};

function square774(){

    var sQz774 = document.getElementById("imgSqrs774").src;

    value30Save774 = "zSqrArtSpecz774";

    localStorage.setItem(value30Save774, sQz774);
};

function square775(){

    var sQz775 = document.getElementById("imgSqrs775").src;

    value30Save775 = "zSqrArtSpecz775";

    localStorage.setItem(value30Save775, sQz775);
};

function square776(){

    var sQz776 = document.getElementById("imgSqrs776").src;

    value30Save776 = "zSqrArtSpecz776";

    localStorage.setItem(value30Save776, sQz776);
};

function square777(){

    var sQz777 = document.getElementById("imgSqrs777").src;

    value30Save777 = "zSqrArtSpecz777";

    localStorage.setItem(value30Save777, sQz777);
};

function square778(){

    var sQz778 = document.getElementById("imgSqrs778").src;

    value30Save778 = "zSqrArtSpecz778";

    localStorage.setItem(value30Save778, sQz778);
};

function square779(){

    var sQz779 = document.getElementById("imgSqrs779").src;

    value30Save779 = "zSqrArtSpecz779";

    localStorage.setItem(value30Save779, sQz779);
};

function square780(){

    var sQz780 = document.getElementById("imgSqrs780").src;

    value30Save780 = "zSqrArtSpecz780";

    localStorage.setItem(value30Save780, sQz780);
};

function square781(){

    var sQz781 = document.getElementById("imgSqrs781").src;

    value30Save781 = "zSqrArtSpecz781";

    localStorage.setItem(value30Save781, sQz781);
};

function square782(){

    var sQz782 = document.getElementById("imgSqrs782").src;

    value30Save782 = "zSqrArtSpecz782";

    localStorage.setItem(value30Save782, sQz782);
};

function square783(){

    var sQz783 = document.getElementById("imgSqrs783").src;

    value30Save783 = "zSqrArtSpecz783";

    localStorage.setItem(value30Save783, sQz783);
};

function square784(){

    var sQz784 = document.getElementById("imgSqrs784").src;

    value30Save784 = "zSqrArtSpecz784";

    localStorage.setItem(value30Save784, sQz784);
};

function square785(){

    var sQz785 = document.getElementById("imgSqrs785").src;

    value30Save785 = "zSqrArtSpecz785";

    localStorage.setItem(value30Save785, sQz785);
};

function square786(){

    var sQz786 = document.getElementById("imgSqrs786").src;

    value30Save786 = "zSqrArtSpecz786";

    localStorage.setItem(value30Save786, sQz786);
};

function square787(){

    var sQz787 = document.getElementById("imgSqrs787").src;

    value30Save787 = "zSqrArtSpecz787";

    localStorage.setItem(value30Save787, sQz787);
};

function square788(){

    var sQz788 = document.getElementById("imgSqrs788").src;

    value30Save788 = "zSqrArtSpecz788";

    localStorage.setItem(value30Save788, sQz788);
};

function square789(){

    var sQz789 = document.getElementById("imgSqrs789").src;

    value30Save789 = "zSqrArtSpecz789";

    localStorage.setItem(value30Save789, sQz789);
};

function square790(){

    var sQz790 = document.getElementById("imgSqrs790").src;

    value30Save790 = "zSqrArtSpecz790";

    localStorage.setItem(value30Save790, sQz790);
};

function square791(){

    var sQz791 = document.getElementById("imgSqrs791").src;

    value30Save791 = "zSqrArtSpecz791";

    localStorage.setItem(value30Save791, sQz791);
};

function square792(){

    var sQz792 = document.getElementById("imgSqrs792").src;

    value30Save792 = "zSqrArtSpecz792";

    localStorage.setItem(value30Save792, sQz792);
};

function square793(){

    var sQz793 = document.getElementById("imgSqrs793").src;

    value30Save793 = "zSqrArtSpecz793";

    localStorage.setItem(value30Save793, sQz793);
};

function square794(){

    var sQz794 = document.getElementById("imgSqrs794").src;

    value30Save794 = "zSqrArtSpecz794";

    localStorage.setItem(value30Save794, sQz794);
};

function square795(){

    var sQz795 = document.getElementById("imgSqrs795").src;

    value30Save795 = "zSqrArtSpecz795";

    localStorage.setItem(value30Save795, sQz795);
};

function square796(){

    var sQz796 = document.getElementById("imgSqrs796").src;

    value30Save796 = "zSqrArtSpecz796";

    localStorage.setItem(value30Save796, sQz796);
};

function square797(){

    var sQz797 = document.getElementById("imgSqrs797").src;

    value30Save797 = "zSqrArtSpecz797";

    localStorage.setItem(value30Save797, sQz797);
};

function square798(){

    var sQz798 = document.getElementById("imgSqrs798").src;

    value30Save798 = "zSqrArtSpecz798";

    localStorage.setItem(value30Save798, sQz798);
};

function square799(){

    var sQz799 = document.getElementById("imgSqrs799").src;

    value30Save799 = "zSqrArtSpecz799";

    localStorage.setItem(value30Save799, sQz799);
};

function square800(){

    var sQz800 = document.getElementById("imgSqrs800").src;

    value30Save800 = "zSqrArtSpecz800";

    localStorage.setItem(value30Save800, sQz800);
};

function square801(){

    var sQz801 = document.getElementById("imgSqrs801").src;

    value30Save801 = "zSqrArtSpecz801";

    localStorage.setItem(value30Save801, sQz801);
};

function square802(){

    var sQz802 = document.getElementById("imgSqrs802").src;

    value30Save802 = "zSqrArtSpecz802";

    localStorage.setItem(value30Save802, sQz802);
};

function square803(){

    var sQz803 = document.getElementById("imgSqrs803").src;

    value30Save803 = "zSqrArtSpecz803";

    localStorage.setItem(value30Save803, sQz803);
};

function square804(){

    var sQz804 = document.getElementById("imgSqrs804").src;

    value30Save804 = "zSqrArtSpecz804";

    localStorage.setItem(value30Save804, sQz804);
};

function square805(){

    var sQz805 = document.getElementById("imgSqrs805").src;

    value30Save805 = "zSqrArtSpecz805";

    localStorage.setItem(value30Save805, sQz805);
};

function square806(){

    var sQz806 = document.getElementById("imgSqrs806").src;

    value30Save806 = "zSqrArtSpecz806";

    localStorage.setItem(value30Save806, sQz806);
};

function square807(){

    var sQz807 = document.getElementById("imgSqrs807").src;

    value30Save807 = "zSqrArtSpecz807";

    localStorage.setItem(value30Save807, sQz807);
};

function square808(){

    var sQz808 = document.getElementById("imgSqrs808").src;

    value30Save808 = "zSqrArtSpecz808";

    localStorage.setItem(value30Save808, sQz808);
};

function square809(){

    var sQz809 = document.getElementById("imgSqrs809").src;

    value30Save809 = "zSqrArtSpecz809";

    localStorage.setItem(value30Save809, sQz809);
};

function square810(){

    var sQz810 = document.getElementById("imgSqrs810").src;

    value30Save810 = "zSqrArtSpecz810";

    localStorage.setItem(value30Save810, sQz810);
};

function square811(){

    var sQz811 = document.getElementById("imgSqrs811").src;

    value30Save811 = "zSqrArtSpecz811";

    localStorage.setItem(value30Save811, sQz811);
};

function square812(){

    var sQz812 = document.getElementById("imgSqrs812").src;

    value30Save812 = "zSqrArtSpecz812";

    localStorage.setItem(value30Save812, sQz812);
};

function square813(){

    var sQz813 = document.getElementById("imgSqrs813").src;

    value30Save813 = "zSqrArtSpecz813";

    localStorage.setItem(value30Save813, sQz813);
};

function square814(){

    var sQz814 = document.getElementById("imgSqrs814").src;

    value30Save814 = "zSqrArtSpecz814";

    localStorage.setItem(value30Save814, sQz814);
};

function square815(){

    var sQz815 = document.getElementById("imgSqrs815").src;

    value30Save815 = "zSqrArtSpecz815";

    localStorage.setItem(value30Save815, sQz815);
};

function square816(){

    var sQz816 = document.getElementById("imgSqrs816").src;

    value30Save816 = "zSqrArtSpecz816";

    localStorage.setItem(value30Save816, sQz816);
};

function square817(){

    var sQz817 = document.getElementById("imgSqrs817").src;

    value30Save817 = "zSqrArtSpecz817";

    localStorage.setItem(value30Save817, sQz817);
};

function square818(){

    var sQz818 = document.getElementById("imgSqrs818").src;

    value30Save818 = "zSqrArtSpecz818";

    localStorage.setItem(value30Save818, sQz818);
};

function square819(){

    var sQz819 = document.getElementById("imgSqrs819").src;

    value30Save819 = "zSqrArtSpecz819";

    localStorage.setItem(value30Save819, sQz819);
};

function square820(){

    var sQz820 = document.getElementById("imgSqrs820").src;

    value30Save820 = "zSqrArtSpecz820";

    localStorage.setItem(value30Save820, sQz820);
};

function square821(){

    var sQz821 = document.getElementById("imgSqrs821").src;

    value30Save821 = "zSqrArtSpecz821";

    localStorage.setItem(value30Save821, sQz821);
};

function square822(){

    var sQz822 = document.getElementById("imgSqrs822").src;

    value30Save822 = "zSqrArtSpecz822";

    localStorage.setItem(value30Save822, sQz822);
};

function square823(){

    var sQz823 = document.getElementById("imgSqrs823").src;

    value30Save823 = "zSqrArtSpecz823";

    localStorage.setItem(value30Save823, sQz823);
};

function square824(){

    var sQz824 = document.getElementById("imgSqrs824").src;

    value30Save824 = "zSqrArtSpecz824";

    localStorage.setItem(value30Save824, sQz824);
};

function square825(){

    var sQz825 = document.getElementById("imgSqrs825").src;

    value30Save825 = "zSqrArtSpecz825";

    localStorage.setItem(value30Save825, sQz825);
};

function square826(){

    var sQz826 = document.getElementById("imgSqrs826").src;

    value30Save826 = "zSqrArtSpecz826";

    localStorage.setItem(value30Save826, sQz826);
};

function square827(){

    var sQz827 = document.getElementById("imgSqrs827").src;

    value30Save827 = "zSqrArtSpecz827";

    localStorage.setItem(value30Save827, sQz827);
};

function square828(){

    var sQz828 = document.getElementById("imgSqrs828").src;

    value30Save828 = "zSqrArtSpecz828";

    localStorage.setItem(value30Save828, sQz828);
};

function square829(){

    var sQz829 = document.getElementById("imgSqrs829").src;

    value30Save829 = "zSqrArtSpecz829";

    localStorage.setItem(value30Save829, sQz829);
};

function square830(){

    var sQz830 = document.getElementById("imgSqrs830").src;

    value30Save830 = "zSqrArtSpecz830";

    localStorage.setItem(value30Save830, sQz830);
};

function square831(){

    var sQz831 = document.getElementById("imgSqrs831").src;

    value30Save831 = "zSqrArtSpecz831";

    localStorage.setItem(value30Save831, sQz831);
};

function square832(){

    var sQz832 = document.getElementById("imgSqrs832").src;

    value30Save832 = "zSqrArtSpecz832";

    localStorage.setItem(value30Save832, sQz832);
};

function square833(){

    var sQz833 = document.getElementById("imgSqrs833").src;

    value30Save833 = "zSqrArtSpecz833";

    localStorage.setItem(value30Save833, sQz833);
};

function square834(){

    var sQz834 = document.getElementById("imgSqrs834").src;

    value30Save834 = "zSqrArtSpecz834";

    localStorage.setItem(value30Save834, sQz834);
};

function square835(){

    var sQz835 = document.getElementById("imgSqrs835").src;

    value30Save835 = "zSqrArtSpecz835";

    localStorage.setItem(value30Save835, sQz835);
};

function square836(){

    var sQz836 = document.getElementById("imgSqrs836").src;

    value30Save836 = "zSqrArtSpecz836";

    localStorage.setItem(value30Save836, sQz836);
};

function square837(){

    var sQz837 = document.getElementById("imgSqrs837").src;

    value30Save837 = "zSqrArtSpecz837";

    localStorage.setItem(value30Save837, sQz837);
};

function square838(){

    var sQz838 = document.getElementById("imgSqrs838").src;

    value30Save838 = "zSqrArtSpecz838";

    localStorage.setItem(value30Save838, sQz838);
};

function square839(){

    var sQz839 = document.getElementById("imgSqrs839").src;

    value30Save839 = "zSqrArtSpecz839";

    localStorage.setItem(value30Save839, sQz839);
};

function square840(){

    var sQz840 = document.getElementById("imgSqrs840").src;

    value30Save840 = "zSqrArtSpecz840";

    localStorage.setItem(value30Save840, sQz840);
};

function square841(){

    var sQz841 = document.getElementById("imgSqrs841").src;

    value30Save841 = "zSqrArtSpecz841";

    localStorage.setItem(value30Save841, sQz841);
};

function square842(){

    var sQz842 = document.getElementById("imgSqrs842").src;

    value30Save842 = "zSqrArtSpecz842";

    localStorage.setItem(value30Save842, sQz842);
};

function square843(){

    var sQz843 = document.getElementById("imgSqrs843").src;

    value30Save843 = "zSqrArtSpecz843";

    localStorage.setItem(value30Save843, sQz843);
};

function square844(){

    var sQz844 = document.getElementById("imgSqrs844").src;

    value30Save844 = "zSqrArtSpecz844";

    localStorage.setItem(value30Save844, sQz844);
};

function square845(){

    var sQz845 = document.getElementById("imgSqrs845").src;

    value30Save845 = "zSqrArtSpecz845";

    localStorage.setItem(value30Save845, sQz845);
};

function square846(){

    var sQz846 = document.getElementById("imgSqrs846").src;

    value30Save846 = "zSqrArtSpecz846";

    localStorage.setItem(value30Save846, sQz846);
};

function square847(){

    var sQz847 = document.getElementById("imgSqrs847").src;

    value30Save847 = "zSqrArtSpecz847";

    localStorage.setItem(value30Save847, sQz847);
};

function square848(){

    var sQz848 = document.getElementById("imgSqrs848").src;

    value30Save848 = "zSqrArtSpecz848";

    localStorage.setItem(value30Save848, sQz848);
};

function square849(){

    var sQz849 = document.getElementById("imgSqrs849").src;

    value30Save849 = "zSqrArtSpecz849";

    localStorage.setItem(value30Save849, sQz849);
};

function square850(){

    var sQz850 = document.getElementById("imgSqrs850").src;

    value30Save850 = "zSqrArtSpecz850";

    localStorage.setItem(value30Save850, sQz850);
};

function square851(){

    var sQz851 = document.getElementById("imgSqrs851").src;

    value30Save851 = "zSqrArtSpecz851";

    localStorage.setItem(value30Save851, sQz851);
};

function square852(){

    var sQz852 = document.getElementById("imgSqrs852").src;

    value30Save852 = "zSqrArtSpecz852";

    localStorage.setItem(value30Save852, sQz852);
};

function square853(){

    var sQz853 = document.getElementById("imgSqrs853").src;

    value30Save853 = "zSqrArtSpecz853";

    localStorage.setItem(value30Save853, sQz853);
};

function square854(){

    var sQz854 = document.getElementById("imgSqrs854").src;

    value30Save854 = "zSqrArtSpecz854";

    localStorage.setItem(value30Save854, sQz854);
};

function square855(){

    var sQz855 = document.getElementById("imgSqrs855").src;

    value30Save855 = "zSqrArtSpecz855";

    localStorage.setItem(value30Save855, sQz855);
};

function square856(){

    var sQz856 = document.getElementById("imgSqrs856").src;

    value30Save856 = "zSqrArtSpecz856";

    localStorage.setItem(value30Save856, sQz856);
};

function square857(){

    var sQz857 = document.getElementById("imgSqrs857").src;

    value30Save857 = "zSqrArtSpecz857";

    localStorage.setItem(value30Save857, sQz857);
};

function square858(){

    var sQz858 = document.getElementById("imgSqrs858").src;

    value30Save858 = "zSqrArtSpecz858";

    localStorage.setItem(value30Save858, sQz858);
};

function square859(){

    var sQz859 = document.getElementById("imgSqrs859").src;

    value30Save859 = "zSqrArtSpecz859";

    localStorage.setItem(value30Save859, sQz859);
};

function square860(){

    var sQz860 = document.getElementById("imgSqrs860").src;

    value30Save860 = "zSqrArtSpecz860";

    localStorage.setItem(value30Save860, sQz860);
};

function square861(){

    var sQz861 = document.getElementById("imgSqrs861").src;

    value30Save861 = "zSqrArtSpecz861";

    localStorage.setItem(value30Save861, sQz861);
};

function square862(){

    var sQz862 = document.getElementById("imgSqrs862").src;

    value30Save862 = "zSqrArtSpecz862";

    localStorage.setItem(value30Save862, sQz862);
};

function square863(){

    var sQz863 = document.getElementById("imgSqrs863").src;

    value30Save863 = "zSqrArtSpecz863";

    localStorage.setItem(value30Save863, sQz863);
};

function square864(){

    var sQz864 = document.getElementById("imgSqrs864").src;

    value30Save864 = "zSqrArtSpecz864";

    localStorage.setItem(value30Save864, sQz864);
};

function square865(){

    var sQz865 = document.getElementById("imgSqrs865").src;

    value30Save865 = "zSqrArtSpecz865";

    localStorage.setItem(value30Save865, sQz865);
};

function square866(){

    var sQz866 = document.getElementById("imgSqrs866").src;

    value30Save866 = "zSqrArtSpecz866";

    localStorage.setItem(value30Save866, sQz866);
};

function square867(){

    var sQz867 = document.getElementById("imgSqrs867").src;

    value30Save867 = "zSqrArtSpecz867";

    localStorage.setItem(value30Save867, sQz867);
};

function square868(){

    var sQz868 = document.getElementById("imgSqrs868").src;

    value30Save868 = "zSqrArtSpecz868";

    localStorage.setItem(value30Save868, sQz868);
};

function square869(){

    var sQz869 = document.getElementById("imgSqrs869").src;

    value30Save869 = "zSqrArtSpecz869";

    localStorage.setItem(value30Save869, sQz869);
};

function square870(){

    var sQz870 = document.getElementById("imgSqrs870").src;

    value30Save870 = "zSqrArtSpecz870";

    localStorage.setItem(value30Save870, sQz870);
};

function square871(){

    var sQz871 = document.getElementById("imgSqrs871").src;

    value30Save871 = "zSqrArtSpecz871";

    localStorage.setItem(value30Save871, sQz871);
};

function square872(){

    var sQz872 = document.getElementById("imgSqrs872").src;

    value30Save872 = "zSqrArtSpecz872";

    localStorage.setItem(value30Save872, sQz872);
};

function square873(){

    var sQz873 = document.getElementById("imgSqrs873").src;

    value30Save873 = "zSqrArtSpecz873";

    localStorage.setItem(value30Save873, sQz873);
};

function square874(){

    var sQz874 = document.getElementById("imgSqrs874").src;

    value30Save874 = "zSqrArtSpecz874";

    localStorage.setItem(value30Save874, sQz874);
};

function square875(){

    var sQz875 = document.getElementById("imgSqrs875").src;

    value30Save875 = "zSqrArtSpecz875";

    localStorage.setItem(value30Save875, sQz875);
};

function square876(){

    var sQz876 = document.getElementById("imgSqrs876").src;

    value30Save876 = "zSqrArtSpecz876";

    localStorage.setItem(value30Save876, sQz876);
};

function square877(){

    var sQz877 = document.getElementById("imgSqrs877").src;

    value30Save877 = "zSqrArtSpecz877";

    localStorage.setItem(value30Save877, sQz877);
};

function square878(){

    var sQz878 = document.getElementById("imgSqrs878").src;

    value30Save878 = "zSqrArtSpecz878";

    localStorage.setItem(value30Save878, sQz878);
};

function square879(){

    var sQz879 = document.getElementById("imgSqrs879").src;

    value30Save879 = "zSqrArtSpecz879";

    localStorage.setItem(value30Save879, sQz879);
};

function square880(){

    var sQz880 = document.getElementById("imgSqrs880").src;

    value30Save880 = "zSqrArtSpecz880";

    localStorage.setItem(value30Save880, sQz880);
};

function square881(){

    var sQz881 = document.getElementById("imgSqrs881").src;

    value30Save881 = "zSqrArtSpecz881";

    localStorage.setItem(value30Save881, sQz881);
};

function square882(){

    var sQz882 = document.getElementById("imgSqrs882").src;

    value30Save882 = "zSqrArtSpecz882";

    localStorage.setItem(value30Save882, sQz882);
};

function square883(){

    var sQz883 = document.getElementById("imgSqrs883").src;

    value30Save883 = "zSqrArtSpecz883";

    localStorage.setItem(value30Save883, sQz883);
};

function square884(){

    var sQz884 = document.getElementById("imgSqrs884").src;

    value30Save884 = "zSqrArtSpecz884";

    localStorage.setItem(value30Save884, sQz884);
};

function square885(){

    var sQz885 = document.getElementById("imgSqrs885").src;

    value30Save885 = "zSqrArtSpecz885";

    localStorage.setItem(value30Save885, sQz885);
};

function square886(){

    var sQz886 = document.getElementById("imgSqrs886").src;

    value30Save886 = "zSqrArtSpecz886";

    localStorage.setItem(value30Save886, sQz886);
};

function square887(){

    var sQz887 = document.getElementById("imgSqrs887").src;

    value30Save887 = "zSqrArtSpecz887";

    localStorage.setItem(value30Save887, sQz887);
};

function square888(){

    var sQz888 = document.getElementById("imgSqrs888").src;

    value30Save888 = "zSqrArtSpecz888";

    localStorage.setItem(value30Save888, sQz888);
};

function square889(){

    var sQz889 = document.getElementById("imgSqrs889").src;

    value30Save889 = "zSqrArtSpecz889";

    localStorage.setItem(value30Save889, sQz889);
};

function square890(){

    var sQz890 = document.getElementById("imgSqrs890").src;

    value30Save890 = "zSqrArtSpecz890";

    localStorage.setItem(value30Save890, sQz890);
};

function square891(){

    var sQz891 = document.getElementById("imgSqrs891").src;

    value30Save891 = "zSqrArtSpecz891";

    localStorage.setItem(value30Save891, sQz891);
};

function square892(){

    var sQz892 = document.getElementById("imgSqrs892").src;

    value30Save892 = "zSqrArtSpecz892";

    localStorage.setItem(value30Save892, sQz892);
};

function square893(){

    var sQz893 = document.getElementById("imgSqrs893").src;

    value30Save893 = "zSqrArtSpecz893";

    localStorage.setItem(value30Save893, sQz893);
};

function square894(){

    var sQz894 = document.getElementById("imgSqrs894").src;

    value30Save894 = "zSqrArtSpecz894";

    localStorage.setItem(value30Save894, sQz894);
};

function square895(){

    var sQz895 = document.getElementById("imgSqrs895").src;

    value30Save895 = "zSqrArtSpecz895";

    localStorage.setItem(value30Save895, sQz895);
};

function square896(){

    var sQz896 = document.getElementById("imgSqrs896").src;

    value30Save896 = "zSqrArtSpecz896";

    localStorage.setItem(value30Save896, sQz896);
};

function square897(){

    var sQz897 = document.getElementById("imgSqrs897").src;

    value30Save897 = "zSqrArtSpecz897";

    localStorage.setItem(value30Save897, sQz897);
};

function square898(){

    var sQz898 = document.getElementById("imgSqrs898").src;

    value30Save898 = "zSqrArtSpecz898";

    localStorage.setItem(value30Save898, sQz898);
};

function square899(){

    var sQz899 = document.getElementById("imgSqrs899").src;

    value30Save899 = "zSqrArtSpecz899";

    localStorage.setItem(value30Save899, sQz899);
};

function square900(){

    var sQz900 = document.getElementById("imgSqrs900").src;

    value30Save900 = "zSqrArtSpecz900";

    localStorage.setItem(value30Save900, sQz900);
};

function setAThis(){
    square1()

    square2()

    square3()

    square4()

    square5()

    square6()

    square7()

    square8()

    square9()

    square10()

    square11()

    square12()

    square13()

    square14()

    square15()

    square16()

    square17()

    square18()

    square19()

    square20()

    square21()

    square22()

    square23()

    square24()

    square25()

    square26()

    square27()

    square28()

    square29()

    square30()

    square31()

    square32()

    square33()

    square34()

    square35()

    square36()

    square37()

    square38()

    square39()

    square40()

    square41()

    square42()

    square43()

    square44()

    square45()

    square46()

    square47()

    square48()

    square49()

    square50()

    square51()

    square52()

    square53()

    square54()

    square55()

    square56()

    square57()

    square58()

    square59()

    square60()

    square61()

    square62()

    square63()

    square64()

    square65()

    square66()

    square67()

    square68()

    square69()

    square70()

    square71()

    square72()

    square73()

    square74()

    square75()

    square76()

    square77()

    square78()

    square79()

    square80()

    square81()

    square82()

    square83()

    square84()

    square85()

    square86()

    square87()

    square88()

    square89()

    square90()

    square91()

    square92()

    square93()

    square94()

    square95()

    square96()

    square97()

    square98()

    square99()

    square100()

    square101()

    square102()

    square103()

    square104()

    square105()

    square106()

    square107()

    square108()

    square109()

    square110()

    square111()

    square112()

    square113()

    square114()

    square115()

    square116()

    square117()

    square118()

    square119()

    square120()

    square121()

    square122()

    square123()

    square124()

    square125()

    square126()

    square127()

    square128()

    square129()

    square130()

    square131()

    square132()

    square133()

    square134()

    square135()

    square136()

    square137()

    square138()

    square139()

    square140()

    square141()

    square142()

    square143()

    square144()

    square145()

    square146()

    square147()

    square148()

    square149()

    square150()

    square151()

    square152()

    square153()

    square154()

    square155()

    square156()

    square157()

    square158()

    square159()

    square160()

    square161()

    square162()

    square163()

    square164()

    square165()

    square166()

    square167()

    square168()

    square169()

    square170()

    square171()

    square172()

    square173()

    square174()

    square175()

    square176()

    square177()

    square178()

    square179()

    square180()

    square181()

    square182()

    square183()

    square184()

    square185()

    square186()

    square187()

    square188()

    square189()

    square190()

    square191()

    square192()

    square193()

    square194()

    square195()

    square196()

    square197()

    square198()

    square199()

    square200()

    square201()

    square202()

    square203()

    square204()

    square205()

    square206()

    square207()

    square208()

    square209()

    square210()

    square211()

    square212()

    square213()

    square214()

    square215()

    square216()

    square217()

    square218()

    square219()

    square220()

    square221()

    square222()

    square223()

    square224()

    square225()

    square226()

    square227()

    square228()

    square229()

    square230()

    square231()

    square232()

    square233()

    square234()

    square235()

    square236()

    square237()

    square238()

    square239()

    square240()

    square241()

    square242()

    square243()

    square244()

    square245()

    square246()

    square247()

    square248()

    square249()

    square250()

    square251()

    square252()

    square253()

    square254()

    square255()

    square256()

    square257()

    square258()

    square259()

    square260()

    square261()

    square262()

    square263()

    square264()

    square265()

    square266()

    square267()

    square268()

    square269()

    square270()

    square271()

    square272()

    square273()

    square274()

    square275()

    square276()

    square277()

    square278()

    square279()

    square280()

    square281()

    square282()

    square283()

    square284()

    square285()

    square286()

    square287()

    square288()

    square289()

    square290()

    square291()

    square292()

    square293()

    square294()

    square295()

    square296()

    square297()

    square298()

    square299()

    square300()

    square301()

    square302()

    square303()

    square304()

    square305()

    square306()

    square307()

    square308()

    square309()

    square310()

    square311()

    square312()

    square313()

    square314()

    square315()

    square316()

    square317()

    square318()

    square319()

    square320()

    square321()

    square322()

    square323()

    square324()

    square325()

    square326()

    square327()

    square328()

    square329()

    square330()

    square331()

    square332()

    square333()

    square334()

    square335()

    square336()

    square337()

    square338()

    square339()

    square340()

    square341()

    square342()

    square343()

    square344()

    square345()

    square346()

    square347()

    square348()

    square349()

    square350()

    square351()

    square352()

    square353()

    square354()

    square355()

    square356()

    square357()

    square358()

    square359()

    square360()

    square361()

    square362()

    square363()

    square364()

    square365()

    square366()

    square367()

    square368()

    square369()

    square370()

    square371()

    square372()

    square373()

    square374()

    square375()

    square376()

    square377()

    square378()

    square379()

    square380()

    square381()

    square382()

    square383()

    square384()

    square385()

    square386()

    square387()

    square388()

    square389()

    square390()

    square391()

    square392()

    square393()

    square394()

    square395()

    square396()

    square397()

    square398()

    square399()

    square400()

    square401()

    square402()

    square403()

    square404()

    square405()

    square406()

    square407()

    square408()

    square409()

    square410()

    square411()

    square412()

    square413()

    square414()

    square415()

    square416()

    square417()

    square418()

    square419()

    square420()

    square421()

    square422()

    square423()

    square424()

    square425()

    square426()

    square427()

    square428()

    square429()

    square430()

    square431()

    square432()

    square433()

    square434()

    square435()

    square436()

    square437()

    square438()

    square439()

    square440()

    square441()

    square442()

    square443()

    square444()

    square445()

    square446()

    square447()

    square448()

    square449()

    square450()

    square451()

    square452()

    square453()

    square454()

    square455()

    square456()

    square457()

    square458()

    square459()

    square460()

    square461()

    square462()

    square463()

    square464()

    square465()

    square466()

    square467()

    square468()

    square469()

    square470()

    square471()

    square472()

    square473()

    square474()

    square475()

    square476()

    square477()

    square478()

    square479()

    square480()

    square481()

    square482()

    square483()

    square484()

    square485()

    square486()

    square487()

    square488()

    square489()

    square490()

    square491()

    square492()

    square493()

    square494()

    square495()

    square496()

    square497()

    square498()

    square499()

    square500()

    square501()

    square502()

    square503()

    square504()

    square505()

    square506()

    square507()

    square508()

    square509()

    square510()

    square511()

    square512()

    square513()

    square514()

    square515()

    square516()

    square517()

    square518()

    square519()

    square520()

    square521()

    square522()

    square523()

    square524()

    square525()

    square526()

    square527()

    square528()

    square529()

    square530()

    square531()

    square532()

    square533()

    square534()

    square535()

    square536()

    square537()

    square538()

    square539()

    square540()

    square541()

    square542()

    square543()

    square544()

    square545()

    square546()

    square547()

    square548()

    square549()

    square550()

    square551()

    square552()

    square553()

    square554()

    square555()

    square556()

    square557()

    square558()

    square559()

    square560()

    square561()

    square562()

    square563()

    square564()

    square565()

    square566()

    square567()

    square568()

    square569()

    square570()

    square571()

    square572()

    square573()

    square574()

    square575()

    square576()

    square577()

    square578()

    square579()

    square580()

    square581()

    square582()

    square583()

    square584()

    square585()

    square586()

    square587()

    square588()

    square589()

    square590()

    square591()

    square592()

    square593()

    square594()

    square595()

    square596()

    square597()

    square598()

    square599()

    square600()

    square601()

    square602()

    square603()

    square604()

    square605()

    square606()

    square607()

    square608()

    square609()

    square610()

    square611()

    square612()

    square613()

    square614()

    square615()

    square616()

    square617()

    square618()

    square619()

    square620()

    square621()

    square622()

    square623()

    square624()

    square625()

    square626()

    square627()

    square628()

    square629()

    square630()

    square631()

    square632()

    square633()

    square634()

    square635()

    square636()

    square637()

    square638()

    square639()

    square640()

    square641()

    square642()

    square643()

    square644()

    square645()

    square646()

    square647()

    square648()

    square649()

    square650()

    square651()

    square652()

    square653()

    square654()

    square655()

    square656()

    square657()

    square658()

    square659()

    square660()

    square661()

    square662()

    square663()

    square664()

    square665()

    square666()

    square667()

    square668()

    square669()

    square670()

    square671()

    square672()

    square673()

    square674()

    square675()

    square676()

    square677()

    square678()

    square679()

    square680()

    square681()

    square682()

    square683()

    square684()

    square685()

    square686()

    square687()

    square688()

    square689()

    square690()

    square691()

    square692()

    square693()

    square694()

    square695()

    square696()

    square697()

    square698()

    square699()

    square700()

    square701()

    square702()

    square703()

    square704()

    square705()

    square706()

    square707()

    square708()

    square709()

    square710()

    square711()

    square712()

    square713()

    square714()

    square715()

    square716()

    square717()

    square718()

    square719()

    square720()

    square721()

    square722()

    square723()

    square724()

    square725()

    square726()

    square727()

    square728()

    square729()

    square730()

    square731()

    square732()

    square733()

    square734()

    square735()

    square736()

    square737()

    square738()

    square739()

    square740()

    square741()

    square742()

    square743()

    square744()

    square745()

    square746()

    square747()

    square748()

    square749()

    square750()

    square751()

    square752()

    square753()

    square754()

    square755()

    square756()

    square757()

    square758()

    square759()

    square760()

    square761()

    square762()

    square763()

    square764()

    square765()

    square766()

    square767()

    square768()

    square769()

    square770()

    square771()

    square772()

    square773()

    square774()

    square775()

    square776()

    square777()

    square778()

    square779()

    square780()

    square781()

    square782()

    square783()

    square784()

    square785()

    square786()

    square787()

    square788()

    square789()

    square790()

    square791()

    square792()

    square793()

    square794()

    square795()

    square796()

    square797()

    square798()

    square799()

    square800()

    square801()

    square802()

    square803()

    square804()

    square805()

    square806()

    square807()

    square808()

    square809()

    square810()

    square811()

    square812()

    square813()

    square814()

    square815()

    square816()

    square817()

    square818()

    square819()

    square820()

    square821()

    square822()

    square823()

    square824()

    square825()

    square826()

    square827()

    square828()

    square829()

    square830()

    square831()

    square832()

    square833()

    square834()

    square835()

    square836()

    square837()

    square838()

    square839()

    square840()

    square841()

    square842()

    square843()

    square844()

    square845()

    square846()

    square847()

    square848()

    square849()

    square850()

    square851()

    square852()

    square853()

    square854()

    square855()

    square856()

    square857()

    square858()

    square859()

    square860()

    square861()

    square862()

    square863()

    square864()

    square865()

    square866()

    square867()

    square868()

    square869()

    square870()

    square871()

    square872()

    square873()

    square874()

    square875()

    square876()

    square877()

    square878()

    square879()

    square880()

    square881()

    square882()

    square883()

    square884()

    square885()

    square886()

    square887()

    square888()

    square889()

    square890()

    square891()

    square892()

    square893()

    square894()

    square895()

    square896()

    square897()

    square898()

    square899()

    square900()

    alert("Your art has been saved locally, to your local browser storage.");
};

function squareToSzzZValue1(){
    value30Save = "zSqrArtSpecz1";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs1").src = tripleZeroA;
};

function squareToSzzZValue2(){
    value30Save = "zSqrArtSpecz2";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs2").src = tripleZeroA;
};

function squareToSzzZValue3(){
    value30Save = "zSqrArtSpecz3";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs3").src = tripleZeroA;
};

function squareToSzzZValue4(){
    value30Save = "zSqrArtSpecz4";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs4").src = tripleZeroA;
};

function squareToSzzZValue5(){
    value30Save = "zSqrArtSpecz5";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs5").src = tripleZeroA;
};

function squareToSzzZValue6(){
    value30Save = "zSqrArtSpecz6";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs6").src = tripleZeroA;
};

function squareToSzzZValue7(){
    value30Save = "zSqrArtSpecz7";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs7").src = tripleZeroA;
};

function squareToSzzZValue8(){
    value30Save = "zSqrArtSpecz8";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs8").src = tripleZeroA;
};

function squareToSzzZValue9(){
    value30Save = "zSqrArtSpecz9";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs9").src = tripleZeroA;
};

function squareToSzzZValue10(){
    value30Save = "zSqrArtSpecz10";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs10").src = tripleZeroA;
};

function squareToSzzZValue11(){
    value30Save = "zSqrArtSpecz11";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs11").src = tripleZeroA;
};

function squareToSzzZValue12(){
    value30Save = "zSqrArtSpecz12";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs12").src = tripleZeroA;
};

function squareToSzzZValue13(){
    value30Save = "zSqrArtSpecz13";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs13").src = tripleZeroA;
};

function squareToSzzZValue14(){
    value30Save = "zSqrArtSpecz14";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs14").src = tripleZeroA;
};

function squareToSzzZValue15(){
    value30Save = "zSqrArtSpecz15";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs15").src = tripleZeroA;
};

function squareToSzzZValue16(){
    value30Save = "zSqrArtSpecz16";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs16").src = tripleZeroA;
};

function squareToSzzZValue17(){
    value30Save = "zSqrArtSpecz17";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs17").src = tripleZeroA;
};

function squareToSzzZValue18(){
    value30Save = "zSqrArtSpecz18";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs18").src = tripleZeroA;
};

function squareToSzzZValue19(){
    value30Save = "zSqrArtSpecz19";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs19").src = tripleZeroA;
};

function squareToSzzZValue20(){
    value30Save = "zSqrArtSpecz20";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs20").src = tripleZeroA;
};

function squareToSzzZValue21(){
    value30Save = "zSqrArtSpecz21";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs21").src = tripleZeroA;
};

function squareToSzzZValue22(){
    value30Save = "zSqrArtSpecz22";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs22").src = tripleZeroA;
};

function squareToSzzZValue23(){
    value30Save = "zSqrArtSpecz23";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs23").src = tripleZeroA;
};

function squareToSzzZValue24(){
    value30Save = "zSqrArtSpecz24";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs24").src = tripleZeroA;
};

function squareToSzzZValue25(){
    value30Save = "zSqrArtSpecz25";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs25").src = tripleZeroA;
};

function squareToSzzZValue26(){
    value30Save = "zSqrArtSpecz26";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs26").src = tripleZeroA;
};

function squareToSzzZValue27(){
    value30Save = "zSqrArtSpecz27";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs27").src = tripleZeroA;
};

function squareToSzzZValue28(){
    value30Save = "zSqrArtSpecz28";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs28").src = tripleZeroA;
};

function squareToSzzZValue29(){
    value30Save = "zSqrArtSpecz29";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs29").src = tripleZeroA;
};

function squareToSzzZValue30(){
    value30Save = "zSqrArtSpecz30";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs30").src = tripleZeroA;
};

function squareToSzzZValue31(){
    value30Save = "zSqrArtSpecz31";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs31").src = tripleZeroA;
};

function squareToSzzZValue32(){
    value30Save = "zSqrArtSpecz32";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs32").src = tripleZeroA;
};

function squareToSzzZValue33(){
    value30Save = "zSqrArtSpecz33";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs33").src = tripleZeroA;
};

function squareToSzzZValue34(){
    value30Save = "zSqrArtSpecz34";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs34").src = tripleZeroA;
};

function squareToSzzZValue35(){
    value30Save = "zSqrArtSpecz35";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs35").src = tripleZeroA;
};

function squareToSzzZValue36(){
    value30Save = "zSqrArtSpecz36";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs36").src = tripleZeroA;
};

function squareToSzzZValue37(){
    value30Save = "zSqrArtSpecz37";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs37").src = tripleZeroA;
};

function squareToSzzZValue38(){
    value30Save = "zSqrArtSpecz38";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs38").src = tripleZeroA;
};

function squareToSzzZValue39(){
    value30Save = "zSqrArtSpecz39";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs39").src = tripleZeroA;
};

function squareToSzzZValue40(){
    value30Save = "zSqrArtSpecz40";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs40").src = tripleZeroA;
};

function squareToSzzZValue41(){
    value30Save = "zSqrArtSpecz41";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs41").src = tripleZeroA;
};

function squareToSzzZValue42(){
    value30Save = "zSqrArtSpecz42";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs42").src = tripleZeroA;
};

function squareToSzzZValue43(){
    value30Save = "zSqrArtSpecz43";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs43").src = tripleZeroA;
};

function squareToSzzZValue44(){
    value30Save = "zSqrArtSpecz44";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs44").src = tripleZeroA;
};

function squareToSzzZValue45(){
    value30Save = "zSqrArtSpecz45";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs45").src = tripleZeroA;
};

function squareToSzzZValue46(){
    value30Save = "zSqrArtSpecz46";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs46").src = tripleZeroA;
};

function squareToSzzZValue47(){
    value30Save = "zSqrArtSpecz47";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs47").src = tripleZeroA;
};

function squareToSzzZValue48(){
    value30Save = "zSqrArtSpecz48";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs48").src = tripleZeroA;
};

function squareToSzzZValue49(){
    value30Save = "zSqrArtSpecz49";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs49").src = tripleZeroA;
};

function squareToSzzZValue50(){
    value30Save = "zSqrArtSpecz50";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs50").src = tripleZeroA;
};

function squareToSzzZValue51(){
    value30Save = "zSqrArtSpecz51";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs51").src = tripleZeroA;
};

function squareToSzzZValue52(){
    value30Save = "zSqrArtSpecz52";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs52").src = tripleZeroA;
};

function squareToSzzZValue53(){
    value30Save = "zSqrArtSpecz53";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs53").src = tripleZeroA;
};

function squareToSzzZValue54(){
    value30Save = "zSqrArtSpecz54";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs54").src = tripleZeroA;
};

function squareToSzzZValue55(){
    value30Save = "zSqrArtSpecz55";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs55").src = tripleZeroA;
};

function squareToSzzZValue56(){
    value30Save = "zSqrArtSpecz56";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs56").src = tripleZeroA;
};

function squareToSzzZValue57(){
    value30Save = "zSqrArtSpecz57";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs57").src = tripleZeroA;
};

function squareToSzzZValue58(){
    value30Save = "zSqrArtSpecz58";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs58").src = tripleZeroA;
};

function squareToSzzZValue59(){
    value30Save = "zSqrArtSpecz59";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs59").src = tripleZeroA;
};

function squareToSzzZValue60(){
    value30Save = "zSqrArtSpecz60";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs60").src = tripleZeroA;
};

function squareToSzzZValue61(){
    value30Save = "zSqrArtSpecz61";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs61").src = tripleZeroA;
};

function squareToSzzZValue62(){
    value30Save = "zSqrArtSpecz62";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs62").src = tripleZeroA;
};

function squareToSzzZValue63(){
    value30Save = "zSqrArtSpecz63";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs63").src = tripleZeroA;
};

function squareToSzzZValue64(){
    value30Save = "zSqrArtSpecz64";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs64").src = tripleZeroA;
};

function squareToSzzZValue65(){
    value30Save = "zSqrArtSpecz65";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs65").src = tripleZeroA;
};

function squareToSzzZValue66(){
    value30Save = "zSqrArtSpecz66";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs66").src = tripleZeroA;
};

function squareToSzzZValue67(){
    value30Save = "zSqrArtSpecz67";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs67").src = tripleZeroA;
};

function squareToSzzZValue68(){
    value30Save = "zSqrArtSpecz68";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs68").src = tripleZeroA;
};

function squareToSzzZValue69(){
    value30Save = "zSqrArtSpecz69";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs69").src = tripleZeroA;
};

function squareToSzzZValue70(){
    value30Save = "zSqrArtSpecz70";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs70").src = tripleZeroA;
};

function squareToSzzZValue71(){
    value30Save = "zSqrArtSpecz71";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs71").src = tripleZeroA;
};

function squareToSzzZValue72(){
    value30Save = "zSqrArtSpecz72";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs72").src = tripleZeroA;
};

function squareToSzzZValue73(){
    value30Save = "zSqrArtSpecz73";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs73").src = tripleZeroA;
};

function squareToSzzZValue74(){
    value30Save = "zSqrArtSpecz74";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs74").src = tripleZeroA;
};

function squareToSzzZValue75(){
    value30Save = "zSqrArtSpecz75";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs75").src = tripleZeroA;
};

function squareToSzzZValue76(){
    value30Save = "zSqrArtSpecz76";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs76").src = tripleZeroA;
};

function squareToSzzZValue77(){
    value30Save = "zSqrArtSpecz77";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs77").src = tripleZeroA;
};

function squareToSzzZValue78(){
    value30Save = "zSqrArtSpecz78";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs78").src = tripleZeroA;
};

function squareToSzzZValue79(){
    value30Save = "zSqrArtSpecz79";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs79").src = tripleZeroA;
};

function squareToSzzZValue80(){
    value30Save = "zSqrArtSpecz80";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs80").src = tripleZeroA;
};

function squareToSzzZValue81(){
    value30Save = "zSqrArtSpecz81";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs81").src = tripleZeroA;
};

function squareToSzzZValue82(){
    value30Save = "zSqrArtSpecz82";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs82").src = tripleZeroA;
};

function squareToSzzZValue83(){
    value30Save = "zSqrArtSpecz83";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs83").src = tripleZeroA;
};

function squareToSzzZValue84(){
    value30Save = "zSqrArtSpecz84";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs84").src = tripleZeroA;
};

function squareToSzzZValue85(){
    value30Save = "zSqrArtSpecz85";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs85").src = tripleZeroA;
};

function squareToSzzZValue86(){
    value30Save = "zSqrArtSpecz86";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs86").src = tripleZeroA;
};

function squareToSzzZValue87(){
    value30Save = "zSqrArtSpecz87";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs87").src = tripleZeroA;
};

function squareToSzzZValue88(){
    value30Save = "zSqrArtSpecz88";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs88").src = tripleZeroA;
};

function squareToSzzZValue89(){
    value30Save = "zSqrArtSpecz89";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs89").src = tripleZeroA;
};

function squareToSzzZValue90(){
    value30Save = "zSqrArtSpecz90";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs90").src = tripleZeroA;
};

function squareToSzzZValue91(){
    value30Save = "zSqrArtSpecz91";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs91").src = tripleZeroA;
};

function squareToSzzZValue92(){
    value30Save = "zSqrArtSpecz92";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs92").src = tripleZeroA;
};

function squareToSzzZValue93(){
    value30Save = "zSqrArtSpecz93";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs93").src = tripleZeroA;
};

function squareToSzzZValue94(){
    value30Save = "zSqrArtSpecz94";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs94").src = tripleZeroA;
};

function squareToSzzZValue95(){
    value30Save = "zSqrArtSpecz95";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs95").src = tripleZeroA;
};

function squareToSzzZValue96(){
    value30Save = "zSqrArtSpecz96";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs96").src = tripleZeroA;
};

function squareToSzzZValue97(){
    value30Save = "zSqrArtSpecz97";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs97").src = tripleZeroA;
};

function squareToSzzZValue98(){
    value30Save = "zSqrArtSpecz98";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs98").src = tripleZeroA;
};

function squareToSzzZValue99(){
    value30Save = "zSqrArtSpecz99";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs99").src = tripleZeroA;
};

function squareToSzzZValue100(){
    value30Save = "zSqrArtSpecz100";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs100").src = tripleZeroA;
};

function squareToSzzZValue101(){
    value30Save = "zSqrArtSpecz101";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs101").src = tripleZeroA;
};

function squareToSzzZValue102(){
    value30Save = "zSqrArtSpecz102";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs102").src = tripleZeroA;
};

function squareToSzzZValue103(){
    value30Save = "zSqrArtSpecz103";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs103").src = tripleZeroA;
};

function squareToSzzZValue104(){
    value30Save = "zSqrArtSpecz104";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs104").src = tripleZeroA;
};

function squareToSzzZValue105(){
    value30Save = "zSqrArtSpecz105";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs105").src = tripleZeroA;
};

function squareToSzzZValue106(){
    value30Save = "zSqrArtSpecz106";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs106").src = tripleZeroA;
};

function squareToSzzZValue107(){
    value30Save = "zSqrArtSpecz107";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs107").src = tripleZeroA;
};

function squareToSzzZValue108(){
    value30Save = "zSqrArtSpecz108";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs108").src = tripleZeroA;
};

function squareToSzzZValue109(){
    value30Save = "zSqrArtSpecz109";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs109").src = tripleZeroA;
};

function squareToSzzZValue110(){
    value30Save = "zSqrArtSpecz110";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs110").src = tripleZeroA;
};

function squareToSzzZValue111(){
    value30Save = "zSqrArtSpecz111";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs111").src = tripleZeroA;
};

function squareToSzzZValue112(){
    value30Save = "zSqrArtSpecz112";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs112").src = tripleZeroA;
};

function squareToSzzZValue113(){
    value30Save = "zSqrArtSpecz113";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs113").src = tripleZeroA;
};

function squareToSzzZValue114(){
    value30Save = "zSqrArtSpecz114";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs114").src = tripleZeroA;
};

function squareToSzzZValue115(){
    value30Save = "zSqrArtSpecz115";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs115").src = tripleZeroA;
};

function squareToSzzZValue116(){
    value30Save = "zSqrArtSpecz116";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs116").src = tripleZeroA;
};

function squareToSzzZValue117(){
    value30Save = "zSqrArtSpecz117";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs117").src = tripleZeroA;
};

function squareToSzzZValue118(){
    value30Save = "zSqrArtSpecz118";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs118").src = tripleZeroA;
};

function squareToSzzZValue119(){
    value30Save = "zSqrArtSpecz119";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs119").src = tripleZeroA;
};

function squareToSzzZValue120(){
    value30Save = "zSqrArtSpecz120";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs120").src = tripleZeroA;
};

function squareToSzzZValue121(){
    value30Save = "zSqrArtSpecz121";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs121").src = tripleZeroA;
};

function squareToSzzZValue122(){
    value30Save = "zSqrArtSpecz122";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs122").src = tripleZeroA;
};

function squareToSzzZValue123(){
    value30Save = "zSqrArtSpecz123";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs123").src = tripleZeroA;
};

function squareToSzzZValue124(){
    value30Save = "zSqrArtSpecz124";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs124").src = tripleZeroA;
};

function squareToSzzZValue125(){
    value30Save = "zSqrArtSpecz125";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs125").src = tripleZeroA;
};

function squareToSzzZValue126(){
    value30Save = "zSqrArtSpecz126";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs126").src = tripleZeroA;
};

function squareToSzzZValue127(){
    value30Save = "zSqrArtSpecz127";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs127").src = tripleZeroA;
};

function squareToSzzZValue128(){
    value30Save = "zSqrArtSpecz128";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs128").src = tripleZeroA;
};

function squareToSzzZValue129(){
    value30Save = "zSqrArtSpecz129";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs129").src = tripleZeroA;
};

function squareToSzzZValue130(){
    value30Save = "zSqrArtSpecz130";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs130").src = tripleZeroA;
};

function squareToSzzZValue131(){
    value30Save = "zSqrArtSpecz131";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs131").src = tripleZeroA;
};

function squareToSzzZValue132(){
    value30Save = "zSqrArtSpecz132";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs132").src = tripleZeroA;
};

function squareToSzzZValue133(){
    value30Save = "zSqrArtSpecz133";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs133").src = tripleZeroA;
};

function squareToSzzZValue134(){
    value30Save = "zSqrArtSpecz134";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs134").src = tripleZeroA;
};

function squareToSzzZValue135(){
    value30Save = "zSqrArtSpecz135";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs135").src = tripleZeroA;
};

function squareToSzzZValue136(){
    value30Save = "zSqrArtSpecz136";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs136").src = tripleZeroA;
};

function squareToSzzZValue137(){
    value30Save = "zSqrArtSpecz137";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs137").src = tripleZeroA;
};

function squareToSzzZValue138(){
    value30Save = "zSqrArtSpecz138";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs138").src = tripleZeroA;
};

function squareToSzzZValue139(){
    value30Save = "zSqrArtSpecz139";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs139").src = tripleZeroA;
};

function squareToSzzZValue140(){
    value30Save = "zSqrArtSpecz140";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs140").src = tripleZeroA;
};

function squareToSzzZValue141(){
    value30Save = "zSqrArtSpecz141";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs141").src = tripleZeroA;
};

function squareToSzzZValue142(){
    value30Save = "zSqrArtSpecz142";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs142").src = tripleZeroA;
};

function squareToSzzZValue143(){
    value30Save = "zSqrArtSpecz143";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs143").src = tripleZeroA;
};

function squareToSzzZValue144(){
    value30Save = "zSqrArtSpecz144";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs144").src = tripleZeroA;
};

function squareToSzzZValue145(){
    value30Save = "zSqrArtSpecz145";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs145").src = tripleZeroA;
};

function squareToSzzZValue146(){
    value30Save = "zSqrArtSpecz146";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs146").src = tripleZeroA;
};

function squareToSzzZValue147(){
    value30Save = "zSqrArtSpecz147";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs147").src = tripleZeroA;
};

function squareToSzzZValue148(){
    value30Save = "zSqrArtSpecz148";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs148").src = tripleZeroA;
};

function squareToSzzZValue149(){
    value30Save = "zSqrArtSpecz149";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs149").src = tripleZeroA;
};

function squareToSzzZValue150(){
    value30Save = "zSqrArtSpecz150";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs150").src = tripleZeroA;
};

function squareToSzzZValue151(){
    value30Save = "zSqrArtSpecz151";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs151").src = tripleZeroA;
};

function squareToSzzZValue152(){
    value30Save = "zSqrArtSpecz152";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs152").src = tripleZeroA;
};

function squareToSzzZValue153(){
    value30Save = "zSqrArtSpecz153";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs153").src = tripleZeroA;
};

function squareToSzzZValue154(){
    value30Save = "zSqrArtSpecz154";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs154").src = tripleZeroA;
};

function squareToSzzZValue155(){
    value30Save = "zSqrArtSpecz155";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs155").src = tripleZeroA;
};

function squareToSzzZValue156(){
    value30Save = "zSqrArtSpecz156";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs156").src = tripleZeroA;
};

function squareToSzzZValue157(){
    value30Save = "zSqrArtSpecz157";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs157").src = tripleZeroA;
};

function squareToSzzZValue158(){
    value30Save = "zSqrArtSpecz158";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs158").src = tripleZeroA;
};

function squareToSzzZValue159(){
    value30Save = "zSqrArtSpecz159";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs159").src = tripleZeroA;
};

function squareToSzzZValue160(){
    value30Save = "zSqrArtSpecz160";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs160").src = tripleZeroA;
};

function squareToSzzZValue161(){
    value30Save = "zSqrArtSpecz161";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs161").src = tripleZeroA;
};

function squareToSzzZValue162(){
    value30Save = "zSqrArtSpecz162";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs162").src = tripleZeroA;
};

function squareToSzzZValue163(){
    value30Save = "zSqrArtSpecz163";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs163").src = tripleZeroA;
};

function squareToSzzZValue164(){
    value30Save = "zSqrArtSpecz164";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs164").src = tripleZeroA;
};

function squareToSzzZValue165(){
    value30Save = "zSqrArtSpecz165";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs165").src = tripleZeroA;
};

function squareToSzzZValue166(){
    value30Save = "zSqrArtSpecz166";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs166").src = tripleZeroA;
};

function squareToSzzZValue167(){
    value30Save = "zSqrArtSpecz167";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs167").src = tripleZeroA;
};

function squareToSzzZValue168(){
    value30Save = "zSqrArtSpecz168";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs168").src = tripleZeroA;
};

function squareToSzzZValue169(){
    value30Save = "zSqrArtSpecz169";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs169").src = tripleZeroA;
};

function squareToSzzZValue170(){
    value30Save = "zSqrArtSpecz170";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs170").src = tripleZeroA;
};

function squareToSzzZValue171(){
    value30Save = "zSqrArtSpecz171";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs171").src = tripleZeroA;
};

function squareToSzzZValue172(){
    value30Save = "zSqrArtSpecz172";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs172").src = tripleZeroA;
};

function squareToSzzZValue173(){
    value30Save = "zSqrArtSpecz173";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs173").src = tripleZeroA;
};

function squareToSzzZValue174(){
    value30Save = "zSqrArtSpecz174";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs174").src = tripleZeroA;
};

function squareToSzzZValue175(){
    value30Save = "zSqrArtSpecz175";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs175").src = tripleZeroA;
};

function squareToSzzZValue176(){
    value30Save = "zSqrArtSpecz176";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs176").src = tripleZeroA;
};

function squareToSzzZValue177(){
    value30Save = "zSqrArtSpecz177";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs177").src = tripleZeroA;
};

function squareToSzzZValue178(){
    value30Save = "zSqrArtSpecz178";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs178").src = tripleZeroA;
};

function squareToSzzZValue179(){
    value30Save = "zSqrArtSpecz179";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs179").src = tripleZeroA;
};

function squareToSzzZValue180(){
    value30Save = "zSqrArtSpecz180";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs180").src = tripleZeroA;
};

function squareToSzzZValue181(){
    value30Save = "zSqrArtSpecz181";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs181").src = tripleZeroA;
};

function squareToSzzZValue182(){
    value30Save = "zSqrArtSpecz182";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs182").src = tripleZeroA;
};

function squareToSzzZValue183(){
    value30Save = "zSqrArtSpecz183";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs183").src = tripleZeroA;
};

function squareToSzzZValue184(){
    value30Save = "zSqrArtSpecz184";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs184").src = tripleZeroA;
};

function squareToSzzZValue185(){
    value30Save = "zSqrArtSpecz185";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs185").src = tripleZeroA;
};

function squareToSzzZValue186(){
    value30Save = "zSqrArtSpecz186";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs186").src = tripleZeroA;
};

function squareToSzzZValue187(){
    value30Save = "zSqrArtSpecz187";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs187").src = tripleZeroA;
};

function squareToSzzZValue188(){
    value30Save = "zSqrArtSpecz188";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs188").src = tripleZeroA;
};

function squareToSzzZValue189(){
    value30Save = "zSqrArtSpecz189";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs189").src = tripleZeroA;
};

function squareToSzzZValue190(){
    value30Save = "zSqrArtSpecz190";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs190").src = tripleZeroA;
};

function squareToSzzZValue191(){
    value30Save = "zSqrArtSpecz191";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs191").src = tripleZeroA;
};

function squareToSzzZValue192(){
    value30Save = "zSqrArtSpecz192";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs192").src = tripleZeroA;
};

function squareToSzzZValue193(){
    value30Save = "zSqrArtSpecz193";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs193").src = tripleZeroA;
};

function squareToSzzZValue194(){
    value30Save = "zSqrArtSpecz194";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs194").src = tripleZeroA;
};

function squareToSzzZValue195(){
    value30Save = "zSqrArtSpecz195";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs195").src = tripleZeroA;
};

function squareToSzzZValue196(){
    value30Save = "zSqrArtSpecz196";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs196").src = tripleZeroA;
};

function squareToSzzZValue197(){
    value30Save = "zSqrArtSpecz197";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs197").src = tripleZeroA;
};

function squareToSzzZValue198(){
    value30Save = "zSqrArtSpecz198";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs198").src = tripleZeroA;
};

function squareToSzzZValue199(){
    value30Save = "zSqrArtSpecz199";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs199").src = tripleZeroA;
};

function squareToSzzZValue200(){
    value30Save = "zSqrArtSpecz200";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs200").src = tripleZeroA;
};

function squareToSzzZValue201(){
    value30Save = "zSqrArtSpecz201";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs201").src = tripleZeroA;
};

function squareToSzzZValue202(){
    value30Save = "zSqrArtSpecz202";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs202").src = tripleZeroA;
};

function squareToSzzZValue203(){
    value30Save = "zSqrArtSpecz203";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs203").src = tripleZeroA;
};

function squareToSzzZValue204(){
    value30Save = "zSqrArtSpecz204";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs204").src = tripleZeroA;
};

function squareToSzzZValue205(){
    value30Save = "zSqrArtSpecz205";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs205").src = tripleZeroA;
};

function squareToSzzZValue206(){
    value30Save = "zSqrArtSpecz206";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs206").src = tripleZeroA;
};

function squareToSzzZValue207(){
    value30Save = "zSqrArtSpecz207";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs207").src = tripleZeroA;
};

function squareToSzzZValue208(){
    value30Save = "zSqrArtSpecz208";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs208").src = tripleZeroA;
};

function squareToSzzZValue209(){
    value30Save = "zSqrArtSpecz209";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs209").src = tripleZeroA;
};

function squareToSzzZValue210(){
    value30Save = "zSqrArtSpecz210";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs210").src = tripleZeroA;
};

function squareToSzzZValue211(){
    value30Save = "zSqrArtSpecz211";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs211").src = tripleZeroA;
};

function squareToSzzZValue212(){
    value30Save = "zSqrArtSpecz212";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs212").src = tripleZeroA;
};

function squareToSzzZValue213(){
    value30Save = "zSqrArtSpecz213";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs213").src = tripleZeroA;
};

function squareToSzzZValue214(){
    value30Save = "zSqrArtSpecz214";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs214").src = tripleZeroA;
};

function squareToSzzZValue215(){
    value30Save = "zSqrArtSpecz215";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs215").src = tripleZeroA;
};

function squareToSzzZValue216(){
    value30Save = "zSqrArtSpecz216";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs216").src = tripleZeroA;
};

function squareToSzzZValue217(){
    value30Save = "zSqrArtSpecz217";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs217").src = tripleZeroA;
};

function squareToSzzZValue218(){
    value30Save = "zSqrArtSpecz218";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs218").src = tripleZeroA;
};

function squareToSzzZValue219(){
    value30Save = "zSqrArtSpecz219";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs219").src = tripleZeroA;
};

function squareToSzzZValue220(){
    value30Save = "zSqrArtSpecz220";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs220").src = tripleZeroA;
};

function squareToSzzZValue221(){
    value30Save = "zSqrArtSpecz221";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs221").src = tripleZeroA;
};

function squareToSzzZValue222(){
    value30Save = "zSqrArtSpecz222";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs222").src = tripleZeroA;
};

function squareToSzzZValue223(){
    value30Save = "zSqrArtSpecz223";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs223").src = tripleZeroA;
};

function squareToSzzZValue224(){
    value30Save = "zSqrArtSpecz224";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs224").src = tripleZeroA;
};

function squareToSzzZValue225(){
    value30Save = "zSqrArtSpecz225";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs225").src = tripleZeroA;
};

function squareToSzzZValue226(){
    value30Save = "zSqrArtSpecz226";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs226").src = tripleZeroA;
};

function squareToSzzZValue227(){
    value30Save = "zSqrArtSpecz227";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs227").src = tripleZeroA;
};

function squareToSzzZValue228(){
    value30Save = "zSqrArtSpecz228";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs228").src = tripleZeroA;
};

function squareToSzzZValue229(){
    value30Save = "zSqrArtSpecz229";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs229").src = tripleZeroA;
};

function squareToSzzZValue230(){
    value30Save = "zSqrArtSpecz230";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs230").src = tripleZeroA;
};

function squareToSzzZValue231(){
    value30Save = "zSqrArtSpecz231";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs231").src = tripleZeroA;
};

function squareToSzzZValue232(){
    value30Save = "zSqrArtSpecz232";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs232").src = tripleZeroA;
};

function squareToSzzZValue233(){
    value30Save = "zSqrArtSpecz233";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs233").src = tripleZeroA;
};

function squareToSzzZValue234(){
    value30Save = "zSqrArtSpecz234";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs234").src = tripleZeroA;
};

function squareToSzzZValue235(){
    value30Save = "zSqrArtSpecz235";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs235").src = tripleZeroA;
};

function squareToSzzZValue236(){
    value30Save = "zSqrArtSpecz236";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs236").src = tripleZeroA;
};

function squareToSzzZValue237(){
    value30Save = "zSqrArtSpecz237";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs237").src = tripleZeroA;
};

function squareToSzzZValue238(){
    value30Save = "zSqrArtSpecz238";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs238").src = tripleZeroA;
};

function squareToSzzZValue239(){
    value30Save = "zSqrArtSpecz239";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs239").src = tripleZeroA;
};

function squareToSzzZValue240(){
    value30Save = "zSqrArtSpecz240";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs240").src = tripleZeroA;
};

function squareToSzzZValue241(){
    value30Save = "zSqrArtSpecz241";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs241").src = tripleZeroA;
};

function squareToSzzZValue242(){
    value30Save = "zSqrArtSpecz242";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs242").src = tripleZeroA;
};

function squareToSzzZValue243(){
    value30Save = "zSqrArtSpecz243";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs243").src = tripleZeroA;
};

function squareToSzzZValue244(){
    value30Save = "zSqrArtSpecz244";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs244").src = tripleZeroA;
};

function squareToSzzZValue245(){
    value30Save = "zSqrArtSpecz245";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs245").src = tripleZeroA;
};

function squareToSzzZValue246(){
    value30Save = "zSqrArtSpecz246";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs246").src = tripleZeroA;
};

function squareToSzzZValue247(){
    value30Save = "zSqrArtSpecz247";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs247").src = tripleZeroA;
};

function squareToSzzZValue248(){
    value30Save = "zSqrArtSpecz248";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs248").src = tripleZeroA;
};

function squareToSzzZValue249(){
    value30Save = "zSqrArtSpecz249";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs249").src = tripleZeroA;
};

function squareToSzzZValue250(){
    value30Save = "zSqrArtSpecz250";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs250").src = tripleZeroA;
};

function squareToSzzZValue251(){
    value30Save = "zSqrArtSpecz251";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs251").src = tripleZeroA;
};

function squareToSzzZValue252(){
    value30Save = "zSqrArtSpecz252";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs252").src = tripleZeroA;
};

function squareToSzzZValue253(){
    value30Save = "zSqrArtSpecz253";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs253").src = tripleZeroA;
};

function squareToSzzZValue254(){
    value30Save = "zSqrArtSpecz254";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs254").src = tripleZeroA;
};

function squareToSzzZValue255(){
    value30Save = "zSqrArtSpecz255";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs255").src = tripleZeroA;
};

function squareToSzzZValue256(){
    value30Save = "zSqrArtSpecz256";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs256").src = tripleZeroA;
};

function squareToSzzZValue257(){
    value30Save = "zSqrArtSpecz257";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs257").src = tripleZeroA;
};

function squareToSzzZValue258(){
    value30Save = "zSqrArtSpecz258";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs258").src = tripleZeroA;
};

function squareToSzzZValue259(){
    value30Save = "zSqrArtSpecz259";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs259").src = tripleZeroA;
};

function squareToSzzZValue260(){
    value30Save = "zSqrArtSpecz260";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs260").src = tripleZeroA;
};

function squareToSzzZValue261(){
    value30Save = "zSqrArtSpecz261";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs261").src = tripleZeroA;
};

function squareToSzzZValue262(){
    value30Save = "zSqrArtSpecz262";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs262").src = tripleZeroA;
};

function squareToSzzZValue263(){
    value30Save = "zSqrArtSpecz263";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs263").src = tripleZeroA;
};

function squareToSzzZValue264(){
    value30Save = "zSqrArtSpecz264";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs264").src = tripleZeroA;
};

function squareToSzzZValue265(){
    value30Save = "zSqrArtSpecz265";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs265").src = tripleZeroA;
};

function squareToSzzZValue266(){
    value30Save = "zSqrArtSpecz266";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs266").src = tripleZeroA;
};

function squareToSzzZValue267(){
    value30Save = "zSqrArtSpecz267";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs267").src = tripleZeroA;
};

function squareToSzzZValue268(){
    value30Save = "zSqrArtSpecz268";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs268").src = tripleZeroA;
};

function squareToSzzZValue269(){
    value30Save = "zSqrArtSpecz269";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs269").src = tripleZeroA;
};

function squareToSzzZValue270(){
    value30Save = "zSqrArtSpecz270";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs270").src = tripleZeroA;
};

function squareToSzzZValue271(){
    value30Save = "zSqrArtSpecz271";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs271").src = tripleZeroA;
};

function squareToSzzZValue272(){
    value30Save = "zSqrArtSpecz272";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs272").src = tripleZeroA;
};

function squareToSzzZValue273(){
    value30Save = "zSqrArtSpecz273";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs273").src = tripleZeroA;
};

function squareToSzzZValue274(){
    value30Save = "zSqrArtSpecz274";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs274").src = tripleZeroA;
};

function squareToSzzZValue275(){
    value30Save = "zSqrArtSpecz275";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs275").src = tripleZeroA;
};

function squareToSzzZValue276(){
    value30Save = "zSqrArtSpecz276";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs276").src = tripleZeroA;
};

function squareToSzzZValue277(){
    value30Save = "zSqrArtSpecz277";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs277").src = tripleZeroA;
};

function squareToSzzZValue278(){
    value30Save = "zSqrArtSpecz278";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs278").src = tripleZeroA;
};

function squareToSzzZValue279(){
    value30Save = "zSqrArtSpecz279";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs279").src = tripleZeroA;
};

function squareToSzzZValue280(){
    value30Save = "zSqrArtSpecz280";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs280").src = tripleZeroA;
};

function squareToSzzZValue281(){
    value30Save = "zSqrArtSpecz281";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs281").src = tripleZeroA;
};

function squareToSzzZValue282(){
    value30Save = "zSqrArtSpecz282";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs282").src = tripleZeroA;
};

function squareToSzzZValue283(){
    value30Save = "zSqrArtSpecz283";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs283").src = tripleZeroA;
};

function squareToSzzZValue284(){
    value30Save = "zSqrArtSpecz284";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs284").src = tripleZeroA;
};

function squareToSzzZValue285(){
    value30Save = "zSqrArtSpecz285";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs285").src = tripleZeroA;
};

function squareToSzzZValue286(){
    value30Save = "zSqrArtSpecz286";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs286").src = tripleZeroA;
};

function squareToSzzZValue287(){
    value30Save = "zSqrArtSpecz287";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs287").src = tripleZeroA;
};

function squareToSzzZValue288(){
    value30Save = "zSqrArtSpecz288";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs288").src = tripleZeroA;
};

function squareToSzzZValue289(){
    value30Save = "zSqrArtSpecz289";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs289").src = tripleZeroA;
};

function squareToSzzZValue290(){
    value30Save = "zSqrArtSpecz290";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs290").src = tripleZeroA;
};

function squareToSzzZValue291(){
    value30Save = "zSqrArtSpecz291";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs291").src = tripleZeroA;
};

function squareToSzzZValue292(){
    value30Save = "zSqrArtSpecz292";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs292").src = tripleZeroA;
};

function squareToSzzZValue293(){
    value30Save = "zSqrArtSpecz293";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs293").src = tripleZeroA;
};

function squareToSzzZValue294(){
    value30Save = "zSqrArtSpecz294";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs294").src = tripleZeroA;
};

function squareToSzzZValue295(){
    value30Save = "zSqrArtSpecz295";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs295").src = tripleZeroA;
};

function squareToSzzZValue296(){
    value30Save = "zSqrArtSpecz296";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs296").src = tripleZeroA;
};

function squareToSzzZValue297(){
    value30Save = "zSqrArtSpecz297";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs297").src = tripleZeroA;
};

function squareToSzzZValue298(){
    value30Save = "zSqrArtSpecz298";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs298").src = tripleZeroA;
};

function squareToSzzZValue299(){
    value30Save = "zSqrArtSpecz299";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs299").src = tripleZeroA;
};

function squareToSzzZValue300(){
    value30Save = "zSqrArtSpecz300";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs300").src = tripleZeroA;
};

function squareToSzzZValue301(){
    value30Save = "zSqrArtSpecz301";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs301").src = tripleZeroA;
};

function squareToSzzZValue302(){
    value30Save = "zSqrArtSpecz302";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs302").src = tripleZeroA;
};

function squareToSzzZValue303(){
    value30Save = "zSqrArtSpecz303";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs303").src = tripleZeroA;
};

function squareToSzzZValue304(){
    value30Save = "zSqrArtSpecz304";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs304").src = tripleZeroA;
};

function squareToSzzZValue305(){
    value30Save = "zSqrArtSpecz305";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs305").src = tripleZeroA;
};

function squareToSzzZValue306(){
    value30Save = "zSqrArtSpecz306";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs306").src = tripleZeroA;
};

function squareToSzzZValue307(){
    value30Save = "zSqrArtSpecz307";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs307").src = tripleZeroA;
};

function squareToSzzZValue308(){
    value30Save = "zSqrArtSpecz308";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs308").src = tripleZeroA;
};

function squareToSzzZValue309(){
    value30Save = "zSqrArtSpecz309";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs309").src = tripleZeroA;
};

function squareToSzzZValue310(){
    value30Save = "zSqrArtSpecz310";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs310").src = tripleZeroA;
};

function squareToSzzZValue311(){
    value30Save = "zSqrArtSpecz311";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs311").src = tripleZeroA;
};

function squareToSzzZValue312(){
    value30Save = "zSqrArtSpecz312";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs312").src = tripleZeroA;
};

function squareToSzzZValue313(){
    value30Save = "zSqrArtSpecz313";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs313").src = tripleZeroA;
};

function squareToSzzZValue314(){
    value30Save = "zSqrArtSpecz314";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs314").src = tripleZeroA;
};

function squareToSzzZValue315(){
    value30Save = "zSqrArtSpecz315";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs315").src = tripleZeroA;
};

function squareToSzzZValue316(){
    value30Save = "zSqrArtSpecz316";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs316").src = tripleZeroA;
};

function squareToSzzZValue317(){
    value30Save = "zSqrArtSpecz317";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs317").src = tripleZeroA;
};

function squareToSzzZValue318(){
    value30Save = "zSqrArtSpecz318";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs318").src = tripleZeroA;
};

function squareToSzzZValue319(){
    value30Save = "zSqrArtSpecz319";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs319").src = tripleZeroA;
};

function squareToSzzZValue320(){
    value30Save = "zSqrArtSpecz320";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs320").src = tripleZeroA;
};

function squareToSzzZValue321(){
    value30Save = "zSqrArtSpecz321";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs321").src = tripleZeroA;
};

function squareToSzzZValue322(){
    value30Save = "zSqrArtSpecz322";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs322").src = tripleZeroA;
};

function squareToSzzZValue323(){
    value30Save = "zSqrArtSpecz323";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs323").src = tripleZeroA;
};

function squareToSzzZValue324(){
    value30Save = "zSqrArtSpecz324";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs324").src = tripleZeroA;
};

function squareToSzzZValue325(){
    value30Save = "zSqrArtSpecz325";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs325").src = tripleZeroA;
};

function squareToSzzZValue326(){
    value30Save = "zSqrArtSpecz326";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs326").src = tripleZeroA;
};

function squareToSzzZValue327(){
    value30Save = "zSqrArtSpecz327";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs327").src = tripleZeroA;
};

function squareToSzzZValue328(){
    value30Save = "zSqrArtSpecz328";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs328").src = tripleZeroA;
};

function squareToSzzZValue329(){
    value30Save = "zSqrArtSpecz329";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs329").src = tripleZeroA;
};

function squareToSzzZValue330(){
    value30Save = "zSqrArtSpecz330";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs330").src = tripleZeroA;
};

function squareToSzzZValue331(){
    value30Save = "zSqrArtSpecz331";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs331").src = tripleZeroA;
};

function squareToSzzZValue332(){
    value30Save = "zSqrArtSpecz332";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs332").src = tripleZeroA;
};

function squareToSzzZValue333(){
    value30Save = "zSqrArtSpecz333";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs333").src = tripleZeroA;
};

function squareToSzzZValue334(){
    value30Save = "zSqrArtSpecz334";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs334").src = tripleZeroA;
};

function squareToSzzZValue335(){
    value30Save = "zSqrArtSpecz335";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs335").src = tripleZeroA;
};

function squareToSzzZValue336(){
    value30Save = "zSqrArtSpecz336";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs336").src = tripleZeroA;
};

function squareToSzzZValue337(){
    value30Save = "zSqrArtSpecz337";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs337").src = tripleZeroA;
};

function squareToSzzZValue338(){
    value30Save = "zSqrArtSpecz338";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs338").src = tripleZeroA;
};

function squareToSzzZValue339(){
    value30Save = "zSqrArtSpecz339";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs339").src = tripleZeroA;
};

function squareToSzzZValue340(){
    value30Save = "zSqrArtSpecz340";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs340").src = tripleZeroA;
};

function squareToSzzZValue341(){
    value30Save = "zSqrArtSpecz341";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs341").src = tripleZeroA;
};

function squareToSzzZValue342(){
    value30Save = "zSqrArtSpecz342";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs342").src = tripleZeroA;
};

function squareToSzzZValue343(){
    value30Save = "zSqrArtSpecz343";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs343").src = tripleZeroA;
};

function squareToSzzZValue344(){
    value30Save = "zSqrArtSpecz344";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs344").src = tripleZeroA;
};

function squareToSzzZValue345(){
    value30Save = "zSqrArtSpecz345";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs345").src = tripleZeroA;
};

function squareToSzzZValue346(){
    value30Save = "zSqrArtSpecz346";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs346").src = tripleZeroA;
};

function squareToSzzZValue347(){
    value30Save = "zSqrArtSpecz347";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs347").src = tripleZeroA;
};

function squareToSzzZValue348(){
    value30Save = "zSqrArtSpecz348";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs348").src = tripleZeroA;
};

function squareToSzzZValue349(){
    value30Save = "zSqrArtSpecz349";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs349").src = tripleZeroA;
};

function squareToSzzZValue350(){
    value30Save = "zSqrArtSpecz350";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs350").src = tripleZeroA;
};

function squareToSzzZValue351(){
    value30Save = "zSqrArtSpecz351";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs351").src = tripleZeroA;
};

function squareToSzzZValue352(){
    value30Save = "zSqrArtSpecz352";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs352").src = tripleZeroA;
};

function squareToSzzZValue353(){
    value30Save = "zSqrArtSpecz353";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs353").src = tripleZeroA;
};

function squareToSzzZValue354(){
    value30Save = "zSqrArtSpecz354";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs354").src = tripleZeroA;
};

function squareToSzzZValue355(){
    value30Save = "zSqrArtSpecz355";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs355").src = tripleZeroA;
};

function squareToSzzZValue356(){
    value30Save = "zSqrArtSpecz356";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs356").src = tripleZeroA;
};

function squareToSzzZValue357(){
    value30Save = "zSqrArtSpecz357";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs357").src = tripleZeroA;
};

function squareToSzzZValue358(){
    value30Save = "zSqrArtSpecz358";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs358").src = tripleZeroA;
};

function squareToSzzZValue359(){
    value30Save = "zSqrArtSpecz359";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs359").src = tripleZeroA;
};

function squareToSzzZValue360(){
    value30Save = "zSqrArtSpecz360";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs360").src = tripleZeroA;
};

function squareToSzzZValue361(){
    value30Save = "zSqrArtSpecz361";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs361").src = tripleZeroA;
};

function squareToSzzZValue362(){
    value30Save = "zSqrArtSpecz362";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs362").src = tripleZeroA;
};

function squareToSzzZValue363(){
    value30Save = "zSqrArtSpecz363";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs363").src = tripleZeroA;
};

function squareToSzzZValue364(){
    value30Save = "zSqrArtSpecz364";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs364").src = tripleZeroA;
};

function squareToSzzZValue365(){
    value30Save = "zSqrArtSpecz365";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs365").src = tripleZeroA;
};

function squareToSzzZValue366(){
    value30Save = "zSqrArtSpecz366";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs366").src = tripleZeroA;
};

function squareToSzzZValue367(){
    value30Save = "zSqrArtSpecz367";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs367").src = tripleZeroA;
};

function squareToSzzZValue368(){
    value30Save = "zSqrArtSpecz368";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs368").src = tripleZeroA;
};

function squareToSzzZValue369(){
    value30Save = "zSqrArtSpecz369";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs369").src = tripleZeroA;
};

function squareToSzzZValue370(){
    value30Save = "zSqrArtSpecz370";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs370").src = tripleZeroA;
};

function squareToSzzZValue371(){
    value30Save = "zSqrArtSpecz371";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs371").src = tripleZeroA;
};

function squareToSzzZValue372(){
    value30Save = "zSqrArtSpecz372";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs372").src = tripleZeroA;
};

function squareToSzzZValue373(){
    value30Save = "zSqrArtSpecz373";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs373").src = tripleZeroA;
};

function squareToSzzZValue374(){
    value30Save = "zSqrArtSpecz374";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs374").src = tripleZeroA;
};

function squareToSzzZValue375(){
    value30Save = "zSqrArtSpecz375";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs375").src = tripleZeroA;
};

function squareToSzzZValue376(){
    value30Save = "zSqrArtSpecz376";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs376").src = tripleZeroA;
};

function squareToSzzZValue377(){
    value30Save = "zSqrArtSpecz377";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs377").src = tripleZeroA;
};

function squareToSzzZValue378(){
    value30Save = "zSqrArtSpecz378";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs378").src = tripleZeroA;
};

function squareToSzzZValue379(){
    value30Save = "zSqrArtSpecz379";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs379").src = tripleZeroA;
};

function squareToSzzZValue380(){
    value30Save = "zSqrArtSpecz380";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs380").src = tripleZeroA;
};

function squareToSzzZValue381(){
    value30Save = "zSqrArtSpecz381";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs381").src = tripleZeroA;
};

function squareToSzzZValue382(){
    value30Save = "zSqrArtSpecz382";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs382").src = tripleZeroA;
};

function squareToSzzZValue383(){
    value30Save = "zSqrArtSpecz383";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs383").src = tripleZeroA;
};

function squareToSzzZValue384(){
    value30Save = "zSqrArtSpecz384";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs384").src = tripleZeroA;
};

function squareToSzzZValue385(){
    value30Save = "zSqrArtSpecz385";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs385").src = tripleZeroA;
};

function squareToSzzZValue386(){
    value30Save = "zSqrArtSpecz386";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs386").src = tripleZeroA;
};

function squareToSzzZValue387(){
    value30Save = "zSqrArtSpecz387";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs387").src = tripleZeroA;
};

function squareToSzzZValue388(){
    value30Save = "zSqrArtSpecz388";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs388").src = tripleZeroA;
};

function squareToSzzZValue389(){
    value30Save = "zSqrArtSpecz389";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs389").src = tripleZeroA;
};

function squareToSzzZValue390(){
    value30Save = "zSqrArtSpecz390";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs390").src = tripleZeroA;
};

function squareToSzzZValue391(){
    value30Save = "zSqrArtSpecz391";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs391").src = tripleZeroA;
};

function squareToSzzZValue392(){
    value30Save = "zSqrArtSpecz392";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs392").src = tripleZeroA;
};

function squareToSzzZValue393(){
    value30Save = "zSqrArtSpecz393";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs393").src = tripleZeroA;
};

function squareToSzzZValue394(){
    value30Save = "zSqrArtSpecz394";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs394").src = tripleZeroA;
};

function squareToSzzZValue395(){
    value30Save = "zSqrArtSpecz395";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs395").src = tripleZeroA;
};

function squareToSzzZValue396(){
    value30Save = "zSqrArtSpecz396";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs396").src = tripleZeroA;
};

function squareToSzzZValue397(){
    value30Save = "zSqrArtSpecz397";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs397").src = tripleZeroA;
};

function squareToSzzZValue398(){
    value30Save = "zSqrArtSpecz398";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs398").src = tripleZeroA;
};

function squareToSzzZValue399(){
    value30Save = "zSqrArtSpecz399";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs399").src = tripleZeroA;
};

function squareToSzzZValue400(){
    value30Save = "zSqrArtSpecz400";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs400").src = tripleZeroA;
};

function squareToSzzZValue401(){
    value30Save = "zSqrArtSpecz401";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs401").src = tripleZeroA;
};

function squareToSzzZValue402(){
    value30Save = "zSqrArtSpecz402";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs402").src = tripleZeroA;
};

function squareToSzzZValue403(){
    value30Save = "zSqrArtSpecz403";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs403").src = tripleZeroA;
};

function squareToSzzZValue404(){
    value30Save = "zSqrArtSpecz404";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs404").src = tripleZeroA;
};

function squareToSzzZValue405(){
    value30Save = "zSqrArtSpecz405";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs405").src = tripleZeroA;
};

function squareToSzzZValue406(){
    value30Save = "zSqrArtSpecz406";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs406").src = tripleZeroA;
};

function squareToSzzZValue407(){
    value30Save = "zSqrArtSpecz407";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs407").src = tripleZeroA;
};

function squareToSzzZValue408(){
    value30Save = "zSqrArtSpecz408";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs408").src = tripleZeroA;
};

function squareToSzzZValue409(){
    value30Save = "zSqrArtSpecz409";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs409").src = tripleZeroA;
};

function squareToSzzZValue410(){
    value30Save = "zSqrArtSpecz410";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs410").src = tripleZeroA;
};

function squareToSzzZValue411(){
    value30Save = "zSqrArtSpecz411";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs411").src = tripleZeroA;
};

function squareToSzzZValue412(){
    value30Save = "zSqrArtSpecz412";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs412").src = tripleZeroA;
};

function squareToSzzZValue413(){
    value30Save = "zSqrArtSpecz413";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs413").src = tripleZeroA;
};

function squareToSzzZValue414(){
    value30Save = "zSqrArtSpecz414";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs414").src = tripleZeroA;
};

function squareToSzzZValue415(){
    value30Save = "zSqrArtSpecz415";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs415").src = tripleZeroA;
};

function squareToSzzZValue416(){
    value30Save = "zSqrArtSpecz416";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs416").src = tripleZeroA;
};

function squareToSzzZValue417(){
    value30Save = "zSqrArtSpecz417";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs417").src = tripleZeroA;
};

function squareToSzzZValue418(){
    value30Save = "zSqrArtSpecz418";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs418").src = tripleZeroA;
};

function squareToSzzZValue419(){
    value30Save = "zSqrArtSpecz419";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs419").src = tripleZeroA;
};

function squareToSzzZValue420(){
    value30Save = "zSqrArtSpecz420";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs420").src = tripleZeroA;
};

function squareToSzzZValue421(){
    value30Save = "zSqrArtSpecz421";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs421").src = tripleZeroA;
};

function squareToSzzZValue422(){
    value30Save = "zSqrArtSpecz422";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs422").src = tripleZeroA;
};

function squareToSzzZValue423(){
    value30Save = "zSqrArtSpecz423";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs423").src = tripleZeroA;
};

function squareToSzzZValue424(){
    value30Save = "zSqrArtSpecz424";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs424").src = tripleZeroA;
};

function squareToSzzZValue425(){
    value30Save = "zSqrArtSpecz425";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs425").src = tripleZeroA;
};

function squareToSzzZValue426(){
    value30Save = "zSqrArtSpecz426";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs426").src = tripleZeroA;
};

function squareToSzzZValue427(){
    value30Save = "zSqrArtSpecz427";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs427").src = tripleZeroA;
};

function squareToSzzZValue428(){
    value30Save = "zSqrArtSpecz428";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs428").src = tripleZeroA;
};

function squareToSzzZValue429(){
    value30Save = "zSqrArtSpecz429";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs429").src = tripleZeroA;
};

function squareToSzzZValue430(){
    value30Save = "zSqrArtSpecz430";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs430").src = tripleZeroA;
};

function squareToSzzZValue431(){
    value30Save = "zSqrArtSpecz431";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs431").src = tripleZeroA;
};

function squareToSzzZValue432(){
    value30Save = "zSqrArtSpecz432";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs432").src = tripleZeroA;
};

function squareToSzzZValue433(){
    value30Save = "zSqrArtSpecz433";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs433").src = tripleZeroA;
};

function squareToSzzZValue434(){
    value30Save = "zSqrArtSpecz434";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs434").src = tripleZeroA;
};

function squareToSzzZValue435(){
    value30Save = "zSqrArtSpecz435";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs435").src = tripleZeroA;
};

function squareToSzzZValue436(){
    value30Save = "zSqrArtSpecz436";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs436").src = tripleZeroA;
};

function squareToSzzZValue437(){
    value30Save = "zSqrArtSpecz437";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs437").src = tripleZeroA;
};

function squareToSzzZValue438(){
    value30Save = "zSqrArtSpecz438";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs438").src = tripleZeroA;
};

function squareToSzzZValue439(){
    value30Save = "zSqrArtSpecz439";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs439").src = tripleZeroA;
};

function squareToSzzZValue440(){
    value30Save = "zSqrArtSpecz440";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs440").src = tripleZeroA;
};

function squareToSzzZValue441(){
    value30Save = "zSqrArtSpecz441";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs441").src = tripleZeroA;
};

function squareToSzzZValue442(){
    value30Save = "zSqrArtSpecz442";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs442").src = tripleZeroA;
};

function squareToSzzZValue443(){
    value30Save = "zSqrArtSpecz443";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs443").src = tripleZeroA;
};

function squareToSzzZValue444(){
    value30Save = "zSqrArtSpecz444";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs444").src = tripleZeroA;
};

function squareToSzzZValue445(){
    value30Save = "zSqrArtSpecz445";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs445").src = tripleZeroA;
};

function squareToSzzZValue446(){
    value30Save = "zSqrArtSpecz446";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs446").src = tripleZeroA;
};

function squareToSzzZValue447(){
    value30Save = "zSqrArtSpecz447";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs447").src = tripleZeroA;
};

function squareToSzzZValue448(){
    value30Save = "zSqrArtSpecz448";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs448").src = tripleZeroA;
};

function squareToSzzZValue449(){
    value30Save = "zSqrArtSpecz449";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs449").src = tripleZeroA;
};

function squareToSzzZValue450(){
    value30Save = "zSqrArtSpecz450";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs450").src = tripleZeroA;
};

function squareToSzzZValue451(){
    value30Save = "zSqrArtSpecz451";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs451").src = tripleZeroA;
};

function squareToSzzZValue452(){
    value30Save = "zSqrArtSpecz452";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs452").src = tripleZeroA;
};

function squareToSzzZValue453(){
    value30Save = "zSqrArtSpecz453";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs453").src = tripleZeroA;
};

function squareToSzzZValue454(){
    value30Save = "zSqrArtSpecz454";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs454").src = tripleZeroA;
};

function squareToSzzZValue455(){
    value30Save = "zSqrArtSpecz455";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs455").src = tripleZeroA;
};

function squareToSzzZValue456(){
    value30Save = "zSqrArtSpecz456";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs456").src = tripleZeroA;
};

function squareToSzzZValue457(){
    value30Save = "zSqrArtSpecz457";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs457").src = tripleZeroA;
};

function squareToSzzZValue458(){
    value30Save = "zSqrArtSpecz458";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs458").src = tripleZeroA;
};

function squareToSzzZValue459(){
    value30Save = "zSqrArtSpecz459";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs459").src = tripleZeroA;
};

function squareToSzzZValue460(){
    value30Save = "zSqrArtSpecz460";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs460").src = tripleZeroA;
};

function squareToSzzZValue461(){
    value30Save = "zSqrArtSpecz461";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs461").src = tripleZeroA;
};

function squareToSzzZValue462(){
    value30Save = "zSqrArtSpecz462";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs462").src = tripleZeroA;
};

function squareToSzzZValue463(){
    value30Save = "zSqrArtSpecz463";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs463").src = tripleZeroA;
};

function squareToSzzZValue464(){
    value30Save = "zSqrArtSpecz464";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs464").src = tripleZeroA;
};

function squareToSzzZValue465(){
    value30Save = "zSqrArtSpecz465";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs465").src = tripleZeroA;
};

function squareToSzzZValue466(){
    value30Save = "zSqrArtSpecz466";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs466").src = tripleZeroA;
};

function squareToSzzZValue467(){
    value30Save = "zSqrArtSpecz467";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs467").src = tripleZeroA;
};

function squareToSzzZValue468(){
    value30Save = "zSqrArtSpecz468";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs468").src = tripleZeroA;
};

function squareToSzzZValue469(){
    value30Save = "zSqrArtSpecz469";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs469").src = tripleZeroA;
};

function squareToSzzZValue470(){
    value30Save = "zSqrArtSpecz470";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs470").src = tripleZeroA;
};

function squareToSzzZValue471(){
    value30Save = "zSqrArtSpecz471";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs471").src = tripleZeroA;
};

function squareToSzzZValue472(){
    value30Save = "zSqrArtSpecz472";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs472").src = tripleZeroA;
};

function squareToSzzZValue473(){
    value30Save = "zSqrArtSpecz473";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs473").src = tripleZeroA;
};

function squareToSzzZValue474(){
    value30Save = "zSqrArtSpecz474";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs474").src = tripleZeroA;
};

function squareToSzzZValue475(){
    value30Save = "zSqrArtSpecz475";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs475").src = tripleZeroA;
};

function squareToSzzZValue476(){
    value30Save = "zSqrArtSpecz476";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs476").src = tripleZeroA;
};

function squareToSzzZValue477(){
    value30Save = "zSqrArtSpecz477";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs477").src = tripleZeroA;
};

function squareToSzzZValue478(){
    value30Save = "zSqrArtSpecz478";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs478").src = tripleZeroA;
};

function squareToSzzZValue479(){
    value30Save = "zSqrArtSpecz479";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs479").src = tripleZeroA;
};

function squareToSzzZValue480(){
    value30Save = "zSqrArtSpecz480";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs480").src = tripleZeroA;
};

function squareToSzzZValue481(){
    value30Save = "zSqrArtSpecz481";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs481").src = tripleZeroA;
};

function squareToSzzZValue482(){
    value30Save = "zSqrArtSpecz482";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs482").src = tripleZeroA;
};

function squareToSzzZValue483(){
    value30Save = "zSqrArtSpecz483";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs483").src = tripleZeroA;
};

function squareToSzzZValue484(){
    value30Save = "zSqrArtSpecz484";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs484").src = tripleZeroA;
};

function squareToSzzZValue485(){
    value30Save = "zSqrArtSpecz485";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs485").src = tripleZeroA;
};

function squareToSzzZValue486(){
    value30Save = "zSqrArtSpecz486";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs486").src = tripleZeroA;
};

function squareToSzzZValue487(){
    value30Save = "zSqrArtSpecz487";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs487").src = tripleZeroA;
};

function squareToSzzZValue488(){
    value30Save = "zSqrArtSpecz488";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs488").src = tripleZeroA;
};

function squareToSzzZValue489(){
    value30Save = "zSqrArtSpecz489";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs489").src = tripleZeroA;
};

function squareToSzzZValue490(){
    value30Save = "zSqrArtSpecz490";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs490").src = tripleZeroA;
};

function squareToSzzZValue491(){
    value30Save = "zSqrArtSpecz491";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs491").src = tripleZeroA;
};

function squareToSzzZValue492(){
    value30Save = "zSqrArtSpecz492";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs492").src = tripleZeroA;
};

function squareToSzzZValue493(){
    value30Save = "zSqrArtSpecz493";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs493").src = tripleZeroA;
};

function squareToSzzZValue494(){
    value30Save = "zSqrArtSpecz494";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs494").src = tripleZeroA;
};

function squareToSzzZValue495(){
    value30Save = "zSqrArtSpecz495";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs495").src = tripleZeroA;
};

function squareToSzzZValue496(){
    value30Save = "zSqrArtSpecz496";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs496").src = tripleZeroA;
};

function squareToSzzZValue497(){
    value30Save = "zSqrArtSpecz497";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs497").src = tripleZeroA;
};

function squareToSzzZValue498(){
    value30Save = "zSqrArtSpecz498";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs498").src = tripleZeroA;
};

function squareToSzzZValue499(){
    value30Save = "zSqrArtSpecz499";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs499").src = tripleZeroA;
};

function squareToSzzZValue500(){
    value30Save = "zSqrArtSpecz500";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs500").src = tripleZeroA;
};

function squareToSzzZValue501(){
    value30Save = "zSqrArtSpecz501";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs501").src = tripleZeroA;
};

function squareToSzzZValue502(){
    value30Save = "zSqrArtSpecz502";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs502").src = tripleZeroA;
};

function squareToSzzZValue503(){
    value30Save = "zSqrArtSpecz503";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs503").src = tripleZeroA;
};

function squareToSzzZValue504(){
    value30Save = "zSqrArtSpecz504";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs504").src = tripleZeroA;
};

function squareToSzzZValue505(){
    value30Save = "zSqrArtSpecz505";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs505").src = tripleZeroA;
};

function squareToSzzZValue506(){
    value30Save = "zSqrArtSpecz506";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs506").src = tripleZeroA;
};

function squareToSzzZValue507(){
    value30Save = "zSqrArtSpecz507";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs507").src = tripleZeroA;
};

function squareToSzzZValue508(){
    value30Save = "zSqrArtSpecz508";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs508").src = tripleZeroA;
};

function squareToSzzZValue509(){
    value30Save = "zSqrArtSpecz509";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs509").src = tripleZeroA;
};

function squareToSzzZValue510(){
    value30Save = "zSqrArtSpecz510";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs510").src = tripleZeroA;
};

function squareToSzzZValue511(){
    value30Save = "zSqrArtSpecz511";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs511").src = tripleZeroA;
};

function squareToSzzZValue512(){
    value30Save = "zSqrArtSpecz512";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs512").src = tripleZeroA;
};

function squareToSzzZValue513(){
    value30Save = "zSqrArtSpecz513";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs513").src = tripleZeroA;
};

function squareToSzzZValue514(){
    value30Save = "zSqrArtSpecz514";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs514").src = tripleZeroA;
};

function squareToSzzZValue515(){
    value30Save = "zSqrArtSpecz515";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs515").src = tripleZeroA;
};

function squareToSzzZValue516(){
    value30Save = "zSqrArtSpecz516";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs516").src = tripleZeroA;
};

function squareToSzzZValue517(){
    value30Save = "zSqrArtSpecz517";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs517").src = tripleZeroA;
};

function squareToSzzZValue518(){
    value30Save = "zSqrArtSpecz518";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs518").src = tripleZeroA;
};

function squareToSzzZValue519(){
    value30Save = "zSqrArtSpecz519";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs519").src = tripleZeroA;
};

function squareToSzzZValue520(){
    value30Save = "zSqrArtSpecz520";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs520").src = tripleZeroA;
};

function squareToSzzZValue521(){
    value30Save = "zSqrArtSpecz521";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs521").src = tripleZeroA;
};

function squareToSzzZValue522(){
    value30Save = "zSqrArtSpecz522";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs522").src = tripleZeroA;
};

function squareToSzzZValue523(){
    value30Save = "zSqrArtSpecz523";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs523").src = tripleZeroA;
};

function squareToSzzZValue524(){
    value30Save = "zSqrArtSpecz524";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs524").src = tripleZeroA;
};

function squareToSzzZValue525(){
    value30Save = "zSqrArtSpecz525";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs525").src = tripleZeroA;
};

function squareToSzzZValue526(){
    value30Save = "zSqrArtSpecz526";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs526").src = tripleZeroA;
};

function squareToSzzZValue527(){
    value30Save = "zSqrArtSpecz527";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs527").src = tripleZeroA;
};

function squareToSzzZValue528(){
    value30Save = "zSqrArtSpecz528";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs528").src = tripleZeroA;
};

function squareToSzzZValue529(){
    value30Save = "zSqrArtSpecz529";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs529").src = tripleZeroA;
};

function squareToSzzZValue530(){
    value30Save = "zSqrArtSpecz530";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs530").src = tripleZeroA;
};

function squareToSzzZValue531(){
    value30Save = "zSqrArtSpecz531";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs531").src = tripleZeroA;
};

function squareToSzzZValue532(){
    value30Save = "zSqrArtSpecz532";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs532").src = tripleZeroA;
};

function squareToSzzZValue533(){
    value30Save = "zSqrArtSpecz533";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs533").src = tripleZeroA;
};

function squareToSzzZValue534(){
    value30Save = "zSqrArtSpecz534";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs534").src = tripleZeroA;
};

function squareToSzzZValue535(){
    value30Save = "zSqrArtSpecz535";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs535").src = tripleZeroA;
};

function squareToSzzZValue536(){
    value30Save = "zSqrArtSpecz536";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs536").src = tripleZeroA;
};

function squareToSzzZValue537(){
    value30Save = "zSqrArtSpecz537";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs537").src = tripleZeroA;
};

function squareToSzzZValue538(){
    value30Save = "zSqrArtSpecz538";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs538").src = tripleZeroA;
};

function squareToSzzZValue539(){
    value30Save = "zSqrArtSpecz539";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs539").src = tripleZeroA;
};

function squareToSzzZValue540(){
    value30Save = "zSqrArtSpecz540";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs540").src = tripleZeroA;
};

function squareToSzzZValue541(){
    value30Save = "zSqrArtSpecz541";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs541").src = tripleZeroA;
};

function squareToSzzZValue542(){
    value30Save = "zSqrArtSpecz542";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs542").src = tripleZeroA;
};

function squareToSzzZValue543(){
    value30Save = "zSqrArtSpecz543";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs543").src = tripleZeroA;
};

function squareToSzzZValue544(){
    value30Save = "zSqrArtSpecz544";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs544").src = tripleZeroA;
};

function squareToSzzZValue545(){
    value30Save = "zSqrArtSpecz545";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs545").src = tripleZeroA;
};

function squareToSzzZValue546(){
    value30Save = "zSqrArtSpecz546";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs546").src = tripleZeroA;
};

function squareToSzzZValue547(){
    value30Save = "zSqrArtSpecz547";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs547").src = tripleZeroA;
};

function squareToSzzZValue548(){
    value30Save = "zSqrArtSpecz548";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs548").src = tripleZeroA;
};

function squareToSzzZValue549(){
    value30Save = "zSqrArtSpecz549";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs549").src = tripleZeroA;
};

function squareToSzzZValue550(){
    value30Save = "zSqrArtSpecz550";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs550").src = tripleZeroA;
};

function squareToSzzZValue551(){
    value30Save = "zSqrArtSpecz551";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs551").src = tripleZeroA;
};

function squareToSzzZValue552(){
    value30Save = "zSqrArtSpecz552";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs552").src = tripleZeroA;
};

function squareToSzzZValue553(){
    value30Save = "zSqrArtSpecz553";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs553").src = tripleZeroA;
};

function squareToSzzZValue554(){
    value30Save = "zSqrArtSpecz554";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs554").src = tripleZeroA;
};

function squareToSzzZValue555(){
    value30Save = "zSqrArtSpecz555";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs555").src = tripleZeroA;
};

function squareToSzzZValue556(){
    value30Save = "zSqrArtSpecz556";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs556").src = tripleZeroA;
};

function squareToSzzZValue557(){
    value30Save = "zSqrArtSpecz557";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs557").src = tripleZeroA;
};

function squareToSzzZValue558(){
    value30Save = "zSqrArtSpecz558";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs558").src = tripleZeroA;
};

function squareToSzzZValue559(){
    value30Save = "zSqrArtSpecz559";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs559").src = tripleZeroA;
};

function squareToSzzZValue560(){
    value30Save = "zSqrArtSpecz560";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs560").src = tripleZeroA;
};

function squareToSzzZValue561(){
    value30Save = "zSqrArtSpecz561";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs561").src = tripleZeroA;
};

function squareToSzzZValue562(){
    value30Save = "zSqrArtSpecz562";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs562").src = tripleZeroA;
};

function squareToSzzZValue563(){
    value30Save = "zSqrArtSpecz563";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs563").src = tripleZeroA;
};

function squareToSzzZValue564(){
    value30Save = "zSqrArtSpecz564";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs564").src = tripleZeroA;
};

function squareToSzzZValue565(){
    value30Save = "zSqrArtSpecz565";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs565").src = tripleZeroA;
};

function squareToSzzZValue566(){
    value30Save = "zSqrArtSpecz566";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs566").src = tripleZeroA;
};

function squareToSzzZValue567(){
    value30Save = "zSqrArtSpecz567";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs567").src = tripleZeroA;
};

function squareToSzzZValue568(){
    value30Save = "zSqrArtSpecz568";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs568").src = tripleZeroA;
};

function squareToSzzZValue569(){
    value30Save = "zSqrArtSpecz569";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs569").src = tripleZeroA;
};

function squareToSzzZValue570(){
    value30Save = "zSqrArtSpecz570";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs570").src = tripleZeroA;
};

function squareToSzzZValue571(){
    value30Save = "zSqrArtSpecz571";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs571").src = tripleZeroA;
};

function squareToSzzZValue572(){
    value30Save = "zSqrArtSpecz572";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs572").src = tripleZeroA;
};

function squareToSzzZValue573(){
    value30Save = "zSqrArtSpecz573";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs573").src = tripleZeroA;
};

function squareToSzzZValue574(){
    value30Save = "zSqrArtSpecz574";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs574").src = tripleZeroA;
};

function squareToSzzZValue575(){
    value30Save = "zSqrArtSpecz575";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs575").src = tripleZeroA;
};

function squareToSzzZValue576(){
    value30Save = "zSqrArtSpecz576";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs576").src = tripleZeroA;
};

function squareToSzzZValue577(){
    value30Save = "zSqrArtSpecz577";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs577").src = tripleZeroA;
};

function squareToSzzZValue578(){
    value30Save = "zSqrArtSpecz578";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs578").src = tripleZeroA;
};

function squareToSzzZValue579(){
    value30Save = "zSqrArtSpecz579";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs579").src = tripleZeroA;
};

function squareToSzzZValue580(){
    value30Save = "zSqrArtSpecz580";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs580").src = tripleZeroA;
};

function squareToSzzZValue581(){
    value30Save = "zSqrArtSpecz581";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs581").src = tripleZeroA;
};

function squareToSzzZValue582(){
    value30Save = "zSqrArtSpecz582";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs582").src = tripleZeroA;
};

function squareToSzzZValue583(){
    value30Save = "zSqrArtSpecz583";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs583").src = tripleZeroA;
};

function squareToSzzZValue584(){
    value30Save = "zSqrArtSpecz584";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs584").src = tripleZeroA;
};

function squareToSzzZValue585(){
    value30Save = "zSqrArtSpecz585";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs585").src = tripleZeroA;
};

function squareToSzzZValue586(){
    value30Save = "zSqrArtSpecz586";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs586").src = tripleZeroA;
};

function squareToSzzZValue587(){
    value30Save = "zSqrArtSpecz587";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs587").src = tripleZeroA;
};

function squareToSzzZValue588(){
    value30Save = "zSqrArtSpecz588";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs588").src = tripleZeroA;
};

function squareToSzzZValue589(){
    value30Save = "zSqrArtSpecz589";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs589").src = tripleZeroA;
};

function squareToSzzZValue590(){
    value30Save = "zSqrArtSpecz590";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs590").src = tripleZeroA;
};

function squareToSzzZValue591(){
    value30Save = "zSqrArtSpecz591";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs591").src = tripleZeroA;
};

function squareToSzzZValue592(){
    value30Save = "zSqrArtSpecz592";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs592").src = tripleZeroA;
};

function squareToSzzZValue593(){
    value30Save = "zSqrArtSpecz593";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs593").src = tripleZeroA;
};

function squareToSzzZValue594(){
    value30Save = "zSqrArtSpecz594";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs594").src = tripleZeroA;
};

function squareToSzzZValue595(){
    value30Save = "zSqrArtSpecz595";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs595").src = tripleZeroA;
};

function squareToSzzZValue596(){
    value30Save = "zSqrArtSpecz596";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs596").src = tripleZeroA;
};

function squareToSzzZValue597(){
    value30Save = "zSqrArtSpecz597";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs597").src = tripleZeroA;
};

function squareToSzzZValue598(){
    value30Save = "zSqrArtSpecz598";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs598").src = tripleZeroA;
};

function squareToSzzZValue599(){
    value30Save = "zSqrArtSpecz599";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs599").src = tripleZeroA;
};

function squareToSzzZValue600(){
    value30Save = "zSqrArtSpecz600";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs600").src = tripleZeroA;
};

function squareToSzzZValue601(){
    value30Save = "zSqrArtSpecz601";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs601").src = tripleZeroA;
};

function squareToSzzZValue602(){
    value30Save = "zSqrArtSpecz602";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs602").src = tripleZeroA;
};

function squareToSzzZValue603(){
    value30Save = "zSqrArtSpecz603";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs603").src = tripleZeroA;
};

function squareToSzzZValue604(){
    value30Save = "zSqrArtSpecz604";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs604").src = tripleZeroA;
};

function squareToSzzZValue605(){
    value30Save = "zSqrArtSpecz605";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs605").src = tripleZeroA;
};

function squareToSzzZValue606(){
    value30Save = "zSqrArtSpecz606";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs606").src = tripleZeroA;
};

function squareToSzzZValue607(){
    value30Save = "zSqrArtSpecz607";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs607").src = tripleZeroA;
};

function squareToSzzZValue608(){
    value30Save = "zSqrArtSpecz608";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs608").src = tripleZeroA;
};

function squareToSzzZValue609(){
    value30Save = "zSqrArtSpecz609";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs609").src = tripleZeroA;
};

function squareToSzzZValue610(){
    value30Save = "zSqrArtSpecz610";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs610").src = tripleZeroA;
};

function squareToSzzZValue611(){
    value30Save = "zSqrArtSpecz611";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs611").src = tripleZeroA;
};

function squareToSzzZValue612(){
    value30Save = "zSqrArtSpecz612";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs612").src = tripleZeroA;
};

function squareToSzzZValue613(){
    value30Save = "zSqrArtSpecz613";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs613").src = tripleZeroA;
};

function squareToSzzZValue614(){
    value30Save = "zSqrArtSpecz614";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs614").src = tripleZeroA;
};

function squareToSzzZValue615(){
    value30Save = "zSqrArtSpecz615";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs615").src = tripleZeroA;
};

function squareToSzzZValue616(){
    value30Save = "zSqrArtSpecz616";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs616").src = tripleZeroA;
};

function squareToSzzZValue617(){
    value30Save = "zSqrArtSpecz617";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs617").src = tripleZeroA;
};

function squareToSzzZValue618(){
    value30Save = "zSqrArtSpecz618";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs618").src = tripleZeroA;
};

function squareToSzzZValue619(){
    value30Save = "zSqrArtSpecz619";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs619").src = tripleZeroA;
};

function squareToSzzZValue620(){
    value30Save = "zSqrArtSpecz620";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs620").src = tripleZeroA;
};

function squareToSzzZValue621(){
    value30Save = "zSqrArtSpecz621";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs621").src = tripleZeroA;
};

function squareToSzzZValue622(){
    value30Save = "zSqrArtSpecz622";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs622").src = tripleZeroA;
};

function squareToSzzZValue623(){
    value30Save = "zSqrArtSpecz623";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs623").src = tripleZeroA;
};

function squareToSzzZValue624(){
    value30Save = "zSqrArtSpecz624";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs624").src = tripleZeroA;
};

function squareToSzzZValue625(){
    value30Save = "zSqrArtSpecz625";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs625").src = tripleZeroA;
};

function squareToSzzZValue626(){
    value30Save = "zSqrArtSpecz626";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs626").src = tripleZeroA;
};

function squareToSzzZValue627(){
    value30Save = "zSqrArtSpecz627";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs627").src = tripleZeroA;
};

function squareToSzzZValue628(){
    value30Save = "zSqrArtSpecz628";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs628").src = tripleZeroA;
};

function squareToSzzZValue629(){
    value30Save = "zSqrArtSpecz629";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs629").src = tripleZeroA;
};

function squareToSzzZValue630(){
    value30Save = "zSqrArtSpecz630";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs630").src = tripleZeroA;
};

function squareToSzzZValue631(){
    value30Save = "zSqrArtSpecz631";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs631").src = tripleZeroA;
};

function squareToSzzZValue632(){
    value30Save = "zSqrArtSpecz632";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs632").src = tripleZeroA;
};

function squareToSzzZValue633(){
    value30Save = "zSqrArtSpecz633";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs633").src = tripleZeroA;
};

function squareToSzzZValue634(){
    value30Save = "zSqrArtSpecz634";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs634").src = tripleZeroA;
};

function squareToSzzZValue635(){
    value30Save = "zSqrArtSpecz635";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs635").src = tripleZeroA;
};

function squareToSzzZValue636(){
    value30Save = "zSqrArtSpecz636";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs636").src = tripleZeroA;
};

function squareToSzzZValue637(){
    value30Save = "zSqrArtSpecz637";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs637").src = tripleZeroA;
};

function squareToSzzZValue638(){
    value30Save = "zSqrArtSpecz638";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs638").src = tripleZeroA;
};

function squareToSzzZValue639(){
    value30Save = "zSqrArtSpecz639";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs639").src = tripleZeroA;
};

function squareToSzzZValue640(){
    value30Save = "zSqrArtSpecz640";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs640").src = tripleZeroA;
};

function squareToSzzZValue641(){
    value30Save = "zSqrArtSpecz641";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs641").src = tripleZeroA;
};

function squareToSzzZValue642(){
    value30Save = "zSqrArtSpecz642";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs642").src = tripleZeroA;
};

function squareToSzzZValue643(){
    value30Save = "zSqrArtSpecz643";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs643").src = tripleZeroA;
};

function squareToSzzZValue644(){
    value30Save = "zSqrArtSpecz644";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs644").src = tripleZeroA;
};

function squareToSzzZValue645(){
    value30Save = "zSqrArtSpecz645";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs645").src = tripleZeroA;
};

function squareToSzzZValue646(){
    value30Save = "zSqrArtSpecz646";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs646").src = tripleZeroA;
};

function squareToSzzZValue647(){
    value30Save = "zSqrArtSpecz647";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs647").src = tripleZeroA;
};

function squareToSzzZValue648(){
    value30Save = "zSqrArtSpecz648";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs648").src = tripleZeroA;
};

function squareToSzzZValue649(){
    value30Save = "zSqrArtSpecz649";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs649").src = tripleZeroA;
};

function squareToSzzZValue650(){
    value30Save = "zSqrArtSpecz650";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs650").src = tripleZeroA;
};

function squareToSzzZValue651(){
    value30Save = "zSqrArtSpecz651";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs651").src = tripleZeroA;
};

function squareToSzzZValue652(){
    value30Save = "zSqrArtSpecz652";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs652").src = tripleZeroA;
};

function squareToSzzZValue653(){
    value30Save = "zSqrArtSpecz653";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs653").src = tripleZeroA;
};

function squareToSzzZValue654(){
    value30Save = "zSqrArtSpecz654";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs654").src = tripleZeroA;
};

function squareToSzzZValue655(){
    value30Save = "zSqrArtSpecz655";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs655").src = tripleZeroA;
};

function squareToSzzZValue656(){
    value30Save = "zSqrArtSpecz656";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs656").src = tripleZeroA;
};

function squareToSzzZValue657(){
    value30Save = "zSqrArtSpecz657";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs657").src = tripleZeroA;
};

function squareToSzzZValue658(){
    value30Save = "zSqrArtSpecz658";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs658").src = tripleZeroA;
};

function squareToSzzZValue659(){
    value30Save = "zSqrArtSpecz659";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs659").src = tripleZeroA;
};

function squareToSzzZValue660(){
    value30Save = "zSqrArtSpecz660";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs660").src = tripleZeroA;
};

function squareToSzzZValue661(){
    value30Save = "zSqrArtSpecz661";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs661").src = tripleZeroA;
};

function squareToSzzZValue662(){
    value30Save = "zSqrArtSpecz662";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs662").src = tripleZeroA;
};

function squareToSzzZValue663(){
    value30Save = "zSqrArtSpecz663";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs663").src = tripleZeroA;
};

function squareToSzzZValue664(){
    value30Save = "zSqrArtSpecz664";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs664").src = tripleZeroA;
};

function squareToSzzZValue665(){
    value30Save = "zSqrArtSpecz665";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs665").src = tripleZeroA;
};

function squareToSzzZValue666(){
    value30Save = "zSqrArtSpecz666";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs666").src = tripleZeroA;
};

function squareToSzzZValue667(){
    value30Save = "zSqrArtSpecz667";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs667").src = tripleZeroA;
};

function squareToSzzZValue668(){
    value30Save = "zSqrArtSpecz668";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs668").src = tripleZeroA;
};

function squareToSzzZValue669(){
    value30Save = "zSqrArtSpecz669";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs669").src = tripleZeroA;
};

function squareToSzzZValue670(){
    value30Save = "zSqrArtSpecz670";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs670").src = tripleZeroA;
};

function squareToSzzZValue671(){
    value30Save = "zSqrArtSpecz671";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs671").src = tripleZeroA;
};

function squareToSzzZValue672(){
    value30Save = "zSqrArtSpecz672";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs672").src = tripleZeroA;
};

function squareToSzzZValue673(){
    value30Save = "zSqrArtSpecz673";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs673").src = tripleZeroA;
};

function squareToSzzZValue674(){
    value30Save = "zSqrArtSpecz674";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs674").src = tripleZeroA;
};

function squareToSzzZValue675(){
    value30Save = "zSqrArtSpecz675";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs675").src = tripleZeroA;
};

function squareToSzzZValue676(){
    value30Save = "zSqrArtSpecz676";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs676").src = tripleZeroA;
};

function squareToSzzZValue677(){
    value30Save = "zSqrArtSpecz677";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs677").src = tripleZeroA;
};

function squareToSzzZValue678(){
    value30Save = "zSqrArtSpecz678";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs678").src = tripleZeroA;
};

function squareToSzzZValue679(){
    value30Save = "zSqrArtSpecz679";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs679").src = tripleZeroA;
};

function squareToSzzZValue680(){
    value30Save = "zSqrArtSpecz680";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs680").src = tripleZeroA;
};

function squareToSzzZValue681(){
    value30Save = "zSqrArtSpecz681";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs681").src = tripleZeroA;
};

function squareToSzzZValue682(){
    value30Save = "zSqrArtSpecz682";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs682").src = tripleZeroA;
};

function squareToSzzZValue683(){
    value30Save = "zSqrArtSpecz683";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs683").src = tripleZeroA;
};

function squareToSzzZValue684(){
    value30Save = "zSqrArtSpecz684";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs684").src = tripleZeroA;
};

function squareToSzzZValue685(){
    value30Save = "zSqrArtSpecz685";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs685").src = tripleZeroA;
};

function squareToSzzZValue686(){
    value30Save = "zSqrArtSpecz686";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs686").src = tripleZeroA;
};

function squareToSzzZValue687(){
    value30Save = "zSqrArtSpecz687";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs687").src = tripleZeroA;
};

function squareToSzzZValue688(){
    value30Save = "zSqrArtSpecz688";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs688").src = tripleZeroA;
};

function squareToSzzZValue689(){
    value30Save = "zSqrArtSpecz689";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs689").src = tripleZeroA;
};

function squareToSzzZValue690(){
    value30Save = "zSqrArtSpecz690";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs690").src = tripleZeroA;
};

function squareToSzzZValue691(){
    value30Save = "zSqrArtSpecz691";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs691").src = tripleZeroA;
};

function squareToSzzZValue692(){
    value30Save = "zSqrArtSpecz692";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs692").src = tripleZeroA;
};

function squareToSzzZValue693(){
    value30Save = "zSqrArtSpecz693";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs693").src = tripleZeroA;
};

function squareToSzzZValue694(){
    value30Save = "zSqrArtSpecz694";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs694").src = tripleZeroA;
};

function squareToSzzZValue695(){
    value30Save = "zSqrArtSpecz695";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs695").src = tripleZeroA;
};

function squareToSzzZValue696(){
    value30Save = "zSqrArtSpecz696";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs696").src = tripleZeroA;
};

function squareToSzzZValue697(){
    value30Save = "zSqrArtSpecz697";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs697").src = tripleZeroA;
};

function squareToSzzZValue698(){
    value30Save = "zSqrArtSpecz698";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs698").src = tripleZeroA;
};

function squareToSzzZValue699(){
    value30Save = "zSqrArtSpecz699";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs699").src = tripleZeroA;
};

function squareToSzzZValue700(){
    value30Save = "zSqrArtSpecz700";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs700").src = tripleZeroA;
};

function squareToSzzZValue701(){
    value30Save = "zSqrArtSpecz701";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs701").src = tripleZeroA;
};

function squareToSzzZValue702(){
    value30Save = "zSqrArtSpecz702";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs702").src = tripleZeroA;
};

function squareToSzzZValue703(){
    value30Save = "zSqrArtSpecz703";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs703").src = tripleZeroA;
};

function squareToSzzZValue704(){
    value30Save = "zSqrArtSpecz704";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs704").src = tripleZeroA;
};

function squareToSzzZValue705(){
    value30Save = "zSqrArtSpecz705";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs705").src = tripleZeroA;
};

function squareToSzzZValue706(){
    value30Save = "zSqrArtSpecz706";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs706").src = tripleZeroA;
};

function squareToSzzZValue707(){
    value30Save = "zSqrArtSpecz707";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs707").src = tripleZeroA;
};

function squareToSzzZValue708(){
    value30Save = "zSqrArtSpecz708";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs708").src = tripleZeroA;
};

function squareToSzzZValue709(){
    value30Save = "zSqrArtSpecz709";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs709").src = tripleZeroA;
};

function squareToSzzZValue710(){
    value30Save = "zSqrArtSpecz710";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs710").src = tripleZeroA;
};

function squareToSzzZValue711(){
    value30Save = "zSqrArtSpecz711";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs711").src = tripleZeroA;
};

function squareToSzzZValue712(){
    value30Save = "zSqrArtSpecz712";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs712").src = tripleZeroA;
};

function squareToSzzZValue713(){
    value30Save = "zSqrArtSpecz713";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs713").src = tripleZeroA;
};

function squareToSzzZValue714(){
    value30Save = "zSqrArtSpecz714";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs714").src = tripleZeroA;
};

function squareToSzzZValue715(){
    value30Save = "zSqrArtSpecz715";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs715").src = tripleZeroA;
};

function squareToSzzZValue716(){
    value30Save = "zSqrArtSpecz716";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs716").src = tripleZeroA;
};

function squareToSzzZValue717(){
    value30Save = "zSqrArtSpecz717";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs717").src = tripleZeroA;
};

function squareToSzzZValue718(){
    value30Save = "zSqrArtSpecz718";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs718").src = tripleZeroA;
};

function squareToSzzZValue719(){
    value30Save = "zSqrArtSpecz719";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs719").src = tripleZeroA;
};

function squareToSzzZValue720(){
    value30Save = "zSqrArtSpecz720";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs720").src = tripleZeroA;
};

function squareToSzzZValue721(){
    value30Save = "zSqrArtSpecz721";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs721").src = tripleZeroA;
};

function squareToSzzZValue722(){
    value30Save = "zSqrArtSpecz722";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs722").src = tripleZeroA;
};

function squareToSzzZValue723(){
    value30Save = "zSqrArtSpecz723";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs723").src = tripleZeroA;
};

function squareToSzzZValue724(){
    value30Save = "zSqrArtSpecz724";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs724").src = tripleZeroA;
};

function squareToSzzZValue725(){
    value30Save = "zSqrArtSpecz725";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs725").src = tripleZeroA;
};

function squareToSzzZValue726(){
    value30Save = "zSqrArtSpecz726";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs726").src = tripleZeroA;
};

function squareToSzzZValue727(){
    value30Save = "zSqrArtSpecz727";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs727").src = tripleZeroA;
};

function squareToSzzZValue728(){
    value30Save = "zSqrArtSpecz728";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs728").src = tripleZeroA;
};

function squareToSzzZValue729(){
    value30Save = "zSqrArtSpecz729";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs729").src = tripleZeroA;
};

function squareToSzzZValue730(){
    value30Save = "zSqrArtSpecz730";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs730").src = tripleZeroA;
};

function squareToSzzZValue731(){
    value30Save = "zSqrArtSpecz731";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs731").src = tripleZeroA;
};

function squareToSzzZValue732(){
    value30Save = "zSqrArtSpecz732";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs732").src = tripleZeroA;
};

function squareToSzzZValue733(){
    value30Save = "zSqrArtSpecz733";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs733").src = tripleZeroA;
};

function squareToSzzZValue734(){
    value30Save = "zSqrArtSpecz734";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs734").src = tripleZeroA;
};

function squareToSzzZValue735(){
    value30Save = "zSqrArtSpecz735";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs735").src = tripleZeroA;
};

function squareToSzzZValue736(){
    value30Save = "zSqrArtSpecz736";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs736").src = tripleZeroA;
};

function squareToSzzZValue737(){
    value30Save = "zSqrArtSpecz737";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs737").src = tripleZeroA;
};

function squareToSzzZValue738(){
    value30Save = "zSqrArtSpecz738";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs738").src = tripleZeroA;
};

function squareToSzzZValue739(){
    value30Save = "zSqrArtSpecz739";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs739").src = tripleZeroA;
};

function squareToSzzZValue740(){
    value30Save = "zSqrArtSpecz740";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs740").src = tripleZeroA;
};

function squareToSzzZValue741(){
    value30Save = "zSqrArtSpecz741";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs741").src = tripleZeroA;
};

function squareToSzzZValue742(){
    value30Save = "zSqrArtSpecz742";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs742").src = tripleZeroA;
};

function squareToSzzZValue743(){
    value30Save = "zSqrArtSpecz743";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs743").src = tripleZeroA;
};

function squareToSzzZValue744(){
    value30Save = "zSqrArtSpecz744";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs744").src = tripleZeroA;
};

function squareToSzzZValue745(){
    value30Save = "zSqrArtSpecz745";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs745").src = tripleZeroA;
};

function squareToSzzZValue746(){
    value30Save = "zSqrArtSpecz746";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs746").src = tripleZeroA;
};

function squareToSzzZValue747(){
    value30Save = "zSqrArtSpecz747";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs747").src = tripleZeroA;
};

function squareToSzzZValue748(){
    value30Save = "zSqrArtSpecz748";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs748").src = tripleZeroA;
};

function squareToSzzZValue749(){
    value30Save = "zSqrArtSpecz749";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs749").src = tripleZeroA;
};

function squareToSzzZValue750(){
    value30Save = "zSqrArtSpecz750";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs750").src = tripleZeroA;
};

function squareToSzzZValue751(){
    value30Save = "zSqrArtSpecz751";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs751").src = tripleZeroA;
};

function squareToSzzZValue752(){
    value30Save = "zSqrArtSpecz752";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs752").src = tripleZeroA;
};

function squareToSzzZValue753(){
    value30Save = "zSqrArtSpecz753";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs753").src = tripleZeroA;
};

function squareToSzzZValue754(){
    value30Save = "zSqrArtSpecz754";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs754").src = tripleZeroA;
};

function squareToSzzZValue755(){
    value30Save = "zSqrArtSpecz755";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs755").src = tripleZeroA;
};

function squareToSzzZValue756(){
    value30Save = "zSqrArtSpecz756";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs756").src = tripleZeroA;
};

function squareToSzzZValue757(){
    value30Save = "zSqrArtSpecz757";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs757").src = tripleZeroA;
};

function squareToSzzZValue758(){
    value30Save = "zSqrArtSpecz758";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs758").src = tripleZeroA;
};

function squareToSzzZValue759(){
    value30Save = "zSqrArtSpecz759";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs759").src = tripleZeroA;
};

function squareToSzzZValue760(){
    value30Save = "zSqrArtSpecz760";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs760").src = tripleZeroA;
};

function squareToSzzZValue761(){
    value30Save = "zSqrArtSpecz761";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs761").src = tripleZeroA;
};

function squareToSzzZValue762(){
    value30Save = "zSqrArtSpecz762";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs762").src = tripleZeroA;
};

function squareToSzzZValue763(){
    value30Save = "zSqrArtSpecz763";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs763").src = tripleZeroA;
};

function squareToSzzZValue764(){
    value30Save = "zSqrArtSpecz764";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs764").src = tripleZeroA;
};

function squareToSzzZValue765(){
    value30Save = "zSqrArtSpecz765";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs765").src = tripleZeroA;
};

function squareToSzzZValue766(){
    value30Save = "zSqrArtSpecz766";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs766").src = tripleZeroA;
};

function squareToSzzZValue767(){
    value30Save = "zSqrArtSpecz767";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs767").src = tripleZeroA;
};

function squareToSzzZValue768(){
    value30Save = "zSqrArtSpecz768";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs768").src = tripleZeroA;
};

function squareToSzzZValue769(){
    value30Save = "zSqrArtSpecz769";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs769").src = tripleZeroA;
};

function squareToSzzZValue770(){
    value30Save = "zSqrArtSpecz770";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs770").src = tripleZeroA;
};

function squareToSzzZValue771(){
    value30Save = "zSqrArtSpecz771";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs771").src = tripleZeroA;
};

function squareToSzzZValue772(){
    value30Save = "zSqrArtSpecz772";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs772").src = tripleZeroA;
};

function squareToSzzZValue773(){
    value30Save = "zSqrArtSpecz773";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs773").src = tripleZeroA;
};

function squareToSzzZValue774(){
    value30Save = "zSqrArtSpecz774";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs774").src = tripleZeroA;
};

function squareToSzzZValue775(){
    value30Save = "zSqrArtSpecz775";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs775").src = tripleZeroA;
};

function squareToSzzZValue776(){
    value30Save = "zSqrArtSpecz776";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs776").src = tripleZeroA;
};

function squareToSzzZValue777(){
    value30Save = "zSqrArtSpecz777";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs777").src = tripleZeroA;
};

function squareToSzzZValue778(){
    value30Save = "zSqrArtSpecz778";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs778").src = tripleZeroA;
};

function squareToSzzZValue779(){
    value30Save = "zSqrArtSpecz779";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs779").src = tripleZeroA;
};

function squareToSzzZValue780(){
    value30Save = "zSqrArtSpecz780";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs780").src = tripleZeroA;
};

function squareToSzzZValue781(){
    value30Save = "zSqrArtSpecz781";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs781").src = tripleZeroA;
};

function squareToSzzZValue782(){
    value30Save = "zSqrArtSpecz782";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs782").src = tripleZeroA;
};

function squareToSzzZValue783(){
    value30Save = "zSqrArtSpecz783";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs783").src = tripleZeroA;
};

function squareToSzzZValue784(){
    value30Save = "zSqrArtSpecz784";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs784").src = tripleZeroA;
};

function squareToSzzZValue785(){
    value30Save = "zSqrArtSpecz785";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs785").src = tripleZeroA;
};

function squareToSzzZValue786(){
    value30Save = "zSqrArtSpecz786";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs786").src = tripleZeroA;
};

function squareToSzzZValue787(){
    value30Save = "zSqrArtSpecz787";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs787").src = tripleZeroA;
};

function squareToSzzZValue788(){
    value30Save = "zSqrArtSpecz788";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs788").src = tripleZeroA;
};

function squareToSzzZValue789(){
    value30Save = "zSqrArtSpecz789";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs789").src = tripleZeroA;
};

function squareToSzzZValue790(){
    value30Save = "zSqrArtSpecz790";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs790").src = tripleZeroA;
};

function squareToSzzZValue791(){
    value30Save = "zSqrArtSpecz791";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs791").src = tripleZeroA;
};

function squareToSzzZValue792(){
    value30Save = "zSqrArtSpecz792";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs792").src = tripleZeroA;
};

function squareToSzzZValue793(){
    value30Save = "zSqrArtSpecz793";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs793").src = tripleZeroA;
};

function squareToSzzZValue794(){
    value30Save = "zSqrArtSpecz794";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs794").src = tripleZeroA;
};

function squareToSzzZValue795(){
    value30Save = "zSqrArtSpecz795";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs795").src = tripleZeroA;
};

function squareToSzzZValue796(){
    value30Save = "zSqrArtSpecz796";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs796").src = tripleZeroA;
};

function squareToSzzZValue797(){
    value30Save = "zSqrArtSpecz797";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs797").src = tripleZeroA;
};

function squareToSzzZValue798(){
    value30Save = "zSqrArtSpecz798";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs798").src = tripleZeroA;
};

function squareToSzzZValue799(){
    value30Save = "zSqrArtSpecz799";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs799").src = tripleZeroA;
};

function squareToSzzZValue800(){
    value30Save = "zSqrArtSpecz800";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs800").src = tripleZeroA;
};

function squareToSzzZValue801(){
    value30Save = "zSqrArtSpecz801";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs801").src = tripleZeroA;
};

function squareToSzzZValue802(){
    value30Save = "zSqrArtSpecz802";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs802").src = tripleZeroA;
};

function squareToSzzZValue803(){
    value30Save = "zSqrArtSpecz803";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs803").src = tripleZeroA;
};

function squareToSzzZValue804(){
    value30Save = "zSqrArtSpecz804";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs804").src = tripleZeroA;
};

function squareToSzzZValue805(){
    value30Save = "zSqrArtSpecz805";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs805").src = tripleZeroA;
};

function squareToSzzZValue806(){
    value30Save = "zSqrArtSpecz806";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs806").src = tripleZeroA;
};

function squareToSzzZValue807(){
    value30Save = "zSqrArtSpecz807";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs807").src = tripleZeroA;
};

function squareToSzzZValue808(){
    value30Save = "zSqrArtSpecz808";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs808").src = tripleZeroA;
};

function squareToSzzZValue809(){
    value30Save = "zSqrArtSpecz809";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs809").src = tripleZeroA;
};

function squareToSzzZValue810(){
    value30Save = "zSqrArtSpecz810";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs810").src = tripleZeroA;
};

function squareToSzzZValue811(){
    value30Save = "zSqrArtSpecz811";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs811").src = tripleZeroA;
};

function squareToSzzZValue812(){
    value30Save = "zSqrArtSpecz812";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs812").src = tripleZeroA;
};

function squareToSzzZValue813(){
    value30Save = "zSqrArtSpecz813";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs813").src = tripleZeroA;
};

function squareToSzzZValue814(){
    value30Save = "zSqrArtSpecz814";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs814").src = tripleZeroA;
};

function squareToSzzZValue815(){
    value30Save = "zSqrArtSpecz815";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs815").src = tripleZeroA;
};

function squareToSzzZValue816(){
    value30Save = "zSqrArtSpecz816";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs816").src = tripleZeroA;
};

function squareToSzzZValue817(){
    value30Save = "zSqrArtSpecz817";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs817").src = tripleZeroA;
};

function squareToSzzZValue818(){
    value30Save = "zSqrArtSpecz818";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs818").src = tripleZeroA;
};

function squareToSzzZValue819(){
    value30Save = "zSqrArtSpecz819";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs819").src = tripleZeroA;
};

function squareToSzzZValue820(){
    value30Save = "zSqrArtSpecz820";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs820").src = tripleZeroA;
};

function squareToSzzZValue821(){
    value30Save = "zSqrArtSpecz821";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs821").src = tripleZeroA;
};

function squareToSzzZValue822(){
    value30Save = "zSqrArtSpecz822";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs822").src = tripleZeroA;
};

function squareToSzzZValue823(){
    value30Save = "zSqrArtSpecz823";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs823").src = tripleZeroA;
};

function squareToSzzZValue824(){
    value30Save = "zSqrArtSpecz824";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs824").src = tripleZeroA;
};

function squareToSzzZValue825(){
    value30Save = "zSqrArtSpecz825";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs825").src = tripleZeroA;
};

function squareToSzzZValue826(){
    value30Save = "zSqrArtSpecz826";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs826").src = tripleZeroA;
};

function squareToSzzZValue827(){
    value30Save = "zSqrArtSpecz827";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs827").src = tripleZeroA;
};

function squareToSzzZValue828(){
    value30Save = "zSqrArtSpecz828";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs828").src = tripleZeroA;
};

function squareToSzzZValue829(){
    value30Save = "zSqrArtSpecz829";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs829").src = tripleZeroA;
};

function squareToSzzZValue830(){
    value30Save = "zSqrArtSpecz830";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs830").src = tripleZeroA;
};

function squareToSzzZValue831(){
    value30Save = "zSqrArtSpecz831";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs831").src = tripleZeroA;
};

function squareToSzzZValue832(){
    value30Save = "zSqrArtSpecz832";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs832").src = tripleZeroA;
};

function squareToSzzZValue833(){
    value30Save = "zSqrArtSpecz833";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs833").src = tripleZeroA;
};

function squareToSzzZValue834(){
    value30Save = "zSqrArtSpecz834";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs834").src = tripleZeroA;
};

function squareToSzzZValue835(){
    value30Save = "zSqrArtSpecz835";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs835").src = tripleZeroA;
};

function squareToSzzZValue836(){
    value30Save = "zSqrArtSpecz836";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs836").src = tripleZeroA;
};

function squareToSzzZValue837(){
    value30Save = "zSqrArtSpecz837";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs837").src = tripleZeroA;
};

function squareToSzzZValue838(){
    value30Save = "zSqrArtSpecz838";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs838").src = tripleZeroA;
};

function squareToSzzZValue839(){
    value30Save = "zSqrArtSpecz839";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs839").src = tripleZeroA;
};

function squareToSzzZValue840(){
    value30Save = "zSqrArtSpecz840";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs840").src = tripleZeroA;
};

function squareToSzzZValue841(){
    value30Save = "zSqrArtSpecz841";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs841").src = tripleZeroA;
};

function squareToSzzZValue842(){
    value30Save = "zSqrArtSpecz842";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs842").src = tripleZeroA;
};

function squareToSzzZValue843(){
    value30Save = "zSqrArtSpecz843";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs843").src = tripleZeroA;
};

function squareToSzzZValue844(){
    value30Save = "zSqrArtSpecz844";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs844").src = tripleZeroA;
};

function squareToSzzZValue845(){
    value30Save = "zSqrArtSpecz845";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs845").src = tripleZeroA;
};

function squareToSzzZValue846(){
    value30Save = "zSqrArtSpecz846";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs846").src = tripleZeroA;
};

function squareToSzzZValue847(){
    value30Save = "zSqrArtSpecz847";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs847").src = tripleZeroA;
};

function squareToSzzZValue848(){
    value30Save = "zSqrArtSpecz848";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs848").src = tripleZeroA;
};

function squareToSzzZValue849(){
    value30Save = "zSqrArtSpecz849";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs849").src = tripleZeroA;
};

function squareToSzzZValue850(){
    value30Save = "zSqrArtSpecz850";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs850").src = tripleZeroA;
};

function squareToSzzZValue851(){
    value30Save = "zSqrArtSpecz851";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs851").src = tripleZeroA;
};

function squareToSzzZValue852(){
    value30Save = "zSqrArtSpecz852";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs852").src = tripleZeroA;
};

function squareToSzzZValue853(){
    value30Save = "zSqrArtSpecz853";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs853").src = tripleZeroA;
};

function squareToSzzZValue854(){
    value30Save = "zSqrArtSpecz854";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs854").src = tripleZeroA;
};

function squareToSzzZValue855(){
    value30Save = "zSqrArtSpecz855";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs855").src = tripleZeroA;
};

function squareToSzzZValue856(){
    value30Save = "zSqrArtSpecz856";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs856").src = tripleZeroA;
};

function squareToSzzZValue857(){
    value30Save = "zSqrArtSpecz857";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs857").src = tripleZeroA;
};

function squareToSzzZValue858(){
    value30Save = "zSqrArtSpecz858";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs858").src = tripleZeroA;
};

function squareToSzzZValue859(){
    value30Save = "zSqrArtSpecz859";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs859").src = tripleZeroA;
};

function squareToSzzZValue860(){
    value30Save = "zSqrArtSpecz860";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs860").src = tripleZeroA;
};

function squareToSzzZValue861(){
    value30Save = "zSqrArtSpecz861";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs861").src = tripleZeroA;
};

function squareToSzzZValue862(){
    value30Save = "zSqrArtSpecz862";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs862").src = tripleZeroA;
};

function squareToSzzZValue863(){
    value30Save = "zSqrArtSpecz863";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs863").src = tripleZeroA;
};

function squareToSzzZValue864(){
    value30Save = "zSqrArtSpecz864";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs864").src = tripleZeroA;
};

function squareToSzzZValue865(){
    value30Save = "zSqrArtSpecz865";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs865").src = tripleZeroA;
};

function squareToSzzZValue866(){
    value30Save = "zSqrArtSpecz866";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs866").src = tripleZeroA;
};

function squareToSzzZValue867(){
    value30Save = "zSqrArtSpecz867";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs867").src = tripleZeroA;
};

function squareToSzzZValue868(){
    value30Save = "zSqrArtSpecz868";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs868").src = tripleZeroA;
};

function squareToSzzZValue869(){
    value30Save = "zSqrArtSpecz869";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs869").src = tripleZeroA;
};

function squareToSzzZValue870(){
    value30Save = "zSqrArtSpecz870";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs870").src = tripleZeroA;
};

function squareToSzzZValue871(){
    value30Save = "zSqrArtSpecz871";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs871").src = tripleZeroA;
};

function squareToSzzZValue872(){
    value30Save = "zSqrArtSpecz872";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs872").src = tripleZeroA;
};

function squareToSzzZValue873(){
    value30Save = "zSqrArtSpecz873";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs873").src = tripleZeroA;
};

function squareToSzzZValue874(){
    value30Save = "zSqrArtSpecz874";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs874").src = tripleZeroA;
};

function squareToSzzZValue875(){
    value30Save = "zSqrArtSpecz875";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs875").src = tripleZeroA;
};

function squareToSzzZValue876(){
    value30Save = "zSqrArtSpecz876";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs876").src = tripleZeroA;
};

function squareToSzzZValue877(){
    value30Save = "zSqrArtSpecz877";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs877").src = tripleZeroA;
};

function squareToSzzZValue878(){
    value30Save = "zSqrArtSpecz878";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs878").src = tripleZeroA;
};

function squareToSzzZValue879(){
    value30Save = "zSqrArtSpecz879";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs879").src = tripleZeroA;
};

function squareToSzzZValue880(){
    value30Save = "zSqrArtSpecz880";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs880").src = tripleZeroA;
};

function squareToSzzZValue881(){
    value30Save = "zSqrArtSpecz881";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs881").src = tripleZeroA;
};

function squareToSzzZValue882(){
    value30Save = "zSqrArtSpecz882";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs882").src = tripleZeroA;
};

function squareToSzzZValue883(){
    value30Save = "zSqrArtSpecz883";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs883").src = tripleZeroA;
};

function squareToSzzZValue884(){
    value30Save = "zSqrArtSpecz884";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs884").src = tripleZeroA;
};

function squareToSzzZValue885(){
    value30Save = "zSqrArtSpecz885";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs885").src = tripleZeroA;
};

function squareToSzzZValue886(){
    value30Save = "zSqrArtSpecz886";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs886").src = tripleZeroA;
};

function squareToSzzZValue887(){
    value30Save = "zSqrArtSpecz887";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs887").src = tripleZeroA;
};

function squareToSzzZValue888(){
    value30Save = "zSqrArtSpecz888";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs888").src = tripleZeroA;
};

function squareToSzzZValue889(){
    value30Save = "zSqrArtSpecz889";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs889").src = tripleZeroA;
};

function squareToSzzZValue890(){
    value30Save = "zSqrArtSpecz890";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs890").src = tripleZeroA;
};

function squareToSzzZValue891(){
    value30Save = "zSqrArtSpecz891";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs891").src = tripleZeroA;
};

function squareToSzzZValue892(){
    value30Save = "zSqrArtSpecz892";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs892").src = tripleZeroA;
};

function squareToSzzZValue893(){
    value30Save = "zSqrArtSpecz893";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs893").src = tripleZeroA;
};

function squareToSzzZValue894(){
    value30Save = "zSqrArtSpecz894";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs894").src = tripleZeroA;
};

function squareToSzzZValue895(){
    value30Save = "zSqrArtSpecz895";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs895").src = tripleZeroA;
};

function squareToSzzZValue896(){
    value30Save = "zSqrArtSpecz896";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs896").src = tripleZeroA;
};

function squareToSzzZValue897(){
    value30Save = "zSqrArtSpecz897";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs897").src = tripleZeroA;
};

function squareToSzzZValue898(){
    value30Save = "zSqrArtSpecz898";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs898").src = tripleZeroA;
};

function squareToSzzZValue899(){
    value30Save = "zSqrArtSpecz899";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs899").src = tripleZeroA;
};

function squareToSzzZValue900(){
    value30Save = "zSqrArtSpecz900";
    var tripleZeroA = localStorage.getItem(value30Save);
    document.getElementById("imgSqrs900").src = tripleZeroA;
};

function getBThis(){
    squareToSzzZValue1()

    squareToSzzZValue2()

    squareToSzzZValue3()

    squareToSzzZValue4()

    squareToSzzZValue5()

    squareToSzzZValue6()

    squareToSzzZValue7()

    squareToSzzZValue8()

    squareToSzzZValue9()

    squareToSzzZValue10()

    squareToSzzZValue11()

    squareToSzzZValue12()

    squareToSzzZValue13()

    squareToSzzZValue14()

    squareToSzzZValue15()

    squareToSzzZValue16()

    squareToSzzZValue17()

    squareToSzzZValue18()

    squareToSzzZValue19()

    squareToSzzZValue20()

    squareToSzzZValue21()

    squareToSzzZValue22()

    squareToSzzZValue23()

    squareToSzzZValue24()

    squareToSzzZValue25()

    squareToSzzZValue26()

    squareToSzzZValue27()

    squareToSzzZValue28()

    squareToSzzZValue29()

    squareToSzzZValue30()

    squareToSzzZValue31()

    squareToSzzZValue32()

    squareToSzzZValue33()

    squareToSzzZValue34()

    squareToSzzZValue35()

    squareToSzzZValue36()

    squareToSzzZValue37()

    squareToSzzZValue38()

    squareToSzzZValue39()

    squareToSzzZValue40()

    squareToSzzZValue41()

    squareToSzzZValue42()

    squareToSzzZValue43()

    squareToSzzZValue44()

    squareToSzzZValue45()

    squareToSzzZValue46()

    squareToSzzZValue47()

    squareToSzzZValue48()

    squareToSzzZValue49()

    squareToSzzZValue50()

    squareToSzzZValue51()

    squareToSzzZValue52()

    squareToSzzZValue53()

    squareToSzzZValue54()

    squareToSzzZValue55()

    squareToSzzZValue56()

    squareToSzzZValue57()

    squareToSzzZValue58()

    squareToSzzZValue59()

    squareToSzzZValue60()

    squareToSzzZValue61()

    squareToSzzZValue62()

    squareToSzzZValue63()

    squareToSzzZValue64()

    squareToSzzZValue65()

    squareToSzzZValue66()

    squareToSzzZValue67()

    squareToSzzZValue68()

    squareToSzzZValue69()

    squareToSzzZValue70()

    squareToSzzZValue71()

    squareToSzzZValue72()

    squareToSzzZValue73()

    squareToSzzZValue74()

    squareToSzzZValue75()

    squareToSzzZValue76()

    squareToSzzZValue77()

    squareToSzzZValue78()

    squareToSzzZValue79()

    squareToSzzZValue80()

    squareToSzzZValue81()

    squareToSzzZValue82()

    squareToSzzZValue83()

    squareToSzzZValue84()

    squareToSzzZValue85()

    squareToSzzZValue86()

    squareToSzzZValue87()

    squareToSzzZValue88()

    squareToSzzZValue89()

    squareToSzzZValue90()

    squareToSzzZValue91()

    squareToSzzZValue92()

    squareToSzzZValue93()

    squareToSzzZValue94()

    squareToSzzZValue95()

    squareToSzzZValue96()

    squareToSzzZValue97()

    squareToSzzZValue98()

    squareToSzzZValue99()

    squareToSzzZValue100()

    squareToSzzZValue101()

    squareToSzzZValue102()

    squareToSzzZValue103()

    squareToSzzZValue104()

    squareToSzzZValue105()

    squareToSzzZValue106()

    squareToSzzZValue107()

    squareToSzzZValue108()

    squareToSzzZValue109()

    squareToSzzZValue110()

    squareToSzzZValue111()

    squareToSzzZValue112()

    squareToSzzZValue113()

    squareToSzzZValue114()

    squareToSzzZValue115()

    squareToSzzZValue116()

    squareToSzzZValue117()

    squareToSzzZValue118()

    squareToSzzZValue119()

    squareToSzzZValue120()

    squareToSzzZValue121()

    squareToSzzZValue122()

    squareToSzzZValue123()

    squareToSzzZValue124()

    squareToSzzZValue125()

    squareToSzzZValue126()

    squareToSzzZValue127()

    squareToSzzZValue128()

    squareToSzzZValue129()

    squareToSzzZValue130()

    squareToSzzZValue131()

    squareToSzzZValue132()

    squareToSzzZValue133()

    squareToSzzZValue134()

    squareToSzzZValue135()

    squareToSzzZValue136()

    squareToSzzZValue137()

    squareToSzzZValue138()

    squareToSzzZValue139()

    squareToSzzZValue140()

    squareToSzzZValue141()

    squareToSzzZValue142()

    squareToSzzZValue143()

    squareToSzzZValue144()

    squareToSzzZValue145()

    squareToSzzZValue146()

    squareToSzzZValue147()

    squareToSzzZValue148()

    squareToSzzZValue149()

    squareToSzzZValue150()

    squareToSzzZValue151()

    squareToSzzZValue152()

    squareToSzzZValue153()

    squareToSzzZValue154()

    squareToSzzZValue155()

    squareToSzzZValue156()

    squareToSzzZValue157()

    squareToSzzZValue158()

    squareToSzzZValue159()

    squareToSzzZValue160()

    squareToSzzZValue161()

    squareToSzzZValue162()

    squareToSzzZValue163()

    squareToSzzZValue164()

    squareToSzzZValue165()

    squareToSzzZValue166()

    squareToSzzZValue167()

    squareToSzzZValue168()

    squareToSzzZValue169()

    squareToSzzZValue170()

    squareToSzzZValue171()

    squareToSzzZValue172()

    squareToSzzZValue173()

    squareToSzzZValue174()

    squareToSzzZValue175()

    squareToSzzZValue176()

    squareToSzzZValue177()

    squareToSzzZValue178()

    squareToSzzZValue179()

    squareToSzzZValue180()

    squareToSzzZValue181()

    squareToSzzZValue182()

    squareToSzzZValue183()

    squareToSzzZValue184()

    squareToSzzZValue185()

    squareToSzzZValue186()

    squareToSzzZValue187()

    squareToSzzZValue188()

    squareToSzzZValue189()

    squareToSzzZValue190()

    squareToSzzZValue191()

    squareToSzzZValue192()

    squareToSzzZValue193()

    squareToSzzZValue194()

    squareToSzzZValue195()

    squareToSzzZValue196()

    squareToSzzZValue197()

    squareToSzzZValue198()

    squareToSzzZValue199()

    squareToSzzZValue200()

    squareToSzzZValue201()

    squareToSzzZValue202()

    squareToSzzZValue203()

    squareToSzzZValue204()

    squareToSzzZValue205()

    squareToSzzZValue206()

    squareToSzzZValue207()

    squareToSzzZValue208()

    squareToSzzZValue209()

    squareToSzzZValue210()

    squareToSzzZValue211()

    squareToSzzZValue212()

    squareToSzzZValue213()

    squareToSzzZValue214()

    squareToSzzZValue215()

    squareToSzzZValue216()

    squareToSzzZValue217()

    squareToSzzZValue218()

    squareToSzzZValue219()

    squareToSzzZValue220()

    squareToSzzZValue221()

    squareToSzzZValue222()

    squareToSzzZValue223()

    squareToSzzZValue224()

    squareToSzzZValue225()

    squareToSzzZValue226()

    squareToSzzZValue227()

    squareToSzzZValue228()

    squareToSzzZValue229()

    squareToSzzZValue230()

    squareToSzzZValue231()

    squareToSzzZValue232()

    squareToSzzZValue233()

    squareToSzzZValue234()

    squareToSzzZValue235()

    squareToSzzZValue236()

    squareToSzzZValue237()

    squareToSzzZValue238()

    squareToSzzZValue239()

    squareToSzzZValue240()

    squareToSzzZValue241()

    squareToSzzZValue242()

    squareToSzzZValue243()

    squareToSzzZValue244()

    squareToSzzZValue245()

    squareToSzzZValue246()

    squareToSzzZValue247()

    squareToSzzZValue248()

    squareToSzzZValue249()

    squareToSzzZValue250()

    squareToSzzZValue251()

    squareToSzzZValue252()

    squareToSzzZValue253()

    squareToSzzZValue254()

    squareToSzzZValue255()

    squareToSzzZValue256()

    squareToSzzZValue257()

    squareToSzzZValue258()

    squareToSzzZValue259()

    squareToSzzZValue260()

    squareToSzzZValue261()

    squareToSzzZValue262()

    squareToSzzZValue263()

    squareToSzzZValue264()

    squareToSzzZValue265()

    squareToSzzZValue266()

    squareToSzzZValue267()

    squareToSzzZValue268()

    squareToSzzZValue269()

    squareToSzzZValue270()

    squareToSzzZValue271()

    squareToSzzZValue272()

    squareToSzzZValue273()

    squareToSzzZValue274()

    squareToSzzZValue275()

    squareToSzzZValue276()

    squareToSzzZValue277()

    squareToSzzZValue278()

    squareToSzzZValue279()

    squareToSzzZValue280()

    squareToSzzZValue281()

    squareToSzzZValue282()

    squareToSzzZValue283()

    squareToSzzZValue284()

    squareToSzzZValue285()

    squareToSzzZValue286()

    squareToSzzZValue287()

    squareToSzzZValue288()

    squareToSzzZValue289()

    squareToSzzZValue290()

    squareToSzzZValue291()

    squareToSzzZValue292()

    squareToSzzZValue293()

    squareToSzzZValue294()

    squareToSzzZValue295()

    squareToSzzZValue296()

    squareToSzzZValue297()

    squareToSzzZValue298()

    squareToSzzZValue299()

    squareToSzzZValue300()

    squareToSzzZValue301()

    squareToSzzZValue302()

    squareToSzzZValue303()

    squareToSzzZValue304()

    squareToSzzZValue305()

    squareToSzzZValue306()

    squareToSzzZValue307()

    squareToSzzZValue308()

    squareToSzzZValue309()

    squareToSzzZValue310()

    squareToSzzZValue311()

    squareToSzzZValue312()

    squareToSzzZValue313()

    squareToSzzZValue314()

    squareToSzzZValue315()

    squareToSzzZValue316()

    squareToSzzZValue317()

    squareToSzzZValue318()

    squareToSzzZValue319()

    squareToSzzZValue320()

    squareToSzzZValue321()

    squareToSzzZValue322()

    squareToSzzZValue323()

    squareToSzzZValue324()

    squareToSzzZValue325()

    squareToSzzZValue326()

    squareToSzzZValue327()

    squareToSzzZValue328()

    squareToSzzZValue329()

    squareToSzzZValue330()

    squareToSzzZValue331()

    squareToSzzZValue332()

    squareToSzzZValue333()

    squareToSzzZValue334()

    squareToSzzZValue335()

    squareToSzzZValue336()

    squareToSzzZValue337()

    squareToSzzZValue338()

    squareToSzzZValue339()

    squareToSzzZValue340()

    squareToSzzZValue341()

    squareToSzzZValue342()

    squareToSzzZValue343()

    squareToSzzZValue344()

    squareToSzzZValue345()

    squareToSzzZValue346()

    squareToSzzZValue347()

    squareToSzzZValue348()

    squareToSzzZValue349()

    squareToSzzZValue350()

    squareToSzzZValue351()

    squareToSzzZValue352()

    squareToSzzZValue353()

    squareToSzzZValue354()

    squareToSzzZValue355()

    squareToSzzZValue356()

    squareToSzzZValue357()

    squareToSzzZValue358()

    squareToSzzZValue359()

    squareToSzzZValue360()

    squareToSzzZValue361()

    squareToSzzZValue362()

    squareToSzzZValue363()

    squareToSzzZValue364()

    squareToSzzZValue365()

    squareToSzzZValue366()

    squareToSzzZValue367()

    squareToSzzZValue368()

    squareToSzzZValue369()

    squareToSzzZValue370()

    squareToSzzZValue371()

    squareToSzzZValue372()

    squareToSzzZValue373()

    squareToSzzZValue374()

    squareToSzzZValue375()

    squareToSzzZValue376()

    squareToSzzZValue377()

    squareToSzzZValue378()

    squareToSzzZValue379()

    squareToSzzZValue380()

    squareToSzzZValue381()

    squareToSzzZValue382()

    squareToSzzZValue383()

    squareToSzzZValue384()

    squareToSzzZValue385()

    squareToSzzZValue386()

    squareToSzzZValue387()

    squareToSzzZValue388()

    squareToSzzZValue389()

    squareToSzzZValue390()

    squareToSzzZValue391()

    squareToSzzZValue392()

    squareToSzzZValue393()

    squareToSzzZValue394()

    squareToSzzZValue395()

    squareToSzzZValue396()

    squareToSzzZValue397()

    squareToSzzZValue398()

    squareToSzzZValue399()

    squareToSzzZValue400()

    squareToSzzZValue401()

    squareToSzzZValue402()

    squareToSzzZValue403()

    squareToSzzZValue404()

    squareToSzzZValue405()

    squareToSzzZValue406()

    squareToSzzZValue407()

    squareToSzzZValue408()

    squareToSzzZValue409()

    squareToSzzZValue410()

    squareToSzzZValue411()

    squareToSzzZValue412()

    squareToSzzZValue413()

    squareToSzzZValue414()

    squareToSzzZValue415()

    squareToSzzZValue416()

    squareToSzzZValue417()

    squareToSzzZValue418()

    squareToSzzZValue419()

    squareToSzzZValue420()

    squareToSzzZValue421()

    squareToSzzZValue422()

    squareToSzzZValue423()

    squareToSzzZValue424()

    squareToSzzZValue425()

    squareToSzzZValue426()

    squareToSzzZValue427()

    squareToSzzZValue428()

    squareToSzzZValue429()

    squareToSzzZValue430()

    squareToSzzZValue431()

    squareToSzzZValue432()

    squareToSzzZValue433()

    squareToSzzZValue434()

    squareToSzzZValue435()

    squareToSzzZValue436()

    squareToSzzZValue437()

    squareToSzzZValue438()

    squareToSzzZValue439()

    squareToSzzZValue440()

    squareToSzzZValue441()

    squareToSzzZValue442()

    squareToSzzZValue443()

    squareToSzzZValue444()

    squareToSzzZValue445()

    squareToSzzZValue446()

    squareToSzzZValue447()

    squareToSzzZValue448()

    squareToSzzZValue449()

    squareToSzzZValue450()

    squareToSzzZValue451()

    squareToSzzZValue452()

    squareToSzzZValue453()

    squareToSzzZValue454()

    squareToSzzZValue455()

    squareToSzzZValue456()

    squareToSzzZValue457()

    squareToSzzZValue458()

    squareToSzzZValue459()

    squareToSzzZValue460()

    squareToSzzZValue461()

    squareToSzzZValue462()

    squareToSzzZValue463()

    squareToSzzZValue464()

    squareToSzzZValue465()

    squareToSzzZValue466()

    squareToSzzZValue467()

    squareToSzzZValue468()

    squareToSzzZValue469()

    squareToSzzZValue470()

    squareToSzzZValue471()

    squareToSzzZValue472()

    squareToSzzZValue473()

    squareToSzzZValue474()

    squareToSzzZValue475()

    squareToSzzZValue476()

    squareToSzzZValue477()

    squareToSzzZValue478()

    squareToSzzZValue479()

    squareToSzzZValue480()

    squareToSzzZValue481()

    squareToSzzZValue482()

    squareToSzzZValue483()

    squareToSzzZValue484()

    squareToSzzZValue485()

    squareToSzzZValue486()

    squareToSzzZValue487()

    squareToSzzZValue488()

    squareToSzzZValue489()

    squareToSzzZValue490()

    squareToSzzZValue491()

    squareToSzzZValue492()

    squareToSzzZValue493()

    squareToSzzZValue494()

    squareToSzzZValue495()

    squareToSzzZValue496()

    squareToSzzZValue497()

    squareToSzzZValue498()

    squareToSzzZValue499()

    squareToSzzZValue500()

    squareToSzzZValue501()

    squareToSzzZValue502()

    squareToSzzZValue503()

    squareToSzzZValue504()

    squareToSzzZValue505()

    squareToSzzZValue506()

    squareToSzzZValue507()

    squareToSzzZValue508()

    squareToSzzZValue509()

    squareToSzzZValue510()

    squareToSzzZValue511()

    squareToSzzZValue512()

    squareToSzzZValue513()

    squareToSzzZValue514()

    squareToSzzZValue515()

    squareToSzzZValue516()

    squareToSzzZValue517()

    squareToSzzZValue518()

    squareToSzzZValue519()

    squareToSzzZValue520()

    squareToSzzZValue521()

    squareToSzzZValue522()

    squareToSzzZValue523()

    squareToSzzZValue524()

    squareToSzzZValue525()

    squareToSzzZValue526()

    squareToSzzZValue527()

    squareToSzzZValue528()

    squareToSzzZValue529()

    squareToSzzZValue530()

    squareToSzzZValue531()

    squareToSzzZValue532()

    squareToSzzZValue533()

    squareToSzzZValue534()

    squareToSzzZValue535()

    squareToSzzZValue536()

    squareToSzzZValue537()

    squareToSzzZValue538()

    squareToSzzZValue539()

    squareToSzzZValue540()

    squareToSzzZValue541()

    squareToSzzZValue542()

    squareToSzzZValue543()

    squareToSzzZValue544()

    squareToSzzZValue545()

    squareToSzzZValue546()

    squareToSzzZValue547()

    squareToSzzZValue548()

    squareToSzzZValue549()

    squareToSzzZValue550()

    squareToSzzZValue551()

    squareToSzzZValue552()

    squareToSzzZValue553()

    squareToSzzZValue554()

    squareToSzzZValue555()

    squareToSzzZValue556()

    squareToSzzZValue557()

    squareToSzzZValue558()

    squareToSzzZValue559()

    squareToSzzZValue560()

    squareToSzzZValue561()

    squareToSzzZValue562()

    squareToSzzZValue563()

    squareToSzzZValue564()

    squareToSzzZValue565()

    squareToSzzZValue566()

    squareToSzzZValue567()

    squareToSzzZValue568()

    squareToSzzZValue569()

    squareToSzzZValue570()

    squareToSzzZValue571()

    squareToSzzZValue572()

    squareToSzzZValue573()

    squareToSzzZValue574()

    squareToSzzZValue575()

    squareToSzzZValue576()

    squareToSzzZValue577()

    squareToSzzZValue578()

    squareToSzzZValue579()

    squareToSzzZValue580()

    squareToSzzZValue581()

    squareToSzzZValue582()

    squareToSzzZValue583()

    squareToSzzZValue584()

    squareToSzzZValue585()

    squareToSzzZValue586()

    squareToSzzZValue587()

    squareToSzzZValue588()

    squareToSzzZValue589()

    squareToSzzZValue590()

    squareToSzzZValue591()

    squareToSzzZValue592()

    squareToSzzZValue593()

    squareToSzzZValue594()

    squareToSzzZValue595()

    squareToSzzZValue596()

    squareToSzzZValue597()

    squareToSzzZValue598()

    squareToSzzZValue599()

    squareToSzzZValue600()

    squareToSzzZValue601()

    squareToSzzZValue602()

    squareToSzzZValue603()

    squareToSzzZValue604()

    squareToSzzZValue605()

    squareToSzzZValue606()

    squareToSzzZValue607()

    squareToSzzZValue608()

    squareToSzzZValue609()

    squareToSzzZValue610()

    squareToSzzZValue611()

    squareToSzzZValue612()

    squareToSzzZValue613()

    squareToSzzZValue614()

    squareToSzzZValue615()

    squareToSzzZValue616()

    squareToSzzZValue617()

    squareToSzzZValue618()

    squareToSzzZValue619()

    squareToSzzZValue620()

    squareToSzzZValue621()

    squareToSzzZValue622()

    squareToSzzZValue623()

    squareToSzzZValue624()

    squareToSzzZValue625()

    squareToSzzZValue626()

    squareToSzzZValue627()

    squareToSzzZValue628()

    squareToSzzZValue629()

    squareToSzzZValue630()

    squareToSzzZValue631()

    squareToSzzZValue632()

    squareToSzzZValue633()

    squareToSzzZValue634()

    squareToSzzZValue635()

    squareToSzzZValue636()

    squareToSzzZValue637()

    squareToSzzZValue638()

    squareToSzzZValue639()

    squareToSzzZValue640()

    squareToSzzZValue641()

    squareToSzzZValue642()

    squareToSzzZValue643()

    squareToSzzZValue644()

    squareToSzzZValue645()

    squareToSzzZValue646()

    squareToSzzZValue647()

    squareToSzzZValue648()

    squareToSzzZValue649()

    squareToSzzZValue650()

    squareToSzzZValue651()

    squareToSzzZValue652()

    squareToSzzZValue653()

    squareToSzzZValue654()

    squareToSzzZValue655()

    squareToSzzZValue656()

    squareToSzzZValue657()

    squareToSzzZValue658()

    squareToSzzZValue659()

    squareToSzzZValue660()

    squareToSzzZValue661()

    squareToSzzZValue662()

    squareToSzzZValue663()

    squareToSzzZValue664()

    squareToSzzZValue665()

    squareToSzzZValue666()

    squareToSzzZValue667()

    squareToSzzZValue668()

    squareToSzzZValue669()

    squareToSzzZValue670()

    squareToSzzZValue671()

    squareToSzzZValue672()

    squareToSzzZValue673()

    squareToSzzZValue674()

    squareToSzzZValue675()

    squareToSzzZValue676()

    squareToSzzZValue677()

    squareToSzzZValue678()

    squareToSzzZValue679()

    squareToSzzZValue680()

    squareToSzzZValue681()

    squareToSzzZValue682()

    squareToSzzZValue683()

    squareToSzzZValue684()

    squareToSzzZValue685()

    squareToSzzZValue686()

    squareToSzzZValue687()

    squareToSzzZValue688()

    squareToSzzZValue689()

    squareToSzzZValue690()

    squareToSzzZValue691()

    squareToSzzZValue692()

    squareToSzzZValue693()

    squareToSzzZValue694()

    squareToSzzZValue695()

    squareToSzzZValue696()

    squareToSzzZValue697()

    squareToSzzZValue698()

    squareToSzzZValue699()

    squareToSzzZValue700()

    squareToSzzZValue701()

    squareToSzzZValue702()

    squareToSzzZValue703()

    squareToSzzZValue704()

    squareToSzzZValue705()

    squareToSzzZValue706()

    squareToSzzZValue707()

    squareToSzzZValue708()

    squareToSzzZValue709()

    squareToSzzZValue710()

    squareToSzzZValue711()

    squareToSzzZValue712()

    squareToSzzZValue713()

    squareToSzzZValue714()

    squareToSzzZValue715()

    squareToSzzZValue716()

    squareToSzzZValue717()

    squareToSzzZValue718()

    squareToSzzZValue719()

    squareToSzzZValue720()

    squareToSzzZValue721()

    squareToSzzZValue722()

    squareToSzzZValue723()

    squareToSzzZValue724()

    squareToSzzZValue725()

    squareToSzzZValue726()

    squareToSzzZValue727()

    squareToSzzZValue728()

    squareToSzzZValue729()

    squareToSzzZValue730()

    squareToSzzZValue731()

    squareToSzzZValue732()

    squareToSzzZValue733()

    squareToSzzZValue734()

    squareToSzzZValue735()

    squareToSzzZValue736()

    squareToSzzZValue737()

    squareToSzzZValue738()

    squareToSzzZValue739()

    squareToSzzZValue740()

    squareToSzzZValue741()

    squareToSzzZValue742()

    squareToSzzZValue743()

    squareToSzzZValue744()

    squareToSzzZValue745()

    squareToSzzZValue746()

    squareToSzzZValue747()

    squareToSzzZValue748()

    squareToSzzZValue749()

    squareToSzzZValue750()

    squareToSzzZValue751()

    squareToSzzZValue752()

    squareToSzzZValue753()

    squareToSzzZValue754()

    squareToSzzZValue755()

    squareToSzzZValue756()

    squareToSzzZValue757()

    squareToSzzZValue758()

    squareToSzzZValue759()

    squareToSzzZValue760()

    squareToSzzZValue761()

    squareToSzzZValue762()

    squareToSzzZValue763()

    squareToSzzZValue764()

    squareToSzzZValue765()

    squareToSzzZValue766()

    squareToSzzZValue767()

    squareToSzzZValue768()

    squareToSzzZValue769()

    squareToSzzZValue770()

    squareToSzzZValue771()

    squareToSzzZValue772()

    squareToSzzZValue773()

    squareToSzzZValue774()

    squareToSzzZValue775()

    squareToSzzZValue776()

    squareToSzzZValue777()

    squareToSzzZValue778()

    squareToSzzZValue779()

    squareToSzzZValue780()

    squareToSzzZValue781()

    squareToSzzZValue782()

    squareToSzzZValue783()

    squareToSzzZValue784()

    squareToSzzZValue785()

    squareToSzzZValue786()

    squareToSzzZValue787()

    squareToSzzZValue788()

    squareToSzzZValue789()

    squareToSzzZValue790()

    squareToSzzZValue791()

    squareToSzzZValue792()

    squareToSzzZValue793()

    squareToSzzZValue794()

    squareToSzzZValue795()

    squareToSzzZValue796()

    squareToSzzZValue797()

    squareToSzzZValue798()

    squareToSzzZValue799()

    squareToSzzZValue800()

    squareToSzzZValue801()

    squareToSzzZValue802()

    squareToSzzZValue803()

    squareToSzzZValue804()

    squareToSzzZValue805()

    squareToSzzZValue806()

    squareToSzzZValue807()

    squareToSzzZValue808()

    squareToSzzZValue809()

    squareToSzzZValue810()

    squareToSzzZValue811()

    squareToSzzZValue812()

    squareToSzzZValue813()

    squareToSzzZValue814()

    squareToSzzZValue815()

    squareToSzzZValue816()

    squareToSzzZValue817()

    squareToSzzZValue818()

    squareToSzzZValue819()

    squareToSzzZValue820()

    squareToSzzZValue821()

    squareToSzzZValue822()

    squareToSzzZValue823()

    squareToSzzZValue824()

    squareToSzzZValue825()

    squareToSzzZValue826()

    squareToSzzZValue827()

    squareToSzzZValue828()

    squareToSzzZValue829()

    squareToSzzZValue830()

    squareToSzzZValue831()

    squareToSzzZValue832()

    squareToSzzZValue833()

    squareToSzzZValue834()

    squareToSzzZValue835()

    squareToSzzZValue836()

    squareToSzzZValue837()

    squareToSzzZValue838()

    squareToSzzZValue839()

    squareToSzzZValue840()

    squareToSzzZValue841()

    squareToSzzZValue842()

    squareToSzzZValue843()

    squareToSzzZValue844()

    squareToSzzZValue845()

    squareToSzzZValue846()

    squareToSzzZValue847()

    squareToSzzZValue848()

    squareToSzzZValue849()

    squareToSzzZValue850()

    squareToSzzZValue851()

    squareToSzzZValue852()

    squareToSzzZValue853()

    squareToSzzZValue854()

    squareToSzzZValue855()

    squareToSzzZValue856()

    squareToSzzZValue857()

    squareToSzzZValue858()

    squareToSzzZValue859()

    squareToSzzZValue860()

    squareToSzzZValue861()

    squareToSzzZValue862()

    squareToSzzZValue863()

    squareToSzzZValue864()

    squareToSzzZValue865()

    squareToSzzZValue866()

    squareToSzzZValue867()

    squareToSzzZValue868()

    squareToSzzZValue869()

    squareToSzzZValue870()

    squareToSzzZValue871()

    squareToSzzZValue872()

    squareToSzzZValue873()

    squareToSzzZValue874()

    squareToSzzZValue875()

    squareToSzzZValue876()

    squareToSzzZValue877()

    squareToSzzZValue878()

    squareToSzzZValue879()

    squareToSzzZValue880()

    squareToSzzZValue881()

    squareToSzzZValue882()

    squareToSzzZValue883()

    squareToSzzZValue884()

    squareToSzzZValue885()

    squareToSzzZValue886()

    squareToSzzZValue887()

    squareToSzzZValue888()

    squareToSzzZValue889()

    squareToSzzZValue890()

    squareToSzzZValue891()

    squareToSzzZValue892()

    squareToSzzZValue893()

    squareToSzzZValue894()

    squareToSzzZValue895()

    squareToSzzZValue896()

    squareToSzzZValue897()

    squareToSzzZValue898()

    squareToSzzZValue899()

    squareToSzzZValue900()
    
    alert("Your art has been loaded successfully from your browser's local browser storage.");

};

function squareNull(){
    valueSave = 'zSqrArtSpecz0';
    var tripleZeroA = localStorage.getItem(valueSave);
    if(tripleZeroA == null){
        setAThis();
    }else{
        getBThis();
    };
};