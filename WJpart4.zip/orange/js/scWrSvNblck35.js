function square1(){

    var sQz1 = document.getElementById("imgSqrs1").src;

    value35Save1 = "zSqrArtSpecz1";

    localStorage.setItem(value35Save1, sQz1);
};

function square2(){

    var sQz2 = document.getElementById("imgSqrs2").src;

    value35Save2 = "zSqrArtSpecz2";

    localStorage.setItem(value35Save2, sQz2);
};

function square3(){

    var sQz3 = document.getElementById("imgSqrs3").src;

    value35Save3 = "zSqrArtSpecz3";

    localStorage.setItem(value35Save3, sQz3);
};

function square4(){

    var sQz4 = document.getElementById("imgSqrs4").src;

    value35Save4 = "zSqrArtSpecz4";

    localStorage.setItem(value35Save4, sQz4);
};

function square5(){

    var sQz5 = document.getElementById("imgSqrs5").src;

    value35Save5 = "zSqrArtSpecz5";

    localStorage.setItem(value35Save5, sQz5);
};

function square6(){

    var sQz6 = document.getElementById("imgSqrs6").src;

    value35Save6 = "zSqrArtSpecz6";

    localStorage.setItem(value35Save6, sQz6);
};

function square7(){

    var sQz7 = document.getElementById("imgSqrs7").src;

    value35Save7 = "zSqrArtSpecz7";

    localStorage.setItem(value35Save7, sQz7);
};

function square8(){

    var sQz8 = document.getElementById("imgSqrs8").src;

    value35Save8 = "zSqrArtSpecz8";

    localStorage.setItem(value35Save8, sQz8);
};

function square9(){

    var sQz9 = document.getElementById("imgSqrs9").src;

    value35Save9 = "zSqrArtSpecz9";

    localStorage.setItem(value35Save9, sQz9);
};

function square10(){

    var sQz10 = document.getElementById("imgSqrs10").src;

    value35Save10 = "zSqrArtSpecz10";

    localStorage.setItem(value35Save10, sQz10);
};

function square11(){

    var sQz11 = document.getElementById("imgSqrs11").src;

    value35Save11 = "zSqrArtSpecz11";

    localStorage.setItem(value35Save11, sQz11);
};

function square12(){

    var sQz12 = document.getElementById("imgSqrs12").src;

    value35Save12 = "zSqrArtSpecz12";

    localStorage.setItem(value35Save12, sQz12);
};

function square13(){

    var sQz13 = document.getElementById("imgSqrs13").src;

    value35Save13 = "zSqrArtSpecz13";

    localStorage.setItem(value35Save13, sQz13);
};

function square14(){

    var sQz14 = document.getElementById("imgSqrs14").src;

    value35Save14 = "zSqrArtSpecz14";

    localStorage.setItem(value35Save14, sQz14);
};

function square15(){

    var sQz15 = document.getElementById("imgSqrs15").src;

    value35Save15 = "zSqrArtSpecz15";

    localStorage.setItem(value35Save15, sQz15);
};

function square16(){

    var sQz16 = document.getElementById("imgSqrs16").src;

    value35Save16 = "zSqrArtSpecz16";

    localStorage.setItem(value35Save16, sQz16);
};

function square17(){

    var sQz17 = document.getElementById("imgSqrs17").src;

    value35Save17 = "zSqrArtSpecz17";

    localStorage.setItem(value35Save17, sQz17);
};

function square18(){

    var sQz18 = document.getElementById("imgSqrs18").src;

    value35Save18 = "zSqrArtSpecz18";

    localStorage.setItem(value35Save18, sQz18);
};

function square19(){

    var sQz19 = document.getElementById("imgSqrs19").src;

    value35Save19 = "zSqrArtSpecz19";

    localStorage.setItem(value35Save19, sQz19);
};

function square20(){

    var sQz20 = document.getElementById("imgSqrs20").src;

    value35Save20 = "zSqrArtSpecz20";

    localStorage.setItem(value35Save20, sQz20);
};

function square21(){

    var sQz21 = document.getElementById("imgSqrs21").src;

    value35Save21 = "zSqrArtSpecz21";

    localStorage.setItem(value35Save21, sQz21);
};

function square22(){

    var sQz22 = document.getElementById("imgSqrs22").src;

    value35Save22 = "zSqrArtSpecz22";

    localStorage.setItem(value35Save22, sQz22);
};

function square23(){

    var sQz23 = document.getElementById("imgSqrs23").src;

    value35Save23 = "zSqrArtSpecz23";

    localStorage.setItem(value35Save23, sQz23);
};

function square24(){

    var sQz24 = document.getElementById("imgSqrs24").src;

    value35Save24 = "zSqrArtSpecz24";

    localStorage.setItem(value35Save24, sQz24);
};

function square25(){

    var sQz25 = document.getElementById("imgSqrs25").src;

    value35Save25 = "zSqrArtSpecz25";

    localStorage.setItem(value35Save25, sQz25);
};

function square26(){

    var sQz26 = document.getElementById("imgSqrs26").src;

    value35Save26 = "zSqrArtSpecz26";

    localStorage.setItem(value35Save26, sQz26);
};

function square27(){

    var sQz27 = document.getElementById("imgSqrs27").src;

    value35Save27 = "zSqrArtSpecz27";

    localStorage.setItem(value35Save27, sQz27);
};

function square28(){

    var sQz28 = document.getElementById("imgSqrs28").src;

    value35Save28 = "zSqrArtSpecz28";

    localStorage.setItem(value35Save28, sQz28);
};

function square29(){

    var sQz29 = document.getElementById("imgSqrs29").src;

    value35Save29 = "zSqrArtSpecz29";

    localStorage.setItem(value35Save29, sQz29);
};

function square30(){

    var sQz30 = document.getElementById("imgSqrs30").src;

    value35Save30 = "zSqrArtSpecz30";

    localStorage.setItem(value35Save30, sQz30);
};

function square31(){

    var sQz31 = document.getElementById("imgSqrs31").src;

    value35Save31 = "zSqrArtSpecz31";

    localStorage.setItem(value35Save31, sQz31);
};

function square32(){

    var sQz32 = document.getElementById("imgSqrs32").src;

    value35Save32 = "zSqrArtSpecz32";

    localStorage.setItem(value35Save32, sQz32);
};

function square33(){

    var sQz33 = document.getElementById("imgSqrs33").src;

    value35Save33 = "zSqrArtSpecz33";

    localStorage.setItem(value35Save33, sQz33);
};

function square34(){

    var sQz34 = document.getElementById("imgSqrs34").src;

    value35Save34 = "zSqrArtSpecz34";

    localStorage.setItem(value35Save34, sQz34);
};

function square35(){

    var sQz35 = document.getElementById("imgSqrs35").src;

    value35Save35 = "zSqrArtSpecz35";

    localStorage.setItem(value35Save35, sQz35);
};

function square36(){

    var sQz36 = document.getElementById("imgSqrs36").src;

    value35Save36 = "zSqrArtSpecz36";

    localStorage.setItem(value35Save36, sQz36);
};

function square37(){

    var sQz37 = document.getElementById("imgSqrs37").src;

    value35Save37 = "zSqrArtSpecz37";

    localStorage.setItem(value35Save37, sQz37);
};

function square38(){

    var sQz38 = document.getElementById("imgSqrs38").src;

    value35Save38 = "zSqrArtSpecz38";

    localStorage.setItem(value35Save38, sQz38);
};

function square39(){

    var sQz39 = document.getElementById("imgSqrs39").src;

    value35Save39 = "zSqrArtSpecz39";

    localStorage.setItem(value35Save39, sQz39);
};

function square40(){

    var sQz40 = document.getElementById("imgSqrs40").src;

    value35Save40 = "zSqrArtSpecz40";

    localStorage.setItem(value35Save40, sQz40);
};

function square41(){

    var sQz41 = document.getElementById("imgSqrs41").src;

    value35Save41 = "zSqrArtSpecz41";

    localStorage.setItem(value35Save41, sQz41);
};

function square42(){

    var sQz42 = document.getElementById("imgSqrs42").src;

    value35Save42 = "zSqrArtSpecz42";

    localStorage.setItem(value35Save42, sQz42);
};

function square43(){

    var sQz43 = document.getElementById("imgSqrs43").src;

    value35Save43 = "zSqrArtSpecz43";

    localStorage.setItem(value35Save43, sQz43);
};

function square44(){

    var sQz44 = document.getElementById("imgSqrs44").src;

    value35Save44 = "zSqrArtSpecz44";

    localStorage.setItem(value35Save44, sQz44);
};

function square45(){

    var sQz45 = document.getElementById("imgSqrs45").src;

    value35Save45 = "zSqrArtSpecz45";

    localStorage.setItem(value35Save45, sQz45);
};

function square46(){

    var sQz46 = document.getElementById("imgSqrs46").src;

    value35Save46 = "zSqrArtSpecz46";

    localStorage.setItem(value35Save46, sQz46);
};

function square47(){

    var sQz47 = document.getElementById("imgSqrs47").src;

    value35Save47 = "zSqrArtSpecz47";

    localStorage.setItem(value35Save47, sQz47);
};

function square48(){

    var sQz48 = document.getElementById("imgSqrs48").src;

    value35Save48 = "zSqrArtSpecz48";

    localStorage.setItem(value35Save48, sQz48);
};

function square49(){

    var sQz49 = document.getElementById("imgSqrs49").src;

    value35Save49 = "zSqrArtSpecz49";

    localStorage.setItem(value35Save49, sQz49);
};

function square50(){

    var sQz50 = document.getElementById("imgSqrs50").src;

    value35Save50 = "zSqrArtSpecz50";

    localStorage.setItem(value35Save50, sQz50);
};

function square51(){

    var sQz51 = document.getElementById("imgSqrs51").src;

    value35Save51 = "zSqrArtSpecz51";

    localStorage.setItem(value35Save51, sQz51);
};

function square52(){

    var sQz52 = document.getElementById("imgSqrs52").src;

    value35Save52 = "zSqrArtSpecz52";

    localStorage.setItem(value35Save52, sQz52);
};

function square53(){

    var sQz53 = document.getElementById("imgSqrs53").src;

    value35Save53 = "zSqrArtSpecz53";

    localStorage.setItem(value35Save53, sQz53);
};

function square54(){

    var sQz54 = document.getElementById("imgSqrs54").src;

    value35Save54 = "zSqrArtSpecz54";

    localStorage.setItem(value35Save54, sQz54);
};

function square55(){

    var sQz55 = document.getElementById("imgSqrs55").src;

    value35Save55 = "zSqrArtSpecz55";

    localStorage.setItem(value35Save55, sQz55);
};

function square56(){

    var sQz56 = document.getElementById("imgSqrs56").src;

    value35Save56 = "zSqrArtSpecz56";

    localStorage.setItem(value35Save56, sQz56);
};

function square57(){

    var sQz57 = document.getElementById("imgSqrs57").src;

    value35Save57 = "zSqrArtSpecz57";

    localStorage.setItem(value35Save57, sQz57);
};

function square58(){

    var sQz58 = document.getElementById("imgSqrs58").src;

    value35Save58 = "zSqrArtSpecz58";

    localStorage.setItem(value35Save58, sQz58);
};

function square59(){

    var sQz59 = document.getElementById("imgSqrs59").src;

    value35Save59 = "zSqrArtSpecz59";

    localStorage.setItem(value35Save59, sQz59);
};

function square60(){

    var sQz60 = document.getElementById("imgSqrs60").src;

    value35Save60 = "zSqrArtSpecz60";

    localStorage.setItem(value35Save60, sQz60);
};

function square61(){

    var sQz61 = document.getElementById("imgSqrs61").src;

    value35Save61 = "zSqrArtSpecz61";

    localStorage.setItem(value35Save61, sQz61);
};

function square62(){

    var sQz62 = document.getElementById("imgSqrs62").src;

    value35Save62 = "zSqrArtSpecz62";

    localStorage.setItem(value35Save62, sQz62);
};

function square63(){

    var sQz63 = document.getElementById("imgSqrs63").src;

    value35Save63 = "zSqrArtSpecz63";

    localStorage.setItem(value35Save63, sQz63);
};

function square64(){

    var sQz64 = document.getElementById("imgSqrs64").src;

    value35Save64 = "zSqrArtSpecz64";

    localStorage.setItem(value35Save64, sQz64);
};

function square65(){

    var sQz65 = document.getElementById("imgSqrs65").src;

    value35Save65 = "zSqrArtSpecz65";

    localStorage.setItem(value35Save65, sQz65);
};

function square66(){

    var sQz66 = document.getElementById("imgSqrs66").src;

    value35Save66 = "zSqrArtSpecz66";

    localStorage.setItem(value35Save66, sQz66);
};

function square67(){

    var sQz67 = document.getElementById("imgSqrs67").src;

    value35Save67 = "zSqrArtSpecz67";

    localStorage.setItem(value35Save67, sQz67);
};

function square68(){

    var sQz68 = document.getElementById("imgSqrs68").src;

    value35Save68 = "zSqrArtSpecz68";

    localStorage.setItem(value35Save68, sQz68);
};

function square69(){

    var sQz69 = document.getElementById("imgSqrs69").src;

    value35Save69 = "zSqrArtSpecz69";

    localStorage.setItem(value35Save69, sQz69);
};

function square70(){

    var sQz70 = document.getElementById("imgSqrs70").src;

    value35Save70 = "zSqrArtSpecz70";

    localStorage.setItem(value35Save70, sQz70);
};

function square71(){

    var sQz71 = document.getElementById("imgSqrs71").src;

    value35Save71 = "zSqrArtSpecz71";

    localStorage.setItem(value35Save71, sQz71);
};

function square72(){

    var sQz72 = document.getElementById("imgSqrs72").src;

    value35Save72 = "zSqrArtSpecz72";

    localStorage.setItem(value35Save72, sQz72);
};

function square73(){

    var sQz73 = document.getElementById("imgSqrs73").src;

    value35Save73 = "zSqrArtSpecz73";

    localStorage.setItem(value35Save73, sQz73);
};

function square74(){

    var sQz74 = document.getElementById("imgSqrs74").src;

    value35Save74 = "zSqrArtSpecz74";

    localStorage.setItem(value35Save74, sQz74);
};

function square75(){

    var sQz75 = document.getElementById("imgSqrs75").src;

    value35Save75 = "zSqrArtSpecz75";

    localStorage.setItem(value35Save75, sQz75);
};

function square76(){

    var sQz76 = document.getElementById("imgSqrs76").src;

    value35Save76 = "zSqrArtSpecz76";

    localStorage.setItem(value35Save76, sQz76);
};

function square77(){

    var sQz77 = document.getElementById("imgSqrs77").src;

    value35Save77 = "zSqrArtSpecz77";

    localStorage.setItem(value35Save77, sQz77);
};

function square78(){

    var sQz78 = document.getElementById("imgSqrs78").src;

    value35Save78 = "zSqrArtSpecz78";

    localStorage.setItem(value35Save78, sQz78);
};

function square79(){

    var sQz79 = document.getElementById("imgSqrs79").src;

    value35Save79 = "zSqrArtSpecz79";

    localStorage.setItem(value35Save79, sQz79);
};

function square80(){

    var sQz80 = document.getElementById("imgSqrs80").src;

    value35Save80 = "zSqrArtSpecz80";

    localStorage.setItem(value35Save80, sQz80);
};

function square81(){

    var sQz81 = document.getElementById("imgSqrs81").src;

    value35Save81 = "zSqrArtSpecz81";

    localStorage.setItem(value35Save81, sQz81);
};

function square82(){

    var sQz82 = document.getElementById("imgSqrs82").src;

    value35Save82 = "zSqrArtSpecz82";

    localStorage.setItem(value35Save82, sQz82);
};

function square83(){

    var sQz83 = document.getElementById("imgSqrs83").src;

    value35Save83 = "zSqrArtSpecz83";

    localStorage.setItem(value35Save83, sQz83);
};

function square84(){

    var sQz84 = document.getElementById("imgSqrs84").src;

    value35Save84 = "zSqrArtSpecz84";

    localStorage.setItem(value35Save84, sQz84);
};

function square85(){

    var sQz85 = document.getElementById("imgSqrs85").src;

    value35Save85 = "zSqrArtSpecz85";

    localStorage.setItem(value35Save85, sQz85);
};

function square86(){

    var sQz86 = document.getElementById("imgSqrs86").src;

    value35Save86 = "zSqrArtSpecz86";

    localStorage.setItem(value35Save86, sQz86);
};

function square87(){

    var sQz87 = document.getElementById("imgSqrs87").src;

    value35Save87 = "zSqrArtSpecz87";

    localStorage.setItem(value35Save87, sQz87);
};

function square88(){

    var sQz88 = document.getElementById("imgSqrs88").src;

    value35Save88 = "zSqrArtSpecz88";

    localStorage.setItem(value35Save88, sQz88);
};

function square89(){

    var sQz89 = document.getElementById("imgSqrs89").src;

    value35Save89 = "zSqrArtSpecz89";

    localStorage.setItem(value35Save89, sQz89);
};

function square90(){

    var sQz90 = document.getElementById("imgSqrs90").src;

    value35Save90 = "zSqrArtSpecz90";

    localStorage.setItem(value35Save90, sQz90);
};

function square91(){

    var sQz91 = document.getElementById("imgSqrs91").src;

    value35Save91 = "zSqrArtSpecz91";

    localStorage.setItem(value35Save91, sQz91);
};

function square92(){

    var sQz92 = document.getElementById("imgSqrs92").src;

    value35Save92 = "zSqrArtSpecz92";

    localStorage.setItem(value35Save92, sQz92);
};

function square93(){

    var sQz93 = document.getElementById("imgSqrs93").src;

    value35Save93 = "zSqrArtSpecz93";

    localStorage.setItem(value35Save93, sQz93);
};

function square94(){

    var sQz94 = document.getElementById("imgSqrs94").src;

    value35Save94 = "zSqrArtSpecz94";

    localStorage.setItem(value35Save94, sQz94);
};

function square95(){

    var sQz95 = document.getElementById("imgSqrs95").src;

    value35Save95 = "zSqrArtSpecz95";

    localStorage.setItem(value35Save95, sQz95);
};

function square96(){

    var sQz96 = document.getElementById("imgSqrs96").src;

    value35Save96 = "zSqrArtSpecz96";

    localStorage.setItem(value35Save96, sQz96);
};

function square97(){

    var sQz97 = document.getElementById("imgSqrs97").src;

    value35Save97 = "zSqrArtSpecz97";

    localStorage.setItem(value35Save97, sQz97);
};

function square98(){

    var sQz98 = document.getElementById("imgSqrs98").src;

    value35Save98 = "zSqrArtSpecz98";

    localStorage.setItem(value35Save98, sQz98);
};

function square99(){

    var sQz99 = document.getElementById("imgSqrs99").src;

    value35Save99 = "zSqrArtSpecz99";

    localStorage.setItem(value35Save99, sQz99);
};

function square100(){

    var sQz100 = document.getElementById("imgSqrs100").src;

    value35Save100 = "zSqrArtSpecz100";

    localStorage.setItem(value35Save100, sQz100);
};

function square101(){

    var sQz101 = document.getElementById("imgSqrs101").src;

    value35Save101 = "zSqrArtSpecz101";

    localStorage.setItem(value35Save101, sQz101);
};

function square102(){

    var sQz102 = document.getElementById("imgSqrs102").src;

    value35Save102 = "zSqrArtSpecz102";

    localStorage.setItem(value35Save102, sQz102);
};

function square103(){

    var sQz103 = document.getElementById("imgSqrs103").src;

    value35Save103 = "zSqrArtSpecz103";

    localStorage.setItem(value35Save103, sQz103);
};

function square104(){

    var sQz104 = document.getElementById("imgSqrs104").src;

    value35Save104 = "zSqrArtSpecz104";

    localStorage.setItem(value35Save104, sQz104);
};

function square105(){

    var sQz105 = document.getElementById("imgSqrs105").src;

    value35Save105 = "zSqrArtSpecz105";

    localStorage.setItem(value35Save105, sQz105);
};

function square106(){

    var sQz106 = document.getElementById("imgSqrs106").src;

    value35Save106 = "zSqrArtSpecz106";

    localStorage.setItem(value35Save106, sQz106);
};

function square107(){

    var sQz107 = document.getElementById("imgSqrs107").src;

    value35Save107 = "zSqrArtSpecz107";

    localStorage.setItem(value35Save107, sQz107);
};

function square108(){

    var sQz108 = document.getElementById("imgSqrs108").src;

    value35Save108 = "zSqrArtSpecz108";

    localStorage.setItem(value35Save108, sQz108);
};

function square109(){

    var sQz109 = document.getElementById("imgSqrs109").src;

    value35Save109 = "zSqrArtSpecz109";

    localStorage.setItem(value35Save109, sQz109);
};

function square110(){

    var sQz110 = document.getElementById("imgSqrs110").src;

    value35Save110 = "zSqrArtSpecz110";

    localStorage.setItem(value35Save110, sQz110);
};

function square111(){

    var sQz111 = document.getElementById("imgSqrs111").src;

    value35Save111 = "zSqrArtSpecz111";

    localStorage.setItem(value35Save111, sQz111);
};

function square112(){

    var sQz112 = document.getElementById("imgSqrs112").src;

    value35Save112 = "zSqrArtSpecz112";

    localStorage.setItem(value35Save112, sQz112);
};

function square113(){

    var sQz113 = document.getElementById("imgSqrs113").src;

    value35Save113 = "zSqrArtSpecz113";

    localStorage.setItem(value35Save113, sQz113);
};

function square114(){

    var sQz114 = document.getElementById("imgSqrs114").src;

    value35Save114 = "zSqrArtSpecz114";

    localStorage.setItem(value35Save114, sQz114);
};

function square115(){

    var sQz115 = document.getElementById("imgSqrs115").src;

    value35Save115 = "zSqrArtSpecz115";

    localStorage.setItem(value35Save115, sQz115);
};

function square116(){

    var sQz116 = document.getElementById("imgSqrs116").src;

    value35Save116 = "zSqrArtSpecz116";

    localStorage.setItem(value35Save116, sQz116);
};

function square117(){

    var sQz117 = document.getElementById("imgSqrs117").src;

    value35Save117 = "zSqrArtSpecz117";

    localStorage.setItem(value35Save117, sQz117);
};

function square118(){

    var sQz118 = document.getElementById("imgSqrs118").src;

    value35Save118 = "zSqrArtSpecz118";

    localStorage.setItem(value35Save118, sQz118);
};

function square119(){

    var sQz119 = document.getElementById("imgSqrs119").src;

    value35Save119 = "zSqrArtSpecz119";

    localStorage.setItem(value35Save119, sQz119);
};

function square120(){

    var sQz120 = document.getElementById("imgSqrs120").src;

    value35Save120 = "zSqrArtSpecz120";

    localStorage.setItem(value35Save120, sQz120);
};

function square121(){

    var sQz121 = document.getElementById("imgSqrs121").src;

    value35Save121 = "zSqrArtSpecz121";

    localStorage.setItem(value35Save121, sQz121);
};

function square122(){

    var sQz122 = document.getElementById("imgSqrs122").src;

    value35Save122 = "zSqrArtSpecz122";

    localStorage.setItem(value35Save122, sQz122);
};

function square123(){

    var sQz123 = document.getElementById("imgSqrs123").src;

    value35Save123 = "zSqrArtSpecz123";

    localStorage.setItem(value35Save123, sQz123);
};

function square124(){

    var sQz124 = document.getElementById("imgSqrs124").src;

    value35Save124 = "zSqrArtSpecz124";

    localStorage.setItem(value35Save124, sQz124);
};

function square125(){

    var sQz125 = document.getElementById("imgSqrs125").src;

    value35Save125 = "zSqrArtSpecz125";

    localStorage.setItem(value35Save125, sQz125);
};

function square126(){

    var sQz126 = document.getElementById("imgSqrs126").src;

    value35Save126 = "zSqrArtSpecz126";

    localStorage.setItem(value35Save126, sQz126);
};

function square127(){

    var sQz127 = document.getElementById("imgSqrs127").src;

    value35Save127 = "zSqrArtSpecz127";

    localStorage.setItem(value35Save127, sQz127);
};

function square128(){

    var sQz128 = document.getElementById("imgSqrs128").src;

    value35Save128 = "zSqrArtSpecz128";

    localStorage.setItem(value35Save128, sQz128);
};

function square129(){

    var sQz129 = document.getElementById("imgSqrs129").src;

    value35Save129 = "zSqrArtSpecz129";

    localStorage.setItem(value35Save129, sQz129);
};

function square130(){

    var sQz130 = document.getElementById("imgSqrs130").src;

    value35Save130 = "zSqrArtSpecz130";

    localStorage.setItem(value35Save130, sQz130);
};

function square131(){

    var sQz131 = document.getElementById("imgSqrs131").src;

    value35Save131 = "zSqrArtSpecz131";

    localStorage.setItem(value35Save131, sQz131);
};

function square132(){

    var sQz132 = document.getElementById("imgSqrs132").src;

    value35Save132 = "zSqrArtSpecz132";

    localStorage.setItem(value35Save132, sQz132);
};

function square133(){

    var sQz133 = document.getElementById("imgSqrs133").src;

    value35Save133 = "zSqrArtSpecz133";

    localStorage.setItem(value35Save133, sQz133);
};

function square134(){

    var sQz134 = document.getElementById("imgSqrs134").src;

    value35Save134 = "zSqrArtSpecz134";

    localStorage.setItem(value35Save134, sQz134);
};

function square135(){

    var sQz135 = document.getElementById("imgSqrs135").src;

    value35Save135 = "zSqrArtSpecz135";

    localStorage.setItem(value35Save135, sQz135);
};

function square136(){

    var sQz136 = document.getElementById("imgSqrs136").src;

    value35Save136 = "zSqrArtSpecz136";

    localStorage.setItem(value35Save136, sQz136);
};

function square137(){

    var sQz137 = document.getElementById("imgSqrs137").src;

    value35Save137 = "zSqrArtSpecz137";

    localStorage.setItem(value35Save137, sQz137);
};

function square138(){

    var sQz138 = document.getElementById("imgSqrs138").src;

    value35Save138 = "zSqrArtSpecz138";

    localStorage.setItem(value35Save138, sQz138);
};

function square139(){

    var sQz139 = document.getElementById("imgSqrs139").src;

    value35Save139 = "zSqrArtSpecz139";

    localStorage.setItem(value35Save139, sQz139);
};

function square140(){

    var sQz140 = document.getElementById("imgSqrs140").src;

    value35Save140 = "zSqrArtSpecz140";

    localStorage.setItem(value35Save140, sQz140);
};

function square141(){

    var sQz141 = document.getElementById("imgSqrs141").src;

    value35Save141 = "zSqrArtSpecz141";

    localStorage.setItem(value35Save141, sQz141);
};

function square142(){

    var sQz142 = document.getElementById("imgSqrs142").src;

    value35Save142 = "zSqrArtSpecz142";

    localStorage.setItem(value35Save142, sQz142);
};

function square143(){

    var sQz143 = document.getElementById("imgSqrs143").src;

    value35Save143 = "zSqrArtSpecz143";

    localStorage.setItem(value35Save143, sQz143);
};

function square144(){

    var sQz144 = document.getElementById("imgSqrs144").src;

    value35Save144 = "zSqrArtSpecz144";

    localStorage.setItem(value35Save144, sQz144);
};

function square145(){

    var sQz145 = document.getElementById("imgSqrs145").src;

    value35Save145 = "zSqrArtSpecz145";

    localStorage.setItem(value35Save145, sQz145);
};

function square146(){

    var sQz146 = document.getElementById("imgSqrs146").src;

    value35Save146 = "zSqrArtSpecz146";

    localStorage.setItem(value35Save146, sQz146);
};

function square147(){

    var sQz147 = document.getElementById("imgSqrs147").src;

    value35Save147 = "zSqrArtSpecz147";

    localStorage.setItem(value35Save147, sQz147);
};

function square148(){

    var sQz148 = document.getElementById("imgSqrs148").src;

    value35Save148 = "zSqrArtSpecz148";

    localStorage.setItem(value35Save148, sQz148);
};

function square149(){

    var sQz149 = document.getElementById("imgSqrs149").src;

    value35Save149 = "zSqrArtSpecz149";

    localStorage.setItem(value35Save149, sQz149);
};

function square150(){

    var sQz150 = document.getElementById("imgSqrs150").src;

    value35Save150 = "zSqrArtSpecz150";

    localStorage.setItem(value35Save150, sQz150);
};

function square151(){

    var sQz151 = document.getElementById("imgSqrs151").src;

    value35Save151 = "zSqrArtSpecz151";

    localStorage.setItem(value35Save151, sQz151);
};

function square152(){

    var sQz152 = document.getElementById("imgSqrs152").src;

    value35Save152 = "zSqrArtSpecz152";

    localStorage.setItem(value35Save152, sQz152);
};

function square153(){

    var sQz153 = document.getElementById("imgSqrs153").src;

    value35Save153 = "zSqrArtSpecz153";

    localStorage.setItem(value35Save153, sQz153);
};

function square154(){

    var sQz154 = document.getElementById("imgSqrs154").src;

    value35Save154 = "zSqrArtSpecz154";

    localStorage.setItem(value35Save154, sQz154);
};

function square155(){

    var sQz155 = document.getElementById("imgSqrs155").src;

    value35Save155 = "zSqrArtSpecz155";

    localStorage.setItem(value35Save155, sQz155);
};

function square156(){

    var sQz156 = document.getElementById("imgSqrs156").src;

    value35Save156 = "zSqrArtSpecz156";

    localStorage.setItem(value35Save156, sQz156);
};

function square157(){

    var sQz157 = document.getElementById("imgSqrs157").src;

    value35Save157 = "zSqrArtSpecz157";

    localStorage.setItem(value35Save157, sQz157);
};

function square158(){

    var sQz158 = document.getElementById("imgSqrs158").src;

    value35Save158 = "zSqrArtSpecz158";

    localStorage.setItem(value35Save158, sQz158);
};

function square159(){

    var sQz159 = document.getElementById("imgSqrs159").src;

    value35Save159 = "zSqrArtSpecz159";

    localStorage.setItem(value35Save159, sQz159);
};

function square160(){

    var sQz160 = document.getElementById("imgSqrs160").src;

    value35Save160 = "zSqrArtSpecz160";

    localStorage.setItem(value35Save160, sQz160);
};

function square161(){

    var sQz161 = document.getElementById("imgSqrs161").src;

    value35Save161 = "zSqrArtSpecz161";

    localStorage.setItem(value35Save161, sQz161);
};

function square162(){

    var sQz162 = document.getElementById("imgSqrs162").src;

    value35Save162 = "zSqrArtSpecz162";

    localStorage.setItem(value35Save162, sQz162);
};

function square163(){

    var sQz163 = document.getElementById("imgSqrs163").src;

    value35Save163 = "zSqrArtSpecz163";

    localStorage.setItem(value35Save163, sQz163);
};

function square164(){

    var sQz164 = document.getElementById("imgSqrs164").src;

    value35Save164 = "zSqrArtSpecz164";

    localStorage.setItem(value35Save164, sQz164);
};

function square165(){

    var sQz165 = document.getElementById("imgSqrs165").src;

    value35Save165 = "zSqrArtSpecz165";

    localStorage.setItem(value35Save165, sQz165);
};

function square166(){

    var sQz166 = document.getElementById("imgSqrs166").src;

    value35Save166 = "zSqrArtSpecz166";

    localStorage.setItem(value35Save166, sQz166);
};

function square167(){

    var sQz167 = document.getElementById("imgSqrs167").src;

    value35Save167 = "zSqrArtSpecz167";

    localStorage.setItem(value35Save167, sQz167);
};

function square168(){

    var sQz168 = document.getElementById("imgSqrs168").src;

    value35Save168 = "zSqrArtSpecz168";

    localStorage.setItem(value35Save168, sQz168);
};

function square169(){

    var sQz169 = document.getElementById("imgSqrs169").src;

    value35Save169 = "zSqrArtSpecz169";

    localStorage.setItem(value35Save169, sQz169);
};

function square170(){

    var sQz170 = document.getElementById("imgSqrs170").src;

    value35Save170 = "zSqrArtSpecz170";

    localStorage.setItem(value35Save170, sQz170);
};

function square171(){

    var sQz171 = document.getElementById("imgSqrs171").src;

    value35Save171 = "zSqrArtSpecz171";

    localStorage.setItem(value35Save171, sQz171);
};

function square172(){

    var sQz172 = document.getElementById("imgSqrs172").src;

    value35Save172 = "zSqrArtSpecz172";

    localStorage.setItem(value35Save172, sQz172);
};

function square173(){

    var sQz173 = document.getElementById("imgSqrs173").src;

    value35Save173 = "zSqrArtSpecz173";

    localStorage.setItem(value35Save173, sQz173);
};

function square174(){

    var sQz174 = document.getElementById("imgSqrs174").src;

    value35Save174 = "zSqrArtSpecz174";

    localStorage.setItem(value35Save174, sQz174);
};

function square175(){

    var sQz175 = document.getElementById("imgSqrs175").src;

    value35Save175 = "zSqrArtSpecz175";

    localStorage.setItem(value35Save175, sQz175);
};

function square176(){

    var sQz176 = document.getElementById("imgSqrs176").src;

    value35Save176 = "zSqrArtSpecz176";

    localStorage.setItem(value35Save176, sQz176);
};

function square177(){

    var sQz177 = document.getElementById("imgSqrs177").src;

    value35Save177 = "zSqrArtSpecz177";

    localStorage.setItem(value35Save177, sQz177);
};

function square178(){

    var sQz178 = document.getElementById("imgSqrs178").src;

    value35Save178 = "zSqrArtSpecz178";

    localStorage.setItem(value35Save178, sQz178);
};

function square179(){

    var sQz179 = document.getElementById("imgSqrs179").src;

    value35Save179 = "zSqrArtSpecz179";

    localStorage.setItem(value35Save179, sQz179);
};

function square180(){

    var sQz180 = document.getElementById("imgSqrs180").src;

    value35Save180 = "zSqrArtSpecz180";

    localStorage.setItem(value35Save180, sQz180);
};

function square181(){

    var sQz181 = document.getElementById("imgSqrs181").src;

    value35Save181 = "zSqrArtSpecz181";

    localStorage.setItem(value35Save181, sQz181);
};

function square182(){

    var sQz182 = document.getElementById("imgSqrs182").src;

    value35Save182 = "zSqrArtSpecz182";

    localStorage.setItem(value35Save182, sQz182);
};

function square183(){

    var sQz183 = document.getElementById("imgSqrs183").src;

    value35Save183 = "zSqrArtSpecz183";

    localStorage.setItem(value35Save183, sQz183);
};

function square184(){

    var sQz184 = document.getElementById("imgSqrs184").src;

    value35Save184 = "zSqrArtSpecz184";

    localStorage.setItem(value35Save184, sQz184);
};

function square185(){

    var sQz185 = document.getElementById("imgSqrs185").src;

    value35Save185 = "zSqrArtSpecz185";

    localStorage.setItem(value35Save185, sQz185);
};

function square186(){

    var sQz186 = document.getElementById("imgSqrs186").src;

    value35Save186 = "zSqrArtSpecz186";

    localStorage.setItem(value35Save186, sQz186);
};

function square187(){

    var sQz187 = document.getElementById("imgSqrs187").src;

    value35Save187 = "zSqrArtSpecz187";

    localStorage.setItem(value35Save187, sQz187);
};

function square188(){

    var sQz188 = document.getElementById("imgSqrs188").src;

    value35Save188 = "zSqrArtSpecz188";

    localStorage.setItem(value35Save188, sQz188);
};

function square189(){

    var sQz189 = document.getElementById("imgSqrs189").src;

    value35Save189 = "zSqrArtSpecz189";

    localStorage.setItem(value35Save189, sQz189);
};

function square190(){

    var sQz190 = document.getElementById("imgSqrs190").src;

    value35Save190 = "zSqrArtSpecz190";

    localStorage.setItem(value35Save190, sQz190);
};

function square191(){

    var sQz191 = document.getElementById("imgSqrs191").src;

    value35Save191 = "zSqrArtSpecz191";

    localStorage.setItem(value35Save191, sQz191);
};

function square192(){

    var sQz192 = document.getElementById("imgSqrs192").src;

    value35Save192 = "zSqrArtSpecz192";

    localStorage.setItem(value35Save192, sQz192);
};

function square193(){

    var sQz193 = document.getElementById("imgSqrs193").src;

    value35Save193 = "zSqrArtSpecz193";

    localStorage.setItem(value35Save193, sQz193);
};

function square194(){

    var sQz194 = document.getElementById("imgSqrs194").src;

    value35Save194 = "zSqrArtSpecz194";

    localStorage.setItem(value35Save194, sQz194);
};

function square195(){

    var sQz195 = document.getElementById("imgSqrs195").src;

    value35Save195 = "zSqrArtSpecz195";

    localStorage.setItem(value35Save195, sQz195);
};

function square196(){

    var sQz196 = document.getElementById("imgSqrs196").src;

    value35Save196 = "zSqrArtSpecz196";

    localStorage.setItem(value35Save196, sQz196);
};

function square197(){

    var sQz197 = document.getElementById("imgSqrs197").src;

    value35Save197 = "zSqrArtSpecz197";

    localStorage.setItem(value35Save197, sQz197);
};

function square198(){

    var sQz198 = document.getElementById("imgSqrs198").src;

    value35Save198 = "zSqrArtSpecz198";

    localStorage.setItem(value35Save198, sQz198);
};

function square199(){

    var sQz199 = document.getElementById("imgSqrs199").src;

    value35Save199 = "zSqrArtSpecz199";

    localStorage.setItem(value35Save199, sQz199);
};

function square200(){

    var sQz200 = document.getElementById("imgSqrs200").src;

    value35Save200 = "zSqrArtSpecz200";

    localStorage.setItem(value35Save200, sQz200);
};

function square201(){

    var sQz201 = document.getElementById("imgSqrs201").src;

    value35Save201 = "zSqrArtSpecz201";

    localStorage.setItem(value35Save201, sQz201);
};

function square202(){

    var sQz202 = document.getElementById("imgSqrs202").src;

    value35Save202 = "zSqrArtSpecz202";

    localStorage.setItem(value35Save202, sQz202);
};

function square203(){

    var sQz203 = document.getElementById("imgSqrs203").src;

    value35Save203 = "zSqrArtSpecz203";

    localStorage.setItem(value35Save203, sQz203);
};

function square204(){

    var sQz204 = document.getElementById("imgSqrs204").src;

    value35Save204 = "zSqrArtSpecz204";

    localStorage.setItem(value35Save204, sQz204);
};

function square205(){

    var sQz205 = document.getElementById("imgSqrs205").src;

    value35Save205 = "zSqrArtSpecz205";

    localStorage.setItem(value35Save205, sQz205);
};

function square206(){

    var sQz206 = document.getElementById("imgSqrs206").src;

    value35Save206 = "zSqrArtSpecz206";

    localStorage.setItem(value35Save206, sQz206);
};

function square207(){

    var sQz207 = document.getElementById("imgSqrs207").src;

    value35Save207 = "zSqrArtSpecz207";

    localStorage.setItem(value35Save207, sQz207);
};

function square208(){

    var sQz208 = document.getElementById("imgSqrs208").src;

    value35Save208 = "zSqrArtSpecz208";

    localStorage.setItem(value35Save208, sQz208);
};

function square209(){

    var sQz209 = document.getElementById("imgSqrs209").src;

    value35Save209 = "zSqrArtSpecz209";

    localStorage.setItem(value35Save209, sQz209);
};

function square210(){

    var sQz210 = document.getElementById("imgSqrs210").src;

    value35Save210 = "zSqrArtSpecz210";

    localStorage.setItem(value35Save210, sQz210);
};

function square211(){

    var sQz211 = document.getElementById("imgSqrs211").src;

    value35Save211 = "zSqrArtSpecz211";

    localStorage.setItem(value35Save211, sQz211);
};

function square212(){

    var sQz212 = document.getElementById("imgSqrs212").src;

    value35Save212 = "zSqrArtSpecz212";

    localStorage.setItem(value35Save212, sQz212);
};

function square213(){

    var sQz213 = document.getElementById("imgSqrs213").src;

    value35Save213 = "zSqrArtSpecz213";

    localStorage.setItem(value35Save213, sQz213);
};

function square214(){

    var sQz214 = document.getElementById("imgSqrs214").src;

    value35Save214 = "zSqrArtSpecz214";

    localStorage.setItem(value35Save214, sQz214);
};

function square215(){

    var sQz215 = document.getElementById("imgSqrs215").src;

    value35Save215 = "zSqrArtSpecz215";

    localStorage.setItem(value35Save215, sQz215);
};

function square216(){

    var sQz216 = document.getElementById("imgSqrs216").src;

    value35Save216 = "zSqrArtSpecz216";

    localStorage.setItem(value35Save216, sQz216);
};

function square217(){

    var sQz217 = document.getElementById("imgSqrs217").src;

    value35Save217 = "zSqrArtSpecz217";

    localStorage.setItem(value35Save217, sQz217);
};

function square218(){

    var sQz218 = document.getElementById("imgSqrs218").src;

    value35Save218 = "zSqrArtSpecz218";

    localStorage.setItem(value35Save218, sQz218);
};

function square219(){

    var sQz219 = document.getElementById("imgSqrs219").src;

    value35Save219 = "zSqrArtSpecz219";

    localStorage.setItem(value35Save219, sQz219);
};

function square220(){

    var sQz220 = document.getElementById("imgSqrs220").src;

    value35Save220 = "zSqrArtSpecz220";

    localStorage.setItem(value35Save220, sQz220);
};

function square221(){

    var sQz221 = document.getElementById("imgSqrs221").src;

    value35Save221 = "zSqrArtSpecz221";

    localStorage.setItem(value35Save221, sQz221);
};

function square222(){

    var sQz222 = document.getElementById("imgSqrs222").src;

    value35Save222 = "zSqrArtSpecz222";

    localStorage.setItem(value35Save222, sQz222);
};

function square223(){

    var sQz223 = document.getElementById("imgSqrs223").src;

    value35Save223 = "zSqrArtSpecz223";

    localStorage.setItem(value35Save223, sQz223);
};

function square224(){

    var sQz224 = document.getElementById("imgSqrs224").src;

    value35Save224 = "zSqrArtSpecz224";

    localStorage.setItem(value35Save224, sQz224);
};

function square225(){

    var sQz225 = document.getElementById("imgSqrs225").src;

    value35Save225 = "zSqrArtSpecz225";

    localStorage.setItem(value35Save225, sQz225);
};

function square226(){

    var sQz226 = document.getElementById("imgSqrs226").src;

    value35Save226 = "zSqrArtSpecz226";

    localStorage.setItem(value35Save226, sQz226);
};

function square227(){

    var sQz227 = document.getElementById("imgSqrs227").src;

    value35Save227 = "zSqrArtSpecz227";

    localStorage.setItem(value35Save227, sQz227);
};

function square228(){

    var sQz228 = document.getElementById("imgSqrs228").src;

    value35Save228 = "zSqrArtSpecz228";

    localStorage.setItem(value35Save228, sQz228);
};

function square229(){

    var sQz229 = document.getElementById("imgSqrs229").src;

    value35Save229 = "zSqrArtSpecz229";

    localStorage.setItem(value35Save229, sQz229);
};

function square230(){

    var sQz230 = document.getElementById("imgSqrs230").src;

    value35Save230 = "zSqrArtSpecz230";

    localStorage.setItem(value35Save230, sQz230);
};

function square231(){

    var sQz231 = document.getElementById("imgSqrs231").src;

    value35Save231 = "zSqrArtSpecz231";

    localStorage.setItem(value35Save231, sQz231);
};

function square232(){

    var sQz232 = document.getElementById("imgSqrs232").src;

    value35Save232 = "zSqrArtSpecz232";

    localStorage.setItem(value35Save232, sQz232);
};

function square233(){

    var sQz233 = document.getElementById("imgSqrs233").src;

    value35Save233 = "zSqrArtSpecz233";

    localStorage.setItem(value35Save233, sQz233);
};

function square234(){

    var sQz234 = document.getElementById("imgSqrs234").src;

    value35Save234 = "zSqrArtSpecz234";

    localStorage.setItem(value35Save234, sQz234);
};

function square235(){

    var sQz235 = document.getElementById("imgSqrs235").src;

    value35Save235 = "zSqrArtSpecz235";

    localStorage.setItem(value35Save235, sQz235);
};

function square236(){

    var sQz236 = document.getElementById("imgSqrs236").src;

    value35Save236 = "zSqrArtSpecz236";

    localStorage.setItem(value35Save236, sQz236);
};

function square237(){

    var sQz237 = document.getElementById("imgSqrs237").src;

    value35Save237 = "zSqrArtSpecz237";

    localStorage.setItem(value35Save237, sQz237);
};

function square238(){

    var sQz238 = document.getElementById("imgSqrs238").src;

    value35Save238 = "zSqrArtSpecz238";

    localStorage.setItem(value35Save238, sQz238);
};

function square239(){

    var sQz239 = document.getElementById("imgSqrs239").src;

    value35Save239 = "zSqrArtSpecz239";

    localStorage.setItem(value35Save239, sQz239);
};

function square240(){

    var sQz240 = document.getElementById("imgSqrs240").src;

    value35Save240 = "zSqrArtSpecz240";

    localStorage.setItem(value35Save240, sQz240);
};

function square241(){

    var sQz241 = document.getElementById("imgSqrs241").src;

    value35Save241 = "zSqrArtSpecz241";

    localStorage.setItem(value35Save241, sQz241);
};

function square242(){

    var sQz242 = document.getElementById("imgSqrs242").src;

    value35Save242 = "zSqrArtSpecz242";

    localStorage.setItem(value35Save242, sQz242);
};

function square243(){

    var sQz243 = document.getElementById("imgSqrs243").src;

    value35Save243 = "zSqrArtSpecz243";

    localStorage.setItem(value35Save243, sQz243);
};

function square244(){

    var sQz244 = document.getElementById("imgSqrs244").src;

    value35Save244 = "zSqrArtSpecz244";

    localStorage.setItem(value35Save244, sQz244);
};

function square245(){

    var sQz245 = document.getElementById("imgSqrs245").src;

    value35Save245 = "zSqrArtSpecz245";

    localStorage.setItem(value35Save245, sQz245);
};

function square246(){

    var sQz246 = document.getElementById("imgSqrs246").src;

    value35Save246 = "zSqrArtSpecz246";

    localStorage.setItem(value35Save246, sQz246);
};

function square247(){

    var sQz247 = document.getElementById("imgSqrs247").src;

    value35Save247 = "zSqrArtSpecz247";

    localStorage.setItem(value35Save247, sQz247);
};

function square248(){

    var sQz248 = document.getElementById("imgSqrs248").src;

    value35Save248 = "zSqrArtSpecz248";

    localStorage.setItem(value35Save248, sQz248);
};

function square249(){

    var sQz249 = document.getElementById("imgSqrs249").src;

    value35Save249 = "zSqrArtSpecz249";

    localStorage.setItem(value35Save249, sQz249);
};

function square250(){

    var sQz250 = document.getElementById("imgSqrs250").src;

    value35Save250 = "zSqrArtSpecz250";

    localStorage.setItem(value35Save250, sQz250);
};

function square251(){

    var sQz251 = document.getElementById("imgSqrs251").src;

    value35Save251 = "zSqrArtSpecz251";

    localStorage.setItem(value35Save251, sQz251);
};

function square252(){

    var sQz252 = document.getElementById("imgSqrs252").src;

    value35Save252 = "zSqrArtSpecz252";

    localStorage.setItem(value35Save252, sQz252);
};

function square253(){

    var sQz253 = document.getElementById("imgSqrs253").src;

    value35Save253 = "zSqrArtSpecz253";

    localStorage.setItem(value35Save253, sQz253);
};

function square254(){

    var sQz254 = document.getElementById("imgSqrs254").src;

    value35Save254 = "zSqrArtSpecz254";

    localStorage.setItem(value35Save254, sQz254);
};

function square255(){

    var sQz255 = document.getElementById("imgSqrs255").src;

    value35Save255 = "zSqrArtSpecz255";

    localStorage.setItem(value35Save255, sQz255);
};

function square256(){

    var sQz256 = document.getElementById("imgSqrs256").src;

    value35Save256 = "zSqrArtSpecz256";

    localStorage.setItem(value35Save256, sQz256);
};

function square257(){

    var sQz257 = document.getElementById("imgSqrs257").src;

    value35Save257 = "zSqrArtSpecz257";

    localStorage.setItem(value35Save257, sQz257);
};

function square258(){

    var sQz258 = document.getElementById("imgSqrs258").src;

    value35Save258 = "zSqrArtSpecz258";

    localStorage.setItem(value35Save258, sQz258);
};

function square259(){

    var sQz259 = document.getElementById("imgSqrs259").src;

    value35Save259 = "zSqrArtSpecz259";

    localStorage.setItem(value35Save259, sQz259);
};

function square260(){

    var sQz260 = document.getElementById("imgSqrs260").src;

    value35Save260 = "zSqrArtSpecz260";

    localStorage.setItem(value35Save260, sQz260);
};

function square261(){

    var sQz261 = document.getElementById("imgSqrs261").src;

    value35Save261 = "zSqrArtSpecz261";

    localStorage.setItem(value35Save261, sQz261);
};

function square262(){

    var sQz262 = document.getElementById("imgSqrs262").src;

    value35Save262 = "zSqrArtSpecz262";

    localStorage.setItem(value35Save262, sQz262);
};

function square263(){

    var sQz263 = document.getElementById("imgSqrs263").src;

    value35Save263 = "zSqrArtSpecz263";

    localStorage.setItem(value35Save263, sQz263);
};

function square264(){

    var sQz264 = document.getElementById("imgSqrs264").src;

    value35Save264 = "zSqrArtSpecz264";

    localStorage.setItem(value35Save264, sQz264);
};

function square265(){

    var sQz265 = document.getElementById("imgSqrs265").src;

    value35Save265 = "zSqrArtSpecz265";

    localStorage.setItem(value35Save265, sQz265);
};

function square266(){

    var sQz266 = document.getElementById("imgSqrs266").src;

    value35Save266 = "zSqrArtSpecz266";

    localStorage.setItem(value35Save266, sQz266);
};

function square267(){

    var sQz267 = document.getElementById("imgSqrs267").src;

    value35Save267 = "zSqrArtSpecz267";

    localStorage.setItem(value35Save267, sQz267);
};

function square268(){

    var sQz268 = document.getElementById("imgSqrs268").src;

    value35Save268 = "zSqrArtSpecz268";

    localStorage.setItem(value35Save268, sQz268);
};

function square269(){

    var sQz269 = document.getElementById("imgSqrs269").src;

    value35Save269 = "zSqrArtSpecz269";

    localStorage.setItem(value35Save269, sQz269);
};

function square270(){

    var sQz270 = document.getElementById("imgSqrs270").src;

    value35Save270 = "zSqrArtSpecz270";

    localStorage.setItem(value35Save270, sQz270);
};

function square271(){

    var sQz271 = document.getElementById("imgSqrs271").src;

    value35Save271 = "zSqrArtSpecz271";

    localStorage.setItem(value35Save271, sQz271);
};

function square272(){

    var sQz272 = document.getElementById("imgSqrs272").src;

    value35Save272 = "zSqrArtSpecz272";

    localStorage.setItem(value35Save272, sQz272);
};

function square273(){

    var sQz273 = document.getElementById("imgSqrs273").src;

    value35Save273 = "zSqrArtSpecz273";

    localStorage.setItem(value35Save273, sQz273);
};

function square274(){

    var sQz274 = document.getElementById("imgSqrs274").src;

    value35Save274 = "zSqrArtSpecz274";

    localStorage.setItem(value35Save274, sQz274);
};

function square275(){

    var sQz275 = document.getElementById("imgSqrs275").src;

    value35Save275 = "zSqrArtSpecz275";

    localStorage.setItem(value35Save275, sQz275);
};

function square276(){

    var sQz276 = document.getElementById("imgSqrs276").src;

    value35Save276 = "zSqrArtSpecz276";

    localStorage.setItem(value35Save276, sQz276);
};

function square277(){

    var sQz277 = document.getElementById("imgSqrs277").src;

    value35Save277 = "zSqrArtSpecz277";

    localStorage.setItem(value35Save277, sQz277);
};

function square278(){

    var sQz278 = document.getElementById("imgSqrs278").src;

    value35Save278 = "zSqrArtSpecz278";

    localStorage.setItem(value35Save278, sQz278);
};

function square279(){

    var sQz279 = document.getElementById("imgSqrs279").src;

    value35Save279 = "zSqrArtSpecz279";

    localStorage.setItem(value35Save279, sQz279);
};

function square280(){

    var sQz280 = document.getElementById("imgSqrs280").src;

    value35Save280 = "zSqrArtSpecz280";

    localStorage.setItem(value35Save280, sQz280);
};

function square281(){

    var sQz281 = document.getElementById("imgSqrs281").src;

    value35Save281 = "zSqrArtSpecz281";

    localStorage.setItem(value35Save281, sQz281);
};

function square282(){

    var sQz282 = document.getElementById("imgSqrs282").src;

    value35Save282 = "zSqrArtSpecz282";

    localStorage.setItem(value35Save282, sQz282);
};

function square283(){

    var sQz283 = document.getElementById("imgSqrs283").src;

    value35Save283 = "zSqrArtSpecz283";

    localStorage.setItem(value35Save283, sQz283);
};

function square284(){

    var sQz284 = document.getElementById("imgSqrs284").src;

    value35Save284 = "zSqrArtSpecz284";

    localStorage.setItem(value35Save284, sQz284);
};

function square285(){

    var sQz285 = document.getElementById("imgSqrs285").src;

    value35Save285 = "zSqrArtSpecz285";

    localStorage.setItem(value35Save285, sQz285);
};

function square286(){

    var sQz286 = document.getElementById("imgSqrs286").src;

    value35Save286 = "zSqrArtSpecz286";

    localStorage.setItem(value35Save286, sQz286);
};

function square287(){

    var sQz287 = document.getElementById("imgSqrs287").src;

    value35Save287 = "zSqrArtSpecz287";

    localStorage.setItem(value35Save287, sQz287);
};

function square288(){

    var sQz288 = document.getElementById("imgSqrs288").src;

    value35Save288 = "zSqrArtSpecz288";

    localStorage.setItem(value35Save288, sQz288);
};

function square289(){

    var sQz289 = document.getElementById("imgSqrs289").src;

    value35Save289 = "zSqrArtSpecz289";

    localStorage.setItem(value35Save289, sQz289);
};

function square290(){

    var sQz290 = document.getElementById("imgSqrs290").src;

    value35Save290 = "zSqrArtSpecz290";

    localStorage.setItem(value35Save290, sQz290);
};

function square291(){

    var sQz291 = document.getElementById("imgSqrs291").src;

    value35Save291 = "zSqrArtSpecz291";

    localStorage.setItem(value35Save291, sQz291);
};

function square292(){

    var sQz292 = document.getElementById("imgSqrs292").src;

    value35Save292 = "zSqrArtSpecz292";

    localStorage.setItem(value35Save292, sQz292);
};

function square293(){

    var sQz293 = document.getElementById("imgSqrs293").src;

    value35Save293 = "zSqrArtSpecz293";

    localStorage.setItem(value35Save293, sQz293);
};

function square294(){

    var sQz294 = document.getElementById("imgSqrs294").src;

    value35Save294 = "zSqrArtSpecz294";

    localStorage.setItem(value35Save294, sQz294);
};

function square295(){

    var sQz295 = document.getElementById("imgSqrs295").src;

    value35Save295 = "zSqrArtSpecz295";

    localStorage.setItem(value35Save295, sQz295);
};

function square296(){

    var sQz296 = document.getElementById("imgSqrs296").src;

    value35Save296 = "zSqrArtSpecz296";

    localStorage.setItem(value35Save296, sQz296);
};

function square297(){

    var sQz297 = document.getElementById("imgSqrs297").src;

    value35Save297 = "zSqrArtSpecz297";

    localStorage.setItem(value35Save297, sQz297);
};

function square298(){

    var sQz298 = document.getElementById("imgSqrs298").src;

    value35Save298 = "zSqrArtSpecz298";

    localStorage.setItem(value35Save298, sQz298);
};

function square299(){

    var sQz299 = document.getElementById("imgSqrs299").src;

    value35Save299 = "zSqrArtSpecz299";

    localStorage.setItem(value35Save299, sQz299);
};

function square300(){

    var sQz300 = document.getElementById("imgSqrs300").src;

    value35Save300 = "zSqrArtSpecz300";

    localStorage.setItem(value35Save300, sQz300);
};

function square301(){

    var sQz301 = document.getElementById("imgSqrs301").src;

    value35Save301 = "zSqrArtSpecz301";

    localStorage.setItem(value35Save301, sQz301);
};

function square302(){

    var sQz302 = document.getElementById("imgSqrs302").src;

    value35Save302 = "zSqrArtSpecz302";

    localStorage.setItem(value35Save302, sQz302);
};

function square303(){

    var sQz303 = document.getElementById("imgSqrs303").src;

    value35Save303 = "zSqrArtSpecz303";

    localStorage.setItem(value35Save303, sQz303);
};

function square304(){

    var sQz304 = document.getElementById("imgSqrs304").src;

    value35Save304 = "zSqrArtSpecz304";

    localStorage.setItem(value35Save304, sQz304);
};

function square305(){

    var sQz305 = document.getElementById("imgSqrs305").src;

    value35Save305 = "zSqrArtSpecz305";

    localStorage.setItem(value35Save305, sQz305);
};

function square306(){

    var sQz306 = document.getElementById("imgSqrs306").src;

    value35Save306 = "zSqrArtSpecz306";

    localStorage.setItem(value35Save306, sQz306);
};

function square307(){

    var sQz307 = document.getElementById("imgSqrs307").src;

    value35Save307 = "zSqrArtSpecz307";

    localStorage.setItem(value35Save307, sQz307);
};

function square308(){

    var sQz308 = document.getElementById("imgSqrs308").src;

    value35Save308 = "zSqrArtSpecz308";

    localStorage.setItem(value35Save308, sQz308);
};

function square309(){

    var sQz309 = document.getElementById("imgSqrs309").src;

    value35Save309 = "zSqrArtSpecz309";

    localStorage.setItem(value35Save309, sQz309);
};

function square310(){

    var sQz310 = document.getElementById("imgSqrs310").src;

    value35Save310 = "zSqrArtSpecz310";

    localStorage.setItem(value35Save310, sQz310);
};

function square311(){

    var sQz311 = document.getElementById("imgSqrs311").src;

    value35Save311 = "zSqrArtSpecz311";

    localStorage.setItem(value35Save311, sQz311);
};

function square312(){

    var sQz312 = document.getElementById("imgSqrs312").src;

    value35Save312 = "zSqrArtSpecz312";

    localStorage.setItem(value35Save312, sQz312);
};

function square313(){

    var sQz313 = document.getElementById("imgSqrs313").src;

    value35Save313 = "zSqrArtSpecz313";

    localStorage.setItem(value35Save313, sQz313);
};

function square314(){

    var sQz314 = document.getElementById("imgSqrs314").src;

    value35Save314 = "zSqrArtSpecz314";

    localStorage.setItem(value35Save314, sQz314);
};

function square315(){

    var sQz315 = document.getElementById("imgSqrs315").src;

    value35Save315 = "zSqrArtSpecz315";

    localStorage.setItem(value35Save315, sQz315);
};

function square316(){

    var sQz316 = document.getElementById("imgSqrs316").src;

    value35Save316 = "zSqrArtSpecz316";

    localStorage.setItem(value35Save316, sQz316);
};

function square317(){

    var sQz317 = document.getElementById("imgSqrs317").src;

    value35Save317 = "zSqrArtSpecz317";

    localStorage.setItem(value35Save317, sQz317);
};

function square318(){

    var sQz318 = document.getElementById("imgSqrs318").src;

    value35Save318 = "zSqrArtSpecz318";

    localStorage.setItem(value35Save318, sQz318);
};

function square319(){

    var sQz319 = document.getElementById("imgSqrs319").src;

    value35Save319 = "zSqrArtSpecz319";

    localStorage.setItem(value35Save319, sQz319);
};

function square320(){

    var sQz320 = document.getElementById("imgSqrs320").src;

    value35Save320 = "zSqrArtSpecz320";

    localStorage.setItem(value35Save320, sQz320);
};

function square321(){

    var sQz321 = document.getElementById("imgSqrs321").src;

    value35Save321 = "zSqrArtSpecz321";

    localStorage.setItem(value35Save321, sQz321);
};

function square322(){

    var sQz322 = document.getElementById("imgSqrs322").src;

    value35Save322 = "zSqrArtSpecz322";

    localStorage.setItem(value35Save322, sQz322);
};

function square323(){

    var sQz323 = document.getElementById("imgSqrs323").src;

    value35Save323 = "zSqrArtSpecz323";

    localStorage.setItem(value35Save323, sQz323);
};

function square324(){

    var sQz324 = document.getElementById("imgSqrs324").src;

    value35Save324 = "zSqrArtSpecz324";

    localStorage.setItem(value35Save324, sQz324);
};

function square325(){

    var sQz325 = document.getElementById("imgSqrs325").src;

    value35Save325 = "zSqrArtSpecz325";

    localStorage.setItem(value35Save325, sQz325);
};

function square326(){

    var sQz326 = document.getElementById("imgSqrs326").src;

    value35Save326 = "zSqrArtSpecz326";

    localStorage.setItem(value35Save326, sQz326);
};

function square327(){

    var sQz327 = document.getElementById("imgSqrs327").src;

    value35Save327 = "zSqrArtSpecz327";

    localStorage.setItem(value35Save327, sQz327);
};

function square328(){

    var sQz328 = document.getElementById("imgSqrs328").src;

    value35Save328 = "zSqrArtSpecz328";

    localStorage.setItem(value35Save328, sQz328);
};

function square329(){

    var sQz329 = document.getElementById("imgSqrs329").src;

    value35Save329 = "zSqrArtSpecz329";

    localStorage.setItem(value35Save329, sQz329);
};

function square330(){

    var sQz330 = document.getElementById("imgSqrs330").src;

    value35Save330 = "zSqrArtSpecz330";

    localStorage.setItem(value35Save330, sQz330);
};

function square331(){

    var sQz331 = document.getElementById("imgSqrs331").src;

    value35Save331 = "zSqrArtSpecz331";

    localStorage.setItem(value35Save331, sQz331);
};

function square332(){

    var sQz332 = document.getElementById("imgSqrs332").src;

    value35Save332 = "zSqrArtSpecz332";

    localStorage.setItem(value35Save332, sQz332);
};

function square333(){

    var sQz333 = document.getElementById("imgSqrs333").src;

    value35Save333 = "zSqrArtSpecz333";

    localStorage.setItem(value35Save333, sQz333);
};

function square334(){

    var sQz334 = document.getElementById("imgSqrs334").src;

    value35Save334 = "zSqrArtSpecz334";

    localStorage.setItem(value35Save334, sQz334);
};

function square335(){

    var sQz335 = document.getElementById("imgSqrs335").src;

    value35Save335 = "zSqrArtSpecz335";

    localStorage.setItem(value35Save335, sQz335);
};

function square336(){

    var sQz336 = document.getElementById("imgSqrs336").src;

    value35Save336 = "zSqrArtSpecz336";

    localStorage.setItem(value35Save336, sQz336);
};

function square337(){

    var sQz337 = document.getElementById("imgSqrs337").src;

    value35Save337 = "zSqrArtSpecz337";

    localStorage.setItem(value35Save337, sQz337);
};

function square338(){

    var sQz338 = document.getElementById("imgSqrs338").src;

    value35Save338 = "zSqrArtSpecz338";

    localStorage.setItem(value35Save338, sQz338);
};

function square339(){

    var sQz339 = document.getElementById("imgSqrs339").src;

    value35Save339 = "zSqrArtSpecz339";

    localStorage.setItem(value35Save339, sQz339);
};

function square340(){

    var sQz340 = document.getElementById("imgSqrs340").src;

    value35Save340 = "zSqrArtSpecz340";

    localStorage.setItem(value35Save340, sQz340);
};

function square341(){

    var sQz341 = document.getElementById("imgSqrs341").src;

    value35Save341 = "zSqrArtSpecz341";

    localStorage.setItem(value35Save341, sQz341);
};

function square342(){

    var sQz342 = document.getElementById("imgSqrs342").src;

    value35Save342 = "zSqrArtSpecz342";

    localStorage.setItem(value35Save342, sQz342);
};

function square343(){

    var sQz343 = document.getElementById("imgSqrs343").src;

    value35Save343 = "zSqrArtSpecz343";

    localStorage.setItem(value35Save343, sQz343);
};

function square344(){

    var sQz344 = document.getElementById("imgSqrs344").src;

    value35Save344 = "zSqrArtSpecz344";

    localStorage.setItem(value35Save344, sQz344);
};

function square345(){

    var sQz345 = document.getElementById("imgSqrs345").src;

    value35Save345 = "zSqrArtSpecz345";

    localStorage.setItem(value35Save345, sQz345);
};

function square346(){

    var sQz346 = document.getElementById("imgSqrs346").src;

    value35Save346 = "zSqrArtSpecz346";

    localStorage.setItem(value35Save346, sQz346);
};

function square347(){

    var sQz347 = document.getElementById("imgSqrs347").src;

    value35Save347 = "zSqrArtSpecz347";

    localStorage.setItem(value35Save347, sQz347);
};

function square348(){

    var sQz348 = document.getElementById("imgSqrs348").src;

    value35Save348 = "zSqrArtSpecz348";

    localStorage.setItem(value35Save348, sQz348);
};

function square349(){

    var sQz349 = document.getElementById("imgSqrs349").src;

    value35Save349 = "zSqrArtSpecz349";

    localStorage.setItem(value35Save349, sQz349);
};

function square350(){

    var sQz350 = document.getElementById("imgSqrs350").src;

    value35Save350 = "zSqrArtSpecz350";

    localStorage.setItem(value35Save350, sQz350);
};

function square351(){

    var sQz351 = document.getElementById("imgSqrs351").src;

    value35Save351 = "zSqrArtSpecz351";

    localStorage.setItem(value35Save351, sQz351);
};

function square352(){

    var sQz352 = document.getElementById("imgSqrs352").src;

    value35Save352 = "zSqrArtSpecz352";

    localStorage.setItem(value35Save352, sQz352);
};

function square353(){

    var sQz353 = document.getElementById("imgSqrs353").src;

    value35Save353 = "zSqrArtSpecz353";

    localStorage.setItem(value35Save353, sQz353);
};

function square354(){

    var sQz354 = document.getElementById("imgSqrs354").src;

    value35Save354 = "zSqrArtSpecz354";

    localStorage.setItem(value35Save354, sQz354);
};

function square355(){

    var sQz355 = document.getElementById("imgSqrs355").src;

    value35Save355 = "zSqrArtSpecz355";

    localStorage.setItem(value35Save355, sQz355);
};

function square356(){

    var sQz356 = document.getElementById("imgSqrs356").src;

    value35Save356 = "zSqrArtSpecz356";

    localStorage.setItem(value35Save356, sQz356);
};

function square357(){

    var sQz357 = document.getElementById("imgSqrs357").src;

    value35Save357 = "zSqrArtSpecz357";

    localStorage.setItem(value35Save357, sQz357);
};

function square358(){

    var sQz358 = document.getElementById("imgSqrs358").src;

    value35Save358 = "zSqrArtSpecz358";

    localStorage.setItem(value35Save358, sQz358);
};

function square359(){

    var sQz359 = document.getElementById("imgSqrs359").src;

    value35Save359 = "zSqrArtSpecz359";

    localStorage.setItem(value35Save359, sQz359);
};

function square360(){

    var sQz360 = document.getElementById("imgSqrs360").src;

    value35Save360 = "zSqrArtSpecz360";

    localStorage.setItem(value35Save360, sQz360);
};

function square361(){

    var sQz361 = document.getElementById("imgSqrs361").src;

    value35Save361 = "zSqrArtSpecz361";

    localStorage.setItem(value35Save361, sQz361);
};

function square362(){

    var sQz362 = document.getElementById("imgSqrs362").src;

    value35Save362 = "zSqrArtSpecz362";

    localStorage.setItem(value35Save362, sQz362);
};

function square363(){

    var sQz363 = document.getElementById("imgSqrs363").src;

    value35Save363 = "zSqrArtSpecz363";

    localStorage.setItem(value35Save363, sQz363);
};

function square364(){

    var sQz364 = document.getElementById("imgSqrs364").src;

    value35Save364 = "zSqrArtSpecz364";

    localStorage.setItem(value35Save364, sQz364);
};

function square365(){

    var sQz365 = document.getElementById("imgSqrs365").src;

    value35Save365 = "zSqrArtSpecz365";

    localStorage.setItem(value35Save365, sQz365);
};

function square366(){

    var sQz366 = document.getElementById("imgSqrs366").src;

    value35Save366 = "zSqrArtSpecz366";

    localStorage.setItem(value35Save366, sQz366);
};

function square367(){

    var sQz367 = document.getElementById("imgSqrs367").src;

    value35Save367 = "zSqrArtSpecz367";

    localStorage.setItem(value35Save367, sQz367);
};

function square368(){

    var sQz368 = document.getElementById("imgSqrs368").src;

    value35Save368 = "zSqrArtSpecz368";

    localStorage.setItem(value35Save368, sQz368);
};

function square369(){

    var sQz369 = document.getElementById("imgSqrs369").src;

    value35Save369 = "zSqrArtSpecz369";

    localStorage.setItem(value35Save369, sQz369);
};

function square370(){

    var sQz370 = document.getElementById("imgSqrs370").src;

    value35Save370 = "zSqrArtSpecz370";

    localStorage.setItem(value35Save370, sQz370);
};

function square371(){

    var sQz371 = document.getElementById("imgSqrs371").src;

    value35Save371 = "zSqrArtSpecz371";

    localStorage.setItem(value35Save371, sQz371);
};

function square372(){

    var sQz372 = document.getElementById("imgSqrs372").src;

    value35Save372 = "zSqrArtSpecz372";

    localStorage.setItem(value35Save372, sQz372);
};

function square373(){

    var sQz373 = document.getElementById("imgSqrs373").src;

    value35Save373 = "zSqrArtSpecz373";

    localStorage.setItem(value35Save373, sQz373);
};

function square374(){

    var sQz374 = document.getElementById("imgSqrs374").src;

    value35Save374 = "zSqrArtSpecz374";

    localStorage.setItem(value35Save374, sQz374);
};

function square375(){

    var sQz375 = document.getElementById("imgSqrs375").src;

    value35Save375 = "zSqrArtSpecz375";

    localStorage.setItem(value35Save375, sQz375);
};

function square376(){

    var sQz376 = document.getElementById("imgSqrs376").src;

    value35Save376 = "zSqrArtSpecz376";

    localStorage.setItem(value35Save376, sQz376);
};

function square377(){

    var sQz377 = document.getElementById("imgSqrs377").src;

    value35Save377 = "zSqrArtSpecz377";

    localStorage.setItem(value35Save377, sQz377);
};

function square378(){

    var sQz378 = document.getElementById("imgSqrs378").src;

    value35Save378 = "zSqrArtSpecz378";

    localStorage.setItem(value35Save378, sQz378);
};

function square379(){

    var sQz379 = document.getElementById("imgSqrs379").src;

    value35Save379 = "zSqrArtSpecz379";

    localStorage.setItem(value35Save379, sQz379);
};

function square380(){

    var sQz380 = document.getElementById("imgSqrs380").src;

    value35Save380 = "zSqrArtSpecz380";

    localStorage.setItem(value35Save380, sQz380);
};

function square381(){

    var sQz381 = document.getElementById("imgSqrs381").src;

    value35Save381 = "zSqrArtSpecz381";

    localStorage.setItem(value35Save381, sQz381);
};

function square382(){

    var sQz382 = document.getElementById("imgSqrs382").src;

    value35Save382 = "zSqrArtSpecz382";

    localStorage.setItem(value35Save382, sQz382);
};

function square383(){

    var sQz383 = document.getElementById("imgSqrs383").src;

    value35Save383 = "zSqrArtSpecz383";

    localStorage.setItem(value35Save383, sQz383);
};

function square384(){

    var sQz384 = document.getElementById("imgSqrs384").src;

    value35Save384 = "zSqrArtSpecz384";

    localStorage.setItem(value35Save384, sQz384);
};

function square385(){

    var sQz385 = document.getElementById("imgSqrs385").src;

    value35Save385 = "zSqrArtSpecz385";

    localStorage.setItem(value35Save385, sQz385);
};

function square386(){

    var sQz386 = document.getElementById("imgSqrs386").src;

    value35Save386 = "zSqrArtSpecz386";

    localStorage.setItem(value35Save386, sQz386);
};

function square387(){

    var sQz387 = document.getElementById("imgSqrs387").src;

    value35Save387 = "zSqrArtSpecz387";

    localStorage.setItem(value35Save387, sQz387);
};

function square388(){

    var sQz388 = document.getElementById("imgSqrs388").src;

    value35Save388 = "zSqrArtSpecz388";

    localStorage.setItem(value35Save388, sQz388);
};

function square389(){

    var sQz389 = document.getElementById("imgSqrs389").src;

    value35Save389 = "zSqrArtSpecz389";

    localStorage.setItem(value35Save389, sQz389);
};

function square390(){

    var sQz390 = document.getElementById("imgSqrs390").src;

    value35Save390 = "zSqrArtSpecz390";

    localStorage.setItem(value35Save390, sQz390);
};

function square391(){

    var sQz391 = document.getElementById("imgSqrs391").src;

    value35Save391 = "zSqrArtSpecz391";

    localStorage.setItem(value35Save391, sQz391);
};

function square392(){

    var sQz392 = document.getElementById("imgSqrs392").src;

    value35Save392 = "zSqrArtSpecz392";

    localStorage.setItem(value35Save392, sQz392);
};

function square393(){

    var sQz393 = document.getElementById("imgSqrs393").src;

    value35Save393 = "zSqrArtSpecz393";

    localStorage.setItem(value35Save393, sQz393);
};

function square394(){

    var sQz394 = document.getElementById("imgSqrs394").src;

    value35Save394 = "zSqrArtSpecz394";

    localStorage.setItem(value35Save394, sQz394);
};

function square395(){

    var sQz395 = document.getElementById("imgSqrs395").src;

    value35Save395 = "zSqrArtSpecz395";

    localStorage.setItem(value35Save395, sQz395);
};

function square396(){

    var sQz396 = document.getElementById("imgSqrs396").src;

    value35Save396 = "zSqrArtSpecz396";

    localStorage.setItem(value35Save396, sQz396);
};

function square397(){

    var sQz397 = document.getElementById("imgSqrs397").src;

    value35Save397 = "zSqrArtSpecz397";

    localStorage.setItem(value35Save397, sQz397);
};

function square398(){

    var sQz398 = document.getElementById("imgSqrs398").src;

    value35Save398 = "zSqrArtSpecz398";

    localStorage.setItem(value35Save398, sQz398);
};

function square399(){

    var sQz399 = document.getElementById("imgSqrs399").src;

    value35Save399 = "zSqrArtSpecz399";

    localStorage.setItem(value35Save399, sQz399);
};

function square400(){

    var sQz400 = document.getElementById("imgSqrs400").src;

    value35Save400 = "zSqrArtSpecz400";

    localStorage.setItem(value35Save400, sQz400);
};

function square401(){

    var sQz401 = document.getElementById("imgSqrs401").src;

    value35Save401 = "zSqrArtSpecz401";

    localStorage.setItem(value35Save401, sQz401);
};

function square402(){

    var sQz402 = document.getElementById("imgSqrs402").src;

    value35Save402 = "zSqrArtSpecz402";

    localStorage.setItem(value35Save402, sQz402);
};

function square403(){

    var sQz403 = document.getElementById("imgSqrs403").src;

    value35Save403 = "zSqrArtSpecz403";

    localStorage.setItem(value35Save403, sQz403);
};

function square404(){

    var sQz404 = document.getElementById("imgSqrs404").src;

    value35Save404 = "zSqrArtSpecz404";

    localStorage.setItem(value35Save404, sQz404);
};

function square405(){

    var sQz405 = document.getElementById("imgSqrs405").src;

    value35Save405 = "zSqrArtSpecz405";

    localStorage.setItem(value35Save405, sQz405);
};

function square406(){

    var sQz406 = document.getElementById("imgSqrs406").src;

    value35Save406 = "zSqrArtSpecz406";

    localStorage.setItem(value35Save406, sQz406);
};

function square407(){

    var sQz407 = document.getElementById("imgSqrs407").src;

    value35Save407 = "zSqrArtSpecz407";

    localStorage.setItem(value35Save407, sQz407);
};

function square408(){

    var sQz408 = document.getElementById("imgSqrs408").src;

    value35Save408 = "zSqrArtSpecz408";

    localStorage.setItem(value35Save408, sQz408);
};

function square409(){

    var sQz409 = document.getElementById("imgSqrs409").src;

    value35Save409 = "zSqrArtSpecz409";

    localStorage.setItem(value35Save409, sQz409);
};

function square410(){

    var sQz410 = document.getElementById("imgSqrs410").src;

    value35Save410 = "zSqrArtSpecz410";

    localStorage.setItem(value35Save410, sQz410);
};

function square411(){

    var sQz411 = document.getElementById("imgSqrs411").src;

    value35Save411 = "zSqrArtSpecz411";

    localStorage.setItem(value35Save411, sQz411);
};

function square412(){

    var sQz412 = document.getElementById("imgSqrs412").src;

    value35Save412 = "zSqrArtSpecz412";

    localStorage.setItem(value35Save412, sQz412);
};

function square413(){

    var sQz413 = document.getElementById("imgSqrs413").src;

    value35Save413 = "zSqrArtSpecz413";

    localStorage.setItem(value35Save413, sQz413);
};

function square414(){

    var sQz414 = document.getElementById("imgSqrs414").src;

    value35Save414 = "zSqrArtSpecz414";

    localStorage.setItem(value35Save414, sQz414);
};

function square415(){

    var sQz415 = document.getElementById("imgSqrs415").src;

    value35Save415 = "zSqrArtSpecz415";

    localStorage.setItem(value35Save415, sQz415);
};

function square416(){

    var sQz416 = document.getElementById("imgSqrs416").src;

    value35Save416 = "zSqrArtSpecz416";

    localStorage.setItem(value35Save416, sQz416);
};

function square417(){

    var sQz417 = document.getElementById("imgSqrs417").src;

    value35Save417 = "zSqrArtSpecz417";

    localStorage.setItem(value35Save417, sQz417);
};

function square418(){

    var sQz418 = document.getElementById("imgSqrs418").src;

    value35Save418 = "zSqrArtSpecz418";

    localStorage.setItem(value35Save418, sQz418);
};

function square419(){

    var sQz419 = document.getElementById("imgSqrs419").src;

    value35Save419 = "zSqrArtSpecz419";

    localStorage.setItem(value35Save419, sQz419);
};

function square420(){

    var sQz420 = document.getElementById("imgSqrs420").src;

    value35Save420 = "zSqrArtSpecz420";

    localStorage.setItem(value35Save420, sQz420);
};

function square421(){

    var sQz421 = document.getElementById("imgSqrs421").src;

    value35Save421 = "zSqrArtSpecz421";

    localStorage.setItem(value35Save421, sQz421);
};

function square422(){

    var sQz422 = document.getElementById("imgSqrs422").src;

    value35Save422 = "zSqrArtSpecz422";

    localStorage.setItem(value35Save422, sQz422);
};

function square423(){

    var sQz423 = document.getElementById("imgSqrs423").src;

    value35Save423 = "zSqrArtSpecz423";

    localStorage.setItem(value35Save423, sQz423);
};

function square424(){

    var sQz424 = document.getElementById("imgSqrs424").src;

    value35Save424 = "zSqrArtSpecz424";

    localStorage.setItem(value35Save424, sQz424);
};

function square425(){

    var sQz425 = document.getElementById("imgSqrs425").src;

    value35Save425 = "zSqrArtSpecz425";

    localStorage.setItem(value35Save425, sQz425);
};

function square426(){

    var sQz426 = document.getElementById("imgSqrs426").src;

    value35Save426 = "zSqrArtSpecz426";

    localStorage.setItem(value35Save426, sQz426);
};

function square427(){

    var sQz427 = document.getElementById("imgSqrs427").src;

    value35Save427 = "zSqrArtSpecz427";

    localStorage.setItem(value35Save427, sQz427);
};

function square428(){

    var sQz428 = document.getElementById("imgSqrs428").src;

    value35Save428 = "zSqrArtSpecz428";

    localStorage.setItem(value35Save428, sQz428);
};

function square429(){

    var sQz429 = document.getElementById("imgSqrs429").src;

    value35Save429 = "zSqrArtSpecz429";

    localStorage.setItem(value35Save429, sQz429);
};

function square430(){

    var sQz430 = document.getElementById("imgSqrs430").src;

    value35Save430 = "zSqrArtSpecz430";

    localStorage.setItem(value35Save430, sQz430);
};

function square431(){

    var sQz431 = document.getElementById("imgSqrs431").src;

    value35Save431 = "zSqrArtSpecz431";

    localStorage.setItem(value35Save431, sQz431);
};

function square432(){

    var sQz432 = document.getElementById("imgSqrs432").src;

    value35Save432 = "zSqrArtSpecz432";

    localStorage.setItem(value35Save432, sQz432);
};

function square433(){

    var sQz433 = document.getElementById("imgSqrs433").src;

    value35Save433 = "zSqrArtSpecz433";

    localStorage.setItem(value35Save433, sQz433);
};

function square434(){

    var sQz434 = document.getElementById("imgSqrs434").src;

    value35Save434 = "zSqrArtSpecz434";

    localStorage.setItem(value35Save434, sQz434);
};

function square435(){

    var sQz435 = document.getElementById("imgSqrs435").src;

    value35Save435 = "zSqrArtSpecz435";

    localStorage.setItem(value35Save435, sQz435);
};

function square436(){

    var sQz436 = document.getElementById("imgSqrs436").src;

    value35Save436 = "zSqrArtSpecz436";

    localStorage.setItem(value35Save436, sQz436);
};

function square437(){

    var sQz437 = document.getElementById("imgSqrs437").src;

    value35Save437 = "zSqrArtSpecz437";

    localStorage.setItem(value35Save437, sQz437);
};

function square438(){

    var sQz438 = document.getElementById("imgSqrs438").src;

    value35Save438 = "zSqrArtSpecz438";

    localStorage.setItem(value35Save438, sQz438);
};

function square439(){

    var sQz439 = document.getElementById("imgSqrs439").src;

    value35Save439 = "zSqrArtSpecz439";

    localStorage.setItem(value35Save439, sQz439);
};

function square440(){

    var sQz440 = document.getElementById("imgSqrs440").src;

    value35Save440 = "zSqrArtSpecz440";

    localStorage.setItem(value35Save440, sQz440);
};

function square441(){

    var sQz441 = document.getElementById("imgSqrs441").src;

    value35Save441 = "zSqrArtSpecz441";

    localStorage.setItem(value35Save441, sQz441);
};

function square442(){

    var sQz442 = document.getElementById("imgSqrs442").src;

    value35Save442 = "zSqrArtSpecz442";

    localStorage.setItem(value35Save442, sQz442);
};

function square443(){

    var sQz443 = document.getElementById("imgSqrs443").src;

    value35Save443 = "zSqrArtSpecz443";

    localStorage.setItem(value35Save443, sQz443);
};

function square444(){

    var sQz444 = document.getElementById("imgSqrs444").src;

    value35Save444 = "zSqrArtSpecz444";

    localStorage.setItem(value35Save444, sQz444);
};

function square445(){

    var sQz445 = document.getElementById("imgSqrs445").src;

    value35Save445 = "zSqrArtSpecz445";

    localStorage.setItem(value35Save445, sQz445);
};

function square446(){

    var sQz446 = document.getElementById("imgSqrs446").src;

    value35Save446 = "zSqrArtSpecz446";

    localStorage.setItem(value35Save446, sQz446);
};

function square447(){

    var sQz447 = document.getElementById("imgSqrs447").src;

    value35Save447 = "zSqrArtSpecz447";

    localStorage.setItem(value35Save447, sQz447);
};

function square448(){

    var sQz448 = document.getElementById("imgSqrs448").src;

    value35Save448 = "zSqrArtSpecz448";

    localStorage.setItem(value35Save448, sQz448);
};

function square449(){

    var sQz449 = document.getElementById("imgSqrs449").src;

    value35Save449 = "zSqrArtSpecz449";

    localStorage.setItem(value35Save449, sQz449);
};

function square450(){

    var sQz450 = document.getElementById("imgSqrs450").src;

    value35Save450 = "zSqrArtSpecz450";

    localStorage.setItem(value35Save450, sQz450);
};

function square451(){

    var sQz451 = document.getElementById("imgSqrs451").src;

    value35Save451 = "zSqrArtSpecz451";

    localStorage.setItem(value35Save451, sQz451);
};

function square452(){

    var sQz452 = document.getElementById("imgSqrs452").src;

    value35Save452 = "zSqrArtSpecz452";

    localStorage.setItem(value35Save452, sQz452);
};

function square453(){

    var sQz453 = document.getElementById("imgSqrs453").src;

    value35Save453 = "zSqrArtSpecz453";

    localStorage.setItem(value35Save453, sQz453);
};

function square454(){

    var sQz454 = document.getElementById("imgSqrs454").src;

    value35Save454 = "zSqrArtSpecz454";

    localStorage.setItem(value35Save454, sQz454);
};

function square455(){

    var sQz455 = document.getElementById("imgSqrs455").src;

    value35Save455 = "zSqrArtSpecz455";

    localStorage.setItem(value35Save455, sQz455);
};

function square456(){

    var sQz456 = document.getElementById("imgSqrs456").src;

    value35Save456 = "zSqrArtSpecz456";

    localStorage.setItem(value35Save456, sQz456);
};

function square457(){

    var sQz457 = document.getElementById("imgSqrs457").src;

    value35Save457 = "zSqrArtSpecz457";

    localStorage.setItem(value35Save457, sQz457);
};

function square458(){

    var sQz458 = document.getElementById("imgSqrs458").src;

    value35Save458 = "zSqrArtSpecz458";

    localStorage.setItem(value35Save458, sQz458);
};

function square459(){

    var sQz459 = document.getElementById("imgSqrs459").src;

    value35Save459 = "zSqrArtSpecz459";

    localStorage.setItem(value35Save459, sQz459);
};

function square460(){

    var sQz460 = document.getElementById("imgSqrs460").src;

    value35Save460 = "zSqrArtSpecz460";

    localStorage.setItem(value35Save460, sQz460);
};

function square461(){

    var sQz461 = document.getElementById("imgSqrs461").src;

    value35Save461 = "zSqrArtSpecz461";

    localStorage.setItem(value35Save461, sQz461);
};

function square462(){

    var sQz462 = document.getElementById("imgSqrs462").src;

    value35Save462 = "zSqrArtSpecz462";

    localStorage.setItem(value35Save462, sQz462);
};

function square463(){

    var sQz463 = document.getElementById("imgSqrs463").src;

    value35Save463 = "zSqrArtSpecz463";

    localStorage.setItem(value35Save463, sQz463);
};

function square464(){

    var sQz464 = document.getElementById("imgSqrs464").src;

    value35Save464 = "zSqrArtSpecz464";

    localStorage.setItem(value35Save464, sQz464);
};

function square465(){

    var sQz465 = document.getElementById("imgSqrs465").src;

    value35Save465 = "zSqrArtSpecz465";

    localStorage.setItem(value35Save465, sQz465);
};

function square466(){

    var sQz466 = document.getElementById("imgSqrs466").src;

    value35Save466 = "zSqrArtSpecz466";

    localStorage.setItem(value35Save466, sQz466);
};

function square467(){

    var sQz467 = document.getElementById("imgSqrs467").src;

    value35Save467 = "zSqrArtSpecz467";

    localStorage.setItem(value35Save467, sQz467);
};

function square468(){

    var sQz468 = document.getElementById("imgSqrs468").src;

    value35Save468 = "zSqrArtSpecz468";

    localStorage.setItem(value35Save468, sQz468);
};

function square469(){

    var sQz469 = document.getElementById("imgSqrs469").src;

    value35Save469 = "zSqrArtSpecz469";

    localStorage.setItem(value35Save469, sQz469);
};

function square470(){

    var sQz470 = document.getElementById("imgSqrs470").src;

    value35Save470 = "zSqrArtSpecz470";

    localStorage.setItem(value35Save470, sQz470);
};

function square471(){

    var sQz471 = document.getElementById("imgSqrs471").src;

    value35Save471 = "zSqrArtSpecz471";

    localStorage.setItem(value35Save471, sQz471);
};

function square472(){

    var sQz472 = document.getElementById("imgSqrs472").src;

    value35Save472 = "zSqrArtSpecz472";

    localStorage.setItem(value35Save472, sQz472);
};

function square473(){

    var sQz473 = document.getElementById("imgSqrs473").src;

    value35Save473 = "zSqrArtSpecz473";

    localStorage.setItem(value35Save473, sQz473);
};

function square474(){

    var sQz474 = document.getElementById("imgSqrs474").src;

    value35Save474 = "zSqrArtSpecz474";

    localStorage.setItem(value35Save474, sQz474);
};

function square475(){

    var sQz475 = document.getElementById("imgSqrs475").src;

    value35Save475 = "zSqrArtSpecz475";

    localStorage.setItem(value35Save475, sQz475);
};

function square476(){

    var sQz476 = document.getElementById("imgSqrs476").src;

    value35Save476 = "zSqrArtSpecz476";

    localStorage.setItem(value35Save476, sQz476);
};

function square477(){

    var sQz477 = document.getElementById("imgSqrs477").src;

    value35Save477 = "zSqrArtSpecz477";

    localStorage.setItem(value35Save477, sQz477);
};

function square478(){

    var sQz478 = document.getElementById("imgSqrs478").src;

    value35Save478 = "zSqrArtSpecz478";

    localStorage.setItem(value35Save478, sQz478);
};

function square479(){

    var sQz479 = document.getElementById("imgSqrs479").src;

    value35Save479 = "zSqrArtSpecz479";

    localStorage.setItem(value35Save479, sQz479);
};

function square480(){

    var sQz480 = document.getElementById("imgSqrs480").src;

    value35Save480 = "zSqrArtSpecz480";

    localStorage.setItem(value35Save480, sQz480);
};

function square481(){

    var sQz481 = document.getElementById("imgSqrs481").src;

    value35Save481 = "zSqrArtSpecz481";

    localStorage.setItem(value35Save481, sQz481);
};

function square482(){

    var sQz482 = document.getElementById("imgSqrs482").src;

    value35Save482 = "zSqrArtSpecz482";

    localStorage.setItem(value35Save482, sQz482);
};

function square483(){

    var sQz483 = document.getElementById("imgSqrs483").src;

    value35Save483 = "zSqrArtSpecz483";

    localStorage.setItem(value35Save483, sQz483);
};

function square484(){

    var sQz484 = document.getElementById("imgSqrs484").src;

    value35Save484 = "zSqrArtSpecz484";

    localStorage.setItem(value35Save484, sQz484);
};

function square485(){

    var sQz485 = document.getElementById("imgSqrs485").src;

    value35Save485 = "zSqrArtSpecz485";

    localStorage.setItem(value35Save485, sQz485);
};

function square486(){

    var sQz486 = document.getElementById("imgSqrs486").src;

    value35Save486 = "zSqrArtSpecz486";

    localStorage.setItem(value35Save486, sQz486);
};

function square487(){

    var sQz487 = document.getElementById("imgSqrs487").src;

    value35Save487 = "zSqrArtSpecz487";

    localStorage.setItem(value35Save487, sQz487);
};

function square488(){

    var sQz488 = document.getElementById("imgSqrs488").src;

    value35Save488 = "zSqrArtSpecz488";

    localStorage.setItem(value35Save488, sQz488);
};

function square489(){

    var sQz489 = document.getElementById("imgSqrs489").src;

    value35Save489 = "zSqrArtSpecz489";

    localStorage.setItem(value35Save489, sQz489);
};

function square490(){

    var sQz490 = document.getElementById("imgSqrs490").src;

    value35Save490 = "zSqrArtSpecz490";

    localStorage.setItem(value35Save490, sQz490);
};

function square491(){

    var sQz491 = document.getElementById("imgSqrs491").src;

    value35Save491 = "zSqrArtSpecz491";

    localStorage.setItem(value35Save491, sQz491);
};

function square492(){

    var sQz492 = document.getElementById("imgSqrs492").src;

    value35Save492 = "zSqrArtSpecz492";

    localStorage.setItem(value35Save492, sQz492);
};

function square493(){

    var sQz493 = document.getElementById("imgSqrs493").src;

    value35Save493 = "zSqrArtSpecz493";

    localStorage.setItem(value35Save493, sQz493);
};

function square494(){

    var sQz494 = document.getElementById("imgSqrs494").src;

    value35Save494 = "zSqrArtSpecz494";

    localStorage.setItem(value35Save494, sQz494);
};

function square495(){

    var sQz495 = document.getElementById("imgSqrs495").src;

    value35Save495 = "zSqrArtSpecz495";

    localStorage.setItem(value35Save495, sQz495);
};

function square496(){

    var sQz496 = document.getElementById("imgSqrs496").src;

    value35Save496 = "zSqrArtSpecz496";

    localStorage.setItem(value35Save496, sQz496);
};

function square497(){

    var sQz497 = document.getElementById("imgSqrs497").src;

    value35Save497 = "zSqrArtSpecz497";

    localStorage.setItem(value35Save497, sQz497);
};

function square498(){

    var sQz498 = document.getElementById("imgSqrs498").src;

    value35Save498 = "zSqrArtSpecz498";

    localStorage.setItem(value35Save498, sQz498);
};

function square499(){

    var sQz499 = document.getElementById("imgSqrs499").src;

    value35Save499 = "zSqrArtSpecz499";

    localStorage.setItem(value35Save499, sQz499);
};

function square500(){

    var sQz500 = document.getElementById("imgSqrs500").src;

    value35Save500 = "zSqrArtSpecz500";

    localStorage.setItem(value35Save500, sQz500);
};

function square501(){

    var sQz501 = document.getElementById("imgSqrs501").src;

    value35Save501 = "zSqrArtSpecz501";

    localStorage.setItem(value35Save501, sQz501);
};

function square502(){

    var sQz502 = document.getElementById("imgSqrs502").src;

    value35Save502 = "zSqrArtSpecz502";

    localStorage.setItem(value35Save502, sQz502);
};

function square503(){

    var sQz503 = document.getElementById("imgSqrs503").src;

    value35Save503 = "zSqrArtSpecz503";

    localStorage.setItem(value35Save503, sQz503);
};

function square504(){

    var sQz504 = document.getElementById("imgSqrs504").src;

    value35Save504 = "zSqrArtSpecz504";

    localStorage.setItem(value35Save504, sQz504);
};

function square505(){

    var sQz505 = document.getElementById("imgSqrs505").src;

    value35Save505 = "zSqrArtSpecz505";

    localStorage.setItem(value35Save505, sQz505);
};

function square506(){

    var sQz506 = document.getElementById("imgSqrs506").src;

    value35Save506 = "zSqrArtSpecz506";

    localStorage.setItem(value35Save506, sQz506);
};

function square507(){

    var sQz507 = document.getElementById("imgSqrs507").src;

    value35Save507 = "zSqrArtSpecz507";

    localStorage.setItem(value35Save507, sQz507);
};

function square508(){

    var sQz508 = document.getElementById("imgSqrs508").src;

    value35Save508 = "zSqrArtSpecz508";

    localStorage.setItem(value35Save508, sQz508);
};

function square509(){

    var sQz509 = document.getElementById("imgSqrs509").src;

    value35Save509 = "zSqrArtSpecz509";

    localStorage.setItem(value35Save509, sQz509);
};

function square510(){

    var sQz510 = document.getElementById("imgSqrs510").src;

    value35Save510 = "zSqrArtSpecz510";

    localStorage.setItem(value35Save510, sQz510);
};

function square511(){

    var sQz511 = document.getElementById("imgSqrs511").src;

    value35Save511 = "zSqrArtSpecz511";

    localStorage.setItem(value35Save511, sQz511);
};

function square512(){

    var sQz512 = document.getElementById("imgSqrs512").src;

    value35Save512 = "zSqrArtSpecz512";

    localStorage.setItem(value35Save512, sQz512);
};

function square513(){

    var sQz513 = document.getElementById("imgSqrs513").src;

    value35Save513 = "zSqrArtSpecz513";

    localStorage.setItem(value35Save513, sQz513);
};

function square514(){

    var sQz514 = document.getElementById("imgSqrs514").src;

    value35Save514 = "zSqrArtSpecz514";

    localStorage.setItem(value35Save514, sQz514);
};

function square515(){

    var sQz515 = document.getElementById("imgSqrs515").src;

    value35Save515 = "zSqrArtSpecz515";

    localStorage.setItem(value35Save515, sQz515);
};

function square516(){

    var sQz516 = document.getElementById("imgSqrs516").src;

    value35Save516 = "zSqrArtSpecz516";

    localStorage.setItem(value35Save516, sQz516);
};

function square517(){

    var sQz517 = document.getElementById("imgSqrs517").src;

    value35Save517 = "zSqrArtSpecz517";

    localStorage.setItem(value35Save517, sQz517);
};

function square518(){

    var sQz518 = document.getElementById("imgSqrs518").src;

    value35Save518 = "zSqrArtSpecz518";

    localStorage.setItem(value35Save518, sQz518);
};

function square519(){

    var sQz519 = document.getElementById("imgSqrs519").src;

    value35Save519 = "zSqrArtSpecz519";

    localStorage.setItem(value35Save519, sQz519);
};

function square520(){

    var sQz520 = document.getElementById("imgSqrs520").src;

    value35Save520 = "zSqrArtSpecz520";

    localStorage.setItem(value35Save520, sQz520);
};

function square521(){

    var sQz521 = document.getElementById("imgSqrs521").src;

    value35Save521 = "zSqrArtSpecz521";

    localStorage.setItem(value35Save521, sQz521);
};

function square522(){

    var sQz522 = document.getElementById("imgSqrs522").src;

    value35Save522 = "zSqrArtSpecz522";

    localStorage.setItem(value35Save522, sQz522);
};

function square523(){

    var sQz523 = document.getElementById("imgSqrs523").src;

    value35Save523 = "zSqrArtSpecz523";

    localStorage.setItem(value35Save523, sQz523);
};

function square524(){

    var sQz524 = document.getElementById("imgSqrs524").src;

    value35Save524 = "zSqrArtSpecz524";

    localStorage.setItem(value35Save524, sQz524);
};

function square525(){

    var sQz525 = document.getElementById("imgSqrs525").src;

    value35Save525 = "zSqrArtSpecz525";

    localStorage.setItem(value35Save525, sQz525);
};

function square526(){

    var sQz526 = document.getElementById("imgSqrs526").src;

    value35Save526 = "zSqrArtSpecz526";

    localStorage.setItem(value35Save526, sQz526);
};

function square527(){

    var sQz527 = document.getElementById("imgSqrs527").src;

    value35Save527 = "zSqrArtSpecz527";

    localStorage.setItem(value35Save527, sQz527);
};

function square528(){

    var sQz528 = document.getElementById("imgSqrs528").src;

    value35Save528 = "zSqrArtSpecz528";

    localStorage.setItem(value35Save528, sQz528);
};

function square529(){

    var sQz529 = document.getElementById("imgSqrs529").src;

    value35Save529 = "zSqrArtSpecz529";

    localStorage.setItem(value35Save529, sQz529);
};

function square530(){

    var sQz530 = document.getElementById("imgSqrs530").src;

    value35Save530 = "zSqrArtSpecz530";

    localStorage.setItem(value35Save530, sQz530);
};

function square531(){

    var sQz531 = document.getElementById("imgSqrs531").src;

    value35Save531 = "zSqrArtSpecz531";

    localStorage.setItem(value35Save531, sQz531);
};

function square532(){

    var sQz532 = document.getElementById("imgSqrs532").src;

    value35Save532 = "zSqrArtSpecz532";

    localStorage.setItem(value35Save532, sQz532);
};

function square533(){

    var sQz533 = document.getElementById("imgSqrs533").src;

    value35Save533 = "zSqrArtSpecz533";

    localStorage.setItem(value35Save533, sQz533);
};

function square534(){

    var sQz534 = document.getElementById("imgSqrs534").src;

    value35Save534 = "zSqrArtSpecz534";

    localStorage.setItem(value35Save534, sQz534);
};

function square535(){

    var sQz535 = document.getElementById("imgSqrs535").src;

    value35Save535 = "zSqrArtSpecz535";

    localStorage.setItem(value35Save535, sQz535);
};

function square536(){

    var sQz536 = document.getElementById("imgSqrs536").src;

    value35Save536 = "zSqrArtSpecz536";

    localStorage.setItem(value35Save536, sQz536);
};

function square537(){

    var sQz537 = document.getElementById("imgSqrs537").src;

    value35Save537 = "zSqrArtSpecz537";

    localStorage.setItem(value35Save537, sQz537);
};

function square538(){

    var sQz538 = document.getElementById("imgSqrs538").src;

    value35Save538 = "zSqrArtSpecz538";

    localStorage.setItem(value35Save538, sQz538);
};

function square539(){

    var sQz539 = document.getElementById("imgSqrs539").src;

    value35Save539 = "zSqrArtSpecz539";

    localStorage.setItem(value35Save539, sQz539);
};

function square540(){

    var sQz540 = document.getElementById("imgSqrs540").src;

    value35Save540 = "zSqrArtSpecz540";

    localStorage.setItem(value35Save540, sQz540);
};

function square541(){

    var sQz541 = document.getElementById("imgSqrs541").src;

    value35Save541 = "zSqrArtSpecz541";

    localStorage.setItem(value35Save541, sQz541);
};

function square542(){

    var sQz542 = document.getElementById("imgSqrs542").src;

    value35Save542 = "zSqrArtSpecz542";

    localStorage.setItem(value35Save542, sQz542);
};

function square543(){

    var sQz543 = document.getElementById("imgSqrs543").src;

    value35Save543 = "zSqrArtSpecz543";

    localStorage.setItem(value35Save543, sQz543);
};

function square544(){

    var sQz544 = document.getElementById("imgSqrs544").src;

    value35Save544 = "zSqrArtSpecz544";

    localStorage.setItem(value35Save544, sQz544);
};

function square545(){

    var sQz545 = document.getElementById("imgSqrs545").src;

    value35Save545 = "zSqrArtSpecz545";

    localStorage.setItem(value35Save545, sQz545);
};

function square546(){

    var sQz546 = document.getElementById("imgSqrs546").src;

    value35Save546 = "zSqrArtSpecz546";

    localStorage.setItem(value35Save546, sQz546);
};

function square547(){

    var sQz547 = document.getElementById("imgSqrs547").src;

    value35Save547 = "zSqrArtSpecz547";

    localStorage.setItem(value35Save547, sQz547);
};

function square548(){

    var sQz548 = document.getElementById("imgSqrs548").src;

    value35Save548 = "zSqrArtSpecz548";

    localStorage.setItem(value35Save548, sQz548);
};

function square549(){

    var sQz549 = document.getElementById("imgSqrs549").src;

    value35Save549 = "zSqrArtSpecz549";

    localStorage.setItem(value35Save549, sQz549);
};

function square550(){

    var sQz550 = document.getElementById("imgSqrs550").src;

    value35Save550 = "zSqrArtSpecz550";

    localStorage.setItem(value35Save550, sQz550);
};

function square551(){

    var sQz551 = document.getElementById("imgSqrs551").src;

    value35Save551 = "zSqrArtSpecz551";

    localStorage.setItem(value35Save551, sQz551);
};

function square552(){

    var sQz552 = document.getElementById("imgSqrs552").src;

    value35Save552 = "zSqrArtSpecz552";

    localStorage.setItem(value35Save552, sQz552);
};

function square553(){

    var sQz553 = document.getElementById("imgSqrs553").src;

    value35Save553 = "zSqrArtSpecz553";

    localStorage.setItem(value35Save553, sQz553);
};

function square554(){

    var sQz554 = document.getElementById("imgSqrs554").src;

    value35Save554 = "zSqrArtSpecz554";

    localStorage.setItem(value35Save554, sQz554);
};

function square555(){

    var sQz555 = document.getElementById("imgSqrs555").src;

    value35Save555 = "zSqrArtSpecz555";

    localStorage.setItem(value35Save555, sQz555);
};

function square556(){

    var sQz556 = document.getElementById("imgSqrs556").src;

    value35Save556 = "zSqrArtSpecz556";

    localStorage.setItem(value35Save556, sQz556);
};

function square557(){

    var sQz557 = document.getElementById("imgSqrs557").src;

    value35Save557 = "zSqrArtSpecz557";

    localStorage.setItem(value35Save557, sQz557);
};

function square558(){

    var sQz558 = document.getElementById("imgSqrs558").src;

    value35Save558 = "zSqrArtSpecz558";

    localStorage.setItem(value35Save558, sQz558);
};

function square559(){

    var sQz559 = document.getElementById("imgSqrs559").src;

    value35Save559 = "zSqrArtSpecz559";

    localStorage.setItem(value35Save559, sQz559);
};

function square560(){

    var sQz560 = document.getElementById("imgSqrs560").src;

    value35Save560 = "zSqrArtSpecz560";

    localStorage.setItem(value35Save560, sQz560);
};

function square561(){

    var sQz561 = document.getElementById("imgSqrs561").src;

    value35Save561 = "zSqrArtSpecz561";

    localStorage.setItem(value35Save561, sQz561);
};

function square562(){

    var sQz562 = document.getElementById("imgSqrs562").src;

    value35Save562 = "zSqrArtSpecz562";

    localStorage.setItem(value35Save562, sQz562);
};

function square563(){

    var sQz563 = document.getElementById("imgSqrs563").src;

    value35Save563 = "zSqrArtSpecz563";

    localStorage.setItem(value35Save563, sQz563);
};

function square564(){

    var sQz564 = document.getElementById("imgSqrs564").src;

    value35Save564 = "zSqrArtSpecz564";

    localStorage.setItem(value35Save564, sQz564);
};

function square565(){

    var sQz565 = document.getElementById("imgSqrs565").src;

    value35Save565 = "zSqrArtSpecz565";

    localStorage.setItem(value35Save565, sQz565);
};

function square566(){

    var sQz566 = document.getElementById("imgSqrs566").src;

    value35Save566 = "zSqrArtSpecz566";

    localStorage.setItem(value35Save566, sQz566);
};

function square567(){

    var sQz567 = document.getElementById("imgSqrs567").src;

    value35Save567 = "zSqrArtSpecz567";

    localStorage.setItem(value35Save567, sQz567);
};

function square568(){

    var sQz568 = document.getElementById("imgSqrs568").src;

    value35Save568 = "zSqrArtSpecz568";

    localStorage.setItem(value35Save568, sQz568);
};

function square569(){

    var sQz569 = document.getElementById("imgSqrs569").src;

    value35Save569 = "zSqrArtSpecz569";

    localStorage.setItem(value35Save569, sQz569);
};

function square570(){

    var sQz570 = document.getElementById("imgSqrs570").src;

    value35Save570 = "zSqrArtSpecz570";

    localStorage.setItem(value35Save570, sQz570);
};

function square571(){

    var sQz571 = document.getElementById("imgSqrs571").src;

    value35Save571 = "zSqrArtSpecz571";

    localStorage.setItem(value35Save571, sQz571);
};

function square572(){

    var sQz572 = document.getElementById("imgSqrs572").src;

    value35Save572 = "zSqrArtSpecz572";

    localStorage.setItem(value35Save572, sQz572);
};

function square573(){

    var sQz573 = document.getElementById("imgSqrs573").src;

    value35Save573 = "zSqrArtSpecz573";

    localStorage.setItem(value35Save573, sQz573);
};

function square574(){

    var sQz574 = document.getElementById("imgSqrs574").src;

    value35Save574 = "zSqrArtSpecz574";

    localStorage.setItem(value35Save574, sQz574);
};

function square575(){

    var sQz575 = document.getElementById("imgSqrs575").src;

    value35Save575 = "zSqrArtSpecz575";

    localStorage.setItem(value35Save575, sQz575);
};

function square576(){

    var sQz576 = document.getElementById("imgSqrs576").src;

    value35Save576 = "zSqrArtSpecz576";

    localStorage.setItem(value35Save576, sQz576);
};

function square577(){

    var sQz577 = document.getElementById("imgSqrs577").src;

    value35Save577 = "zSqrArtSpecz577";

    localStorage.setItem(value35Save577, sQz577);
};

function square578(){

    var sQz578 = document.getElementById("imgSqrs578").src;

    value35Save578 = "zSqrArtSpecz578";

    localStorage.setItem(value35Save578, sQz578);
};

function square579(){

    var sQz579 = document.getElementById("imgSqrs579").src;

    value35Save579 = "zSqrArtSpecz579";

    localStorage.setItem(value35Save579, sQz579);
};

function square580(){

    var sQz580 = document.getElementById("imgSqrs580").src;

    value35Save580 = "zSqrArtSpecz580";

    localStorage.setItem(value35Save580, sQz580);
};

function square581(){

    var sQz581 = document.getElementById("imgSqrs581").src;

    value35Save581 = "zSqrArtSpecz581";

    localStorage.setItem(value35Save581, sQz581);
};

function square582(){

    var sQz582 = document.getElementById("imgSqrs582").src;

    value35Save582 = "zSqrArtSpecz582";

    localStorage.setItem(value35Save582, sQz582);
};

function square583(){

    var sQz583 = document.getElementById("imgSqrs583").src;

    value35Save583 = "zSqrArtSpecz583";

    localStorage.setItem(value35Save583, sQz583);
};

function square584(){

    var sQz584 = document.getElementById("imgSqrs584").src;

    value35Save584 = "zSqrArtSpecz584";

    localStorage.setItem(value35Save584, sQz584);
};

function square585(){

    var sQz585 = document.getElementById("imgSqrs585").src;

    value35Save585 = "zSqrArtSpecz585";

    localStorage.setItem(value35Save585, sQz585);
};

function square586(){

    var sQz586 = document.getElementById("imgSqrs586").src;

    value35Save586 = "zSqrArtSpecz586";

    localStorage.setItem(value35Save586, sQz586);
};

function square587(){

    var sQz587 = document.getElementById("imgSqrs587").src;

    value35Save587 = "zSqrArtSpecz587";

    localStorage.setItem(value35Save587, sQz587);
};

function square588(){

    var sQz588 = document.getElementById("imgSqrs588").src;

    value35Save588 = "zSqrArtSpecz588";

    localStorage.setItem(value35Save588, sQz588);
};

function square589(){

    var sQz589 = document.getElementById("imgSqrs589").src;

    value35Save589 = "zSqrArtSpecz589";

    localStorage.setItem(value35Save589, sQz589);
};

function square590(){

    var sQz590 = document.getElementById("imgSqrs590").src;

    value35Save590 = "zSqrArtSpecz590";

    localStorage.setItem(value35Save590, sQz590);
};

function square591(){

    var sQz591 = document.getElementById("imgSqrs591").src;

    value35Save591 = "zSqrArtSpecz591";

    localStorage.setItem(value35Save591, sQz591);
};

function square592(){

    var sQz592 = document.getElementById("imgSqrs592").src;

    value35Save592 = "zSqrArtSpecz592";

    localStorage.setItem(value35Save592, sQz592);
};

function square593(){

    var sQz593 = document.getElementById("imgSqrs593").src;

    value35Save593 = "zSqrArtSpecz593";

    localStorage.setItem(value35Save593, sQz593);
};

function square594(){

    var sQz594 = document.getElementById("imgSqrs594").src;

    value35Save594 = "zSqrArtSpecz594";

    localStorage.setItem(value35Save594, sQz594);
};

function square595(){

    var sQz595 = document.getElementById("imgSqrs595").src;

    value35Save595 = "zSqrArtSpecz595";

    localStorage.setItem(value35Save595, sQz595);
};

function square596(){

    var sQz596 = document.getElementById("imgSqrs596").src;

    value35Save596 = "zSqrArtSpecz596";

    localStorage.setItem(value35Save596, sQz596);
};

function square597(){

    var sQz597 = document.getElementById("imgSqrs597").src;

    value35Save597 = "zSqrArtSpecz597";

    localStorage.setItem(value35Save597, sQz597);
};

function square598(){

    var sQz598 = document.getElementById("imgSqrs598").src;

    value35Save598 = "zSqrArtSpecz598";

    localStorage.setItem(value35Save598, sQz598);
};

function square599(){

    var sQz599 = document.getElementById("imgSqrs599").src;

    value35Save599 = "zSqrArtSpecz599";

    localStorage.setItem(value35Save599, sQz599);
};

function square600(){

    var sQz600 = document.getElementById("imgSqrs600").src;

    value35Save600 = "zSqrArtSpecz600";

    localStorage.setItem(value35Save600, sQz600);
};

function square601(){

    var sQz601 = document.getElementById("imgSqrs601").src;

    value35Save601 = "zSqrArtSpecz601";

    localStorage.setItem(value35Save601, sQz601);
};

function square602(){

    var sQz602 = document.getElementById("imgSqrs602").src;

    value35Save602 = "zSqrArtSpecz602";

    localStorage.setItem(value35Save602, sQz602);
};

function square603(){

    var sQz603 = document.getElementById("imgSqrs603").src;

    value35Save603 = "zSqrArtSpecz603";

    localStorage.setItem(value35Save603, sQz603);
};

function square604(){

    var sQz604 = document.getElementById("imgSqrs604").src;

    value35Save604 = "zSqrArtSpecz604";

    localStorage.setItem(value35Save604, sQz604);
};

function square605(){

    var sQz605 = document.getElementById("imgSqrs605").src;

    value35Save605 = "zSqrArtSpecz605";

    localStorage.setItem(value35Save605, sQz605);
};

function square606(){

    var sQz606 = document.getElementById("imgSqrs606").src;

    value35Save606 = "zSqrArtSpecz606";

    localStorage.setItem(value35Save606, sQz606);
};

function square607(){

    var sQz607 = document.getElementById("imgSqrs607").src;

    value35Save607 = "zSqrArtSpecz607";

    localStorage.setItem(value35Save607, sQz607);
};

function square608(){

    var sQz608 = document.getElementById("imgSqrs608").src;

    value35Save608 = "zSqrArtSpecz608";

    localStorage.setItem(value35Save608, sQz608);
};

function square609(){

    var sQz609 = document.getElementById("imgSqrs609").src;

    value35Save609 = "zSqrArtSpecz609";

    localStorage.setItem(value35Save609, sQz609);
};

function square610(){

    var sQz610 = document.getElementById("imgSqrs610").src;

    value35Save610 = "zSqrArtSpecz610";

    localStorage.setItem(value35Save610, sQz610);
};

function square611(){

    var sQz611 = document.getElementById("imgSqrs611").src;

    value35Save611 = "zSqrArtSpecz611";

    localStorage.setItem(value35Save611, sQz611);
};

function square612(){

    var sQz612 = document.getElementById("imgSqrs612").src;

    value35Save612 = "zSqrArtSpecz612";

    localStorage.setItem(value35Save612, sQz612);
};

function square613(){

    var sQz613 = document.getElementById("imgSqrs613").src;

    value35Save613 = "zSqrArtSpecz613";

    localStorage.setItem(value35Save613, sQz613);
};

function square614(){

    var sQz614 = document.getElementById("imgSqrs614").src;

    value35Save614 = "zSqrArtSpecz614";

    localStorage.setItem(value35Save614, sQz614);
};

function square615(){

    var sQz615 = document.getElementById("imgSqrs615").src;

    value35Save615 = "zSqrArtSpecz615";

    localStorage.setItem(value35Save615, sQz615);
};

function square616(){

    var sQz616 = document.getElementById("imgSqrs616").src;

    value35Save616 = "zSqrArtSpecz616";

    localStorage.setItem(value35Save616, sQz616);
};

function square617(){

    var sQz617 = document.getElementById("imgSqrs617").src;

    value35Save617 = "zSqrArtSpecz617";

    localStorage.setItem(value35Save617, sQz617);
};

function square618(){

    var sQz618 = document.getElementById("imgSqrs618").src;

    value35Save618 = "zSqrArtSpecz618";

    localStorage.setItem(value35Save618, sQz618);
};

function square619(){

    var sQz619 = document.getElementById("imgSqrs619").src;

    value35Save619 = "zSqrArtSpecz619";

    localStorage.setItem(value35Save619, sQz619);
};

function square620(){

    var sQz620 = document.getElementById("imgSqrs620").src;

    value35Save620 = "zSqrArtSpecz620";

    localStorage.setItem(value35Save620, sQz620);
};

function square621(){

    var sQz621 = document.getElementById("imgSqrs621").src;

    value35Save621 = "zSqrArtSpecz621";

    localStorage.setItem(value35Save621, sQz621);
};

function square622(){

    var sQz622 = document.getElementById("imgSqrs622").src;

    value35Save622 = "zSqrArtSpecz622";

    localStorage.setItem(value35Save622, sQz622);
};

function square623(){

    var sQz623 = document.getElementById("imgSqrs623").src;

    value35Save623 = "zSqrArtSpecz623";

    localStorage.setItem(value35Save623, sQz623);
};

function square624(){

    var sQz624 = document.getElementById("imgSqrs624").src;

    value35Save624 = "zSqrArtSpecz624";

    localStorage.setItem(value35Save624, sQz624);
};

function square625(){

    var sQz625 = document.getElementById("imgSqrs625").src;

    value35Save625 = "zSqrArtSpecz625";

    localStorage.setItem(value35Save625, sQz625);
};

function square626(){

    var sQz626 = document.getElementById("imgSqrs626").src;

    value35Save626 = "zSqrArtSpecz626";

    localStorage.setItem(value35Save626, sQz626);
};

function square627(){

    var sQz627 = document.getElementById("imgSqrs627").src;

    value35Save627 = "zSqrArtSpecz627";

    localStorage.setItem(value35Save627, sQz627);
};

function square628(){

    var sQz628 = document.getElementById("imgSqrs628").src;

    value35Save628 = "zSqrArtSpecz628";

    localStorage.setItem(value35Save628, sQz628);
};

function square629(){

    var sQz629 = document.getElementById("imgSqrs629").src;

    value35Save629 = "zSqrArtSpecz629";

    localStorage.setItem(value35Save629, sQz629);
};

function square630(){

    var sQz630 = document.getElementById("imgSqrs630").src;

    value35Save630 = "zSqrArtSpecz630";

    localStorage.setItem(value35Save630, sQz630);
};

function square631(){

    var sQz631 = document.getElementById("imgSqrs631").src;

    value35Save631 = "zSqrArtSpecz631";

    localStorage.setItem(value35Save631, sQz631);
};

function square632(){

    var sQz632 = document.getElementById("imgSqrs632").src;

    value35Save632 = "zSqrArtSpecz632";

    localStorage.setItem(value35Save632, sQz632);
};

function square633(){

    var sQz633 = document.getElementById("imgSqrs633").src;

    value35Save633 = "zSqrArtSpecz633";

    localStorage.setItem(value35Save633, sQz633);
};

function square634(){

    var sQz634 = document.getElementById("imgSqrs634").src;

    value35Save634 = "zSqrArtSpecz634";

    localStorage.setItem(value35Save634, sQz634);
};

function square635(){

    var sQz635 = document.getElementById("imgSqrs635").src;

    value35Save635 = "zSqrArtSpecz635";

    localStorage.setItem(value35Save635, sQz635);
};

function square636(){

    var sQz636 = document.getElementById("imgSqrs636").src;

    value35Save636 = "zSqrArtSpecz636";

    localStorage.setItem(value35Save636, sQz636);
};

function square637(){

    var sQz637 = document.getElementById("imgSqrs637").src;

    value35Save637 = "zSqrArtSpecz637";

    localStorage.setItem(value35Save637, sQz637);
};

function square638(){

    var sQz638 = document.getElementById("imgSqrs638").src;

    value35Save638 = "zSqrArtSpecz638";

    localStorage.setItem(value35Save638, sQz638);
};

function square639(){

    var sQz639 = document.getElementById("imgSqrs639").src;

    value35Save639 = "zSqrArtSpecz639";

    localStorage.setItem(value35Save639, sQz639);
};

function square640(){

    var sQz640 = document.getElementById("imgSqrs640").src;

    value35Save640 = "zSqrArtSpecz640";

    localStorage.setItem(value35Save640, sQz640);
};

function square641(){

    var sQz641 = document.getElementById("imgSqrs641").src;

    value35Save641 = "zSqrArtSpecz641";

    localStorage.setItem(value35Save641, sQz641);
};

function square642(){

    var sQz642 = document.getElementById("imgSqrs642").src;

    value35Save642 = "zSqrArtSpecz642";

    localStorage.setItem(value35Save642, sQz642);
};

function square643(){

    var sQz643 = document.getElementById("imgSqrs643").src;

    value35Save643 = "zSqrArtSpecz643";

    localStorage.setItem(value35Save643, sQz643);
};

function square644(){

    var sQz644 = document.getElementById("imgSqrs644").src;

    value35Save644 = "zSqrArtSpecz644";

    localStorage.setItem(value35Save644, sQz644);
};

function square645(){

    var sQz645 = document.getElementById("imgSqrs645").src;

    value35Save645 = "zSqrArtSpecz645";

    localStorage.setItem(value35Save645, sQz645);
};

function square646(){

    var sQz646 = document.getElementById("imgSqrs646").src;

    value35Save646 = "zSqrArtSpecz646";

    localStorage.setItem(value35Save646, sQz646);
};

function square647(){

    var sQz647 = document.getElementById("imgSqrs647").src;

    value35Save647 = "zSqrArtSpecz647";

    localStorage.setItem(value35Save647, sQz647);
};

function square648(){

    var sQz648 = document.getElementById("imgSqrs648").src;

    value35Save648 = "zSqrArtSpecz648";

    localStorage.setItem(value35Save648, sQz648);
};

function square649(){

    var sQz649 = document.getElementById("imgSqrs649").src;

    value35Save649 = "zSqrArtSpecz649";

    localStorage.setItem(value35Save649, sQz649);
};

function square650(){

    var sQz650 = document.getElementById("imgSqrs650").src;

    value35Save650 = "zSqrArtSpecz650";

    localStorage.setItem(value35Save650, sQz650);
};

function square651(){

    var sQz651 = document.getElementById("imgSqrs651").src;

    value35Save651 = "zSqrArtSpecz651";

    localStorage.setItem(value35Save651, sQz651);
};

function square652(){

    var sQz652 = document.getElementById("imgSqrs652").src;

    value35Save652 = "zSqrArtSpecz652";

    localStorage.setItem(value35Save652, sQz652);
};

function square653(){

    var sQz653 = document.getElementById("imgSqrs653").src;

    value35Save653 = "zSqrArtSpecz653";

    localStorage.setItem(value35Save653, sQz653);
};

function square654(){

    var sQz654 = document.getElementById("imgSqrs654").src;

    value35Save654 = "zSqrArtSpecz654";

    localStorage.setItem(value35Save654, sQz654);
};

function square655(){

    var sQz655 = document.getElementById("imgSqrs655").src;

    value35Save655 = "zSqrArtSpecz655";

    localStorage.setItem(value35Save655, sQz655);
};

function square656(){

    var sQz656 = document.getElementById("imgSqrs656").src;

    value35Save656 = "zSqrArtSpecz656";

    localStorage.setItem(value35Save656, sQz656);
};

function square657(){

    var sQz657 = document.getElementById("imgSqrs657").src;

    value35Save657 = "zSqrArtSpecz657";

    localStorage.setItem(value35Save657, sQz657);
};

function square658(){

    var sQz658 = document.getElementById("imgSqrs658").src;

    value35Save658 = "zSqrArtSpecz658";

    localStorage.setItem(value35Save658, sQz658);
};

function square659(){

    var sQz659 = document.getElementById("imgSqrs659").src;

    value35Save659 = "zSqrArtSpecz659";

    localStorage.setItem(value35Save659, sQz659);
};

function square660(){

    var sQz660 = document.getElementById("imgSqrs660").src;

    value35Save660 = "zSqrArtSpecz660";

    localStorage.setItem(value35Save660, sQz660);
};

function square661(){

    var sQz661 = document.getElementById("imgSqrs661").src;

    value35Save661 = "zSqrArtSpecz661";

    localStorage.setItem(value35Save661, sQz661);
};

function square662(){

    var sQz662 = document.getElementById("imgSqrs662").src;

    value35Save662 = "zSqrArtSpecz662";

    localStorage.setItem(value35Save662, sQz662);
};

function square663(){

    var sQz663 = document.getElementById("imgSqrs663").src;

    value35Save663 = "zSqrArtSpecz663";

    localStorage.setItem(value35Save663, sQz663);
};

function square664(){

    var sQz664 = document.getElementById("imgSqrs664").src;

    value35Save664 = "zSqrArtSpecz664";

    localStorage.setItem(value35Save664, sQz664);
};

function square665(){

    var sQz665 = document.getElementById("imgSqrs665").src;

    value35Save665 = "zSqrArtSpecz665";

    localStorage.setItem(value35Save665, sQz665);
};

function square666(){

    var sQz666 = document.getElementById("imgSqrs666").src;

    value35Save666 = "zSqrArtSpecz666";

    localStorage.setItem(value35Save666, sQz666);
};

function square667(){

    var sQz667 = document.getElementById("imgSqrs667").src;

    value35Save667 = "zSqrArtSpecz667";

    localStorage.setItem(value35Save667, sQz667);
};

function square668(){

    var sQz668 = document.getElementById("imgSqrs668").src;

    value35Save668 = "zSqrArtSpecz668";

    localStorage.setItem(value35Save668, sQz668);
};

function square669(){

    var sQz669 = document.getElementById("imgSqrs669").src;

    value35Save669 = "zSqrArtSpecz669";

    localStorage.setItem(value35Save669, sQz669);
};

function square670(){

    var sQz670 = document.getElementById("imgSqrs670").src;

    value35Save670 = "zSqrArtSpecz670";

    localStorage.setItem(value35Save670, sQz670);
};

function square671(){

    var sQz671 = document.getElementById("imgSqrs671").src;

    value35Save671 = "zSqrArtSpecz671";

    localStorage.setItem(value35Save671, sQz671);
};

function square672(){

    var sQz672 = document.getElementById("imgSqrs672").src;

    value35Save672 = "zSqrArtSpecz672";

    localStorage.setItem(value35Save672, sQz672);
};

function square673(){

    var sQz673 = document.getElementById("imgSqrs673").src;

    value35Save673 = "zSqrArtSpecz673";

    localStorage.setItem(value35Save673, sQz673);
};

function square674(){

    var sQz674 = document.getElementById("imgSqrs674").src;

    value35Save674 = "zSqrArtSpecz674";

    localStorage.setItem(value35Save674, sQz674);
};

function square675(){

    var sQz675 = document.getElementById("imgSqrs675").src;

    value35Save675 = "zSqrArtSpecz675";

    localStorage.setItem(value35Save675, sQz675);
};

function square676(){

    var sQz676 = document.getElementById("imgSqrs676").src;

    value35Save676 = "zSqrArtSpecz676";

    localStorage.setItem(value35Save676, sQz676);
};

function square677(){

    var sQz677 = document.getElementById("imgSqrs677").src;

    value35Save677 = "zSqrArtSpecz677";

    localStorage.setItem(value35Save677, sQz677);
};

function square678(){

    var sQz678 = document.getElementById("imgSqrs678").src;

    value35Save678 = "zSqrArtSpecz678";

    localStorage.setItem(value35Save678, sQz678);
};

function square679(){

    var sQz679 = document.getElementById("imgSqrs679").src;

    value35Save679 = "zSqrArtSpecz679";

    localStorage.setItem(value35Save679, sQz679);
};

function square680(){

    var sQz680 = document.getElementById("imgSqrs680").src;

    value35Save680 = "zSqrArtSpecz680";

    localStorage.setItem(value35Save680, sQz680);
};

function square681(){

    var sQz681 = document.getElementById("imgSqrs681").src;

    value35Save681 = "zSqrArtSpecz681";

    localStorage.setItem(value35Save681, sQz681);
};

function square682(){

    var sQz682 = document.getElementById("imgSqrs682").src;

    value35Save682 = "zSqrArtSpecz682";

    localStorage.setItem(value35Save682, sQz682);
};

function square683(){

    var sQz683 = document.getElementById("imgSqrs683").src;

    value35Save683 = "zSqrArtSpecz683";

    localStorage.setItem(value35Save683, sQz683);
};

function square684(){

    var sQz684 = document.getElementById("imgSqrs684").src;

    value35Save684 = "zSqrArtSpecz684";

    localStorage.setItem(value35Save684, sQz684);
};

function square685(){

    var sQz685 = document.getElementById("imgSqrs685").src;

    value35Save685 = "zSqrArtSpecz685";

    localStorage.setItem(value35Save685, sQz685);
};

function square686(){

    var sQz686 = document.getElementById("imgSqrs686").src;

    value35Save686 = "zSqrArtSpecz686";

    localStorage.setItem(value35Save686, sQz686);
};

function square687(){

    var sQz687 = document.getElementById("imgSqrs687").src;

    value35Save687 = "zSqrArtSpecz687";

    localStorage.setItem(value35Save687, sQz687);
};

function square688(){

    var sQz688 = document.getElementById("imgSqrs688").src;

    value35Save688 = "zSqrArtSpecz688";

    localStorage.setItem(value35Save688, sQz688);
};

function square689(){

    var sQz689 = document.getElementById("imgSqrs689").src;

    value35Save689 = "zSqrArtSpecz689";

    localStorage.setItem(value35Save689, sQz689);
};

function square690(){

    var sQz690 = document.getElementById("imgSqrs690").src;

    value35Save690 = "zSqrArtSpecz690";

    localStorage.setItem(value35Save690, sQz690);
};

function square691(){

    var sQz691 = document.getElementById("imgSqrs691").src;

    value35Save691 = "zSqrArtSpecz691";

    localStorage.setItem(value35Save691, sQz691);
};

function square692(){

    var sQz692 = document.getElementById("imgSqrs692").src;

    value35Save692 = "zSqrArtSpecz692";

    localStorage.setItem(value35Save692, sQz692);
};

function square693(){

    var sQz693 = document.getElementById("imgSqrs693").src;

    value35Save693 = "zSqrArtSpecz693";

    localStorage.setItem(value35Save693, sQz693);
};

function square694(){

    var sQz694 = document.getElementById("imgSqrs694").src;

    value35Save694 = "zSqrArtSpecz694";

    localStorage.setItem(value35Save694, sQz694);
};

function square695(){

    var sQz695 = document.getElementById("imgSqrs695").src;

    value35Save695 = "zSqrArtSpecz695";

    localStorage.setItem(value35Save695, sQz695);
};

function square696(){

    var sQz696 = document.getElementById("imgSqrs696").src;

    value35Save696 = "zSqrArtSpecz696";

    localStorage.setItem(value35Save696, sQz696);
};

function square697(){

    var sQz697 = document.getElementById("imgSqrs697").src;

    value35Save697 = "zSqrArtSpecz697";

    localStorage.setItem(value35Save697, sQz697);
};

function square698(){

    var sQz698 = document.getElementById("imgSqrs698").src;

    value35Save698 = "zSqrArtSpecz698";

    localStorage.setItem(value35Save698, sQz698);
};

function square699(){

    var sQz699 = document.getElementById("imgSqrs699").src;

    value35Save699 = "zSqrArtSpecz699";

    localStorage.setItem(value35Save699, sQz699);
};

function square700(){

    var sQz700 = document.getElementById("imgSqrs700").src;

    value35Save700 = "zSqrArtSpecz700";

    localStorage.setItem(value35Save700, sQz700);
};

function square701(){

    var sQz701 = document.getElementById("imgSqrs701").src;

    value35Save701 = "zSqrArtSpecz701";

    localStorage.setItem(value35Save701, sQz701);
};

function square702(){

    var sQz702 = document.getElementById("imgSqrs702").src;

    value35Save702 = "zSqrArtSpecz702";

    localStorage.setItem(value35Save702, sQz702);
};

function square703(){

    var sQz703 = document.getElementById("imgSqrs703").src;

    value35Save703 = "zSqrArtSpecz703";

    localStorage.setItem(value35Save703, sQz703);
};

function square704(){

    var sQz704 = document.getElementById("imgSqrs704").src;

    value35Save704 = "zSqrArtSpecz704";

    localStorage.setItem(value35Save704, sQz704);
};

function square705(){

    var sQz705 = document.getElementById("imgSqrs705").src;

    value35Save705 = "zSqrArtSpecz705";

    localStorage.setItem(value35Save705, sQz705);
};

function square706(){

    var sQz706 = document.getElementById("imgSqrs706").src;

    value35Save706 = "zSqrArtSpecz706";

    localStorage.setItem(value35Save706, sQz706);
};

function square707(){

    var sQz707 = document.getElementById("imgSqrs707").src;

    value35Save707 = "zSqrArtSpecz707";

    localStorage.setItem(value35Save707, sQz707);
};

function square708(){

    var sQz708 = document.getElementById("imgSqrs708").src;

    value35Save708 = "zSqrArtSpecz708";

    localStorage.setItem(value35Save708, sQz708);
};

function square709(){

    var sQz709 = document.getElementById("imgSqrs709").src;

    value35Save709 = "zSqrArtSpecz709";

    localStorage.setItem(value35Save709, sQz709);
};

function square710(){

    var sQz710 = document.getElementById("imgSqrs710").src;

    value35Save710 = "zSqrArtSpecz710";

    localStorage.setItem(value35Save710, sQz710);
};

function square711(){

    var sQz711 = document.getElementById("imgSqrs711").src;

    value35Save711 = "zSqrArtSpecz711";

    localStorage.setItem(value35Save711, sQz711);
};

function square712(){

    var sQz712 = document.getElementById("imgSqrs712").src;

    value35Save712 = "zSqrArtSpecz712";

    localStorage.setItem(value35Save712, sQz712);
};

function square713(){

    var sQz713 = document.getElementById("imgSqrs713").src;

    value35Save713 = "zSqrArtSpecz713";

    localStorage.setItem(value35Save713, sQz713);
};

function square714(){

    var sQz714 = document.getElementById("imgSqrs714").src;

    value35Save714 = "zSqrArtSpecz714";

    localStorage.setItem(value35Save714, sQz714);
};

function square715(){

    var sQz715 = document.getElementById("imgSqrs715").src;

    value35Save715 = "zSqrArtSpecz715";

    localStorage.setItem(value35Save715, sQz715);
};

function square716(){

    var sQz716 = document.getElementById("imgSqrs716").src;

    value35Save716 = "zSqrArtSpecz716";

    localStorage.setItem(value35Save716, sQz716);
};

function square717(){

    var sQz717 = document.getElementById("imgSqrs717").src;

    value35Save717 = "zSqrArtSpecz717";

    localStorage.setItem(value35Save717, sQz717);
};

function square718(){

    var sQz718 = document.getElementById("imgSqrs718").src;

    value35Save718 = "zSqrArtSpecz718";

    localStorage.setItem(value35Save718, sQz718);
};

function square719(){

    var sQz719 = document.getElementById("imgSqrs719").src;

    value35Save719 = "zSqrArtSpecz719";

    localStorage.setItem(value35Save719, sQz719);
};

function square720(){

    var sQz720 = document.getElementById("imgSqrs720").src;

    value35Save720 = "zSqrArtSpecz720";

    localStorage.setItem(value35Save720, sQz720);
};

function square721(){

    var sQz721 = document.getElementById("imgSqrs721").src;

    value35Save721 = "zSqrArtSpecz721";

    localStorage.setItem(value35Save721, sQz721);
};

function square722(){

    var sQz722 = document.getElementById("imgSqrs722").src;

    value35Save722 = "zSqrArtSpecz722";

    localStorage.setItem(value35Save722, sQz722);
};

function square723(){

    var sQz723 = document.getElementById("imgSqrs723").src;

    value35Save723 = "zSqrArtSpecz723";

    localStorage.setItem(value35Save723, sQz723);
};

function square724(){

    var sQz724 = document.getElementById("imgSqrs724").src;

    value35Save724 = "zSqrArtSpecz724";

    localStorage.setItem(value35Save724, sQz724);
};

function square725(){

    var sQz725 = document.getElementById("imgSqrs725").src;

    value35Save725 = "zSqrArtSpecz725";

    localStorage.setItem(value35Save725, sQz725);
};

function square726(){

    var sQz726 = document.getElementById("imgSqrs726").src;

    value35Save726 = "zSqrArtSpecz726";

    localStorage.setItem(value35Save726, sQz726);
};

function square727(){

    var sQz727 = document.getElementById("imgSqrs727").src;

    value35Save727 = "zSqrArtSpecz727";

    localStorage.setItem(value35Save727, sQz727);
};

function square728(){

    var sQz728 = document.getElementById("imgSqrs728").src;

    value35Save728 = "zSqrArtSpecz728";

    localStorage.setItem(value35Save728, sQz728);
};

function square729(){

    var sQz729 = document.getElementById("imgSqrs729").src;

    value35Save729 = "zSqrArtSpecz729";

    localStorage.setItem(value35Save729, sQz729);
};

function square730(){

    var sQz730 = document.getElementById("imgSqrs730").src;

    value35Save730 = "zSqrArtSpecz730";

    localStorage.setItem(value35Save730, sQz730);
};

function square731(){

    var sQz731 = document.getElementById("imgSqrs731").src;

    value35Save731 = "zSqrArtSpecz731";

    localStorage.setItem(value35Save731, sQz731);
};

function square732(){

    var sQz732 = document.getElementById("imgSqrs732").src;

    value35Save732 = "zSqrArtSpecz732";

    localStorage.setItem(value35Save732, sQz732);
};

function square733(){

    var sQz733 = document.getElementById("imgSqrs733").src;

    value35Save733 = "zSqrArtSpecz733";

    localStorage.setItem(value35Save733, sQz733);
};

function square734(){

    var sQz734 = document.getElementById("imgSqrs734").src;

    value35Save734 = "zSqrArtSpecz734";

    localStorage.setItem(value35Save734, sQz734);
};

function square735(){

    var sQz735 = document.getElementById("imgSqrs735").src;

    value35Save735 = "zSqrArtSpecz735";

    localStorage.setItem(value35Save735, sQz735);
};

function square736(){

    var sQz736 = document.getElementById("imgSqrs736").src;

    value35Save736 = "zSqrArtSpecz736";

    localStorage.setItem(value35Save736, sQz736);
};

function square737(){

    var sQz737 = document.getElementById("imgSqrs737").src;

    value35Save737 = "zSqrArtSpecz737";

    localStorage.setItem(value35Save737, sQz737);
};

function square738(){

    var sQz738 = document.getElementById("imgSqrs738").src;

    value35Save738 = "zSqrArtSpecz738";

    localStorage.setItem(value35Save738, sQz738);
};

function square739(){

    var sQz739 = document.getElementById("imgSqrs739").src;

    value35Save739 = "zSqrArtSpecz739";

    localStorage.setItem(value35Save739, sQz739);
};

function square740(){

    var sQz740 = document.getElementById("imgSqrs740").src;

    value35Save740 = "zSqrArtSpecz740";

    localStorage.setItem(value35Save740, sQz740);
};

function square741(){

    var sQz741 = document.getElementById("imgSqrs741").src;

    value35Save741 = "zSqrArtSpecz741";

    localStorage.setItem(value35Save741, sQz741);
};

function square742(){

    var sQz742 = document.getElementById("imgSqrs742").src;

    value35Save742 = "zSqrArtSpecz742";

    localStorage.setItem(value35Save742, sQz742);
};

function square743(){

    var sQz743 = document.getElementById("imgSqrs743").src;

    value35Save743 = "zSqrArtSpecz743";

    localStorage.setItem(value35Save743, sQz743);
};

function square744(){

    var sQz744 = document.getElementById("imgSqrs744").src;

    value35Save744 = "zSqrArtSpecz744";

    localStorage.setItem(value35Save744, sQz744);
};

function square745(){

    var sQz745 = document.getElementById("imgSqrs745").src;

    value35Save745 = "zSqrArtSpecz745";

    localStorage.setItem(value35Save745, sQz745);
};

function square746(){

    var sQz746 = document.getElementById("imgSqrs746").src;

    value35Save746 = "zSqrArtSpecz746";

    localStorage.setItem(value35Save746, sQz746);
};

function square747(){

    var sQz747 = document.getElementById("imgSqrs747").src;

    value35Save747 = "zSqrArtSpecz747";

    localStorage.setItem(value35Save747, sQz747);
};

function square748(){

    var sQz748 = document.getElementById("imgSqrs748").src;

    value35Save748 = "zSqrArtSpecz748";

    localStorage.setItem(value35Save748, sQz748);
};

function square749(){

    var sQz749 = document.getElementById("imgSqrs749").src;

    value35Save749 = "zSqrArtSpecz749";

    localStorage.setItem(value35Save749, sQz749);
};

function square750(){

    var sQz750 = document.getElementById("imgSqrs750").src;

    value35Save750 = "zSqrArtSpecz750";

    localStorage.setItem(value35Save750, sQz750);
};

function square751(){

    var sQz751 = document.getElementById("imgSqrs751").src;

    value35Save751 = "zSqrArtSpecz751";

    localStorage.setItem(value35Save751, sQz751);
};

function square752(){

    var sQz752 = document.getElementById("imgSqrs752").src;

    value35Save752 = "zSqrArtSpecz752";

    localStorage.setItem(value35Save752, sQz752);
};

function square753(){

    var sQz753 = document.getElementById("imgSqrs753").src;

    value35Save753 = "zSqrArtSpecz753";

    localStorage.setItem(value35Save753, sQz753);
};

function square754(){

    var sQz754 = document.getElementById("imgSqrs754").src;

    value35Save754 = "zSqrArtSpecz754";

    localStorage.setItem(value35Save754, sQz754);
};

function square755(){

    var sQz755 = document.getElementById("imgSqrs755").src;

    value35Save755 = "zSqrArtSpecz755";

    localStorage.setItem(value35Save755, sQz755);
};

function square756(){

    var sQz756 = document.getElementById("imgSqrs756").src;

    value35Save756 = "zSqrArtSpecz756";

    localStorage.setItem(value35Save756, sQz756);
};

function square757(){

    var sQz757 = document.getElementById("imgSqrs757").src;

    value35Save757 = "zSqrArtSpecz757";

    localStorage.setItem(value35Save757, sQz757);
};

function square758(){

    var sQz758 = document.getElementById("imgSqrs758").src;

    value35Save758 = "zSqrArtSpecz758";

    localStorage.setItem(value35Save758, sQz758);
};

function square759(){

    var sQz759 = document.getElementById("imgSqrs759").src;

    value35Save759 = "zSqrArtSpecz759";

    localStorage.setItem(value35Save759, sQz759);
};

function square760(){

    var sQz760 = document.getElementById("imgSqrs760").src;

    value35Save760 = "zSqrArtSpecz760";

    localStorage.setItem(value35Save760, sQz760);
};

function square761(){

    var sQz761 = document.getElementById("imgSqrs761").src;

    value35Save761 = "zSqrArtSpecz761";

    localStorage.setItem(value35Save761, sQz761);
};

function square762(){

    var sQz762 = document.getElementById("imgSqrs762").src;

    value35Save762 = "zSqrArtSpecz762";

    localStorage.setItem(value35Save762, sQz762);
};

function square763(){

    var sQz763 = document.getElementById("imgSqrs763").src;

    value35Save763 = "zSqrArtSpecz763";

    localStorage.setItem(value35Save763, sQz763);
};

function square764(){

    var sQz764 = document.getElementById("imgSqrs764").src;

    value35Save764 = "zSqrArtSpecz764";

    localStorage.setItem(value35Save764, sQz764);
};

function square765(){

    var sQz765 = document.getElementById("imgSqrs765").src;

    value35Save765 = "zSqrArtSpecz765";

    localStorage.setItem(value35Save765, sQz765);
};

function square766(){

    var sQz766 = document.getElementById("imgSqrs766").src;

    value35Save766 = "zSqrArtSpecz766";

    localStorage.setItem(value35Save766, sQz766);
};

function square767(){

    var sQz767 = document.getElementById("imgSqrs767").src;

    value35Save767 = "zSqrArtSpecz767";

    localStorage.setItem(value35Save767, sQz767);
};

function square768(){

    var sQz768 = document.getElementById("imgSqrs768").src;

    value35Save768 = "zSqrArtSpecz768";

    localStorage.setItem(value35Save768, sQz768);
};

function square769(){

    var sQz769 = document.getElementById("imgSqrs769").src;

    value35Save769 = "zSqrArtSpecz769";

    localStorage.setItem(value35Save769, sQz769);
};

function square770(){

    var sQz770 = document.getElementById("imgSqrs770").src;

    value35Save770 = "zSqrArtSpecz770";

    localStorage.setItem(value35Save770, sQz770);
};

function square771(){

    var sQz771 = document.getElementById("imgSqrs771").src;

    value35Save771 = "zSqrArtSpecz771";

    localStorage.setItem(value35Save771, sQz771);
};

function square772(){

    var sQz772 = document.getElementById("imgSqrs772").src;

    value35Save772 = "zSqrArtSpecz772";

    localStorage.setItem(value35Save772, sQz772);
};

function square773(){

    var sQz773 = document.getElementById("imgSqrs773").src;

    value35Save773 = "zSqrArtSpecz773";

    localStorage.setItem(value35Save773, sQz773);
};

function square774(){

    var sQz774 = document.getElementById("imgSqrs774").src;

    value35Save774 = "zSqrArtSpecz774";

    localStorage.setItem(value35Save774, sQz774);
};

function square775(){

    var sQz775 = document.getElementById("imgSqrs775").src;

    value35Save775 = "zSqrArtSpecz775";

    localStorage.setItem(value35Save775, sQz775);
};

function square776(){

    var sQz776 = document.getElementById("imgSqrs776").src;

    value35Save776 = "zSqrArtSpecz776";

    localStorage.setItem(value35Save776, sQz776);
};

function square777(){

    var sQz777 = document.getElementById("imgSqrs777").src;

    value35Save777 = "zSqrArtSpecz777";

    localStorage.setItem(value35Save777, sQz777);
};

function square778(){

    var sQz778 = document.getElementById("imgSqrs778").src;

    value35Save778 = "zSqrArtSpecz778";

    localStorage.setItem(value35Save778, sQz778);
};

function square779(){

    var sQz779 = document.getElementById("imgSqrs779").src;

    value35Save779 = "zSqrArtSpecz779";

    localStorage.setItem(value35Save779, sQz779);
};

function square780(){

    var sQz780 = document.getElementById("imgSqrs780").src;

    value35Save780 = "zSqrArtSpecz780";

    localStorage.setItem(value35Save780, sQz780);
};

function square781(){

    var sQz781 = document.getElementById("imgSqrs781").src;

    value35Save781 = "zSqrArtSpecz781";

    localStorage.setItem(value35Save781, sQz781);
};

function square782(){

    var sQz782 = document.getElementById("imgSqrs782").src;

    value35Save782 = "zSqrArtSpecz782";

    localStorage.setItem(value35Save782, sQz782);
};

function square783(){

    var sQz783 = document.getElementById("imgSqrs783").src;

    value35Save783 = "zSqrArtSpecz783";

    localStorage.setItem(value35Save783, sQz783);
};

function square784(){

    var sQz784 = document.getElementById("imgSqrs784").src;

    value35Save784 = "zSqrArtSpecz784";

    localStorage.setItem(value35Save784, sQz784);
};

function square785(){

    var sQz785 = document.getElementById("imgSqrs785").src;

    value35Save785 = "zSqrArtSpecz785";

    localStorage.setItem(value35Save785, sQz785);
};

function square786(){

    var sQz786 = document.getElementById("imgSqrs786").src;

    value35Save786 = "zSqrArtSpecz786";

    localStorage.setItem(value35Save786, sQz786);
};

function square787(){

    var sQz787 = document.getElementById("imgSqrs787").src;

    value35Save787 = "zSqrArtSpecz787";

    localStorage.setItem(value35Save787, sQz787);
};

function square788(){

    var sQz788 = document.getElementById("imgSqrs788").src;

    value35Save788 = "zSqrArtSpecz788";

    localStorage.setItem(value35Save788, sQz788);
};

function square789(){

    var sQz789 = document.getElementById("imgSqrs789").src;

    value35Save789 = "zSqrArtSpecz789";

    localStorage.setItem(value35Save789, sQz789);
};

function square790(){

    var sQz790 = document.getElementById("imgSqrs790").src;

    value35Save790 = "zSqrArtSpecz790";

    localStorage.setItem(value35Save790, sQz790);
};

function square791(){

    var sQz791 = document.getElementById("imgSqrs791").src;

    value35Save791 = "zSqrArtSpecz791";

    localStorage.setItem(value35Save791, sQz791);
};

function square792(){

    var sQz792 = document.getElementById("imgSqrs792").src;

    value35Save792 = "zSqrArtSpecz792";

    localStorage.setItem(value35Save792, sQz792);
};

function square793(){

    var sQz793 = document.getElementById("imgSqrs793").src;

    value35Save793 = "zSqrArtSpecz793";

    localStorage.setItem(value35Save793, sQz793);
};

function square794(){

    var sQz794 = document.getElementById("imgSqrs794").src;

    value35Save794 = "zSqrArtSpecz794";

    localStorage.setItem(value35Save794, sQz794);
};

function square795(){

    var sQz795 = document.getElementById("imgSqrs795").src;

    value35Save795 = "zSqrArtSpecz795";

    localStorage.setItem(value35Save795, sQz795);
};

function square796(){

    var sQz796 = document.getElementById("imgSqrs796").src;

    value35Save796 = "zSqrArtSpecz796";

    localStorage.setItem(value35Save796, sQz796);
};

function square797(){

    var sQz797 = document.getElementById("imgSqrs797").src;

    value35Save797 = "zSqrArtSpecz797";

    localStorage.setItem(value35Save797, sQz797);
};

function square798(){

    var sQz798 = document.getElementById("imgSqrs798").src;

    value35Save798 = "zSqrArtSpecz798";

    localStorage.setItem(value35Save798, sQz798);
};

function square799(){

    var sQz799 = document.getElementById("imgSqrs799").src;

    value35Save799 = "zSqrArtSpecz799";

    localStorage.setItem(value35Save799, sQz799);
};

function square800(){

    var sQz800 = document.getElementById("imgSqrs800").src;

    value35Save800 = "zSqrArtSpecz800";

    localStorage.setItem(value35Save800, sQz800);
};

function square801(){

    var sQz801 = document.getElementById("imgSqrs801").src;

    value35Save801 = "zSqrArtSpecz801";

    localStorage.setItem(value35Save801, sQz801);
};

function square802(){

    var sQz802 = document.getElementById("imgSqrs802").src;

    value35Save802 = "zSqrArtSpecz802";

    localStorage.setItem(value35Save802, sQz802);
};

function square803(){

    var sQz803 = document.getElementById("imgSqrs803").src;

    value35Save803 = "zSqrArtSpecz803";

    localStorage.setItem(value35Save803, sQz803);
};

function square804(){

    var sQz804 = document.getElementById("imgSqrs804").src;

    value35Save804 = "zSqrArtSpecz804";

    localStorage.setItem(value35Save804, sQz804);
};

function square805(){

    var sQz805 = document.getElementById("imgSqrs805").src;

    value35Save805 = "zSqrArtSpecz805";

    localStorage.setItem(value35Save805, sQz805);
};

function square806(){

    var sQz806 = document.getElementById("imgSqrs806").src;

    value35Save806 = "zSqrArtSpecz806";

    localStorage.setItem(value35Save806, sQz806);
};

function square807(){

    var sQz807 = document.getElementById("imgSqrs807").src;

    value35Save807 = "zSqrArtSpecz807";

    localStorage.setItem(value35Save807, sQz807);
};

function square808(){

    var sQz808 = document.getElementById("imgSqrs808").src;

    value35Save808 = "zSqrArtSpecz808";

    localStorage.setItem(value35Save808, sQz808);
};

function square809(){

    var sQz809 = document.getElementById("imgSqrs809").src;

    value35Save809 = "zSqrArtSpecz809";

    localStorage.setItem(value35Save809, sQz809);
};

function square810(){

    var sQz810 = document.getElementById("imgSqrs810").src;

    value35Save810 = "zSqrArtSpecz810";

    localStorage.setItem(value35Save810, sQz810);
};

function square811(){

    var sQz811 = document.getElementById("imgSqrs811").src;

    value35Save811 = "zSqrArtSpecz811";

    localStorage.setItem(value35Save811, sQz811);
};

function square812(){

    var sQz812 = document.getElementById("imgSqrs812").src;

    value35Save812 = "zSqrArtSpecz812";

    localStorage.setItem(value35Save812, sQz812);
};

function square813(){

    var sQz813 = document.getElementById("imgSqrs813").src;

    value35Save813 = "zSqrArtSpecz813";

    localStorage.setItem(value35Save813, sQz813);
};

function square814(){

    var sQz814 = document.getElementById("imgSqrs814").src;

    value35Save814 = "zSqrArtSpecz814";

    localStorage.setItem(value35Save814, sQz814);
};

function square815(){

    var sQz815 = document.getElementById("imgSqrs815").src;

    value35Save815 = "zSqrArtSpecz815";

    localStorage.setItem(value35Save815, sQz815);
};

function square816(){

    var sQz816 = document.getElementById("imgSqrs816").src;

    value35Save816 = "zSqrArtSpecz816";

    localStorage.setItem(value35Save816, sQz816);
};

function square817(){

    var sQz817 = document.getElementById("imgSqrs817").src;

    value35Save817 = "zSqrArtSpecz817";

    localStorage.setItem(value35Save817, sQz817);
};

function square818(){

    var sQz818 = document.getElementById("imgSqrs818").src;

    value35Save818 = "zSqrArtSpecz818";

    localStorage.setItem(value35Save818, sQz818);
};

function square819(){

    var sQz819 = document.getElementById("imgSqrs819").src;

    value35Save819 = "zSqrArtSpecz819";

    localStorage.setItem(value35Save819, sQz819);
};

function square820(){

    var sQz820 = document.getElementById("imgSqrs820").src;

    value35Save820 = "zSqrArtSpecz820";

    localStorage.setItem(value35Save820, sQz820);
};

function square821(){

    var sQz821 = document.getElementById("imgSqrs821").src;

    value35Save821 = "zSqrArtSpecz821";

    localStorage.setItem(value35Save821, sQz821);
};

function square822(){

    var sQz822 = document.getElementById("imgSqrs822").src;

    value35Save822 = "zSqrArtSpecz822";

    localStorage.setItem(value35Save822, sQz822);
};

function square823(){

    var sQz823 = document.getElementById("imgSqrs823").src;

    value35Save823 = "zSqrArtSpecz823";

    localStorage.setItem(value35Save823, sQz823);
};

function square824(){

    var sQz824 = document.getElementById("imgSqrs824").src;

    value35Save824 = "zSqrArtSpecz824";

    localStorage.setItem(value35Save824, sQz824);
};

function square825(){

    var sQz825 = document.getElementById("imgSqrs825").src;

    value35Save825 = "zSqrArtSpecz825";

    localStorage.setItem(value35Save825, sQz825);
};

function square826(){

    var sQz826 = document.getElementById("imgSqrs826").src;

    value35Save826 = "zSqrArtSpecz826";

    localStorage.setItem(value35Save826, sQz826);
};

function square827(){

    var sQz827 = document.getElementById("imgSqrs827").src;

    value35Save827 = "zSqrArtSpecz827";

    localStorage.setItem(value35Save827, sQz827);
};

function square828(){

    var sQz828 = document.getElementById("imgSqrs828").src;

    value35Save828 = "zSqrArtSpecz828";

    localStorage.setItem(value35Save828, sQz828);
};

function square829(){

    var sQz829 = document.getElementById("imgSqrs829").src;

    value35Save829 = "zSqrArtSpecz829";

    localStorage.setItem(value35Save829, sQz829);
};

function square830(){

    var sQz830 = document.getElementById("imgSqrs830").src;

    value35Save830 = "zSqrArtSpecz830";

    localStorage.setItem(value35Save830, sQz830);
};

function square831(){

    var sQz831 = document.getElementById("imgSqrs831").src;

    value35Save831 = "zSqrArtSpecz831";

    localStorage.setItem(value35Save831, sQz831);
};

function square832(){

    var sQz832 = document.getElementById("imgSqrs832").src;

    value35Save832 = "zSqrArtSpecz832";

    localStorage.setItem(value35Save832, sQz832);
};

function square833(){

    var sQz833 = document.getElementById("imgSqrs833").src;

    value35Save833 = "zSqrArtSpecz833";

    localStorage.setItem(value35Save833, sQz833);
};

function square834(){

    var sQz834 = document.getElementById("imgSqrs834").src;

    value35Save834 = "zSqrArtSpecz834";

    localStorage.setItem(value35Save834, sQz834);
};

function square835(){

    var sQz835 = document.getElementById("imgSqrs835").src;

    value35Save835 = "zSqrArtSpecz835";

    localStorage.setItem(value35Save835, sQz835);
};

function square836(){

    var sQz836 = document.getElementById("imgSqrs836").src;

    value35Save836 = "zSqrArtSpecz836";

    localStorage.setItem(value35Save836, sQz836);
};

function square837(){

    var sQz837 = document.getElementById("imgSqrs837").src;

    value35Save837 = "zSqrArtSpecz837";

    localStorage.setItem(value35Save837, sQz837);
};

function square838(){

    var sQz838 = document.getElementById("imgSqrs838").src;

    value35Save838 = "zSqrArtSpecz838";

    localStorage.setItem(value35Save838, sQz838);
};

function square839(){

    var sQz839 = document.getElementById("imgSqrs839").src;

    value35Save839 = "zSqrArtSpecz839";

    localStorage.setItem(value35Save839, sQz839);
};

function square840(){

    var sQz840 = document.getElementById("imgSqrs840").src;

    value35Save840 = "zSqrArtSpecz840";

    localStorage.setItem(value35Save840, sQz840);
};

function square841(){

    var sQz841 = document.getElementById("imgSqrs841").src;

    value35Save841 = "zSqrArtSpecz841";

    localStorage.setItem(value35Save841, sQz841);
};

function square842(){

    var sQz842 = document.getElementById("imgSqrs842").src;

    value35Save842 = "zSqrArtSpecz842";

    localStorage.setItem(value35Save842, sQz842);
};

function square843(){

    var sQz843 = document.getElementById("imgSqrs843").src;

    value35Save843 = "zSqrArtSpecz843";

    localStorage.setItem(value35Save843, sQz843);
};

function square844(){

    var sQz844 = document.getElementById("imgSqrs844").src;

    value35Save844 = "zSqrArtSpecz844";

    localStorage.setItem(value35Save844, sQz844);
};

function square845(){

    var sQz845 = document.getElementById("imgSqrs845").src;

    value35Save845 = "zSqrArtSpecz845";

    localStorage.setItem(value35Save845, sQz845);
};

function square846(){

    var sQz846 = document.getElementById("imgSqrs846").src;

    value35Save846 = "zSqrArtSpecz846";

    localStorage.setItem(value35Save846, sQz846);
};

function square847(){

    var sQz847 = document.getElementById("imgSqrs847").src;

    value35Save847 = "zSqrArtSpecz847";

    localStorage.setItem(value35Save847, sQz847);
};

function square848(){

    var sQz848 = document.getElementById("imgSqrs848").src;

    value35Save848 = "zSqrArtSpecz848";

    localStorage.setItem(value35Save848, sQz848);
};

function square849(){

    var sQz849 = document.getElementById("imgSqrs849").src;

    value35Save849 = "zSqrArtSpecz849";

    localStorage.setItem(value35Save849, sQz849);
};

function square850(){

    var sQz850 = document.getElementById("imgSqrs850").src;

    value35Save850 = "zSqrArtSpecz850";

    localStorage.setItem(value35Save850, sQz850);
};

function square851(){

    var sQz851 = document.getElementById("imgSqrs851").src;

    value35Save851 = "zSqrArtSpecz851";

    localStorage.setItem(value35Save851, sQz851);
};

function square852(){

    var sQz852 = document.getElementById("imgSqrs852").src;

    value35Save852 = "zSqrArtSpecz852";

    localStorage.setItem(value35Save852, sQz852);
};

function square853(){

    var sQz853 = document.getElementById("imgSqrs853").src;

    value35Save853 = "zSqrArtSpecz853";

    localStorage.setItem(value35Save853, sQz853);
};

function square854(){

    var sQz854 = document.getElementById("imgSqrs854").src;

    value35Save854 = "zSqrArtSpecz854";

    localStorage.setItem(value35Save854, sQz854);
};

function square855(){

    var sQz855 = document.getElementById("imgSqrs855").src;

    value35Save855 = "zSqrArtSpecz855";

    localStorage.setItem(value35Save855, sQz855);
};

function square856(){

    var sQz856 = document.getElementById("imgSqrs856").src;

    value35Save856 = "zSqrArtSpecz856";

    localStorage.setItem(value35Save856, sQz856);
};

function square857(){

    var sQz857 = document.getElementById("imgSqrs857").src;

    value35Save857 = "zSqrArtSpecz857";

    localStorage.setItem(value35Save857, sQz857);
};

function square858(){

    var sQz858 = document.getElementById("imgSqrs858").src;

    value35Save858 = "zSqrArtSpecz858";

    localStorage.setItem(value35Save858, sQz858);
};

function square859(){

    var sQz859 = document.getElementById("imgSqrs859").src;

    value35Save859 = "zSqrArtSpecz859";

    localStorage.setItem(value35Save859, sQz859);
};

function square860(){

    var sQz860 = document.getElementById("imgSqrs860").src;

    value35Save860 = "zSqrArtSpecz860";

    localStorage.setItem(value35Save860, sQz860);
};

function square861(){

    var sQz861 = document.getElementById("imgSqrs861").src;

    value35Save861 = "zSqrArtSpecz861";

    localStorage.setItem(value35Save861, sQz861);
};

function square862(){

    var sQz862 = document.getElementById("imgSqrs862").src;

    value35Save862 = "zSqrArtSpecz862";

    localStorage.setItem(value35Save862, sQz862);
};

function square863(){

    var sQz863 = document.getElementById("imgSqrs863").src;

    value35Save863 = "zSqrArtSpecz863";

    localStorage.setItem(value35Save863, sQz863);
};

function square864(){

    var sQz864 = document.getElementById("imgSqrs864").src;

    value35Save864 = "zSqrArtSpecz864";

    localStorage.setItem(value35Save864, sQz864);
};

function square865(){

    var sQz865 = document.getElementById("imgSqrs865").src;

    value35Save865 = "zSqrArtSpecz865";

    localStorage.setItem(value35Save865, sQz865);
};

function square866(){

    var sQz866 = document.getElementById("imgSqrs866").src;

    value35Save866 = "zSqrArtSpecz866";

    localStorage.setItem(value35Save866, sQz866);
};

function square867(){

    var sQz867 = document.getElementById("imgSqrs867").src;

    value35Save867 = "zSqrArtSpecz867";

    localStorage.setItem(value35Save867, sQz867);
};

function square868(){

    var sQz868 = document.getElementById("imgSqrs868").src;

    value35Save868 = "zSqrArtSpecz868";

    localStorage.setItem(value35Save868, sQz868);
};

function square869(){

    var sQz869 = document.getElementById("imgSqrs869").src;

    value35Save869 = "zSqrArtSpecz869";

    localStorage.setItem(value35Save869, sQz869);
};

function square870(){

    var sQz870 = document.getElementById("imgSqrs870").src;

    value35Save870 = "zSqrArtSpecz870";

    localStorage.setItem(value35Save870, sQz870);
};

function square871(){

    var sQz871 = document.getElementById("imgSqrs871").src;

    value35Save871 = "zSqrArtSpecz871";

    localStorage.setItem(value35Save871, sQz871);
};

function square872(){

    var sQz872 = document.getElementById("imgSqrs872").src;

    value35Save872 = "zSqrArtSpecz872";

    localStorage.setItem(value35Save872, sQz872);
};

function square873(){

    var sQz873 = document.getElementById("imgSqrs873").src;

    value35Save873 = "zSqrArtSpecz873";

    localStorage.setItem(value35Save873, sQz873);
};

function square874(){

    var sQz874 = document.getElementById("imgSqrs874").src;

    value35Save874 = "zSqrArtSpecz874";

    localStorage.setItem(value35Save874, sQz874);
};

function square875(){

    var sQz875 = document.getElementById("imgSqrs875").src;

    value35Save875 = "zSqrArtSpecz875";

    localStorage.setItem(value35Save875, sQz875);
};

function square876(){

    var sQz876 = document.getElementById("imgSqrs876").src;

    value35Save876 = "zSqrArtSpecz876";

    localStorage.setItem(value35Save876, sQz876);
};

function square877(){

    var sQz877 = document.getElementById("imgSqrs877").src;

    value35Save877 = "zSqrArtSpecz877";

    localStorage.setItem(value35Save877, sQz877);
};

function square878(){

    var sQz878 = document.getElementById("imgSqrs878").src;

    value35Save878 = "zSqrArtSpecz878";

    localStorage.setItem(value35Save878, sQz878);
};

function square879(){

    var sQz879 = document.getElementById("imgSqrs879").src;

    value35Save879 = "zSqrArtSpecz879";

    localStorage.setItem(value35Save879, sQz879);
};

function square880(){

    var sQz880 = document.getElementById("imgSqrs880").src;

    value35Save880 = "zSqrArtSpecz880";

    localStorage.setItem(value35Save880, sQz880);
};

function square881(){

    var sQz881 = document.getElementById("imgSqrs881").src;

    value35Save881 = "zSqrArtSpecz881";

    localStorage.setItem(value35Save881, sQz881);
};

function square882(){

    var sQz882 = document.getElementById("imgSqrs882").src;

    value35Save882 = "zSqrArtSpecz882";

    localStorage.setItem(value35Save882, sQz882);
};

function square883(){

    var sQz883 = document.getElementById("imgSqrs883").src;

    value35Save883 = "zSqrArtSpecz883";

    localStorage.setItem(value35Save883, sQz883);
};

function square884(){

    var sQz884 = document.getElementById("imgSqrs884").src;

    value35Save884 = "zSqrArtSpecz884";

    localStorage.setItem(value35Save884, sQz884);
};

function square885(){

    var sQz885 = document.getElementById("imgSqrs885").src;

    value35Save885 = "zSqrArtSpecz885";

    localStorage.setItem(value35Save885, sQz885);
};

function square886(){

    var sQz886 = document.getElementById("imgSqrs886").src;

    value35Save886 = "zSqrArtSpecz886";

    localStorage.setItem(value35Save886, sQz886);
};

function square887(){

    var sQz887 = document.getElementById("imgSqrs887").src;

    value35Save887 = "zSqrArtSpecz887";

    localStorage.setItem(value35Save887, sQz887);
};

function square888(){

    var sQz888 = document.getElementById("imgSqrs888").src;

    value35Save888 = "zSqrArtSpecz888";

    localStorage.setItem(value35Save888, sQz888);
};

function square889(){

    var sQz889 = document.getElementById("imgSqrs889").src;

    value35Save889 = "zSqrArtSpecz889";

    localStorage.setItem(value35Save889, sQz889);
};

function square890(){

    var sQz890 = document.getElementById("imgSqrs890").src;

    value35Save890 = "zSqrArtSpecz890";

    localStorage.setItem(value35Save890, sQz890);
};

function square891(){

    var sQz891 = document.getElementById("imgSqrs891").src;

    value35Save891 = "zSqrArtSpecz891";

    localStorage.setItem(value35Save891, sQz891);
};

function square892(){

    var sQz892 = document.getElementById("imgSqrs892").src;

    value35Save892 = "zSqrArtSpecz892";

    localStorage.setItem(value35Save892, sQz892);
};

function square893(){

    var sQz893 = document.getElementById("imgSqrs893").src;

    value35Save893 = "zSqrArtSpecz893";

    localStorage.setItem(value35Save893, sQz893);
};

function square894(){

    var sQz894 = document.getElementById("imgSqrs894").src;

    value35Save894 = "zSqrArtSpecz894";

    localStorage.setItem(value35Save894, sQz894);
};

function square895(){

    var sQz895 = document.getElementById("imgSqrs895").src;

    value35Save895 = "zSqrArtSpecz895";

    localStorage.setItem(value35Save895, sQz895);
};

function square896(){

    var sQz896 = document.getElementById("imgSqrs896").src;

    value35Save896 = "zSqrArtSpecz896";

    localStorage.setItem(value35Save896, sQz896);
};

function square897(){

    var sQz897 = document.getElementById("imgSqrs897").src;

    value35Save897 = "zSqrArtSpecz897";

    localStorage.setItem(value35Save897, sQz897);
};

function square898(){

    var sQz898 = document.getElementById("imgSqrs898").src;

    value35Save898 = "zSqrArtSpecz898";

    localStorage.setItem(value35Save898, sQz898);
};

function square899(){

    var sQz899 = document.getElementById("imgSqrs899").src;

    value35Save899 = "zSqrArtSpecz899";

    localStorage.setItem(value35Save899, sQz899);
};

function square900(){

    var sQz900 = document.getElementById("imgSqrs900").src;

    value35Save900 = "zSqrArtSpecz900";

    localStorage.setItem(value35Save900, sQz900);
};

function square901(){

    var sQz901 = document.getElementById("imgSqrs901").src;

    value35Save901 = "zSqrArtSpecz901";

    localStorage.setItem(value35Save901, sQz901);
};

function square902(){

    var sQz902 = document.getElementById("imgSqrs902").src;

    value35Save902 = "zSqrArtSpecz902";

    localStorage.setItem(value35Save902, sQz902);
};

function square903(){

    var sQz903 = document.getElementById("imgSqrs903").src;

    value35Save903 = "zSqrArtSpecz903";

    localStorage.setItem(value35Save903, sQz903);
};

function square904(){

    var sQz904 = document.getElementById("imgSqrs904").src;

    value35Save904 = "zSqrArtSpecz904";

    localStorage.setItem(value35Save904, sQz904);
};

function square905(){

    var sQz905 = document.getElementById("imgSqrs905").src;

    value35Save905 = "zSqrArtSpecz905";

    localStorage.setItem(value35Save905, sQz905);
};

function square906(){

    var sQz906 = document.getElementById("imgSqrs906").src;

    value35Save906 = "zSqrArtSpecz906";

    localStorage.setItem(value35Save906, sQz906);
};

function square907(){

    var sQz907 = document.getElementById("imgSqrs907").src;

    value35Save907 = "zSqrArtSpecz907";

    localStorage.setItem(value35Save907, sQz907);
};

function square908(){

    var sQz908 = document.getElementById("imgSqrs908").src;

    value35Save908 = "zSqrArtSpecz908";

    localStorage.setItem(value35Save908, sQz908);
};

function square909(){

    var sQz909 = document.getElementById("imgSqrs909").src;

    value35Save909 = "zSqrArtSpecz909";

    localStorage.setItem(value35Save909, sQz909);
};

function square910(){

    var sQz910 = document.getElementById("imgSqrs910").src;

    value35Save910 = "zSqrArtSpecz910";

    localStorage.setItem(value35Save910, sQz910);
};

function square911(){

    var sQz911 = document.getElementById("imgSqrs911").src;

    value35Save911 = "zSqrArtSpecz911";

    localStorage.setItem(value35Save911, sQz911);
};

function square912(){

    var sQz912 = document.getElementById("imgSqrs912").src;

    value35Save912 = "zSqrArtSpecz912";

    localStorage.setItem(value35Save912, sQz912);
};

function square913(){

    var sQz913 = document.getElementById("imgSqrs913").src;

    value35Save913 = "zSqrArtSpecz913";

    localStorage.setItem(value35Save913, sQz913);
};

function square914(){

    var sQz914 = document.getElementById("imgSqrs914").src;

    value35Save914 = "zSqrArtSpecz914";

    localStorage.setItem(value35Save914, sQz914);
};

function square915(){

    var sQz915 = document.getElementById("imgSqrs915").src;

    value35Save915 = "zSqrArtSpecz915";

    localStorage.setItem(value35Save915, sQz915);
};

function square916(){

    var sQz916 = document.getElementById("imgSqrs916").src;

    value35Save916 = "zSqrArtSpecz916";

    localStorage.setItem(value35Save916, sQz916);
};

function square917(){

    var sQz917 = document.getElementById("imgSqrs917").src;

    value35Save917 = "zSqrArtSpecz917";

    localStorage.setItem(value35Save917, sQz917);
};

function square918(){

    var sQz918 = document.getElementById("imgSqrs918").src;

    value35Save918 = "zSqrArtSpecz918";

    localStorage.setItem(value35Save918, sQz918);
};

function square919(){

    var sQz919 = document.getElementById("imgSqrs919").src;

    value35Save919 = "zSqrArtSpecz919";

    localStorage.setItem(value35Save919, sQz919);
};

function square920(){

    var sQz920 = document.getElementById("imgSqrs920").src;

    value35Save920 = "zSqrArtSpecz920";

    localStorage.setItem(value35Save920, sQz920);
};

function square921(){

    var sQz921 = document.getElementById("imgSqrs921").src;

    value35Save921 = "zSqrArtSpecz921";

    localStorage.setItem(value35Save921, sQz921);
};

function square922(){

    var sQz922 = document.getElementById("imgSqrs922").src;

    value35Save922 = "zSqrArtSpecz922";

    localStorage.setItem(value35Save922, sQz922);
};

function square923(){

    var sQz923 = document.getElementById("imgSqrs923").src;

    value35Save923 = "zSqrArtSpecz923";

    localStorage.setItem(value35Save923, sQz923);
};

function square924(){

    var sQz924 = document.getElementById("imgSqrs924").src;

    value35Save924 = "zSqrArtSpecz924";

    localStorage.setItem(value35Save924, sQz924);
};

function square925(){

    var sQz925 = document.getElementById("imgSqrs925").src;

    value35Save925 = "zSqrArtSpecz925";

    localStorage.setItem(value35Save925, sQz925);
};

function square926(){

    var sQz926 = document.getElementById("imgSqrs926").src;

    value35Save926 = "zSqrArtSpecz926";

    localStorage.setItem(value35Save926, sQz926);
};

function square927(){

    var sQz927 = document.getElementById("imgSqrs927").src;

    value35Save927 = "zSqrArtSpecz927";

    localStorage.setItem(value35Save927, sQz927);
};

function square928(){

    var sQz928 = document.getElementById("imgSqrs928").src;

    value35Save928 = "zSqrArtSpecz928";

    localStorage.setItem(value35Save928, sQz928);
};

function square929(){

    var sQz929 = document.getElementById("imgSqrs929").src;

    value35Save929 = "zSqrArtSpecz929";

    localStorage.setItem(value35Save929, sQz929);
};

function square930(){

    var sQz930 = document.getElementById("imgSqrs930").src;

    value35Save930 = "zSqrArtSpecz930";

    localStorage.setItem(value35Save930, sQz930);
};

function square931(){

    var sQz931 = document.getElementById("imgSqrs931").src;

    value35Save931 = "zSqrArtSpecz931";

    localStorage.setItem(value35Save931, sQz931);
};

function square932(){

    var sQz932 = document.getElementById("imgSqrs932").src;

    value35Save932 = "zSqrArtSpecz932";

    localStorage.setItem(value35Save932, sQz932);
};

function square933(){

    var sQz933 = document.getElementById("imgSqrs933").src;

    value35Save933 = "zSqrArtSpecz933";

    localStorage.setItem(value35Save933, sQz933);
};

function square934(){

    var sQz934 = document.getElementById("imgSqrs934").src;

    value35Save934 = "zSqrArtSpecz934";

    localStorage.setItem(value35Save934, sQz934);
};

function square935(){

    var sQz935 = document.getElementById("imgSqrs935").src;

    value35Save935 = "zSqrArtSpecz935";

    localStorage.setItem(value35Save935, sQz935);
};

function square936(){

    var sQz936 = document.getElementById("imgSqrs936").src;

    value35Save936 = "zSqrArtSpecz936";

    localStorage.setItem(value35Save936, sQz936);
};

function square937(){

    var sQz937 = document.getElementById("imgSqrs937").src;

    value35Save937 = "zSqrArtSpecz937";

    localStorage.setItem(value35Save937, sQz937);
};

function square938(){

    var sQz938 = document.getElementById("imgSqrs938").src;

    value35Save938 = "zSqrArtSpecz938";

    localStorage.setItem(value35Save938, sQz938);
};

function square939(){

    var sQz939 = document.getElementById("imgSqrs939").src;

    value35Save939 = "zSqrArtSpecz939";

    localStorage.setItem(value35Save939, sQz939);
};

function square940(){

    var sQz940 = document.getElementById("imgSqrs940").src;

    value35Save940 = "zSqrArtSpecz940";

    localStorage.setItem(value35Save940, sQz940);
};

function square941(){

    var sQz941 = document.getElementById("imgSqrs941").src;

    value35Save941 = "zSqrArtSpecz941";

    localStorage.setItem(value35Save941, sQz941);
};

function square942(){

    var sQz942 = document.getElementById("imgSqrs942").src;

    value35Save942 = "zSqrArtSpecz942";

    localStorage.setItem(value35Save942, sQz942);
};

function square943(){

    var sQz943 = document.getElementById("imgSqrs943").src;

    value35Save943 = "zSqrArtSpecz943";

    localStorage.setItem(value35Save943, sQz943);
};

function square944(){

    var sQz944 = document.getElementById("imgSqrs944").src;

    value35Save944 = "zSqrArtSpecz944";

    localStorage.setItem(value35Save944, sQz944);
};

function square945(){

    var sQz945 = document.getElementById("imgSqrs945").src;

    value35Save945 = "zSqrArtSpecz945";

    localStorage.setItem(value35Save945, sQz945);
};

function square946(){

    var sQz946 = document.getElementById("imgSqrs946").src;

    value35Save946 = "zSqrArtSpecz946";

    localStorage.setItem(value35Save946, sQz946);
};

function square947(){

    var sQz947 = document.getElementById("imgSqrs947").src;

    value35Save947 = "zSqrArtSpecz947";

    localStorage.setItem(value35Save947, sQz947);
};

function square948(){

    var sQz948 = document.getElementById("imgSqrs948").src;

    value35Save948 = "zSqrArtSpecz948";

    localStorage.setItem(value35Save948, sQz948);
};

function square949(){

    var sQz949 = document.getElementById("imgSqrs949").src;

    value35Save949 = "zSqrArtSpecz949";

    localStorage.setItem(value35Save949, sQz949);
};

function square950(){

    var sQz950 = document.getElementById("imgSqrs950").src;

    value35Save950 = "zSqrArtSpecz950";

    localStorage.setItem(value35Save950, sQz950);
};

function square951(){

    var sQz951 = document.getElementById("imgSqrs951").src;

    value35Save951 = "zSqrArtSpecz951";

    localStorage.setItem(value35Save951, sQz951);
};

function square952(){

    var sQz952 = document.getElementById("imgSqrs952").src;

    value35Save952 = "zSqrArtSpecz952";

    localStorage.setItem(value35Save952, sQz952);
};

function square953(){

    var sQz953 = document.getElementById("imgSqrs953").src;

    value35Save953 = "zSqrArtSpecz953";

    localStorage.setItem(value35Save953, sQz953);
};

function square954(){

    var sQz954 = document.getElementById("imgSqrs954").src;

    value35Save954 = "zSqrArtSpecz954";

    localStorage.setItem(value35Save954, sQz954);
};

function square955(){

    var sQz955 = document.getElementById("imgSqrs955").src;

    value35Save955 = "zSqrArtSpecz955";

    localStorage.setItem(value35Save955, sQz955);
};

function square956(){

    var sQz956 = document.getElementById("imgSqrs956").src;

    value35Save956 = "zSqrArtSpecz956";

    localStorage.setItem(value35Save956, sQz956);
};

function square957(){

    var sQz957 = document.getElementById("imgSqrs957").src;

    value35Save957 = "zSqrArtSpecz957";

    localStorage.setItem(value35Save957, sQz957);
};

function square958(){

    var sQz958 = document.getElementById("imgSqrs958").src;

    value35Save958 = "zSqrArtSpecz958";

    localStorage.setItem(value35Save958, sQz958);
};

function square959(){

    var sQz959 = document.getElementById("imgSqrs959").src;

    value35Save959 = "zSqrArtSpecz959";

    localStorage.setItem(value35Save959, sQz959);
};

function square960(){

    var sQz960 = document.getElementById("imgSqrs960").src;

    value35Save960 = "zSqrArtSpecz960";

    localStorage.setItem(value35Save960, sQz960);
};

function square961(){

    var sQz961 = document.getElementById("imgSqrs961").src;

    value35Save961 = "zSqrArtSpecz961";

    localStorage.setItem(value35Save961, sQz961);
};

function square962(){

    var sQz962 = document.getElementById("imgSqrs962").src;

    value35Save962 = "zSqrArtSpecz962";

    localStorage.setItem(value35Save962, sQz962);
};

function square963(){

    var sQz963 = document.getElementById("imgSqrs963").src;

    value35Save963 = "zSqrArtSpecz963";

    localStorage.setItem(value35Save963, sQz963);
};

function square964(){

    var sQz964 = document.getElementById("imgSqrs964").src;

    value35Save964 = "zSqrArtSpecz964";

    localStorage.setItem(value35Save964, sQz964);
};

function square965(){

    var sQz965 = document.getElementById("imgSqrs965").src;

    value35Save965 = "zSqrArtSpecz965";

    localStorage.setItem(value35Save965, sQz965);
};

function square966(){

    var sQz966 = document.getElementById("imgSqrs966").src;

    value35Save966 = "zSqrArtSpecz966";

    localStorage.setItem(value35Save966, sQz966);
};

function square967(){

    var sQz967 = document.getElementById("imgSqrs967").src;

    value35Save967 = "zSqrArtSpecz967";

    localStorage.setItem(value35Save967, sQz967);
};

function square968(){

    var sQz968 = document.getElementById("imgSqrs968").src;

    value35Save968 = "zSqrArtSpecz968";

    localStorage.setItem(value35Save968, sQz968);
};

function square969(){

    var sQz969 = document.getElementById("imgSqrs969").src;

    value35Save969 = "zSqrArtSpecz969";

    localStorage.setItem(value35Save969, sQz969);
};

function square970(){

    var sQz970 = document.getElementById("imgSqrs970").src;

    value35Save970 = "zSqrArtSpecz970";

    localStorage.setItem(value35Save970, sQz970);
};

function square971(){

    var sQz971 = document.getElementById("imgSqrs971").src;

    value35Save971 = "zSqrArtSpecz971";

    localStorage.setItem(value35Save971, sQz971);
};

function square972(){

    var sQz972 = document.getElementById("imgSqrs972").src;

    value35Save972 = "zSqrArtSpecz972";

    localStorage.setItem(value35Save972, sQz972);
};

function square973(){

    var sQz973 = document.getElementById("imgSqrs973").src;

    value35Save973 = "zSqrArtSpecz973";

    localStorage.setItem(value35Save973, sQz973);
};

function square974(){

    var sQz974 = document.getElementById("imgSqrs974").src;

    value35Save974 = "zSqrArtSpecz974";

    localStorage.setItem(value35Save974, sQz974);
};

function square975(){

    var sQz975 = document.getElementById("imgSqrs975").src;

    value35Save975 = "zSqrArtSpecz975";

    localStorage.setItem(value35Save975, sQz975);
};

function square976(){

    var sQz976 = document.getElementById("imgSqrs976").src;

    value35Save976 = "zSqrArtSpecz976";

    localStorage.setItem(value35Save976, sQz976);
};

function square977(){

    var sQz977 = document.getElementById("imgSqrs977").src;

    value35Save977 = "zSqrArtSpecz977";

    localStorage.setItem(value35Save977, sQz977);
};

function square978(){

    var sQz978 = document.getElementById("imgSqrs978").src;

    value35Save978 = "zSqrArtSpecz978";

    localStorage.setItem(value35Save978, sQz978);
};

function square979(){

    var sQz979 = document.getElementById("imgSqrs979").src;

    value35Save979 = "zSqrArtSpecz979";

    localStorage.setItem(value35Save979, sQz979);
};

function square980(){

    var sQz980 = document.getElementById("imgSqrs980").src;

    value35Save980 = "zSqrArtSpecz980";

    localStorage.setItem(value35Save980, sQz980);
};

function square981(){

    var sQz981 = document.getElementById("imgSqrs981").src;

    value35Save981 = "zSqrArtSpecz981";

    localStorage.setItem(value35Save981, sQz981);
};

function square982(){

    var sQz982 = document.getElementById("imgSqrs982").src;

    value35Save982 = "zSqrArtSpecz982";

    localStorage.setItem(value35Save982, sQz982);
};

function square983(){

    var sQz983 = document.getElementById("imgSqrs983").src;

    value35Save983 = "zSqrArtSpecz983";

    localStorage.setItem(value35Save983, sQz983);
};

function square984(){

    var sQz984 = document.getElementById("imgSqrs984").src;

    value35Save984 = "zSqrArtSpecz984";

    localStorage.setItem(value35Save984, sQz984);
};

function square985(){

    var sQz985 = document.getElementById("imgSqrs985").src;

    value35Save985 = "zSqrArtSpecz985";

    localStorage.setItem(value35Save985, sQz985);
};

function square986(){

    var sQz986 = document.getElementById("imgSqrs986").src;

    value35Save986 = "zSqrArtSpecz986";

    localStorage.setItem(value35Save986, sQz986);
};

function square987(){

    var sQz987 = document.getElementById("imgSqrs987").src;

    value35Save987 = "zSqrArtSpecz987";

    localStorage.setItem(value35Save987, sQz987);
};

function square988(){

    var sQz988 = document.getElementById("imgSqrs988").src;

    value35Save988 = "zSqrArtSpecz988";

    localStorage.setItem(value35Save988, sQz988);
};

function square989(){

    var sQz989 = document.getElementById("imgSqrs989").src;

    value35Save989 = "zSqrArtSpecz989";

    localStorage.setItem(value35Save989, sQz989);
};

function square990(){

    var sQz990 = document.getElementById("imgSqrs990").src;

    value35Save990 = "zSqrArtSpecz990";

    localStorage.setItem(value35Save990, sQz990);
};

function square991(){

    var sQz991 = document.getElementById("imgSqrs991").src;

    value35Save991 = "zSqrArtSpecz991";

    localStorage.setItem(value35Save991, sQz991);
};

function square992(){

    var sQz992 = document.getElementById("imgSqrs992").src;

    value35Save992 = "zSqrArtSpecz992";

    localStorage.setItem(value35Save992, sQz992);
};

function square993(){

    var sQz993 = document.getElementById("imgSqrs993").src;

    value35Save993 = "zSqrArtSpecz993";

    localStorage.setItem(value35Save993, sQz993);
};

function square994(){

    var sQz994 = document.getElementById("imgSqrs994").src;

    value35Save994 = "zSqrArtSpecz994";

    localStorage.setItem(value35Save994, sQz994);
};

function square995(){

    var sQz995 = document.getElementById("imgSqrs995").src;

    value35Save995 = "zSqrArtSpecz995";

    localStorage.setItem(value35Save995, sQz995);
};

function square996(){

    var sQz996 = document.getElementById("imgSqrs996").src;

    value35Save996 = "zSqrArtSpecz996";

    localStorage.setItem(value35Save996, sQz996);
};

function square997(){

    var sQz997 = document.getElementById("imgSqrs997").src;

    value35Save997 = "zSqrArtSpecz997";

    localStorage.setItem(value35Save997, sQz997);
};

function square998(){

    var sQz998 = document.getElementById("imgSqrs998").src;

    value35Save998 = "zSqrArtSpecz998";

    localStorage.setItem(value35Save998, sQz998);
};

function square999(){

    var sQz999 = document.getElementById("imgSqrs999").src;

    value35Save999 = "zSqrArtSpecz999";

    localStorage.setItem(value35Save999, sQz999);
};

function square1000(){

    var sQz1000 = document.getElementById("imgSqrs1000").src;

    value35Save1000 = "zSqrArtSpecz1000";

    localStorage.setItem(value35Save1000, sQz1000);
};

function square1001(){

    var sQz1001 = document.getElementById("imgSqrs1001").src;

    value35Save1001 = "zSqrArtSpecz1001";

    localStorage.setItem(value35Save1001, sQz1001);
};

function square1002(){

    var sQz1002 = document.getElementById("imgSqrs1002").src;

    value35Save1002 = "zSqrArtSpecz1002";

    localStorage.setItem(value35Save1002, sQz1002);
};

function square1003(){

    var sQz1003 = document.getElementById("imgSqrs1003").src;

    value35Save1003 = "zSqrArtSpecz1003";

    localStorage.setItem(value35Save1003, sQz1003);
};

function square1004(){

    var sQz1004 = document.getElementById("imgSqrs1004").src;

    value35Save1004 = "zSqrArtSpecz1004";

    localStorage.setItem(value35Save1004, sQz1004);
};

function square1005(){

    var sQz1005 = document.getElementById("imgSqrs1005").src;

    value35Save1005 = "zSqrArtSpecz1005";

    localStorage.setItem(value35Save1005, sQz1005);
};

function square1006(){

    var sQz1006 = document.getElementById("imgSqrs1006").src;

    value35Save1006 = "zSqrArtSpecz1006";

    localStorage.setItem(value35Save1006, sQz1006);
};

function square1007(){

    var sQz1007 = document.getElementById("imgSqrs1007").src;

    value35Save1007 = "zSqrArtSpecz1007";

    localStorage.setItem(value35Save1007, sQz1007);
};

function square1008(){

    var sQz1008 = document.getElementById("imgSqrs1008").src;

    value35Save1008 = "zSqrArtSpecz1008";

    localStorage.setItem(value35Save1008, sQz1008);
};

function square1009(){

    var sQz1009 = document.getElementById("imgSqrs1009").src;

    value35Save1009 = "zSqrArtSpecz1009";

    localStorage.setItem(value35Save1009, sQz1009);
};

function square1010(){

    var sQz1010 = document.getElementById("imgSqrs1010").src;

    value35Save1010 = "zSqrArtSpecz1010";

    localStorage.setItem(value35Save1010, sQz1010);
};

function square1011(){

    var sQz1011 = document.getElementById("imgSqrs1011").src;

    value35Save1011 = "zSqrArtSpecz1011";

    localStorage.setItem(value35Save1011, sQz1011);
};

function square1012(){

    var sQz1012 = document.getElementById("imgSqrs1012").src;

    value35Save1012 = "zSqrArtSpecz1012";

    localStorage.setItem(value35Save1012, sQz1012);
};

function square1013(){

    var sQz1013 = document.getElementById("imgSqrs1013").src;

    value35Save1013 = "zSqrArtSpecz1013";

    localStorage.setItem(value35Save1013, sQz1013);
};

function square1014(){

    var sQz1014 = document.getElementById("imgSqrs1014").src;

    value35Save1014 = "zSqrArtSpecz1014";

    localStorage.setItem(value35Save1014, sQz1014);
};

function square1015(){

    var sQz1015 = document.getElementById("imgSqrs1015").src;

    value35Save1015 = "zSqrArtSpecz1015";

    localStorage.setItem(value35Save1015, sQz1015);
};

function square1016(){

    var sQz1016 = document.getElementById("imgSqrs1016").src;

    value35Save1016 = "zSqrArtSpecz1016";

    localStorage.setItem(value35Save1016, sQz1016);
};

function square1017(){

    var sQz1017 = document.getElementById("imgSqrs1017").src;

    value35Save1017 = "zSqrArtSpecz1017";

    localStorage.setItem(value35Save1017, sQz1017);
};

function square1018(){

    var sQz1018 = document.getElementById("imgSqrs1018").src;

    value35Save1018 = "zSqrArtSpecz1018";

    localStorage.setItem(value35Save1018, sQz1018);
};

function square1019(){

    var sQz1019 = document.getElementById("imgSqrs1019").src;

    value35Save1019 = "zSqrArtSpecz1019";

    localStorage.setItem(value35Save1019, sQz1019);
};

function square1020(){

    var sQz1020 = document.getElementById("imgSqrs1020").src;

    value35Save1020 = "zSqrArtSpecz1020";

    localStorage.setItem(value35Save1020, sQz1020);
};

function square1021(){

    var sQz1021 = document.getElementById("imgSqrs1021").src;

    value35Save1021 = "zSqrArtSpecz1021";

    localStorage.setItem(value35Save1021, sQz1021);
};

function square1022(){

    var sQz1022 = document.getElementById("imgSqrs1022").src;

    value35Save1022 = "zSqrArtSpecz1022";

    localStorage.setItem(value35Save1022, sQz1022);
};

function square1023(){

    var sQz1023 = document.getElementById("imgSqrs1023").src;

    value35Save1023 = "zSqrArtSpecz1023";

    localStorage.setItem(value35Save1023, sQz1023);
};

function square1024(){

    var sQz1024 = document.getElementById("imgSqrs1024").src;

    value35Save1024 = "zSqrArtSpecz1024";

    localStorage.setItem(value35Save1024, sQz1024);
};

function square1025(){

    var sQz1025 = document.getElementById("imgSqrs1025").src;

    value35Save1025 = "zSqrArtSpecz1025";

    localStorage.setItem(value35Save1025, sQz1025);
};

function square1026(){

    var sQz1026 = document.getElementById("imgSqrs1026").src;

    value35Save1026 = "zSqrArtSpecz1026";

    localStorage.setItem(value35Save1026, sQz1026);
};

function square1027(){

    var sQz1027 = document.getElementById("imgSqrs1027").src;

    value35Save1027 = "zSqrArtSpecz1027";

    localStorage.setItem(value35Save1027, sQz1027);
};

function square1028(){

    var sQz1028 = document.getElementById("imgSqrs1028").src;

    value35Save1028 = "zSqrArtSpecz1028";

    localStorage.setItem(value35Save1028, sQz1028);
};

function square1029(){

    var sQz1029 = document.getElementById("imgSqrs1029").src;

    value35Save1029 = "zSqrArtSpecz1029";

    localStorage.setItem(value35Save1029, sQz1029);
};

function square1030(){

    var sQz1030 = document.getElementById("imgSqrs1030").src;

    value35Save1030 = "zSqrArtSpecz1030";

    localStorage.setItem(value35Save1030, sQz1030);
};

function square1031(){

    var sQz1031 = document.getElementById("imgSqrs1031").src;

    value35Save1031 = "zSqrArtSpecz1031";

    localStorage.setItem(value35Save1031, sQz1031);
};

function square1032(){

    var sQz1032 = document.getElementById("imgSqrs1032").src;

    value35Save1032 = "zSqrArtSpecz1032";

    localStorage.setItem(value35Save1032, sQz1032);
};

function square1033(){

    var sQz1033 = document.getElementById("imgSqrs1033").src;

    value35Save1033 = "zSqrArtSpecz1033";

    localStorage.setItem(value35Save1033, sQz1033);
};

function square1034(){

    var sQz1034 = document.getElementById("imgSqrs1034").src;

    value35Save1034 = "zSqrArtSpecz1034";

    localStorage.setItem(value35Save1034, sQz1034);
};

function square1035(){

    var sQz1035 = document.getElementById("imgSqrs1035").src;

    value35Save1035 = "zSqrArtSpecz1035";

    localStorage.setItem(value35Save1035, sQz1035);
};

function square1036(){

    var sQz1036 = document.getElementById("imgSqrs1036").src;

    value35Save1036 = "zSqrArtSpecz1036";

    localStorage.setItem(value35Save1036, sQz1036);
};

function square1037(){

    var sQz1037 = document.getElementById("imgSqrs1037").src;

    value35Save1037 = "zSqrArtSpecz1037";

    localStorage.setItem(value35Save1037, sQz1037);
};

function square1038(){

    var sQz1038 = document.getElementById("imgSqrs1038").src;

    value35Save1038 = "zSqrArtSpecz1038";

    localStorage.setItem(value35Save1038, sQz1038);
};

function square1039(){

    var sQz1039 = document.getElementById("imgSqrs1039").src;

    value35Save1039 = "zSqrArtSpecz1039";

    localStorage.setItem(value35Save1039, sQz1039);
};

function square1040(){

    var sQz1040 = document.getElementById("imgSqrs1040").src;

    value35Save1040 = "zSqrArtSpecz1040";

    localStorage.setItem(value35Save1040, sQz1040);
};

function square1041(){

    var sQz1041 = document.getElementById("imgSqrs1041").src;

    value35Save1041 = "zSqrArtSpecz1041";

    localStorage.setItem(value35Save1041, sQz1041);
};

function square1042(){

    var sQz1042 = document.getElementById("imgSqrs1042").src;

    value35Save1042 = "zSqrArtSpecz1042";

    localStorage.setItem(value35Save1042, sQz1042);
};

function square1043(){

    var sQz1043 = document.getElementById("imgSqrs1043").src;

    value35Save1043 = "zSqrArtSpecz1043";

    localStorage.setItem(value35Save1043, sQz1043);
};

function square1044(){

    var sQz1044 = document.getElementById("imgSqrs1044").src;

    value35Save1044 = "zSqrArtSpecz1044";

    localStorage.setItem(value35Save1044, sQz1044);
};

function square1045(){

    var sQz1045 = document.getElementById("imgSqrs1045").src;

    value35Save1045 = "zSqrArtSpecz1045";

    localStorage.setItem(value35Save1045, sQz1045);
};

function square1046(){

    var sQz1046 = document.getElementById("imgSqrs1046").src;

    value35Save1046 = "zSqrArtSpecz1046";

    localStorage.setItem(value35Save1046, sQz1046);
};

function square1047(){

    var sQz1047 = document.getElementById("imgSqrs1047").src;

    value35Save1047 = "zSqrArtSpecz1047";

    localStorage.setItem(value35Save1047, sQz1047);
};

function square1048(){

    var sQz1048 = document.getElementById("imgSqrs1048").src;

    value35Save1048 = "zSqrArtSpecz1048";

    localStorage.setItem(value35Save1048, sQz1048);
};

function square1049(){

    var sQz1049 = document.getElementById("imgSqrs1049").src;

    value35Save1049 = "zSqrArtSpecz1049";

    localStorage.setItem(value35Save1049, sQz1049);
};

function square1050(){

    var sQz1050 = document.getElementById("imgSqrs1050").src;

    value35Save1050 = "zSqrArtSpecz1050";

    localStorage.setItem(value35Save1050, sQz1050);
};

function square1051(){

    var sQz1051 = document.getElementById("imgSqrs1051").src;

    value35Save1051 = "zSqrArtSpecz1051";

    localStorage.setItem(value35Save1051, sQz1051);
};

function square1052(){

    var sQz1052 = document.getElementById("imgSqrs1052").src;

    value35Save1052 = "zSqrArtSpecz1052";

    localStorage.setItem(value35Save1052, sQz1052);
};

function square1053(){

    var sQz1053 = document.getElementById("imgSqrs1053").src;

    value35Save1053 = "zSqrArtSpecz1053";

    localStorage.setItem(value35Save1053, sQz1053);
};

function square1054(){

    var sQz1054 = document.getElementById("imgSqrs1054").src;

    value35Save1054 = "zSqrArtSpecz1054";

    localStorage.setItem(value35Save1054, sQz1054);
};

function square1055(){

    var sQz1055 = document.getElementById("imgSqrs1055").src;

    value35Save1055 = "zSqrArtSpecz1055";

    localStorage.setItem(value35Save1055, sQz1055);
};

function square1056(){

    var sQz1056 = document.getElementById("imgSqrs1056").src;

    value35Save1056 = "zSqrArtSpecz1056";

    localStorage.setItem(value35Save1056, sQz1056);
};

function square1057(){

    var sQz1057 = document.getElementById("imgSqrs1057").src;

    value35Save1057 = "zSqrArtSpecz1057";

    localStorage.setItem(value35Save1057, sQz1057);
};

function square1058(){

    var sQz1058 = document.getElementById("imgSqrs1058").src;

    value35Save1058 = "zSqrArtSpecz1058";

    localStorage.setItem(value35Save1058, sQz1058);
};

function square1059(){

    var sQz1059 = document.getElementById("imgSqrs1059").src;

    value35Save1059 = "zSqrArtSpecz1059";

    localStorage.setItem(value35Save1059, sQz1059);
};

function square1060(){

    var sQz1060 = document.getElementById("imgSqrs1060").src;

    value35Save1060 = "zSqrArtSpecz1060";

    localStorage.setItem(value35Save1060, sQz1060);
};

function square1061(){

    var sQz1061 = document.getElementById("imgSqrs1061").src;

    value35Save1061 = "zSqrArtSpecz1061";

    localStorage.setItem(value35Save1061, sQz1061);
};

function square1062(){

    var sQz1062 = document.getElementById("imgSqrs1062").src;

    value35Save1062 = "zSqrArtSpecz1062";

    localStorage.setItem(value35Save1062, sQz1062);
};

function square1063(){

    var sQz1063 = document.getElementById("imgSqrs1063").src;

    value35Save1063 = "zSqrArtSpecz1063";

    localStorage.setItem(value35Save1063, sQz1063);
};

function square1064(){

    var sQz1064 = document.getElementById("imgSqrs1064").src;

    value35Save1064 = "zSqrArtSpecz1064";

    localStorage.setItem(value35Save1064, sQz1064);
};

function square1065(){

    var sQz1065 = document.getElementById("imgSqrs1065").src;

    value35Save1065 = "zSqrArtSpecz1065";

    localStorage.setItem(value35Save1065, sQz1065);
};

function square1066(){

    var sQz1066 = document.getElementById("imgSqrs1066").src;

    value35Save1066 = "zSqrArtSpecz1066";

    localStorage.setItem(value35Save1066, sQz1066);
};

function square1067(){

    var sQz1067 = document.getElementById("imgSqrs1067").src;

    value35Save1067 = "zSqrArtSpecz1067";

    localStorage.setItem(value35Save1067, sQz1067);
};

function square1068(){

    var sQz1068 = document.getElementById("imgSqrs1068").src;

    value35Save1068 = "zSqrArtSpecz1068";

    localStorage.setItem(value35Save1068, sQz1068);
};

function square1069(){

    var sQz1069 = document.getElementById("imgSqrs1069").src;

    value35Save1069 = "zSqrArtSpecz1069";

    localStorage.setItem(value35Save1069, sQz1069);
};

function square1070(){

    var sQz1070 = document.getElementById("imgSqrs1070").src;

    value35Save1070 = "zSqrArtSpecz1070";

    localStorage.setItem(value35Save1070, sQz1070);
};

function square1071(){

    var sQz1071 = document.getElementById("imgSqrs1071").src;

    value35Save1071 = "zSqrArtSpecz1071";

    localStorage.setItem(value35Save1071, sQz1071);
};

function square1072(){

    var sQz1072 = document.getElementById("imgSqrs1072").src;

    value35Save1072 = "zSqrArtSpecz1072";

    localStorage.setItem(value35Save1072, sQz1072);
};

function square1073(){

    var sQz1073 = document.getElementById("imgSqrs1073").src;

    value35Save1073 = "zSqrArtSpecz1073";

    localStorage.setItem(value35Save1073, sQz1073);
};

function square1074(){

    var sQz1074 = document.getElementById("imgSqrs1074").src;

    value35Save1074 = "zSqrArtSpecz1074";

    localStorage.setItem(value35Save1074, sQz1074);
};

function square1075(){

    var sQz1075 = document.getElementById("imgSqrs1075").src;

    value35Save1075 = "zSqrArtSpecz1075";

    localStorage.setItem(value35Save1075, sQz1075);
};

function square1076(){

    var sQz1076 = document.getElementById("imgSqrs1076").src;

    value35Save1076 = "zSqrArtSpecz1076";

    localStorage.setItem(value35Save1076, sQz1076);
};

function square1077(){

    var sQz1077 = document.getElementById("imgSqrs1077").src;

    value35Save1077 = "zSqrArtSpecz1077";

    localStorage.setItem(value35Save1077, sQz1077);
};

function square1078(){

    var sQz1078 = document.getElementById("imgSqrs1078").src;

    value35Save1078 = "zSqrArtSpecz1078";

    localStorage.setItem(value35Save1078, sQz1078);
};

function square1079(){

    var sQz1079 = document.getElementById("imgSqrs1079").src;

    value35Save1079 = "zSqrArtSpecz1079";

    localStorage.setItem(value35Save1079, sQz1079);
};

function square1080(){

    var sQz1080 = document.getElementById("imgSqrs1080").src;

    value35Save1080 = "zSqrArtSpecz1080";

    localStorage.setItem(value35Save1080, sQz1080);
};

function square1081(){

    var sQz1081 = document.getElementById("imgSqrs1081").src;

    value35Save1081 = "zSqrArtSpecz1081";

    localStorage.setItem(value35Save1081, sQz1081);
};

function square1082(){

    var sQz1082 = document.getElementById("imgSqrs1082").src;

    value35Save1082 = "zSqrArtSpecz1082";

    localStorage.setItem(value35Save1082, sQz1082);
};

function square1083(){

    var sQz1083 = document.getElementById("imgSqrs1083").src;

    value35Save1083 = "zSqrArtSpecz1083";

    localStorage.setItem(value35Save1083, sQz1083);
};

function square1084(){

    var sQz1084 = document.getElementById("imgSqrs1084").src;

    value35Save1084 = "zSqrArtSpecz1084";

    localStorage.setItem(value35Save1084, sQz1084);
};

function square1085(){

    var sQz1085 = document.getElementById("imgSqrs1085").src;

    value35Save1085 = "zSqrArtSpecz1085";

    localStorage.setItem(value35Save1085, sQz1085);
};

function square1086(){

    var sQz1086 = document.getElementById("imgSqrs1086").src;

    value35Save1086 = "zSqrArtSpecz1086";

    localStorage.setItem(value35Save1086, sQz1086);
};

function square1087(){

    var sQz1087 = document.getElementById("imgSqrs1087").src;

    value35Save1087 = "zSqrArtSpecz1087";

    localStorage.setItem(value35Save1087, sQz1087);
};

function square1088(){

    var sQz1088 = document.getElementById("imgSqrs1088").src;

    value35Save1088 = "zSqrArtSpecz1088";

    localStorage.setItem(value35Save1088, sQz1088);
};

function square1089(){

    var sQz1089 = document.getElementById("imgSqrs1089").src;

    value35Save1089 = "zSqrArtSpecz1089";

    localStorage.setItem(value35Save1089, sQz1089);
};

function square1090(){

    var sQz1090 = document.getElementById("imgSqrs1090").src;

    value35Save1090 = "zSqrArtSpecz1090";

    localStorage.setItem(value35Save1090, sQz1090);
};

function square1091(){

    var sQz1091 = document.getElementById("imgSqrs1091").src;

    value35Save1091 = "zSqrArtSpecz1091";

    localStorage.setItem(value35Save1091, sQz1091);
};

function square1092(){

    var sQz1092 = document.getElementById("imgSqrs1092").src;

    value35Save1092 = "zSqrArtSpecz1092";

    localStorage.setItem(value35Save1092, sQz1092);
};

function square1093(){

    var sQz1093 = document.getElementById("imgSqrs1093").src;

    value35Save1093 = "zSqrArtSpecz1093";

    localStorage.setItem(value35Save1093, sQz1093);
};

function square1094(){

    var sQz1094 = document.getElementById("imgSqrs1094").src;

    value35Save1094 = "zSqrArtSpecz1094";

    localStorage.setItem(value35Save1094, sQz1094);
};

function square1095(){

    var sQz1095 = document.getElementById("imgSqrs1095").src;

    value35Save1095 = "zSqrArtSpecz1095";

    localStorage.setItem(value35Save1095, sQz1095);
};

function square1096(){

    var sQz1096 = document.getElementById("imgSqrs1096").src;

    value35Save1096 = "zSqrArtSpecz1096";

    localStorage.setItem(value35Save1096, sQz1096);
};

function square1097(){

    var sQz1097 = document.getElementById("imgSqrs1097").src;

    value35Save1097 = "zSqrArtSpecz1097";

    localStorage.setItem(value35Save1097, sQz1097);
};

function square1098(){

    var sQz1098 = document.getElementById("imgSqrs1098").src;

    value35Save1098 = "zSqrArtSpecz1098";

    localStorage.setItem(value35Save1098, sQz1098);
};

function square1099(){

    var sQz1099 = document.getElementById("imgSqrs1099").src;

    value35Save1099 = "zSqrArtSpecz1099";

    localStorage.setItem(value35Save1099, sQz1099);
};

function square1100(){

    var sQz1100 = document.getElementById("imgSqrs1100").src;

    value35Save1100 = "zSqrArtSpecz1100";

    localStorage.setItem(value35Save1100, sQz1100);
};

function square1101(){

    var sQz1101 = document.getElementById("imgSqrs1101").src;

    value35Save1101 = "zSqrArtSpecz1101";

    localStorage.setItem(value35Save1101, sQz1101);
};

function square1102(){

    var sQz1102 = document.getElementById("imgSqrs1102").src;

    value35Save1102 = "zSqrArtSpecz1102";

    localStorage.setItem(value35Save1102, sQz1102);
};

function square1103(){

    var sQz1103 = document.getElementById("imgSqrs1103").src;

    value35Save1103 = "zSqrArtSpecz1103";

    localStorage.setItem(value35Save1103, sQz1103);
};

function square1104(){

    var sQz1104 = document.getElementById("imgSqrs1104").src;

    value35Save1104 = "zSqrArtSpecz1104";

    localStorage.setItem(value35Save1104, sQz1104);
};

function square1105(){

    var sQz1105 = document.getElementById("imgSqrs1105").src;

    value35Save1105 = "zSqrArtSpecz1105";

    localStorage.setItem(value35Save1105, sQz1105);
};

function square1106(){

    var sQz1106 = document.getElementById("imgSqrs1106").src;

    value35Save1106 = "zSqrArtSpecz1106";

    localStorage.setItem(value35Save1106, sQz1106);
};

function square1107(){

    var sQz1107 = document.getElementById("imgSqrs1107").src;

    value35Save1107 = "zSqrArtSpecz1107";

    localStorage.setItem(value35Save1107, sQz1107);
};

function square1108(){

    var sQz1108 = document.getElementById("imgSqrs1108").src;

    value35Save1108 = "zSqrArtSpecz1108";

    localStorage.setItem(value35Save1108, sQz1108);
};

function square1109(){

    var sQz1109 = document.getElementById("imgSqrs1109").src;

    value35Save1109 = "zSqrArtSpecz1109";

    localStorage.setItem(value35Save1109, sQz1109);
};

function square1110(){

    var sQz1110 = document.getElementById("imgSqrs1110").src;

    value35Save1110 = "zSqrArtSpecz1110";

    localStorage.setItem(value35Save1110, sQz1110);
};

function square1111(){

    var sQz1111 = document.getElementById("imgSqrs1111").src;

    value35Save1111 = "zSqrArtSpecz1111";

    localStorage.setItem(value35Save1111, sQz1111);
};

function square1112(){

    var sQz1112 = document.getElementById("imgSqrs1112").src;

    value35Save1112 = "zSqrArtSpecz1112";

    localStorage.setItem(value35Save1112, sQz1112);
};

function square1113(){

    var sQz1113 = document.getElementById("imgSqrs1113").src;

    value35Save1113 = "zSqrArtSpecz1113";

    localStorage.setItem(value35Save1113, sQz1113);
};

function square1114(){

    var sQz1114 = document.getElementById("imgSqrs1114").src;

    value35Save1114 = "zSqrArtSpecz1114";

    localStorage.setItem(value35Save1114, sQz1114);
};

function square1115(){

    var sQz1115 = document.getElementById("imgSqrs1115").src;

    value35Save1115 = "zSqrArtSpecz1115";

    localStorage.setItem(value35Save1115, sQz1115);
};

function square1116(){

    var sQz1116 = document.getElementById("imgSqrs1116").src;

    value35Save1116 = "zSqrArtSpecz1116";

    localStorage.setItem(value35Save1116, sQz1116);
};

function square1117(){

    var sQz1117 = document.getElementById("imgSqrs1117").src;

    value35Save1117 = "zSqrArtSpecz1117";

    localStorage.setItem(value35Save1117, sQz1117);
};

function square1118(){

    var sQz1118 = document.getElementById("imgSqrs1118").src;

    value35Save1118 = "zSqrArtSpecz1118";

    localStorage.setItem(value35Save1118, sQz1118);
};

function square1119(){

    var sQz1119 = document.getElementById("imgSqrs1119").src;

    value35Save1119 = "zSqrArtSpecz1119";

    localStorage.setItem(value35Save1119, sQz1119);
};

function square1120(){

    var sQz1120 = document.getElementById("imgSqrs1120").src;

    value35Save1120 = "zSqrArtSpecz1120";

    localStorage.setItem(value35Save1120, sQz1120);
};

function square1121(){

    var sQz1121 = document.getElementById("imgSqrs1121").src;

    value35Save1121 = "zSqrArtSpecz1121";

    localStorage.setItem(value35Save1121, sQz1121);
};

function square1122(){

    var sQz1122 = document.getElementById("imgSqrs1122").src;

    value35Save1122 = "zSqrArtSpecz1122";

    localStorage.setItem(value35Save1122, sQz1122);
};

function square1123(){

    var sQz1123 = document.getElementById("imgSqrs1123").src;

    value35Save1123 = "zSqrArtSpecz1123";

    localStorage.setItem(value35Save1123, sQz1123);
};

function square1124(){

    var sQz1124 = document.getElementById("imgSqrs1124").src;

    value35Save1124 = "zSqrArtSpecz1124";

    localStorage.setItem(value35Save1124, sQz1124);
};

function square1125(){

    var sQz1125 = document.getElementById("imgSqrs1125").src;

    value35Save1125 = "zSqrArtSpecz1125";

    localStorage.setItem(value35Save1125, sQz1125);
};

function square1126(){

    var sQz1126 = document.getElementById("imgSqrs1126").src;

    value35Save1126 = "zSqrArtSpecz1126";

    localStorage.setItem(value35Save1126, sQz1126);
};

function square1127(){

    var sQz1127 = document.getElementById("imgSqrs1127").src;

    value35Save1127 = "zSqrArtSpecz1127";

    localStorage.setItem(value35Save1127, sQz1127);
};

function square1128(){

    var sQz1128 = document.getElementById("imgSqrs1128").src;

    value35Save1128 = "zSqrArtSpecz1128";

    localStorage.setItem(value35Save1128, sQz1128);
};

function square1129(){

    var sQz1129 = document.getElementById("imgSqrs1129").src;

    value35Save1129 = "zSqrArtSpecz1129";

    localStorage.setItem(value35Save1129, sQz1129);
};

function square1130(){

    var sQz1130 = document.getElementById("imgSqrs1130").src;

    value35Save1130 = "zSqrArtSpecz1130";

    localStorage.setItem(value35Save1130, sQz1130);
};

function square1131(){

    var sQz1131 = document.getElementById("imgSqrs1131").src;

    value35Save1131 = "zSqrArtSpecz1131";

    localStorage.setItem(value35Save1131, sQz1131);
};

function square1132(){

    var sQz1132 = document.getElementById("imgSqrs1132").src;

    value35Save1132 = "zSqrArtSpecz1132";

    localStorage.setItem(value35Save1132, sQz1132);
};

function square1133(){

    var sQz1133 = document.getElementById("imgSqrs1133").src;

    value35Save1133 = "zSqrArtSpecz1133";

    localStorage.setItem(value35Save1133, sQz1133);
};

function square1134(){

    var sQz1134 = document.getElementById("imgSqrs1134").src;

    value35Save1134 = "zSqrArtSpecz1134";

    localStorage.setItem(value35Save1134, sQz1134);
};

function square1135(){

    var sQz1135 = document.getElementById("imgSqrs1135").src;

    value35Save1135 = "zSqrArtSpecz1135";

    localStorage.setItem(value35Save1135, sQz1135);
};

function square1136(){

    var sQz1136 = document.getElementById("imgSqrs1136").src;

    value35Save1136 = "zSqrArtSpecz1136";

    localStorage.setItem(value35Save1136, sQz1136);
};

function square1137(){

    var sQz1137 = document.getElementById("imgSqrs1137").src;

    value35Save1137 = "zSqrArtSpecz1137";

    localStorage.setItem(value35Save1137, sQz1137);
};

function square1138(){

    var sQz1138 = document.getElementById("imgSqrs1138").src;

    value35Save1138 = "zSqrArtSpecz1138";

    localStorage.setItem(value35Save1138, sQz1138);
};

function square1139(){

    var sQz1139 = document.getElementById("imgSqrs1139").src;

    value35Save1139 = "zSqrArtSpecz1139";

    localStorage.setItem(value35Save1139, sQz1139);
};

function square1140(){

    var sQz1140 = document.getElementById("imgSqrs1140").src;

    value35Save1140 = "zSqrArtSpecz1140";

    localStorage.setItem(value35Save1140, sQz1140);
};

function square1141(){

    var sQz1141 = document.getElementById("imgSqrs1141").src;

    value35Save1141 = "zSqrArtSpecz1141";

    localStorage.setItem(value35Save1141, sQz1141);
};

function square1142(){

    var sQz1142 = document.getElementById("imgSqrs1142").src;

    value35Save1142 = "zSqrArtSpecz1142";

    localStorage.setItem(value35Save1142, sQz1142);
};

function square1143(){

    var sQz1143 = document.getElementById("imgSqrs1143").src;

    value35Save1143 = "zSqrArtSpecz1143";

    localStorage.setItem(value35Save1143, sQz1143);
};

function square1144(){

    var sQz1144 = document.getElementById("imgSqrs1144").src;

    value35Save1144 = "zSqrArtSpecz1144";

    localStorage.setItem(value35Save1144, sQz1144);
};

function square1145(){

    var sQz1145 = document.getElementById("imgSqrs1145").src;

    value35Save1145 = "zSqrArtSpecz1145";

    localStorage.setItem(value35Save1145, sQz1145);
};

function square1146(){

    var sQz1146 = document.getElementById("imgSqrs1146").src;

    value35Save1146 = "zSqrArtSpecz1146";

    localStorage.setItem(value35Save1146, sQz1146);
};

function square1147(){

    var sQz1147 = document.getElementById("imgSqrs1147").src;

    value35Save1147 = "zSqrArtSpecz1147";

    localStorage.setItem(value35Save1147, sQz1147);
};

function square1148(){

    var sQz1148 = document.getElementById("imgSqrs1148").src;

    value35Save1148 = "zSqrArtSpecz1148";

    localStorage.setItem(value35Save1148, sQz1148);
};

function square1149(){

    var sQz1149 = document.getElementById("imgSqrs1149").src;

    value35Save1149 = "zSqrArtSpecz1149";

    localStorage.setItem(value35Save1149, sQz1149);
};

function square1150(){

    var sQz1150 = document.getElementById("imgSqrs1150").src;

    value35Save1150 = "zSqrArtSpecz1150";

    localStorage.setItem(value35Save1150, sQz1150);
};

function square1151(){

    var sQz1151 = document.getElementById("imgSqrs1151").src;

    value35Save1151 = "zSqrArtSpecz1151";

    localStorage.setItem(value35Save1151, sQz1151);
};

function square1152(){

    var sQz1152 = document.getElementById("imgSqrs1152").src;

    value35Save1152 = "zSqrArtSpecz1152";

    localStorage.setItem(value35Save1152, sQz1152);
};

function square1153(){

    var sQz1153 = document.getElementById("imgSqrs1153").src;

    value35Save1153 = "zSqrArtSpecz1153";

    localStorage.setItem(value35Save1153, sQz1153);
};

function square1154(){

    var sQz1154 = document.getElementById("imgSqrs1154").src;

    value35Save1154 = "zSqrArtSpecz1154";

    localStorage.setItem(value35Save1154, sQz1154);
};

function square1155(){

    var sQz1155 = document.getElementById("imgSqrs1155").src;

    value35Save1155 = "zSqrArtSpecz1155";

    localStorage.setItem(value35Save1155, sQz1155);
};

function square1156(){

    var sQz1156 = document.getElementById("imgSqrs1156").src;

    value35Save1156 = "zSqrArtSpecz1156";

    localStorage.setItem(value35Save1156, sQz1156);
};

function square1157(){

    var sQz1157 = document.getElementById("imgSqrs1157").src;

    value35Save1157 = "zSqrArtSpecz1157";

    localStorage.setItem(value35Save1157, sQz1157);
};

function square1158(){

    var sQz1158 = document.getElementById("imgSqrs1158").src;

    value35Save1158 = "zSqrArtSpecz1158";

    localStorage.setItem(value35Save1158, sQz1158);
};

function square1159(){

    var sQz1159 = document.getElementById("imgSqrs1159").src;

    value35Save1159 = "zSqrArtSpecz1159";

    localStorage.setItem(value35Save1159, sQz1159);
};

function square1160(){

    var sQz1160 = document.getElementById("imgSqrs1160").src;

    value35Save1160 = "zSqrArtSpecz1160";

    localStorage.setItem(value35Save1160, sQz1160);
};

function square1161(){

    var sQz1161 = document.getElementById("imgSqrs1161").src;

    value35Save1161 = "zSqrArtSpecz1161";

    localStorage.setItem(value35Save1161, sQz1161);
};

function square1162(){

    var sQz1162 = document.getElementById("imgSqrs1162").src;

    value35Save1162 = "zSqrArtSpecz1162";

    localStorage.setItem(value35Save1162, sQz1162);
};

function square1163(){

    var sQz1163 = document.getElementById("imgSqrs1163").src;

    value35Save1163 = "zSqrArtSpecz1163";

    localStorage.setItem(value35Save1163, sQz1163);
};

function square1164(){

    var sQz1164 = document.getElementById("imgSqrs1164").src;

    value35Save1164 = "zSqrArtSpecz1164";

    localStorage.setItem(value35Save1164, sQz1164);
};

function square1165(){

    var sQz1165 = document.getElementById("imgSqrs1165").src;

    value35Save1165 = "zSqrArtSpecz1165";

    localStorage.setItem(value35Save1165, sQz1165);
};

function square1166(){

    var sQz1166 = document.getElementById("imgSqrs1166").src;

    value35Save1166 = "zSqrArtSpecz1166";

    localStorage.setItem(value35Save1166, sQz1166);
};

function square1167(){

    var sQz1167 = document.getElementById("imgSqrs1167").src;

    value35Save1167 = "zSqrArtSpecz1167";

    localStorage.setItem(value35Save1167, sQz1167);
};

function square1168(){

    var sQz1168 = document.getElementById("imgSqrs1168").src;

    value35Save1168 = "zSqrArtSpecz1168";

    localStorage.setItem(value35Save1168, sQz1168);
};

function square1169(){

    var sQz1169 = document.getElementById("imgSqrs1169").src;

    value35Save1169 = "zSqrArtSpecz1169";

    localStorage.setItem(value35Save1169, sQz1169);
};

function square1170(){

    var sQz1170 = document.getElementById("imgSqrs1170").src;

    value35Save1170 = "zSqrArtSpecz1170";

    localStorage.setItem(value35Save1170, sQz1170);
};

function square1171(){

    var sQz1171 = document.getElementById("imgSqrs1171").src;

    value35Save1171 = "zSqrArtSpecz1171";

    localStorage.setItem(value35Save1171, sQz1171);
};

function square1172(){

    var sQz1172 = document.getElementById("imgSqrs1172").src;

    value35Save1172 = "zSqrArtSpecz1172";

    localStorage.setItem(value35Save1172, sQz1172);
};

function square1173(){

    var sQz1173 = document.getElementById("imgSqrs1173").src;

    value35Save1173 = "zSqrArtSpecz1173";

    localStorage.setItem(value35Save1173, sQz1173);
};

function square1174(){

    var sQz1174 = document.getElementById("imgSqrs1174").src;

    value35Save1174 = "zSqrArtSpecz1174";

    localStorage.setItem(value35Save1174, sQz1174);
};

function square1175(){

    var sQz1175 = document.getElementById("imgSqrs1175").src;

    value35Save1175 = "zSqrArtSpecz1175";

    localStorage.setItem(value35Save1175, sQz1175);
};

function square1176(){

    var sQz1176 = document.getElementById("imgSqrs1176").src;

    value35Save1176 = "zSqrArtSpecz1176";

    localStorage.setItem(value35Save1176, sQz1176);
};

function square1177(){

    var sQz1177 = document.getElementById("imgSqrs1177").src;

    value35Save1177 = "zSqrArtSpecz1177";

    localStorage.setItem(value35Save1177, sQz1177);
};

function square1178(){

    var sQz1178 = document.getElementById("imgSqrs1178").src;

    value35Save1178 = "zSqrArtSpecz1178";

    localStorage.setItem(value35Save1178, sQz1178);
};

function square1179(){

    var sQz1179 = document.getElementById("imgSqrs1179").src;

    value35Save1179 = "zSqrArtSpecz1179";

    localStorage.setItem(value35Save1179, sQz1179);
};

function square1180(){

    var sQz1180 = document.getElementById("imgSqrs1180").src;

    value35Save1180 = "zSqrArtSpecz1180";

    localStorage.setItem(value35Save1180, sQz1180);
};

function square1181(){

    var sQz1181 = document.getElementById("imgSqrs1181").src;

    value35Save1181 = "zSqrArtSpecz1181";

    localStorage.setItem(value35Save1181, sQz1181);
};

function square1182(){

    var sQz1182 = document.getElementById("imgSqrs1182").src;

    value35Save1182 = "zSqrArtSpecz1182";

    localStorage.setItem(value35Save1182, sQz1182);
};

function square1183(){

    var sQz1183 = document.getElementById("imgSqrs1183").src;

    value35Save1183 = "zSqrArtSpecz1183";

    localStorage.setItem(value35Save1183, sQz1183);
};

function square1184(){

    var sQz1184 = document.getElementById("imgSqrs1184").src;

    value35Save1184 = "zSqrArtSpecz1184";

    localStorage.setItem(value35Save1184, sQz1184);
};

function square1185(){

    var sQz1185 = document.getElementById("imgSqrs1185").src;

    value35Save1185 = "zSqrArtSpecz1185";

    localStorage.setItem(value35Save1185, sQz1185);
};

function square1186(){

    var sQz1186 = document.getElementById("imgSqrs1186").src;

    value35Save1186 = "zSqrArtSpecz1186";

    localStorage.setItem(value35Save1186, sQz1186);
};

function square1187(){

    var sQz1187 = document.getElementById("imgSqrs1187").src;

    value35Save1187 = "zSqrArtSpecz1187";

    localStorage.setItem(value35Save1187, sQz1187);
};

function square1188(){

    var sQz1188 = document.getElementById("imgSqrs1188").src;

    value35Save1188 = "zSqrArtSpecz1188";

    localStorage.setItem(value35Save1188, sQz1188);
};

function square1189(){

    var sQz1189 = document.getElementById("imgSqrs1189").src;

    value35Save1189 = "zSqrArtSpecz1189";

    localStorage.setItem(value35Save1189, sQz1189);
};

function square1190(){

    var sQz1190 = document.getElementById("imgSqrs1190").src;

    value35Save1190 = "zSqrArtSpecz1190";

    localStorage.setItem(value35Save1190, sQz1190);
};

function square1191(){

    var sQz1191 = document.getElementById("imgSqrs1191").src;

    value35Save1191 = "zSqrArtSpecz1191";

    localStorage.setItem(value35Save1191, sQz1191);
};

function square1192(){

    var sQz1192 = document.getElementById("imgSqrs1192").src;

    value35Save1192 = "zSqrArtSpecz1192";

    localStorage.setItem(value35Save1192, sQz1192);
};

function square1193(){

    var sQz1193 = document.getElementById("imgSqrs1193").src;

    value35Save1193 = "zSqrArtSpecz1193";

    localStorage.setItem(value35Save1193, sQz1193);
};

function square1194(){

    var sQz1194 = document.getElementById("imgSqrs1194").src;

    value35Save1194 = "zSqrArtSpecz1194";

    localStorage.setItem(value35Save1194, sQz1194);
};

function square1195(){

    var sQz1195 = document.getElementById("imgSqrs1195").src;

    value35Save1195 = "zSqrArtSpecz1195";

    localStorage.setItem(value35Save1195, sQz1195);
};

function square1196(){

    var sQz1196 = document.getElementById("imgSqrs1196").src;

    value35Save1196 = "zSqrArtSpecz1196";

    localStorage.setItem(value35Save1196, sQz1196);
};

function square1197(){

    var sQz1197 = document.getElementById("imgSqrs1197").src;

    value35Save1197 = "zSqrArtSpecz1197";

    localStorage.setItem(value35Save1197, sQz1197);
};

function square1198(){

    var sQz1198 = document.getElementById("imgSqrs1198").src;

    value35Save1198 = "zSqrArtSpecz1198";

    localStorage.setItem(value35Save1198, sQz1198);
};

function square1199(){

    var sQz1199 = document.getElementById("imgSqrs1199").src;

    value35Save1199 = "zSqrArtSpecz1199";

    localStorage.setItem(value35Save1199, sQz1199);
};

function square1200(){

    var sQz1200 = document.getElementById("imgSqrs1200").src;

    value35Save1200 = "zSqrArtSpecz1200";

    localStorage.setItem(value35Save1200, sQz1200);
};

function square1201(){

    var sQz1201 = document.getElementById("imgSqrs1201").src;

    value35Save1201 = "zSqrArtSpecz1201";

    localStorage.setItem(value35Save1201, sQz1201);
};

function square1202(){

    var sQz1202 = document.getElementById("imgSqrs1202").src;

    value35Save1202 = "zSqrArtSpecz1202";

    localStorage.setItem(value35Save1202, sQz1202);
};

function square1203(){

    var sQz1203 = document.getElementById("imgSqrs1203").src;

    value35Save1203 = "zSqrArtSpecz1203";

    localStorage.setItem(value35Save1203, sQz1203);
};

function square1204(){

    var sQz1204 = document.getElementById("imgSqrs1204").src;

    value35Save1204 = "zSqrArtSpecz1204";

    localStorage.setItem(value35Save1204, sQz1204);
};

function square1205(){

    var sQz1205 = document.getElementById("imgSqrs1205").src;

    value35Save1205 = "zSqrArtSpecz1205";

    localStorage.setItem(value35Save1205, sQz1205);
};

function square1206(){

    var sQz1206 = document.getElementById("imgSqrs1206").src;

    value35Save1206 = "zSqrArtSpecz1206";

    localStorage.setItem(value35Save1206, sQz1206);
};

function square1207(){

    var sQz1207 = document.getElementById("imgSqrs1207").src;

    value35Save1207 = "zSqrArtSpecz1207";

    localStorage.setItem(value35Save1207, sQz1207);
};

function square1208(){

    var sQz1208 = document.getElementById("imgSqrs1208").src;

    value35Save1208 = "zSqrArtSpecz1208";

    localStorage.setItem(value35Save1208, sQz1208);
};

function square1209(){

    var sQz1209 = document.getElementById("imgSqrs1209").src;

    value35Save1209 = "zSqrArtSpecz1209";

    localStorage.setItem(value35Save1209, sQz1209);
};

function square1210(){

    var sQz1210 = document.getElementById("imgSqrs1210").src;

    value35Save1210 = "zSqrArtSpecz1210";

    localStorage.setItem(value35Save1210, sQz1210);
};

function square1211(){

    var sQz1211 = document.getElementById("imgSqrs1211").src;

    value35Save1211 = "zSqrArtSpecz1211";

    localStorage.setItem(value35Save1211, sQz1211);
};

function square1212(){

    var sQz1212 = document.getElementById("imgSqrs1212").src;

    value35Save1212 = "zSqrArtSpecz1212";

    localStorage.setItem(value35Save1212, sQz1212);
};

function square1213(){

    var sQz1213 = document.getElementById("imgSqrs1213").src;

    value35Save1213 = "zSqrArtSpecz1213";

    localStorage.setItem(value35Save1213, sQz1213);
};

function square1214(){

    var sQz1214 = document.getElementById("imgSqrs1214").src;

    value35Save1214 = "zSqrArtSpecz1214";

    localStorage.setItem(value35Save1214, sQz1214);
};

function square1215(){

    var sQz1215 = document.getElementById("imgSqrs1215").src;

    value35Save1215 = "zSqrArtSpecz1215";

    localStorage.setItem(value35Save1215, sQz1215);
};

function square1216(){

    var sQz1216 = document.getElementById("imgSqrs1216").src;

    value35Save1216 = "zSqrArtSpecz1216";

    localStorage.setItem(value35Save1216, sQz1216);
};

function square1217(){

    var sQz1217 = document.getElementById("imgSqrs1217").src;

    value35Save1217 = "zSqrArtSpecz1217";

    localStorage.setItem(value35Save1217, sQz1217);
};

function square1218(){

    var sQz1218 = document.getElementById("imgSqrs1218").src;

    value35Save1218 = "zSqrArtSpecz1218";

    localStorage.setItem(value35Save1218, sQz1218);
};

function square1219(){

    var sQz1219 = document.getElementById("imgSqrs1219").src;

    value35Save1219 = "zSqrArtSpecz1219";

    localStorage.setItem(value35Save1219, sQz1219);
};

function square1220(){

    var sQz1220 = document.getElementById("imgSqrs1220").src;

    value35Save1220 = "zSqrArtSpecz1220";

    localStorage.setItem(value35Save1220, sQz1220);
};

function square1221(){

    var sQz1221 = document.getElementById("imgSqrs1221").src;

    value35Save1221 = "zSqrArtSpecz1221";

    localStorage.setItem(value35Save1221, sQz1221);
};

function square1222(){

    var sQz1222 = document.getElementById("imgSqrs1222").src;

    value35Save1222 = "zSqrArtSpecz1222";

    localStorage.setItem(value35Save1222, sQz1222);
};

function square1223(){

    var sQz1223 = document.getElementById("imgSqrs1223").src;

    value35Save1223 = "zSqrArtSpecz1223";

    localStorage.setItem(value35Save1223, sQz1223);
};

function square1224(){

    var sQz1224 = document.getElementById("imgSqrs1224").src;

    value35Save1224 = "zSqrArtSpecz1224";

    localStorage.setItem(value35Save1224, sQz1224);
};

function square1225(){

    var sQz1225 = document.getElementById("imgSqrs1225").src;

    value35Save1225 = "zSqrArtSpecz1225";

    localStorage.setItem(value35Save1225, sQz1225);
};

function setAThis(){
    square1()

    square2()

    square3()

    square4()

    square5()

    square6()

    square7()

    square8()

    square9()

    square10()

    square11()

    square12()

    square13()

    square14()

    square15()

    square16()

    square17()

    square18()

    square19()

    square20()

    square21()

    square22()

    square23()

    square24()

    square25()

    square26()

    square27()

    square28()

    square29()

    square30()

    square31()

    square32()

    square33()

    square34()

    square35()

    square36()

    square37()

    square38()

    square39()

    square40()

    square41()

    square42()

    square43()

    square44()

    square45()

    square46()

    square47()

    square48()

    square49()

    square50()

    square51()

    square52()

    square53()

    square54()

    square55()

    square56()

    square57()

    square58()

    square59()

    square60()

    square61()

    square62()

    square63()

    square64()

    square65()

    square66()

    square67()

    square68()

    square69()

    square70()

    square71()

    square72()

    square73()

    square74()

    square75()

    square76()

    square77()

    square78()

    square79()

    square80()

    square81()

    square82()

    square83()

    square84()

    square85()

    square86()

    square87()

    square88()

    square89()

    square90()

    square91()

    square92()

    square93()

    square94()

    square95()

    square96()

    square97()

    square98()

    square99()

    square100()

    square101()

    square102()

    square103()

    square104()

    square105()

    square106()

    square107()

    square108()

    square109()

    square110()

    square111()

    square112()

    square113()

    square114()

    square115()

    square116()

    square117()

    square118()

    square119()

    square120()

    square121()

    square122()

    square123()

    square124()

    square125()

    square126()

    square127()

    square128()

    square129()

    square130()

    square131()

    square132()

    square133()

    square134()

    square135()

    square136()

    square137()

    square138()

    square139()

    square140()

    square141()

    square142()

    square143()

    square144()

    square145()

    square146()

    square147()

    square148()

    square149()

    square150()

    square151()

    square152()

    square153()

    square154()

    square155()

    square156()

    square157()

    square158()

    square159()

    square160()

    square161()

    square162()

    square163()

    square164()

    square165()

    square166()

    square167()

    square168()

    square169()

    square170()

    square171()

    square172()

    square173()

    square174()

    square175()

    square176()

    square177()

    square178()

    square179()

    square180()

    square181()

    square182()

    square183()

    square184()

    square185()

    square186()

    square187()

    square188()

    square189()

    square190()

    square191()

    square192()

    square193()

    square194()

    square195()

    square196()

    square197()

    square198()

    square199()

    square200()

    square201()

    square202()

    square203()

    square204()

    square205()

    square206()

    square207()

    square208()

    square209()

    square210()

    square211()

    square212()

    square213()

    square214()

    square215()

    square216()

    square217()

    square218()

    square219()

    square220()

    square221()

    square222()

    square223()

    square224()

    square225()

    square226()

    square227()

    square228()

    square229()

    square230()

    square231()

    square232()

    square233()

    square234()

    square235()

    square236()

    square237()

    square238()

    square239()

    square240()

    square241()

    square242()

    square243()

    square244()

    square245()

    square246()

    square247()

    square248()

    square249()

    square250()

    square251()

    square252()

    square253()

    square254()

    square255()

    square256()

    square257()

    square258()

    square259()

    square260()

    square261()

    square262()

    square263()

    square264()

    square265()

    square266()

    square267()

    square268()

    square269()

    square270()

    square271()

    square272()

    square273()

    square274()

    square275()

    square276()

    square277()

    square278()

    square279()

    square280()

    square281()

    square282()

    square283()

    square284()

    square285()

    square286()

    square287()

    square288()

    square289()

    square290()

    square291()

    square292()

    square293()

    square294()

    square295()

    square296()

    square297()

    square298()

    square299()

    square300()

    square301()

    square302()

    square303()

    square304()

    square305()

    square306()

    square307()

    square308()

    square309()

    square310()

    square311()

    square312()

    square313()

    square314()

    square315()

    square316()

    square317()

    square318()

    square319()

    square320()

    square321()

    square322()

    square323()

    square324()

    square325()

    square326()

    square327()

    square328()

    square329()

    square330()

    square331()

    square332()

    square333()

    square334()

    square335()

    square336()

    square337()

    square338()

    square339()

    square340()

    square341()

    square342()

    square343()

    square344()

    square345()

    square346()

    square347()

    square348()

    square349()

    square350()

    square351()

    square352()

    square353()

    square354()

    square355()

    square356()

    square357()

    square358()

    square359()

    square360()

    square361()

    square362()

    square363()

    square364()

    square365()

    square366()

    square367()

    square368()

    square369()

    square370()

    square371()

    square372()

    square373()

    square374()

    square375()

    square376()

    square377()

    square378()

    square379()

    square380()

    square381()

    square382()

    square383()

    square384()

    square385()

    square386()

    square387()

    square388()

    square389()

    square390()

    square391()

    square392()

    square393()

    square394()

    square395()

    square396()

    square397()

    square398()

    square399()

    square400()

    square401()

    square402()

    square403()

    square404()

    square405()

    square406()

    square407()

    square408()

    square409()

    square410()

    square411()

    square412()

    square413()

    square414()

    square415()

    square416()

    square417()

    square418()

    square419()

    square420()

    square421()

    square422()

    square423()

    square424()

    square425()

    square426()

    square427()

    square428()

    square429()

    square430()

    square431()

    square432()

    square433()

    square434()

    square435()

    square436()

    square437()

    square438()

    square439()

    square440()

    square441()

    square442()

    square443()

    square444()

    square445()

    square446()

    square447()

    square448()

    square449()

    square450()

    square451()

    square452()

    square453()

    square454()

    square455()

    square456()

    square457()

    square458()

    square459()

    square460()

    square461()

    square462()

    square463()

    square464()

    square465()

    square466()

    square467()

    square468()

    square469()

    square470()

    square471()

    square472()

    square473()

    square474()

    square475()

    square476()

    square477()

    square478()

    square479()

    square480()

    square481()

    square482()

    square483()

    square484()

    square485()

    square486()

    square487()

    square488()

    square489()

    square490()

    square491()

    square492()

    square493()

    square494()

    square495()

    square496()

    square497()

    square498()

    square499()

    square500()

    square501()

    square502()

    square503()

    square504()

    square505()

    square506()

    square507()

    square508()

    square509()

    square510()

    square511()

    square512()

    square513()

    square514()

    square515()

    square516()

    square517()

    square518()

    square519()

    square520()

    square521()

    square522()

    square523()

    square524()

    square525()

    square526()

    square527()

    square528()

    square529()

    square530()

    square531()

    square532()

    square533()

    square534()

    square535()

    square536()

    square537()

    square538()

    square539()

    square540()

    square541()

    square542()

    square543()

    square544()

    square545()

    square546()

    square547()

    square548()

    square549()

    square550()

    square551()

    square552()

    square553()

    square554()

    square555()

    square556()

    square557()

    square558()

    square559()

    square560()

    square561()

    square562()

    square563()

    square564()

    square565()

    square566()

    square567()

    square568()

    square569()

    square570()

    square571()

    square572()

    square573()

    square574()

    square575()

    square576()

    square577()

    square578()

    square579()

    square580()

    square581()

    square582()

    square583()

    square584()

    square585()

    square586()

    square587()

    square588()

    square589()

    square590()

    square591()

    square592()

    square593()

    square594()

    square595()

    square596()

    square597()

    square598()

    square599()

    square600()

    square601()

    square602()

    square603()

    square604()

    square605()

    square606()

    square607()

    square608()

    square609()

    square610()

    square611()

    square612()

    square613()

    square614()

    square615()

    square616()

    square617()

    square618()

    square619()

    square620()

    square621()

    square622()

    square623()

    square624()

    square625()

    square626()

    square627()

    square628()

    square629()

    square630()

    square631()

    square632()

    square633()

    square634()

    square635()

    square636()

    square637()

    square638()

    square639()

    square640()

    square641()

    square642()

    square643()

    square644()

    square645()

    square646()

    square647()

    square648()

    square649()

    square650()

    square651()

    square652()

    square653()

    square654()

    square655()

    square656()

    square657()

    square658()

    square659()

    square660()

    square661()

    square662()

    square663()

    square664()

    square665()

    square666()

    square667()

    square668()

    square669()

    square670()

    square671()

    square672()

    square673()

    square674()

    square675()

    square676()

    square677()

    square678()

    square679()

    square680()

    square681()

    square682()

    square683()

    square684()

    square685()

    square686()

    square687()

    square688()

    square689()

    square690()

    square691()

    square692()

    square693()

    square694()

    square695()

    square696()

    square697()

    square698()

    square699()

    square700()

    square701()

    square702()

    square703()

    square704()

    square705()

    square706()

    square707()

    square708()

    square709()

    square710()

    square711()

    square712()

    square713()

    square714()

    square715()

    square716()

    square717()

    square718()

    square719()

    square720()

    square721()

    square722()

    square723()

    square724()

    square725()

    square726()

    square727()

    square728()

    square729()

    square730()

    square731()

    square732()

    square733()

    square734()

    square735()

    square736()

    square737()

    square738()

    square739()

    square740()

    square741()

    square742()

    square743()

    square744()

    square745()

    square746()

    square747()

    square748()

    square749()

    square750()

    square751()

    square752()

    square753()

    square754()

    square755()

    square756()

    square757()

    square758()

    square759()

    square760()

    square761()

    square762()

    square763()

    square764()

    square765()

    square766()

    square767()

    square768()

    square769()

    square770()

    square771()

    square772()

    square773()

    square774()

    square775()

    square776()

    square777()

    square778()

    square779()

    square780()

    square781()

    square782()

    square783()

    square784()

    square785()

    square786()

    square787()

    square788()

    square789()

    square790()

    square791()

    square792()

    square793()

    square794()

    square795()

    square796()

    square797()

    square798()

    square799()

    square800()

    square801()

    square802()

    square803()

    square804()

    square805()

    square806()

    square807()

    square808()

    square809()

    square810()

    square811()

    square812()

    square813()

    square814()

    square815()

    square816()

    square817()

    square818()

    square819()

    square820()

    square821()

    square822()

    square823()

    square824()

    square825()

    square826()

    square827()

    square828()

    square829()

    square830()

    square831()

    square832()

    square833()

    square834()

    square835()

    square836()

    square837()

    square838()

    square839()

    square840()

    square841()

    square842()

    square843()

    square844()

    square845()

    square846()

    square847()

    square848()

    square849()

    square850()

    square851()

    square852()

    square853()

    square854()

    square855()

    square856()

    square857()

    square858()

    square859()

    square860()

    square861()

    square862()

    square863()

    square864()

    square865()

    square866()

    square867()

    square868()

    square869()

    square870()

    square871()

    square872()

    square873()

    square874()

    square875()

    square876()

    square877()

    square878()

    square879()

    square880()

    square881()

    square882()

    square883()

    square884()

    square885()

    square886()

    square887()

    square888()

    square889()

    square890()

    square891()

    square892()

    square893()

    square894()

    square895()

    square896()

    square897()

    square898()

    square899()

    square900()

    square901()

    square902()

    square903()

    square904()

    square905()

    square906()

    square907()

    square908()

    square909()

    square910()

    square911()

    square912()

    square913()

    square914()

    square915()

    square916()

    square917()

    square918()

    square919()

    square920()

    square921()

    square922()

    square923()

    square924()

    square925()

    square926()

    square927()

    square928()

    square929()

    square930()

    square931()

    square932()

    square933()

    square934()

    square935()

    square936()

    square937()

    square938()

    square939()

    square940()

    square941()

    square942()

    square943()

    square944()

    square945()

    square946()

    square947()

    square948()

    square949()

    square950()

    square951()

    square952()

    square953()

    square954()

    square955()

    square956()

    square957()

    square958()

    square959()

    square960()

    square961()

    square962()

    square963()

    square964()

    square965()

    square966()

    square967()

    square968()

    square969()

    square970()

    square971()

    square972()

    square973()

    square974()

    square975()

    square976()

    square977()

    square978()

    square979()

    square980()

    square981()

    square982()

    square983()

    square984()

    square985()

    square986()

    square987()

    square988()

    square989()

    square990()

    square991()

    square992()

    square993()

    square994()

    square995()

    square996()

    square997()

    square998()

    square999()

    square1000()

    square1001()

    square1002()

    square1003()

    square1004()

    square1005()

    square1006()

    square1007()

    square1008()

    square1009()

    square1010()

    square1011()

    square1012()

    square1013()

    square1014()

    square1015()

    square1016()

    square1017()

    square1018()

    square1019()

    square1020()

    square1021()

    square1022()

    square1023()

    square1024()

    square1025()

    square1026()

    square1027()

    square1028()

    square1029()

    square1030()

    square1031()

    square1032()

    square1033()

    square1034()

    square1035()

    square1036()

    square1037()

    square1038()

    square1039()

    square1040()

    square1041()

    square1042()

    square1043()

    square1044()

    square1045()

    square1046()

    square1047()

    square1048()

    square1049()

    square1050()

    square1051()

    square1052()

    square1053()

    square1054()

    square1055()

    square1056()

    square1057()

    square1058()

    square1059()

    square1060()

    square1061()

    square1062()

    square1063()

    square1064()

    square1065()

    square1066()

    square1067()

    square1068()

    square1069()

    square1070()

    square1071()

    square1072()

    square1073()

    square1074()

    square1075()

    square1076()

    square1077()

    square1078()

    square1079()

    square1080()

    square1081()

    square1082()

    square1083()

    square1084()

    square1085()

    square1086()

    square1087()

    square1088()

    square1089()

    square1090()

    square1091()

    square1092()

    square1093()

    square1094()

    square1095()

    square1096()

    square1097()

    square1098()

    square1099()

    square1100()

    square1101()

    square1102()

    square1103()

    square1104()

    square1105()

    square1106()

    square1107()

    square1108()

    square1109()

    square1110()

    square1111()

    square1112()

    square1113()

    square1114()

    square1115()

    square1116()

    square1117()

    square1118()

    square1119()

    square1120()

    square1121()

    square1122()

    square1123()

    square1124()

    square1125()

    square1126()

    square1127()

    square1128()

    square1129()

    square1130()

    square1131()

    square1132()

    square1133()

    square1134()

    square1135()

    square1136()

    square1137()

    square1138()

    square1139()

    square1140()

    square1141()

    square1142()

    square1143()

    square1144()

    square1145()

    square1146()

    square1147()

    square1148()

    square1149()

    square1150()

    square1151()

    square1152()

    square1153()

    square1154()

    square1155()

    square1156()

    square1157()

    square1158()

    square1159()

    square1160()

    square1161()

    square1162()

    square1163()

    square1164()

    square1165()

    square1166()

    square1167()

    square1168()

    square1169()

    square1170()

    square1171()

    square1172()

    square1173()

    square1174()

    square1175()

    square1176()

    square1177()

    square1178()

    square1179()

    square1180()

    square1181()

    square1182()

    square1183()

    square1184()

    square1185()

    square1186()

    square1187()

    square1188()

    square1189()

    square1190()

    square1191()

    square1192()

    square1193()

    square1194()

    square1195()

    square1196()

    square1197()

    square1198()

    square1199()

    square1200()

    square1201()

    square1202()

    square1203()

    square1204()

    square1205()

    square1206()

    square1207()

    square1208()

    square1209()

    square1210()

    square1211()

    square1212()

    square1213()

    square1214()

    square1215()

    square1216()

    square1217()

    square1218()

    square1219()

    square1220()

    square1221()

    square1222()

    square1223()

    square1224()

    square1225()

    alert("Your art has been saved locally, to your local browser storage.");
};

function squareToSzzZValue1(){
    value35Save = "zSqrArtSpecz1";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1").src = tripleZeroA;
};

function squareToSzzZValue2(){
    value35Save = "zSqrArtSpecz2";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs2").src = tripleZeroA;
};

function squareToSzzZValue3(){
    value35Save = "zSqrArtSpecz3";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs3").src = tripleZeroA;
};

function squareToSzzZValue4(){
    value35Save = "zSqrArtSpecz4";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs4").src = tripleZeroA;
};

function squareToSzzZValue5(){
    value35Save = "zSqrArtSpecz5";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs5").src = tripleZeroA;
};

function squareToSzzZValue6(){
    value35Save = "zSqrArtSpecz6";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs6").src = tripleZeroA;
};

function squareToSzzZValue7(){
    value35Save = "zSqrArtSpecz7";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs7").src = tripleZeroA;
};

function squareToSzzZValue8(){
    value35Save = "zSqrArtSpecz8";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs8").src = tripleZeroA;
};

function squareToSzzZValue9(){
    value35Save = "zSqrArtSpecz9";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs9").src = tripleZeroA;
};

function squareToSzzZValue10(){
    value35Save = "zSqrArtSpecz10";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs10").src = tripleZeroA;
};

function squareToSzzZValue11(){
    value35Save = "zSqrArtSpecz11";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs11").src = tripleZeroA;
};

function squareToSzzZValue12(){
    value35Save = "zSqrArtSpecz12";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs12").src = tripleZeroA;
};

function squareToSzzZValue13(){
    value35Save = "zSqrArtSpecz13";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs13").src = tripleZeroA;
};

function squareToSzzZValue14(){
    value35Save = "zSqrArtSpecz14";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs14").src = tripleZeroA;
};

function squareToSzzZValue15(){
    value35Save = "zSqrArtSpecz15";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs15").src = tripleZeroA;
};

function squareToSzzZValue16(){
    value35Save = "zSqrArtSpecz16";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs16").src = tripleZeroA;
};

function squareToSzzZValue17(){
    value35Save = "zSqrArtSpecz17";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs17").src = tripleZeroA;
};

function squareToSzzZValue18(){
    value35Save = "zSqrArtSpecz18";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs18").src = tripleZeroA;
};

function squareToSzzZValue19(){
    value35Save = "zSqrArtSpecz19";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs19").src = tripleZeroA;
};

function squareToSzzZValue20(){
    value35Save = "zSqrArtSpecz20";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs20").src = tripleZeroA;
};

function squareToSzzZValue21(){
    value35Save = "zSqrArtSpecz21";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs21").src = tripleZeroA;
};

function squareToSzzZValue22(){
    value35Save = "zSqrArtSpecz22";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs22").src = tripleZeroA;
};

function squareToSzzZValue23(){
    value35Save = "zSqrArtSpecz23";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs23").src = tripleZeroA;
};

function squareToSzzZValue24(){
    value35Save = "zSqrArtSpecz24";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs24").src = tripleZeroA;
};

function squareToSzzZValue25(){
    value35Save = "zSqrArtSpecz25";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs25").src = tripleZeroA;
};

function squareToSzzZValue26(){
    value35Save = "zSqrArtSpecz26";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs26").src = tripleZeroA;
};

function squareToSzzZValue27(){
    value35Save = "zSqrArtSpecz27";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs27").src = tripleZeroA;
};

function squareToSzzZValue28(){
    value35Save = "zSqrArtSpecz28";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs28").src = tripleZeroA;
};

function squareToSzzZValue29(){
    value35Save = "zSqrArtSpecz29";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs29").src = tripleZeroA;
};

function squareToSzzZValue30(){
    value35Save = "zSqrArtSpecz30";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs30").src = tripleZeroA;
};

function squareToSzzZValue31(){
    value35Save = "zSqrArtSpecz31";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs31").src = tripleZeroA;
};

function squareToSzzZValue32(){
    value35Save = "zSqrArtSpecz32";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs32").src = tripleZeroA;
};

function squareToSzzZValue33(){
    value35Save = "zSqrArtSpecz33";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs33").src = tripleZeroA;
};

function squareToSzzZValue34(){
    value35Save = "zSqrArtSpecz34";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs34").src = tripleZeroA;
};

function squareToSzzZValue35(){
    value35Save = "zSqrArtSpecz35";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs35").src = tripleZeroA;
};

function squareToSzzZValue36(){
    value35Save = "zSqrArtSpecz36";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs36").src = tripleZeroA;
};

function squareToSzzZValue37(){
    value35Save = "zSqrArtSpecz37";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs37").src = tripleZeroA;
};

function squareToSzzZValue38(){
    value35Save = "zSqrArtSpecz38";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs38").src = tripleZeroA;
};

function squareToSzzZValue39(){
    value35Save = "zSqrArtSpecz39";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs39").src = tripleZeroA;
};

function squareToSzzZValue40(){
    value35Save = "zSqrArtSpecz40";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs40").src = tripleZeroA;
};

function squareToSzzZValue41(){
    value35Save = "zSqrArtSpecz41";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs41").src = tripleZeroA;
};

function squareToSzzZValue42(){
    value35Save = "zSqrArtSpecz42";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs42").src = tripleZeroA;
};

function squareToSzzZValue43(){
    value35Save = "zSqrArtSpecz43";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs43").src = tripleZeroA;
};

function squareToSzzZValue44(){
    value35Save = "zSqrArtSpecz44";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs44").src = tripleZeroA;
};

function squareToSzzZValue45(){
    value35Save = "zSqrArtSpecz45";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs45").src = tripleZeroA;
};

function squareToSzzZValue46(){
    value35Save = "zSqrArtSpecz46";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs46").src = tripleZeroA;
};

function squareToSzzZValue47(){
    value35Save = "zSqrArtSpecz47";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs47").src = tripleZeroA;
};

function squareToSzzZValue48(){
    value35Save = "zSqrArtSpecz48";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs48").src = tripleZeroA;
};

function squareToSzzZValue49(){
    value35Save = "zSqrArtSpecz49";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs49").src = tripleZeroA;
};

function squareToSzzZValue50(){
    value35Save = "zSqrArtSpecz50";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs50").src = tripleZeroA;
};

function squareToSzzZValue51(){
    value35Save = "zSqrArtSpecz51";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs51").src = tripleZeroA;
};

function squareToSzzZValue52(){
    value35Save = "zSqrArtSpecz52";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs52").src = tripleZeroA;
};

function squareToSzzZValue53(){
    value35Save = "zSqrArtSpecz53";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs53").src = tripleZeroA;
};

function squareToSzzZValue54(){
    value35Save = "zSqrArtSpecz54";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs54").src = tripleZeroA;
};

function squareToSzzZValue55(){
    value35Save = "zSqrArtSpecz55";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs55").src = tripleZeroA;
};

function squareToSzzZValue56(){
    value35Save = "zSqrArtSpecz56";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs56").src = tripleZeroA;
};

function squareToSzzZValue57(){
    value35Save = "zSqrArtSpecz57";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs57").src = tripleZeroA;
};

function squareToSzzZValue58(){
    value35Save = "zSqrArtSpecz58";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs58").src = tripleZeroA;
};

function squareToSzzZValue59(){
    value35Save = "zSqrArtSpecz59";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs59").src = tripleZeroA;
};

function squareToSzzZValue60(){
    value35Save = "zSqrArtSpecz60";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs60").src = tripleZeroA;
};

function squareToSzzZValue61(){
    value35Save = "zSqrArtSpecz61";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs61").src = tripleZeroA;
};

function squareToSzzZValue62(){
    value35Save = "zSqrArtSpecz62";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs62").src = tripleZeroA;
};

function squareToSzzZValue63(){
    value35Save = "zSqrArtSpecz63";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs63").src = tripleZeroA;
};

function squareToSzzZValue64(){
    value35Save = "zSqrArtSpecz64";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs64").src = tripleZeroA;
};

function squareToSzzZValue65(){
    value35Save = "zSqrArtSpecz65";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs65").src = tripleZeroA;
};

function squareToSzzZValue66(){
    value35Save = "zSqrArtSpecz66";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs66").src = tripleZeroA;
};

function squareToSzzZValue67(){
    value35Save = "zSqrArtSpecz67";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs67").src = tripleZeroA;
};

function squareToSzzZValue68(){
    value35Save = "zSqrArtSpecz68";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs68").src = tripleZeroA;
};

function squareToSzzZValue69(){
    value35Save = "zSqrArtSpecz69";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs69").src = tripleZeroA;
};

function squareToSzzZValue70(){
    value35Save = "zSqrArtSpecz70";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs70").src = tripleZeroA;
};

function squareToSzzZValue71(){
    value35Save = "zSqrArtSpecz71";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs71").src = tripleZeroA;
};

function squareToSzzZValue72(){
    value35Save = "zSqrArtSpecz72";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs72").src = tripleZeroA;
};

function squareToSzzZValue73(){
    value35Save = "zSqrArtSpecz73";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs73").src = tripleZeroA;
};

function squareToSzzZValue74(){
    value35Save = "zSqrArtSpecz74";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs74").src = tripleZeroA;
};

function squareToSzzZValue75(){
    value35Save = "zSqrArtSpecz75";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs75").src = tripleZeroA;
};

function squareToSzzZValue76(){
    value35Save = "zSqrArtSpecz76";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs76").src = tripleZeroA;
};

function squareToSzzZValue77(){
    value35Save = "zSqrArtSpecz77";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs77").src = tripleZeroA;
};

function squareToSzzZValue78(){
    value35Save = "zSqrArtSpecz78";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs78").src = tripleZeroA;
};

function squareToSzzZValue79(){
    value35Save = "zSqrArtSpecz79";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs79").src = tripleZeroA;
};

function squareToSzzZValue80(){
    value35Save = "zSqrArtSpecz80";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs80").src = tripleZeroA;
};

function squareToSzzZValue81(){
    value35Save = "zSqrArtSpecz81";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs81").src = tripleZeroA;
};

function squareToSzzZValue82(){
    value35Save = "zSqrArtSpecz82";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs82").src = tripleZeroA;
};

function squareToSzzZValue83(){
    value35Save = "zSqrArtSpecz83";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs83").src = tripleZeroA;
};

function squareToSzzZValue84(){
    value35Save = "zSqrArtSpecz84";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs84").src = tripleZeroA;
};

function squareToSzzZValue85(){
    value35Save = "zSqrArtSpecz85";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs85").src = tripleZeroA;
};

function squareToSzzZValue86(){
    value35Save = "zSqrArtSpecz86";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs86").src = tripleZeroA;
};

function squareToSzzZValue87(){
    value35Save = "zSqrArtSpecz87";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs87").src = tripleZeroA;
};

function squareToSzzZValue88(){
    value35Save = "zSqrArtSpecz88";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs88").src = tripleZeroA;
};

function squareToSzzZValue89(){
    value35Save = "zSqrArtSpecz89";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs89").src = tripleZeroA;
};

function squareToSzzZValue90(){
    value35Save = "zSqrArtSpecz90";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs90").src = tripleZeroA;
};

function squareToSzzZValue91(){
    value35Save = "zSqrArtSpecz91";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs91").src = tripleZeroA;
};

function squareToSzzZValue92(){
    value35Save = "zSqrArtSpecz92";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs92").src = tripleZeroA;
};

function squareToSzzZValue93(){
    value35Save = "zSqrArtSpecz93";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs93").src = tripleZeroA;
};

function squareToSzzZValue94(){
    value35Save = "zSqrArtSpecz94";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs94").src = tripleZeroA;
};

function squareToSzzZValue95(){
    value35Save = "zSqrArtSpecz95";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs95").src = tripleZeroA;
};

function squareToSzzZValue96(){
    value35Save = "zSqrArtSpecz96";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs96").src = tripleZeroA;
};

function squareToSzzZValue97(){
    value35Save = "zSqrArtSpecz97";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs97").src = tripleZeroA;
};

function squareToSzzZValue98(){
    value35Save = "zSqrArtSpecz98";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs98").src = tripleZeroA;
};

function squareToSzzZValue99(){
    value35Save = "zSqrArtSpecz99";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs99").src = tripleZeroA;
};

function squareToSzzZValue100(){
    value35Save = "zSqrArtSpecz100";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs100").src = tripleZeroA;
};

function squareToSzzZValue101(){
    value35Save = "zSqrArtSpecz101";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs101").src = tripleZeroA;
};

function squareToSzzZValue102(){
    value35Save = "zSqrArtSpecz102";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs102").src = tripleZeroA;
};

function squareToSzzZValue103(){
    value35Save = "zSqrArtSpecz103";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs103").src = tripleZeroA;
};

function squareToSzzZValue104(){
    value35Save = "zSqrArtSpecz104";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs104").src = tripleZeroA;
};

function squareToSzzZValue105(){
    value35Save = "zSqrArtSpecz105";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs105").src = tripleZeroA;
};

function squareToSzzZValue106(){
    value35Save = "zSqrArtSpecz106";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs106").src = tripleZeroA;
};

function squareToSzzZValue107(){
    value35Save = "zSqrArtSpecz107";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs107").src = tripleZeroA;
};

function squareToSzzZValue108(){
    value35Save = "zSqrArtSpecz108";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs108").src = tripleZeroA;
};

function squareToSzzZValue109(){
    value35Save = "zSqrArtSpecz109";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs109").src = tripleZeroA;
};

function squareToSzzZValue110(){
    value35Save = "zSqrArtSpecz110";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs110").src = tripleZeroA;
};

function squareToSzzZValue111(){
    value35Save = "zSqrArtSpecz111";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs111").src = tripleZeroA;
};

function squareToSzzZValue112(){
    value35Save = "zSqrArtSpecz112";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs112").src = tripleZeroA;
};

function squareToSzzZValue113(){
    value35Save = "zSqrArtSpecz113";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs113").src = tripleZeroA;
};

function squareToSzzZValue114(){
    value35Save = "zSqrArtSpecz114";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs114").src = tripleZeroA;
};

function squareToSzzZValue115(){
    value35Save = "zSqrArtSpecz115";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs115").src = tripleZeroA;
};

function squareToSzzZValue116(){
    value35Save = "zSqrArtSpecz116";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs116").src = tripleZeroA;
};

function squareToSzzZValue117(){
    value35Save = "zSqrArtSpecz117";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs117").src = tripleZeroA;
};

function squareToSzzZValue118(){
    value35Save = "zSqrArtSpecz118";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs118").src = tripleZeroA;
};

function squareToSzzZValue119(){
    value35Save = "zSqrArtSpecz119";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs119").src = tripleZeroA;
};

function squareToSzzZValue120(){
    value35Save = "zSqrArtSpecz120";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs120").src = tripleZeroA;
};

function squareToSzzZValue121(){
    value35Save = "zSqrArtSpecz121";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs121").src = tripleZeroA;
};

function squareToSzzZValue122(){
    value35Save = "zSqrArtSpecz122";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs122").src = tripleZeroA;
};

function squareToSzzZValue123(){
    value35Save = "zSqrArtSpecz123";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs123").src = tripleZeroA;
};

function squareToSzzZValue124(){
    value35Save = "zSqrArtSpecz124";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs124").src = tripleZeroA;
};

function squareToSzzZValue125(){
    value35Save = "zSqrArtSpecz125";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs125").src = tripleZeroA;
};

function squareToSzzZValue126(){
    value35Save = "zSqrArtSpecz126";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs126").src = tripleZeroA;
};

function squareToSzzZValue127(){
    value35Save = "zSqrArtSpecz127";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs127").src = tripleZeroA;
};

function squareToSzzZValue128(){
    value35Save = "zSqrArtSpecz128";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs128").src = tripleZeroA;
};

function squareToSzzZValue129(){
    value35Save = "zSqrArtSpecz129";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs129").src = tripleZeroA;
};

function squareToSzzZValue130(){
    value35Save = "zSqrArtSpecz130";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs130").src = tripleZeroA;
};

function squareToSzzZValue131(){
    value35Save = "zSqrArtSpecz131";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs131").src = tripleZeroA;
};

function squareToSzzZValue132(){
    value35Save = "zSqrArtSpecz132";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs132").src = tripleZeroA;
};

function squareToSzzZValue133(){
    value35Save = "zSqrArtSpecz133";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs133").src = tripleZeroA;
};

function squareToSzzZValue134(){
    value35Save = "zSqrArtSpecz134";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs134").src = tripleZeroA;
};

function squareToSzzZValue135(){
    value35Save = "zSqrArtSpecz135";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs135").src = tripleZeroA;
};

function squareToSzzZValue136(){
    value35Save = "zSqrArtSpecz136";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs136").src = tripleZeroA;
};

function squareToSzzZValue137(){
    value35Save = "zSqrArtSpecz137";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs137").src = tripleZeroA;
};

function squareToSzzZValue138(){
    value35Save = "zSqrArtSpecz138";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs138").src = tripleZeroA;
};

function squareToSzzZValue139(){
    value35Save = "zSqrArtSpecz139";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs139").src = tripleZeroA;
};

function squareToSzzZValue140(){
    value35Save = "zSqrArtSpecz140";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs140").src = tripleZeroA;
};

function squareToSzzZValue141(){
    value35Save = "zSqrArtSpecz141";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs141").src = tripleZeroA;
};

function squareToSzzZValue142(){
    value35Save = "zSqrArtSpecz142";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs142").src = tripleZeroA;
};

function squareToSzzZValue143(){
    value35Save = "zSqrArtSpecz143";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs143").src = tripleZeroA;
};

function squareToSzzZValue144(){
    value35Save = "zSqrArtSpecz144";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs144").src = tripleZeroA;
};

function squareToSzzZValue145(){
    value35Save = "zSqrArtSpecz145";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs145").src = tripleZeroA;
};

function squareToSzzZValue146(){
    value35Save = "zSqrArtSpecz146";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs146").src = tripleZeroA;
};

function squareToSzzZValue147(){
    value35Save = "zSqrArtSpecz147";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs147").src = tripleZeroA;
};

function squareToSzzZValue148(){
    value35Save = "zSqrArtSpecz148";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs148").src = tripleZeroA;
};

function squareToSzzZValue149(){
    value35Save = "zSqrArtSpecz149";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs149").src = tripleZeroA;
};

function squareToSzzZValue150(){
    value35Save = "zSqrArtSpecz150";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs150").src = tripleZeroA;
};

function squareToSzzZValue151(){
    value35Save = "zSqrArtSpecz151";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs151").src = tripleZeroA;
};

function squareToSzzZValue152(){
    value35Save = "zSqrArtSpecz152";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs152").src = tripleZeroA;
};

function squareToSzzZValue153(){
    value35Save = "zSqrArtSpecz153";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs153").src = tripleZeroA;
};

function squareToSzzZValue154(){
    value35Save = "zSqrArtSpecz154";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs154").src = tripleZeroA;
};

function squareToSzzZValue155(){
    value35Save = "zSqrArtSpecz155";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs155").src = tripleZeroA;
};

function squareToSzzZValue156(){
    value35Save = "zSqrArtSpecz156";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs156").src = tripleZeroA;
};

function squareToSzzZValue157(){
    value35Save = "zSqrArtSpecz157";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs157").src = tripleZeroA;
};

function squareToSzzZValue158(){
    value35Save = "zSqrArtSpecz158";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs158").src = tripleZeroA;
};

function squareToSzzZValue159(){
    value35Save = "zSqrArtSpecz159";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs159").src = tripleZeroA;
};

function squareToSzzZValue160(){
    value35Save = "zSqrArtSpecz160";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs160").src = tripleZeroA;
};

function squareToSzzZValue161(){
    value35Save = "zSqrArtSpecz161";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs161").src = tripleZeroA;
};

function squareToSzzZValue162(){
    value35Save = "zSqrArtSpecz162";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs162").src = tripleZeroA;
};

function squareToSzzZValue163(){
    value35Save = "zSqrArtSpecz163";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs163").src = tripleZeroA;
};

function squareToSzzZValue164(){
    value35Save = "zSqrArtSpecz164";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs164").src = tripleZeroA;
};

function squareToSzzZValue165(){
    value35Save = "zSqrArtSpecz165";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs165").src = tripleZeroA;
};

function squareToSzzZValue166(){
    value35Save = "zSqrArtSpecz166";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs166").src = tripleZeroA;
};

function squareToSzzZValue167(){
    value35Save = "zSqrArtSpecz167";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs167").src = tripleZeroA;
};

function squareToSzzZValue168(){
    value35Save = "zSqrArtSpecz168";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs168").src = tripleZeroA;
};

function squareToSzzZValue169(){
    value35Save = "zSqrArtSpecz169";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs169").src = tripleZeroA;
};

function squareToSzzZValue170(){
    value35Save = "zSqrArtSpecz170";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs170").src = tripleZeroA;
};

function squareToSzzZValue171(){
    value35Save = "zSqrArtSpecz171";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs171").src = tripleZeroA;
};

function squareToSzzZValue172(){
    value35Save = "zSqrArtSpecz172";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs172").src = tripleZeroA;
};

function squareToSzzZValue173(){
    value35Save = "zSqrArtSpecz173";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs173").src = tripleZeroA;
};

function squareToSzzZValue174(){
    value35Save = "zSqrArtSpecz174";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs174").src = tripleZeroA;
};

function squareToSzzZValue175(){
    value35Save = "zSqrArtSpecz175";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs175").src = tripleZeroA;
};

function squareToSzzZValue176(){
    value35Save = "zSqrArtSpecz176";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs176").src = tripleZeroA;
};

function squareToSzzZValue177(){
    value35Save = "zSqrArtSpecz177";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs177").src = tripleZeroA;
};

function squareToSzzZValue178(){
    value35Save = "zSqrArtSpecz178";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs178").src = tripleZeroA;
};

function squareToSzzZValue179(){
    value35Save = "zSqrArtSpecz179";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs179").src = tripleZeroA;
};

function squareToSzzZValue180(){
    value35Save = "zSqrArtSpecz180";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs180").src = tripleZeroA;
};

function squareToSzzZValue181(){
    value35Save = "zSqrArtSpecz181";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs181").src = tripleZeroA;
};

function squareToSzzZValue182(){
    value35Save = "zSqrArtSpecz182";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs182").src = tripleZeroA;
};

function squareToSzzZValue183(){
    value35Save = "zSqrArtSpecz183";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs183").src = tripleZeroA;
};

function squareToSzzZValue184(){
    value35Save = "zSqrArtSpecz184";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs184").src = tripleZeroA;
};

function squareToSzzZValue185(){
    value35Save = "zSqrArtSpecz185";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs185").src = tripleZeroA;
};

function squareToSzzZValue186(){
    value35Save = "zSqrArtSpecz186";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs186").src = tripleZeroA;
};

function squareToSzzZValue187(){
    value35Save = "zSqrArtSpecz187";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs187").src = tripleZeroA;
};

function squareToSzzZValue188(){
    value35Save = "zSqrArtSpecz188";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs188").src = tripleZeroA;
};

function squareToSzzZValue189(){
    value35Save = "zSqrArtSpecz189";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs189").src = tripleZeroA;
};

function squareToSzzZValue190(){
    value35Save = "zSqrArtSpecz190";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs190").src = tripleZeroA;
};

function squareToSzzZValue191(){
    value35Save = "zSqrArtSpecz191";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs191").src = tripleZeroA;
};

function squareToSzzZValue192(){
    value35Save = "zSqrArtSpecz192";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs192").src = tripleZeroA;
};

function squareToSzzZValue193(){
    value35Save = "zSqrArtSpecz193";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs193").src = tripleZeroA;
};

function squareToSzzZValue194(){
    value35Save = "zSqrArtSpecz194";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs194").src = tripleZeroA;
};

function squareToSzzZValue195(){
    value35Save = "zSqrArtSpecz195";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs195").src = tripleZeroA;
};

function squareToSzzZValue196(){
    value35Save = "zSqrArtSpecz196";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs196").src = tripleZeroA;
};

function squareToSzzZValue197(){
    value35Save = "zSqrArtSpecz197";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs197").src = tripleZeroA;
};

function squareToSzzZValue198(){
    value35Save = "zSqrArtSpecz198";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs198").src = tripleZeroA;
};

function squareToSzzZValue199(){
    value35Save = "zSqrArtSpecz199";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs199").src = tripleZeroA;
};

function squareToSzzZValue200(){
    value35Save = "zSqrArtSpecz200";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs200").src = tripleZeroA;
};

function squareToSzzZValue201(){
    value35Save = "zSqrArtSpecz201";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs201").src = tripleZeroA;
};

function squareToSzzZValue202(){
    value35Save = "zSqrArtSpecz202";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs202").src = tripleZeroA;
};

function squareToSzzZValue203(){
    value35Save = "zSqrArtSpecz203";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs203").src = tripleZeroA;
};

function squareToSzzZValue204(){
    value35Save = "zSqrArtSpecz204";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs204").src = tripleZeroA;
};

function squareToSzzZValue205(){
    value35Save = "zSqrArtSpecz205";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs205").src = tripleZeroA;
};

function squareToSzzZValue206(){
    value35Save = "zSqrArtSpecz206";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs206").src = tripleZeroA;
};

function squareToSzzZValue207(){
    value35Save = "zSqrArtSpecz207";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs207").src = tripleZeroA;
};

function squareToSzzZValue208(){
    value35Save = "zSqrArtSpecz208";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs208").src = tripleZeroA;
};

function squareToSzzZValue209(){
    value35Save = "zSqrArtSpecz209";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs209").src = tripleZeroA;
};

function squareToSzzZValue210(){
    value35Save = "zSqrArtSpecz210";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs210").src = tripleZeroA;
};

function squareToSzzZValue211(){
    value35Save = "zSqrArtSpecz211";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs211").src = tripleZeroA;
};

function squareToSzzZValue212(){
    value35Save = "zSqrArtSpecz212";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs212").src = tripleZeroA;
};

function squareToSzzZValue213(){
    value35Save = "zSqrArtSpecz213";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs213").src = tripleZeroA;
};

function squareToSzzZValue214(){
    value35Save = "zSqrArtSpecz214";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs214").src = tripleZeroA;
};

function squareToSzzZValue215(){
    value35Save = "zSqrArtSpecz215";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs215").src = tripleZeroA;
};

function squareToSzzZValue216(){
    value35Save = "zSqrArtSpecz216";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs216").src = tripleZeroA;
};

function squareToSzzZValue217(){
    value35Save = "zSqrArtSpecz217";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs217").src = tripleZeroA;
};

function squareToSzzZValue218(){
    value35Save = "zSqrArtSpecz218";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs218").src = tripleZeroA;
};

function squareToSzzZValue219(){
    value35Save = "zSqrArtSpecz219";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs219").src = tripleZeroA;
};

function squareToSzzZValue220(){
    value35Save = "zSqrArtSpecz220";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs220").src = tripleZeroA;
};

function squareToSzzZValue221(){
    value35Save = "zSqrArtSpecz221";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs221").src = tripleZeroA;
};

function squareToSzzZValue222(){
    value35Save = "zSqrArtSpecz222";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs222").src = tripleZeroA;
};

function squareToSzzZValue223(){
    value35Save = "zSqrArtSpecz223";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs223").src = tripleZeroA;
};

function squareToSzzZValue224(){
    value35Save = "zSqrArtSpecz224";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs224").src = tripleZeroA;
};

function squareToSzzZValue225(){
    value35Save = "zSqrArtSpecz225";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs225").src = tripleZeroA;
};

function squareToSzzZValue226(){
    value35Save = "zSqrArtSpecz226";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs226").src = tripleZeroA;
};

function squareToSzzZValue227(){
    value35Save = "zSqrArtSpecz227";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs227").src = tripleZeroA;
};

function squareToSzzZValue228(){
    value35Save = "zSqrArtSpecz228";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs228").src = tripleZeroA;
};

function squareToSzzZValue229(){
    value35Save = "zSqrArtSpecz229";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs229").src = tripleZeroA;
};

function squareToSzzZValue230(){
    value35Save = "zSqrArtSpecz230";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs230").src = tripleZeroA;
};

function squareToSzzZValue231(){
    value35Save = "zSqrArtSpecz231";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs231").src = tripleZeroA;
};

function squareToSzzZValue232(){
    value35Save = "zSqrArtSpecz232";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs232").src = tripleZeroA;
};

function squareToSzzZValue233(){
    value35Save = "zSqrArtSpecz233";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs233").src = tripleZeroA;
};

function squareToSzzZValue234(){
    value35Save = "zSqrArtSpecz234";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs234").src = tripleZeroA;
};

function squareToSzzZValue235(){
    value35Save = "zSqrArtSpecz235";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs235").src = tripleZeroA;
};

function squareToSzzZValue236(){
    value35Save = "zSqrArtSpecz236";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs236").src = tripleZeroA;
};

function squareToSzzZValue237(){
    value35Save = "zSqrArtSpecz237";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs237").src = tripleZeroA;
};

function squareToSzzZValue238(){
    value35Save = "zSqrArtSpecz238";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs238").src = tripleZeroA;
};

function squareToSzzZValue239(){
    value35Save = "zSqrArtSpecz239";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs239").src = tripleZeroA;
};

function squareToSzzZValue240(){
    value35Save = "zSqrArtSpecz240";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs240").src = tripleZeroA;
};

function squareToSzzZValue241(){
    value35Save = "zSqrArtSpecz241";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs241").src = tripleZeroA;
};

function squareToSzzZValue242(){
    value35Save = "zSqrArtSpecz242";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs242").src = tripleZeroA;
};

function squareToSzzZValue243(){
    value35Save = "zSqrArtSpecz243";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs243").src = tripleZeroA;
};

function squareToSzzZValue244(){
    value35Save = "zSqrArtSpecz244";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs244").src = tripleZeroA;
};

function squareToSzzZValue245(){
    value35Save = "zSqrArtSpecz245";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs245").src = tripleZeroA;
};

function squareToSzzZValue246(){
    value35Save = "zSqrArtSpecz246";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs246").src = tripleZeroA;
};

function squareToSzzZValue247(){
    value35Save = "zSqrArtSpecz247";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs247").src = tripleZeroA;
};

function squareToSzzZValue248(){
    value35Save = "zSqrArtSpecz248";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs248").src = tripleZeroA;
};

function squareToSzzZValue249(){
    value35Save = "zSqrArtSpecz249";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs249").src = tripleZeroA;
};

function squareToSzzZValue250(){
    value35Save = "zSqrArtSpecz250";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs250").src = tripleZeroA;
};

function squareToSzzZValue251(){
    value35Save = "zSqrArtSpecz251";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs251").src = tripleZeroA;
};

function squareToSzzZValue252(){
    value35Save = "zSqrArtSpecz252";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs252").src = tripleZeroA;
};

function squareToSzzZValue253(){
    value35Save = "zSqrArtSpecz253";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs253").src = tripleZeroA;
};

function squareToSzzZValue254(){
    value35Save = "zSqrArtSpecz254";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs254").src = tripleZeroA;
};

function squareToSzzZValue255(){
    value35Save = "zSqrArtSpecz255";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs255").src = tripleZeroA;
};

function squareToSzzZValue256(){
    value35Save = "zSqrArtSpecz256";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs256").src = tripleZeroA;
};

function squareToSzzZValue257(){
    value35Save = "zSqrArtSpecz257";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs257").src = tripleZeroA;
};

function squareToSzzZValue258(){
    value35Save = "zSqrArtSpecz258";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs258").src = tripleZeroA;
};

function squareToSzzZValue259(){
    value35Save = "zSqrArtSpecz259";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs259").src = tripleZeroA;
};

function squareToSzzZValue260(){
    value35Save = "zSqrArtSpecz260";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs260").src = tripleZeroA;
};

function squareToSzzZValue261(){
    value35Save = "zSqrArtSpecz261";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs261").src = tripleZeroA;
};

function squareToSzzZValue262(){
    value35Save = "zSqrArtSpecz262";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs262").src = tripleZeroA;
};

function squareToSzzZValue263(){
    value35Save = "zSqrArtSpecz263";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs263").src = tripleZeroA;
};

function squareToSzzZValue264(){
    value35Save = "zSqrArtSpecz264";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs264").src = tripleZeroA;
};

function squareToSzzZValue265(){
    value35Save = "zSqrArtSpecz265";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs265").src = tripleZeroA;
};

function squareToSzzZValue266(){
    value35Save = "zSqrArtSpecz266";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs266").src = tripleZeroA;
};

function squareToSzzZValue267(){
    value35Save = "zSqrArtSpecz267";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs267").src = tripleZeroA;
};

function squareToSzzZValue268(){
    value35Save = "zSqrArtSpecz268";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs268").src = tripleZeroA;
};

function squareToSzzZValue269(){
    value35Save = "zSqrArtSpecz269";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs269").src = tripleZeroA;
};

function squareToSzzZValue270(){
    value35Save = "zSqrArtSpecz270";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs270").src = tripleZeroA;
};

function squareToSzzZValue271(){
    value35Save = "zSqrArtSpecz271";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs271").src = tripleZeroA;
};

function squareToSzzZValue272(){
    value35Save = "zSqrArtSpecz272";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs272").src = tripleZeroA;
};

function squareToSzzZValue273(){
    value35Save = "zSqrArtSpecz273";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs273").src = tripleZeroA;
};

function squareToSzzZValue274(){
    value35Save = "zSqrArtSpecz274";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs274").src = tripleZeroA;
};

function squareToSzzZValue275(){
    value35Save = "zSqrArtSpecz275";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs275").src = tripleZeroA;
};

function squareToSzzZValue276(){
    value35Save = "zSqrArtSpecz276";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs276").src = tripleZeroA;
};

function squareToSzzZValue277(){
    value35Save = "zSqrArtSpecz277";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs277").src = tripleZeroA;
};

function squareToSzzZValue278(){
    value35Save = "zSqrArtSpecz278";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs278").src = tripleZeroA;
};

function squareToSzzZValue279(){
    value35Save = "zSqrArtSpecz279";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs279").src = tripleZeroA;
};

function squareToSzzZValue280(){
    value35Save = "zSqrArtSpecz280";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs280").src = tripleZeroA;
};

function squareToSzzZValue281(){
    value35Save = "zSqrArtSpecz281";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs281").src = tripleZeroA;
};

function squareToSzzZValue282(){
    value35Save = "zSqrArtSpecz282";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs282").src = tripleZeroA;
};

function squareToSzzZValue283(){
    value35Save = "zSqrArtSpecz283";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs283").src = tripleZeroA;
};

function squareToSzzZValue284(){
    value35Save = "zSqrArtSpecz284";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs284").src = tripleZeroA;
};

function squareToSzzZValue285(){
    value35Save = "zSqrArtSpecz285";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs285").src = tripleZeroA;
};

function squareToSzzZValue286(){
    value35Save = "zSqrArtSpecz286";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs286").src = tripleZeroA;
};

function squareToSzzZValue287(){
    value35Save = "zSqrArtSpecz287";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs287").src = tripleZeroA;
};

function squareToSzzZValue288(){
    value35Save = "zSqrArtSpecz288";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs288").src = tripleZeroA;
};

function squareToSzzZValue289(){
    value35Save = "zSqrArtSpecz289";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs289").src = tripleZeroA;
};

function squareToSzzZValue290(){
    value35Save = "zSqrArtSpecz290";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs290").src = tripleZeroA;
};

function squareToSzzZValue291(){
    value35Save = "zSqrArtSpecz291";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs291").src = tripleZeroA;
};

function squareToSzzZValue292(){
    value35Save = "zSqrArtSpecz292";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs292").src = tripleZeroA;
};

function squareToSzzZValue293(){
    value35Save = "zSqrArtSpecz293";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs293").src = tripleZeroA;
};

function squareToSzzZValue294(){
    value35Save = "zSqrArtSpecz294";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs294").src = tripleZeroA;
};

function squareToSzzZValue295(){
    value35Save = "zSqrArtSpecz295";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs295").src = tripleZeroA;
};

function squareToSzzZValue296(){
    value35Save = "zSqrArtSpecz296";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs296").src = tripleZeroA;
};

function squareToSzzZValue297(){
    value35Save = "zSqrArtSpecz297";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs297").src = tripleZeroA;
};

function squareToSzzZValue298(){
    value35Save = "zSqrArtSpecz298";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs298").src = tripleZeroA;
};

function squareToSzzZValue299(){
    value35Save = "zSqrArtSpecz299";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs299").src = tripleZeroA;
};

function squareToSzzZValue300(){
    value35Save = "zSqrArtSpecz300";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs300").src = tripleZeroA;
};

function squareToSzzZValue301(){
    value35Save = "zSqrArtSpecz301";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs301").src = tripleZeroA;
};

function squareToSzzZValue302(){
    value35Save = "zSqrArtSpecz302";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs302").src = tripleZeroA;
};

function squareToSzzZValue303(){
    value35Save = "zSqrArtSpecz303";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs303").src = tripleZeroA;
};

function squareToSzzZValue304(){
    value35Save = "zSqrArtSpecz304";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs304").src = tripleZeroA;
};

function squareToSzzZValue305(){
    value35Save = "zSqrArtSpecz305";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs305").src = tripleZeroA;
};

function squareToSzzZValue306(){
    value35Save = "zSqrArtSpecz306";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs306").src = tripleZeroA;
};

function squareToSzzZValue307(){
    value35Save = "zSqrArtSpecz307";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs307").src = tripleZeroA;
};

function squareToSzzZValue308(){
    value35Save = "zSqrArtSpecz308";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs308").src = tripleZeroA;
};

function squareToSzzZValue309(){
    value35Save = "zSqrArtSpecz309";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs309").src = tripleZeroA;
};

function squareToSzzZValue310(){
    value35Save = "zSqrArtSpecz310";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs310").src = tripleZeroA;
};

function squareToSzzZValue311(){
    value35Save = "zSqrArtSpecz311";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs311").src = tripleZeroA;
};

function squareToSzzZValue312(){
    value35Save = "zSqrArtSpecz312";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs312").src = tripleZeroA;
};

function squareToSzzZValue313(){
    value35Save = "zSqrArtSpecz313";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs313").src = tripleZeroA;
};

function squareToSzzZValue314(){
    value35Save = "zSqrArtSpecz314";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs314").src = tripleZeroA;
};

function squareToSzzZValue315(){
    value35Save = "zSqrArtSpecz315";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs315").src = tripleZeroA;
};

function squareToSzzZValue316(){
    value35Save = "zSqrArtSpecz316";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs316").src = tripleZeroA;
};

function squareToSzzZValue317(){
    value35Save = "zSqrArtSpecz317";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs317").src = tripleZeroA;
};

function squareToSzzZValue318(){
    value35Save = "zSqrArtSpecz318";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs318").src = tripleZeroA;
};

function squareToSzzZValue319(){
    value35Save = "zSqrArtSpecz319";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs319").src = tripleZeroA;
};

function squareToSzzZValue320(){
    value35Save = "zSqrArtSpecz320";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs320").src = tripleZeroA;
};

function squareToSzzZValue321(){
    value35Save = "zSqrArtSpecz321";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs321").src = tripleZeroA;
};

function squareToSzzZValue322(){
    value35Save = "zSqrArtSpecz322";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs322").src = tripleZeroA;
};

function squareToSzzZValue323(){
    value35Save = "zSqrArtSpecz323";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs323").src = tripleZeroA;
};

function squareToSzzZValue324(){
    value35Save = "zSqrArtSpecz324";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs324").src = tripleZeroA;
};

function squareToSzzZValue325(){
    value35Save = "zSqrArtSpecz325";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs325").src = tripleZeroA;
};

function squareToSzzZValue326(){
    value35Save = "zSqrArtSpecz326";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs326").src = tripleZeroA;
};

function squareToSzzZValue327(){
    value35Save = "zSqrArtSpecz327";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs327").src = tripleZeroA;
};

function squareToSzzZValue328(){
    value35Save = "zSqrArtSpecz328";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs328").src = tripleZeroA;
};

function squareToSzzZValue329(){
    value35Save = "zSqrArtSpecz329";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs329").src = tripleZeroA;
};

function squareToSzzZValue330(){
    value35Save = "zSqrArtSpecz330";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs330").src = tripleZeroA;
};

function squareToSzzZValue331(){
    value35Save = "zSqrArtSpecz331";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs331").src = tripleZeroA;
};

function squareToSzzZValue332(){
    value35Save = "zSqrArtSpecz332";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs332").src = tripleZeroA;
};

function squareToSzzZValue333(){
    value35Save = "zSqrArtSpecz333";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs333").src = tripleZeroA;
};

function squareToSzzZValue334(){
    value35Save = "zSqrArtSpecz334";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs334").src = tripleZeroA;
};

function squareToSzzZValue335(){
    value35Save = "zSqrArtSpecz335";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs335").src = tripleZeroA;
};

function squareToSzzZValue336(){
    value35Save = "zSqrArtSpecz336";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs336").src = tripleZeroA;
};

function squareToSzzZValue337(){
    value35Save = "zSqrArtSpecz337";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs337").src = tripleZeroA;
};

function squareToSzzZValue338(){
    value35Save = "zSqrArtSpecz338";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs338").src = tripleZeroA;
};

function squareToSzzZValue339(){
    value35Save = "zSqrArtSpecz339";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs339").src = tripleZeroA;
};

function squareToSzzZValue340(){
    value35Save = "zSqrArtSpecz340";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs340").src = tripleZeroA;
};

function squareToSzzZValue341(){
    value35Save = "zSqrArtSpecz341";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs341").src = tripleZeroA;
};

function squareToSzzZValue342(){
    value35Save = "zSqrArtSpecz342";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs342").src = tripleZeroA;
};

function squareToSzzZValue343(){
    value35Save = "zSqrArtSpecz343";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs343").src = tripleZeroA;
};

function squareToSzzZValue344(){
    value35Save = "zSqrArtSpecz344";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs344").src = tripleZeroA;
};

function squareToSzzZValue345(){
    value35Save = "zSqrArtSpecz345";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs345").src = tripleZeroA;
};

function squareToSzzZValue346(){
    value35Save = "zSqrArtSpecz346";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs346").src = tripleZeroA;
};

function squareToSzzZValue347(){
    value35Save = "zSqrArtSpecz347";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs347").src = tripleZeroA;
};

function squareToSzzZValue348(){
    value35Save = "zSqrArtSpecz348";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs348").src = tripleZeroA;
};

function squareToSzzZValue349(){
    value35Save = "zSqrArtSpecz349";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs349").src = tripleZeroA;
};

function squareToSzzZValue350(){
    value35Save = "zSqrArtSpecz350";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs350").src = tripleZeroA;
};

function squareToSzzZValue351(){
    value35Save = "zSqrArtSpecz351";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs351").src = tripleZeroA;
};

function squareToSzzZValue352(){
    value35Save = "zSqrArtSpecz352";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs352").src = tripleZeroA;
};

function squareToSzzZValue353(){
    value35Save = "zSqrArtSpecz353";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs353").src = tripleZeroA;
};

function squareToSzzZValue354(){
    value35Save = "zSqrArtSpecz354";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs354").src = tripleZeroA;
};

function squareToSzzZValue355(){
    value35Save = "zSqrArtSpecz355";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs355").src = tripleZeroA;
};

function squareToSzzZValue356(){
    value35Save = "zSqrArtSpecz356";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs356").src = tripleZeroA;
};

function squareToSzzZValue357(){
    value35Save = "zSqrArtSpecz357";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs357").src = tripleZeroA;
};

function squareToSzzZValue358(){
    value35Save = "zSqrArtSpecz358";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs358").src = tripleZeroA;
};

function squareToSzzZValue359(){
    value35Save = "zSqrArtSpecz359";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs359").src = tripleZeroA;
};

function squareToSzzZValue360(){
    value35Save = "zSqrArtSpecz360";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs360").src = tripleZeroA;
};

function squareToSzzZValue361(){
    value35Save = "zSqrArtSpecz361";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs361").src = tripleZeroA;
};

function squareToSzzZValue362(){
    value35Save = "zSqrArtSpecz362";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs362").src = tripleZeroA;
};

function squareToSzzZValue363(){
    value35Save = "zSqrArtSpecz363";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs363").src = tripleZeroA;
};

function squareToSzzZValue364(){
    value35Save = "zSqrArtSpecz364";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs364").src = tripleZeroA;
};

function squareToSzzZValue365(){
    value35Save = "zSqrArtSpecz365";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs365").src = tripleZeroA;
};

function squareToSzzZValue366(){
    value35Save = "zSqrArtSpecz366";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs366").src = tripleZeroA;
};

function squareToSzzZValue367(){
    value35Save = "zSqrArtSpecz367";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs367").src = tripleZeroA;
};

function squareToSzzZValue368(){
    value35Save = "zSqrArtSpecz368";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs368").src = tripleZeroA;
};

function squareToSzzZValue369(){
    value35Save = "zSqrArtSpecz369";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs369").src = tripleZeroA;
};

function squareToSzzZValue370(){
    value35Save = "zSqrArtSpecz370";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs370").src = tripleZeroA;
};

function squareToSzzZValue371(){
    value35Save = "zSqrArtSpecz371";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs371").src = tripleZeroA;
};

function squareToSzzZValue372(){
    value35Save = "zSqrArtSpecz372";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs372").src = tripleZeroA;
};

function squareToSzzZValue373(){
    value35Save = "zSqrArtSpecz373";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs373").src = tripleZeroA;
};

function squareToSzzZValue374(){
    value35Save = "zSqrArtSpecz374";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs374").src = tripleZeroA;
};

function squareToSzzZValue375(){
    value35Save = "zSqrArtSpecz375";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs375").src = tripleZeroA;
};

function squareToSzzZValue376(){
    value35Save = "zSqrArtSpecz376";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs376").src = tripleZeroA;
};

function squareToSzzZValue377(){
    value35Save = "zSqrArtSpecz377";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs377").src = tripleZeroA;
};

function squareToSzzZValue378(){
    value35Save = "zSqrArtSpecz378";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs378").src = tripleZeroA;
};

function squareToSzzZValue379(){
    value35Save = "zSqrArtSpecz379";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs379").src = tripleZeroA;
};

function squareToSzzZValue380(){
    value35Save = "zSqrArtSpecz380";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs380").src = tripleZeroA;
};

function squareToSzzZValue381(){
    value35Save = "zSqrArtSpecz381";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs381").src = tripleZeroA;
};

function squareToSzzZValue382(){
    value35Save = "zSqrArtSpecz382";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs382").src = tripleZeroA;
};

function squareToSzzZValue383(){
    value35Save = "zSqrArtSpecz383";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs383").src = tripleZeroA;
};

function squareToSzzZValue384(){
    value35Save = "zSqrArtSpecz384";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs384").src = tripleZeroA;
};

function squareToSzzZValue385(){
    value35Save = "zSqrArtSpecz385";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs385").src = tripleZeroA;
};

function squareToSzzZValue386(){
    value35Save = "zSqrArtSpecz386";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs386").src = tripleZeroA;
};

function squareToSzzZValue387(){
    value35Save = "zSqrArtSpecz387";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs387").src = tripleZeroA;
};

function squareToSzzZValue388(){
    value35Save = "zSqrArtSpecz388";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs388").src = tripleZeroA;
};

function squareToSzzZValue389(){
    value35Save = "zSqrArtSpecz389";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs389").src = tripleZeroA;
};

function squareToSzzZValue390(){
    value35Save = "zSqrArtSpecz390";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs390").src = tripleZeroA;
};

function squareToSzzZValue391(){
    value35Save = "zSqrArtSpecz391";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs391").src = tripleZeroA;
};

function squareToSzzZValue392(){
    value35Save = "zSqrArtSpecz392";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs392").src = tripleZeroA;
};

function squareToSzzZValue393(){
    value35Save = "zSqrArtSpecz393";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs393").src = tripleZeroA;
};

function squareToSzzZValue394(){
    value35Save = "zSqrArtSpecz394";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs394").src = tripleZeroA;
};

function squareToSzzZValue395(){
    value35Save = "zSqrArtSpecz395";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs395").src = tripleZeroA;
};

function squareToSzzZValue396(){
    value35Save = "zSqrArtSpecz396";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs396").src = tripleZeroA;
};

function squareToSzzZValue397(){
    value35Save = "zSqrArtSpecz397";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs397").src = tripleZeroA;
};

function squareToSzzZValue398(){
    value35Save = "zSqrArtSpecz398";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs398").src = tripleZeroA;
};

function squareToSzzZValue399(){
    value35Save = "zSqrArtSpecz399";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs399").src = tripleZeroA;
};

function squareToSzzZValue400(){
    value35Save = "zSqrArtSpecz400";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs400").src = tripleZeroA;
};

function squareToSzzZValue401(){
    value35Save = "zSqrArtSpecz401";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs401").src = tripleZeroA;
};

function squareToSzzZValue402(){
    value35Save = "zSqrArtSpecz402";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs402").src = tripleZeroA;
};

function squareToSzzZValue403(){
    value35Save = "zSqrArtSpecz403";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs403").src = tripleZeroA;
};

function squareToSzzZValue404(){
    value35Save = "zSqrArtSpecz404";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs404").src = tripleZeroA;
};

function squareToSzzZValue405(){
    value35Save = "zSqrArtSpecz405";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs405").src = tripleZeroA;
};

function squareToSzzZValue406(){
    value35Save = "zSqrArtSpecz406";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs406").src = tripleZeroA;
};

function squareToSzzZValue407(){
    value35Save = "zSqrArtSpecz407";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs407").src = tripleZeroA;
};

function squareToSzzZValue408(){
    value35Save = "zSqrArtSpecz408";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs408").src = tripleZeroA;
};

function squareToSzzZValue409(){
    value35Save = "zSqrArtSpecz409";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs409").src = tripleZeroA;
};

function squareToSzzZValue410(){
    value35Save = "zSqrArtSpecz410";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs410").src = tripleZeroA;
};

function squareToSzzZValue411(){
    value35Save = "zSqrArtSpecz411";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs411").src = tripleZeroA;
};

function squareToSzzZValue412(){
    value35Save = "zSqrArtSpecz412";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs412").src = tripleZeroA;
};

function squareToSzzZValue413(){
    value35Save = "zSqrArtSpecz413";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs413").src = tripleZeroA;
};

function squareToSzzZValue414(){
    value35Save = "zSqrArtSpecz414";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs414").src = tripleZeroA;
};

function squareToSzzZValue415(){
    value35Save = "zSqrArtSpecz415";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs415").src = tripleZeroA;
};

function squareToSzzZValue416(){
    value35Save = "zSqrArtSpecz416";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs416").src = tripleZeroA;
};

function squareToSzzZValue417(){
    value35Save = "zSqrArtSpecz417";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs417").src = tripleZeroA;
};

function squareToSzzZValue418(){
    value35Save = "zSqrArtSpecz418";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs418").src = tripleZeroA;
};

function squareToSzzZValue419(){
    value35Save = "zSqrArtSpecz419";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs419").src = tripleZeroA;
};

function squareToSzzZValue420(){
    value35Save = "zSqrArtSpecz420";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs420").src = tripleZeroA;
};

function squareToSzzZValue421(){
    value35Save = "zSqrArtSpecz421";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs421").src = tripleZeroA;
};

function squareToSzzZValue422(){
    value35Save = "zSqrArtSpecz422";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs422").src = tripleZeroA;
};

function squareToSzzZValue423(){
    value35Save = "zSqrArtSpecz423";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs423").src = tripleZeroA;
};

function squareToSzzZValue424(){
    value35Save = "zSqrArtSpecz424";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs424").src = tripleZeroA;
};

function squareToSzzZValue425(){
    value35Save = "zSqrArtSpecz425";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs425").src = tripleZeroA;
};

function squareToSzzZValue426(){
    value35Save = "zSqrArtSpecz426";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs426").src = tripleZeroA;
};

function squareToSzzZValue427(){
    value35Save = "zSqrArtSpecz427";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs427").src = tripleZeroA;
};

function squareToSzzZValue428(){
    value35Save = "zSqrArtSpecz428";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs428").src = tripleZeroA;
};

function squareToSzzZValue429(){
    value35Save = "zSqrArtSpecz429";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs429").src = tripleZeroA;
};

function squareToSzzZValue430(){
    value35Save = "zSqrArtSpecz430";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs430").src = tripleZeroA;
};

function squareToSzzZValue431(){
    value35Save = "zSqrArtSpecz431";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs431").src = tripleZeroA;
};

function squareToSzzZValue432(){
    value35Save = "zSqrArtSpecz432";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs432").src = tripleZeroA;
};

function squareToSzzZValue433(){
    value35Save = "zSqrArtSpecz433";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs433").src = tripleZeroA;
};

function squareToSzzZValue434(){
    value35Save = "zSqrArtSpecz434";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs434").src = tripleZeroA;
};

function squareToSzzZValue435(){
    value35Save = "zSqrArtSpecz435";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs435").src = tripleZeroA;
};

function squareToSzzZValue436(){
    value35Save = "zSqrArtSpecz436";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs436").src = tripleZeroA;
};

function squareToSzzZValue437(){
    value35Save = "zSqrArtSpecz437";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs437").src = tripleZeroA;
};

function squareToSzzZValue438(){
    value35Save = "zSqrArtSpecz438";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs438").src = tripleZeroA;
};

function squareToSzzZValue439(){
    value35Save = "zSqrArtSpecz439";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs439").src = tripleZeroA;
};

function squareToSzzZValue440(){
    value35Save = "zSqrArtSpecz440";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs440").src = tripleZeroA;
};

function squareToSzzZValue441(){
    value35Save = "zSqrArtSpecz441";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs441").src = tripleZeroA;
};

function squareToSzzZValue442(){
    value35Save = "zSqrArtSpecz442";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs442").src = tripleZeroA;
};

function squareToSzzZValue443(){
    value35Save = "zSqrArtSpecz443";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs443").src = tripleZeroA;
};

function squareToSzzZValue444(){
    value35Save = "zSqrArtSpecz444";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs444").src = tripleZeroA;
};

function squareToSzzZValue445(){
    value35Save = "zSqrArtSpecz445";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs445").src = tripleZeroA;
};

function squareToSzzZValue446(){
    value35Save = "zSqrArtSpecz446";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs446").src = tripleZeroA;
};

function squareToSzzZValue447(){
    value35Save = "zSqrArtSpecz447";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs447").src = tripleZeroA;
};

function squareToSzzZValue448(){
    value35Save = "zSqrArtSpecz448";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs448").src = tripleZeroA;
};

function squareToSzzZValue449(){
    value35Save = "zSqrArtSpecz449";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs449").src = tripleZeroA;
};

function squareToSzzZValue450(){
    value35Save = "zSqrArtSpecz450";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs450").src = tripleZeroA;
};

function squareToSzzZValue451(){
    value35Save = "zSqrArtSpecz451";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs451").src = tripleZeroA;
};

function squareToSzzZValue452(){
    value35Save = "zSqrArtSpecz452";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs452").src = tripleZeroA;
};

function squareToSzzZValue453(){
    value35Save = "zSqrArtSpecz453";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs453").src = tripleZeroA;
};

function squareToSzzZValue454(){
    value35Save = "zSqrArtSpecz454";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs454").src = tripleZeroA;
};

function squareToSzzZValue455(){
    value35Save = "zSqrArtSpecz455";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs455").src = tripleZeroA;
};

function squareToSzzZValue456(){
    value35Save = "zSqrArtSpecz456";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs456").src = tripleZeroA;
};

function squareToSzzZValue457(){
    value35Save = "zSqrArtSpecz457";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs457").src = tripleZeroA;
};

function squareToSzzZValue458(){
    value35Save = "zSqrArtSpecz458";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs458").src = tripleZeroA;
};

function squareToSzzZValue459(){
    value35Save = "zSqrArtSpecz459";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs459").src = tripleZeroA;
};

function squareToSzzZValue460(){
    value35Save = "zSqrArtSpecz460";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs460").src = tripleZeroA;
};

function squareToSzzZValue461(){
    value35Save = "zSqrArtSpecz461";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs461").src = tripleZeroA;
};

function squareToSzzZValue462(){
    value35Save = "zSqrArtSpecz462";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs462").src = tripleZeroA;
};

function squareToSzzZValue463(){
    value35Save = "zSqrArtSpecz463";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs463").src = tripleZeroA;
};

function squareToSzzZValue464(){
    value35Save = "zSqrArtSpecz464";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs464").src = tripleZeroA;
};

function squareToSzzZValue465(){
    value35Save = "zSqrArtSpecz465";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs465").src = tripleZeroA;
};

function squareToSzzZValue466(){
    value35Save = "zSqrArtSpecz466";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs466").src = tripleZeroA;
};

function squareToSzzZValue467(){
    value35Save = "zSqrArtSpecz467";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs467").src = tripleZeroA;
};

function squareToSzzZValue468(){
    value35Save = "zSqrArtSpecz468";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs468").src = tripleZeroA;
};

function squareToSzzZValue469(){
    value35Save = "zSqrArtSpecz469";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs469").src = tripleZeroA;
};

function squareToSzzZValue470(){
    value35Save = "zSqrArtSpecz470";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs470").src = tripleZeroA;
};

function squareToSzzZValue471(){
    value35Save = "zSqrArtSpecz471";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs471").src = tripleZeroA;
};

function squareToSzzZValue472(){
    value35Save = "zSqrArtSpecz472";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs472").src = tripleZeroA;
};

function squareToSzzZValue473(){
    value35Save = "zSqrArtSpecz473";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs473").src = tripleZeroA;
};

function squareToSzzZValue474(){
    value35Save = "zSqrArtSpecz474";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs474").src = tripleZeroA;
};

function squareToSzzZValue475(){
    value35Save = "zSqrArtSpecz475";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs475").src = tripleZeroA;
};

function squareToSzzZValue476(){
    value35Save = "zSqrArtSpecz476";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs476").src = tripleZeroA;
};

function squareToSzzZValue477(){
    value35Save = "zSqrArtSpecz477";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs477").src = tripleZeroA;
};

function squareToSzzZValue478(){
    value35Save = "zSqrArtSpecz478";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs478").src = tripleZeroA;
};

function squareToSzzZValue479(){
    value35Save = "zSqrArtSpecz479";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs479").src = tripleZeroA;
};

function squareToSzzZValue480(){
    value35Save = "zSqrArtSpecz480";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs480").src = tripleZeroA;
};

function squareToSzzZValue481(){
    value35Save = "zSqrArtSpecz481";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs481").src = tripleZeroA;
};

function squareToSzzZValue482(){
    value35Save = "zSqrArtSpecz482";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs482").src = tripleZeroA;
};

function squareToSzzZValue483(){
    value35Save = "zSqrArtSpecz483";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs483").src = tripleZeroA;
};

function squareToSzzZValue484(){
    value35Save = "zSqrArtSpecz484";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs484").src = tripleZeroA;
};

function squareToSzzZValue485(){
    value35Save = "zSqrArtSpecz485";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs485").src = tripleZeroA;
};

function squareToSzzZValue486(){
    value35Save = "zSqrArtSpecz486";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs486").src = tripleZeroA;
};

function squareToSzzZValue487(){
    value35Save = "zSqrArtSpecz487";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs487").src = tripleZeroA;
};

function squareToSzzZValue488(){
    value35Save = "zSqrArtSpecz488";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs488").src = tripleZeroA;
};

function squareToSzzZValue489(){
    value35Save = "zSqrArtSpecz489";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs489").src = tripleZeroA;
};

function squareToSzzZValue490(){
    value35Save = "zSqrArtSpecz490";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs490").src = tripleZeroA;
};

function squareToSzzZValue491(){
    value35Save = "zSqrArtSpecz491";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs491").src = tripleZeroA;
};

function squareToSzzZValue492(){
    value35Save = "zSqrArtSpecz492";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs492").src = tripleZeroA;
};

function squareToSzzZValue493(){
    value35Save = "zSqrArtSpecz493";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs493").src = tripleZeroA;
};

function squareToSzzZValue494(){
    value35Save = "zSqrArtSpecz494";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs494").src = tripleZeroA;
};

function squareToSzzZValue495(){
    value35Save = "zSqrArtSpecz495";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs495").src = tripleZeroA;
};

function squareToSzzZValue496(){
    value35Save = "zSqrArtSpecz496";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs496").src = tripleZeroA;
};

function squareToSzzZValue497(){
    value35Save = "zSqrArtSpecz497";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs497").src = tripleZeroA;
};

function squareToSzzZValue498(){
    value35Save = "zSqrArtSpecz498";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs498").src = tripleZeroA;
};

function squareToSzzZValue499(){
    value35Save = "zSqrArtSpecz499";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs499").src = tripleZeroA;
};

function squareToSzzZValue500(){
    value35Save = "zSqrArtSpecz500";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs500").src = tripleZeroA;
};

function squareToSzzZValue501(){
    value35Save = "zSqrArtSpecz501";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs501").src = tripleZeroA;
};

function squareToSzzZValue502(){
    value35Save = "zSqrArtSpecz502";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs502").src = tripleZeroA;
};

function squareToSzzZValue503(){
    value35Save = "zSqrArtSpecz503";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs503").src = tripleZeroA;
};

function squareToSzzZValue504(){
    value35Save = "zSqrArtSpecz504";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs504").src = tripleZeroA;
};

function squareToSzzZValue505(){
    value35Save = "zSqrArtSpecz505";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs505").src = tripleZeroA;
};

function squareToSzzZValue506(){
    value35Save = "zSqrArtSpecz506";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs506").src = tripleZeroA;
};

function squareToSzzZValue507(){
    value35Save = "zSqrArtSpecz507";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs507").src = tripleZeroA;
};

function squareToSzzZValue508(){
    value35Save = "zSqrArtSpecz508";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs508").src = tripleZeroA;
};

function squareToSzzZValue509(){
    value35Save = "zSqrArtSpecz509";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs509").src = tripleZeroA;
};

function squareToSzzZValue510(){
    value35Save = "zSqrArtSpecz510";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs510").src = tripleZeroA;
};

function squareToSzzZValue511(){
    value35Save = "zSqrArtSpecz511";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs511").src = tripleZeroA;
};

function squareToSzzZValue512(){
    value35Save = "zSqrArtSpecz512";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs512").src = tripleZeroA;
};

function squareToSzzZValue513(){
    value35Save = "zSqrArtSpecz513";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs513").src = tripleZeroA;
};

function squareToSzzZValue514(){
    value35Save = "zSqrArtSpecz514";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs514").src = tripleZeroA;
};

function squareToSzzZValue515(){
    value35Save = "zSqrArtSpecz515";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs515").src = tripleZeroA;
};

function squareToSzzZValue516(){
    value35Save = "zSqrArtSpecz516";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs516").src = tripleZeroA;
};

function squareToSzzZValue517(){
    value35Save = "zSqrArtSpecz517";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs517").src = tripleZeroA;
};

function squareToSzzZValue518(){
    value35Save = "zSqrArtSpecz518";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs518").src = tripleZeroA;
};

function squareToSzzZValue519(){
    value35Save = "zSqrArtSpecz519";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs519").src = tripleZeroA;
};

function squareToSzzZValue520(){
    value35Save = "zSqrArtSpecz520";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs520").src = tripleZeroA;
};

function squareToSzzZValue521(){
    value35Save = "zSqrArtSpecz521";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs521").src = tripleZeroA;
};

function squareToSzzZValue522(){
    value35Save = "zSqrArtSpecz522";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs522").src = tripleZeroA;
};

function squareToSzzZValue523(){
    value35Save = "zSqrArtSpecz523";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs523").src = tripleZeroA;
};

function squareToSzzZValue524(){
    value35Save = "zSqrArtSpecz524";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs524").src = tripleZeroA;
};

function squareToSzzZValue525(){
    value35Save = "zSqrArtSpecz525";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs525").src = tripleZeroA;
};

function squareToSzzZValue526(){
    value35Save = "zSqrArtSpecz526";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs526").src = tripleZeroA;
};

function squareToSzzZValue527(){
    value35Save = "zSqrArtSpecz527";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs527").src = tripleZeroA;
};

function squareToSzzZValue528(){
    value35Save = "zSqrArtSpecz528";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs528").src = tripleZeroA;
};

function squareToSzzZValue529(){
    value35Save = "zSqrArtSpecz529";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs529").src = tripleZeroA;
};

function squareToSzzZValue530(){
    value35Save = "zSqrArtSpecz530";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs530").src = tripleZeroA;
};

function squareToSzzZValue531(){
    value35Save = "zSqrArtSpecz531";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs531").src = tripleZeroA;
};

function squareToSzzZValue532(){
    value35Save = "zSqrArtSpecz532";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs532").src = tripleZeroA;
};

function squareToSzzZValue533(){
    value35Save = "zSqrArtSpecz533";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs533").src = tripleZeroA;
};

function squareToSzzZValue534(){
    value35Save = "zSqrArtSpecz534";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs534").src = tripleZeroA;
};

function squareToSzzZValue535(){
    value35Save = "zSqrArtSpecz535";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs535").src = tripleZeroA;
};

function squareToSzzZValue536(){
    value35Save = "zSqrArtSpecz536";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs536").src = tripleZeroA;
};

function squareToSzzZValue537(){
    value35Save = "zSqrArtSpecz537";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs537").src = tripleZeroA;
};

function squareToSzzZValue538(){
    value35Save = "zSqrArtSpecz538";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs538").src = tripleZeroA;
};

function squareToSzzZValue539(){
    value35Save = "zSqrArtSpecz539";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs539").src = tripleZeroA;
};

function squareToSzzZValue540(){
    value35Save = "zSqrArtSpecz540";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs540").src = tripleZeroA;
};

function squareToSzzZValue541(){
    value35Save = "zSqrArtSpecz541";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs541").src = tripleZeroA;
};

function squareToSzzZValue542(){
    value35Save = "zSqrArtSpecz542";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs542").src = tripleZeroA;
};

function squareToSzzZValue543(){
    value35Save = "zSqrArtSpecz543";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs543").src = tripleZeroA;
};

function squareToSzzZValue544(){
    value35Save = "zSqrArtSpecz544";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs544").src = tripleZeroA;
};

function squareToSzzZValue545(){
    value35Save = "zSqrArtSpecz545";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs545").src = tripleZeroA;
};

function squareToSzzZValue546(){
    value35Save = "zSqrArtSpecz546";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs546").src = tripleZeroA;
};

function squareToSzzZValue547(){
    value35Save = "zSqrArtSpecz547";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs547").src = tripleZeroA;
};

function squareToSzzZValue548(){
    value35Save = "zSqrArtSpecz548";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs548").src = tripleZeroA;
};

function squareToSzzZValue549(){
    value35Save = "zSqrArtSpecz549";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs549").src = tripleZeroA;
};

function squareToSzzZValue550(){
    value35Save = "zSqrArtSpecz550";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs550").src = tripleZeroA;
};

function squareToSzzZValue551(){
    value35Save = "zSqrArtSpecz551";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs551").src = tripleZeroA;
};

function squareToSzzZValue552(){
    value35Save = "zSqrArtSpecz552";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs552").src = tripleZeroA;
};

function squareToSzzZValue553(){
    value35Save = "zSqrArtSpecz553";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs553").src = tripleZeroA;
};

function squareToSzzZValue554(){
    value35Save = "zSqrArtSpecz554";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs554").src = tripleZeroA;
};

function squareToSzzZValue555(){
    value35Save = "zSqrArtSpecz555";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs555").src = tripleZeroA;
};

function squareToSzzZValue556(){
    value35Save = "zSqrArtSpecz556";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs556").src = tripleZeroA;
};

function squareToSzzZValue557(){
    value35Save = "zSqrArtSpecz557";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs557").src = tripleZeroA;
};

function squareToSzzZValue558(){
    value35Save = "zSqrArtSpecz558";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs558").src = tripleZeroA;
};

function squareToSzzZValue559(){
    value35Save = "zSqrArtSpecz559";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs559").src = tripleZeroA;
};

function squareToSzzZValue560(){
    value35Save = "zSqrArtSpecz560";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs560").src = tripleZeroA;
};

function squareToSzzZValue561(){
    value35Save = "zSqrArtSpecz561";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs561").src = tripleZeroA;
};

function squareToSzzZValue562(){
    value35Save = "zSqrArtSpecz562";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs562").src = tripleZeroA;
};

function squareToSzzZValue563(){
    value35Save = "zSqrArtSpecz563";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs563").src = tripleZeroA;
};

function squareToSzzZValue564(){
    value35Save = "zSqrArtSpecz564";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs564").src = tripleZeroA;
};

function squareToSzzZValue565(){
    value35Save = "zSqrArtSpecz565";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs565").src = tripleZeroA;
};

function squareToSzzZValue566(){
    value35Save = "zSqrArtSpecz566";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs566").src = tripleZeroA;
};

function squareToSzzZValue567(){
    value35Save = "zSqrArtSpecz567";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs567").src = tripleZeroA;
};

function squareToSzzZValue568(){
    value35Save = "zSqrArtSpecz568";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs568").src = tripleZeroA;
};

function squareToSzzZValue569(){
    value35Save = "zSqrArtSpecz569";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs569").src = tripleZeroA;
};

function squareToSzzZValue570(){
    value35Save = "zSqrArtSpecz570";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs570").src = tripleZeroA;
};

function squareToSzzZValue571(){
    value35Save = "zSqrArtSpecz571";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs571").src = tripleZeroA;
};

function squareToSzzZValue572(){
    value35Save = "zSqrArtSpecz572";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs572").src = tripleZeroA;
};

function squareToSzzZValue573(){
    value35Save = "zSqrArtSpecz573";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs573").src = tripleZeroA;
};

function squareToSzzZValue574(){
    value35Save = "zSqrArtSpecz574";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs574").src = tripleZeroA;
};

function squareToSzzZValue575(){
    value35Save = "zSqrArtSpecz575";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs575").src = tripleZeroA;
};

function squareToSzzZValue576(){
    value35Save = "zSqrArtSpecz576";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs576").src = tripleZeroA;
};

function squareToSzzZValue577(){
    value35Save = "zSqrArtSpecz577";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs577").src = tripleZeroA;
};

function squareToSzzZValue578(){
    value35Save = "zSqrArtSpecz578";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs578").src = tripleZeroA;
};

function squareToSzzZValue579(){
    value35Save = "zSqrArtSpecz579";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs579").src = tripleZeroA;
};

function squareToSzzZValue580(){
    value35Save = "zSqrArtSpecz580";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs580").src = tripleZeroA;
};

function squareToSzzZValue581(){
    value35Save = "zSqrArtSpecz581";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs581").src = tripleZeroA;
};

function squareToSzzZValue582(){
    value35Save = "zSqrArtSpecz582";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs582").src = tripleZeroA;
};

function squareToSzzZValue583(){
    value35Save = "zSqrArtSpecz583";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs583").src = tripleZeroA;
};

function squareToSzzZValue584(){
    value35Save = "zSqrArtSpecz584";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs584").src = tripleZeroA;
};

function squareToSzzZValue585(){
    value35Save = "zSqrArtSpecz585";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs585").src = tripleZeroA;
};

function squareToSzzZValue586(){
    value35Save = "zSqrArtSpecz586";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs586").src = tripleZeroA;
};

function squareToSzzZValue587(){
    value35Save = "zSqrArtSpecz587";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs587").src = tripleZeroA;
};

function squareToSzzZValue588(){
    value35Save = "zSqrArtSpecz588";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs588").src = tripleZeroA;
};

function squareToSzzZValue589(){
    value35Save = "zSqrArtSpecz589";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs589").src = tripleZeroA;
};

function squareToSzzZValue590(){
    value35Save = "zSqrArtSpecz590";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs590").src = tripleZeroA;
};

function squareToSzzZValue591(){
    value35Save = "zSqrArtSpecz591";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs591").src = tripleZeroA;
};

function squareToSzzZValue592(){
    value35Save = "zSqrArtSpecz592";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs592").src = tripleZeroA;
};

function squareToSzzZValue593(){
    value35Save = "zSqrArtSpecz593";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs593").src = tripleZeroA;
};

function squareToSzzZValue594(){
    value35Save = "zSqrArtSpecz594";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs594").src = tripleZeroA;
};

function squareToSzzZValue595(){
    value35Save = "zSqrArtSpecz595";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs595").src = tripleZeroA;
};

function squareToSzzZValue596(){
    value35Save = "zSqrArtSpecz596";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs596").src = tripleZeroA;
};

function squareToSzzZValue597(){
    value35Save = "zSqrArtSpecz597";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs597").src = tripleZeroA;
};

function squareToSzzZValue598(){
    value35Save = "zSqrArtSpecz598";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs598").src = tripleZeroA;
};

function squareToSzzZValue599(){
    value35Save = "zSqrArtSpecz599";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs599").src = tripleZeroA;
};

function squareToSzzZValue600(){
    value35Save = "zSqrArtSpecz600";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs600").src = tripleZeroA;
};

function squareToSzzZValue601(){
    value35Save = "zSqrArtSpecz601";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs601").src = tripleZeroA;
};

function squareToSzzZValue602(){
    value35Save = "zSqrArtSpecz602";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs602").src = tripleZeroA;
};

function squareToSzzZValue603(){
    value35Save = "zSqrArtSpecz603";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs603").src = tripleZeroA;
};

function squareToSzzZValue604(){
    value35Save = "zSqrArtSpecz604";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs604").src = tripleZeroA;
};

function squareToSzzZValue605(){
    value35Save = "zSqrArtSpecz605";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs605").src = tripleZeroA;
};

function squareToSzzZValue606(){
    value35Save = "zSqrArtSpecz606";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs606").src = tripleZeroA;
};

function squareToSzzZValue607(){
    value35Save = "zSqrArtSpecz607";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs607").src = tripleZeroA;
};

function squareToSzzZValue608(){
    value35Save = "zSqrArtSpecz608";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs608").src = tripleZeroA;
};

function squareToSzzZValue609(){
    value35Save = "zSqrArtSpecz609";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs609").src = tripleZeroA;
};

function squareToSzzZValue610(){
    value35Save = "zSqrArtSpecz610";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs610").src = tripleZeroA;
};

function squareToSzzZValue611(){
    value35Save = "zSqrArtSpecz611";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs611").src = tripleZeroA;
};

function squareToSzzZValue612(){
    value35Save = "zSqrArtSpecz612";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs612").src = tripleZeroA;
};

function squareToSzzZValue613(){
    value35Save = "zSqrArtSpecz613";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs613").src = tripleZeroA;
};

function squareToSzzZValue614(){
    value35Save = "zSqrArtSpecz614";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs614").src = tripleZeroA;
};

function squareToSzzZValue615(){
    value35Save = "zSqrArtSpecz615";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs615").src = tripleZeroA;
};

function squareToSzzZValue616(){
    value35Save = "zSqrArtSpecz616";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs616").src = tripleZeroA;
};

function squareToSzzZValue617(){
    value35Save = "zSqrArtSpecz617";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs617").src = tripleZeroA;
};

function squareToSzzZValue618(){
    value35Save = "zSqrArtSpecz618";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs618").src = tripleZeroA;
};

function squareToSzzZValue619(){
    value35Save = "zSqrArtSpecz619";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs619").src = tripleZeroA;
};

function squareToSzzZValue620(){
    value35Save = "zSqrArtSpecz620";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs620").src = tripleZeroA;
};

function squareToSzzZValue621(){
    value35Save = "zSqrArtSpecz621";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs621").src = tripleZeroA;
};

function squareToSzzZValue622(){
    value35Save = "zSqrArtSpecz622";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs622").src = tripleZeroA;
};

function squareToSzzZValue623(){
    value35Save = "zSqrArtSpecz623";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs623").src = tripleZeroA;
};

function squareToSzzZValue624(){
    value35Save = "zSqrArtSpecz624";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs624").src = tripleZeroA;
};

function squareToSzzZValue625(){
    value35Save = "zSqrArtSpecz625";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs625").src = tripleZeroA;
};

function squareToSzzZValue626(){
    value35Save = "zSqrArtSpecz626";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs626").src = tripleZeroA;
};

function squareToSzzZValue627(){
    value35Save = "zSqrArtSpecz627";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs627").src = tripleZeroA;
};

function squareToSzzZValue628(){
    value35Save = "zSqrArtSpecz628";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs628").src = tripleZeroA;
};

function squareToSzzZValue629(){
    value35Save = "zSqrArtSpecz629";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs629").src = tripleZeroA;
};

function squareToSzzZValue630(){
    value35Save = "zSqrArtSpecz630";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs630").src = tripleZeroA;
};

function squareToSzzZValue631(){
    value35Save = "zSqrArtSpecz631";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs631").src = tripleZeroA;
};

function squareToSzzZValue632(){
    value35Save = "zSqrArtSpecz632";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs632").src = tripleZeroA;
};

function squareToSzzZValue633(){
    value35Save = "zSqrArtSpecz633";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs633").src = tripleZeroA;
};

function squareToSzzZValue634(){
    value35Save = "zSqrArtSpecz634";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs634").src = tripleZeroA;
};

function squareToSzzZValue635(){
    value35Save = "zSqrArtSpecz635";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs635").src = tripleZeroA;
};

function squareToSzzZValue636(){
    value35Save = "zSqrArtSpecz636";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs636").src = tripleZeroA;
};

function squareToSzzZValue637(){
    value35Save = "zSqrArtSpecz637";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs637").src = tripleZeroA;
};

function squareToSzzZValue638(){
    value35Save = "zSqrArtSpecz638";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs638").src = tripleZeroA;
};

function squareToSzzZValue639(){
    value35Save = "zSqrArtSpecz639";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs639").src = tripleZeroA;
};

function squareToSzzZValue640(){
    value35Save = "zSqrArtSpecz640";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs640").src = tripleZeroA;
};

function squareToSzzZValue641(){
    value35Save = "zSqrArtSpecz641";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs641").src = tripleZeroA;
};

function squareToSzzZValue642(){
    value35Save = "zSqrArtSpecz642";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs642").src = tripleZeroA;
};

function squareToSzzZValue643(){
    value35Save = "zSqrArtSpecz643";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs643").src = tripleZeroA;
};

function squareToSzzZValue644(){
    value35Save = "zSqrArtSpecz644";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs644").src = tripleZeroA;
};

function squareToSzzZValue645(){
    value35Save = "zSqrArtSpecz645";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs645").src = tripleZeroA;
};

function squareToSzzZValue646(){
    value35Save = "zSqrArtSpecz646";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs646").src = tripleZeroA;
};

function squareToSzzZValue647(){
    value35Save = "zSqrArtSpecz647";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs647").src = tripleZeroA;
};

function squareToSzzZValue648(){
    value35Save = "zSqrArtSpecz648";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs648").src = tripleZeroA;
};

function squareToSzzZValue649(){
    value35Save = "zSqrArtSpecz649";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs649").src = tripleZeroA;
};

function squareToSzzZValue650(){
    value35Save = "zSqrArtSpecz650";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs650").src = tripleZeroA;
};

function squareToSzzZValue651(){
    value35Save = "zSqrArtSpecz651";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs651").src = tripleZeroA;
};

function squareToSzzZValue652(){
    value35Save = "zSqrArtSpecz652";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs652").src = tripleZeroA;
};

function squareToSzzZValue653(){
    value35Save = "zSqrArtSpecz653";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs653").src = tripleZeroA;
};

function squareToSzzZValue654(){
    value35Save = "zSqrArtSpecz654";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs654").src = tripleZeroA;
};

function squareToSzzZValue655(){
    value35Save = "zSqrArtSpecz655";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs655").src = tripleZeroA;
};

function squareToSzzZValue656(){
    value35Save = "zSqrArtSpecz656";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs656").src = tripleZeroA;
};

function squareToSzzZValue657(){
    value35Save = "zSqrArtSpecz657";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs657").src = tripleZeroA;
};

function squareToSzzZValue658(){
    value35Save = "zSqrArtSpecz658";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs658").src = tripleZeroA;
};

function squareToSzzZValue659(){
    value35Save = "zSqrArtSpecz659";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs659").src = tripleZeroA;
};

function squareToSzzZValue660(){
    value35Save = "zSqrArtSpecz660";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs660").src = tripleZeroA;
};

function squareToSzzZValue661(){
    value35Save = "zSqrArtSpecz661";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs661").src = tripleZeroA;
};

function squareToSzzZValue662(){
    value35Save = "zSqrArtSpecz662";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs662").src = tripleZeroA;
};

function squareToSzzZValue663(){
    value35Save = "zSqrArtSpecz663";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs663").src = tripleZeroA;
};

function squareToSzzZValue664(){
    value35Save = "zSqrArtSpecz664";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs664").src = tripleZeroA;
};

function squareToSzzZValue665(){
    value35Save = "zSqrArtSpecz665";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs665").src = tripleZeroA;
};

function squareToSzzZValue666(){
    value35Save = "zSqrArtSpecz666";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs666").src = tripleZeroA;
};

function squareToSzzZValue667(){
    value35Save = "zSqrArtSpecz667";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs667").src = tripleZeroA;
};

function squareToSzzZValue668(){
    value35Save = "zSqrArtSpecz668";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs668").src = tripleZeroA;
};

function squareToSzzZValue669(){
    value35Save = "zSqrArtSpecz669";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs669").src = tripleZeroA;
};

function squareToSzzZValue670(){
    value35Save = "zSqrArtSpecz670";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs670").src = tripleZeroA;
};

function squareToSzzZValue671(){
    value35Save = "zSqrArtSpecz671";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs671").src = tripleZeroA;
};

function squareToSzzZValue672(){
    value35Save = "zSqrArtSpecz672";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs672").src = tripleZeroA;
};

function squareToSzzZValue673(){
    value35Save = "zSqrArtSpecz673";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs673").src = tripleZeroA;
};

function squareToSzzZValue674(){
    value35Save = "zSqrArtSpecz674";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs674").src = tripleZeroA;
};

function squareToSzzZValue675(){
    value35Save = "zSqrArtSpecz675";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs675").src = tripleZeroA;
};

function squareToSzzZValue676(){
    value35Save = "zSqrArtSpecz676";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs676").src = tripleZeroA;
};

function squareToSzzZValue677(){
    value35Save = "zSqrArtSpecz677";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs677").src = tripleZeroA;
};

function squareToSzzZValue678(){
    value35Save = "zSqrArtSpecz678";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs678").src = tripleZeroA;
};

function squareToSzzZValue679(){
    value35Save = "zSqrArtSpecz679";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs679").src = tripleZeroA;
};

function squareToSzzZValue680(){
    value35Save = "zSqrArtSpecz680";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs680").src = tripleZeroA;
};

function squareToSzzZValue681(){
    value35Save = "zSqrArtSpecz681";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs681").src = tripleZeroA;
};

function squareToSzzZValue682(){
    value35Save = "zSqrArtSpecz682";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs682").src = tripleZeroA;
};

function squareToSzzZValue683(){
    value35Save = "zSqrArtSpecz683";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs683").src = tripleZeroA;
};

function squareToSzzZValue684(){
    value35Save = "zSqrArtSpecz684";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs684").src = tripleZeroA;
};

function squareToSzzZValue685(){
    value35Save = "zSqrArtSpecz685";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs685").src = tripleZeroA;
};

function squareToSzzZValue686(){
    value35Save = "zSqrArtSpecz686";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs686").src = tripleZeroA;
};

function squareToSzzZValue687(){
    value35Save = "zSqrArtSpecz687";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs687").src = tripleZeroA;
};

function squareToSzzZValue688(){
    value35Save = "zSqrArtSpecz688";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs688").src = tripleZeroA;
};

function squareToSzzZValue689(){
    value35Save = "zSqrArtSpecz689";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs689").src = tripleZeroA;
};

function squareToSzzZValue690(){
    value35Save = "zSqrArtSpecz690";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs690").src = tripleZeroA;
};

function squareToSzzZValue691(){
    value35Save = "zSqrArtSpecz691";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs691").src = tripleZeroA;
};

function squareToSzzZValue692(){
    value35Save = "zSqrArtSpecz692";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs692").src = tripleZeroA;
};

function squareToSzzZValue693(){
    value35Save = "zSqrArtSpecz693";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs693").src = tripleZeroA;
};

function squareToSzzZValue694(){
    value35Save = "zSqrArtSpecz694";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs694").src = tripleZeroA;
};

function squareToSzzZValue695(){
    value35Save = "zSqrArtSpecz695";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs695").src = tripleZeroA;
};

function squareToSzzZValue696(){
    value35Save = "zSqrArtSpecz696";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs696").src = tripleZeroA;
};

function squareToSzzZValue697(){
    value35Save = "zSqrArtSpecz697";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs697").src = tripleZeroA;
};

function squareToSzzZValue698(){
    value35Save = "zSqrArtSpecz698";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs698").src = tripleZeroA;
};

function squareToSzzZValue699(){
    value35Save = "zSqrArtSpecz699";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs699").src = tripleZeroA;
};

function squareToSzzZValue700(){
    value35Save = "zSqrArtSpecz700";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs700").src = tripleZeroA;
};

function squareToSzzZValue701(){
    value35Save = "zSqrArtSpecz701";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs701").src = tripleZeroA;
};

function squareToSzzZValue702(){
    value35Save = "zSqrArtSpecz702";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs702").src = tripleZeroA;
};

function squareToSzzZValue703(){
    value35Save = "zSqrArtSpecz703";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs703").src = tripleZeroA;
};

function squareToSzzZValue704(){
    value35Save = "zSqrArtSpecz704";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs704").src = tripleZeroA;
};

function squareToSzzZValue705(){
    value35Save = "zSqrArtSpecz705";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs705").src = tripleZeroA;
};

function squareToSzzZValue706(){
    value35Save = "zSqrArtSpecz706";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs706").src = tripleZeroA;
};

function squareToSzzZValue707(){
    value35Save = "zSqrArtSpecz707";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs707").src = tripleZeroA;
};

function squareToSzzZValue708(){
    value35Save = "zSqrArtSpecz708";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs708").src = tripleZeroA;
};

function squareToSzzZValue709(){
    value35Save = "zSqrArtSpecz709";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs709").src = tripleZeroA;
};

function squareToSzzZValue710(){
    value35Save = "zSqrArtSpecz710";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs710").src = tripleZeroA;
};

function squareToSzzZValue711(){
    value35Save = "zSqrArtSpecz711";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs711").src = tripleZeroA;
};

function squareToSzzZValue712(){
    value35Save = "zSqrArtSpecz712";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs712").src = tripleZeroA;
};

function squareToSzzZValue713(){
    value35Save = "zSqrArtSpecz713";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs713").src = tripleZeroA;
};

function squareToSzzZValue714(){
    value35Save = "zSqrArtSpecz714";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs714").src = tripleZeroA;
};

function squareToSzzZValue715(){
    value35Save = "zSqrArtSpecz715";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs715").src = tripleZeroA;
};

function squareToSzzZValue716(){
    value35Save = "zSqrArtSpecz716";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs716").src = tripleZeroA;
};

function squareToSzzZValue717(){
    value35Save = "zSqrArtSpecz717";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs717").src = tripleZeroA;
};

function squareToSzzZValue718(){
    value35Save = "zSqrArtSpecz718";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs718").src = tripleZeroA;
};

function squareToSzzZValue719(){
    value35Save = "zSqrArtSpecz719";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs719").src = tripleZeroA;
};

function squareToSzzZValue720(){
    value35Save = "zSqrArtSpecz720";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs720").src = tripleZeroA;
};

function squareToSzzZValue721(){
    value35Save = "zSqrArtSpecz721";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs721").src = tripleZeroA;
};

function squareToSzzZValue722(){
    value35Save = "zSqrArtSpecz722";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs722").src = tripleZeroA;
};

function squareToSzzZValue723(){
    value35Save = "zSqrArtSpecz723";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs723").src = tripleZeroA;
};

function squareToSzzZValue724(){
    value35Save = "zSqrArtSpecz724";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs724").src = tripleZeroA;
};

function squareToSzzZValue725(){
    value35Save = "zSqrArtSpecz725";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs725").src = tripleZeroA;
};

function squareToSzzZValue726(){
    value35Save = "zSqrArtSpecz726";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs726").src = tripleZeroA;
};

function squareToSzzZValue727(){
    value35Save = "zSqrArtSpecz727";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs727").src = tripleZeroA;
};

function squareToSzzZValue728(){
    value35Save = "zSqrArtSpecz728";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs728").src = tripleZeroA;
};

function squareToSzzZValue729(){
    value35Save = "zSqrArtSpecz729";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs729").src = tripleZeroA;
};

function squareToSzzZValue730(){
    value35Save = "zSqrArtSpecz730";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs730").src = tripleZeroA;
};

function squareToSzzZValue731(){
    value35Save = "zSqrArtSpecz731";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs731").src = tripleZeroA;
};

function squareToSzzZValue732(){
    value35Save = "zSqrArtSpecz732";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs732").src = tripleZeroA;
};

function squareToSzzZValue733(){
    value35Save = "zSqrArtSpecz733";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs733").src = tripleZeroA;
};

function squareToSzzZValue734(){
    value35Save = "zSqrArtSpecz734";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs734").src = tripleZeroA;
};

function squareToSzzZValue735(){
    value35Save = "zSqrArtSpecz735";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs735").src = tripleZeroA;
};

function squareToSzzZValue736(){
    value35Save = "zSqrArtSpecz736";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs736").src = tripleZeroA;
};

function squareToSzzZValue737(){
    value35Save = "zSqrArtSpecz737";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs737").src = tripleZeroA;
};

function squareToSzzZValue738(){
    value35Save = "zSqrArtSpecz738";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs738").src = tripleZeroA;
};

function squareToSzzZValue739(){
    value35Save = "zSqrArtSpecz739";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs739").src = tripleZeroA;
};

function squareToSzzZValue740(){
    value35Save = "zSqrArtSpecz740";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs740").src = tripleZeroA;
};

function squareToSzzZValue741(){
    value35Save = "zSqrArtSpecz741";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs741").src = tripleZeroA;
};

function squareToSzzZValue742(){
    value35Save = "zSqrArtSpecz742";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs742").src = tripleZeroA;
};

function squareToSzzZValue743(){
    value35Save = "zSqrArtSpecz743";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs743").src = tripleZeroA;
};

function squareToSzzZValue744(){
    value35Save = "zSqrArtSpecz744";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs744").src = tripleZeroA;
};

function squareToSzzZValue745(){
    value35Save = "zSqrArtSpecz745";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs745").src = tripleZeroA;
};

function squareToSzzZValue746(){
    value35Save = "zSqrArtSpecz746";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs746").src = tripleZeroA;
};

function squareToSzzZValue747(){
    value35Save = "zSqrArtSpecz747";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs747").src = tripleZeroA;
};

function squareToSzzZValue748(){
    value35Save = "zSqrArtSpecz748";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs748").src = tripleZeroA;
};

function squareToSzzZValue749(){
    value35Save = "zSqrArtSpecz749";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs749").src = tripleZeroA;
};

function squareToSzzZValue750(){
    value35Save = "zSqrArtSpecz750";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs750").src = tripleZeroA;
};

function squareToSzzZValue751(){
    value35Save = "zSqrArtSpecz751";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs751").src = tripleZeroA;
};

function squareToSzzZValue752(){
    value35Save = "zSqrArtSpecz752";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs752").src = tripleZeroA;
};

function squareToSzzZValue753(){
    value35Save = "zSqrArtSpecz753";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs753").src = tripleZeroA;
};

function squareToSzzZValue754(){
    value35Save = "zSqrArtSpecz754";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs754").src = tripleZeroA;
};

function squareToSzzZValue755(){
    value35Save = "zSqrArtSpecz755";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs755").src = tripleZeroA;
};

function squareToSzzZValue756(){
    value35Save = "zSqrArtSpecz756";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs756").src = tripleZeroA;
};

function squareToSzzZValue757(){
    value35Save = "zSqrArtSpecz757";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs757").src = tripleZeroA;
};

function squareToSzzZValue758(){
    value35Save = "zSqrArtSpecz758";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs758").src = tripleZeroA;
};

function squareToSzzZValue759(){
    value35Save = "zSqrArtSpecz759";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs759").src = tripleZeroA;
};

function squareToSzzZValue760(){
    value35Save = "zSqrArtSpecz760";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs760").src = tripleZeroA;
};

function squareToSzzZValue761(){
    value35Save = "zSqrArtSpecz761";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs761").src = tripleZeroA;
};

function squareToSzzZValue762(){
    value35Save = "zSqrArtSpecz762";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs762").src = tripleZeroA;
};

function squareToSzzZValue763(){
    value35Save = "zSqrArtSpecz763";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs763").src = tripleZeroA;
};

function squareToSzzZValue764(){
    value35Save = "zSqrArtSpecz764";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs764").src = tripleZeroA;
};

function squareToSzzZValue765(){
    value35Save = "zSqrArtSpecz765";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs765").src = tripleZeroA;
};

function squareToSzzZValue766(){
    value35Save = "zSqrArtSpecz766";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs766").src = tripleZeroA;
};

function squareToSzzZValue767(){
    value35Save = "zSqrArtSpecz767";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs767").src = tripleZeroA;
};

function squareToSzzZValue768(){
    value35Save = "zSqrArtSpecz768";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs768").src = tripleZeroA;
};

function squareToSzzZValue769(){
    value35Save = "zSqrArtSpecz769";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs769").src = tripleZeroA;
};

function squareToSzzZValue770(){
    value35Save = "zSqrArtSpecz770";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs770").src = tripleZeroA;
};

function squareToSzzZValue771(){
    value35Save = "zSqrArtSpecz771";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs771").src = tripleZeroA;
};

function squareToSzzZValue772(){
    value35Save = "zSqrArtSpecz772";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs772").src = tripleZeroA;
};

function squareToSzzZValue773(){
    value35Save = "zSqrArtSpecz773";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs773").src = tripleZeroA;
};

function squareToSzzZValue774(){
    value35Save = "zSqrArtSpecz774";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs774").src = tripleZeroA;
};

function squareToSzzZValue775(){
    value35Save = "zSqrArtSpecz775";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs775").src = tripleZeroA;
};

function squareToSzzZValue776(){
    value35Save = "zSqrArtSpecz776";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs776").src = tripleZeroA;
};

function squareToSzzZValue777(){
    value35Save = "zSqrArtSpecz777";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs777").src = tripleZeroA;
};

function squareToSzzZValue778(){
    value35Save = "zSqrArtSpecz778";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs778").src = tripleZeroA;
};

function squareToSzzZValue779(){
    value35Save = "zSqrArtSpecz779";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs779").src = tripleZeroA;
};

function squareToSzzZValue780(){
    value35Save = "zSqrArtSpecz780";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs780").src = tripleZeroA;
};

function squareToSzzZValue781(){
    value35Save = "zSqrArtSpecz781";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs781").src = tripleZeroA;
};

function squareToSzzZValue782(){
    value35Save = "zSqrArtSpecz782";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs782").src = tripleZeroA;
};

function squareToSzzZValue783(){
    value35Save = "zSqrArtSpecz783";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs783").src = tripleZeroA;
};

function squareToSzzZValue784(){
    value35Save = "zSqrArtSpecz784";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs784").src = tripleZeroA;
};

function squareToSzzZValue785(){
    value35Save = "zSqrArtSpecz785";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs785").src = tripleZeroA;
};

function squareToSzzZValue786(){
    value35Save = "zSqrArtSpecz786";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs786").src = tripleZeroA;
};

function squareToSzzZValue787(){
    value35Save = "zSqrArtSpecz787";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs787").src = tripleZeroA;
};

function squareToSzzZValue788(){
    value35Save = "zSqrArtSpecz788";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs788").src = tripleZeroA;
};

function squareToSzzZValue789(){
    value35Save = "zSqrArtSpecz789";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs789").src = tripleZeroA;
};

function squareToSzzZValue790(){
    value35Save = "zSqrArtSpecz790";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs790").src = tripleZeroA;
};

function squareToSzzZValue791(){
    value35Save = "zSqrArtSpecz791";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs791").src = tripleZeroA;
};

function squareToSzzZValue792(){
    value35Save = "zSqrArtSpecz792";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs792").src = tripleZeroA;
};

function squareToSzzZValue793(){
    value35Save = "zSqrArtSpecz793";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs793").src = tripleZeroA;
};

function squareToSzzZValue794(){
    value35Save = "zSqrArtSpecz794";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs794").src = tripleZeroA;
};

function squareToSzzZValue795(){
    value35Save = "zSqrArtSpecz795";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs795").src = tripleZeroA;
};

function squareToSzzZValue796(){
    value35Save = "zSqrArtSpecz796";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs796").src = tripleZeroA;
};

function squareToSzzZValue797(){
    value35Save = "zSqrArtSpecz797";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs797").src = tripleZeroA;
};

function squareToSzzZValue798(){
    value35Save = "zSqrArtSpecz798";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs798").src = tripleZeroA;
};

function squareToSzzZValue799(){
    value35Save = "zSqrArtSpecz799";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs799").src = tripleZeroA;
};

function squareToSzzZValue800(){
    value35Save = "zSqrArtSpecz800";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs800").src = tripleZeroA;
};

function squareToSzzZValue801(){
    value35Save = "zSqrArtSpecz801";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs801").src = tripleZeroA;
};

function squareToSzzZValue802(){
    value35Save = "zSqrArtSpecz802";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs802").src = tripleZeroA;
};

function squareToSzzZValue803(){
    value35Save = "zSqrArtSpecz803";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs803").src = tripleZeroA;
};

function squareToSzzZValue804(){
    value35Save = "zSqrArtSpecz804";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs804").src = tripleZeroA;
};

function squareToSzzZValue805(){
    value35Save = "zSqrArtSpecz805";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs805").src = tripleZeroA;
};

function squareToSzzZValue806(){
    value35Save = "zSqrArtSpecz806";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs806").src = tripleZeroA;
};

function squareToSzzZValue807(){
    value35Save = "zSqrArtSpecz807";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs807").src = tripleZeroA;
};

function squareToSzzZValue808(){
    value35Save = "zSqrArtSpecz808";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs808").src = tripleZeroA;
};

function squareToSzzZValue809(){
    value35Save = "zSqrArtSpecz809";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs809").src = tripleZeroA;
};

function squareToSzzZValue810(){
    value35Save = "zSqrArtSpecz810";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs810").src = tripleZeroA;
};

function squareToSzzZValue811(){
    value35Save = "zSqrArtSpecz811";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs811").src = tripleZeroA;
};

function squareToSzzZValue812(){
    value35Save = "zSqrArtSpecz812";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs812").src = tripleZeroA;
};

function squareToSzzZValue813(){
    value35Save = "zSqrArtSpecz813";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs813").src = tripleZeroA;
};

function squareToSzzZValue814(){
    value35Save = "zSqrArtSpecz814";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs814").src = tripleZeroA;
};

function squareToSzzZValue815(){
    value35Save = "zSqrArtSpecz815";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs815").src = tripleZeroA;
};

function squareToSzzZValue816(){
    value35Save = "zSqrArtSpecz816";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs816").src = tripleZeroA;
};

function squareToSzzZValue817(){
    value35Save = "zSqrArtSpecz817";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs817").src = tripleZeroA;
};

function squareToSzzZValue818(){
    value35Save = "zSqrArtSpecz818";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs818").src = tripleZeroA;
};

function squareToSzzZValue819(){
    value35Save = "zSqrArtSpecz819";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs819").src = tripleZeroA;
};

function squareToSzzZValue820(){
    value35Save = "zSqrArtSpecz820";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs820").src = tripleZeroA;
};

function squareToSzzZValue821(){
    value35Save = "zSqrArtSpecz821";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs821").src = tripleZeroA;
};

function squareToSzzZValue822(){
    value35Save = "zSqrArtSpecz822";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs822").src = tripleZeroA;
};

function squareToSzzZValue823(){
    value35Save = "zSqrArtSpecz823";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs823").src = tripleZeroA;
};

function squareToSzzZValue824(){
    value35Save = "zSqrArtSpecz824";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs824").src = tripleZeroA;
};

function squareToSzzZValue825(){
    value35Save = "zSqrArtSpecz825";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs825").src = tripleZeroA;
};

function squareToSzzZValue826(){
    value35Save = "zSqrArtSpecz826";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs826").src = tripleZeroA;
};

function squareToSzzZValue827(){
    value35Save = "zSqrArtSpecz827";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs827").src = tripleZeroA;
};

function squareToSzzZValue828(){
    value35Save = "zSqrArtSpecz828";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs828").src = tripleZeroA;
};

function squareToSzzZValue829(){
    value35Save = "zSqrArtSpecz829";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs829").src = tripleZeroA;
};

function squareToSzzZValue830(){
    value35Save = "zSqrArtSpecz830";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs830").src = tripleZeroA;
};

function squareToSzzZValue831(){
    value35Save = "zSqrArtSpecz831";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs831").src = tripleZeroA;
};

function squareToSzzZValue832(){
    value35Save = "zSqrArtSpecz832";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs832").src = tripleZeroA;
};

function squareToSzzZValue833(){
    value35Save = "zSqrArtSpecz833";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs833").src = tripleZeroA;
};

function squareToSzzZValue834(){
    value35Save = "zSqrArtSpecz834";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs834").src = tripleZeroA;
};

function squareToSzzZValue835(){
    value35Save = "zSqrArtSpecz835";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs835").src = tripleZeroA;
};

function squareToSzzZValue836(){
    value35Save = "zSqrArtSpecz836";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs836").src = tripleZeroA;
};

function squareToSzzZValue837(){
    value35Save = "zSqrArtSpecz837";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs837").src = tripleZeroA;
};

function squareToSzzZValue838(){
    value35Save = "zSqrArtSpecz838";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs838").src = tripleZeroA;
};

function squareToSzzZValue839(){
    value35Save = "zSqrArtSpecz839";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs839").src = tripleZeroA;
};

function squareToSzzZValue840(){
    value35Save = "zSqrArtSpecz840";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs840").src = tripleZeroA;
};

function squareToSzzZValue841(){
    value35Save = "zSqrArtSpecz841";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs841").src = tripleZeroA;
};

function squareToSzzZValue842(){
    value35Save = "zSqrArtSpecz842";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs842").src = tripleZeroA;
};

function squareToSzzZValue843(){
    value35Save = "zSqrArtSpecz843";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs843").src = tripleZeroA;
};

function squareToSzzZValue844(){
    value35Save = "zSqrArtSpecz844";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs844").src = tripleZeroA;
};

function squareToSzzZValue845(){
    value35Save = "zSqrArtSpecz845";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs845").src = tripleZeroA;
};

function squareToSzzZValue846(){
    value35Save = "zSqrArtSpecz846";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs846").src = tripleZeroA;
};

function squareToSzzZValue847(){
    value35Save = "zSqrArtSpecz847";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs847").src = tripleZeroA;
};

function squareToSzzZValue848(){
    value35Save = "zSqrArtSpecz848";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs848").src = tripleZeroA;
};

function squareToSzzZValue849(){
    value35Save = "zSqrArtSpecz849";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs849").src = tripleZeroA;
};

function squareToSzzZValue850(){
    value35Save = "zSqrArtSpecz850";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs850").src = tripleZeroA;
};

function squareToSzzZValue851(){
    value35Save = "zSqrArtSpecz851";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs851").src = tripleZeroA;
};

function squareToSzzZValue852(){
    value35Save = "zSqrArtSpecz852";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs852").src = tripleZeroA;
};

function squareToSzzZValue853(){
    value35Save = "zSqrArtSpecz853";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs853").src = tripleZeroA;
};

function squareToSzzZValue854(){
    value35Save = "zSqrArtSpecz854";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs854").src = tripleZeroA;
};

function squareToSzzZValue855(){
    value35Save = "zSqrArtSpecz855";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs855").src = tripleZeroA;
};

function squareToSzzZValue856(){
    value35Save = "zSqrArtSpecz856";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs856").src = tripleZeroA;
};

function squareToSzzZValue857(){
    value35Save = "zSqrArtSpecz857";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs857").src = tripleZeroA;
};

function squareToSzzZValue858(){
    value35Save = "zSqrArtSpecz858";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs858").src = tripleZeroA;
};

function squareToSzzZValue859(){
    value35Save = "zSqrArtSpecz859";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs859").src = tripleZeroA;
};

function squareToSzzZValue860(){
    value35Save = "zSqrArtSpecz860";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs860").src = tripleZeroA;
};

function squareToSzzZValue861(){
    value35Save = "zSqrArtSpecz861";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs861").src = tripleZeroA;
};

function squareToSzzZValue862(){
    value35Save = "zSqrArtSpecz862";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs862").src = tripleZeroA;
};

function squareToSzzZValue863(){
    value35Save = "zSqrArtSpecz863";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs863").src = tripleZeroA;
};

function squareToSzzZValue864(){
    value35Save = "zSqrArtSpecz864";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs864").src = tripleZeroA;
};

function squareToSzzZValue865(){
    value35Save = "zSqrArtSpecz865";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs865").src = tripleZeroA;
};

function squareToSzzZValue866(){
    value35Save = "zSqrArtSpecz866";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs866").src = tripleZeroA;
};

function squareToSzzZValue867(){
    value35Save = "zSqrArtSpecz867";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs867").src = tripleZeroA;
};

function squareToSzzZValue868(){
    value35Save = "zSqrArtSpecz868";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs868").src = tripleZeroA;
};

function squareToSzzZValue869(){
    value35Save = "zSqrArtSpecz869";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs869").src = tripleZeroA;
};

function squareToSzzZValue870(){
    value35Save = "zSqrArtSpecz870";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs870").src = tripleZeroA;
};

function squareToSzzZValue871(){
    value35Save = "zSqrArtSpecz871";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs871").src = tripleZeroA;
};

function squareToSzzZValue872(){
    value35Save = "zSqrArtSpecz872";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs872").src = tripleZeroA;
};

function squareToSzzZValue873(){
    value35Save = "zSqrArtSpecz873";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs873").src = tripleZeroA;
};

function squareToSzzZValue874(){
    value35Save = "zSqrArtSpecz874";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs874").src = tripleZeroA;
};

function squareToSzzZValue875(){
    value35Save = "zSqrArtSpecz875";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs875").src = tripleZeroA;
};

function squareToSzzZValue876(){
    value35Save = "zSqrArtSpecz876";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs876").src = tripleZeroA;
};

function squareToSzzZValue877(){
    value35Save = "zSqrArtSpecz877";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs877").src = tripleZeroA;
};

function squareToSzzZValue878(){
    value35Save = "zSqrArtSpecz878";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs878").src = tripleZeroA;
};

function squareToSzzZValue879(){
    value35Save = "zSqrArtSpecz879";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs879").src = tripleZeroA;
};

function squareToSzzZValue880(){
    value35Save = "zSqrArtSpecz880";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs880").src = tripleZeroA;
};

function squareToSzzZValue881(){
    value35Save = "zSqrArtSpecz881";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs881").src = tripleZeroA;
};

function squareToSzzZValue882(){
    value35Save = "zSqrArtSpecz882";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs882").src = tripleZeroA;
};

function squareToSzzZValue883(){
    value35Save = "zSqrArtSpecz883";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs883").src = tripleZeroA;
};

function squareToSzzZValue884(){
    value35Save = "zSqrArtSpecz884";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs884").src = tripleZeroA;
};

function squareToSzzZValue885(){
    value35Save = "zSqrArtSpecz885";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs885").src = tripleZeroA;
};

function squareToSzzZValue886(){
    value35Save = "zSqrArtSpecz886";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs886").src = tripleZeroA;
};

function squareToSzzZValue887(){
    value35Save = "zSqrArtSpecz887";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs887").src = tripleZeroA;
};

function squareToSzzZValue888(){
    value35Save = "zSqrArtSpecz888";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs888").src = tripleZeroA;
};

function squareToSzzZValue889(){
    value35Save = "zSqrArtSpecz889";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs889").src = tripleZeroA;
};

function squareToSzzZValue890(){
    value35Save = "zSqrArtSpecz890";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs890").src = tripleZeroA;
};

function squareToSzzZValue891(){
    value35Save = "zSqrArtSpecz891";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs891").src = tripleZeroA;
};

function squareToSzzZValue892(){
    value35Save = "zSqrArtSpecz892";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs892").src = tripleZeroA;
};

function squareToSzzZValue893(){
    value35Save = "zSqrArtSpecz893";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs893").src = tripleZeroA;
};

function squareToSzzZValue894(){
    value35Save = "zSqrArtSpecz894";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs894").src = tripleZeroA;
};

function squareToSzzZValue895(){
    value35Save = "zSqrArtSpecz895";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs895").src = tripleZeroA;
};

function squareToSzzZValue896(){
    value35Save = "zSqrArtSpecz896";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs896").src = tripleZeroA;
};

function squareToSzzZValue897(){
    value35Save = "zSqrArtSpecz897";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs897").src = tripleZeroA;
};

function squareToSzzZValue898(){
    value35Save = "zSqrArtSpecz898";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs898").src = tripleZeroA;
};

function squareToSzzZValue899(){
    value35Save = "zSqrArtSpecz899";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs899").src = tripleZeroA;
};

function squareToSzzZValue900(){
    value35Save = "zSqrArtSpecz900";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs900").src = tripleZeroA;
};

function squareToSzzZValue901(){
    value35Save = "zSqrArtSpecz901";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs901").src = tripleZeroA;
};

function squareToSzzZValue902(){
    value35Save = "zSqrArtSpecz902";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs902").src = tripleZeroA;
};

function squareToSzzZValue903(){
    value35Save = "zSqrArtSpecz903";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs903").src = tripleZeroA;
};

function squareToSzzZValue904(){
    value35Save = "zSqrArtSpecz904";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs904").src = tripleZeroA;
};

function squareToSzzZValue905(){
    value35Save = "zSqrArtSpecz905";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs905").src = tripleZeroA;
};

function squareToSzzZValue906(){
    value35Save = "zSqrArtSpecz906";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs906").src = tripleZeroA;
};

function squareToSzzZValue907(){
    value35Save = "zSqrArtSpecz907";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs907").src = tripleZeroA;
};

function squareToSzzZValue908(){
    value35Save = "zSqrArtSpecz908";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs908").src = tripleZeroA;
};

function squareToSzzZValue909(){
    value35Save = "zSqrArtSpecz909";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs909").src = tripleZeroA;
};

function squareToSzzZValue910(){
    value35Save = "zSqrArtSpecz910";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs910").src = tripleZeroA;
};

function squareToSzzZValue911(){
    value35Save = "zSqrArtSpecz911";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs911").src = tripleZeroA;
};

function squareToSzzZValue912(){
    value35Save = "zSqrArtSpecz912";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs912").src = tripleZeroA;
};

function squareToSzzZValue913(){
    value35Save = "zSqrArtSpecz913";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs913").src = tripleZeroA;
};

function squareToSzzZValue914(){
    value35Save = "zSqrArtSpecz914";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs914").src = tripleZeroA;
};

function squareToSzzZValue915(){
    value35Save = "zSqrArtSpecz915";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs915").src = tripleZeroA;
};

function squareToSzzZValue916(){
    value35Save = "zSqrArtSpecz916";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs916").src = tripleZeroA;
};

function squareToSzzZValue917(){
    value35Save = "zSqrArtSpecz917";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs917").src = tripleZeroA;
};

function squareToSzzZValue918(){
    value35Save = "zSqrArtSpecz918";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs918").src = tripleZeroA;
};

function squareToSzzZValue919(){
    value35Save = "zSqrArtSpecz919";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs919").src = tripleZeroA;
};

function squareToSzzZValue920(){
    value35Save = "zSqrArtSpecz920";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs920").src = tripleZeroA;
};

function squareToSzzZValue921(){
    value35Save = "zSqrArtSpecz921";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs921").src = tripleZeroA;
};

function squareToSzzZValue922(){
    value35Save = "zSqrArtSpecz922";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs922").src = tripleZeroA;
};

function squareToSzzZValue923(){
    value35Save = "zSqrArtSpecz923";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs923").src = tripleZeroA;
};

function squareToSzzZValue924(){
    value35Save = "zSqrArtSpecz924";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs924").src = tripleZeroA;
};

function squareToSzzZValue925(){
    value35Save = "zSqrArtSpecz925";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs925").src = tripleZeroA;
};

function squareToSzzZValue926(){
    value35Save = "zSqrArtSpecz926";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs926").src = tripleZeroA;
};

function squareToSzzZValue927(){
    value35Save = "zSqrArtSpecz927";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs927").src = tripleZeroA;
};

function squareToSzzZValue928(){
    value35Save = "zSqrArtSpecz928";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs928").src = tripleZeroA;
};

function squareToSzzZValue929(){
    value35Save = "zSqrArtSpecz929";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs929").src = tripleZeroA;
};

function squareToSzzZValue930(){
    value35Save = "zSqrArtSpecz930";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs930").src = tripleZeroA;
};

function squareToSzzZValue931(){
    value35Save = "zSqrArtSpecz931";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs931").src = tripleZeroA;
};

function squareToSzzZValue932(){
    value35Save = "zSqrArtSpecz932";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs932").src = tripleZeroA;
};

function squareToSzzZValue933(){
    value35Save = "zSqrArtSpecz933";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs933").src = tripleZeroA;
};

function squareToSzzZValue934(){
    value35Save = "zSqrArtSpecz934";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs934").src = tripleZeroA;
};

function squareToSzzZValue935(){
    value35Save = "zSqrArtSpecz935";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs935").src = tripleZeroA;
};

function squareToSzzZValue936(){
    value35Save = "zSqrArtSpecz936";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs936").src = tripleZeroA;
};

function squareToSzzZValue937(){
    value35Save = "zSqrArtSpecz937";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs937").src = tripleZeroA;
};

function squareToSzzZValue938(){
    value35Save = "zSqrArtSpecz938";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs938").src = tripleZeroA;
};

function squareToSzzZValue939(){
    value35Save = "zSqrArtSpecz939";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs939").src = tripleZeroA;
};

function squareToSzzZValue940(){
    value35Save = "zSqrArtSpecz940";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs940").src = tripleZeroA;
};

function squareToSzzZValue941(){
    value35Save = "zSqrArtSpecz941";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs941").src = tripleZeroA;
};

function squareToSzzZValue942(){
    value35Save = "zSqrArtSpecz942";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs942").src = tripleZeroA;
};

function squareToSzzZValue943(){
    value35Save = "zSqrArtSpecz943";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs943").src = tripleZeroA;
};

function squareToSzzZValue944(){
    value35Save = "zSqrArtSpecz944";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs944").src = tripleZeroA;
};

function squareToSzzZValue945(){
    value35Save = "zSqrArtSpecz945";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs945").src = tripleZeroA;
};

function squareToSzzZValue946(){
    value35Save = "zSqrArtSpecz946";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs946").src = tripleZeroA;
};

function squareToSzzZValue947(){
    value35Save = "zSqrArtSpecz947";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs947").src = tripleZeroA;
};

function squareToSzzZValue948(){
    value35Save = "zSqrArtSpecz948";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs948").src = tripleZeroA;
};

function squareToSzzZValue949(){
    value35Save = "zSqrArtSpecz949";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs949").src = tripleZeroA;
};

function squareToSzzZValue950(){
    value35Save = "zSqrArtSpecz950";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs950").src = tripleZeroA;
};

function squareToSzzZValue951(){
    value35Save = "zSqrArtSpecz951";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs951").src = tripleZeroA;
};

function squareToSzzZValue952(){
    value35Save = "zSqrArtSpecz952";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs952").src = tripleZeroA;
};

function squareToSzzZValue953(){
    value35Save = "zSqrArtSpecz953";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs953").src = tripleZeroA;
};

function squareToSzzZValue954(){
    value35Save = "zSqrArtSpecz954";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs954").src = tripleZeroA;
};

function squareToSzzZValue955(){
    value35Save = "zSqrArtSpecz955";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs955").src = tripleZeroA;
};

function squareToSzzZValue956(){
    value35Save = "zSqrArtSpecz956";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs956").src = tripleZeroA;
};

function squareToSzzZValue957(){
    value35Save = "zSqrArtSpecz957";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs957").src = tripleZeroA;
};

function squareToSzzZValue958(){
    value35Save = "zSqrArtSpecz958";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs958").src = tripleZeroA;
};

function squareToSzzZValue959(){
    value35Save = "zSqrArtSpecz959";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs959").src = tripleZeroA;
};

function squareToSzzZValue960(){
    value35Save = "zSqrArtSpecz960";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs960").src = tripleZeroA;
};

function squareToSzzZValue961(){
    value35Save = "zSqrArtSpecz961";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs961").src = tripleZeroA;
};

function squareToSzzZValue962(){
    value35Save = "zSqrArtSpecz962";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs962").src = tripleZeroA;
};

function squareToSzzZValue963(){
    value35Save = "zSqrArtSpecz963";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs963").src = tripleZeroA;
};

function squareToSzzZValue964(){
    value35Save = "zSqrArtSpecz964";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs964").src = tripleZeroA;
};

function squareToSzzZValue965(){
    value35Save = "zSqrArtSpecz965";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs965").src = tripleZeroA;
};

function squareToSzzZValue966(){
    value35Save = "zSqrArtSpecz966";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs966").src = tripleZeroA;
};

function squareToSzzZValue967(){
    value35Save = "zSqrArtSpecz967";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs967").src = tripleZeroA;
};

function squareToSzzZValue968(){
    value35Save = "zSqrArtSpecz968";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs968").src = tripleZeroA;
};

function squareToSzzZValue969(){
    value35Save = "zSqrArtSpecz969";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs969").src = tripleZeroA;
};

function squareToSzzZValue970(){
    value35Save = "zSqrArtSpecz970";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs970").src = tripleZeroA;
};

function squareToSzzZValue971(){
    value35Save = "zSqrArtSpecz971";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs971").src = tripleZeroA;
};

function squareToSzzZValue972(){
    value35Save = "zSqrArtSpecz972";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs972").src = tripleZeroA;
};

function squareToSzzZValue973(){
    value35Save = "zSqrArtSpecz973";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs973").src = tripleZeroA;
};

function squareToSzzZValue974(){
    value35Save = "zSqrArtSpecz974";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs974").src = tripleZeroA;
};

function squareToSzzZValue975(){
    value35Save = "zSqrArtSpecz975";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs975").src = tripleZeroA;
};

function squareToSzzZValue976(){
    value35Save = "zSqrArtSpecz976";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs976").src = tripleZeroA;
};

function squareToSzzZValue977(){
    value35Save = "zSqrArtSpecz977";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs977").src = tripleZeroA;
};

function squareToSzzZValue978(){
    value35Save = "zSqrArtSpecz978";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs978").src = tripleZeroA;
};

function squareToSzzZValue979(){
    value35Save = "zSqrArtSpecz979";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs979").src = tripleZeroA;
};

function squareToSzzZValue980(){
    value35Save = "zSqrArtSpecz980";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs980").src = tripleZeroA;
};

function squareToSzzZValue981(){
    value35Save = "zSqrArtSpecz981";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs981").src = tripleZeroA;
};

function squareToSzzZValue982(){
    value35Save = "zSqrArtSpecz982";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs982").src = tripleZeroA;
};

function squareToSzzZValue983(){
    value35Save = "zSqrArtSpecz983";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs983").src = tripleZeroA;
};

function squareToSzzZValue984(){
    value35Save = "zSqrArtSpecz984";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs984").src = tripleZeroA;
};

function squareToSzzZValue985(){
    value35Save = "zSqrArtSpecz985";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs985").src = tripleZeroA;
};

function squareToSzzZValue986(){
    value35Save = "zSqrArtSpecz986";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs986").src = tripleZeroA;
};

function squareToSzzZValue987(){
    value35Save = "zSqrArtSpecz987";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs987").src = tripleZeroA;
};

function squareToSzzZValue988(){
    value35Save = "zSqrArtSpecz988";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs988").src = tripleZeroA;
};

function squareToSzzZValue989(){
    value35Save = "zSqrArtSpecz989";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs989").src = tripleZeroA;
};

function squareToSzzZValue990(){
    value35Save = "zSqrArtSpecz990";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs990").src = tripleZeroA;
};

function squareToSzzZValue991(){
    value35Save = "zSqrArtSpecz991";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs991").src = tripleZeroA;
};

function squareToSzzZValue992(){
    value35Save = "zSqrArtSpecz992";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs992").src = tripleZeroA;
};

function squareToSzzZValue993(){
    value35Save = "zSqrArtSpecz993";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs993").src = tripleZeroA;
};

function squareToSzzZValue994(){
    value35Save = "zSqrArtSpecz994";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs994").src = tripleZeroA;
};

function squareToSzzZValue995(){
    value35Save = "zSqrArtSpecz995";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs995").src = tripleZeroA;
};

function squareToSzzZValue996(){
    value35Save = "zSqrArtSpecz996";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs996").src = tripleZeroA;
};

function squareToSzzZValue997(){
    value35Save = "zSqrArtSpecz997";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs997").src = tripleZeroA;
};

function squareToSzzZValue998(){
    value35Save = "zSqrArtSpecz998";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs998").src = tripleZeroA;
};

function squareToSzzZValue999(){
    value35Save = "zSqrArtSpecz999";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs999").src = tripleZeroA;
};

function squareToSzzZValue1000(){
    value35Save = "zSqrArtSpecz1000";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1000").src = tripleZeroA;
};

function squareToSzzZValue1001(){
    value35Save = "zSqrArtSpecz1001";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1001").src = tripleZeroA;
};

function squareToSzzZValue1002(){
    value35Save = "zSqrArtSpecz1002";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1002").src = tripleZeroA;
};

function squareToSzzZValue1003(){
    value35Save = "zSqrArtSpecz1003";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1003").src = tripleZeroA;
};

function squareToSzzZValue1004(){
    value35Save = "zSqrArtSpecz1004";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1004").src = tripleZeroA;
};

function squareToSzzZValue1005(){
    value35Save = "zSqrArtSpecz1005";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1005").src = tripleZeroA;
};

function squareToSzzZValue1006(){
    value35Save = "zSqrArtSpecz1006";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1006").src = tripleZeroA;
};

function squareToSzzZValue1007(){
    value35Save = "zSqrArtSpecz1007";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1007").src = tripleZeroA;
};

function squareToSzzZValue1008(){
    value35Save = "zSqrArtSpecz1008";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1008").src = tripleZeroA;
};

function squareToSzzZValue1009(){
    value35Save = "zSqrArtSpecz1009";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1009").src = tripleZeroA;
};

function squareToSzzZValue1010(){
    value35Save = "zSqrArtSpecz1010";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1010").src = tripleZeroA;
};

function squareToSzzZValue1011(){
    value35Save = "zSqrArtSpecz1011";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1011").src = tripleZeroA;
};

function squareToSzzZValue1012(){
    value35Save = "zSqrArtSpecz1012";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1012").src = tripleZeroA;
};

function squareToSzzZValue1013(){
    value35Save = "zSqrArtSpecz1013";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1013").src = tripleZeroA;
};

function squareToSzzZValue1014(){
    value35Save = "zSqrArtSpecz1014";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1014").src = tripleZeroA;
};

function squareToSzzZValue1015(){
    value35Save = "zSqrArtSpecz1015";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1015").src = tripleZeroA;
};

function squareToSzzZValue1016(){
    value35Save = "zSqrArtSpecz1016";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1016").src = tripleZeroA;
};

function squareToSzzZValue1017(){
    value35Save = "zSqrArtSpecz1017";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1017").src = tripleZeroA;
};

function squareToSzzZValue1018(){
    value35Save = "zSqrArtSpecz1018";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1018").src = tripleZeroA;
};

function squareToSzzZValue1019(){
    value35Save = "zSqrArtSpecz1019";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1019").src = tripleZeroA;
};

function squareToSzzZValue1020(){
    value35Save = "zSqrArtSpecz1020";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1020").src = tripleZeroA;
};

function squareToSzzZValue1021(){
    value35Save = "zSqrArtSpecz1021";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1021").src = tripleZeroA;
};

function squareToSzzZValue1022(){
    value35Save = "zSqrArtSpecz1022";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1022").src = tripleZeroA;
};

function squareToSzzZValue1023(){
    value35Save = "zSqrArtSpecz1023";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1023").src = tripleZeroA;
};

function squareToSzzZValue1024(){
    value35Save = "zSqrArtSpecz1024";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1024").src = tripleZeroA;
};

function squareToSzzZValue1025(){
    value35Save = "zSqrArtSpecz1025";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1025").src = tripleZeroA;
};

function squareToSzzZValue1026(){
    value35Save = "zSqrArtSpecz1026";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1026").src = tripleZeroA;
};

function squareToSzzZValue1027(){
    value35Save = "zSqrArtSpecz1027";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1027").src = tripleZeroA;
};

function squareToSzzZValue1028(){
    value35Save = "zSqrArtSpecz1028";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1028").src = tripleZeroA;
};

function squareToSzzZValue1029(){
    value35Save = "zSqrArtSpecz1029";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1029").src = tripleZeroA;
};

function squareToSzzZValue1030(){
    value35Save = "zSqrArtSpecz1030";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1030").src = tripleZeroA;
};

function squareToSzzZValue1031(){
    value35Save = "zSqrArtSpecz1031";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1031").src = tripleZeroA;
};

function squareToSzzZValue1032(){
    value35Save = "zSqrArtSpecz1032";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1032").src = tripleZeroA;
};

function squareToSzzZValue1033(){
    value35Save = "zSqrArtSpecz1033";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1033").src = tripleZeroA;
};

function squareToSzzZValue1034(){
    value35Save = "zSqrArtSpecz1034";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1034").src = tripleZeroA;
};

function squareToSzzZValue1035(){
    value35Save = "zSqrArtSpecz1035";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1035").src = tripleZeroA;
};

function squareToSzzZValue1036(){
    value35Save = "zSqrArtSpecz1036";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1036").src = tripleZeroA;
};

function squareToSzzZValue1037(){
    value35Save = "zSqrArtSpecz1037";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1037").src = tripleZeroA;
};

function squareToSzzZValue1038(){
    value35Save = "zSqrArtSpecz1038";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1038").src = tripleZeroA;
};

function squareToSzzZValue1039(){
    value35Save = "zSqrArtSpecz1039";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1039").src = tripleZeroA;
};

function squareToSzzZValue1040(){
    value35Save = "zSqrArtSpecz1040";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1040").src = tripleZeroA;
};

function squareToSzzZValue1041(){
    value35Save = "zSqrArtSpecz1041";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1041").src = tripleZeroA;
};

function squareToSzzZValue1042(){
    value35Save = "zSqrArtSpecz1042";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1042").src = tripleZeroA;
};

function squareToSzzZValue1043(){
    value35Save = "zSqrArtSpecz1043";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1043").src = tripleZeroA;
};

function squareToSzzZValue1044(){
    value35Save = "zSqrArtSpecz1044";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1044").src = tripleZeroA;
};

function squareToSzzZValue1045(){
    value35Save = "zSqrArtSpecz1045";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1045").src = tripleZeroA;
};

function squareToSzzZValue1046(){
    value35Save = "zSqrArtSpecz1046";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1046").src = tripleZeroA;
};

function squareToSzzZValue1047(){
    value35Save = "zSqrArtSpecz1047";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1047").src = tripleZeroA;
};

function squareToSzzZValue1048(){
    value35Save = "zSqrArtSpecz1048";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1048").src = tripleZeroA;
};

function squareToSzzZValue1049(){
    value35Save = "zSqrArtSpecz1049";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1049").src = tripleZeroA;
};

function squareToSzzZValue1050(){
    value35Save = "zSqrArtSpecz1050";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1050").src = tripleZeroA;
};

function squareToSzzZValue1051(){
    value35Save = "zSqrArtSpecz1051";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1051").src = tripleZeroA;
};

function squareToSzzZValue1052(){
    value35Save = "zSqrArtSpecz1052";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1052").src = tripleZeroA;
};

function squareToSzzZValue1053(){
    value35Save = "zSqrArtSpecz1053";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1053").src = tripleZeroA;
};

function squareToSzzZValue1054(){
    value35Save = "zSqrArtSpecz1054";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1054").src = tripleZeroA;
};

function squareToSzzZValue1055(){
    value35Save = "zSqrArtSpecz1055";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1055").src = tripleZeroA;
};

function squareToSzzZValue1056(){
    value35Save = "zSqrArtSpecz1056";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1056").src = tripleZeroA;
};

function squareToSzzZValue1057(){
    value35Save = "zSqrArtSpecz1057";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1057").src = tripleZeroA;
};

function squareToSzzZValue1058(){
    value35Save = "zSqrArtSpecz1058";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1058").src = tripleZeroA;
};

function squareToSzzZValue1059(){
    value35Save = "zSqrArtSpecz1059";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1059").src = tripleZeroA;
};

function squareToSzzZValue1060(){
    value35Save = "zSqrArtSpecz1060";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1060").src = tripleZeroA;
};

function squareToSzzZValue1061(){
    value35Save = "zSqrArtSpecz1061";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1061").src = tripleZeroA;
};

function squareToSzzZValue1062(){
    value35Save = "zSqrArtSpecz1062";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1062").src = tripleZeroA;
};

function squareToSzzZValue1063(){
    value35Save = "zSqrArtSpecz1063";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1063").src = tripleZeroA;
};

function squareToSzzZValue1064(){
    value35Save = "zSqrArtSpecz1064";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1064").src = tripleZeroA;
};

function squareToSzzZValue1065(){
    value35Save = "zSqrArtSpecz1065";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1065").src = tripleZeroA;
};

function squareToSzzZValue1066(){
    value35Save = "zSqrArtSpecz1066";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1066").src = tripleZeroA;
};

function squareToSzzZValue1067(){
    value35Save = "zSqrArtSpecz1067";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1067").src = tripleZeroA;
};

function squareToSzzZValue1068(){
    value35Save = "zSqrArtSpecz1068";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1068").src = tripleZeroA;
};

function squareToSzzZValue1069(){
    value35Save = "zSqrArtSpecz1069";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1069").src = tripleZeroA;
};

function squareToSzzZValue1070(){
    value35Save = "zSqrArtSpecz1070";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1070").src = tripleZeroA;
};

function squareToSzzZValue1071(){
    value35Save = "zSqrArtSpecz1071";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1071").src = tripleZeroA;
};

function squareToSzzZValue1072(){
    value35Save = "zSqrArtSpecz1072";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1072").src = tripleZeroA;
};

function squareToSzzZValue1073(){
    value35Save = "zSqrArtSpecz1073";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1073").src = tripleZeroA;
};

function squareToSzzZValue1074(){
    value35Save = "zSqrArtSpecz1074";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1074").src = tripleZeroA;
};

function squareToSzzZValue1075(){
    value35Save = "zSqrArtSpecz1075";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1075").src = tripleZeroA;
};

function squareToSzzZValue1076(){
    value35Save = "zSqrArtSpecz1076";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1076").src = tripleZeroA;
};

function squareToSzzZValue1077(){
    value35Save = "zSqrArtSpecz1077";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1077").src = tripleZeroA;
};

function squareToSzzZValue1078(){
    value35Save = "zSqrArtSpecz1078";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1078").src = tripleZeroA;
};

function squareToSzzZValue1079(){
    value35Save = "zSqrArtSpecz1079";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1079").src = tripleZeroA;
};

function squareToSzzZValue1080(){
    value35Save = "zSqrArtSpecz1080";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1080").src = tripleZeroA;
};

function squareToSzzZValue1081(){
    value35Save = "zSqrArtSpecz1081";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1081").src = tripleZeroA;
};

function squareToSzzZValue1082(){
    value35Save = "zSqrArtSpecz1082";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1082").src = tripleZeroA;
};

function squareToSzzZValue1083(){
    value35Save = "zSqrArtSpecz1083";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1083").src = tripleZeroA;
};

function squareToSzzZValue1084(){
    value35Save = "zSqrArtSpecz1084";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1084").src = tripleZeroA;
};

function squareToSzzZValue1085(){
    value35Save = "zSqrArtSpecz1085";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1085").src = tripleZeroA;
};

function squareToSzzZValue1086(){
    value35Save = "zSqrArtSpecz1086";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1086").src = tripleZeroA;
};

function squareToSzzZValue1087(){
    value35Save = "zSqrArtSpecz1087";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1087").src = tripleZeroA;
};

function squareToSzzZValue1088(){
    value35Save = "zSqrArtSpecz1088";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1088").src = tripleZeroA;
};

function squareToSzzZValue1089(){
    value35Save = "zSqrArtSpecz1089";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1089").src = tripleZeroA;
};

function squareToSzzZValue1090(){
    value35Save = "zSqrArtSpecz1090";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1090").src = tripleZeroA;
};

function squareToSzzZValue1091(){
    value35Save = "zSqrArtSpecz1091";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1091").src = tripleZeroA;
};

function squareToSzzZValue1092(){
    value35Save = "zSqrArtSpecz1092";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1092").src = tripleZeroA;
};

function squareToSzzZValue1093(){
    value35Save = "zSqrArtSpecz1093";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1093").src = tripleZeroA;
};

function squareToSzzZValue1094(){
    value35Save = "zSqrArtSpecz1094";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1094").src = tripleZeroA;
};

function squareToSzzZValue1095(){
    value35Save = "zSqrArtSpecz1095";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1095").src = tripleZeroA;
};

function squareToSzzZValue1096(){
    value35Save = "zSqrArtSpecz1096";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1096").src = tripleZeroA;
};

function squareToSzzZValue1097(){
    value35Save = "zSqrArtSpecz1097";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1097").src = tripleZeroA;
};

function squareToSzzZValue1098(){
    value35Save = "zSqrArtSpecz1098";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1098").src = tripleZeroA;
};

function squareToSzzZValue1099(){
    value35Save = "zSqrArtSpecz1099";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1099").src = tripleZeroA;
};

function squareToSzzZValue1100(){
    value35Save = "zSqrArtSpecz1100";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1100").src = tripleZeroA;
};

function squareToSzzZValue1101(){
    value35Save = "zSqrArtSpecz1101";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1101").src = tripleZeroA;
};

function squareToSzzZValue1102(){
    value35Save = "zSqrArtSpecz1102";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1102").src = tripleZeroA;
};

function squareToSzzZValue1103(){
    value35Save = "zSqrArtSpecz1103";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1103").src = tripleZeroA;
};

function squareToSzzZValue1104(){
    value35Save = "zSqrArtSpecz1104";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1104").src = tripleZeroA;
};

function squareToSzzZValue1105(){
    value35Save = "zSqrArtSpecz1105";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1105").src = tripleZeroA;
};

function squareToSzzZValue1106(){
    value35Save = "zSqrArtSpecz1106";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1106").src = tripleZeroA;
};

function squareToSzzZValue1107(){
    value35Save = "zSqrArtSpecz1107";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1107").src = tripleZeroA;
};

function squareToSzzZValue1108(){
    value35Save = "zSqrArtSpecz1108";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1108").src = tripleZeroA;
};

function squareToSzzZValue1109(){
    value35Save = "zSqrArtSpecz1109";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1109").src = tripleZeroA;
};

function squareToSzzZValue1110(){
    value35Save = "zSqrArtSpecz1110";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1110").src = tripleZeroA;
};

function squareToSzzZValue1111(){
    value35Save = "zSqrArtSpecz1111";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1111").src = tripleZeroA;
};

function squareToSzzZValue1112(){
    value35Save = "zSqrArtSpecz1112";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1112").src = tripleZeroA;
};

function squareToSzzZValue1113(){
    value35Save = "zSqrArtSpecz1113";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1113").src = tripleZeroA;
};

function squareToSzzZValue1114(){
    value35Save = "zSqrArtSpecz1114";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1114").src = tripleZeroA;
};

function squareToSzzZValue1115(){
    value35Save = "zSqrArtSpecz1115";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1115").src = tripleZeroA;
};

function squareToSzzZValue1116(){
    value35Save = "zSqrArtSpecz1116";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1116").src = tripleZeroA;
};

function squareToSzzZValue1117(){
    value35Save = "zSqrArtSpecz1117";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1117").src = tripleZeroA;
};

function squareToSzzZValue1118(){
    value35Save = "zSqrArtSpecz1118";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1118").src = tripleZeroA;
};

function squareToSzzZValue1119(){
    value35Save = "zSqrArtSpecz1119";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1119").src = tripleZeroA;
};

function squareToSzzZValue1120(){
    value35Save = "zSqrArtSpecz1120";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1120").src = tripleZeroA;
};

function squareToSzzZValue1121(){
    value35Save = "zSqrArtSpecz1121";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1121").src = tripleZeroA;
};

function squareToSzzZValue1122(){
    value35Save = "zSqrArtSpecz1122";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1122").src = tripleZeroA;
};

function squareToSzzZValue1123(){
    value35Save = "zSqrArtSpecz1123";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1123").src = tripleZeroA;
};

function squareToSzzZValue1124(){
    value35Save = "zSqrArtSpecz1124";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1124").src = tripleZeroA;
};

function squareToSzzZValue1125(){
    value35Save = "zSqrArtSpecz1125";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1125").src = tripleZeroA;
};

function squareToSzzZValue1126(){
    value35Save = "zSqrArtSpecz1126";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1126").src = tripleZeroA;
};

function squareToSzzZValue1127(){
    value35Save = "zSqrArtSpecz1127";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1127").src = tripleZeroA;
};

function squareToSzzZValue1128(){
    value35Save = "zSqrArtSpecz1128";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1128").src = tripleZeroA;
};

function squareToSzzZValue1129(){
    value35Save = "zSqrArtSpecz1129";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1129").src = tripleZeroA;
};

function squareToSzzZValue1130(){
    value35Save = "zSqrArtSpecz1130";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1130").src = tripleZeroA;
};

function squareToSzzZValue1131(){
    value35Save = "zSqrArtSpecz1131";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1131").src = tripleZeroA;
};

function squareToSzzZValue1132(){
    value35Save = "zSqrArtSpecz1132";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1132").src = tripleZeroA;
};

function squareToSzzZValue1133(){
    value35Save = "zSqrArtSpecz1133";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1133").src = tripleZeroA;
};

function squareToSzzZValue1134(){
    value35Save = "zSqrArtSpecz1134";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1134").src = tripleZeroA;
};

function squareToSzzZValue1135(){
    value35Save = "zSqrArtSpecz1135";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1135").src = tripleZeroA;
};

function squareToSzzZValue1136(){
    value35Save = "zSqrArtSpecz1136";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1136").src = tripleZeroA;
};

function squareToSzzZValue1137(){
    value35Save = "zSqrArtSpecz1137";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1137").src = tripleZeroA;
};

function squareToSzzZValue1138(){
    value35Save = "zSqrArtSpecz1138";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1138").src = tripleZeroA;
};

function squareToSzzZValue1139(){
    value35Save = "zSqrArtSpecz1139";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1139").src = tripleZeroA;
};

function squareToSzzZValue1140(){
    value35Save = "zSqrArtSpecz1140";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1140").src = tripleZeroA;
};

function squareToSzzZValue1141(){
    value35Save = "zSqrArtSpecz1141";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1141").src = tripleZeroA;
};

function squareToSzzZValue1142(){
    value35Save = "zSqrArtSpecz1142";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1142").src = tripleZeroA;
};

function squareToSzzZValue1143(){
    value35Save = "zSqrArtSpecz1143";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1143").src = tripleZeroA;
};

function squareToSzzZValue1144(){
    value35Save = "zSqrArtSpecz1144";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1144").src = tripleZeroA;
};

function squareToSzzZValue1145(){
    value35Save = "zSqrArtSpecz1145";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1145").src = tripleZeroA;
};

function squareToSzzZValue1146(){
    value35Save = "zSqrArtSpecz1146";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1146").src = tripleZeroA;
};

function squareToSzzZValue1147(){
    value35Save = "zSqrArtSpecz1147";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1147").src = tripleZeroA;
};

function squareToSzzZValue1148(){
    value35Save = "zSqrArtSpecz1148";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1148").src = tripleZeroA;
};

function squareToSzzZValue1149(){
    value35Save = "zSqrArtSpecz1149";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1149").src = tripleZeroA;
};

function squareToSzzZValue1150(){
    value35Save = "zSqrArtSpecz1150";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1150").src = tripleZeroA;
};

function squareToSzzZValue1151(){
    value35Save = "zSqrArtSpecz1151";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1151").src = tripleZeroA;
};

function squareToSzzZValue1152(){
    value35Save = "zSqrArtSpecz1152";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1152").src = tripleZeroA;
};

function squareToSzzZValue1153(){
    value35Save = "zSqrArtSpecz1153";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1153").src = tripleZeroA;
};

function squareToSzzZValue1154(){
    value35Save = "zSqrArtSpecz1154";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1154").src = tripleZeroA;
};

function squareToSzzZValue1155(){
    value35Save = "zSqrArtSpecz1155";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1155").src = tripleZeroA;
};

function squareToSzzZValue1156(){
    value35Save = "zSqrArtSpecz1156";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1156").src = tripleZeroA;
};

function squareToSzzZValue1157(){
    value35Save = "zSqrArtSpecz1157";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1157").src = tripleZeroA;
};

function squareToSzzZValue1158(){
    value35Save = "zSqrArtSpecz1158";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1158").src = tripleZeroA;
};

function squareToSzzZValue1159(){
    value35Save = "zSqrArtSpecz1159";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1159").src = tripleZeroA;
};

function squareToSzzZValue1160(){
    value35Save = "zSqrArtSpecz1160";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1160").src = tripleZeroA;
};

function squareToSzzZValue1161(){
    value35Save = "zSqrArtSpecz1161";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1161").src = tripleZeroA;
};

function squareToSzzZValue1162(){
    value35Save = "zSqrArtSpecz1162";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1162").src = tripleZeroA;
};

function squareToSzzZValue1163(){
    value35Save = "zSqrArtSpecz1163";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1163").src = tripleZeroA;
};

function squareToSzzZValue1164(){
    value35Save = "zSqrArtSpecz1164";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1164").src = tripleZeroA;
};

function squareToSzzZValue1165(){
    value35Save = "zSqrArtSpecz1165";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1165").src = tripleZeroA;
};

function squareToSzzZValue1166(){
    value35Save = "zSqrArtSpecz1166";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1166").src = tripleZeroA;
};

function squareToSzzZValue1167(){
    value35Save = "zSqrArtSpecz1167";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1167").src = tripleZeroA;
};

function squareToSzzZValue1168(){
    value35Save = "zSqrArtSpecz1168";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1168").src = tripleZeroA;
};

function squareToSzzZValue1169(){
    value35Save = "zSqrArtSpecz1169";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1169").src = tripleZeroA;
};

function squareToSzzZValue1170(){
    value35Save = "zSqrArtSpecz1170";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1170").src = tripleZeroA;
};

function squareToSzzZValue1171(){
    value35Save = "zSqrArtSpecz1171";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1171").src = tripleZeroA;
};

function squareToSzzZValue1172(){
    value35Save = "zSqrArtSpecz1172";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1172").src = tripleZeroA;
};

function squareToSzzZValue1173(){
    value35Save = "zSqrArtSpecz1173";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1173").src = tripleZeroA;
};

function squareToSzzZValue1174(){
    value35Save = "zSqrArtSpecz1174";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1174").src = tripleZeroA;
};

function squareToSzzZValue1175(){
    value35Save = "zSqrArtSpecz1175";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1175").src = tripleZeroA;
};

function squareToSzzZValue1176(){
    value35Save = "zSqrArtSpecz1176";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1176").src = tripleZeroA;
};

function squareToSzzZValue1177(){
    value35Save = "zSqrArtSpecz1177";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1177").src = tripleZeroA;
};

function squareToSzzZValue1178(){
    value35Save = "zSqrArtSpecz1178";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1178").src = tripleZeroA;
};

function squareToSzzZValue1179(){
    value35Save = "zSqrArtSpecz1179";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1179").src = tripleZeroA;
};

function squareToSzzZValue1180(){
    value35Save = "zSqrArtSpecz1180";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1180").src = tripleZeroA;
};

function squareToSzzZValue1181(){
    value35Save = "zSqrArtSpecz1181";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1181").src = tripleZeroA;
};

function squareToSzzZValue1182(){
    value35Save = "zSqrArtSpecz1182";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1182").src = tripleZeroA;
};

function squareToSzzZValue1183(){
    value35Save = "zSqrArtSpecz1183";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1183").src = tripleZeroA;
};

function squareToSzzZValue1184(){
    value35Save = "zSqrArtSpecz1184";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1184").src = tripleZeroA;
};

function squareToSzzZValue1185(){
    value35Save = "zSqrArtSpecz1185";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1185").src = tripleZeroA;
};

function squareToSzzZValue1186(){
    value35Save = "zSqrArtSpecz1186";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1186").src = tripleZeroA;
};

function squareToSzzZValue1187(){
    value35Save = "zSqrArtSpecz1187";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1187").src = tripleZeroA;
};

function squareToSzzZValue1188(){
    value35Save = "zSqrArtSpecz1188";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1188").src = tripleZeroA;
};

function squareToSzzZValue1189(){
    value35Save = "zSqrArtSpecz1189";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1189").src = tripleZeroA;
};

function squareToSzzZValue1190(){
    value35Save = "zSqrArtSpecz1190";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1190").src = tripleZeroA;
};

function squareToSzzZValue1191(){
    value35Save = "zSqrArtSpecz1191";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1191").src = tripleZeroA;
};

function squareToSzzZValue1192(){
    value35Save = "zSqrArtSpecz1192";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1192").src = tripleZeroA;
};

function squareToSzzZValue1193(){
    value35Save = "zSqrArtSpecz1193";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1193").src = tripleZeroA;
};

function squareToSzzZValue1194(){
    value35Save = "zSqrArtSpecz1194";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1194").src = tripleZeroA;
};

function squareToSzzZValue1195(){
    value35Save = "zSqrArtSpecz1195";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1195").src = tripleZeroA;
};

function squareToSzzZValue1196(){
    value35Save = "zSqrArtSpecz1196";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1196").src = tripleZeroA;
};

function squareToSzzZValue1197(){
    value35Save = "zSqrArtSpecz1197";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1197").src = tripleZeroA;
};

function squareToSzzZValue1198(){
    value35Save = "zSqrArtSpecz1198";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1198").src = tripleZeroA;
};

function squareToSzzZValue1199(){
    value35Save = "zSqrArtSpecz1199";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1199").src = tripleZeroA;
};

function squareToSzzZValue1200(){
    value35Save = "zSqrArtSpecz1200";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1200").src = tripleZeroA;
};

function squareToSzzZValue1201(){
    value35Save = "zSqrArtSpecz1201";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1201").src = tripleZeroA;
};

function squareToSzzZValue1202(){
    value35Save = "zSqrArtSpecz1202";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1202").src = tripleZeroA;
};

function squareToSzzZValue1203(){
    value35Save = "zSqrArtSpecz1203";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1203").src = tripleZeroA;
};

function squareToSzzZValue1204(){
    value35Save = "zSqrArtSpecz1204";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1204").src = tripleZeroA;
};

function squareToSzzZValue1205(){
    value35Save = "zSqrArtSpecz1205";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1205").src = tripleZeroA;
};

function squareToSzzZValue1206(){
    value35Save = "zSqrArtSpecz1206";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1206").src = tripleZeroA;
};

function squareToSzzZValue1207(){
    value35Save = "zSqrArtSpecz1207";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1207").src = tripleZeroA;
};

function squareToSzzZValue1208(){
    value35Save = "zSqrArtSpecz1208";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1208").src = tripleZeroA;
};

function squareToSzzZValue1209(){
    value35Save = "zSqrArtSpecz1209";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1209").src = tripleZeroA;
};

function squareToSzzZValue1210(){
    value35Save = "zSqrArtSpecz1210";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1210").src = tripleZeroA;
};

function squareToSzzZValue1211(){
    value35Save = "zSqrArtSpecz1211";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1211").src = tripleZeroA;
};

function squareToSzzZValue1212(){
    value35Save = "zSqrArtSpecz1212";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1212").src = tripleZeroA;
};

function squareToSzzZValue1213(){
    value35Save = "zSqrArtSpecz1213";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1213").src = tripleZeroA;
};

function squareToSzzZValue1214(){
    value35Save = "zSqrArtSpecz1214";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1214").src = tripleZeroA;
};

function squareToSzzZValue1215(){
    value35Save = "zSqrArtSpecz1215";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1215").src = tripleZeroA;
};

function squareToSzzZValue1216(){
    value35Save = "zSqrArtSpecz1216";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1216").src = tripleZeroA;
};

function squareToSzzZValue1217(){
    value35Save = "zSqrArtSpecz1217";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1217").src = tripleZeroA;
};

function squareToSzzZValue1218(){
    value35Save = "zSqrArtSpecz1218";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1218").src = tripleZeroA;
};

function squareToSzzZValue1219(){
    value35Save = "zSqrArtSpecz1219";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1219").src = tripleZeroA;
};

function squareToSzzZValue1220(){
    value35Save = "zSqrArtSpecz1220";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1220").src = tripleZeroA;
};

function squareToSzzZValue1221(){
    value35Save = "zSqrArtSpecz1221";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1221").src = tripleZeroA;
};

function squareToSzzZValue1222(){
    value35Save = "zSqrArtSpecz1222";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1222").src = tripleZeroA;
};

function squareToSzzZValue1223(){
    value35Save = "zSqrArtSpecz1223";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1223").src = tripleZeroA;
};

function squareToSzzZValue1224(){
    value35Save = "zSqrArtSpecz1224";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1224").src = tripleZeroA;
};

function squareToSzzZValue1225(){
    value35Save = "zSqrArtSpecz1225";
    var tripleZeroA = localStorage.getItem(value35Save);
    document.getElementById("imgSqrs1225").src = tripleZeroA;
};

function getBThis(){
    squareToSzzZValue1()

    squareToSzzZValue2()

    squareToSzzZValue3()

    squareToSzzZValue4()

    squareToSzzZValue5()

    squareToSzzZValue6()

    squareToSzzZValue7()

    squareToSzzZValue8()

    squareToSzzZValue9()

    squareToSzzZValue10()

    squareToSzzZValue11()

    squareToSzzZValue12()

    squareToSzzZValue13()

    squareToSzzZValue14()

    squareToSzzZValue15()

    squareToSzzZValue16()

    squareToSzzZValue17()

    squareToSzzZValue18()

    squareToSzzZValue19()

    squareToSzzZValue20()

    squareToSzzZValue21()

    squareToSzzZValue22()

    squareToSzzZValue23()

    squareToSzzZValue24()

    squareToSzzZValue25()

    squareToSzzZValue26()

    squareToSzzZValue27()

    squareToSzzZValue28()

    squareToSzzZValue29()

    squareToSzzZValue30()

    squareToSzzZValue31()

    squareToSzzZValue32()

    squareToSzzZValue33()

    squareToSzzZValue34()

    squareToSzzZValue35()

    squareToSzzZValue36()

    squareToSzzZValue37()

    squareToSzzZValue38()

    squareToSzzZValue39()

    squareToSzzZValue40()

    squareToSzzZValue41()

    squareToSzzZValue42()

    squareToSzzZValue43()

    squareToSzzZValue44()

    squareToSzzZValue45()

    squareToSzzZValue46()

    squareToSzzZValue47()

    squareToSzzZValue48()

    squareToSzzZValue49()

    squareToSzzZValue50()

    squareToSzzZValue51()

    squareToSzzZValue52()

    squareToSzzZValue53()

    squareToSzzZValue54()

    squareToSzzZValue55()

    squareToSzzZValue56()

    squareToSzzZValue57()

    squareToSzzZValue58()

    squareToSzzZValue59()

    squareToSzzZValue60()

    squareToSzzZValue61()

    squareToSzzZValue62()

    squareToSzzZValue63()

    squareToSzzZValue64()

    squareToSzzZValue65()

    squareToSzzZValue66()

    squareToSzzZValue67()

    squareToSzzZValue68()

    squareToSzzZValue69()

    squareToSzzZValue70()

    squareToSzzZValue71()

    squareToSzzZValue72()

    squareToSzzZValue73()

    squareToSzzZValue74()

    squareToSzzZValue75()

    squareToSzzZValue76()

    squareToSzzZValue77()

    squareToSzzZValue78()

    squareToSzzZValue79()

    squareToSzzZValue80()

    squareToSzzZValue81()

    squareToSzzZValue82()

    squareToSzzZValue83()

    squareToSzzZValue84()

    squareToSzzZValue85()

    squareToSzzZValue86()

    squareToSzzZValue87()

    squareToSzzZValue88()

    squareToSzzZValue89()

    squareToSzzZValue90()

    squareToSzzZValue91()

    squareToSzzZValue92()

    squareToSzzZValue93()

    squareToSzzZValue94()

    squareToSzzZValue95()

    squareToSzzZValue96()

    squareToSzzZValue97()

    squareToSzzZValue98()

    squareToSzzZValue99()

    squareToSzzZValue100()

    squareToSzzZValue101()

    squareToSzzZValue102()

    squareToSzzZValue103()

    squareToSzzZValue104()

    squareToSzzZValue105()

    squareToSzzZValue106()

    squareToSzzZValue107()

    squareToSzzZValue108()

    squareToSzzZValue109()

    squareToSzzZValue110()

    squareToSzzZValue111()

    squareToSzzZValue112()

    squareToSzzZValue113()

    squareToSzzZValue114()

    squareToSzzZValue115()

    squareToSzzZValue116()

    squareToSzzZValue117()

    squareToSzzZValue118()

    squareToSzzZValue119()

    squareToSzzZValue120()

    squareToSzzZValue121()

    squareToSzzZValue122()

    squareToSzzZValue123()

    squareToSzzZValue124()

    squareToSzzZValue125()

    squareToSzzZValue126()

    squareToSzzZValue127()

    squareToSzzZValue128()

    squareToSzzZValue129()

    squareToSzzZValue130()

    squareToSzzZValue131()

    squareToSzzZValue132()

    squareToSzzZValue133()

    squareToSzzZValue134()

    squareToSzzZValue135()

    squareToSzzZValue136()

    squareToSzzZValue137()

    squareToSzzZValue138()

    squareToSzzZValue139()

    squareToSzzZValue140()

    squareToSzzZValue141()

    squareToSzzZValue142()

    squareToSzzZValue143()

    squareToSzzZValue144()

    squareToSzzZValue145()

    squareToSzzZValue146()

    squareToSzzZValue147()

    squareToSzzZValue148()

    squareToSzzZValue149()

    squareToSzzZValue150()

    squareToSzzZValue151()

    squareToSzzZValue152()

    squareToSzzZValue153()

    squareToSzzZValue154()

    squareToSzzZValue155()

    squareToSzzZValue156()

    squareToSzzZValue157()

    squareToSzzZValue158()

    squareToSzzZValue159()

    squareToSzzZValue160()

    squareToSzzZValue161()

    squareToSzzZValue162()

    squareToSzzZValue163()

    squareToSzzZValue164()

    squareToSzzZValue165()

    squareToSzzZValue166()

    squareToSzzZValue167()

    squareToSzzZValue168()

    squareToSzzZValue169()

    squareToSzzZValue170()

    squareToSzzZValue171()

    squareToSzzZValue172()

    squareToSzzZValue173()

    squareToSzzZValue174()

    squareToSzzZValue175()

    squareToSzzZValue176()

    squareToSzzZValue177()

    squareToSzzZValue178()

    squareToSzzZValue179()

    squareToSzzZValue180()

    squareToSzzZValue181()

    squareToSzzZValue182()

    squareToSzzZValue183()

    squareToSzzZValue184()

    squareToSzzZValue185()

    squareToSzzZValue186()

    squareToSzzZValue187()

    squareToSzzZValue188()

    squareToSzzZValue189()

    squareToSzzZValue190()

    squareToSzzZValue191()

    squareToSzzZValue192()

    squareToSzzZValue193()

    squareToSzzZValue194()

    squareToSzzZValue195()

    squareToSzzZValue196()

    squareToSzzZValue197()

    squareToSzzZValue198()

    squareToSzzZValue199()

    squareToSzzZValue200()

    squareToSzzZValue201()

    squareToSzzZValue202()

    squareToSzzZValue203()

    squareToSzzZValue204()

    squareToSzzZValue205()

    squareToSzzZValue206()

    squareToSzzZValue207()

    squareToSzzZValue208()

    squareToSzzZValue209()

    squareToSzzZValue210()

    squareToSzzZValue211()

    squareToSzzZValue212()

    squareToSzzZValue213()

    squareToSzzZValue214()

    squareToSzzZValue215()

    squareToSzzZValue216()

    squareToSzzZValue217()

    squareToSzzZValue218()

    squareToSzzZValue219()

    squareToSzzZValue220()

    squareToSzzZValue221()

    squareToSzzZValue222()

    squareToSzzZValue223()

    squareToSzzZValue224()

    squareToSzzZValue225()

    squareToSzzZValue226()

    squareToSzzZValue227()

    squareToSzzZValue228()

    squareToSzzZValue229()

    squareToSzzZValue230()

    squareToSzzZValue231()

    squareToSzzZValue232()

    squareToSzzZValue233()

    squareToSzzZValue234()

    squareToSzzZValue235()

    squareToSzzZValue236()

    squareToSzzZValue237()

    squareToSzzZValue238()

    squareToSzzZValue239()

    squareToSzzZValue240()

    squareToSzzZValue241()

    squareToSzzZValue242()

    squareToSzzZValue243()

    squareToSzzZValue244()

    squareToSzzZValue245()

    squareToSzzZValue246()

    squareToSzzZValue247()

    squareToSzzZValue248()

    squareToSzzZValue249()

    squareToSzzZValue250()

    squareToSzzZValue251()

    squareToSzzZValue252()

    squareToSzzZValue253()

    squareToSzzZValue254()

    squareToSzzZValue255()

    squareToSzzZValue256()

    squareToSzzZValue257()

    squareToSzzZValue258()

    squareToSzzZValue259()

    squareToSzzZValue260()

    squareToSzzZValue261()

    squareToSzzZValue262()

    squareToSzzZValue263()

    squareToSzzZValue264()

    squareToSzzZValue265()

    squareToSzzZValue266()

    squareToSzzZValue267()

    squareToSzzZValue268()

    squareToSzzZValue269()

    squareToSzzZValue270()

    squareToSzzZValue271()

    squareToSzzZValue272()

    squareToSzzZValue273()

    squareToSzzZValue274()

    squareToSzzZValue275()

    squareToSzzZValue276()

    squareToSzzZValue277()

    squareToSzzZValue278()

    squareToSzzZValue279()

    squareToSzzZValue280()

    squareToSzzZValue281()

    squareToSzzZValue282()

    squareToSzzZValue283()

    squareToSzzZValue284()

    squareToSzzZValue285()

    squareToSzzZValue286()

    squareToSzzZValue287()

    squareToSzzZValue288()

    squareToSzzZValue289()

    squareToSzzZValue290()

    squareToSzzZValue291()

    squareToSzzZValue292()

    squareToSzzZValue293()

    squareToSzzZValue294()

    squareToSzzZValue295()

    squareToSzzZValue296()

    squareToSzzZValue297()

    squareToSzzZValue298()

    squareToSzzZValue299()

    squareToSzzZValue300()

    squareToSzzZValue301()

    squareToSzzZValue302()

    squareToSzzZValue303()

    squareToSzzZValue304()

    squareToSzzZValue305()

    squareToSzzZValue306()

    squareToSzzZValue307()

    squareToSzzZValue308()

    squareToSzzZValue309()

    squareToSzzZValue310()

    squareToSzzZValue311()

    squareToSzzZValue312()

    squareToSzzZValue313()

    squareToSzzZValue314()

    squareToSzzZValue315()

    squareToSzzZValue316()

    squareToSzzZValue317()

    squareToSzzZValue318()

    squareToSzzZValue319()

    squareToSzzZValue320()

    squareToSzzZValue321()

    squareToSzzZValue322()

    squareToSzzZValue323()

    squareToSzzZValue324()

    squareToSzzZValue325()

    squareToSzzZValue326()

    squareToSzzZValue327()

    squareToSzzZValue328()

    squareToSzzZValue329()

    squareToSzzZValue330()

    squareToSzzZValue331()

    squareToSzzZValue332()

    squareToSzzZValue333()

    squareToSzzZValue334()

    squareToSzzZValue335()

    squareToSzzZValue336()

    squareToSzzZValue337()

    squareToSzzZValue338()

    squareToSzzZValue339()

    squareToSzzZValue340()

    squareToSzzZValue341()

    squareToSzzZValue342()

    squareToSzzZValue343()

    squareToSzzZValue344()

    squareToSzzZValue345()

    squareToSzzZValue346()

    squareToSzzZValue347()

    squareToSzzZValue348()

    squareToSzzZValue349()

    squareToSzzZValue350()

    squareToSzzZValue351()

    squareToSzzZValue352()

    squareToSzzZValue353()

    squareToSzzZValue354()

    squareToSzzZValue355()

    squareToSzzZValue356()

    squareToSzzZValue357()

    squareToSzzZValue358()

    squareToSzzZValue359()

    squareToSzzZValue360()

    squareToSzzZValue361()

    squareToSzzZValue362()

    squareToSzzZValue363()

    squareToSzzZValue364()

    squareToSzzZValue365()

    squareToSzzZValue366()

    squareToSzzZValue367()

    squareToSzzZValue368()

    squareToSzzZValue369()

    squareToSzzZValue370()

    squareToSzzZValue371()

    squareToSzzZValue372()

    squareToSzzZValue373()

    squareToSzzZValue374()

    squareToSzzZValue375()

    squareToSzzZValue376()

    squareToSzzZValue377()

    squareToSzzZValue378()

    squareToSzzZValue379()

    squareToSzzZValue380()

    squareToSzzZValue381()

    squareToSzzZValue382()

    squareToSzzZValue383()

    squareToSzzZValue384()

    squareToSzzZValue385()

    squareToSzzZValue386()

    squareToSzzZValue387()

    squareToSzzZValue388()

    squareToSzzZValue389()

    squareToSzzZValue390()

    squareToSzzZValue391()

    squareToSzzZValue392()

    squareToSzzZValue393()

    squareToSzzZValue394()

    squareToSzzZValue395()

    squareToSzzZValue396()

    squareToSzzZValue397()

    squareToSzzZValue398()

    squareToSzzZValue399()

    squareToSzzZValue400()

    squareToSzzZValue401()

    squareToSzzZValue402()

    squareToSzzZValue403()

    squareToSzzZValue404()

    squareToSzzZValue405()

    squareToSzzZValue406()

    squareToSzzZValue407()

    squareToSzzZValue408()

    squareToSzzZValue409()

    squareToSzzZValue410()

    squareToSzzZValue411()

    squareToSzzZValue412()

    squareToSzzZValue413()

    squareToSzzZValue414()

    squareToSzzZValue415()

    squareToSzzZValue416()

    squareToSzzZValue417()

    squareToSzzZValue418()

    squareToSzzZValue419()

    squareToSzzZValue420()

    squareToSzzZValue421()

    squareToSzzZValue422()

    squareToSzzZValue423()

    squareToSzzZValue424()

    squareToSzzZValue425()

    squareToSzzZValue426()

    squareToSzzZValue427()

    squareToSzzZValue428()

    squareToSzzZValue429()

    squareToSzzZValue430()

    squareToSzzZValue431()

    squareToSzzZValue432()

    squareToSzzZValue433()

    squareToSzzZValue434()

    squareToSzzZValue435()

    squareToSzzZValue436()

    squareToSzzZValue437()

    squareToSzzZValue438()

    squareToSzzZValue439()

    squareToSzzZValue440()

    squareToSzzZValue441()

    squareToSzzZValue442()

    squareToSzzZValue443()

    squareToSzzZValue444()

    squareToSzzZValue445()

    squareToSzzZValue446()

    squareToSzzZValue447()

    squareToSzzZValue448()

    squareToSzzZValue449()

    squareToSzzZValue450()

    squareToSzzZValue451()

    squareToSzzZValue452()

    squareToSzzZValue453()

    squareToSzzZValue454()

    squareToSzzZValue455()

    squareToSzzZValue456()

    squareToSzzZValue457()

    squareToSzzZValue458()

    squareToSzzZValue459()

    squareToSzzZValue460()

    squareToSzzZValue461()

    squareToSzzZValue462()

    squareToSzzZValue463()

    squareToSzzZValue464()

    squareToSzzZValue465()

    squareToSzzZValue466()

    squareToSzzZValue467()

    squareToSzzZValue468()

    squareToSzzZValue469()

    squareToSzzZValue470()

    squareToSzzZValue471()

    squareToSzzZValue472()

    squareToSzzZValue473()

    squareToSzzZValue474()

    squareToSzzZValue475()

    squareToSzzZValue476()

    squareToSzzZValue477()

    squareToSzzZValue478()

    squareToSzzZValue479()

    squareToSzzZValue480()

    squareToSzzZValue481()

    squareToSzzZValue482()

    squareToSzzZValue483()

    squareToSzzZValue484()

    squareToSzzZValue485()

    squareToSzzZValue486()

    squareToSzzZValue487()

    squareToSzzZValue488()

    squareToSzzZValue489()

    squareToSzzZValue490()

    squareToSzzZValue491()

    squareToSzzZValue492()

    squareToSzzZValue493()

    squareToSzzZValue494()

    squareToSzzZValue495()

    squareToSzzZValue496()

    squareToSzzZValue497()

    squareToSzzZValue498()

    squareToSzzZValue499()

    squareToSzzZValue500()

    squareToSzzZValue501()

    squareToSzzZValue502()

    squareToSzzZValue503()

    squareToSzzZValue504()

    squareToSzzZValue505()

    squareToSzzZValue506()

    squareToSzzZValue507()

    squareToSzzZValue508()

    squareToSzzZValue509()

    squareToSzzZValue510()

    squareToSzzZValue511()

    squareToSzzZValue512()

    squareToSzzZValue513()

    squareToSzzZValue514()

    squareToSzzZValue515()

    squareToSzzZValue516()

    squareToSzzZValue517()

    squareToSzzZValue518()

    squareToSzzZValue519()

    squareToSzzZValue520()

    squareToSzzZValue521()

    squareToSzzZValue522()

    squareToSzzZValue523()

    squareToSzzZValue524()

    squareToSzzZValue525()

    squareToSzzZValue526()

    squareToSzzZValue527()

    squareToSzzZValue528()

    squareToSzzZValue529()

    squareToSzzZValue530()

    squareToSzzZValue531()

    squareToSzzZValue532()

    squareToSzzZValue533()

    squareToSzzZValue534()

    squareToSzzZValue535()

    squareToSzzZValue536()

    squareToSzzZValue537()

    squareToSzzZValue538()

    squareToSzzZValue539()

    squareToSzzZValue540()

    squareToSzzZValue541()

    squareToSzzZValue542()

    squareToSzzZValue543()

    squareToSzzZValue544()

    squareToSzzZValue545()

    squareToSzzZValue546()

    squareToSzzZValue547()

    squareToSzzZValue548()

    squareToSzzZValue549()

    squareToSzzZValue550()

    squareToSzzZValue551()

    squareToSzzZValue552()

    squareToSzzZValue553()

    squareToSzzZValue554()

    squareToSzzZValue555()

    squareToSzzZValue556()

    squareToSzzZValue557()

    squareToSzzZValue558()

    squareToSzzZValue559()

    squareToSzzZValue560()

    squareToSzzZValue561()

    squareToSzzZValue562()

    squareToSzzZValue563()

    squareToSzzZValue564()

    squareToSzzZValue565()

    squareToSzzZValue566()

    squareToSzzZValue567()

    squareToSzzZValue568()

    squareToSzzZValue569()

    squareToSzzZValue570()

    squareToSzzZValue571()

    squareToSzzZValue572()

    squareToSzzZValue573()

    squareToSzzZValue574()

    squareToSzzZValue575()

    squareToSzzZValue576()

    squareToSzzZValue577()

    squareToSzzZValue578()

    squareToSzzZValue579()

    squareToSzzZValue580()

    squareToSzzZValue581()

    squareToSzzZValue582()

    squareToSzzZValue583()

    squareToSzzZValue584()

    squareToSzzZValue585()

    squareToSzzZValue586()

    squareToSzzZValue587()

    squareToSzzZValue588()

    squareToSzzZValue589()

    squareToSzzZValue590()

    squareToSzzZValue591()

    squareToSzzZValue592()

    squareToSzzZValue593()

    squareToSzzZValue594()

    squareToSzzZValue595()

    squareToSzzZValue596()

    squareToSzzZValue597()

    squareToSzzZValue598()

    squareToSzzZValue599()

    squareToSzzZValue600()

    squareToSzzZValue601()

    squareToSzzZValue602()

    squareToSzzZValue603()

    squareToSzzZValue604()

    squareToSzzZValue605()

    squareToSzzZValue606()

    squareToSzzZValue607()

    squareToSzzZValue608()

    squareToSzzZValue609()

    squareToSzzZValue610()

    squareToSzzZValue611()

    squareToSzzZValue612()

    squareToSzzZValue613()

    squareToSzzZValue614()

    squareToSzzZValue615()

    squareToSzzZValue616()

    squareToSzzZValue617()

    squareToSzzZValue618()

    squareToSzzZValue619()

    squareToSzzZValue620()

    squareToSzzZValue621()

    squareToSzzZValue622()

    squareToSzzZValue623()

    squareToSzzZValue624()

    squareToSzzZValue625()

    squareToSzzZValue626()

    squareToSzzZValue627()

    squareToSzzZValue628()

    squareToSzzZValue629()

    squareToSzzZValue630()

    squareToSzzZValue631()

    squareToSzzZValue632()

    squareToSzzZValue633()

    squareToSzzZValue634()

    squareToSzzZValue635()

    squareToSzzZValue636()

    squareToSzzZValue637()

    squareToSzzZValue638()

    squareToSzzZValue639()

    squareToSzzZValue640()

    squareToSzzZValue641()

    squareToSzzZValue642()

    squareToSzzZValue643()

    squareToSzzZValue644()

    squareToSzzZValue645()

    squareToSzzZValue646()

    squareToSzzZValue647()

    squareToSzzZValue648()

    squareToSzzZValue649()

    squareToSzzZValue650()

    squareToSzzZValue651()

    squareToSzzZValue652()

    squareToSzzZValue653()

    squareToSzzZValue654()

    squareToSzzZValue655()

    squareToSzzZValue656()

    squareToSzzZValue657()

    squareToSzzZValue658()

    squareToSzzZValue659()

    squareToSzzZValue660()

    squareToSzzZValue661()

    squareToSzzZValue662()

    squareToSzzZValue663()

    squareToSzzZValue664()

    squareToSzzZValue665()

    squareToSzzZValue666()

    squareToSzzZValue667()

    squareToSzzZValue668()

    squareToSzzZValue669()

    squareToSzzZValue670()

    squareToSzzZValue671()

    squareToSzzZValue672()

    squareToSzzZValue673()

    squareToSzzZValue674()

    squareToSzzZValue675()

    squareToSzzZValue676()

    squareToSzzZValue677()

    squareToSzzZValue678()

    squareToSzzZValue679()

    squareToSzzZValue680()

    squareToSzzZValue681()

    squareToSzzZValue682()

    squareToSzzZValue683()

    squareToSzzZValue684()

    squareToSzzZValue685()

    squareToSzzZValue686()

    squareToSzzZValue687()

    squareToSzzZValue688()

    squareToSzzZValue689()

    squareToSzzZValue690()

    squareToSzzZValue691()

    squareToSzzZValue692()

    squareToSzzZValue693()

    squareToSzzZValue694()

    squareToSzzZValue695()

    squareToSzzZValue696()

    squareToSzzZValue697()

    squareToSzzZValue698()

    squareToSzzZValue699()

    squareToSzzZValue700()

    squareToSzzZValue701()

    squareToSzzZValue702()

    squareToSzzZValue703()

    squareToSzzZValue704()

    squareToSzzZValue705()

    squareToSzzZValue706()

    squareToSzzZValue707()

    squareToSzzZValue708()

    squareToSzzZValue709()

    squareToSzzZValue710()

    squareToSzzZValue711()

    squareToSzzZValue712()

    squareToSzzZValue713()

    squareToSzzZValue714()

    squareToSzzZValue715()

    squareToSzzZValue716()

    squareToSzzZValue717()

    squareToSzzZValue718()

    squareToSzzZValue719()

    squareToSzzZValue720()

    squareToSzzZValue721()

    squareToSzzZValue722()

    squareToSzzZValue723()

    squareToSzzZValue724()

    squareToSzzZValue725()

    squareToSzzZValue726()

    squareToSzzZValue727()

    squareToSzzZValue728()

    squareToSzzZValue729()

    squareToSzzZValue730()

    squareToSzzZValue731()

    squareToSzzZValue732()

    squareToSzzZValue733()

    squareToSzzZValue734()

    squareToSzzZValue735()

    squareToSzzZValue736()

    squareToSzzZValue737()

    squareToSzzZValue738()

    squareToSzzZValue739()

    squareToSzzZValue740()

    squareToSzzZValue741()

    squareToSzzZValue742()

    squareToSzzZValue743()

    squareToSzzZValue744()

    squareToSzzZValue745()

    squareToSzzZValue746()

    squareToSzzZValue747()

    squareToSzzZValue748()

    squareToSzzZValue749()

    squareToSzzZValue750()

    squareToSzzZValue751()

    squareToSzzZValue752()

    squareToSzzZValue753()

    squareToSzzZValue754()

    squareToSzzZValue755()

    squareToSzzZValue756()

    squareToSzzZValue757()

    squareToSzzZValue758()

    squareToSzzZValue759()

    squareToSzzZValue760()

    squareToSzzZValue761()

    squareToSzzZValue762()

    squareToSzzZValue763()

    squareToSzzZValue764()

    squareToSzzZValue765()

    squareToSzzZValue766()

    squareToSzzZValue767()

    squareToSzzZValue768()

    squareToSzzZValue769()

    squareToSzzZValue770()

    squareToSzzZValue771()

    squareToSzzZValue772()

    squareToSzzZValue773()

    squareToSzzZValue774()

    squareToSzzZValue775()

    squareToSzzZValue776()

    squareToSzzZValue777()

    squareToSzzZValue778()

    squareToSzzZValue779()

    squareToSzzZValue780()

    squareToSzzZValue781()

    squareToSzzZValue782()

    squareToSzzZValue783()

    squareToSzzZValue784()

    squareToSzzZValue785()

    squareToSzzZValue786()

    squareToSzzZValue787()

    squareToSzzZValue788()

    squareToSzzZValue789()

    squareToSzzZValue790()

    squareToSzzZValue791()

    squareToSzzZValue792()

    squareToSzzZValue793()

    squareToSzzZValue794()

    squareToSzzZValue795()

    squareToSzzZValue796()

    squareToSzzZValue797()

    squareToSzzZValue798()

    squareToSzzZValue799()

    squareToSzzZValue800()

    squareToSzzZValue801()

    squareToSzzZValue802()

    squareToSzzZValue803()

    squareToSzzZValue804()

    squareToSzzZValue805()

    squareToSzzZValue806()

    squareToSzzZValue807()

    squareToSzzZValue808()

    squareToSzzZValue809()

    squareToSzzZValue810()

    squareToSzzZValue811()

    squareToSzzZValue812()

    squareToSzzZValue813()

    squareToSzzZValue814()

    squareToSzzZValue815()

    squareToSzzZValue816()

    squareToSzzZValue817()

    squareToSzzZValue818()

    squareToSzzZValue819()

    squareToSzzZValue820()

    squareToSzzZValue821()

    squareToSzzZValue822()

    squareToSzzZValue823()

    squareToSzzZValue824()

    squareToSzzZValue825()

    squareToSzzZValue826()

    squareToSzzZValue827()

    squareToSzzZValue828()

    squareToSzzZValue829()

    squareToSzzZValue830()

    squareToSzzZValue831()

    squareToSzzZValue832()

    squareToSzzZValue833()

    squareToSzzZValue834()

    squareToSzzZValue835()

    squareToSzzZValue836()

    squareToSzzZValue837()

    squareToSzzZValue838()

    squareToSzzZValue839()

    squareToSzzZValue840()

    squareToSzzZValue841()

    squareToSzzZValue842()

    squareToSzzZValue843()

    squareToSzzZValue844()

    squareToSzzZValue845()

    squareToSzzZValue846()

    squareToSzzZValue847()

    squareToSzzZValue848()

    squareToSzzZValue849()

    squareToSzzZValue850()

    squareToSzzZValue851()

    squareToSzzZValue852()

    squareToSzzZValue853()

    squareToSzzZValue854()

    squareToSzzZValue855()

    squareToSzzZValue856()

    squareToSzzZValue857()

    squareToSzzZValue858()

    squareToSzzZValue859()

    squareToSzzZValue860()

    squareToSzzZValue861()

    squareToSzzZValue862()

    squareToSzzZValue863()

    squareToSzzZValue864()

    squareToSzzZValue865()

    squareToSzzZValue866()

    squareToSzzZValue867()

    squareToSzzZValue868()

    squareToSzzZValue869()

    squareToSzzZValue870()

    squareToSzzZValue871()

    squareToSzzZValue872()

    squareToSzzZValue873()

    squareToSzzZValue874()

    squareToSzzZValue875()

    squareToSzzZValue876()

    squareToSzzZValue877()

    squareToSzzZValue878()

    squareToSzzZValue879()

    squareToSzzZValue880()

    squareToSzzZValue881()

    squareToSzzZValue882()

    squareToSzzZValue883()

    squareToSzzZValue884()

    squareToSzzZValue885()

    squareToSzzZValue886()

    squareToSzzZValue887()

    squareToSzzZValue888()

    squareToSzzZValue889()

    squareToSzzZValue890()

    squareToSzzZValue891()

    squareToSzzZValue892()

    squareToSzzZValue893()

    squareToSzzZValue894()

    squareToSzzZValue895()

    squareToSzzZValue896()

    squareToSzzZValue897()

    squareToSzzZValue898()

    squareToSzzZValue899()

    squareToSzzZValue900()

    squareToSzzZValue901()

    squareToSzzZValue902()

    squareToSzzZValue903()

    squareToSzzZValue904()

    squareToSzzZValue905()

    squareToSzzZValue906()

    squareToSzzZValue907()

    squareToSzzZValue908()

    squareToSzzZValue909()

    squareToSzzZValue910()

    squareToSzzZValue911()

    squareToSzzZValue912()

    squareToSzzZValue913()

    squareToSzzZValue914()

    squareToSzzZValue915()

    squareToSzzZValue916()

    squareToSzzZValue917()

    squareToSzzZValue918()

    squareToSzzZValue919()

    squareToSzzZValue920()

    squareToSzzZValue921()

    squareToSzzZValue922()

    squareToSzzZValue923()

    squareToSzzZValue924()

    squareToSzzZValue925()

    squareToSzzZValue926()

    squareToSzzZValue927()

    squareToSzzZValue928()

    squareToSzzZValue929()

    squareToSzzZValue930()

    squareToSzzZValue931()

    squareToSzzZValue932()

    squareToSzzZValue933()

    squareToSzzZValue934()

    squareToSzzZValue935()

    squareToSzzZValue936()

    squareToSzzZValue937()

    squareToSzzZValue938()

    squareToSzzZValue939()

    squareToSzzZValue940()

    squareToSzzZValue941()

    squareToSzzZValue942()

    squareToSzzZValue943()

    squareToSzzZValue944()

    squareToSzzZValue945()

    squareToSzzZValue946()

    squareToSzzZValue947()

    squareToSzzZValue948()

    squareToSzzZValue949()

    squareToSzzZValue950()

    squareToSzzZValue951()

    squareToSzzZValue952()

    squareToSzzZValue953()

    squareToSzzZValue954()

    squareToSzzZValue955()

    squareToSzzZValue956()

    squareToSzzZValue957()

    squareToSzzZValue958()

    squareToSzzZValue959()

    squareToSzzZValue960()

    squareToSzzZValue961()

    squareToSzzZValue962()

    squareToSzzZValue963()

    squareToSzzZValue964()

    squareToSzzZValue965()

    squareToSzzZValue966()

    squareToSzzZValue967()

    squareToSzzZValue968()

    squareToSzzZValue969()

    squareToSzzZValue970()

    squareToSzzZValue971()

    squareToSzzZValue972()

    squareToSzzZValue973()

    squareToSzzZValue974()

    squareToSzzZValue975()

    squareToSzzZValue976()

    squareToSzzZValue977()

    squareToSzzZValue978()

    squareToSzzZValue979()

    squareToSzzZValue980()

    squareToSzzZValue981()

    squareToSzzZValue982()

    squareToSzzZValue983()

    squareToSzzZValue984()

    squareToSzzZValue985()

    squareToSzzZValue986()

    squareToSzzZValue987()

    squareToSzzZValue988()

    squareToSzzZValue989()

    squareToSzzZValue990()

    squareToSzzZValue991()

    squareToSzzZValue992()

    squareToSzzZValue993()

    squareToSzzZValue994()

    squareToSzzZValue995()

    squareToSzzZValue996()

    squareToSzzZValue997()

    squareToSzzZValue998()

    squareToSzzZValue999()

    squareToSzzZValue1000()

    squareToSzzZValue1001()

    squareToSzzZValue1002()

    squareToSzzZValue1003()

    squareToSzzZValue1004()

    squareToSzzZValue1005()

    squareToSzzZValue1006()

    squareToSzzZValue1007()

    squareToSzzZValue1008()

    squareToSzzZValue1009()

    squareToSzzZValue1010()

    squareToSzzZValue1011()

    squareToSzzZValue1012()

    squareToSzzZValue1013()

    squareToSzzZValue1014()

    squareToSzzZValue1015()

    squareToSzzZValue1016()

    squareToSzzZValue1017()

    squareToSzzZValue1018()

    squareToSzzZValue1019()

    squareToSzzZValue1020()

    squareToSzzZValue1021()

    squareToSzzZValue1022()

    squareToSzzZValue1023()

    squareToSzzZValue1024()

    squareToSzzZValue1025()

    squareToSzzZValue1026()

    squareToSzzZValue1027()

    squareToSzzZValue1028()

    squareToSzzZValue1029()

    squareToSzzZValue1030()

    squareToSzzZValue1031()

    squareToSzzZValue1032()

    squareToSzzZValue1033()

    squareToSzzZValue1034()

    squareToSzzZValue1035()

    squareToSzzZValue1036()

    squareToSzzZValue1037()

    squareToSzzZValue1038()

    squareToSzzZValue1039()

    squareToSzzZValue1040()

    squareToSzzZValue1041()

    squareToSzzZValue1042()

    squareToSzzZValue1043()

    squareToSzzZValue1044()

    squareToSzzZValue1045()

    squareToSzzZValue1046()

    squareToSzzZValue1047()

    squareToSzzZValue1048()

    squareToSzzZValue1049()

    squareToSzzZValue1050()

    squareToSzzZValue1051()

    squareToSzzZValue1052()

    squareToSzzZValue1053()

    squareToSzzZValue1054()

    squareToSzzZValue1055()

    squareToSzzZValue1056()

    squareToSzzZValue1057()

    squareToSzzZValue1058()

    squareToSzzZValue1059()

    squareToSzzZValue1060()

    squareToSzzZValue1061()

    squareToSzzZValue1062()

    squareToSzzZValue1063()

    squareToSzzZValue1064()

    squareToSzzZValue1065()

    squareToSzzZValue1066()

    squareToSzzZValue1067()

    squareToSzzZValue1068()

    squareToSzzZValue1069()

    squareToSzzZValue1070()

    squareToSzzZValue1071()

    squareToSzzZValue1072()

    squareToSzzZValue1073()

    squareToSzzZValue1074()

    squareToSzzZValue1075()

    squareToSzzZValue1076()

    squareToSzzZValue1077()

    squareToSzzZValue1078()

    squareToSzzZValue1079()

    squareToSzzZValue1080()

    squareToSzzZValue1081()

    squareToSzzZValue1082()

    squareToSzzZValue1083()

    squareToSzzZValue1084()

    squareToSzzZValue1085()

    squareToSzzZValue1086()

    squareToSzzZValue1087()

    squareToSzzZValue1088()

    squareToSzzZValue1089()

    squareToSzzZValue1090()

    squareToSzzZValue1091()

    squareToSzzZValue1092()

    squareToSzzZValue1093()

    squareToSzzZValue1094()

    squareToSzzZValue1095()

    squareToSzzZValue1096()

    squareToSzzZValue1097()

    squareToSzzZValue1098()

    squareToSzzZValue1099()

    squareToSzzZValue1100()

    squareToSzzZValue1101()

    squareToSzzZValue1102()

    squareToSzzZValue1103()

    squareToSzzZValue1104()

    squareToSzzZValue1105()

    squareToSzzZValue1106()

    squareToSzzZValue1107()

    squareToSzzZValue1108()

    squareToSzzZValue1109()

    squareToSzzZValue1110()

    squareToSzzZValue1111()

    squareToSzzZValue1112()

    squareToSzzZValue1113()

    squareToSzzZValue1114()

    squareToSzzZValue1115()

    squareToSzzZValue1116()

    squareToSzzZValue1117()

    squareToSzzZValue1118()

    squareToSzzZValue1119()

    squareToSzzZValue1120()

    squareToSzzZValue1121()

    squareToSzzZValue1122()

    squareToSzzZValue1123()

    squareToSzzZValue1124()

    squareToSzzZValue1125()

    squareToSzzZValue1126()

    squareToSzzZValue1127()

    squareToSzzZValue1128()

    squareToSzzZValue1129()

    squareToSzzZValue1130()

    squareToSzzZValue1131()

    squareToSzzZValue1132()

    squareToSzzZValue1133()

    squareToSzzZValue1134()

    squareToSzzZValue1135()

    squareToSzzZValue1136()

    squareToSzzZValue1137()

    squareToSzzZValue1138()

    squareToSzzZValue1139()

    squareToSzzZValue1140()

    squareToSzzZValue1141()

    squareToSzzZValue1142()

    squareToSzzZValue1143()

    squareToSzzZValue1144()

    squareToSzzZValue1145()

    squareToSzzZValue1146()

    squareToSzzZValue1147()

    squareToSzzZValue1148()

    squareToSzzZValue1149()

    squareToSzzZValue1150()

    squareToSzzZValue1151()

    squareToSzzZValue1152()

    squareToSzzZValue1153()

    squareToSzzZValue1154()

    squareToSzzZValue1155()

    squareToSzzZValue1156()

    squareToSzzZValue1157()

    squareToSzzZValue1158()

    squareToSzzZValue1159()

    squareToSzzZValue1160()

    squareToSzzZValue1161()

    squareToSzzZValue1162()

    squareToSzzZValue1163()

    squareToSzzZValue1164()

    squareToSzzZValue1165()

    squareToSzzZValue1166()

    squareToSzzZValue1167()

    squareToSzzZValue1168()

    squareToSzzZValue1169()

    squareToSzzZValue1170()

    squareToSzzZValue1171()

    squareToSzzZValue1172()

    squareToSzzZValue1173()

    squareToSzzZValue1174()

    squareToSzzZValue1175()

    squareToSzzZValue1176()

    squareToSzzZValue1177()

    squareToSzzZValue1178()

    squareToSzzZValue1179()

    squareToSzzZValue1180()

    squareToSzzZValue1181()

    squareToSzzZValue1182()

    squareToSzzZValue1183()

    squareToSzzZValue1184()

    squareToSzzZValue1185()

    squareToSzzZValue1186()

    squareToSzzZValue1187()

    squareToSzzZValue1188()

    squareToSzzZValue1189()

    squareToSzzZValue1190()

    squareToSzzZValue1191()

    squareToSzzZValue1192()

    squareToSzzZValue1193()

    squareToSzzZValue1194()

    squareToSzzZValue1195()

    squareToSzzZValue1196()

    squareToSzzZValue1197()

    squareToSzzZValue1198()

    squareToSzzZValue1199()

    squareToSzzZValue1200()

    squareToSzzZValue1201()

    squareToSzzZValue1202()

    squareToSzzZValue1203()

    squareToSzzZValue1204()

    squareToSzzZValue1205()

    squareToSzzZValue1206()

    squareToSzzZValue1207()

    squareToSzzZValue1208()

    squareToSzzZValue1209()

    squareToSzzZValue1210()

    squareToSzzZValue1211()

    squareToSzzZValue1212()

    squareToSzzZValue1213()

    squareToSzzZValue1214()

    squareToSzzZValue1215()

    squareToSzzZValue1216()

    squareToSzzZValue1217()

    squareToSzzZValue1218()

    squareToSzzZValue1219()

    squareToSzzZValue1220()

    squareToSzzZValue1221()

    squareToSzzZValue1222()

    squareToSzzZValue1223()

    squareToSzzZValue1224()

    squareToSzzZValue1225()

    alert("Your art has been loaded successfully from your browser's local browser storage.");

};

function squareNull(){
    valueSave = 'zSqrArtSpecz0';
    var tripleZeroA = localStorage.getItem(valueSave);
    if(tripleZeroA == null){
        setAThis();
    }else{
        getBThis();
    };
};