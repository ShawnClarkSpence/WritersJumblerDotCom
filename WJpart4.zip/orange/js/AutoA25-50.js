function autoA52() {
    var z1 = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25"];
    var z2 = ["51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75"];
    var z3 = ["101", "102", "103", "104", "105", "106", "107", "108", "109", "110", "111", "112", "113", "114", "115", "116", "117", "118", "119", "120", "121", "122", "123", "124", "125"];
	var z4 = ["151", "152", "153", "154", "155", "156", "157", "158", "159", "160", "161", "162", "163", "164", "165", "166", "167", "168", "169", "170", "171", "172", "173", "174", "175"];
    var z5 = ["201", "202", "203", "204", "205", "206", "207", "208", "209", "210", "211", "212", "213", "214", "215", "216", "217", "218", "219", "220", "221", "222", "223", "224", "225"];
	var z6 = ["251", "252", "253", "254", "255", "256", "257", "258", "259", "260", "261", "262", "263", "264", "265", "266", "267", "268", "269", "270", "271", "272", "273", "274", "275"];
    var z7 = ["301", "302", "303", "304", "305", "306", "307", "308", "309", "310", "311", "312", "313", "314", "315", "316", "317", "318", "319", "320", "321", "322", "323", "324", "325"];
	var z8 = ["351", "352", "353", "354", "355", "356", "357", "358", "359", "360", "361", "362", "363", "364", "365", "366", "367", "368", "369", "370", "371", "372", "373", "374", "375"];
    var z9 = ["401", "402", "403", "404", "405", "406", "407", "408", "409", "410", "411", "412", "413", "414", "415", "416", "417", "418", "419", "420", "421", "422", "423", "424", "425"];
	var z10 = ["451", "452", "453", "454", "455", "456", "457", "458", "459", "460", "461", "462", "463", "464", "465", "466", "467", "468", "469", "470", "471", "472", "473", "474", "475"];
    var z11 = ["501", "502", "503", "504", "505", "506", "507", "508", "509", "510", "511", "512", "513", "514", "515", "516", "517", "518", "519", "520", "521", "522", "523", "524", "525"];
	var z12 = ["551", "552", "553", "554", "555", "556", "557", "558", "559", "560", "561", "562", "563", "564", "565", "566", "567", "568", "569", "570", "571", "572", "573", "574", "575"];
    var z13 = ["601", "602", "603", "604", "605", "606", "607", "608", "609", "610", "611", "612", "613", "614", "615", "616", "617", "618", "619", "620", "621", "622", "623", "624", "625"];
	var z14 = ["651", "652", "653", "654", "655", "656", "657", "658", "659", "660", "661", "662", "663", "664", "665", "666", "667", "668", "669", "670", "671", "672", "673", "674", "675"];
    var z15 = ["701", "702", "703", "704", "705", "706", "707", "708", "709", "710", "711", "712", "713", "714", "715", "716", "717", "718", "719", "720", "721", "722", "723", "724", "725"];
	var z16 = ["751", "752", "753", "754", "755", "756", "757", "758", "759", "760", "761", "762", "763", "764", "765", "766", "767", "768", "769", "770", "771", "772", "773", "774", "775"];
    var z17 = ["801", "802", "803", "804", "805", "806", "807", "808", "809", "810", "811", "812", "813", "814", "815", "816", "817", "818", "819", "820", "821", "822", "823", "824", "825"];
	var z18 = ["851", "852", "853", "854", "855", "856", "857", "858", "859", "860", "861", "862", "863", "864", "865", "866", "867", "868", "869", "870", "871", "872", "873", "874", "875"];
    var z19 = ["901", "902", "903", "904", "905", "906", "907", "908", "909", "910", "911", "912", "913", "914", "915", "916", "917", "918", "919", "920", "921", "922", "923", "924", "925"];
	var z20 = ["951", "952", "953", "954", "955", "956", "957", "958", "959", "960", "961", "962", "963", "964", "965", "966", "967", "968", "969", "970", "971", "972", "973", "974", "975"];
    var z21 = ["1001", "1002", "1003", "1004", "1005", "1006", "1007", "1008", "1009", "1010", "1011", "1012", "1013", "1014", "1015", "1016", "1017", "1018", "1019", "1020", "1021", "1022", "1023", "1024", "1025"];
	var z22 = ["1051", "1052", "1053", "1054", "1055", "1056", "1057", "1058", "1059", "1060", "1061", "1062", "1063", "1064", "1065", "1066", "1067", "1068", "1069", "1070", "1071", "1072", "1073", "1074", "1075"];
    var z23 = ["1101", "1102", "1103", "1104", "1105", "1106", "1107", "1108", "1109", "1110", "1111", "1112", "1113", "1114", "1115", "1116", "1117", "1118", "1119", "1120", "1121", "1122", "1123", "1124", "1125"];
	var z24 = ["1151", "1152", "1153", "1154", "1155", "1156", "1157", "1158", "1159", "1160", "1161", "1162", "1163", "1164", "1165", "1166", "1167", "1168", "1169", "1170", "1171", "1172", "1173", "1174", "1175"];
    var z25 = ["1201", "1202", "1203", "1204", "1205", "1206", "1207", "1208", "1209", "1210", "1211", "1212", "1213", "1214", "1215", "1216", "1217", "1218", "1219", "1220", "1221", "1222", "1223", "1224", "1225"];
	var x1 = Math.floor(((Math.random() * 25) + 1))
	var x2 = Math.floor(((Math.random() * 25) + 1))
	var x3 = Math.floor(((Math.random() * 25) + 1))
	var x4 = Math.floor(((Math.random() * 25) + 1))
	var x5 = Math.floor(((Math.random() * 25) + 1))
	var x6 = Math.floor(((Math.random() * 25) + 1))
	var x7 = Math.floor(((Math.random() * 25) + 1))
	var x8 = Math.floor(((Math.random() * 25) + 1))
	var x9 = Math.floor(((Math.random() * 25) + 1))
	var x10 = Math.floor(((Math.random() * 25) + 1))
	var x11 = Math.floor(((Math.random() * 25) + 1))
	var x12 = Math.floor(((Math.random() * 25) + 1))
	var x13 = Math.floor(((Math.random() * 25) + 1))
	let a = z1[x1]
	let b = z2[x2]
	let c = z3[x3]
	let d = z4[x4]
	let e = z5[x5]
	let f = z6[x6]
	let g = z7[x7]
	let h = z8[x8]
	let i = z9[x9]
	let j = z10[x10]
	let k = z11[x11]
	let l = z12[x12]
	let m = z13[x13]
	let n = z14[x12]
    let o = z15[x11]
	let p = z16[x10]
	let q = z17[x9]
	let r = z18[x8]
	let s = z19[x7]
	let t = z20[x6]
	let u = z21[x5]
	let v = z22[x4]
	let w = z23[x3]
	let y = z24[x2]
	let z = z25[x1]
	var y2 = a
	var y3 = b
	var y4 = c
	var y5 = d
	var y6 = e
	var y7 = f
 	var y8 = g
	var y9 = h
	var y10 = i
	var y11 = j
	var y12 = k
	var y13 = l
	var y14 = m
	var y15 = n
    var y16 = o
	var y17 = p
	var y18 = q
	var y19 = r
	var y20 = s
	var y21 = t
	var y22 = u
	var y23 = v
	var y24 = w
	var y25 = y
	var y26 = z
	var a1 = 'imgSqrs' + y2
	var b1 = 'imgSqrs' + y3
	var c1 = 'imgSqrs' + y4
	var d1 = 'imgSqrs' + y5
	var e1 = 'imgSqrs' + y6
	var f1 = 'imgSqrs' + y7
	var g1 = 'imgSqrs' + y8
	var h1 = 'imgSqrs' + y9
	var i1 = 'imgSqrs' + y10
	var j1 = 'imgSqrs' + y11
	var k1 = 'imgSqrs' + y12
	var l1 = 'imgSqrs' + y13
	var m1 = 'imgSqrs' + y14
	var n1 = 'imgSqrs' + y15
	var o1 = 'imgSqrs' + y16
	var p1 = 'imgSqrs' + y17
	var q1 = 'imgSqrs' + y18
	var r1 = 'imgSqrs' + y19
	var s1 = 'imgSqrs' + y20
	var t1 = 'imgSqrs' + y21
	var u1 = 'imgSqrs' + y22
	var v1 = 'imgSqrs' + y23
	var w1 = 'imgSqrs' + y24
	var y1 = 'imgSqrs' + y25
	var z1 = 'imgSqrs' + y26
	if(document.getElementById(a1).src = "img/sqrs/wSqr.png") {
		document.getElementById(a1).src = "img/sqrs/blSqr.png"
	};
	if(document.getElementById(b1).src = "img/sqrs/wSqr.png") {
		document.getElementById(b1).src = "img/sqrs/blSqr.png"
	};
	if(document.getElementById(c1).src = "img/sqrs/wSqr.png") {
		document.getElementById(c1).src = "img/sqrs/blSqr.png"
	};
	if(document.getElementById(d1).src = "img/sqrs/wSqr.png") {
		document.getElementById(d1).src = "img/sqrs/blSqr.png"
	};
	if(document.getElementById(e1).src = "img/sqrs/wSqr.png") {
		document.getElementById(e1).src = "img/sqrs/blSqr.png"
	};
	if(document.getElementById(f1).src = "img/sqrs/wSqr.png") {
		document.getElementById(f1).src = "img/sqrs/blSqr.png"
	};
	if(document.getElementById(g1).src = "img/sqrs/wSqr.png") {
		document.getElementById(g1).src = "img/sqrs/blSqr.png"
	};
	if(document.getElementById(h1).src = "img/sqrs/wSqr.png") {
		document.getElementById(h1).src = "img/sqrs/blSqr.png"
	};
	if(document.getElementById(i1).src = "img/sqrs/wSqr.png") {
		document.getElementById(i1).src = "img/sqrs/blSqr.png"
	};
	if(document.getElementById(j1).src = "img/sqrs/wSqr.png") {
		document.getElementById(j1).src = "img/sqrs/blSqr.png"
	};
	if(document.getElementById(k1).src = "img/sqrs/wSqr.png") {
		document.getElementById(k1).src = "img/sqrs/blSqr.png"
	};
	if(document.getElementById(l1).src = "img/sqrs/wSqr.png") {
		document.getElementById(l1).src = "img/sqrs/blSqr.png"
	};
	if(document.getElementById(m1).src = "img/sqrs/wSqr.png") {
		document.getElementById(m1).src = "img/sqrs/blSqr.png"
	};
	if(document.getElementById(n1).src = "img/sqrs/wSqr.png") {
		document.getElementById(n1).src = "img/sqrs/blSqr.png"
	};
	if(document.getElementById(o1).src = "img/sqrs/wSqr.png") {
		document.getElementById(o1).src = "img/sqrs/blSqr.png"
	};
	if(document.getElementById(p1).src = "img/sqrs/wSqr.png") {
		document.getElementById(p1).src = "img/sqrs/blSqr.png"
	};
	if(document.getElementById(q1).src = "img/sqrs/wSqr.png") {
		document.getElementById(q1).src = "img/sqrs/blSqr.png"
	};
	if(document.getElementById(r1).src = "img/sqrs/wSqr.png") {
		document.getElementById(r1).src = "img/sqrs/blSqr.png"
	};
	if(document.getElementById(s1).src = "img/sqrs/wSqr.png") {
		document.getElementById(s1).src = "img/sqrs/blSqr.png"
	};
	if(document.getElementById(t1).src = "img/sqrs/wSqr.png") {
		document.getElementById(t1).src = "img/sqrs/blSqr.png"
	};
	if(document.getElementById(u1).src = "img/sqrs/wSqr.png") {
		document.getElementById(u1).src = "img/sqrs/blSqr.png"
	};
	if(document.getElementById(v1).src = "img/sqrs/wSqr.png") {
		document.getElementById(v1).src = "img/sqrs/blSqr.png"
	};
	if(document.getElementById(w1).src = "img/sqrs/wSqr.png") {
		document.getElementById(w1).src = "img/sqrs/blSqr.png"
	};
	if(document.getElementById(y1).src = "img/sqrs/wSqr.png") {
		document.getElementById(y1).src = "img/sqrs/blSqr.png"
	};
	if(document.getElementById(z1).src = "img/sqrs/wSqr.png") {
		document.getElementById(z1).src = "img/sqrs/blSqr.png"
	};
};