function asqrsA1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs1").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1").src = "img/sqrs/blSqr.png"
};};};

function asqrsA2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs2").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs2").src = "img/sqrs/blSqr.png"
};};};

function asqrsA3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs3").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs3").src = "img/sqrs/blSqr.png"
};};};

function asqrsA4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs4").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs4").src = "img/sqrs/blSqr.png"
};};};

function asqrsA5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs5").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs5").src = "img/sqrs/blSqr.png"
};};};

function asqrsA6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs6").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs6").src = "img/sqrs/blSqr.png"
};};};

function asqrsA7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs7").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs7").src = "img/sqrs/blSqr.png"
};};};

function asqrsA8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs8").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs8").src = "img/sqrs/blSqr.png"
};};};

function asqrsA9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs9").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs9").src = "img/sqrs/blSqr.png"
};};};

function asqrsA10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs10").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs10").src = "img/sqrs/blSqr.png"
};};};

function asqrsA11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs11").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs11").src = "img/sqrs/blSqr.png"
};};};

function asqrsA12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs12").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs12").src = "img/sqrs/blSqr.png"
};};};

function asqrsA13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs13").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs13").src = "img/sqrs/blSqr.png"
};};};

function asqrsA14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs14").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs14").src = "img/sqrs/blSqr.png"
};};};

function asqrsA15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs15").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs15").src = "img/sqrs/blSqr.png"
};};};

function asqrsA16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs16").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs16").src = "img/sqrs/blSqr.png"
};};};

function asqrsA17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs17").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs17").src = "img/sqrs/blSqr.png"
};};};

function asqrsA18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs18").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs18").src = "img/sqrs/blSqr.png"
};};};

function asqrsA19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs19").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs19").src = "img/sqrs/blSqr.png"
};};};

function asqrsA20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs20").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs20").src = "img/sqrs/blSqr.png"
};};};

function asqrsA21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs21").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs21").src = "img/sqrs/blSqr.png"
};};};

function asqrsA22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs22").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs22").src = "img/sqrs/blSqr.png"
};};};

function asqrsA23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs23").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs23").src = "img/sqrs/blSqr.png"
};};};

function asqrsA24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs24").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs24").src = "img/sqrs/blSqr.png"
};};};

function asqrsA25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs25").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs25").src = "img/sqrs/blSqr.png"
};};};

function asqrsA26() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs26").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs26").src = "img/sqrs/blSqr.png"
};};};

function asqrsA27() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs27").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs27").src = "img/sqrs/blSqr.png"
};};};

function asqrsA28() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs28").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs28").src = "img/sqrs/blSqr.png"
};};};

function asqrsA29() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs29").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs29").src = "img/sqrs/blSqr.png"
};};};

function asqrsA30() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs30").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs30").src = "img/sqrs/blSqr.png"
};};};

function asqrsA31() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs31").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs31").src = "img/sqrs/blSqr.png"
};};};

function asqrsA32() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs32").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs32").src = "img/sqrs/blSqr.png"
};};};

function asqrsA33() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs33").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs33").src = "img/sqrs/blSqr.png"
};};};

function asqrsA34() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs34").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs34").src = "img/sqrs/blSqr.png"
};};};

function asqrsA35() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs35").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs35").src = "img/sqrs/blSqr.png"
};};};

function asqrsA36() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs36").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs36").src = "img/sqrs/blSqr.png"
};};};

function asqrsA37() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs37").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs37").src = "img/sqrs/blSqr.png"
};};};

function asqrsA38() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs38").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs38").src = "img/sqrs/blSqr.png"
};};};

function asqrsA39() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs39").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs39").src = "img/sqrs/blSqr.png"
};};};

function asqrsA40() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs40").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs40").src = "img/sqrs/blSqr.png"
};};};

function asqrsA41() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs41").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs41").src = "img/sqrs/blSqr.png"
};};};

function asqrsA42() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs42").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs42").src = "img/sqrs/blSqr.png"
};};};

function asqrsA43() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs43").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs43").src = "img/sqrs/blSqr.png"
};};};

function asqrsA44() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs44").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs44").src = "img/sqrs/blSqr.png"
};};};

function asqrsA45() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs45").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs45").src = "img/sqrs/blSqr.png"
};};};

function asqrsA46() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs46").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs46").src = "img/sqrs/blSqr.png"
};};};

function asqrsA47() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs47").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs47").src = "img/sqrs/blSqr.png"
};};};

function asqrsA48() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs48").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs48").src = "img/sqrs/blSqr.png"
};};};

function asqrsA49() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs49").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs49").src = "img/sqrs/blSqr.png"
};};};

function asqrsA50() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs50").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs50").src = "img/sqrs/blSqr.png"
};};};

function asqrsB51() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs51").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs51").src = "img/sqrs/blSqr.png"
};};};

function asqrsB52() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs52").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs52").src = "img/sqrs/blSqr.png"
};};};

function asqrsB53() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs53").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs53").src = "img/sqrs/blSqr.png"
};};};

function asqrsB54() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs54").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs54").src = "img/sqrs/blSqr.png"
};};};

function asqrsB55() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs55").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs55").src = "img/sqrs/blSqr.png"
};};};

function asqrsB56() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs56").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs56").src = "img/sqrs/blSqr.png"
};};};

function asqrsB57() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs57").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs57").src = "img/sqrs/blSqr.png"
};};};

function asqrsB58() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs58").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs58").src = "img/sqrs/blSqr.png"
};};};

function asqrsB59() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs59").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs59").src = "img/sqrs/blSqr.png"
};};};

function asqrsB60() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs60").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs60").src = "img/sqrs/blSqr.png"
};};};

function asqrsB61() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs61").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs61").src = "img/sqrs/blSqr.png"
};};};

function asqrsB62() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs62").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs62").src = "img/sqrs/blSqr.png"
};};};

function asqrsB63() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs63").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs63").src = "img/sqrs/blSqr.png"
};};};

function asqrsB64() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs64").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs64").src = "img/sqrs/blSqr.png"
};};};

function asqrsB65() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs65").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs65").src = "img/sqrs/blSqr.png"
};};};

function asqrsB66() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs66").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs66").src = "img/sqrs/blSqr.png"
};};};

function asqrsB67() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs67").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs67").src = "img/sqrs/blSqr.png"
};};};

function asqrsB68() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs68").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs68").src = "img/sqrs/blSqr.png"
};};};

function asqrsB69() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs69").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs69").src = "img/sqrs/blSqr.png"
};};};

function asqrsB70() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs70").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs70").src = "img/sqrs/blSqr.png"
};};};

function asqrsB71() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs71").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs71").src = "img/sqrs/blSqr.png"
};};};

function asqrsB72() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs72").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs72").src = "img/sqrs/blSqr.png"
};};};

function asqrsB73() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs73").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs73").src = "img/sqrs/blSqr.png"
};};};

function asqrsB74() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs74").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs74").src = "img/sqrs/blSqr.png"
};};};

function asqrsB75() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs75").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs75").src = "img/sqrs/blSqr.png"
};};};

function asqrsB76() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs76").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs76").src = "img/sqrs/blSqr.png"
};};};

function asqrsB77() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs77").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs77").src = "img/sqrs/blSqr.png"
};};};

function asqrsB78() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs78").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs78").src = "img/sqrs/blSqr.png"
};};};

function asqrsB79() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs79").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs79").src = "img/sqrs/blSqr.png"
};};};

function asqrsB80() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs80").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs80").src = "img/sqrs/blSqr.png"
};};};

function asqrsB81() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs81").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs81").src = "img/sqrs/blSqr.png"
};};};

function asqrsB82() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs82").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs82").src = "img/sqrs/blSqr.png"
};};};

function asqrsB83() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs83").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs83").src = "img/sqrs/blSqr.png"
};};};

function asqrsB84() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs84").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs84").src = "img/sqrs/blSqr.png"
};};};

function asqrsB85() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs85").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs85").src = "img/sqrs/blSqr.png"
};};};

function asqrsB86() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs86").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs86").src = "img/sqrs/blSqr.png"
};};};

function asqrsB87() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs87").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs87").src = "img/sqrs/blSqr.png"
};};};

function asqrsB88() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs88").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs88").src = "img/sqrs/blSqr.png"
};};};

function asqrsB89() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs89").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs89").src = "img/sqrs/blSqr.png"
};};};

function asqrsB90() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs90").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs90").src = "img/sqrs/blSqr.png"
};};};

function asqrsB91() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs91").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs91").src = "img/sqrs/blSqr.png"
};};};

function asqrsB92() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs92").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs92").src = "img/sqrs/blSqr.png"
};};};

function asqrsB93() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs93").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs93").src = "img/sqrs/blSqr.png"
};};};

function asqrsB94() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs94").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs94").src = "img/sqrs/blSqr.png"
};};};

function asqrsB95() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs95").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs95").src = "img/sqrs/blSqr.png"
};};};

function asqrsB96() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs96").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs96").src = "img/sqrs/blSqr.png"
};};};

function asqrsB97() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs97").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs97").src = "img/sqrs/blSqr.png"
};};};

function asqrsB98() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs98").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs98").src = "img/sqrs/blSqr.png"
};};};

function asqrsB99() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs99").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs99").src = "img/sqrs/blSqr.png"
};};};

function asqrsB100() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs100").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs100").src = "img/sqrs/blSqr.png"
};};};

function asqrsC101() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs101").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs101").src = "img/sqrs/blSqr.png"
};};};

function asqrsC102() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs102").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs102").src = "img/sqrs/blSqr.png"
};};};

function asqrsC103() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs103").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs103").src = "img/sqrs/blSqr.png"
};};};

function asqrsC104() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs104").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs104").src = "img/sqrs/blSqr.png"
};};};

function asqrsC105() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs105").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs105").src = "img/sqrs/blSqr.png"
};};};

function asqrsC106() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs106").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs106").src = "img/sqrs/blSqr.png"
};};};

function asqrsC107() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs107").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs107").src = "img/sqrs/blSqr.png"
};};};

function asqrsC108() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs108").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs108").src = "img/sqrs/blSqr.png"
};};};

function asqrsC109() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs109").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs109").src = "img/sqrs/blSqr.png"
};};};

function asqrsC110() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs110").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs110").src = "img/sqrs/blSqr.png"
};};};

function asqrsC111() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs111").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs111").src = "img/sqrs/blSqr.png"
};};};

function asqrsC112() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs112").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs112").src = "img/sqrs/blSqr.png"
};};};

function asqrsC113() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs113").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs113").src = "img/sqrs/blSqr.png"
};};};

function asqrsC114() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs114").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs114").src = "img/sqrs/blSqr.png"
};};};

function asqrsC115() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs115").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs115").src = "img/sqrs/blSqr.png"
};};};

function asqrsC116() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs116").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs116").src = "img/sqrs/blSqr.png"
};};};

function asqrsC117() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs117").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs117").src = "img/sqrs/blSqr.png"
};};};

function asqrsC118() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs118").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs118").src = "img/sqrs/blSqr.png"
};};};

function asqrsC119() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs119").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs119").src = "img/sqrs/blSqr.png"
};};};

function asqrsC120() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs120").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs120").src = "img/sqrs/blSqr.png"
};};};

function asqrsC121() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs121").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs121").src = "img/sqrs/blSqr.png"
};};};

function asqrsC122() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs122").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs122").src = "img/sqrs/blSqr.png"
};};};

function asqrsC123() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs123").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs123").src = "img/sqrs/blSqr.png"
};};};

function asqrsC124() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs124").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs124").src = "img/sqrs/blSqr.png"
};};};

function asqrsC125() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs125").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs125").src = "img/sqrs/blSqr.png"
};};};

function asqrsC126() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs126").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs126").src = "img/sqrs/blSqr.png"
};};};

function asqrsC127() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs127").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs127").src = "img/sqrs/blSqr.png"
};};};

function asqrsC128() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs128").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs128").src = "img/sqrs/blSqr.png"
};};};

function asqrsC129() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs129").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs129").src = "img/sqrs/blSqr.png"
};};};

function asqrsC130() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs130").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs130").src = "img/sqrs/blSqr.png"
};};};

function asqrsC131() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs131").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs131").src = "img/sqrs/blSqr.png"
};};};

function asqrsC132() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs132").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs132").src = "img/sqrs/blSqr.png"
};};};

function asqrsC133() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs133").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs133").src = "img/sqrs/blSqr.png"
};};};

function asqrsC134() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs134").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs134").src = "img/sqrs/blSqr.png"
};};};

function asqrsC135() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs135").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs135").src = "img/sqrs/blSqr.png"
};};};

function asqrsC136() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs136").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs136").src = "img/sqrs/blSqr.png"
};};};

function asqrsC137() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs137").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs137").src = "img/sqrs/blSqr.png"
};};};

function asqrsC138() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs138").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs138").src = "img/sqrs/blSqr.png"
};};};

function asqrsC139() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs139").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs139").src = "img/sqrs/blSqr.png"
};};};

function asqrsC140() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs140").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs140").src = "img/sqrs/blSqr.png"
};};};

function asqrsC141() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs141").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs141").src = "img/sqrs/blSqr.png"
};};};

function asqrsC142() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs142").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs142").src = "img/sqrs/blSqr.png"
};};};

function asqrsC143() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs143").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs143").src = "img/sqrs/blSqr.png"
};};};

function asqrsC144() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs144").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs144").src = "img/sqrs/blSqr.png"
};};};

function asqrsC145() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs145").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs145").src = "img/sqrs/blSqr.png"
};};};

function asqrsC146() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs146").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs146").src = "img/sqrs/blSqr.png"
};};};

function asqrsC147() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs147").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs147").src = "img/sqrs/blSqr.png"
};};};

function asqrsC148() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs148").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs148").src = "img/sqrs/blSqr.png"
};};};

function asqrsC149() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs149").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs149").src = "img/sqrs/blSqr.png"
};};};

function asqrsC150() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs150").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs150").src = "img/sqrs/blSqr.png"
};};};

function asqrsD151() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs151").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs151").src = "img/sqrs/blSqr.png"
};};};

function asqrsD152() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs152").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs152").src = "img/sqrs/blSqr.png"
};};};

function asqrsD153() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs153").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs153").src = "img/sqrs/blSqr.png"
};};};

function asqrsD154() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs154").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs154").src = "img/sqrs/blSqr.png"
};};};

function asqrsD155() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs155").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs155").src = "img/sqrs/blSqr.png"
};};};

function asqrsD156() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs156").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs156").src = "img/sqrs/blSqr.png"
};};};

function asqrsD157() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs157").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs157").src = "img/sqrs/blSqr.png"
};};};

function asqrsD158() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs158").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs158").src = "img/sqrs/blSqr.png"
};};};

function asqrsD159() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs159").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs159").src = "img/sqrs/blSqr.png"
};};};

function asqrsD160() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs160").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs160").src = "img/sqrs/blSqr.png"
};};};

function asqrsD161() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs161").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs161").src = "img/sqrs/blSqr.png"
};};};

function asqrsD162() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs162").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs162").src = "img/sqrs/blSqr.png"
};};};

function asqrsD163() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs163").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs163").src = "img/sqrs/blSqr.png"
};};};

function asqrsD164() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs164").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs164").src = "img/sqrs/blSqr.png"
};};};

function asqrsD165() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs165").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs165").src = "img/sqrs/blSqr.png"
};};};

function asqrsD166() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs166").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs166").src = "img/sqrs/blSqr.png"
};};};

function asqrsD167() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs167").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs167").src = "img/sqrs/blSqr.png"
};};};

function asqrsD168() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs168").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs168").src = "img/sqrs/blSqr.png"
};};};

function asqrsD169() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs169").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs169").src = "img/sqrs/blSqr.png"
};};};

function asqrsD170() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs170").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs170").src = "img/sqrs/blSqr.png"
};};};

function asqrsD171() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs171").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs171").src = "img/sqrs/blSqr.png"
};};};

function asqrsD172() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs172").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs172").src = "img/sqrs/blSqr.png"
};};};

function asqrsD173() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs173").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs173").src = "img/sqrs/blSqr.png"
};};};

function asqrsD174() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs174").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs174").src = "img/sqrs/blSqr.png"
};};};

function asqrsD175() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs175").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs175").src = "img/sqrs/blSqr.png"
};};};

function asqrsD176() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs176").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs176").src = "img/sqrs/blSqr.png"
};};};

function asqrsD177() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs177").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs177").src = "img/sqrs/blSqr.png"
};};};

function asqrsD178() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs178").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs178").src = "img/sqrs/blSqr.png"
};};};

function asqrsD179() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs179").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs179").src = "img/sqrs/blSqr.png"
};};};

function asqrsD180() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs180").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs180").src = "img/sqrs/blSqr.png"
};};};

function asqrsD181() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs181").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs181").src = "img/sqrs/blSqr.png"
};};};

function asqrsD182() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs182").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs182").src = "img/sqrs/blSqr.png"
};};};

function asqrsD183() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs183").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs183").src = "img/sqrs/blSqr.png"
};};};

function asqrsD184() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs184").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs184").src = "img/sqrs/blSqr.png"
};};};

function asqrsD185() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs185").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs185").src = "img/sqrs/blSqr.png"
};};};

function asqrsD186() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs186").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs186").src = "img/sqrs/blSqr.png"
};};};

function asqrsD187() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs187").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs187").src = "img/sqrs/blSqr.png"
};};};

function asqrsD188() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs188").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs188").src = "img/sqrs/blSqr.png"
};};};

function asqrsD189() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs189").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs189").src = "img/sqrs/blSqr.png"
};};};

function asqrsD190() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs190").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs190").src = "img/sqrs/blSqr.png"
};};};

function asqrsD191() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs191").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs191").src = "img/sqrs/blSqr.png"
};};};

function asqrsD192() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs192").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs192").src = "img/sqrs/blSqr.png"
};};};

function asqrsD193() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs193").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs193").src = "img/sqrs/blSqr.png"
};};};

function asqrsD194() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs194").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs194").src = "img/sqrs/blSqr.png"
};};};

function asqrsD195() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs195").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs195").src = "img/sqrs/blSqr.png"
};};};

function asqrsD196() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs196").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs196").src = "img/sqrs/blSqr.png"
};};};

function asqrsD197() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs197").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs197").src = "img/sqrs/blSqr.png"
};};};

function asqrsD198() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs198").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs198").src = "img/sqrs/blSqr.png"
};};};

function asqrsD199() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs199").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs199").src = "img/sqrs/blSqr.png"
};};};

function asqrsD200() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs200").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs200").src = "img/sqrs/blSqr.png"
};};};

function asqrsE201() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs201").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs201").src = "img/sqrs/blSqr.png"
};};};

function asqrsE202() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs202").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs202").src = "img/sqrs/blSqr.png"
};};};

function asqrsE203() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs203").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs203").src = "img/sqrs/blSqr.png"
};};};

function asqrsE204() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs204").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs204").src = "img/sqrs/blSqr.png"
};};};

function asqrsE205() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs205").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs205").src = "img/sqrs/blSqr.png"
};};};

function asqrsE206() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs206").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs206").src = "img/sqrs/blSqr.png"
};};};

function asqrsE207() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs207").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs207").src = "img/sqrs/blSqr.png"
};};};

function asqrsE208() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs208").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs208").src = "img/sqrs/blSqr.png"
};};};

function asqrsE209() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs209").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs209").src = "img/sqrs/blSqr.png"
};};};

function asqrsE210() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs210").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs210").src = "img/sqrs/blSqr.png"
};};};

function asqrsE211() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs211").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs211").src = "img/sqrs/blSqr.png"
};};};

function asqrsE212() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs212").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs212").src = "img/sqrs/blSqr.png"
};};};

function asqrsE213() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs213").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs213").src = "img/sqrs/blSqr.png"
};};};

function asqrsE214() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs214").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs214").src = "img/sqrs/blSqr.png"
};};};

function asqrsE215() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs215").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs215").src = "img/sqrs/blSqr.png"
};};};

function asqrsE216() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs216").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs216").src = "img/sqrs/blSqr.png"
};};};

function asqrsE217() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs217").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs217").src = "img/sqrs/blSqr.png"
};};};

function asqrsE218() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs218").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs218").src = "img/sqrs/blSqr.png"
};};};

function asqrsE219() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs219").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs219").src = "img/sqrs/blSqr.png"
};};};

function asqrsE220() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs220").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs220").src = "img/sqrs/blSqr.png"
};};};

function asqrsE221() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs221").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs221").src = "img/sqrs/blSqr.png"
};};};

function asqrsE222() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs222").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs222").src = "img/sqrs/blSqr.png"
};};};

function asqrsE223() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs223").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs223").src = "img/sqrs/blSqr.png"
};};};

function asqrsE224() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs224").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs224").src = "img/sqrs/blSqr.png"
};};};

function asqrsE225() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs225").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs225").src = "img/sqrs/blSqr.png"
};};};

function asqrsE226() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs226").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs226").src = "img/sqrs/blSqr.png"
};};};

function asqrsE227() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs227").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs227").src = "img/sqrs/blSqr.png"
};};};

function asqrsE228() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs228").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs228").src = "img/sqrs/blSqr.png"
};};};

function asqrsE229() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs229").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs229").src = "img/sqrs/blSqr.png"
};};};

function asqrsE230() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs230").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs230").src = "img/sqrs/blSqr.png"
};};};

function asqrsE231() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs231").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs231").src = "img/sqrs/blSqr.png"
};};};

function asqrsE232() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs232").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs232").src = "img/sqrs/blSqr.png"
};};};

function asqrsE233() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs233").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs233").src = "img/sqrs/blSqr.png"
};};};

function asqrsE234() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs234").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs234").src = "img/sqrs/blSqr.png"
};};};

function asqrsE235() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs235").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs235").src = "img/sqrs/blSqr.png"
};};};

function asqrsE236() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs236").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs236").src = "img/sqrs/blSqr.png"
};};};

function asqrsE237() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs237").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs237").src = "img/sqrs/blSqr.png"
};};};

function asqrsE238() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs238").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs238").src = "img/sqrs/blSqr.png"
};};};

function asqrsE239() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs239").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs239").src = "img/sqrs/blSqr.png"
};};};

function asqrsE240() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs240").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs240").src = "img/sqrs/blSqr.png"
};};};

function asqrsE241() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs241").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs241").src = "img/sqrs/blSqr.png"
};};};

function asqrsE242() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs242").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs242").src = "img/sqrs/blSqr.png"
};};};

function asqrsE243() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs243").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs243").src = "img/sqrs/blSqr.png"
};};};

function asqrsE244() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs244").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs244").src = "img/sqrs/blSqr.png"
};};};

function asqrsE245() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs245").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs245").src = "img/sqrs/blSqr.png"
};};};

function asqrsE246() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs246").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs246").src = "img/sqrs/blSqr.png"
};};};

function asqrsE247() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs247").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs247").src = "img/sqrs/blSqr.png"
};};};

function asqrsE248() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs248").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs248").src = "img/sqrs/blSqr.png"
};};};

function asqrsE249() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs249").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs249").src = "img/sqrs/blSqr.png"
};};};

function asqrsE250() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs250").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs250").src = "img/sqrs/blSqr.png"
};};};

function asqrsF251() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs251").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs251").src = "img/sqrs/blSqr.png"
};};};

function asqrsF252() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs252").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs252").src = "img/sqrs/blSqr.png"
};};};

function asqrsF253() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs253").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs253").src = "img/sqrs/blSqr.png"
};};};

function asqrsF254() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs254").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs254").src = "img/sqrs/blSqr.png"
};};};

function asqrsF255() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs255").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs255").src = "img/sqrs/blSqr.png"
};};};

function asqrsF256() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs256").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs256").src = "img/sqrs/blSqr.png"
};};};

function asqrsF257() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs257").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs257").src = "img/sqrs/blSqr.png"
};};};

function asqrsF258() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs258").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs258").src = "img/sqrs/blSqr.png"
};};};

function asqrsF259() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs259").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs259").src = "img/sqrs/blSqr.png"
};};};

function asqrsF260() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs260").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs260").src = "img/sqrs/blSqr.png"
};};};

function asqrsF261() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs261").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs261").src = "img/sqrs/blSqr.png"
};};};

function asqrsF262() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs262").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs262").src = "img/sqrs/blSqr.png"
};};};

function asqrsF263() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs263").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs263").src = "img/sqrs/blSqr.png"
};};};

function asqrsF264() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs264").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs264").src = "img/sqrs/blSqr.png"
};};};

function asqrsF265() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs265").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs265").src = "img/sqrs/blSqr.png"
};};};

function asqrsF266() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs266").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs266").src = "img/sqrs/blSqr.png"
};};};

function asqrsF267() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs267").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs267").src = "img/sqrs/blSqr.png"
};};};

function asqrsF268() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs268").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs268").src = "img/sqrs/blSqr.png"
};};};

function asqrsF269() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs269").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs269").src = "img/sqrs/blSqr.png"
};};};

function asqrsF270() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs270").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs270").src = "img/sqrs/blSqr.png"
};};};

function asqrsF271() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs271").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs271").src = "img/sqrs/blSqr.png"
};};};

function asqrsF272() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs272").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs272").src = "img/sqrs/blSqr.png"
};};};

function asqrsF273() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs273").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs273").src = "img/sqrs/blSqr.png"
};};};

function asqrsF274() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs274").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs274").src = "img/sqrs/blSqr.png"
};};};

function asqrsF275() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs275").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs275").src = "img/sqrs/blSqr.png"
};};};

function asqrsF276() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs276").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs276").src = "img/sqrs/blSqr.png"
};};};

function asqrsF277() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs277").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs277").src = "img/sqrs/blSqr.png"
};};};

function asqrsF278() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs278").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs278").src = "img/sqrs/blSqr.png"
};};};

function asqrsF279() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs279").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs279").src = "img/sqrs/blSqr.png"
};};};

function asqrsF280() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs280").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs280").src = "img/sqrs/blSqr.png"
};};};

function asqrsF281() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs281").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs281").src = "img/sqrs/blSqr.png"
};};};

function asqrsF282() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs282").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs282").src = "img/sqrs/blSqr.png"
};};};

function asqrsF283() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs283").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs283").src = "img/sqrs/blSqr.png"
};};};

function asqrsF284() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs284").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs284").src = "img/sqrs/blSqr.png"
};};};

function asqrsF285() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs285").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs285").src = "img/sqrs/blSqr.png"
};};};

function asqrsF286() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs286").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs286").src = "img/sqrs/blSqr.png"
};};};

function asqrsF287() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs287").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs287").src = "img/sqrs/blSqr.png"
};};};

function asqrsF288() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs288").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs288").src = "img/sqrs/blSqr.png"
};};};

function asqrsF289() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs289").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs289").src = "img/sqrs/blSqr.png"
};};};

function asqrsF290() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs290").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs290").src = "img/sqrs/blSqr.png"
};};};

function asqrsF291() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs291").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs291").src = "img/sqrs/blSqr.png"
};};};

function asqrsF292() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs292").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs292").src = "img/sqrs/blSqr.png"
};};};

function asqrsF293() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs293").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs293").src = "img/sqrs/blSqr.png"
};};};

function asqrsF294() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs294").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs294").src = "img/sqrs/blSqr.png"
};};};

function asqrsF295() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs295").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs295").src = "img/sqrs/blSqr.png"
};};};

function asqrsF296() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs296").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs296").src = "img/sqrs/blSqr.png"
};};};

function asqrsF297() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs297").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs297").src = "img/sqrs/blSqr.png"
};};};

function asqrsF298() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs298").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs298").src = "img/sqrs/blSqr.png"
};};};

function asqrsF299() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs299").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs299").src = "img/sqrs/blSqr.png"
};};};

function asqrsF300() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs300").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs300").src = "img/sqrs/blSqr.png"
};};};

function asqrsG301() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs301").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs301").src = "img/sqrs/blSqr.png"
};};};

function asqrsG302() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs302").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs302").src = "img/sqrs/blSqr.png"
};};};

function asqrsG303() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs303").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs303").src = "img/sqrs/blSqr.png"
};};};

function asqrsG304() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs304").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs304").src = "img/sqrs/blSqr.png"
};};};

function asqrsG305() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs305").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs305").src = "img/sqrs/blSqr.png"
};};};

function asqrsG306() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs306").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs306").src = "img/sqrs/blSqr.png"
};};};

function asqrsG307() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs307").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs307").src = "img/sqrs/blSqr.png"
};};};

function asqrsG308() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs308").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs308").src = "img/sqrs/blSqr.png"
};};};

function asqrsG309() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs309").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs309").src = "img/sqrs/blSqr.png"
};};};

function asqrsG310() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs310").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs310").src = "img/sqrs/blSqr.png"
};};};

function asqrsG311() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs311").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs311").src = "img/sqrs/blSqr.png"
};};};

function asqrsG312() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs312").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs312").src = "img/sqrs/blSqr.png"
};};};

function asqrsG313() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs313").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs313").src = "img/sqrs/blSqr.png"
};};};

function asqrsG314() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs314").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs314").src = "img/sqrs/blSqr.png"
};};};

function asqrsG315() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs315").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs315").src = "img/sqrs/blSqr.png"
};};};

function asqrsG316() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs316").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs316").src = "img/sqrs/blSqr.png"
};};};

function asqrsG317() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs317").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs317").src = "img/sqrs/blSqr.png"
};};};

function asqrsG318() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs318").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs318").src = "img/sqrs/blSqr.png"
};};};

function asqrsG319() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs319").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs319").src = "img/sqrs/blSqr.png"
};};};

function asqrsG320() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs320").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs320").src = "img/sqrs/blSqr.png"
};};};

function asqrsG321() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs321").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs321").src = "img/sqrs/blSqr.png"
};};};

function asqrsG322() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs322").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs322").src = "img/sqrs/blSqr.png"
};};};

function asqrsG323() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs323").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs323").src = "img/sqrs/blSqr.png"
};};};

function asqrsG324() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs324").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs324").src = "img/sqrs/blSqr.png"
};};};

function asqrsG325() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs325").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs325").src = "img/sqrs/blSqr.png"
};};};

function asqrsG326() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs326").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs326").src = "img/sqrs/blSqr.png"
};};};

function asqrsG327() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs327").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs327").src = "img/sqrs/blSqr.png"
};};};

function asqrsG328() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs328").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs328").src = "img/sqrs/blSqr.png"
};};};

function asqrsG329() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs329").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs329").src = "img/sqrs/blSqr.png"
};};};

function asqrsG330() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs330").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs330").src = "img/sqrs/blSqr.png"
};};};

function asqrsG331() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs331").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs331").src = "img/sqrs/blSqr.png"
};};};

function asqrsG332() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs332").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs332").src = "img/sqrs/blSqr.png"
};};};

function asqrsG333() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs333").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs333").src = "img/sqrs/blSqr.png"
};};};

function asqrsG334() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs334").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs334").src = "img/sqrs/blSqr.png"
};};};

function asqrsG335() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs335").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs335").src = "img/sqrs/blSqr.png"
};};};

function asqrsG336() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs336").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs336").src = "img/sqrs/blSqr.png"
};};};

function asqrsG337() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs337").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs337").src = "img/sqrs/blSqr.png"
};};};

function asqrsG338() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs338").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs338").src = "img/sqrs/blSqr.png"
};};};

function asqrsG339() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs339").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs339").src = "img/sqrs/blSqr.png"
};};};

function asqrsG340() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs340").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs340").src = "img/sqrs/blSqr.png"
};};};

function asqrsG341() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs341").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs341").src = "img/sqrs/blSqr.png"
};};};

function asqrsG342() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs342").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs342").src = "img/sqrs/blSqr.png"
};};};

function asqrsG343() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs343").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs343").src = "img/sqrs/blSqr.png"
};};};

function asqrsG344() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs344").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs344").src = "img/sqrs/blSqr.png"
};};};

function asqrsG345() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs345").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs345").src = "img/sqrs/blSqr.png"
};};};

function asqrsG346() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs346").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs346").src = "img/sqrs/blSqr.png"
};};};

function asqrsG347() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs347").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs347").src = "img/sqrs/blSqr.png"
};};};

function asqrsG348() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs348").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs348").src = "img/sqrs/blSqr.png"
};};};

function asqrsG349() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs349").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs349").src = "img/sqrs/blSqr.png"
};};};

function asqrsG350() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs350").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs350").src = "img/sqrs/blSqr.png"
};};};

function asqrsH351() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs351").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs351").src = "img/sqrs/blSqr.png"
};};};

function asqrsH352() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs352").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs352").src = "img/sqrs/blSqr.png"
};};};

function asqrsH353() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs353").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs353").src = "img/sqrs/blSqr.png"
};};};

function asqrsH354() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs354").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs354").src = "img/sqrs/blSqr.png"
};};};

function asqrsH355() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs355").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs355").src = "img/sqrs/blSqr.png"
};};};

function asqrsH356() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs356").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs356").src = "img/sqrs/blSqr.png"
};};};

function asqrsH357() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs357").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs357").src = "img/sqrs/blSqr.png"
};};};

function asqrsH358() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs358").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs358").src = "img/sqrs/blSqr.png"
};};};

function asqrsH359() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs359").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs359").src = "img/sqrs/blSqr.png"
};};};

function asqrsH360() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs360").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs360").src = "img/sqrs/blSqr.png"
};};};

function asqrsH361() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs361").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs361").src = "img/sqrs/blSqr.png"
};};};

function asqrsH362() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs362").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs362").src = "img/sqrs/blSqr.png"
};};};

function asqrsH363() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs363").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs363").src = "img/sqrs/blSqr.png"
};};};

function asqrsH364() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs364").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs364").src = "img/sqrs/blSqr.png"
};};};

function asqrsH365() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs365").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs365").src = "img/sqrs/blSqr.png"
};};};

function asqrsH366() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs366").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs366").src = "img/sqrs/blSqr.png"
};};};

function asqrsH367() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs367").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs367").src = "img/sqrs/blSqr.png"
};};};

function asqrsH368() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs368").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs368").src = "img/sqrs/blSqr.png"
};};};

function asqrsH369() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs369").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs369").src = "img/sqrs/blSqr.png"
};};};

function asqrsH370() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs370").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs370").src = "img/sqrs/blSqr.png"
};};};

function asqrsH371() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs371").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs371").src = "img/sqrs/blSqr.png"
};};};

function asqrsH372() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs372").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs372").src = "img/sqrs/blSqr.png"
};};};

function asqrsH373() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs373").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs373").src = "img/sqrs/blSqr.png"
};};};

function asqrsH374() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs374").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs374").src = "img/sqrs/blSqr.png"
};};};

function asqrsH375() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs375").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs375").src = "img/sqrs/blSqr.png"
};};};

function asqrsH376() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs376").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs376").src = "img/sqrs/blSqr.png"
};};};

function asqrsH377() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs377").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs377").src = "img/sqrs/blSqr.png"
};};};

function asqrsH378() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs378").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs378").src = "img/sqrs/blSqr.png"
};};};

function asqrsH379() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs379").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs379").src = "img/sqrs/blSqr.png"
};};};

function asqrsH380() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs380").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs380").src = "img/sqrs/blSqr.png"
};};};

function asqrsH381() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs381").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs381").src = "img/sqrs/blSqr.png"
};};};

function asqrsH382() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs382").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs382").src = "img/sqrs/blSqr.png"
};};};

function asqrsH383() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs383").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs383").src = "img/sqrs/blSqr.png"
};};};

function asqrsH384() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs384").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs384").src = "img/sqrs/blSqr.png"
};};};

function asqrsH385() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs385").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs385").src = "img/sqrs/blSqr.png"
};};};

function asqrsH386() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs386").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs386").src = "img/sqrs/blSqr.png"
};};};

function asqrsH387() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs387").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs387").src = "img/sqrs/blSqr.png"
};};};

function asqrsH388() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs388").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs388").src = "img/sqrs/blSqr.png"
};};};

function asqrsH389() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs389").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs389").src = "img/sqrs/blSqr.png"
};};};

function asqrsH390() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs390").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs390").src = "img/sqrs/blSqr.png"
};};};

function asqrsH391() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs391").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs391").src = "img/sqrs/blSqr.png"
};};};

function asqrsH392() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs392").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs392").src = "img/sqrs/blSqr.png"
};};};

function asqrsH393() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs393").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs393").src = "img/sqrs/blSqr.png"
};};};

function asqrsH394() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs394").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs394").src = "img/sqrs/blSqr.png"
};};};

function asqrsH395() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs395").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs395").src = "img/sqrs/blSqr.png"
};};};

function asqrsH396() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs396").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs396").src = "img/sqrs/blSqr.png"
};};};

function asqrsH397() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs397").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs397").src = "img/sqrs/blSqr.png"
};};};

function asqrsH398() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs398").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs398").src = "img/sqrs/blSqr.png"
};};};

function asqrsH399() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs399").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs399").src = "img/sqrs/blSqr.png"
};};};

function asqrsH400() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs400").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs400").src = "img/sqrs/blSqr.png"
};};};

function asqrsI401() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs401").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs401").src = "img/sqrs/blSqr.png"
};};};

function asqrsI402() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs402").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs402").src = "img/sqrs/blSqr.png"
};};};

function asqrsI403() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs403").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs403").src = "img/sqrs/blSqr.png"
};};};

function asqrsI404() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs404").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs404").src = "img/sqrs/blSqr.png"
};};};

function asqrsI405() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs405").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs405").src = "img/sqrs/blSqr.png"
};};};

function asqrsI406() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs406").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs406").src = "img/sqrs/blSqr.png"
};};};

function asqrsI407() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs407").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs407").src = "img/sqrs/blSqr.png"
};};};

function asqrsI408() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs408").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs408").src = "img/sqrs/blSqr.png"
};};};

function asqrsI409() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs409").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs409").src = "img/sqrs/blSqr.png"
};};};

function asqrsI410() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs410").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs410").src = "img/sqrs/blSqr.png"
};};};

function asqrsI411() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs411").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs411").src = "img/sqrs/blSqr.png"
};};};

function asqrsI412() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs412").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs412").src = "img/sqrs/blSqr.png"
};};};

function asqrsI413() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs413").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs413").src = "img/sqrs/blSqr.png"
};};};

function asqrsI414() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs414").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs414").src = "img/sqrs/blSqr.png"
};};};

function asqrsI415() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs415").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs415").src = "img/sqrs/blSqr.png"
};};};

function asqrsI416() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs416").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs416").src = "img/sqrs/blSqr.png"
};};};

function asqrsI417() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs417").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs417").src = "img/sqrs/blSqr.png"
};};};

function asqrsI418() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs418").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs418").src = "img/sqrs/blSqr.png"
};};};

function asqrsI419() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs419").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs419").src = "img/sqrs/blSqr.png"
};};};

function asqrsI420() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs420").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs420").src = "img/sqrs/blSqr.png"
};};};

function asqrsI421() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs421").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs421").src = "img/sqrs/blSqr.png"
};};};

function asqrsI422() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs422").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs422").src = "img/sqrs/blSqr.png"
};};};

function asqrsI423() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs423").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs423").src = "img/sqrs/blSqr.png"
};};};

function asqrsI424() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs424").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs424").src = "img/sqrs/blSqr.png"
};};};

function asqrsI425() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs425").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs425").src = "img/sqrs/blSqr.png"
};};};

function asqrsI426() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs426").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs426").src = "img/sqrs/blSqr.png"
};};};

function asqrsI427() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs427").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs427").src = "img/sqrs/blSqr.png"
};};};

function asqrsI428() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs428").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs428").src = "img/sqrs/blSqr.png"
};};};

function asqrsI429() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs429").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs429").src = "img/sqrs/blSqr.png"
};};};

function asqrsI430() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs430").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs430").src = "img/sqrs/blSqr.png"
};};};

function asqrsI431() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs431").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs431").src = "img/sqrs/blSqr.png"
};};};

function asqrsI432() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs432").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs432").src = "img/sqrs/blSqr.png"
};};};

function asqrsI433() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs433").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs433").src = "img/sqrs/blSqr.png"
};};};

function asqrsI434() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs434").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs434").src = "img/sqrs/blSqr.png"
};};};

function asqrsI435() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs435").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs435").src = "img/sqrs/blSqr.png"
};};};

function asqrsI436() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs436").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs436").src = "img/sqrs/blSqr.png"
};};};

function asqrsI437() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs437").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs437").src = "img/sqrs/blSqr.png"
};};};

function asqrsI438() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs438").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs438").src = "img/sqrs/blSqr.png"
};};};

function asqrsI439() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs439").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs439").src = "img/sqrs/blSqr.png"
};};};

function asqrsI440() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs440").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs440").src = "img/sqrs/blSqr.png"
};};};

function asqrsI441() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs441").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs441").src = "img/sqrs/blSqr.png"
};};};

function asqrsI442() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs442").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs442").src = "img/sqrs/blSqr.png"
};};};

function asqrsI443() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs443").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs443").src = "img/sqrs/blSqr.png"
};};};

function asqrsI444() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs444").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs444").src = "img/sqrs/blSqr.png"
};};};

function asqrsI445() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs445").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs445").src = "img/sqrs/blSqr.png"
};};};

function asqrsI446() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs446").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs446").src = "img/sqrs/blSqr.png"
};};};

function asqrsI447() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs447").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs447").src = "img/sqrs/blSqr.png"
};};};

function asqrsI448() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs448").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs448").src = "img/sqrs/blSqr.png"
};};};

function asqrsI449() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs449").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs449").src = "img/sqrs/blSqr.png"
};};};

function asqrsI450() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs450").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs450").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ451() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs451").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs451").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ452() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs452").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs452").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ453() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs453").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs453").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ454() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs454").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs454").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ455() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs455").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs455").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ456() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs456").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs456").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ457() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs457").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs457").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ458() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs458").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs458").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ459() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs459").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs459").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ460() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs460").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs460").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ461() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs461").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs461").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ462() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs462").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs462").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ463() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs463").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs463").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ464() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs464").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs464").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ465() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs465").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs465").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ466() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs466").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs466").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ467() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs467").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs467").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ468() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs468").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs468").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ469() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs469").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs469").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ470() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs470").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs470").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ471() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs471").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs471").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ472() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs472").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs472").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ473() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs473").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs473").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ474() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs474").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs474").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ475() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs475").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs475").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ476() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs476").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs476").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ477() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs477").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs477").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ478() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs478").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs478").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ479() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs479").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs479").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ480() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs480").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs480").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ481() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs481").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs481").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ482() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs482").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs482").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ483() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs483").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs483").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ484() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs484").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs484").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ485() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs485").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs485").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ486() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs486").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs486").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ487() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs487").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs487").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ488() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs488").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs488").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ489() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs489").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs489").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ490() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs490").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs490").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ491() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs491").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs491").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ492() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs492").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs492").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ493() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs493").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs493").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ494() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs494").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs494").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ495() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs495").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs495").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ496() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs496").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs496").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ497() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs497").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs497").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ498() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs498").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs498").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ499() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs499").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs499").src = "img/sqrs/blSqr.png"
};};};

function asqrsJ500() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs500").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs500").src = "img/sqrs/blSqr.png"
};};};

function asqrsK501() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs501").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs501").src = "img/sqrs/blSqr.png"
};};};

function asqrsK502() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs502").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs502").src = "img/sqrs/blSqr.png"
};};};

function asqrsK503() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs503").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs503").src = "img/sqrs/blSqr.png"
};};};

function asqrsK504() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs504").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs504").src = "img/sqrs/blSqr.png"
};};};

function asqrsK505() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs505").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs505").src = "img/sqrs/blSqr.png"
};};};

function asqrsK506() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs506").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs506").src = "img/sqrs/blSqr.png"
};};};

function asqrsK507() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs507").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs507").src = "img/sqrs/blSqr.png"
};};};

function asqrsK508() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs508").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs508").src = "img/sqrs/blSqr.png"
};};};

function asqrsK509() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs509").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs509").src = "img/sqrs/blSqr.png"
};};};

function asqrsK510() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs510").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs510").src = "img/sqrs/blSqr.png"
};};};

function asqrsK511() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs511").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs511").src = "img/sqrs/blSqr.png"
};};};

function asqrsK512() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs512").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs512").src = "img/sqrs/blSqr.png"
};};};

function asqrsK513() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs513").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs513").src = "img/sqrs/blSqr.png"
};};};

function asqrsK514() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs514").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs514").src = "img/sqrs/blSqr.png"
};};};

function asqrsK515() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs515").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs515").src = "img/sqrs/blSqr.png"
};};};

function asqrsK516() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs516").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs516").src = "img/sqrs/blSqr.png"
};};};

function asqrsK517() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs517").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs517").src = "img/sqrs/blSqr.png"
};};};

function asqrsK518() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs518").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs518").src = "img/sqrs/blSqr.png"
};};};

function asqrsK519() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs519").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs519").src = "img/sqrs/blSqr.png"
};};};

function asqrsK520() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs520").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs520").src = "img/sqrs/blSqr.png"
};};};

function asqrsK521() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs521").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs521").src = "img/sqrs/blSqr.png"
};};};

function asqrsK522() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs522").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs522").src = "img/sqrs/blSqr.png"
};};};

function asqrsK523() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs523").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs523").src = "img/sqrs/blSqr.png"
};};};

function asqrsK524() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs524").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs524").src = "img/sqrs/blSqr.png"
};};};

function asqrsK525() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs525").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs525").src = "img/sqrs/blSqr.png"
};};};

function asqrsK526() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs526").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs526").src = "img/sqrs/blSqr.png"
};};};

function asqrsK527() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs527").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs527").src = "img/sqrs/blSqr.png"
};};};

function asqrsK528() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs528").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs528").src = "img/sqrs/blSqr.png"
};};};

function asqrsK529() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs529").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs529").src = "img/sqrs/blSqr.png"
};};};

function asqrsK530() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs530").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs530").src = "img/sqrs/blSqr.png"
};};};

function asqrsK531() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs531").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs531").src = "img/sqrs/blSqr.png"
};};};

function asqrsK532() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs532").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs532").src = "img/sqrs/blSqr.png"
};};};

function asqrsK533() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs533").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs533").src = "img/sqrs/blSqr.png"
};};};

function asqrsK534() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs534").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs534").src = "img/sqrs/blSqr.png"
};};};

function asqrsK535() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs535").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs535").src = "img/sqrs/blSqr.png"
};};};

function asqrsK536() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs536").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs536").src = "img/sqrs/blSqr.png"
};};};

function asqrsK537() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs537").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs537").src = "img/sqrs/blSqr.png"
};};};

function asqrsK538() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs538").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs538").src = "img/sqrs/blSqr.png"
};};};

function asqrsK539() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs539").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs539").src = "img/sqrs/blSqr.png"
};};};

function asqrsK540() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs540").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs540").src = "img/sqrs/blSqr.png"
};};};

function asqrsK541() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs541").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs541").src = "img/sqrs/blSqr.png"
};};};

function asqrsK542() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs542").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs542").src = "img/sqrs/blSqr.png"
};};};

function asqrsK543() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs543").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs543").src = "img/sqrs/blSqr.png"
};};};

function asqrsK544() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs544").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs544").src = "img/sqrs/blSqr.png"
};};};

function asqrsK545() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs545").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs545").src = "img/sqrs/blSqr.png"
};};};

function asqrsK546() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs546").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs546").src = "img/sqrs/blSqr.png"
};};};

function asqrsK547() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs547").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs547").src = "img/sqrs/blSqr.png"
};};};

function asqrsK548() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs548").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs548").src = "img/sqrs/blSqr.png"
};};};

function asqrsK549() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs549").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs549").src = "img/sqrs/blSqr.png"
};};};

function asqrsK550() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs550").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs550").src = "img/sqrs/blSqr.png"
};};};

function asqrsL551() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs551").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs551").src = "img/sqrs/blSqr.png"
};};};

function asqrsL552() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs552").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs552").src = "img/sqrs/blSqr.png"
};};};

function asqrsL553() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs553").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs553").src = "img/sqrs/blSqr.png"
};};};

function asqrsL554() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs554").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs554").src = "img/sqrs/blSqr.png"
};};};

function asqrsL555() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs555").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs555").src = "img/sqrs/blSqr.png"
};};};

function asqrsL556() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs556").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs556").src = "img/sqrs/blSqr.png"
};};};

function asqrsL557() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs557").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs557").src = "img/sqrs/blSqr.png"
};};};

function asqrsL558() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs558").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs558").src = "img/sqrs/blSqr.png"
};};};

function asqrsL559() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs559").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs559").src = "img/sqrs/blSqr.png"
};};};

function asqrsL560() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs560").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs560").src = "img/sqrs/blSqr.png"
};};};

function asqrsL561() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs561").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs561").src = "img/sqrs/blSqr.png"
};};};

function asqrsL562() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs562").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs562").src = "img/sqrs/blSqr.png"
};};};

function asqrsL563() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs563").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs563").src = "img/sqrs/blSqr.png"
};};};

function asqrsL564() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs564").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs564").src = "img/sqrs/blSqr.png"
};};};

function asqrsL565() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs565").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs565").src = "img/sqrs/blSqr.png"
};};};

function asqrsL566() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs566").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs566").src = "img/sqrs/blSqr.png"
};};};

function asqrsL567() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs567").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs567").src = "img/sqrs/blSqr.png"
};};};

function asqrsL568() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs568").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs568").src = "img/sqrs/blSqr.png"
};};};

function asqrsL569() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs569").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs569").src = "img/sqrs/blSqr.png"
};};};

function asqrsL570() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs570").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs570").src = "img/sqrs/blSqr.png"
};};};

function asqrsL571() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs571").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs571").src = "img/sqrs/blSqr.png"
};};};

function asqrsL572() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs572").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs572").src = "img/sqrs/blSqr.png"
};};};

function asqrsL573() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs573").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs573").src = "img/sqrs/blSqr.png"
};};};

function asqrsL574() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs574").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs574").src = "img/sqrs/blSqr.png"
};};};

function asqrsL575() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs575").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs575").src = "img/sqrs/blSqr.png"
};};};

function asqrsL576() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs576").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs576").src = "img/sqrs/blSqr.png"
};};};

function asqrsL577() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs577").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs577").src = "img/sqrs/blSqr.png"
};};};

function asqrsL578() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs578").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs578").src = "img/sqrs/blSqr.png"
};};};

function asqrsL579() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs579").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs579").src = "img/sqrs/blSqr.png"
};};};

function asqrsL580() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs580").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs580").src = "img/sqrs/blSqr.png"
};};};

function asqrsL581() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs581").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs581").src = "img/sqrs/blSqr.png"
};};};

function asqrsL582() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs582").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs582").src = "img/sqrs/blSqr.png"
};};};

function asqrsL583() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs583").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs583").src = "img/sqrs/blSqr.png"
};};};

function asqrsL584() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs584").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs584").src = "img/sqrs/blSqr.png"
};};};

function asqrsL585() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs585").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs585").src = "img/sqrs/blSqr.png"
};};};

function asqrsL586() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs586").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs586").src = "img/sqrs/blSqr.png"
};};};

function asqrsL587() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs587").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs587").src = "img/sqrs/blSqr.png"
};};};

function asqrsL588() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs588").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs588").src = "img/sqrs/blSqr.png"
};};};

function asqrsL589() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs589").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs589").src = "img/sqrs/blSqr.png"
};};};

function asqrsL590() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs590").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs590").src = "img/sqrs/blSqr.png"
};};};

function asqrsL591() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs591").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs591").src = "img/sqrs/blSqr.png"
};};};

function asqrsL592() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs592").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs592").src = "img/sqrs/blSqr.png"
};};};

function asqrsL593() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs593").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs593").src = "img/sqrs/blSqr.png"
};};};

function asqrsL594() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs594").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs594").src = "img/sqrs/blSqr.png"
};};};

function asqrsL595() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs595").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs595").src = "img/sqrs/blSqr.png"
};};};

function asqrsL596() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs596").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs596").src = "img/sqrs/blSqr.png"
};};};

function asqrsL597() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs597").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs597").src = "img/sqrs/blSqr.png"
};};};

function asqrsL598() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs598").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs598").src = "img/sqrs/blSqr.png"
};};};

function asqrsL599() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs599").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs599").src = "img/sqrs/blSqr.png"
};};};

function asqrsL600() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs600").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs600").src = "img/sqrs/blSqr.png"
};};};

function asqrsM601() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs601").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs601").src = "img/sqrs/blSqr.png"
};};};

function asqrsM602() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs602").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs602").src = "img/sqrs/blSqr.png"
};};};

function asqrsM603() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs603").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs603").src = "img/sqrs/blSqr.png"
};};};

function asqrsM604() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs604").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs604").src = "img/sqrs/blSqr.png"
};};};

function asqrsM605() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs605").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs605").src = "img/sqrs/blSqr.png"
};};};

function asqrsM606() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs606").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs606").src = "img/sqrs/blSqr.png"
};};};

function asqrsM607() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs607").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs607").src = "img/sqrs/blSqr.png"
};};};

function asqrsM608() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs608").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs608").src = "img/sqrs/blSqr.png"
};};};

function asqrsM609() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs609").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs609").src = "img/sqrs/blSqr.png"
};};};

function asqrsM610() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs610").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs610").src = "img/sqrs/blSqr.png"
};};};

function asqrsM611() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs611").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs611").src = "img/sqrs/blSqr.png"
};};};

function asqrsM612() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs612").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs612").src = "img/sqrs/blSqr.png"
};};};

function asqrsM613() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs613").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs613").src = "img/sqrs/blSqr.png"
};};};

function asqrsM614() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs614").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs614").src = "img/sqrs/blSqr.png"
};};};

function asqrsM615() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs615").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs615").src = "img/sqrs/blSqr.png"
};};};

function asqrsM616() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs616").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs616").src = "img/sqrs/blSqr.png"
};};};

function asqrsM617() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs617").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs617").src = "img/sqrs/blSqr.png"
};};};

function asqrsM618() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs618").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs618").src = "img/sqrs/blSqr.png"
};};};

function asqrsM619() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs619").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs619").src = "img/sqrs/blSqr.png"
};};};

function asqrsM620() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs620").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs620").src = "img/sqrs/blSqr.png"
};};};

function asqrsM621() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs621").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs621").src = "img/sqrs/blSqr.png"
};};};

function asqrsM622() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs622").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs622").src = "img/sqrs/blSqr.png"
};};};

function asqrsM623() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs623").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs623").src = "img/sqrs/blSqr.png"
};};};

function asqrsM624() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs624").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs624").src = "img/sqrs/blSqr.png"
};};};

function asqrsM625() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqrs625").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs625").src = "img/sqrs/blSqr.png"
};};};
