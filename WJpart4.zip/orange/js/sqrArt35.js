function sqrsA1() {
    if(document.getElementById("imgSqrs1").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1").src = "img/sqrs/blSqr.png"
};
};
function sqrsA2() {
    if(document.getElementById("imgSqrs2").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs2").src = "img/sqrs/blSqr.png"
};
};
function sqrsA3() {
    if(document.getElementById("imgSqrs3").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs3").src = "img/sqrs/blSqr.png"
};
};
function sqrsA4() {
    if(document.getElementById("imgSqrs4").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs4").src = "img/sqrs/blSqr.png"
};
};
function sqrsA5() {
    if(document.getElementById("imgSqrs5").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs5").src = "img/sqrs/blSqr.png"
};
};
function sqrsA6() {
    if(document.getElementById("imgSqrs6").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs6").src = "img/sqrs/blSqr.png"
};
};
function sqrsA7() {
    if(document.getElementById("imgSqrs7").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs7").src = "img/sqrs/blSqr.png"
};
};
function sqrsA8() {
    if(document.getElementById("imgSqrs8").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs8").src = "img/sqrs/blSqr.png"
};
};
function sqrsA9() {
    if(document.getElementById("imgSqrs9").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs9").src = "img/sqrs/blSqr.png"
};
};
function sqrsA10() {
    if(document.getElementById("imgSqrs10").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs10").src = "img/sqrs/blSqr.png"
};
};
function sqrsA11() {
    if(document.getElementById("imgSqrs11").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs11").src = "img/sqrs/blSqr.png"
};
};
function sqrsA12() {
    if(document.getElementById("imgSqrs12").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs12").src = "img/sqrs/blSqr.png"
};
};
function sqrsA13() {
    if(document.getElementById("imgSqrs13").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs13").src = "img/sqrs/blSqr.png"
};
};
function sqrsA14() {
    if(document.getElementById("imgSqrs14").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs14").src = "img/sqrs/blSqr.png"
};
};
function sqrsA15() {
    if(document.getElementById("imgSqrs15").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs15").src = "img/sqrs/blSqr.png"
};
};
function sqrsA16() {
    if(document.getElementById("imgSqrs16").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs16").src = "img/sqrs/blSqr.png"
};
};
function sqrsA17() {
    if(document.getElementById("imgSqrs17").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs17").src = "img/sqrs/blSqr.png"
};
};
function sqrsA18() {
    if(document.getElementById("imgSqrs18").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs18").src = "img/sqrs/blSqr.png"
};
};
function sqrsA19() {
    if(document.getElementById("imgSqrs19").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs19").src = "img/sqrs/blSqr.png"
};
};
function sqrsA20() {
    if(document.getElementById("imgSqrs20").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs20").src = "img/sqrs/blSqr.png"
};
};
function sqrsA21() {
    if(document.getElementById("imgSqrs21").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs21").src = "img/sqrs/blSqr.png"
};
};
function sqrsA22() {
    if(document.getElementById("imgSqrs22").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs22").src = "img/sqrs/blSqr.png"
};
};
function sqrsA23() {
    if(document.getElementById("imgSqrs23").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs23").src = "img/sqrs/blSqr.png"
};
};
function sqrsA24() {
    if(document.getElementById("imgSqrs24").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs24").src = "img/sqrs/blSqr.png"
};
};
function sqrsA25() {
    if(document.getElementById("imgSqrs25").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs25").src = "img/sqrs/blSqr.png"
};
};
function sqrsA26() {
    if(document.getElementById("imgSqrs26").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs26").src = "img/sqrs/blSqr.png"
};
};
function sqrsA27() {
    if(document.getElementById("imgSqrs27").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs27").src = "img/sqrs/blSqr.png"
};
};
function sqrsA28() {
    if(document.getElementById("imgSqrs28").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs28").src = "img/sqrs/blSqr.png"
};
};
function sqrsA29() {
    if(document.getElementById("imgSqrs29").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs29").src = "img/sqrs/blSqr.png"
};
};
function sqrsA30() {
    if(document.getElementById("imgSqrs30").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs30").src = "img/sqrs/blSqr.png"
};
};
function sqrsA31() {
    if(document.getElementById("imgSqrs31").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs31").src = "img/sqrs/blSqr.png"
};
};
function sqrsA32() {
    if(document.getElementById("imgSqrs32").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs32").src = "img/sqrs/blSqr.png"
};
};
function sqrsA33() {
    if(document.getElementById("imgSqrs33").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs33").src = "img/sqrs/blSqr.png"
};
};
function sqrsA34() {
    if(document.getElementById("imgSqrs34").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs34").src = "img/sqrs/blSqr.png"
};
};
function sqrsA35() {
    if(document.getElementById("imgSqrs35").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs35").src = "img/sqrs/blSqr.png"
};
};
function sqrsA36() {
    if(document.getElementById("imgSqrs36").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs36").src = "img/sqrs/blSqr.png"
};
};
function sqrsA37() {
    if(document.getElementById("imgSqrs37").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs37").src = "img/sqrs/blSqr.png"
};
};
function sqrsA38() {
    if(document.getElementById("imgSqrs38").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs38").src = "img/sqrs/blSqr.png"
};
};
function sqrsA39() {
    if(document.getElementById("imgSqrs39").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs39").src = "img/sqrs/blSqr.png"
};
};
function sqrsA40() {
    if(document.getElementById("imgSqrs40").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs40").src = "img/sqrs/blSqr.png"
};
};
function sqrsA41() {
    if(document.getElementById("imgSqrs41").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs41").src = "img/sqrs/blSqr.png"
};
};
function sqrsA42() {
    if(document.getElementById("imgSqrs42").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs42").src = "img/sqrs/blSqr.png"
};
};
function sqrsA43() {
    if(document.getElementById("imgSqrs43").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs43").src = "img/sqrs/blSqr.png"
};
};
function sqrsA44() {
    if(document.getElementById("imgSqrs44").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs44").src = "img/sqrs/blSqr.png"
};
};
function sqrsA45() {
    if(document.getElementById("imgSqrs45").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs45").src = "img/sqrs/blSqr.png"
};
};
function sqrsA46() {
    if(document.getElementById("imgSqrs46").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs46").src = "img/sqrs/blSqr.png"
};
};
function sqrsA47() {
    if(document.getElementById("imgSqrs47").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs47").src = "img/sqrs/blSqr.png"
};
};
function sqrsA48() {
    if(document.getElementById("imgSqrs48").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs48").src = "img/sqrs/blSqr.png"
};
};
function sqrsA49() {
    if(document.getElementById("imgSqrs49").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs49").src = "img/sqrs/blSqr.png"
};
};
function sqrsA50() {
    if(document.getElementById("imgSqrs50").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs50").src = "img/sqrs/blSqr.png"
};
};
function sqrsB51() {
    if(document.getElementById("imgSqrs51").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs51").src = "img/sqrs/blSqr.png"
};
};
function sqrsB52() {
    if(document.getElementById("imgSqrs52").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs52").src = "img/sqrs/blSqr.png"
};
};
function sqrsB53() {
    if(document.getElementById("imgSqrs53").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs53").src = "img/sqrs/blSqr.png"
};
};
function sqrsB54() {
    if(document.getElementById("imgSqrs54").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs54").src = "img/sqrs/blSqr.png"
};
};
function sqrsB55() {
    if(document.getElementById("imgSqrs55").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs55").src = "img/sqrs/blSqr.png"
};
};
function sqrsB56() {
    if(document.getElementById("imgSqrs56").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs56").src = "img/sqrs/blSqr.png"
};
};
function sqrsB57() {
    if(document.getElementById("imgSqrs57").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs57").src = "img/sqrs/blSqr.png"
};
};
function sqrsB58() {
    if(document.getElementById("imgSqrs58").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs58").src = "img/sqrs/blSqr.png"
};
};
function sqrsB59() {
    if(document.getElementById("imgSqrs59").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs59").src = "img/sqrs/blSqr.png"
};
};
function sqrsB60() {
    if(document.getElementById("imgSqrs60").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs60").src = "img/sqrs/blSqr.png"
};
};
function sqrsB61() {
    if(document.getElementById("imgSqrs61").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs61").src = "img/sqrs/blSqr.png"
};
};
function sqrsB62() {
    if(document.getElementById("imgSqrs62").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs62").src = "img/sqrs/blSqr.png"
};
};
function sqrsB63() {
    if(document.getElementById("imgSqrs63").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs63").src = "img/sqrs/blSqr.png"
};
};
function sqrsB64() {
    if(document.getElementById("imgSqrs64").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs64").src = "img/sqrs/blSqr.png"
};
};
function sqrsB65() {
    if(document.getElementById("imgSqrs65").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs65").src = "img/sqrs/blSqr.png"
};
};
function sqrsB66() {
    if(document.getElementById("imgSqrs66").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs66").src = "img/sqrs/blSqr.png"
};
};
function sqrsB67() {
    if(document.getElementById("imgSqrs67").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs67").src = "img/sqrs/blSqr.png"
};
};
function sqrsB68() {
    if(document.getElementById("imgSqrs68").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs68").src = "img/sqrs/blSqr.png"
};
};
function sqrsB69() {
    if(document.getElementById("imgSqrs69").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs69").src = "img/sqrs/blSqr.png"
};
};
function sqrsB70() {
    if(document.getElementById("imgSqrs70").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs70").src = "img/sqrs/blSqr.png"
};
};
function sqrsB71() {
    if(document.getElementById("imgSqrs71").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs71").src = "img/sqrs/blSqr.png"
};
};
function sqrsB72() {
    if(document.getElementById("imgSqrs72").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs72").src = "img/sqrs/blSqr.png"
};
};
function sqrsB73() {
    if(document.getElementById("imgSqrs73").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs73").src = "img/sqrs/blSqr.png"
};
};
function sqrsB74() {
    if(document.getElementById("imgSqrs74").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs74").src = "img/sqrs/blSqr.png"
};
};
function sqrsB75() {
    if(document.getElementById("imgSqrs75").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs75").src = "img/sqrs/blSqr.png"
};
};
function sqrsB76() {
    if(document.getElementById("imgSqrs76").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs76").src = "img/sqrs/blSqr.png"
};
};
function sqrsB77() {
    if(document.getElementById("imgSqrs77").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs77").src = "img/sqrs/blSqr.png"
};
};
function sqrsB78() {
    if(document.getElementById("imgSqrs78").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs78").src = "img/sqrs/blSqr.png"
};
};
function sqrsB79() {
    if(document.getElementById("imgSqrs79").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs79").src = "img/sqrs/blSqr.png"
};
};
function sqrsB80() {
    if(document.getElementById("imgSqrs80").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs80").src = "img/sqrs/blSqr.png"
};
};
function sqrsB81() {
    if(document.getElementById("imgSqrs81").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs81").src = "img/sqrs/blSqr.png"
};
};
function sqrsB82() {
    if(document.getElementById("imgSqrs82").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs82").src = "img/sqrs/blSqr.png"
};
};
function sqrsB83() {
    if(document.getElementById("imgSqrs83").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs83").src = "img/sqrs/blSqr.png"
};
};
function sqrsB84() {
    if(document.getElementById("imgSqrs84").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs84").src = "img/sqrs/blSqr.png"
};
};
function sqrsB85() {
    if(document.getElementById("imgSqrs85").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs85").src = "img/sqrs/blSqr.png"
};
};
function sqrsB86() {
    if(document.getElementById("imgSqrs86").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs86").src = "img/sqrs/blSqr.png"
};
};
function sqrsB87() {
    if(document.getElementById("imgSqrs87").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs87").src = "img/sqrs/blSqr.png"
};
};
function sqrsB88() {
    if(document.getElementById("imgSqrs88").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs88").src = "img/sqrs/blSqr.png"
};
};
function sqrsB89() {
    if(document.getElementById("imgSqrs89").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs89").src = "img/sqrs/blSqr.png"
};
};
function sqrsB90() {
    if(document.getElementById("imgSqrs90").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs90").src = "img/sqrs/blSqr.png"
};
};
function sqrsB91() {
    if(document.getElementById("imgSqrs91").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs91").src = "img/sqrs/blSqr.png"
};
};
function sqrsB92() {
    if(document.getElementById("imgSqrs92").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs92").src = "img/sqrs/blSqr.png"
};
};
function sqrsB93() {
    if(document.getElementById("imgSqrs93").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs93").src = "img/sqrs/blSqr.png"
};
};
function sqrsB94() {
    if(document.getElementById("imgSqrs94").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs94").src = "img/sqrs/blSqr.png"
};
};
function sqrsB95() {
    if(document.getElementById("imgSqrs95").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs95").src = "img/sqrs/blSqr.png"
};
};
function sqrsB96() {
    if(document.getElementById("imgSqrs96").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs96").src = "img/sqrs/blSqr.png"
};
};
function sqrsB97() {
    if(document.getElementById("imgSqrs97").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs97").src = "img/sqrs/blSqr.png"
};
};
function sqrsB98() {
    if(document.getElementById("imgSqrs98").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs98").src = "img/sqrs/blSqr.png"
};
};
function sqrsB99() {
    if(document.getElementById("imgSqrs99").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs99").src = "img/sqrs/blSqr.png"
};
};
function sqrsB100() {
    if(document.getElementById("imgSqrs100").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs100").src = "img/sqrs/blSqr.png"
};
};
function sqrsC101() {
    if(document.getElementById("imgSqrs101").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs101").src = "img/sqrs/blSqr.png"
};
};
function sqrsC102() {
    if(document.getElementById("imgSqrs102").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs102").src = "img/sqrs/blSqr.png"
};
};
function sqrsC103() {
    if(document.getElementById("imgSqrs103").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs103").src = "img/sqrs/blSqr.png"
};
};
function sqrsC104() {
    if(document.getElementById("imgSqrs104").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs104").src = "img/sqrs/blSqr.png"
};
};
function sqrsC105() {
    if(document.getElementById("imgSqrs105").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs105").src = "img/sqrs/blSqr.png"
};
};
function sqrsC106() {
    if(document.getElementById("imgSqrs106").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs106").src = "img/sqrs/blSqr.png"
};
};
function sqrsC107() {
    if(document.getElementById("imgSqrs107").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs107").src = "img/sqrs/blSqr.png"
};
};
function sqrsC108() {
    if(document.getElementById("imgSqrs108").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs108").src = "img/sqrs/blSqr.png"
};
};
function sqrsC109() {
    if(document.getElementById("imgSqrs109").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs109").src = "img/sqrs/blSqr.png"
};
};
function sqrsC110() {
    if(document.getElementById("imgSqrs110").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs110").src = "img/sqrs/blSqr.png"
};
};
function sqrsC111() {
    if(document.getElementById("imgSqrs111").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs111").src = "img/sqrs/blSqr.png"
};
};
function sqrsC112() {
    if(document.getElementById("imgSqrs112").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs112").src = "img/sqrs/blSqr.png"
};
};
function sqrsC113() {
    if(document.getElementById("imgSqrs113").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs113").src = "img/sqrs/blSqr.png"
};
};
function sqrsC114() {
    if(document.getElementById("imgSqrs114").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs114").src = "img/sqrs/blSqr.png"
};
};
function sqrsC115() {
    if(document.getElementById("imgSqrs115").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs115").src = "img/sqrs/blSqr.png"
};
};
function sqrsC116() {
    if(document.getElementById("imgSqrs116").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs116").src = "img/sqrs/blSqr.png"
};
};
function sqrsC117() {
    if(document.getElementById("imgSqrs117").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs117").src = "img/sqrs/blSqr.png"
};
};
function sqrsC118() {
    if(document.getElementById("imgSqrs118").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs118").src = "img/sqrs/blSqr.png"
};
};
function sqrsC119() {
    if(document.getElementById("imgSqrs119").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs119").src = "img/sqrs/blSqr.png"
};
};
function sqrsC120() {
    if(document.getElementById("imgSqrs120").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs120").src = "img/sqrs/blSqr.png"
};
};
function sqrsC121() {
    if(document.getElementById("imgSqrs121").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs121").src = "img/sqrs/blSqr.png"
};
};
function sqrsC122() {
    if(document.getElementById("imgSqrs122").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs122").src = "img/sqrs/blSqr.png"
};
};
function sqrsC123() {
    if(document.getElementById("imgSqrs123").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs123").src = "img/sqrs/blSqr.png"
};
};
function sqrsC124() {
    if(document.getElementById("imgSqrs124").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs124").src = "img/sqrs/blSqr.png"
};
};
function sqrsC125() {
    if(document.getElementById("imgSqrs125").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs125").src = "img/sqrs/blSqr.png"
};
};
function sqrsC126() {
    if(document.getElementById("imgSqrs126").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs126").src = "img/sqrs/blSqr.png"
};
};
function sqrsC127() {
    if(document.getElementById("imgSqrs127").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs127").src = "img/sqrs/blSqr.png"
};
};
function sqrsC128() {
    if(document.getElementById("imgSqrs128").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs128").src = "img/sqrs/blSqr.png"
};
};
function sqrsC129() {
    if(document.getElementById("imgSqrs129").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs129").src = "img/sqrs/blSqr.png"
};
};
function sqrsC130() {
    if(document.getElementById("imgSqrs130").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs130").src = "img/sqrs/blSqr.png"
};
};
function sqrsC131() {
    if(document.getElementById("imgSqrs131").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs131").src = "img/sqrs/blSqr.png"
};
};
function sqrsC132() {
    if(document.getElementById("imgSqrs132").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs132").src = "img/sqrs/blSqr.png"
};
};
function sqrsC133() {
    if(document.getElementById("imgSqrs133").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs133").src = "img/sqrs/blSqr.png"
};
};
function sqrsC134() {
    if(document.getElementById("imgSqrs134").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs134").src = "img/sqrs/blSqr.png"
};
};
function sqrsC135() {
    if(document.getElementById("imgSqrs135").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs135").src = "img/sqrs/blSqr.png"
};
};
function sqrsC136() {
    if(document.getElementById("imgSqrs136").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs136").src = "img/sqrs/blSqr.png"
};
};
function sqrsC137() {
    if(document.getElementById("imgSqrs137").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs137").src = "img/sqrs/blSqr.png"
};
};
function sqrsC138() {
    if(document.getElementById("imgSqrs138").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs138").src = "img/sqrs/blSqr.png"
};
};
function sqrsC139() {
    if(document.getElementById("imgSqrs139").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs139").src = "img/sqrs/blSqr.png"
};
};
function sqrsC140() {
    if(document.getElementById("imgSqrs140").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs140").src = "img/sqrs/blSqr.png"
};
};
function sqrsC141() {
    if(document.getElementById("imgSqrs141").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs141").src = "img/sqrs/blSqr.png"
};
};
function sqrsC142() {
    if(document.getElementById("imgSqrs142").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs142").src = "img/sqrs/blSqr.png"
};
};
function sqrsC143() {
    if(document.getElementById("imgSqrs143").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs143").src = "img/sqrs/blSqr.png"
};
};
function sqrsC144() {
    if(document.getElementById("imgSqrs144").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs144").src = "img/sqrs/blSqr.png"
};
};
function sqrsC145() {
    if(document.getElementById("imgSqrs145").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs145").src = "img/sqrs/blSqr.png"
};
};
function sqrsC146() {
    if(document.getElementById("imgSqrs146").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs146").src = "img/sqrs/blSqr.png"
};
};
function sqrsC147() {
    if(document.getElementById("imgSqrs147").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs147").src = "img/sqrs/blSqr.png"
};
};
function sqrsC148() {
    if(document.getElementById("imgSqrs148").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs148").src = "img/sqrs/blSqr.png"
};
};
function sqrsC149() {
    if(document.getElementById("imgSqrs149").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs149").src = "img/sqrs/blSqr.png"
};
};
function sqrsC150() {
    if(document.getElementById("imgSqrs150").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs150").src = "img/sqrs/blSqr.png"
};
};
function sqrsD151() {
    if(document.getElementById("imgSqrs151").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs151").src = "img/sqrs/blSqr.png"
};
};
function sqrsD152() {
    if(document.getElementById("imgSqrs152").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs152").src = "img/sqrs/blSqr.png"
};
};
function sqrsD153() {
    if(document.getElementById("imgSqrs153").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs153").src = "img/sqrs/blSqr.png"
};
};
function sqrsD154() {
    if(document.getElementById("imgSqrs154").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs154").src = "img/sqrs/blSqr.png"
};
};
function sqrsD155() {
    if(document.getElementById("imgSqrs155").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs155").src = "img/sqrs/blSqr.png"
};
};
function sqrsD156() {
    if(document.getElementById("imgSqrs156").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs156").src = "img/sqrs/blSqr.png"
};
};
function sqrsD157() {
    if(document.getElementById("imgSqrs157").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs157").src = "img/sqrs/blSqr.png"
};
};
function sqrsD158() {
    if(document.getElementById("imgSqrs158").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs158").src = "img/sqrs/blSqr.png"
};
};
function sqrsD159() {
    if(document.getElementById("imgSqrs159").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs159").src = "img/sqrs/blSqr.png"
};
};
function sqrsD160() {
    if(document.getElementById("imgSqrs160").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs160").src = "img/sqrs/blSqr.png"
};
};
function sqrsD161() {
    if(document.getElementById("imgSqrs161").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs161").src = "img/sqrs/blSqr.png"
};
};
function sqrsD162() {
    if(document.getElementById("imgSqrs162").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs162").src = "img/sqrs/blSqr.png"
};
};
function sqrsD163() {
    if(document.getElementById("imgSqrs163").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs163").src = "img/sqrs/blSqr.png"
};
};
function sqrsD164() {
    if(document.getElementById("imgSqrs164").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs164").src = "img/sqrs/blSqr.png"
};
};
function sqrsD165() {
    if(document.getElementById("imgSqrs165").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs165").src = "img/sqrs/blSqr.png"
};
};
function sqrsD166() {
    if(document.getElementById("imgSqrs166").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs166").src = "img/sqrs/blSqr.png"
};
};
function sqrsD167() {
    if(document.getElementById("imgSqrs167").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs167").src = "img/sqrs/blSqr.png"
};
};
function sqrsD168() {
    if(document.getElementById("imgSqrs168").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs168").src = "img/sqrs/blSqr.png"
};
};
function sqrsD169() {
    if(document.getElementById("imgSqrs169").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs169").src = "img/sqrs/blSqr.png"
};
};
function sqrsD170() {
    if(document.getElementById("imgSqrs170").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs170").src = "img/sqrs/blSqr.png"
};
};
function sqrsD171() {
    if(document.getElementById("imgSqrs171").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs171").src = "img/sqrs/blSqr.png"
};
};
function sqrsD172() {
    if(document.getElementById("imgSqrs172").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs172").src = "img/sqrs/blSqr.png"
};
};
function sqrsD173() {
    if(document.getElementById("imgSqrs173").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs173").src = "img/sqrs/blSqr.png"
};
};
function sqrsD174() {
    if(document.getElementById("imgSqrs174").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs174").src = "img/sqrs/blSqr.png"
};
};
function sqrsD175() {
    if(document.getElementById("imgSqrs175").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs175").src = "img/sqrs/blSqr.png"
};
};
function sqrsD176() {
    if(document.getElementById("imgSqrs176").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs176").src = "img/sqrs/blSqr.png"
};
};
function sqrsD177() {
    if(document.getElementById("imgSqrs177").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs177").src = "img/sqrs/blSqr.png"
};
};
function sqrsD178() {
    if(document.getElementById("imgSqrs178").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs178").src = "img/sqrs/blSqr.png"
};
};
function sqrsD179() {
    if(document.getElementById("imgSqrs179").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs179").src = "img/sqrs/blSqr.png"
};
};
function sqrsD180() {
    if(document.getElementById("imgSqrs180").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs180").src = "img/sqrs/blSqr.png"
};
};
function sqrsD181() {
    if(document.getElementById("imgSqrs181").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs181").src = "img/sqrs/blSqr.png"
};
};
function sqrsD182() {
    if(document.getElementById("imgSqrs182").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs182").src = "img/sqrs/blSqr.png"
};
};
function sqrsD183() {
    if(document.getElementById("imgSqrs183").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs183").src = "img/sqrs/blSqr.png"
};
};
function sqrsD184() {
    if(document.getElementById("imgSqrs184").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs184").src = "img/sqrs/blSqr.png"
};
};
function sqrsD185() {
    if(document.getElementById("imgSqrs185").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs185").src = "img/sqrs/blSqr.png"
};
};
function sqrsD186() {
    if(document.getElementById("imgSqrs186").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs186").src = "img/sqrs/blSqr.png"
};
};
function sqrsD187() {
    if(document.getElementById("imgSqrs187").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs187").src = "img/sqrs/blSqr.png"
};
};
function sqrsD188() {
    if(document.getElementById("imgSqrs188").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs188").src = "img/sqrs/blSqr.png"
};
};
function sqrsD189() {
    if(document.getElementById("imgSqrs189").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs189").src = "img/sqrs/blSqr.png"
};
};
function sqrsD190() {
    if(document.getElementById("imgSqrs190").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs190").src = "img/sqrs/blSqr.png"
};
};
function sqrsD191() {
    if(document.getElementById("imgSqrs191").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs191").src = "img/sqrs/blSqr.png"
};
};
function sqrsD192() {
    if(document.getElementById("imgSqrs192").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs192").src = "img/sqrs/blSqr.png"
};
};
function sqrsD193() {
    if(document.getElementById("imgSqrs193").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs193").src = "img/sqrs/blSqr.png"
};
};
function sqrsD194() {
    if(document.getElementById("imgSqrs194").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs194").src = "img/sqrs/blSqr.png"
};
};
function sqrsD195() {
    if(document.getElementById("imgSqrs195").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs195").src = "img/sqrs/blSqr.png"
};
};
function sqrsD196() {
    if(document.getElementById("imgSqrs196").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs196").src = "img/sqrs/blSqr.png"
};
};
function sqrsD197() {
    if(document.getElementById("imgSqrs197").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs197").src = "img/sqrs/blSqr.png"
};
};
function sqrsD198() {
    if(document.getElementById("imgSqrs198").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs198").src = "img/sqrs/blSqr.png"
};
};
function sqrsD199() {
    if(document.getElementById("imgSqrs199").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs199").src = "img/sqrs/blSqr.png"
};
};
function sqrsD200() {
    if(document.getElementById("imgSqrs200").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs200").src = "img/sqrs/blSqr.png"
};
};
function sqrsE201() {
    if(document.getElementById("imgSqrs201").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs201").src = "img/sqrs/blSqr.png"
};
};
function sqrsE202() {
    if(document.getElementById("imgSqrs202").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs202").src = "img/sqrs/blSqr.png"
};
};
function sqrsE203() {
    if(document.getElementById("imgSqrs203").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs203").src = "img/sqrs/blSqr.png"
};
};
function sqrsE204() {
    if(document.getElementById("imgSqrs204").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs204").src = "img/sqrs/blSqr.png"
};
};
function sqrsE205() {
    if(document.getElementById("imgSqrs205").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs205").src = "img/sqrs/blSqr.png"
};
};
function sqrsE206() {
    if(document.getElementById("imgSqrs206").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs206").src = "img/sqrs/blSqr.png"
};
};
function sqrsE207() {
    if(document.getElementById("imgSqrs207").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs207").src = "img/sqrs/blSqr.png"
};
};
function sqrsE208() {
    if(document.getElementById("imgSqrs208").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs208").src = "img/sqrs/blSqr.png"
};
};
function sqrsE209() {
    if(document.getElementById("imgSqrs209").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs209").src = "img/sqrs/blSqr.png"
};
};
function sqrsE210() {
    if(document.getElementById("imgSqrs210").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs210").src = "img/sqrs/blSqr.png"
};
};
function sqrsE211() {
    if(document.getElementById("imgSqrs211").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs211").src = "img/sqrs/blSqr.png"
};
};
function sqrsE212() {
    if(document.getElementById("imgSqrs212").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs212").src = "img/sqrs/blSqr.png"
};
};
function sqrsE213() {
    if(document.getElementById("imgSqrs213").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs213").src = "img/sqrs/blSqr.png"
};
};
function sqrsE214() {
    if(document.getElementById("imgSqrs214").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs214").src = "img/sqrs/blSqr.png"
};
};
function sqrsE215() {
    if(document.getElementById("imgSqrs215").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs215").src = "img/sqrs/blSqr.png"
};
};
function sqrsE216() {
    if(document.getElementById("imgSqrs216").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs216").src = "img/sqrs/blSqr.png"
};
};
function sqrsE217() {
    if(document.getElementById("imgSqrs217").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs217").src = "img/sqrs/blSqr.png"
};
};
function sqrsE218() {
    if(document.getElementById("imgSqrs218").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs218").src = "img/sqrs/blSqr.png"
};
};
function sqrsE219() {
    if(document.getElementById("imgSqrs219").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs219").src = "img/sqrs/blSqr.png"
};
};
function sqrsE220() {
    if(document.getElementById("imgSqrs220").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs220").src = "img/sqrs/blSqr.png"
};
};
function sqrsE221() {
    if(document.getElementById("imgSqrs221").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs221").src = "img/sqrs/blSqr.png"
};
};
function sqrsE222() {
    if(document.getElementById("imgSqrs222").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs222").src = "img/sqrs/blSqr.png"
};
};
function sqrsE223() {
    if(document.getElementById("imgSqrs223").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs223").src = "img/sqrs/blSqr.png"
};
};
function sqrsE224() {
    if(document.getElementById("imgSqrs224").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs224").src = "img/sqrs/blSqr.png"
};
};
function sqrsE225() {
    if(document.getElementById("imgSqrs225").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs225").src = "img/sqrs/blSqr.png"
};
};
function sqrsE226() {
    if(document.getElementById("imgSqrs226").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs226").src = "img/sqrs/blSqr.png"
};
};
function sqrsE227() {
    if(document.getElementById("imgSqrs227").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs227").src = "img/sqrs/blSqr.png"
};
};
function sqrsE228() {
    if(document.getElementById("imgSqrs228").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs228").src = "img/sqrs/blSqr.png"
};
};
function sqrsE229() {
    if(document.getElementById("imgSqrs229").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs229").src = "img/sqrs/blSqr.png"
};
};
function sqrsE230() {
    if(document.getElementById("imgSqrs230").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs230").src = "img/sqrs/blSqr.png"
};
};
function sqrsE231() {
    if(document.getElementById("imgSqrs231").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs231").src = "img/sqrs/blSqr.png"
};
};
function sqrsE232() {
    if(document.getElementById("imgSqrs232").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs232").src = "img/sqrs/blSqr.png"
};
};
function sqrsE233() {
    if(document.getElementById("imgSqrs233").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs233").src = "img/sqrs/blSqr.png"
};
};
function sqrsE234() {
    if(document.getElementById("imgSqrs234").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs234").src = "img/sqrs/blSqr.png"
};
};
function sqrsE235() {
    if(document.getElementById("imgSqrs235").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs235").src = "img/sqrs/blSqr.png"
};
};
function sqrsE236() {
    if(document.getElementById("imgSqrs236").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs236").src = "img/sqrs/blSqr.png"
};
};
function sqrsE237() {
    if(document.getElementById("imgSqrs237").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs237").src = "img/sqrs/blSqr.png"
};
};
function sqrsE238() {
    if(document.getElementById("imgSqrs238").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs238").src = "img/sqrs/blSqr.png"
};
};
function sqrsE239() {
    if(document.getElementById("imgSqrs239").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs239").src = "img/sqrs/blSqr.png"
};
};
function sqrsE240() {
    if(document.getElementById("imgSqrs240").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs240").src = "img/sqrs/blSqr.png"
};
};
function sqrsE241() {
    if(document.getElementById("imgSqrs241").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs241").src = "img/sqrs/blSqr.png"
};
};
function sqrsE242() {
    if(document.getElementById("imgSqrs242").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs242").src = "img/sqrs/blSqr.png"
};
};
function sqrsE243() {
    if(document.getElementById("imgSqrs243").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs243").src = "img/sqrs/blSqr.png"
};
};
function sqrsE244() {
    if(document.getElementById("imgSqrs244").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs244").src = "img/sqrs/blSqr.png"
};
};
function sqrsE245() {
    if(document.getElementById("imgSqrs245").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs245").src = "img/sqrs/blSqr.png"
};
};
function sqrsE246() {
    if(document.getElementById("imgSqrs246").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs246").src = "img/sqrs/blSqr.png"
};
};
function sqrsE247() {
    if(document.getElementById("imgSqrs247").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs247").src = "img/sqrs/blSqr.png"
};
};
function sqrsE248() {
    if(document.getElementById("imgSqrs248").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs248").src = "img/sqrs/blSqr.png"
};
};
function sqrsE249() {
    if(document.getElementById("imgSqrs249").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs249").src = "img/sqrs/blSqr.png"
};
};
function sqrsE250() {
    if(document.getElementById("imgSqrs250").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs250").src = "img/sqrs/blSqr.png"
};
};
function sqrsF251() {
    if(document.getElementById("imgSqrs251").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs251").src = "img/sqrs/blSqr.png"
};
};
function sqrsF252() {
    if(document.getElementById("imgSqrs252").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs252").src = "img/sqrs/blSqr.png"
};
};
function sqrsF253() {
    if(document.getElementById("imgSqrs253").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs253").src = "img/sqrs/blSqr.png"
};
};
function sqrsF254() {
    if(document.getElementById("imgSqrs254").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs254").src = "img/sqrs/blSqr.png"
};
};
function sqrsF255() {
    if(document.getElementById("imgSqrs255").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs255").src = "img/sqrs/blSqr.png"
};
};
function sqrsF256() {
    if(document.getElementById("imgSqrs256").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs256").src = "img/sqrs/blSqr.png"
};
};
function sqrsF257() {
    if(document.getElementById("imgSqrs257").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs257").src = "img/sqrs/blSqr.png"
};
};
function sqrsF258() {
    if(document.getElementById("imgSqrs258").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs258").src = "img/sqrs/blSqr.png"
};
};
function sqrsF259() {
    if(document.getElementById("imgSqrs259").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs259").src = "img/sqrs/blSqr.png"
};
};
function sqrsF260() {
    if(document.getElementById("imgSqrs260").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs260").src = "img/sqrs/blSqr.png"
};
};
function sqrsF261() {
    if(document.getElementById("imgSqrs261").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs261").src = "img/sqrs/blSqr.png"
};
};
function sqrsF262() {
    if(document.getElementById("imgSqrs262").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs262").src = "img/sqrs/blSqr.png"
};
};
function sqrsF263() {
    if(document.getElementById("imgSqrs263").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs263").src = "img/sqrs/blSqr.png"
};
};
function sqrsF264() {
    if(document.getElementById("imgSqrs264").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs264").src = "img/sqrs/blSqr.png"
};
};
function sqrsF265() {
    if(document.getElementById("imgSqrs265").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs265").src = "img/sqrs/blSqr.png"
};
};
function sqrsF266() {
    if(document.getElementById("imgSqrs266").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs266").src = "img/sqrs/blSqr.png"
};
};
function sqrsF267() {
    if(document.getElementById("imgSqrs267").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs267").src = "img/sqrs/blSqr.png"
};
};
function sqrsF268() {
    if(document.getElementById("imgSqrs268").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs268").src = "img/sqrs/blSqr.png"
};
};
function sqrsF269() {
    if(document.getElementById("imgSqrs269").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs269").src = "img/sqrs/blSqr.png"
};
};
function sqrsF270() {
    if(document.getElementById("imgSqrs270").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs270").src = "img/sqrs/blSqr.png"
};
};
function sqrsF271() {
    if(document.getElementById("imgSqrs271").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs271").src = "img/sqrs/blSqr.png"
};
};
function sqrsF272() {
    if(document.getElementById("imgSqrs272").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs272").src = "img/sqrs/blSqr.png"
};
};
function sqrsF273() {
    if(document.getElementById("imgSqrs273").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs273").src = "img/sqrs/blSqr.png"
};
};
function sqrsF274() {
    if(document.getElementById("imgSqrs274").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs274").src = "img/sqrs/blSqr.png"
};
};
function sqrsF275() {
    if(document.getElementById("imgSqrs275").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs275").src = "img/sqrs/blSqr.png"
};
};
function sqrsF276() {
    if(document.getElementById("imgSqrs276").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs276").src = "img/sqrs/blSqr.png"
};
};
function sqrsF277() {
    if(document.getElementById("imgSqrs277").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs277").src = "img/sqrs/blSqr.png"
};
};
function sqrsF278() {
    if(document.getElementById("imgSqrs278").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs278").src = "img/sqrs/blSqr.png"
};
};
function sqrsF279() {
    if(document.getElementById("imgSqrs279").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs279").src = "img/sqrs/blSqr.png"
};
};
function sqrsF280() {
    if(document.getElementById("imgSqrs280").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs280").src = "img/sqrs/blSqr.png"
};
};
function sqrsF281() {
    if(document.getElementById("imgSqrs281").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs281").src = "img/sqrs/blSqr.png"
};
};
function sqrsF282() {
    if(document.getElementById("imgSqrs282").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs282").src = "img/sqrs/blSqr.png"
};
};
function sqrsF283() {
    if(document.getElementById("imgSqrs283").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs283").src = "img/sqrs/blSqr.png"
};
};
function sqrsF284() {
    if(document.getElementById("imgSqrs284").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs284").src = "img/sqrs/blSqr.png"
};
};
function sqrsF285() {
    if(document.getElementById("imgSqrs285").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs285").src = "img/sqrs/blSqr.png"
};
};
function sqrsF286() {
    if(document.getElementById("imgSqrs286").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs286").src = "img/sqrs/blSqr.png"
};
};
function sqrsF287() {
    if(document.getElementById("imgSqrs287").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs287").src = "img/sqrs/blSqr.png"
};
};
function sqrsF288() {
    if(document.getElementById("imgSqrs288").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs288").src = "img/sqrs/blSqr.png"
};
};
function sqrsF289() {
    if(document.getElementById("imgSqrs289").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs289").src = "img/sqrs/blSqr.png"
};
};
function sqrsF290() {
    if(document.getElementById("imgSqrs290").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs290").src = "img/sqrs/blSqr.png"
};
};
function sqrsF291() {
    if(document.getElementById("imgSqrs291").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs291").src = "img/sqrs/blSqr.png"
};
};
function sqrsF292() {
    if(document.getElementById("imgSqrs292").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs292").src = "img/sqrs/blSqr.png"
};
};
function sqrsF293() {
    if(document.getElementById("imgSqrs293").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs293").src = "img/sqrs/blSqr.png"
};
};
function sqrsF294() {
    if(document.getElementById("imgSqrs294").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs294").src = "img/sqrs/blSqr.png"
};
};
function sqrsF295() {
    if(document.getElementById("imgSqrs295").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs295").src = "img/sqrs/blSqr.png"
};
};
function sqrsF296() {
    if(document.getElementById("imgSqrs296").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs296").src = "img/sqrs/blSqr.png"
};
};
function sqrsF297() {
    if(document.getElementById("imgSqrs297").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs297").src = "img/sqrs/blSqr.png"
};
};
function sqrsF298() {
    if(document.getElementById("imgSqrs298").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs298").src = "img/sqrs/blSqr.png"
};
};
function sqrsF299() {
    if(document.getElementById("imgSqrs299").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs299").src = "img/sqrs/blSqr.png"
};
};
function sqrsF300() {
    if(document.getElementById("imgSqrs300").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs300").src = "img/sqrs/blSqr.png"
};
};
function sqrsG301() {
    if(document.getElementById("imgSqrs301").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs301").src = "img/sqrs/blSqr.png"
};
};
function sqrsG302() {
    if(document.getElementById("imgSqrs302").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs302").src = "img/sqrs/blSqr.png"
};
};
function sqrsG303() {
    if(document.getElementById("imgSqrs303").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs303").src = "img/sqrs/blSqr.png"
};
};
function sqrsG304() {
    if(document.getElementById("imgSqrs304").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs304").src = "img/sqrs/blSqr.png"
};
};
function sqrsG305() {
    if(document.getElementById("imgSqrs305").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs305").src = "img/sqrs/blSqr.png"
};
};
function sqrsG306() {
    if(document.getElementById("imgSqrs306").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs306").src = "img/sqrs/blSqr.png"
};
};
function sqrsG307() {
    if(document.getElementById("imgSqrs307").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs307").src = "img/sqrs/blSqr.png"
};
};
function sqrsG308() {
    if(document.getElementById("imgSqrs308").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs308").src = "img/sqrs/blSqr.png"
};
};
function sqrsG309() {
    if(document.getElementById("imgSqrs309").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs309").src = "img/sqrs/blSqr.png"
};
};
function sqrsG310() {
    if(document.getElementById("imgSqrs310").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs310").src = "img/sqrs/blSqr.png"
};
};
function sqrsG311() {
    if(document.getElementById("imgSqrs311").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs311").src = "img/sqrs/blSqr.png"
};
};
function sqrsG312() {
    if(document.getElementById("imgSqrs312").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs312").src = "img/sqrs/blSqr.png"
};
};
function sqrsG313() {
    if(document.getElementById("imgSqrs313").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs313").src = "img/sqrs/blSqr.png"
};
};
function sqrsG314() {
    if(document.getElementById("imgSqrs314").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs314").src = "img/sqrs/blSqr.png"
};
};
function sqrsG315() {
    if(document.getElementById("imgSqrs315").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs315").src = "img/sqrs/blSqr.png"
};
};
function sqrsG316() {
    if(document.getElementById("imgSqrs316").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs316").src = "img/sqrs/blSqr.png"
};
};
function sqrsG317() {
    if(document.getElementById("imgSqrs317").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs317").src = "img/sqrs/blSqr.png"
};
};
function sqrsG318() {
    if(document.getElementById("imgSqrs318").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs318").src = "img/sqrs/blSqr.png"
};
};
function sqrsG319() {
    if(document.getElementById("imgSqrs319").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs319").src = "img/sqrs/blSqr.png"
};
};
function sqrsG320() {
    if(document.getElementById("imgSqrs320").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs320").src = "img/sqrs/blSqr.png"
};
};
function sqrsG321() {
    if(document.getElementById("imgSqrs321").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs321").src = "img/sqrs/blSqr.png"
};
};
function sqrsG322() {
    if(document.getElementById("imgSqrs322").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs322").src = "img/sqrs/blSqr.png"
};
};
function sqrsG323() {
    if(document.getElementById("imgSqrs323").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs323").src = "img/sqrs/blSqr.png"
};
};
function sqrsG324() {
    if(document.getElementById("imgSqrs324").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs324").src = "img/sqrs/blSqr.png"
};
};
function sqrsG325() {
    if(document.getElementById("imgSqrs325").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs325").src = "img/sqrs/blSqr.png"
};
};
function sqrsG326() {
    if(document.getElementById("imgSqrs326").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs326").src = "img/sqrs/blSqr.png"
};
};
function sqrsG327() {
    if(document.getElementById("imgSqrs327").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs327").src = "img/sqrs/blSqr.png"
};
};
function sqrsG328() {
    if(document.getElementById("imgSqrs328").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs328").src = "img/sqrs/blSqr.png"
};
};
function sqrsG329() {
    if(document.getElementById("imgSqrs329").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs329").src = "img/sqrs/blSqr.png"
};
};
function sqrsG330() {
    if(document.getElementById("imgSqrs330").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs330").src = "img/sqrs/blSqr.png"
};
};
function sqrsG331() {
    if(document.getElementById("imgSqrs331").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs331").src = "img/sqrs/blSqr.png"
};
};
function sqrsG332() {
    if(document.getElementById("imgSqrs332").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs332").src = "img/sqrs/blSqr.png"
};
};
function sqrsG333() {
    if(document.getElementById("imgSqrs333").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs333").src = "img/sqrs/blSqr.png"
};
};
function sqrsG334() {
    if(document.getElementById("imgSqrs334").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs334").src = "img/sqrs/blSqr.png"
};
};
function sqrsG335() {
    if(document.getElementById("imgSqrs335").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs335").src = "img/sqrs/blSqr.png"
};
};
function sqrsG336() {
    if(document.getElementById("imgSqrs336").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs336").src = "img/sqrs/blSqr.png"
};
};
function sqrsG337() {
    if(document.getElementById("imgSqrs337").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs337").src = "img/sqrs/blSqr.png"
};
};
function sqrsG338() {
    if(document.getElementById("imgSqrs338").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs338").src = "img/sqrs/blSqr.png"
};
};
function sqrsG339() {
    if(document.getElementById("imgSqrs339").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs339").src = "img/sqrs/blSqr.png"
};
};
function sqrsG340() {
    if(document.getElementById("imgSqrs340").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs340").src = "img/sqrs/blSqr.png"
};
};
function sqrsG341() {
    if(document.getElementById("imgSqrs341").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs341").src = "img/sqrs/blSqr.png"
};
};
function sqrsG342() {
    if(document.getElementById("imgSqrs342").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs342").src = "img/sqrs/blSqr.png"
};
};
function sqrsG343() {
    if(document.getElementById("imgSqrs343").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs343").src = "img/sqrs/blSqr.png"
};
};
function sqrsG344() {
    if(document.getElementById("imgSqrs344").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs344").src = "img/sqrs/blSqr.png"
};
};
function sqrsG345() {
    if(document.getElementById("imgSqrs345").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs345").src = "img/sqrs/blSqr.png"
};
};
function sqrsG346() {
    if(document.getElementById("imgSqrs346").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs346").src = "img/sqrs/blSqr.png"
};
};
function sqrsG347() {
    if(document.getElementById("imgSqrs347").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs347").src = "img/sqrs/blSqr.png"
};
};
function sqrsG348() {
    if(document.getElementById("imgSqrs348").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs348").src = "img/sqrs/blSqr.png"
};
};
function sqrsG349() {
    if(document.getElementById("imgSqrs349").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs349").src = "img/sqrs/blSqr.png"
};
};
function sqrsG350() {
    if(document.getElementById("imgSqrs350").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs350").src = "img/sqrs/blSqr.png"
};
};
function sqrsH351() {
    if(document.getElementById("imgSqrs351").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs351").src = "img/sqrs/blSqr.png"
};
};
function sqrsH352() {
    if(document.getElementById("imgSqrs352").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs352").src = "img/sqrs/blSqr.png"
};
};
function sqrsH353() {
    if(document.getElementById("imgSqrs353").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs353").src = "img/sqrs/blSqr.png"
};
};
function sqrsH354() {
    if(document.getElementById("imgSqrs354").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs354").src = "img/sqrs/blSqr.png"
};
};
function sqrsH355() {
    if(document.getElementById("imgSqrs355").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs355").src = "img/sqrs/blSqr.png"
};
};
function sqrsH356() {
    if(document.getElementById("imgSqrs356").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs356").src = "img/sqrs/blSqr.png"
};
};
function sqrsH357() {
    if(document.getElementById("imgSqrs357").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs357").src = "img/sqrs/blSqr.png"
};
};
function sqrsH358() {
    if(document.getElementById("imgSqrs358").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs358").src = "img/sqrs/blSqr.png"
};
};
function sqrsH359() {
    if(document.getElementById("imgSqrs359").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs359").src = "img/sqrs/blSqr.png"
};
};
function sqrsH360() {
    if(document.getElementById("imgSqrs360").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs360").src = "img/sqrs/blSqr.png"
};
};
function sqrsH361() {
    if(document.getElementById("imgSqrs361").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs361").src = "img/sqrs/blSqr.png"
};
};
function sqrsH362() {
    if(document.getElementById("imgSqrs362").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs362").src = "img/sqrs/blSqr.png"
};
};
function sqrsH363() {
    if(document.getElementById("imgSqrs363").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs363").src = "img/sqrs/blSqr.png"
};
};
function sqrsH364() {
    if(document.getElementById("imgSqrs364").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs364").src = "img/sqrs/blSqr.png"
};
};
function sqrsH365() {
    if(document.getElementById("imgSqrs365").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs365").src = "img/sqrs/blSqr.png"
};
};
function sqrsH366() {
    if(document.getElementById("imgSqrs366").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs366").src = "img/sqrs/blSqr.png"
};
};
function sqrsH367() {
    if(document.getElementById("imgSqrs367").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs367").src = "img/sqrs/blSqr.png"
};
};
function sqrsH368() {
    if(document.getElementById("imgSqrs368").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs368").src = "img/sqrs/blSqr.png"
};
};
function sqrsH369() {
    if(document.getElementById("imgSqrs369").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs369").src = "img/sqrs/blSqr.png"
};
};
function sqrsH370() {
    if(document.getElementById("imgSqrs370").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs370").src = "img/sqrs/blSqr.png"
};
};
function sqrsH371() {
    if(document.getElementById("imgSqrs371").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs371").src = "img/sqrs/blSqr.png"
};
};
function sqrsH372() {
    if(document.getElementById("imgSqrs372").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs372").src = "img/sqrs/blSqr.png"
};
};
function sqrsH373() {
    if(document.getElementById("imgSqrs373").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs373").src = "img/sqrs/blSqr.png"
};
};
function sqrsH374() {
    if(document.getElementById("imgSqrs374").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs374").src = "img/sqrs/blSqr.png"
};
};
function sqrsH375() {
    if(document.getElementById("imgSqrs375").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs375").src = "img/sqrs/blSqr.png"
};
};
function sqrsH376() {
    if(document.getElementById("imgSqrs376").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs376").src = "img/sqrs/blSqr.png"
};
};
function sqrsH377() {
    if(document.getElementById("imgSqrs377").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs377").src = "img/sqrs/blSqr.png"
};
};
function sqrsH378() {
    if(document.getElementById("imgSqrs378").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs378").src = "img/sqrs/blSqr.png"
};
};
function sqrsH379() {
    if(document.getElementById("imgSqrs379").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs379").src = "img/sqrs/blSqr.png"
};
};
function sqrsH380() {
    if(document.getElementById("imgSqrs380").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs380").src = "img/sqrs/blSqr.png"
};
};
function sqrsH381() {
    if(document.getElementById("imgSqrs381").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs381").src = "img/sqrs/blSqr.png"
};
};
function sqrsH382() {
    if(document.getElementById("imgSqrs382").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs382").src = "img/sqrs/blSqr.png"
};
};
function sqrsH383() {
    if(document.getElementById("imgSqrs383").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs383").src = "img/sqrs/blSqr.png"
};
};
function sqrsH384() {
    if(document.getElementById("imgSqrs384").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs384").src = "img/sqrs/blSqr.png"
};
};
function sqrsH385() {
    if(document.getElementById("imgSqrs385").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs385").src = "img/sqrs/blSqr.png"
};
};
function sqrsH386() {
    if(document.getElementById("imgSqrs386").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs386").src = "img/sqrs/blSqr.png"
};
};
function sqrsH387() {
    if(document.getElementById("imgSqrs387").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs387").src = "img/sqrs/blSqr.png"
};
};
function sqrsH388() {
    if(document.getElementById("imgSqrs388").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs388").src = "img/sqrs/blSqr.png"
};
};
function sqrsH389() {
    if(document.getElementById("imgSqrs389").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs389").src = "img/sqrs/blSqr.png"
};
};
function sqrsH390() {
    if(document.getElementById("imgSqrs390").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs390").src = "img/sqrs/blSqr.png"
};
};
function sqrsH391() {
    if(document.getElementById("imgSqrs391").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs391").src = "img/sqrs/blSqr.png"
};
};
function sqrsH392() {
    if(document.getElementById("imgSqrs392").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs392").src = "img/sqrs/blSqr.png"
};
};
function sqrsH393() {
    if(document.getElementById("imgSqrs393").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs393").src = "img/sqrs/blSqr.png"
};
};
function sqrsH394() {
    if(document.getElementById("imgSqrs394").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs394").src = "img/sqrs/blSqr.png"
};
};
function sqrsH395() {
    if(document.getElementById("imgSqrs395").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs395").src = "img/sqrs/blSqr.png"
};
};
function sqrsH396() {
    if(document.getElementById("imgSqrs396").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs396").src = "img/sqrs/blSqr.png"
};
};
function sqrsH397() {
    if(document.getElementById("imgSqrs397").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs397").src = "img/sqrs/blSqr.png"
};
};
function sqrsH398() {
    if(document.getElementById("imgSqrs398").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs398").src = "img/sqrs/blSqr.png"
};
};
function sqrsH399() {
    if(document.getElementById("imgSqrs399").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs399").src = "img/sqrs/blSqr.png"
};
};
function sqrsH400() {
    if(document.getElementById("imgSqrs400").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs400").src = "img/sqrs/blSqr.png"
};
};
function sqrsI401() {
    if(document.getElementById("imgSqrs401").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs401").src = "img/sqrs/blSqr.png"
};
};
function sqrsI402() {
    if(document.getElementById("imgSqrs402").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs402").src = "img/sqrs/blSqr.png"
};
};
function sqrsI403() {
    if(document.getElementById("imgSqrs403").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs403").src = "img/sqrs/blSqr.png"
};
};
function sqrsI404() {
    if(document.getElementById("imgSqrs404").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs404").src = "img/sqrs/blSqr.png"
};
};
function sqrsI405() {
    if(document.getElementById("imgSqrs405").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs405").src = "img/sqrs/blSqr.png"
};
};
function sqrsI406() {
    if(document.getElementById("imgSqrs406").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs406").src = "img/sqrs/blSqr.png"
};
};
function sqrsI407() {
    if(document.getElementById("imgSqrs407").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs407").src = "img/sqrs/blSqr.png"
};
};
function sqrsI408() {
    if(document.getElementById("imgSqrs408").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs408").src = "img/sqrs/blSqr.png"
};
};
function sqrsI409() {
    if(document.getElementById("imgSqrs409").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs409").src = "img/sqrs/blSqr.png"
};
};
function sqrsI410() {
    if(document.getElementById("imgSqrs410").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs410").src = "img/sqrs/blSqr.png"
};
};
function sqrsI411() {
    if(document.getElementById("imgSqrs411").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs411").src = "img/sqrs/blSqr.png"
};
};
function sqrsI412() {
    if(document.getElementById("imgSqrs412").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs412").src = "img/sqrs/blSqr.png"
};
};
function sqrsI413() {
    if(document.getElementById("imgSqrs413").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs413").src = "img/sqrs/blSqr.png"
};
};
function sqrsI414() {
    if(document.getElementById("imgSqrs414").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs414").src = "img/sqrs/blSqr.png"
};
};
function sqrsI415() {
    if(document.getElementById("imgSqrs415").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs415").src = "img/sqrs/blSqr.png"
};
};
function sqrsI416() {
    if(document.getElementById("imgSqrs416").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs416").src = "img/sqrs/blSqr.png"
};
};
function sqrsI417() {
    if(document.getElementById("imgSqrs417").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs417").src = "img/sqrs/blSqr.png"
};
};
function sqrsI418() {
    if(document.getElementById("imgSqrs418").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs418").src = "img/sqrs/blSqr.png"
};
};
function sqrsI419() {
    if(document.getElementById("imgSqrs419").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs419").src = "img/sqrs/blSqr.png"
};
};
function sqrsI420() {
    if(document.getElementById("imgSqrs420").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs420").src = "img/sqrs/blSqr.png"
};
};
function sqrsI421() {
    if(document.getElementById("imgSqrs421").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs421").src = "img/sqrs/blSqr.png"
};
};
function sqrsI422() {
    if(document.getElementById("imgSqrs422").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs422").src = "img/sqrs/blSqr.png"
};
};
function sqrsI423() {
    if(document.getElementById("imgSqrs423").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs423").src = "img/sqrs/blSqr.png"
};
};
function sqrsI424() {
    if(document.getElementById("imgSqrs424").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs424").src = "img/sqrs/blSqr.png"
};
};
function sqrsI425() {
    if(document.getElementById("imgSqrs425").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs425").src = "img/sqrs/blSqr.png"
};
};
function sqrsI426() {
    if(document.getElementById("imgSqrs426").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs426").src = "img/sqrs/blSqr.png"
};
};
function sqrsI427() {
    if(document.getElementById("imgSqrs427").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs427").src = "img/sqrs/blSqr.png"
};
};
function sqrsI428() {
    if(document.getElementById("imgSqrs428").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs428").src = "img/sqrs/blSqr.png"
};
};
function sqrsI429() {
    if(document.getElementById("imgSqrs429").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs429").src = "img/sqrs/blSqr.png"
};
};
function sqrsI430() {
    if(document.getElementById("imgSqrs430").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs430").src = "img/sqrs/blSqr.png"
};
};
function sqrsI431() {
    if(document.getElementById("imgSqrs431").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs431").src = "img/sqrs/blSqr.png"
};
};
function sqrsI432() {
    if(document.getElementById("imgSqrs432").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs432").src = "img/sqrs/blSqr.png"
};
};
function sqrsI433() {
    if(document.getElementById("imgSqrs433").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs433").src = "img/sqrs/blSqr.png"
};
};
function sqrsI434() {
    if(document.getElementById("imgSqrs434").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs434").src = "img/sqrs/blSqr.png"
};
};
function sqrsI435() {
    if(document.getElementById("imgSqrs435").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs435").src = "img/sqrs/blSqr.png"
};
};
function sqrsI436() {
    if(document.getElementById("imgSqrs436").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs436").src = "img/sqrs/blSqr.png"
};
};
function sqrsI437() {
    if(document.getElementById("imgSqrs437").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs437").src = "img/sqrs/blSqr.png"
};
};
function sqrsI438() {
    if(document.getElementById("imgSqrs438").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs438").src = "img/sqrs/blSqr.png"
};
};
function sqrsI439() {
    if(document.getElementById("imgSqrs439").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs439").src = "img/sqrs/blSqr.png"
};
};
function sqrsI440() {
    if(document.getElementById("imgSqrs440").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs440").src = "img/sqrs/blSqr.png"
};
};
function sqrsI441() {
    if(document.getElementById("imgSqrs441").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs441").src = "img/sqrs/blSqr.png"
};
};
function sqrsI442() {
    if(document.getElementById("imgSqrs442").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs442").src = "img/sqrs/blSqr.png"
};
};
function sqrsI443() {
    if(document.getElementById("imgSqrs443").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs443").src = "img/sqrs/blSqr.png"
};
};
function sqrsI444() {
    if(document.getElementById("imgSqrs444").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs444").src = "img/sqrs/blSqr.png"
};
};
function sqrsI445() {
    if(document.getElementById("imgSqrs445").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs445").src = "img/sqrs/blSqr.png"
};
};
function sqrsI446() {
    if(document.getElementById("imgSqrs446").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs446").src = "img/sqrs/blSqr.png"
};
};
function sqrsI447() {
    if(document.getElementById("imgSqrs447").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs447").src = "img/sqrs/blSqr.png"
};
};
function sqrsI448() {
    if(document.getElementById("imgSqrs448").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs448").src = "img/sqrs/blSqr.png"
};
};
function sqrsI449() {
    if(document.getElementById("imgSqrs449").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs449").src = "img/sqrs/blSqr.png"
};
};
function sqrsI450() {
    if(document.getElementById("imgSqrs450").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs450").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ451() {
    if(document.getElementById("imgSqrs451").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs451").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ452() {
    if(document.getElementById("imgSqrs452").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs452").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ453() {
    if(document.getElementById("imgSqrs453").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs453").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ454() {
    if(document.getElementById("imgSqrs454").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs454").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ455() {
    if(document.getElementById("imgSqrs455").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs455").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ456() {
    if(document.getElementById("imgSqrs456").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs456").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ457() {
    if(document.getElementById("imgSqrs457").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs457").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ458() {
    if(document.getElementById("imgSqrs458").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs458").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ459() {
    if(document.getElementById("imgSqrs459").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs459").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ460() {
    if(document.getElementById("imgSqrs460").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs460").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ461() {
    if(document.getElementById("imgSqrs461").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs461").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ462() {
    if(document.getElementById("imgSqrs462").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs462").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ463() {
    if(document.getElementById("imgSqrs463").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs463").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ464() {
    if(document.getElementById("imgSqrs464").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs464").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ465() {
    if(document.getElementById("imgSqrs465").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs465").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ466() {
    if(document.getElementById("imgSqrs466").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs466").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ467() {
    if(document.getElementById("imgSqrs467").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs467").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ468() {
    if(document.getElementById("imgSqrs468").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs468").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ469() {
    if(document.getElementById("imgSqrs469").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs469").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ470() {
    if(document.getElementById("imgSqrs470").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs470").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ471() {
    if(document.getElementById("imgSqrs471").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs471").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ472() {
    if(document.getElementById("imgSqrs472").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs472").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ473() {
    if(document.getElementById("imgSqrs473").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs473").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ474() {
    if(document.getElementById("imgSqrs474").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs474").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ475() {
    if(document.getElementById("imgSqrs475").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs475").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ476() {
    if(document.getElementById("imgSqrs476").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs476").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ477() {
    if(document.getElementById("imgSqrs477").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs477").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ478() {
    if(document.getElementById("imgSqrs478").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs478").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ479() {
    if(document.getElementById("imgSqrs479").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs479").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ480() {
    if(document.getElementById("imgSqrs480").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs480").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ481() {
    if(document.getElementById("imgSqrs481").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs481").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ482() {
    if(document.getElementById("imgSqrs482").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs482").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ483() {
    if(document.getElementById("imgSqrs483").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs483").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ484() {
    if(document.getElementById("imgSqrs484").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs484").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ485() {
    if(document.getElementById("imgSqrs485").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs485").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ486() {
    if(document.getElementById("imgSqrs486").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs486").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ487() {
    if(document.getElementById("imgSqrs487").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs487").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ488() {
    if(document.getElementById("imgSqrs488").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs488").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ489() {
    if(document.getElementById("imgSqrs489").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs489").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ490() {
    if(document.getElementById("imgSqrs490").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs490").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ491() {
    if(document.getElementById("imgSqrs491").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs491").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ492() {
    if(document.getElementById("imgSqrs492").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs492").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ493() {
    if(document.getElementById("imgSqrs493").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs493").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ494() {
    if(document.getElementById("imgSqrs494").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs494").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ495() {
    if(document.getElementById("imgSqrs495").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs495").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ496() {
    if(document.getElementById("imgSqrs496").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs496").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ497() {
    if(document.getElementById("imgSqrs497").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs497").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ498() {
    if(document.getElementById("imgSqrs498").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs498").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ499() {
    if(document.getElementById("imgSqrs499").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs499").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ500() {
    if(document.getElementById("imgSqrs500").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs500").src = "img/sqrs/blSqr.png"
};
};
function sqrsK501() {
    if(document.getElementById("imgSqrs501").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs501").src = "img/sqrs/blSqr.png"
};
};
function sqrsK502() {
    if(document.getElementById("imgSqrs502").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs502").src = "img/sqrs/blSqr.png"
};
};
function sqrsK503() {
    if(document.getElementById("imgSqrs503").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs503").src = "img/sqrs/blSqr.png"
};
};
function sqrsK504() {
    if(document.getElementById("imgSqrs504").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs504").src = "img/sqrs/blSqr.png"
};
};
function sqrsK505() {
    if(document.getElementById("imgSqrs505").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs505").src = "img/sqrs/blSqr.png"
};
};
function sqrsK506() {
    if(document.getElementById("imgSqrs506").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs506").src = "img/sqrs/blSqr.png"
};
};
function sqrsK507() {
    if(document.getElementById("imgSqrs507").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs507").src = "img/sqrs/blSqr.png"
};
};
function sqrsK508() {
    if(document.getElementById("imgSqrs508").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs508").src = "img/sqrs/blSqr.png"
};
};
function sqrsK509() {
    if(document.getElementById("imgSqrs509").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs509").src = "img/sqrs/blSqr.png"
};
};
function sqrsK510() {
    if(document.getElementById("imgSqrs510").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs510").src = "img/sqrs/blSqr.png"
};
};
function sqrsK511() {
    if(document.getElementById("imgSqrs511").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs511").src = "img/sqrs/blSqr.png"
};
};
function sqrsK512() {
    if(document.getElementById("imgSqrs512").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs512").src = "img/sqrs/blSqr.png"
};
};
function sqrsK513() {
    if(document.getElementById("imgSqrs513").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs513").src = "img/sqrs/blSqr.png"
};
};
function sqrsK514() {
    if(document.getElementById("imgSqrs514").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs514").src = "img/sqrs/blSqr.png"
};
};
function sqrsK515() {
    if(document.getElementById("imgSqrs515").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs515").src = "img/sqrs/blSqr.png"
};
};
function sqrsK516() {
    if(document.getElementById("imgSqrs516").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs516").src = "img/sqrs/blSqr.png"
};
};
function sqrsK517() {
    if(document.getElementById("imgSqrs517").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs517").src = "img/sqrs/blSqr.png"
};
};
function sqrsK518() {
    if(document.getElementById("imgSqrs518").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs518").src = "img/sqrs/blSqr.png"
};
};
function sqrsK519() {
    if(document.getElementById("imgSqrs519").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs519").src = "img/sqrs/blSqr.png"
};
};
function sqrsK520() {
    if(document.getElementById("imgSqrs520").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs520").src = "img/sqrs/blSqr.png"
};
};
function sqrsK521() {
    if(document.getElementById("imgSqrs521").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs521").src = "img/sqrs/blSqr.png"
};
};
function sqrsK522() {
    if(document.getElementById("imgSqrs522").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs522").src = "img/sqrs/blSqr.png"
};
};
function sqrsK523() {
    if(document.getElementById("imgSqrs523").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs523").src = "img/sqrs/blSqr.png"
};
};
function sqrsK524() {
    if(document.getElementById("imgSqrs524").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs524").src = "img/sqrs/blSqr.png"
};
};
function sqrsK525() {
    if(document.getElementById("imgSqrs525").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs525").src = "img/sqrs/blSqr.png"
};
};
function sqrsK526() {
    if(document.getElementById("imgSqrs526").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs526").src = "img/sqrs/blSqr.png"
};
};
function sqrsK527() {
    if(document.getElementById("imgSqrs527").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs527").src = "img/sqrs/blSqr.png"
};
};
function sqrsK528() {
    if(document.getElementById("imgSqrs528").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs528").src = "img/sqrs/blSqr.png"
};
};
function sqrsK529() {
    if(document.getElementById("imgSqrs529").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs529").src = "img/sqrs/blSqr.png"
};
};
function sqrsK530() {
    if(document.getElementById("imgSqrs530").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs530").src = "img/sqrs/blSqr.png"
};
};
function sqrsK531() {
    if(document.getElementById("imgSqrs531").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs531").src = "img/sqrs/blSqr.png"
};
};
function sqrsK532() {
    if(document.getElementById("imgSqrs532").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs532").src = "img/sqrs/blSqr.png"
};
};
function sqrsK533() {
    if(document.getElementById("imgSqrs533").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs533").src = "img/sqrs/blSqr.png"
};
};
function sqrsK534() {
    if(document.getElementById("imgSqrs534").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs534").src = "img/sqrs/blSqr.png"
};
};
function sqrsK535() {
    if(document.getElementById("imgSqrs535").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs535").src = "img/sqrs/blSqr.png"
};
};
function sqrsK536() {
    if(document.getElementById("imgSqrs536").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs536").src = "img/sqrs/blSqr.png"
};
};
function sqrsK537() {
    if(document.getElementById("imgSqrs537").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs537").src = "img/sqrs/blSqr.png"
};
};
function sqrsK538() {
    if(document.getElementById("imgSqrs538").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs538").src = "img/sqrs/blSqr.png"
};
};
function sqrsK539() {
    if(document.getElementById("imgSqrs539").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs539").src = "img/sqrs/blSqr.png"
};
};
function sqrsK540() {
    if(document.getElementById("imgSqrs540").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs540").src = "img/sqrs/blSqr.png"
};
};
function sqrsK541() {
    if(document.getElementById("imgSqrs541").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs541").src = "img/sqrs/blSqr.png"
};
};
function sqrsK542() {
    if(document.getElementById("imgSqrs542").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs542").src = "img/sqrs/blSqr.png"
};
};
function sqrsK543() {
    if(document.getElementById("imgSqrs543").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs543").src = "img/sqrs/blSqr.png"
};
};
function sqrsK544() {
    if(document.getElementById("imgSqrs544").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs544").src = "img/sqrs/blSqr.png"
};
};
function sqrsK545() {
    if(document.getElementById("imgSqrs545").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs545").src = "img/sqrs/blSqr.png"
};
};
function sqrsK546() {
    if(document.getElementById("imgSqrs546").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs546").src = "img/sqrs/blSqr.png"
};
};
function sqrsK547() {
    if(document.getElementById("imgSqrs547").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs547").src = "img/sqrs/blSqr.png"
};
};
function sqrsK548() {
    if(document.getElementById("imgSqrs548").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs548").src = "img/sqrs/blSqr.png"
};
};
function sqrsK549() {
    if(document.getElementById("imgSqrs549").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs549").src = "img/sqrs/blSqr.png"
};
};
function sqrsK550() {
    if(document.getElementById("imgSqrs550").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs550").src = "img/sqrs/blSqr.png"
};
};
function sqrsL551() {
    if(document.getElementById("imgSqrs551").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs551").src = "img/sqrs/blSqr.png"
};
};
function sqrsL552() {
    if(document.getElementById("imgSqrs552").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs552").src = "img/sqrs/blSqr.png"
};
};
function sqrsL553() {
    if(document.getElementById("imgSqrs553").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs553").src = "img/sqrs/blSqr.png"
};
};
function sqrsL554() {
    if(document.getElementById("imgSqrs554").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs554").src = "img/sqrs/blSqr.png"
};
};
function sqrsL555() {
    if(document.getElementById("imgSqrs555").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs555").src = "img/sqrs/blSqr.png"
};
};
function sqrsL556() {
    if(document.getElementById("imgSqrs556").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs556").src = "img/sqrs/blSqr.png"
};
};
function sqrsL557() {
    if(document.getElementById("imgSqrs557").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs557").src = "img/sqrs/blSqr.png"
};
};
function sqrsL558() {
    if(document.getElementById("imgSqrs558").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs558").src = "img/sqrs/blSqr.png"
};
};
function sqrsL559() {
    if(document.getElementById("imgSqrs559").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs559").src = "img/sqrs/blSqr.png"
};
};
function sqrsL560() {
    if(document.getElementById("imgSqrs560").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs560").src = "img/sqrs/blSqr.png"
};
};
function sqrsL561() {
    if(document.getElementById("imgSqrs561").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs561").src = "img/sqrs/blSqr.png"
};
};
function sqrsL562() {
    if(document.getElementById("imgSqrs562").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs562").src = "img/sqrs/blSqr.png"
};
};
function sqrsL563() {
    if(document.getElementById("imgSqrs563").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs563").src = "img/sqrs/blSqr.png"
};
};
function sqrsL564() {
    if(document.getElementById("imgSqrs564").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs564").src = "img/sqrs/blSqr.png"
};
};
function sqrsL565() {
    if(document.getElementById("imgSqrs565").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs565").src = "img/sqrs/blSqr.png"
};
};
function sqrsL566() {
    if(document.getElementById("imgSqrs566").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs566").src = "img/sqrs/blSqr.png"
};
};
function sqrsL567() {
    if(document.getElementById("imgSqrs567").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs567").src = "img/sqrs/blSqr.png"
};
};
function sqrsL568() {
    if(document.getElementById("imgSqrs568").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs568").src = "img/sqrs/blSqr.png"
};
};
function sqrsL569() {
    if(document.getElementById("imgSqrs569").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs569").src = "img/sqrs/blSqr.png"
};
};
function sqrsL570() {
    if(document.getElementById("imgSqrs570").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs570").src = "img/sqrs/blSqr.png"
};
};
function sqrsL571() {
    if(document.getElementById("imgSqrs571").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs571").src = "img/sqrs/blSqr.png"
};
};
function sqrsL572() {
    if(document.getElementById("imgSqrs572").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs572").src = "img/sqrs/blSqr.png"
};
};
function sqrsL573() {
    if(document.getElementById("imgSqrs573").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs573").src = "img/sqrs/blSqr.png"
};
};
function sqrsL574() {
    if(document.getElementById("imgSqrs574").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs574").src = "img/sqrs/blSqr.png"
};
};
function sqrsL575() {
    if(document.getElementById("imgSqrs575").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs575").src = "img/sqrs/blSqr.png"
};
};
function sqrsL576() {
    if(document.getElementById("imgSqrs576").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs576").src = "img/sqrs/blSqr.png"
};
};
function sqrsL577() {
    if(document.getElementById("imgSqrs577").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs577").src = "img/sqrs/blSqr.png"
};
};
function sqrsL578() {
    if(document.getElementById("imgSqrs578").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs578").src = "img/sqrs/blSqr.png"
};
};
function sqrsL579() {
    if(document.getElementById("imgSqrs579").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs579").src = "img/sqrs/blSqr.png"
};
};
function sqrsL580() {
    if(document.getElementById("imgSqrs580").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs580").src = "img/sqrs/blSqr.png"
};
};
function sqrsL581() {
    if(document.getElementById("imgSqrs581").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs581").src = "img/sqrs/blSqr.png"
};
};
function sqrsL582() {
    if(document.getElementById("imgSqrs582").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs582").src = "img/sqrs/blSqr.png"
};
};
function sqrsL583() {
    if(document.getElementById("imgSqrs583").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs583").src = "img/sqrs/blSqr.png"
};
};
function sqrsL584() {
    if(document.getElementById("imgSqrs584").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs584").src = "img/sqrs/blSqr.png"
};
};
function sqrsL585() {
    if(document.getElementById("imgSqrs585").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs585").src = "img/sqrs/blSqr.png"
};
};
function sqrsL586() {
    if(document.getElementById("imgSqrs586").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs586").src = "img/sqrs/blSqr.png"
};
};
function sqrsL587() {
    if(document.getElementById("imgSqrs587").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs587").src = "img/sqrs/blSqr.png"
};
};
function sqrsL588() {
    if(document.getElementById("imgSqrs588").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs588").src = "img/sqrs/blSqr.png"
};
};
function sqrsL589() {
    if(document.getElementById("imgSqrs589").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs589").src = "img/sqrs/blSqr.png"
};
};
function sqrsL590() {
    if(document.getElementById("imgSqrs590").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs590").src = "img/sqrs/blSqr.png"
};
};
function sqrsL591() {
    if(document.getElementById("imgSqrs591").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs591").src = "img/sqrs/blSqr.png"
};
};
function sqrsL592() {
    if(document.getElementById("imgSqrs592").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs592").src = "img/sqrs/blSqr.png"
};
};
function sqrsL593() {
    if(document.getElementById("imgSqrs593").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs593").src = "img/sqrs/blSqr.png"
};
};
function sqrsL594() {
    if(document.getElementById("imgSqrs594").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs594").src = "img/sqrs/blSqr.png"
};
};
function sqrsL595() {
    if(document.getElementById("imgSqrs595").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs595").src = "img/sqrs/blSqr.png"
};
};
function sqrsL596() {
    if(document.getElementById("imgSqrs596").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs596").src = "img/sqrs/blSqr.png"
};
};
function sqrsL597() {
    if(document.getElementById("imgSqrs597").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs597").src = "img/sqrs/blSqr.png"
};
};
function sqrsL598() {
    if(document.getElementById("imgSqrs598").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs598").src = "img/sqrs/blSqr.png"
};
};
function sqrsL599() {
    if(document.getElementById("imgSqrs599").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs599").src = "img/sqrs/blSqr.png"
};
};
function sqrsL600() {
    if(document.getElementById("imgSqrs600").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs600").src = "img/sqrs/blSqr.png"
};
};
function sqrsM601() {
    if(document.getElementById("imgSqrs601").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs601").src = "img/sqrs/blSqr.png"
};
};
function sqrsM602() {
    if(document.getElementById("imgSqrs602").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs602").src = "img/sqrs/blSqr.png"
};
};
function sqrsM603() {
    if(document.getElementById("imgSqrs603").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs603").src = "img/sqrs/blSqr.png"
};
};
function sqrsM604() {
    if(document.getElementById("imgSqrs604").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs604").src = "img/sqrs/blSqr.png"
};
};
function sqrsM605() {
    if(document.getElementById("imgSqrs605").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs605").src = "img/sqrs/blSqr.png"
};
};
function sqrsM606() {
    if(document.getElementById("imgSqrs606").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs606").src = "img/sqrs/blSqr.png"
};
};
function sqrsM607() {
    if(document.getElementById("imgSqrs607").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs607").src = "img/sqrs/blSqr.png"
};
};
function sqrsM608() {
    if(document.getElementById("imgSqrs608").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs608").src = "img/sqrs/blSqr.png"
};
};
function sqrsM609() {
    if(document.getElementById("imgSqrs609").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs609").src = "img/sqrs/blSqr.png"
};
};
function sqrsM610() {
    if(document.getElementById("imgSqrs610").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs610").src = "img/sqrs/blSqr.png"
};
};
function sqrsM611() {
    if(document.getElementById("imgSqrs611").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs611").src = "img/sqrs/blSqr.png"
};
};
function sqrsM612() {
    if(document.getElementById("imgSqrs612").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs612").src = "img/sqrs/blSqr.png"
};
};
function sqrsM613() {
    if(document.getElementById("imgSqrs613").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs613").src = "img/sqrs/blSqr.png"
};
};
function sqrsM614() {
    if(document.getElementById("imgSqrs614").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs614").src = "img/sqrs/blSqr.png"
};
};
function sqrsM615() {
    if(document.getElementById("imgSqrs615").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs615").src = "img/sqrs/blSqr.png"
};
};
function sqrsM616() {
    if(document.getElementById("imgSqrs616").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs616").src = "img/sqrs/blSqr.png"
};
};
function sqrsM617() {
    if(document.getElementById("imgSqrs617").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs617").src = "img/sqrs/blSqr.png"
};
};
function sqrsM618() {
    if(document.getElementById("imgSqrs618").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs618").src = "img/sqrs/blSqr.png"
};
};
function sqrsM619() {
    if(document.getElementById("imgSqrs619").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs619").src = "img/sqrs/blSqr.png"
};
};
function sqrsM620() {
    if(document.getElementById("imgSqrs620").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs620").src = "img/sqrs/blSqr.png"
};
};
function sqrsM621() {
    if(document.getElementById("imgSqrs621").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs621").src = "img/sqrs/blSqr.png"
};
};
function sqrsM622() {
    if(document.getElementById("imgSqrs622").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs622").src = "img/sqrs/blSqr.png"
};
};
function sqrsM623() {
    if(document.getElementById("imgSqrs623").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs623").src = "img/sqrs/blSqr.png"
};
};
function sqrsM624() {
    if(document.getElementById("imgSqrs624").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs624").src = "img/sqrs/blSqr.png"
};
};
function sqrsM625() {
    if(document.getElementById("imgSqrs625").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs625").src = "img/sqrs/blSqr.png"
};
};
function sqrsM626() {
    if(document.getElementById("imgSqrs626").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs626").src = "img/sqrs/blSqr.png"
};
};
function sqrsM627() {
    if(document.getElementById("imgSqrs627").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs627").src = "img/sqrs/blSqr.png"
};
};
function sqrsM628() {
    if(document.getElementById("imgSqrs628").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs628").src = "img/sqrs/blSqr.png"
};
};
function sqrsM629() {
    if(document.getElementById("imgSqrs629").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs629").src = "img/sqrs/blSqr.png"
};
};
function sqrsM630() {
    if(document.getElementById("imgSqrs630").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs630").src = "img/sqrs/blSqr.png"
};
};
function sqrsM631() {
    if(document.getElementById("imgSqrs631").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs631").src = "img/sqrs/blSqr.png"
};
};
function sqrsM632() {
    if(document.getElementById("imgSqrs632").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs632").src = "img/sqrs/blSqr.png"
};
};
function sqrsM633() {
    if(document.getElementById("imgSqrs633").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs633").src = "img/sqrs/blSqr.png"
};
};
function sqrsM634() {
    if(document.getElementById("imgSqrs634").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs634").src = "img/sqrs/blSqr.png"
};
};
function sqrsM635() {
    if(document.getElementById("imgSqrs635").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs635").src = "img/sqrs/blSqr.png"
};
};
function sqrsM636() {
    if(document.getElementById("imgSqrs636").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs636").src = "img/sqrs/blSqr.png"
};
};
function sqrsM637() {
    if(document.getElementById("imgSqrs637").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs637").src = "img/sqrs/blSqr.png"
};
};
function sqrsM638() {
    if(document.getElementById("imgSqrs638").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs638").src = "img/sqrs/blSqr.png"
};
};
function sqrsM639() {
    if(document.getElementById("imgSqrs639").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs639").src = "img/sqrs/blSqr.png"
};
};
function sqrsM640() {
    if(document.getElementById("imgSqrs640").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs640").src = "img/sqrs/blSqr.png"
};
};
function sqrsM641() {
    if(document.getElementById("imgSqrs641").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs641").src = "img/sqrs/blSqr.png"
};
};
function sqrsM642() {
    if(document.getElementById("imgSqrs642").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs642").src = "img/sqrs/blSqr.png"
};
};
function sqrsM643() {
    if(document.getElementById("imgSqrs643").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs643").src = "img/sqrs/blSqr.png"
};
};
function sqrsM644() {
    if(document.getElementById("imgSqrs644").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs644").src = "img/sqrs/blSqr.png"
};
};
function sqrsM645() {
    if(document.getElementById("imgSqrs645").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs645").src = "img/sqrs/blSqr.png"
};
};
function sqrsM646() {
    if(document.getElementById("imgSqrs646").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs646").src = "img/sqrs/blSqr.png"
};
};
function sqrsM647() {
    if(document.getElementById("imgSqrs647").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs647").src = "img/sqrs/blSqr.png"
};
};
function sqrsM648() {
    if(document.getElementById("imgSqrs648").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs648").src = "img/sqrs/blSqr.png"
};
};
function sqrsM649() {
    if(document.getElementById("imgSqrs649").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs649").src = "img/sqrs/blSqr.png"
};
};
function sqrsM650() {
    if(document.getElementById("imgSqrs650").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs650").src = "img/sqrs/blSqr.png"
};
};
function sqrsN651() {
    if(document.getElementById("imgSqrs651").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs651").src = "img/sqrs/blSqr.png"
};
};
function sqrsN652() {
    if(document.getElementById("imgSqrs652").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs652").src = "img/sqrs/blSqr.png"
};
};
function sqrsN653() {
    if(document.getElementById("imgSqrs653").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs653").src = "img/sqrs/blSqr.png"
};
};
function sqrsN654() {
    if(document.getElementById("imgSqrs654").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs654").src = "img/sqrs/blSqr.png"
};
};
function sqrsN655() {
    if(document.getElementById("imgSqrs655").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs655").src = "img/sqrs/blSqr.png"
};
};
function sqrsN656() {
    if(document.getElementById("imgSqrs656").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs656").src = "img/sqrs/blSqr.png"
};
};
function sqrsN657() {
    if(document.getElementById("imgSqrs657").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs657").src = "img/sqrs/blSqr.png"
};
};
function sqrsN658() {
    if(document.getElementById("imgSqrs658").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs658").src = "img/sqrs/blSqr.png"
};
};
function sqrsN659() {
    if(document.getElementById("imgSqrs659").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs659").src = "img/sqrs/blSqr.png"
};
};
function sqrsN660() {
    if(document.getElementById("imgSqrs660").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs660").src = "img/sqrs/blSqr.png"
};
};
function sqrsN661() {
    if(document.getElementById("imgSqrs661").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs661").src = "img/sqrs/blSqr.png"
};
};
function sqrsN662() {
    if(document.getElementById("imgSqrs662").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs662").src = "img/sqrs/blSqr.png"
};
};
function sqrsN663() {
    if(document.getElementById("imgSqrs663").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs663").src = "img/sqrs/blSqr.png"
};
};
function sqrsN664() {
    if(document.getElementById("imgSqrs664").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs664").src = "img/sqrs/blSqr.png"
};
};
function sqrsN665() {
    if(document.getElementById("imgSqrs665").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs665").src = "img/sqrs/blSqr.png"
};
};
function sqrsN666() {
    if(document.getElementById("imgSqrs666").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs666").src = "img/sqrs/blSqr.png"
};
};
function sqrsN667() {
    if(document.getElementById("imgSqrs667").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs667").src = "img/sqrs/blSqr.png"
};
};
function sqrsN668() {
    if(document.getElementById("imgSqrs668").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs668").src = "img/sqrs/blSqr.png"
};
};
function sqrsN669() {
    if(document.getElementById("imgSqrs669").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs669").src = "img/sqrs/blSqr.png"
};
};
function sqrsN670() {
    if(document.getElementById("imgSqrs670").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs670").src = "img/sqrs/blSqr.png"
};
};
function sqrsN671() {
    if(document.getElementById("imgSqrs671").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs671").src = "img/sqrs/blSqr.png"
};
};
function sqrsN672() {
    if(document.getElementById("imgSqrs672").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs672").src = "img/sqrs/blSqr.png"
};
};
function sqrsN673() {
    if(document.getElementById("imgSqrs673").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs673").src = "img/sqrs/blSqr.png"
};
};
function sqrsN674() {
    if(document.getElementById("imgSqrs674").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs674").src = "img/sqrs/blSqr.png"
};
};
function sqrsN675() {
    if(document.getElementById("imgSqrs675").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs675").src = "img/sqrs/blSqr.png"
};
};
function sqrsN676() {
    if(document.getElementById("imgSqrs676").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs676").src = "img/sqrs/blSqr.png"
};
};
function sqrsN677() {
    if(document.getElementById("imgSqrs677").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs677").src = "img/sqrs/blSqr.png"
};
};
function sqrsN678() {
    if(document.getElementById("imgSqrs678").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs678").src = "img/sqrs/blSqr.png"
};
};
function sqrsN679() {
    if(document.getElementById("imgSqrs679").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs679").src = "img/sqrs/blSqr.png"
};
};
function sqrsN680() {
    if(document.getElementById("imgSqrs680").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs680").src = "img/sqrs/blSqr.png"
};
};
function sqrsN681() {
    if(document.getElementById("imgSqrs681").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs681").src = "img/sqrs/blSqr.png"
};
};
function sqrsN682() {
    if(document.getElementById("imgSqrs682").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs682").src = "img/sqrs/blSqr.png"
};
};
function sqrsN683() {
    if(document.getElementById("imgSqrs683").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs683").src = "img/sqrs/blSqr.png"
};
};
function sqrsN684() {
    if(document.getElementById("imgSqrs684").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs684").src = "img/sqrs/blSqr.png"
};
};
function sqrsN685() {
    if(document.getElementById("imgSqrs685").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs685").src = "img/sqrs/blSqr.png"
};
};
function sqrsN686() {
    if(document.getElementById("imgSqrs686").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs686").src = "img/sqrs/blSqr.png"
};
};
function sqrsN687() {
    if(document.getElementById("imgSqrs687").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs687").src = "img/sqrs/blSqr.png"
};
};
function sqrsN688() {
    if(document.getElementById("imgSqrs688").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs688").src = "img/sqrs/blSqr.png"
};
};
function sqrsN689() {
    if(document.getElementById("imgSqrs689").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs689").src = "img/sqrs/blSqr.png"
};
};
function sqrsN690() {
    if(document.getElementById("imgSqrs690").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs690").src = "img/sqrs/blSqr.png"
};
};
function sqrsN691() {
    if(document.getElementById("imgSqrs691").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs691").src = "img/sqrs/blSqr.png"
};
};
function sqrsN692() {
    if(document.getElementById("imgSqrs692").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs692").src = "img/sqrs/blSqr.png"
};
};
function sqrsN693() {
    if(document.getElementById("imgSqrs693").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs693").src = "img/sqrs/blSqr.png"
};
};
function sqrsN694() {
    if(document.getElementById("imgSqrs694").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs694").src = "img/sqrs/blSqr.png"
};
};
function sqrsN695() {
    if(document.getElementById("imgSqrs695").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs695").src = "img/sqrs/blSqr.png"
};
};
function sqrsN696() {
    if(document.getElementById("imgSqrs696").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs696").src = "img/sqrs/blSqr.png"
};
};
function sqrsN697() {
    if(document.getElementById("imgSqrs697").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs697").src = "img/sqrs/blSqr.png"
};
};
function sqrsN698() {
    if(document.getElementById("imgSqrs698").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs698").src = "img/sqrs/blSqr.png"
};
};
function sqrsN699() {
    if(document.getElementById("imgSqrs699").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs699").src = "img/sqrs/blSqr.png"
};
};
function sqrsN700() {
    if(document.getElementById("imgSqrs700").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs700").src = "img/sqrs/blSqr.png"
};
};
function sqrsO701() {
    if(document.getElementById("imgSqrs701").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs701").src = "img/sqrs/blSqr.png"
};
};
function sqrsO702() {
    if(document.getElementById("imgSqrs702").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs702").src = "img/sqrs/blSqr.png"
};
};
function sqrsO703() {
    if(document.getElementById("imgSqrs703").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs703").src = "img/sqrs/blSqr.png"
};
};
function sqrsO704() {
    if(document.getElementById("imgSqrs704").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs704").src = "img/sqrs/blSqr.png"
};
};
function sqrsO705() {
    if(document.getElementById("imgSqrs705").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs705").src = "img/sqrs/blSqr.png"
};
};
function sqrsO706() {
    if(document.getElementById("imgSqrs706").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs706").src = "img/sqrs/blSqr.png"
};
};
function sqrsO707() {
    if(document.getElementById("imgSqrs707").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs707").src = "img/sqrs/blSqr.png"
};
};
function sqrsO708() {
    if(document.getElementById("imgSqrs708").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs708").src = "img/sqrs/blSqr.png"
};
};
function sqrsO709() {
    if(document.getElementById("imgSqrs709").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs709").src = "img/sqrs/blSqr.png"
};
};
function sqrsO710() {
    if(document.getElementById("imgSqrs710").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs710").src = "img/sqrs/blSqr.png"
};
};
function sqrsO711() {
    if(document.getElementById("imgSqrs711").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs711").src = "img/sqrs/blSqr.png"
};
};
function sqrsO712() {
    if(document.getElementById("imgSqrs712").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs712").src = "img/sqrs/blSqr.png"
};
};
function sqrsO713() {
    if(document.getElementById("imgSqrs713").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs713").src = "img/sqrs/blSqr.png"
};
};
function sqrsO714() {
    if(document.getElementById("imgSqrs714").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs714").src = "img/sqrs/blSqr.png"
};
};
function sqrsO715() {
    if(document.getElementById("imgSqrs715").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs715").src = "img/sqrs/blSqr.png"
};
};
function sqrsO716() {
    if(document.getElementById("imgSqrs716").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs716").src = "img/sqrs/blSqr.png"
};
};
function sqrsO717() {
    if(document.getElementById("imgSqrs717").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs717").src = "img/sqrs/blSqr.png"
};
};
function sqrsO718() {
    if(document.getElementById("imgSqrs718").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs718").src = "img/sqrs/blSqr.png"
};
};
function sqrsO719() {
    if(document.getElementById("imgSqrs719").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs719").src = "img/sqrs/blSqr.png"
};
};
function sqrsO720() {
    if(document.getElementById("imgSqrs720").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs720").src = "img/sqrs/blSqr.png"
};
};
function sqrsO721() {
    if(document.getElementById("imgSqrs721").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs721").src = "img/sqrs/blSqr.png"
};
};
function sqrsO722() {
    if(document.getElementById("imgSqrs722").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs722").src = "img/sqrs/blSqr.png"
};
};
function sqrsO723() {
    if(document.getElementById("imgSqrs723").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs723").src = "img/sqrs/blSqr.png"
};
};
function sqrsO724() {
    if(document.getElementById("imgSqrs724").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs724").src = "img/sqrs/blSqr.png"
};
};
function sqrsO725() {
    if(document.getElementById("imgSqrs725").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs725").src = "img/sqrs/blSqr.png"
};
};
function sqrsO726() {
    if(document.getElementById("imgSqrs726").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs726").src = "img/sqrs/blSqr.png"
};
};
function sqrsO727() {
    if(document.getElementById("imgSqrs727").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs727").src = "img/sqrs/blSqr.png"
};
};
function sqrsO728() {
    if(document.getElementById("imgSqrs728").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs728").src = "img/sqrs/blSqr.png"
};
};
function sqrsO729() {
    if(document.getElementById("imgSqrs729").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs729").src = "img/sqrs/blSqr.png"
};
};
function sqrsO730() {
    if(document.getElementById("imgSqrs730").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs730").src = "img/sqrs/blSqr.png"
};
};
function sqrsO731() {
    if(document.getElementById("imgSqrs731").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs731").src = "img/sqrs/blSqr.png"
};
};
function sqrsO732() {
    if(document.getElementById("imgSqrs732").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs732").src = "img/sqrs/blSqr.png"
};
};
function sqrsO733() {
    if(document.getElementById("imgSqrs733").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs733").src = "img/sqrs/blSqr.png"
};
};
function sqrsO734() {
    if(document.getElementById("imgSqrs734").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs734").src = "img/sqrs/blSqr.png"
};
};
function sqrsO735() {
    if(document.getElementById("imgSqrs735").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs735").src = "img/sqrs/blSqr.png"
};
};
function sqrsO736() {
    if(document.getElementById("imgSqrs736").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs736").src = "img/sqrs/blSqr.png"
};
};
function sqrsO737() {
    if(document.getElementById("imgSqrs737").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs737").src = "img/sqrs/blSqr.png"
};
};
function sqrsO738() {
    if(document.getElementById("imgSqrs738").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs738").src = "img/sqrs/blSqr.png"
};
};
function sqrsO739() {
    if(document.getElementById("imgSqrs739").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs739").src = "img/sqrs/blSqr.png"
};
};
function sqrsO740() {
    if(document.getElementById("imgSqrs740").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs740").src = "img/sqrs/blSqr.png"
};
};
function sqrsO741() {
    if(document.getElementById("imgSqrs741").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs741").src = "img/sqrs/blSqr.png"
};
};
function sqrsO742() {
    if(document.getElementById("imgSqrs742").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs742").src = "img/sqrs/blSqr.png"
};
};
function sqrsO743() {
    if(document.getElementById("imgSqrs743").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs743").src = "img/sqrs/blSqr.png"
};
};
function sqrsO744() {
    if(document.getElementById("imgSqrs744").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs744").src = "img/sqrs/blSqr.png"
};
};
function sqrsO745() {
    if(document.getElementById("imgSqrs745").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs745").src = "img/sqrs/blSqr.png"
};
};
function sqrsO746() {
    if(document.getElementById("imgSqrs746").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs746").src = "img/sqrs/blSqr.png"
};
};
function sqrsO747() {
    if(document.getElementById("imgSqrs747").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs747").src = "img/sqrs/blSqr.png"
};
};
function sqrsO748() {
    if(document.getElementById("imgSqrs748").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs748").src = "img/sqrs/blSqr.png"
};
};
function sqrsO749() {
    if(document.getElementById("imgSqrs749").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs749").src = "img/sqrs/blSqr.png"
};
};
function sqrsO750() {
    if(document.getElementById("imgSqrs750").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs750").src = "img/sqrs/blSqr.png"
};
};
function sqrsP751() {
    if(document.getElementById("imgSqrs751").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs751").src = "img/sqrs/blSqr.png"
};
};
function sqrsP752() {
    if(document.getElementById("imgSqrs752").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs752").src = "img/sqrs/blSqr.png"
};
};
function sqrsP753() {
    if(document.getElementById("imgSqrs753").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs753").src = "img/sqrs/blSqr.png"
};
};
function sqrsP754() {
    if(document.getElementById("imgSqrs754").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs754").src = "img/sqrs/blSqr.png"
};
};
function sqrsP755() {
    if(document.getElementById("imgSqrs755").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs755").src = "img/sqrs/blSqr.png"
};
};
function sqrsP756() {
    if(document.getElementById("imgSqrs756").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs756").src = "img/sqrs/blSqr.png"
};
};
function sqrsP757() {
    if(document.getElementById("imgSqrs757").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs757").src = "img/sqrs/blSqr.png"
};
};
function sqrsP758() {
    if(document.getElementById("imgSqrs758").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs758").src = "img/sqrs/blSqr.png"
};
};
function sqrsP759() {
    if(document.getElementById("imgSqrs759").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs759").src = "img/sqrs/blSqr.png"
};
};
function sqrsP760() {
    if(document.getElementById("imgSqrs760").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs760").src = "img/sqrs/blSqr.png"
};
};
function sqrsP761() {
    if(document.getElementById("imgSqrs761").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs761").src = "img/sqrs/blSqr.png"
};
};
function sqrsP762() {
    if(document.getElementById("imgSqrs762").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs762").src = "img/sqrs/blSqr.png"
};
};
function sqrsP763() {
    if(document.getElementById("imgSqrs763").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs763").src = "img/sqrs/blSqr.png"
};
};
function sqrsP764() {
    if(document.getElementById("imgSqrs764").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs764").src = "img/sqrs/blSqr.png"
};
};
function sqrsP765() {
    if(document.getElementById("imgSqrs765").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs765").src = "img/sqrs/blSqr.png"
};
};
function sqrsP766() {
    if(document.getElementById("imgSqrs766").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs766").src = "img/sqrs/blSqr.png"
};
};
function sqrsP767() {
    if(document.getElementById("imgSqrs767").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs767").src = "img/sqrs/blSqr.png"
};
};
function sqrsP768() {
    if(document.getElementById("imgSqrs768").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs768").src = "img/sqrs/blSqr.png"
};
};
function sqrsP769() {
    if(document.getElementById("imgSqrs769").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs769").src = "img/sqrs/blSqr.png"
};
};
function sqrsP770() {
    if(document.getElementById("imgSqrs770").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs770").src = "img/sqrs/blSqr.png"
};
};
function sqrsP771() {
    if(document.getElementById("imgSqrs771").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs771").src = "img/sqrs/blSqr.png"
};
};
function sqrsP772() {
    if(document.getElementById("imgSqrs772").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs772").src = "img/sqrs/blSqr.png"
};
};
function sqrsP773() {
    if(document.getElementById("imgSqrs773").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs773").src = "img/sqrs/blSqr.png"
};
};
function sqrsP774() {
    if(document.getElementById("imgSqrs774").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs774").src = "img/sqrs/blSqr.png"
};
};
function sqrsP775() {
    if(document.getElementById("imgSqrs775").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs775").src = "img/sqrs/blSqr.png"
};
};
function sqrsP776() {
    if(document.getElementById("imgSqrs776").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs776").src = "img/sqrs/blSqr.png"
};
};
function sqrsP777() {
    if(document.getElementById("imgSqrs777").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs777").src = "img/sqrs/blSqr.png"
};
};
function sqrsP778() {
    if(document.getElementById("imgSqrs778").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs778").src = "img/sqrs/blSqr.png"
};
};
function sqrsP779() {
    if(document.getElementById("imgSqrs779").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs779").src = "img/sqrs/blSqr.png"
};
};
function sqrsP780() {
    if(document.getElementById("imgSqrs780").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs780").src = "img/sqrs/blSqr.png"
};
};
function sqrsP781() {
    if(document.getElementById("imgSqrs781").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs781").src = "img/sqrs/blSqr.png"
};
};
function sqrsP782() {
    if(document.getElementById("imgSqrs782").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs782").src = "img/sqrs/blSqr.png"
};
};
function sqrsP783() {
    if(document.getElementById("imgSqrs783").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs783").src = "img/sqrs/blSqr.png"
};
};
function sqrsP784() {
    if(document.getElementById("imgSqrs784").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs784").src = "img/sqrs/blSqr.png"
};
};
function sqrsP785() {
    if(document.getElementById("imgSqrs785").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs785").src = "img/sqrs/blSqr.png"
};
};
function sqrsP786() {
    if(document.getElementById("imgSqrs786").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs786").src = "img/sqrs/blSqr.png"
};
};
function sqrsP787() {
    if(document.getElementById("imgSqrs787").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs787").src = "img/sqrs/blSqr.png"
};
};
function sqrsP788() {
    if(document.getElementById("imgSqrs788").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs788").src = "img/sqrs/blSqr.png"
};
};
function sqrsP789() {
    if(document.getElementById("imgSqrs789").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs789").src = "img/sqrs/blSqr.png"
};
};
function sqrsP790() {
    if(document.getElementById("imgSqrs790").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs790").src = "img/sqrs/blSqr.png"
};
};
function sqrsP791() {
    if(document.getElementById("imgSqrs791").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs791").src = "img/sqrs/blSqr.png"
};
};
function sqrsP792() {
    if(document.getElementById("imgSqrs792").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs792").src = "img/sqrs/blSqr.png"
};
};
function sqrsP793() {
    if(document.getElementById("imgSqrs793").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs793").src = "img/sqrs/blSqr.png"
};
};
function sqrsP794() {
    if(document.getElementById("imgSqrs794").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs794").src = "img/sqrs/blSqr.png"
};
};
function sqrsP795() {
    if(document.getElementById("imgSqrs795").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs795").src = "img/sqrs/blSqr.png"
};
};
function sqrsP796() {
    if(document.getElementById("imgSqrs796").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs796").src = "img/sqrs/blSqr.png"
};
};
function sqrsP797() {
    if(document.getElementById("imgSqrs797").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs797").src = "img/sqrs/blSqr.png"
};
};
function sqrsP798() {
    if(document.getElementById("imgSqrs798").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs798").src = "img/sqrs/blSqr.png"
};
};
function sqrsP799() {
    if(document.getElementById("imgSqrs799").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs799").src = "img/sqrs/blSqr.png"
};
};
function sqrsP800() {
    if(document.getElementById("imgSqrs800").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs800").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ801() {
    if(document.getElementById("imgSqrs801").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs801").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ802() {
    if(document.getElementById("imgSqrs802").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs802").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ803() {
    if(document.getElementById("imgSqrs803").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs803").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ804() {
    if(document.getElementById("imgSqrs804").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs804").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ805() {
    if(document.getElementById("imgSqrs805").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs805").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ806() {
    if(document.getElementById("imgSqrs806").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs806").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ807() {
    if(document.getElementById("imgSqrs807").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs807").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ808() {
    if(document.getElementById("imgSqrs808").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs808").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ809() {
    if(document.getElementById("imgSqrs809").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs809").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ810() {
    if(document.getElementById("imgSqrs810").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs810").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ811() {
    if(document.getElementById("imgSqrs811").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs811").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ812() {
    if(document.getElementById("imgSqrs812").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs812").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ813() {
    if(document.getElementById("imgSqrs813").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs813").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ814() {
    if(document.getElementById("imgSqrs814").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs814").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ815() {
    if(document.getElementById("imgSqrs815").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs815").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ816() {
    if(document.getElementById("imgSqrs816").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs816").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ817() {
    if(document.getElementById("imgSqrs817").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs817").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ818() {
    if(document.getElementById("imgSqrs818").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs818").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ819() {
    if(document.getElementById("imgSqrs819").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs819").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ820() {
    if(document.getElementById("imgSqrs820").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs820").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ821() {
    if(document.getElementById("imgSqrs821").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs821").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ822() {
    if(document.getElementById("imgSqrs822").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs822").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ823() {
    if(document.getElementById("imgSqrs823").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs823").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ824() {
    if(document.getElementById("imgSqrs824").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs824").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ825() {
    if(document.getElementById("imgSqrs825").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs825").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ826() {
    if(document.getElementById("imgSqrs826").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs826").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ827() {
    if(document.getElementById("imgSqrs827").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs827").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ828() {
    if(document.getElementById("imgSqrs828").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs828").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ829() {
    if(document.getElementById("imgSqrs829").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs829").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ830() {
    if(document.getElementById("imgSqrs830").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs830").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ831() {
    if(document.getElementById("imgSqrs831").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs831").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ832() {
    if(document.getElementById("imgSqrs832").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs832").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ833() {
    if(document.getElementById("imgSqrs833").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs833").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ834() {
    if(document.getElementById("imgSqrs834").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs834").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ835() {
    if(document.getElementById("imgSqrs835").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs835").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ836() {
    if(document.getElementById("imgSqrs836").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs836").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ837() {
    if(document.getElementById("imgSqrs837").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs837").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ838() {
    if(document.getElementById("imgSqrs838").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs838").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ839() {
    if(document.getElementById("imgSqrs839").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs839").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ840() {
    if(document.getElementById("imgSqrs840").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs840").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ841() {
    if(document.getElementById("imgSqrs841").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs841").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ842() {
    if(document.getElementById("imgSqrs842").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs842").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ843() {
    if(document.getElementById("imgSqrs843").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs843").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ844() {
    if(document.getElementById("imgSqrs844").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs844").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ845() {
    if(document.getElementById("imgSqrs845").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs845").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ846() {
    if(document.getElementById("imgSqrs846").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs846").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ847() {
    if(document.getElementById("imgSqrs847").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs847").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ848() {
    if(document.getElementById("imgSqrs848").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs848").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ849() {
    if(document.getElementById("imgSqrs849").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs849").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ850() {
    if(document.getElementById("imgSqrs850").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs850").src = "img/sqrs/blSqr.png"
};
};
function sqrsR851() {
    if(document.getElementById("imgSqrs851").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs851").src = "img/sqrs/blSqr.png"
};
};
function sqrsR852() {
    if(document.getElementById("imgSqrs852").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs852").src = "img/sqrs/blSqr.png"
};
};
function sqrsR853() {
    if(document.getElementById("imgSqrs853").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs853").src = "img/sqrs/blSqr.png"
};
};
function sqrsR854() {
    if(document.getElementById("imgSqrs854").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs854").src = "img/sqrs/blSqr.png"
};
};
function sqrsR855() {
    if(document.getElementById("imgSqrs855").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs855").src = "img/sqrs/blSqr.png"
};
};
function sqrsR856() {
    if(document.getElementById("imgSqrs856").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs856").src = "img/sqrs/blSqr.png"
};
};
function sqrsR857() {
    if(document.getElementById("imgSqrs857").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs857").src = "img/sqrs/blSqr.png"
};
};
function sqrsR858() {
    if(document.getElementById("imgSqrs858").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs858").src = "img/sqrs/blSqr.png"
};
};
function sqrsR859() {
    if(document.getElementById("imgSqrs859").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs859").src = "img/sqrs/blSqr.png"
};
};
function sqrsR860() {
    if(document.getElementById("imgSqrs860").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs860").src = "img/sqrs/blSqr.png"
};
};
function sqrsR861() {
    if(document.getElementById("imgSqrs861").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs861").src = "img/sqrs/blSqr.png"
};
};
function sqrsR862() {
    if(document.getElementById("imgSqrs862").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs862").src = "img/sqrs/blSqr.png"
};
};
function sqrsR863() {
    if(document.getElementById("imgSqrs863").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs863").src = "img/sqrs/blSqr.png"
};
};
function sqrsR864() {
    if(document.getElementById("imgSqrs864").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs864").src = "img/sqrs/blSqr.png"
};
};
function sqrsR865() {
    if(document.getElementById("imgSqrs865").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs865").src = "img/sqrs/blSqr.png"
};
};
function sqrsR866() {
    if(document.getElementById("imgSqrs866").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs866").src = "img/sqrs/blSqr.png"
};
};
function sqrsR867() {
    if(document.getElementById("imgSqrs867").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs867").src = "img/sqrs/blSqr.png"
};
};
function sqrsR868() {
    if(document.getElementById("imgSqrs868").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs868").src = "img/sqrs/blSqr.png"
};
};
function sqrsR869() {
    if(document.getElementById("imgSqrs869").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs869").src = "img/sqrs/blSqr.png"
};
};
function sqrsR870() {
    if(document.getElementById("imgSqrs870").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs870").src = "img/sqrs/blSqr.png"
};
};
function sqrsR871() {
    if(document.getElementById("imgSqrs871").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs871").src = "img/sqrs/blSqr.png"
};
};
function sqrsR872() {
    if(document.getElementById("imgSqrs872").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs872").src = "img/sqrs/blSqr.png"
};
};
function sqrsR873() {
    if(document.getElementById("imgSqrs873").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs873").src = "img/sqrs/blSqr.png"
};
};
function sqrsR874() {
    if(document.getElementById("imgSqrs874").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs874").src = "img/sqrs/blSqr.png"
};
};
function sqrsR875() {
    if(document.getElementById("imgSqrs875").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs875").src = "img/sqrs/blSqr.png"
};
};
function sqrsR876() {
    if(document.getElementById("imgSqrs876").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs876").src = "img/sqrs/blSqr.png"
};
};
function sqrsR877() {
    if(document.getElementById("imgSqrs877").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs877").src = "img/sqrs/blSqr.png"
};
};
function sqrsR878() {
    if(document.getElementById("imgSqrs878").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs878").src = "img/sqrs/blSqr.png"
};
};
function sqrsR879() {
    if(document.getElementById("imgSqrs879").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs879").src = "img/sqrs/blSqr.png"
};
};
function sqrsR880() {
    if(document.getElementById("imgSqrs880").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs880").src = "img/sqrs/blSqr.png"
};
};
function sqrsR881() {
    if(document.getElementById("imgSqrs881").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs881").src = "img/sqrs/blSqr.png"
};
};
function sqrsR882() {
    if(document.getElementById("imgSqrs882").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs882").src = "img/sqrs/blSqr.png"
};
};
function sqrsR883() {
    if(document.getElementById("imgSqrs883").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs883").src = "img/sqrs/blSqr.png"
};
};
function sqrsR884() {
    if(document.getElementById("imgSqrs884").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs884").src = "img/sqrs/blSqr.png"
};
};
function sqrsR885() {
    if(document.getElementById("imgSqrs885").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs885").src = "img/sqrs/blSqr.png"
};
};
function sqrsR886() {
    if(document.getElementById("imgSqrs886").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs886").src = "img/sqrs/blSqr.png"
};
};
function sqrsR887() {
    if(document.getElementById("imgSqrs887").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs887").src = "img/sqrs/blSqr.png"
};
};
function sqrsR888() {
    if(document.getElementById("imgSqrs888").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs888").src = "img/sqrs/blSqr.png"
};
};
function sqrsR889() {
    if(document.getElementById("imgSqrs889").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs889").src = "img/sqrs/blSqr.png"
};
};
function sqrsR890() {
    if(document.getElementById("imgSqrs890").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs890").src = "img/sqrs/blSqr.png"
};
};
function sqrsR891() {
    if(document.getElementById("imgSqrs891").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs891").src = "img/sqrs/blSqr.png"
};
};
function sqrsR892() {
    if(document.getElementById("imgSqrs892").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs892").src = "img/sqrs/blSqr.png"
};
};
function sqrsR893() {
    if(document.getElementById("imgSqrs893").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs893").src = "img/sqrs/blSqr.png"
};
};
function sqrsR894() {
    if(document.getElementById("imgSqrs894").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs894").src = "img/sqrs/blSqr.png"
};
};
function sqrsR895() {
    if(document.getElementById("imgSqrs895").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs895").src = "img/sqrs/blSqr.png"
};
};
function sqrsR896() {
    if(document.getElementById("imgSqrs896").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs896").src = "img/sqrs/blSqr.png"
};
};
function sqrsR897() {
    if(document.getElementById("imgSqrs897").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs897").src = "img/sqrs/blSqr.png"
};
};
function sqrsR898() {
    if(document.getElementById("imgSqrs898").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs898").src = "img/sqrs/blSqr.png"
};
};
function sqrsR899() {
    if(document.getElementById("imgSqrs899").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs899").src = "img/sqrs/blSqr.png"
};
};
function sqrsR900() {
    if(document.getElementById("imgSqrs900").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs900").src = "img/sqrs/blSqr.png"
};
};
function sqrsS901() {
    if(document.getElementById("imgSqrs901").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs901").src = "img/sqrs/blSqr.png"
};
};
function sqrsS902() {
    if(document.getElementById("imgSqrs902").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs902").src = "img/sqrs/blSqr.png"
};
};
function sqrsS903() {
    if(document.getElementById("imgSqrs903").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs903").src = "img/sqrs/blSqr.png"
};
};
function sqrsS904() {
    if(document.getElementById("imgSqrs904").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs904").src = "img/sqrs/blSqr.png"
};
};
function sqrsS905() {
    if(document.getElementById("imgSqrs905").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs905").src = "img/sqrs/blSqr.png"
};
};
function sqrsS906() {
    if(document.getElementById("imgSqrs906").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs906").src = "img/sqrs/blSqr.png"
};
};
function sqrsS907() {
    if(document.getElementById("imgSqrs907").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs907").src = "img/sqrs/blSqr.png"
};
};
function sqrsS908() {
    if(document.getElementById("imgSqrs908").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs908").src = "img/sqrs/blSqr.png"
};
};
function sqrsS909() {
    if(document.getElementById("imgSqrs909").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs909").src = "img/sqrs/blSqr.png"
};
};
function sqrsS910() {
    if(document.getElementById("imgSqrs910").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs910").src = "img/sqrs/blSqr.png"
};
};
function sqrsS911() {
    if(document.getElementById("imgSqrs911").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs911").src = "img/sqrs/blSqr.png"
};
};
function sqrsS912() {
    if(document.getElementById("imgSqrs912").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs912").src = "img/sqrs/blSqr.png"
};
};
function sqrsS913() {
    if(document.getElementById("imgSqrs913").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs913").src = "img/sqrs/blSqr.png"
};
};
function sqrsS914() {
    if(document.getElementById("imgSqrs914").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs914").src = "img/sqrs/blSqr.png"
};
};
function sqrsS915() {
    if(document.getElementById("imgSqrs915").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs915").src = "img/sqrs/blSqr.png"
};
};
function sqrsS916() {
    if(document.getElementById("imgSqrs916").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs916").src = "img/sqrs/blSqr.png"
};
};
function sqrsS917() {
    if(document.getElementById("imgSqrs917").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs917").src = "img/sqrs/blSqr.png"
};
};
function sqrsS918() {
    if(document.getElementById("imgSqrs918").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs918").src = "img/sqrs/blSqr.png"
};
};
function sqrsS919() {
    if(document.getElementById("imgSqrs919").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs919").src = "img/sqrs/blSqr.png"
};
};
function sqrsS920() {
    if(document.getElementById("imgSqrs920").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs920").src = "img/sqrs/blSqr.png"
};
};
function sqrsS921() {
    if(document.getElementById("imgSqrs921").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs921").src = "img/sqrs/blSqr.png"
};
};
function sqrsS922() {
    if(document.getElementById("imgSqrs922").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs922").src = "img/sqrs/blSqr.png"
};
};
function sqrsS923() {
    if(document.getElementById("imgSqrs923").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs923").src = "img/sqrs/blSqr.png"
};
};
function sqrsS924() {
    if(document.getElementById("imgSqrs924").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs924").src = "img/sqrs/blSqr.png"
};
};
function sqrsS925() {
    if(document.getElementById("imgSqrs925").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs925").src = "img/sqrs/blSqr.png"
};
};
function sqrsS926() {
    if(document.getElementById("imgSqrs926").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs926").src = "img/sqrs/blSqr.png"
};
};
function sqrsS927() {
    if(document.getElementById("imgSqrs927").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs927").src = "img/sqrs/blSqr.png"
};
};
function sqrsS928() {
    if(document.getElementById("imgSqrs928").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs928").src = "img/sqrs/blSqr.png"
};
};
function sqrsS929() {
    if(document.getElementById("imgSqrs929").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs929").src = "img/sqrs/blSqr.png"
};
};
function sqrsS930() {
    if(document.getElementById("imgSqrs930").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs930").src = "img/sqrs/blSqr.png"
};
};
function sqrsS931() {
    if(document.getElementById("imgSqrs931").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs931").src = "img/sqrs/blSqr.png"
};
};
function sqrsS932() {
    if(document.getElementById("imgSqrs932").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs932").src = "img/sqrs/blSqr.png"
};
};
function sqrsS933() {
    if(document.getElementById("imgSqrs933").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs933").src = "img/sqrs/blSqr.png"
};
};
function sqrsS934() {
    if(document.getElementById("imgSqrs934").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs934").src = "img/sqrs/blSqr.png"
};
};
function sqrsS935() {
    if(document.getElementById("imgSqrs935").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs935").src = "img/sqrs/blSqr.png"
};
};
function sqrsS936() {
    if(document.getElementById("imgSqrs936").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs936").src = "img/sqrs/blSqr.png"
};
};
function sqrsS937() {
    if(document.getElementById("imgSqrs937").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs937").src = "img/sqrs/blSqr.png"
};
};
function sqrsS938() {
    if(document.getElementById("imgSqrs938").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs938").src = "img/sqrs/blSqr.png"
};
};
function sqrsS939() {
    if(document.getElementById("imgSqrs939").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs939").src = "img/sqrs/blSqr.png"
};
};
function sqrsS940() {
    if(document.getElementById("imgSqrs940").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs940").src = "img/sqrs/blSqr.png"
};
};
function sqrsS941() {
    if(document.getElementById("imgSqrs941").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs941").src = "img/sqrs/blSqr.png"
};
};
function sqrsS942() {
    if(document.getElementById("imgSqrs942").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs942").src = "img/sqrs/blSqr.png"
};
};
function sqrsS943() {
    if(document.getElementById("imgSqrs943").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs943").src = "img/sqrs/blSqr.png"
};
};
function sqrsS944() {
    if(document.getElementById("imgSqrs944").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs944").src = "img/sqrs/blSqr.png"
};
};
function sqrsS945() {
    if(document.getElementById("imgSqrs945").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs945").src = "img/sqrs/blSqr.png"
};
};
function sqrsS946() {
    if(document.getElementById("imgSqrs946").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs946").src = "img/sqrs/blSqr.png"
};
};
function sqrsS947() {
    if(document.getElementById("imgSqrs947").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs947").src = "img/sqrs/blSqr.png"
};
};
function sqrsS948() {
    if(document.getElementById("imgSqrs948").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs948").src = "img/sqrs/blSqr.png"
};
};
function sqrsS949() {
    if(document.getElementById("imgSqrs949").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs949").src = "img/sqrs/blSqr.png"
};
};
function sqrsS950() {
    if(document.getElementById("imgSqrs950").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs950").src = "img/sqrs/blSqr.png"
};
};
function sqrsT951() {
    if(document.getElementById("imgSqrs951").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs951").src = "img/sqrs/blSqr.png"
};
};
function sqrsT952() {
    if(document.getElementById("imgSqrs952").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs952").src = "img/sqrs/blSqr.png"
};
};
function sqrsT953() {
    if(document.getElementById("imgSqrs953").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs953").src = "img/sqrs/blSqr.png"
};
};
function sqrsT954() {
    if(document.getElementById("imgSqrs954").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs954").src = "img/sqrs/blSqr.png"
};
};
function sqrsT955() {
    if(document.getElementById("imgSqrs955").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs955").src = "img/sqrs/blSqr.png"
};
};
function sqrsT956() {
    if(document.getElementById("imgSqrs956").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs956").src = "img/sqrs/blSqr.png"
};
};
function sqrsT957() {
    if(document.getElementById("imgSqrs957").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs957").src = "img/sqrs/blSqr.png"
};
};
function sqrsT958() {
    if(document.getElementById("imgSqrs958").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs958").src = "img/sqrs/blSqr.png"
};
};
function sqrsT959() {
    if(document.getElementById("imgSqrs959").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs959").src = "img/sqrs/blSqr.png"
};
};
function sqrsT960() {
    if(document.getElementById("imgSqrs960").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs960").src = "img/sqrs/blSqr.png"
};
};
function sqrsT961() {
    if(document.getElementById("imgSqrs961").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs961").src = "img/sqrs/blSqr.png"
};
};
function sqrsT962() {
    if(document.getElementById("imgSqrs962").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs962").src = "img/sqrs/blSqr.png"
};
};
function sqrsT963() {
    if(document.getElementById("imgSqrs963").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs963").src = "img/sqrs/blSqr.png"
};
};
function sqrsT964() {
    if(document.getElementById("imgSqrs964").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs964").src = "img/sqrs/blSqr.png"
};
};
function sqrsT965() {
    if(document.getElementById("imgSqrs965").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs965").src = "img/sqrs/blSqr.png"
};
};
function sqrsT966() {
    if(document.getElementById("imgSqrs966").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs966").src = "img/sqrs/blSqr.png"
};
};
function sqrsT967() {
    if(document.getElementById("imgSqrs967").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs967").src = "img/sqrs/blSqr.png"
};
};
function sqrsT968() {
    if(document.getElementById("imgSqrs968").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs968").src = "img/sqrs/blSqr.png"
};
};
function sqrsT969() {
    if(document.getElementById("imgSqrs969").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs969").src = "img/sqrs/blSqr.png"
};
};
function sqrsT970() {
    if(document.getElementById("imgSqrs970").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs970").src = "img/sqrs/blSqr.png"
};
};
function sqrsT971() {
    if(document.getElementById("imgSqrs971").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs971").src = "img/sqrs/blSqr.png"
};
};
function sqrsT972() {
    if(document.getElementById("imgSqrs972").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs972").src = "img/sqrs/blSqr.png"
};
};
function sqrsT973() {
    if(document.getElementById("imgSqrs973").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs973").src = "img/sqrs/blSqr.png"
};
};
function sqrsT974() {
    if(document.getElementById("imgSqrs974").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs974").src = "img/sqrs/blSqr.png"
};
};
function sqrsT975() {
    if(document.getElementById("imgSqrs975").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs975").src = "img/sqrs/blSqr.png"
};
};
function sqrsT976() {
    if(document.getElementById("imgSqrs976").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs976").src = "img/sqrs/blSqr.png"
};
};
function sqrsT977() {
    if(document.getElementById("imgSqrs977").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs977").src = "img/sqrs/blSqr.png"
};
};
function sqrsT978() {
    if(document.getElementById("imgSqrs978").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs978").src = "img/sqrs/blSqr.png"
};
};
function sqrsT979() {
    if(document.getElementById("imgSqrs979").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs979").src = "img/sqrs/blSqr.png"
};
};
function sqrsT980() {
    if(document.getElementById("imgSqrs980").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs980").src = "img/sqrs/blSqr.png"
};
};
function sqrsT981() {
    if(document.getElementById("imgSqrs981").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs981").src = "img/sqrs/blSqr.png"
};
};
function sqrsT982() {
    if(document.getElementById("imgSqrs982").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs982").src = "img/sqrs/blSqr.png"
};
};
function sqrsT983() {
    if(document.getElementById("imgSqrs983").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs983").src = "img/sqrs/blSqr.png"
};
};
function sqrsT984() {
    if(document.getElementById("imgSqrs984").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs984").src = "img/sqrs/blSqr.png"
};
};
function sqrsT985() {
    if(document.getElementById("imgSqrs985").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs985").src = "img/sqrs/blSqr.png"
};
};
function sqrsT986() {
    if(document.getElementById("imgSqrs986").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs986").src = "img/sqrs/blSqr.png"
};
};
function sqrsT987() {
    if(document.getElementById("imgSqrs987").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs987").src = "img/sqrs/blSqr.png"
};
};
function sqrsT988() {
    if(document.getElementById("imgSqrs988").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs988").src = "img/sqrs/blSqr.png"
};
};
function sqrsT989() {
    if(document.getElementById("imgSqrs989").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs989").src = "img/sqrs/blSqr.png"
};
};
function sqrsT990() {
    if(document.getElementById("imgSqrs990").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs990").src = "img/sqrs/blSqr.png"
};
};
function sqrsT991() {
    if(document.getElementById("imgSqrs991").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs991").src = "img/sqrs/blSqr.png"
};
};
function sqrsT992() {
    if(document.getElementById("imgSqrs992").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs992").src = "img/sqrs/blSqr.png"
};
};
function sqrsT993() {
    if(document.getElementById("imgSqrs993").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs993").src = "img/sqrs/blSqr.png"
};
};
function sqrsT994() {
    if(document.getElementById("imgSqrs994").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs994").src = "img/sqrs/blSqr.png"
};
};
function sqrsT995() {
    if(document.getElementById("imgSqrs995").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs995").src = "img/sqrs/blSqr.png"
};
};
function sqrsT996() {
    if(document.getElementById("imgSqrs996").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs996").src = "img/sqrs/blSqr.png"
};
};
function sqrsT997() {
    if(document.getElementById("imgSqrs997").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs997").src = "img/sqrs/blSqr.png"
};
};
function sqrsT998() {
    if(document.getElementById("imgSqrs998").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs998").src = "img/sqrs/blSqr.png"
};
};
function sqrsT999() {
    if(document.getElementById("imgSqrs999").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs999").src = "img/sqrs/blSqr.png"
};
};
function sqrsT1000() {
    if(document.getElementById("imgSqrs1000").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1000").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1001() {
    if(document.getElementById("imgSqrs1001").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1001").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1002() {
    if(document.getElementById("imgSqrs1002").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1002").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1003() {
    if(document.getElementById("imgSqrs1003").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1003").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1004() {
    if(document.getElementById("imgSqrs1004").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1004").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1005() {
    if(document.getElementById("imgSqrs1005").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1005").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1006() {
    if(document.getElementById("imgSqrs1006").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1006").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1007() {
    if(document.getElementById("imgSqrs1007").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1007").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1008() {
    if(document.getElementById("imgSqrs1008").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1008").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1009() {
    if(document.getElementById("imgSqrs1009").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1009").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1010() {
    if(document.getElementById("imgSqrs1010").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1010").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1011() {
    if(document.getElementById("imgSqrs1011").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1011").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1012() {
    if(document.getElementById("imgSqrs1012").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1012").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1013() {
    if(document.getElementById("imgSqrs1013").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1013").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1014() {
    if(document.getElementById("imgSqrs1014").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1014").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1015() {
    if(document.getElementById("imgSqrs1015").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1015").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1016() {
    if(document.getElementById("imgSqrs1016").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1016").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1017() {
    if(document.getElementById("imgSqrs1017").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1017").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1018() {
    if(document.getElementById("imgSqrs1018").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1018").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1019() {
    if(document.getElementById("imgSqrs1019").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1019").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1020() {
    if(document.getElementById("imgSqrs1020").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1020").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1021() {
    if(document.getElementById("imgSqrs1021").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1021").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1022() {
    if(document.getElementById("imgSqrs1022").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1022").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1023() {
    if(document.getElementById("imgSqrs1023").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1023").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1024() {
    if(document.getElementById("imgSqrs1024").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1024").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1025() {
    if(document.getElementById("imgSqrs1025").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1025").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1026() {
    if(document.getElementById("imgSqrs1026").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1026").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1027() {
    if(document.getElementById("imgSqrs1027").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1027").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1028() {
    if(document.getElementById("imgSqrs1028").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1028").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1029() {
    if(document.getElementById("imgSqrs1029").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1029").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1030() {
    if(document.getElementById("imgSqrs1030").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1030").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1031() {
    if(document.getElementById("imgSqrs1031").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1031").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1032() {
    if(document.getElementById("imgSqrs1032").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1032").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1033() {
    if(document.getElementById("imgSqrs1033").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1033").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1034() {
    if(document.getElementById("imgSqrs1034").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1034").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1035() {
    if(document.getElementById("imgSqrs1035").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1035").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1036() {
    if(document.getElementById("imgSqrs1036").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1036").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1037() {
    if(document.getElementById("imgSqrs1037").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1037").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1038() {
    if(document.getElementById("imgSqrs1038").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1038").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1039() {
    if(document.getElementById("imgSqrs1039").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1039").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1040() {
    if(document.getElementById("imgSqrs1040").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1040").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1041() {
    if(document.getElementById("imgSqrs1041").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1041").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1042() {
    if(document.getElementById("imgSqrs1042").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1042").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1043() {
    if(document.getElementById("imgSqrs1043").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1043").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1044() {
    if(document.getElementById("imgSqrs1044").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1044").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1045() {
    if(document.getElementById("imgSqrs1045").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1045").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1046() {
    if(document.getElementById("imgSqrs1046").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1046").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1047() {
    if(document.getElementById("imgSqrs1047").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1047").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1048() {
    if(document.getElementById("imgSqrs1048").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1048").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1049() {
    if(document.getElementById("imgSqrs1049").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1049").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1050() {
    if(document.getElementById("imgSqrs1050").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1050").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1051() {
    if(document.getElementById("imgSqrs1051").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1051").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1052() {
    if(document.getElementById("imgSqrs1052").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1052").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1053() {
    if(document.getElementById("imgSqrs1053").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1053").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1054() {
    if(document.getElementById("imgSqrs1054").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1054").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1055() {
    if(document.getElementById("imgSqrs1055").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1055").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1056() {
    if(document.getElementById("imgSqrs1056").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1056").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1057() {
    if(document.getElementById("imgSqrs1057").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1057").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1058() {
    if(document.getElementById("imgSqrs1058").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1058").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1059() {
    if(document.getElementById("imgSqrs1059").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1059").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1060() {
    if(document.getElementById("imgSqrs1060").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1060").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1061() {
    if(document.getElementById("imgSqrs1061").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1061").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1062() {
    if(document.getElementById("imgSqrs1062").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1062").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1063() {
    if(document.getElementById("imgSqrs1063").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1063").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1064() {
    if(document.getElementById("imgSqrs1064").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1064").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1065() {
    if(document.getElementById("imgSqrs1065").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1065").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1066() {
    if(document.getElementById("imgSqrs1066").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1066").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1067() {
    if(document.getElementById("imgSqrs1067").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1067").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1068() {
    if(document.getElementById("imgSqrs1068").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1068").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1069() {
    if(document.getElementById("imgSqrs1069").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1069").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1070() {
    if(document.getElementById("imgSqrs1070").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1070").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1071() {
    if(document.getElementById("imgSqrs1071").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1071").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1072() {
    if(document.getElementById("imgSqrs1072").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1072").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1073() {
    if(document.getElementById("imgSqrs1073").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1073").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1074() {
    if(document.getElementById("imgSqrs1074").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1074").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1075() {
    if(document.getElementById("imgSqrs1075").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1075").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1076() {
    if(document.getElementById("imgSqrs1076").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1076").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1077() {
    if(document.getElementById("imgSqrs1077").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1077").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1078() {
    if(document.getElementById("imgSqrs1078").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1078").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1079() {
    if(document.getElementById("imgSqrs1079").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1079").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1080() {
    if(document.getElementById("imgSqrs1080").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1080").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1081() {
    if(document.getElementById("imgSqrs1081").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1081").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1082() {
    if(document.getElementById("imgSqrs1082").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1082").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1083() {
    if(document.getElementById("imgSqrs1083").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1083").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1084() {
    if(document.getElementById("imgSqrs1084").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1084").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1085() {
    if(document.getElementById("imgSqrs1085").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1085").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1086() {
    if(document.getElementById("imgSqrs1086").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1086").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1087() {
    if(document.getElementById("imgSqrs1087").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1087").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1088() {
    if(document.getElementById("imgSqrs1088").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1088").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1089() {
    if(document.getElementById("imgSqrs1089").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1089").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1090() {
    if(document.getElementById("imgSqrs1090").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1090").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1091() {
    if(document.getElementById("imgSqrs1091").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1091").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1092() {
    if(document.getElementById("imgSqrs1092").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1092").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1093() {
    if(document.getElementById("imgSqrs1093").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1093").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1094() {
    if(document.getElementById("imgSqrs1094").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1094").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1095() {
    if(document.getElementById("imgSqrs1095").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1095").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1096() {
    if(document.getElementById("imgSqrs1096").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1096").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1097() {
    if(document.getElementById("imgSqrs1097").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1097").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1098() {
    if(document.getElementById("imgSqrs1098").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1098").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1099() {
    if(document.getElementById("imgSqrs1099").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1099").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1100() {
    if(document.getElementById("imgSqrs1100").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1100").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1101() {
    if(document.getElementById("imgSqrs1101").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1101").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1102() {
    if(document.getElementById("imgSqrs1102").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1102").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1103() {
    if(document.getElementById("imgSqrs1103").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1103").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1104() {
    if(document.getElementById("imgSqrs1104").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1104").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1105() {
    if(document.getElementById("imgSqrs1105").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1105").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1106() {
    if(document.getElementById("imgSqrs1106").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1106").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1107() {
    if(document.getElementById("imgSqrs1107").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1107").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1108() {
    if(document.getElementById("imgSqrs1108").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1108").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1109() {
    if(document.getElementById("imgSqrs1109").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1109").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1110() {
    if(document.getElementById("imgSqrs1110").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1110").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1111() {
    if(document.getElementById("imgSqrs1111").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1111").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1112() {
    if(document.getElementById("imgSqrs1112").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1112").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1113() {
    if(document.getElementById("imgSqrs1113").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1113").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1114() {
    if(document.getElementById("imgSqrs1114").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1114").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1115() {
    if(document.getElementById("imgSqrs1115").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1115").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1116() {
    if(document.getElementById("imgSqrs1116").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1116").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1117() {
    if(document.getElementById("imgSqrs1117").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1117").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1118() {
    if(document.getElementById("imgSqrs1118").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1118").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1119() {
    if(document.getElementById("imgSqrs1119").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1119").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1120() {
    if(document.getElementById("imgSqrs1120").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1120").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1121() {
    if(document.getElementById("imgSqrs1121").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1121").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1122() {
    if(document.getElementById("imgSqrs1122").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1122").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1123() {
    if(document.getElementById("imgSqrs1123").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1123").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1124() {
    if(document.getElementById("imgSqrs1124").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1124").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1125() {
    if(document.getElementById("imgSqrs1125").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1125").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1126() {
    if(document.getElementById("imgSqrs1126").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1126").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1127() {
    if(document.getElementById("imgSqrs1127").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1127").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1128() {
    if(document.getElementById("imgSqrs1128").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1128").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1129() {
    if(document.getElementById("imgSqrs1129").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1129").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1130() {
    if(document.getElementById("imgSqrs1130").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1130").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1131() {
    if(document.getElementById("imgSqrs1131").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1131").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1132() {
    if(document.getElementById("imgSqrs1132").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1132").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1133() {
    if(document.getElementById("imgSqrs1133").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1133").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1134() {
    if(document.getElementById("imgSqrs1134").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1134").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1135() {
    if(document.getElementById("imgSqrs1135").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1135").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1136() {
    if(document.getElementById("imgSqrs1136").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1136").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1137() {
    if(document.getElementById("imgSqrs1137").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1137").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1138() {
    if(document.getElementById("imgSqrs1138").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1138").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1139() {
    if(document.getElementById("imgSqrs1139").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1139").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1140() {
    if(document.getElementById("imgSqrs1140").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1140").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1141() {
    if(document.getElementById("imgSqrs1141").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1141").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1142() {
    if(document.getElementById("imgSqrs1142").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1142").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1143() {
    if(document.getElementById("imgSqrs1143").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1143").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1144() {
    if(document.getElementById("imgSqrs1144").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1144").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1145() {
    if(document.getElementById("imgSqrs1145").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1145").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1146() {
    if(document.getElementById("imgSqrs1146").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1146").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1147() {
    if(document.getElementById("imgSqrs1147").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1147").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1148() {
    if(document.getElementById("imgSqrs1148").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1148").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1149() {
    if(document.getElementById("imgSqrs1149").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1149").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1150() {
    if(document.getElementById("imgSqrs1150").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1150").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1151() {
    if(document.getElementById("imgSqrs1151").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1151").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1152() {
    if(document.getElementById("imgSqrs1152").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1152").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1153() {
    if(document.getElementById("imgSqrs1153").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1153").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1154() {
    if(document.getElementById("imgSqrs1154").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1154").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1155() {
    if(document.getElementById("imgSqrs1155").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1155").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1156() {
    if(document.getElementById("imgSqrs1156").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1156").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1157() {
    if(document.getElementById("imgSqrs1157").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1157").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1158() {
    if(document.getElementById("imgSqrs1158").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1158").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1159() {
    if(document.getElementById("imgSqrs1159").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1159").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1160() {
    if(document.getElementById("imgSqrs1160").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1160").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1161() {
    if(document.getElementById("imgSqrs1161").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1161").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1162() {
    if(document.getElementById("imgSqrs1162").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1162").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1163() {
    if(document.getElementById("imgSqrs1163").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1163").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1164() {
    if(document.getElementById("imgSqrs1164").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1164").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1165() {
    if(document.getElementById("imgSqrs1165").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1165").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1166() {
    if(document.getElementById("imgSqrs1166").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1166").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1167() {
    if(document.getElementById("imgSqrs1167").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1167").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1168() {
    if(document.getElementById("imgSqrs1168").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1168").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1169() {
    if(document.getElementById("imgSqrs1169").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1169").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1170() {
    if(document.getElementById("imgSqrs1170").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1170").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1171() {
    if(document.getElementById("imgSqrs1171").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1171").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1172() {
    if(document.getElementById("imgSqrs1172").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1172").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1173() {
    if(document.getElementById("imgSqrs1173").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1173").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1174() {
    if(document.getElementById("imgSqrs1174").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1174").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1175() {
    if(document.getElementById("imgSqrs1175").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1175").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1176() {
    if(document.getElementById("imgSqrs1176").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1176").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1177() {
    if(document.getElementById("imgSqrs1177").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1177").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1178() {
    if(document.getElementById("imgSqrs1178").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1178").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1179() {
    if(document.getElementById("imgSqrs1179").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1179").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1180() {
    if(document.getElementById("imgSqrs1180").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1180").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1181() {
    if(document.getElementById("imgSqrs1181").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1181").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1182() {
    if(document.getElementById("imgSqrs1182").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1182").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1183() {
    if(document.getElementById("imgSqrs1183").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1183").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1184() {
    if(document.getElementById("imgSqrs1184").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1184").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1185() {
    if(document.getElementById("imgSqrs1185").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1185").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1186() {
    if(document.getElementById("imgSqrs1186").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1186").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1187() {
    if(document.getElementById("imgSqrs1187").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1187").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1188() {
    if(document.getElementById("imgSqrs1188").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1188").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1189() {
    if(document.getElementById("imgSqrs1189").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1189").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1190() {
    if(document.getElementById("imgSqrs1190").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1190").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1191() {
    if(document.getElementById("imgSqrs1191").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1191").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1192() {
    if(document.getElementById("imgSqrs1192").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1192").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1193() {
    if(document.getElementById("imgSqrs1193").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1193").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1194() {
    if(document.getElementById("imgSqrs1194").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1194").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1195() {
    if(document.getElementById("imgSqrs1195").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1195").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1196() {
    if(document.getElementById("imgSqrs1196").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1196").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1197() {
    if(document.getElementById("imgSqrs1197").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1197").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1198() {
    if(document.getElementById("imgSqrs1198").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1198").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1199() {
    if(document.getElementById("imgSqrs1199").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1199").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1200() {
    if(document.getElementById("imgSqrs1200").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1200").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1201() {
    if(document.getElementById("imgSqrs1201").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1201").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1202() {
    if(document.getElementById("imgSqrs1202").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1202").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1203() {
    if(document.getElementById("imgSqrs1203").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1203").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1204() {
    if(document.getElementById("imgSqrs1204").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1204").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1205() {
    if(document.getElementById("imgSqrs1205").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1205").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1206() {
    if(document.getElementById("imgSqrs1206").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1206").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1207() {
    if(document.getElementById("imgSqrs1207").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1207").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1208() {
    if(document.getElementById("imgSqrs1208").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1208").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1209() {
    if(document.getElementById("imgSqrs1209").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1209").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1210() {
    if(document.getElementById("imgSqrs1210").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1210").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1211() {
    if(document.getElementById("imgSqrs1211").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1211").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1212() {
    if(document.getElementById("imgSqrs1212").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1212").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1213() {
    if(document.getElementById("imgSqrs1213").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1213").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1214() {
    if(document.getElementById("imgSqrs1214").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1214").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1215() {
    if(document.getElementById("imgSqrs1215").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1215").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1216() {
    if(document.getElementById("imgSqrs1216").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1216").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1217() {
    if(document.getElementById("imgSqrs1217").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1217").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1218() {
    if(document.getElementById("imgSqrs1218").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1218").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1219() {
    if(document.getElementById("imgSqrs1219").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1219").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1220() {
    if(document.getElementById("imgSqrs1220").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1220").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1221() {
    if(document.getElementById("imgSqrs1221").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1221").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1222() {
    if(document.getElementById("imgSqrs1222").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1222").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1223() {
    if(document.getElementById("imgSqrs1223").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1223").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1224() {
    if(document.getElementById("imgSqrs1224").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1224").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1225() {
    if(document.getElementById("imgSqrs1225").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1225").src = "img/sqrs/blSqr.png"
};
};

function sqrsA1() {
    if(document.getElementById("imgSqrs1").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1").src = "img/sqrs/blSqr.png"
};
};
function sqrsA2() {
    if(document.getElementById("imgSqrs2").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs2").src = "img/sqrs/blSqr.png"
};
};
function sqrsA3() {
    if(document.getElementById("imgSqrs3").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs3").src = "img/sqrs/blSqr.png"
};
};
function sqrsA4() {
    if(document.getElementById("imgSqrs4").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs4").src = "img/sqrs/blSqr.png"
};
};
function sqrsA5() {
    if(document.getElementById("imgSqrs5").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs5").src = "img/sqrs/blSqr.png"
};
};
function sqrsA6() {
    if(document.getElementById("imgSqrs6").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs6").src = "img/sqrs/blSqr.png"
};
};
function sqrsA7() {
    if(document.getElementById("imgSqrs7").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs7").src = "img/sqrs/blSqr.png"
};
};
function sqrsA8() {
    if(document.getElementById("imgSqrs8").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs8").src = "img/sqrs/blSqr.png"
};
};
function sqrsA9() {
    if(document.getElementById("imgSqrs9").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs9").src = "img/sqrs/blSqr.png"
};
};
function sqrsA10() {
    if(document.getElementById("imgSqrs10").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs10").src = "img/sqrs/blSqr.png"
};
};
function sqrsA11() {
    if(document.getElementById("imgSqrs11").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs11").src = "img/sqrs/blSqr.png"
};
};
function sqrsA12() {
    if(document.getElementById("imgSqrs12").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs12").src = "img/sqrs/blSqr.png"
};
};
function sqrsA13() {
    if(document.getElementById("imgSqrs13").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs13").src = "img/sqrs/blSqr.png"
};
};
function sqrsA14() {
    if(document.getElementById("imgSqrs14").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs14").src = "img/sqrs/blSqr.png"
};
};
function sqrsA15() {
    if(document.getElementById("imgSqrs15").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs15").src = "img/sqrs/blSqr.png"
};
};
function sqrsA16() {
    if(document.getElementById("imgSqrs16").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs16").src = "img/sqrs/blSqr.png"
};
};
function sqrsA17() {
    if(document.getElementById("imgSqrs17").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs17").src = "img/sqrs/blSqr.png"
};
};
function sqrsA18() {
    if(document.getElementById("imgSqrs18").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs18").src = "img/sqrs/blSqr.png"
};
};
function sqrsA19() {
    if(document.getElementById("imgSqrs19").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs19").src = "img/sqrs/blSqr.png"
};
};
function sqrsA20() {
    if(document.getElementById("imgSqrs20").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs20").src = "img/sqrs/blSqr.png"
};
};
function sqrsA21() {
    if(document.getElementById("imgSqrs21").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs21").src = "img/sqrs/blSqr.png"
};
};
function sqrsA22() {
    if(document.getElementById("imgSqrs22").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs22").src = "img/sqrs/blSqr.png"
};
};
function sqrsA23() {
    if(document.getElementById("imgSqrs23").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs23").src = "img/sqrs/blSqr.png"
};
};
function sqrsA24() {
    if(document.getElementById("imgSqrs24").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs24").src = "img/sqrs/blSqr.png"
};
};
function sqrsA25() {
    if(document.getElementById("imgSqrs25").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs25").src = "img/sqrs/blSqr.png"
};
};
function sqrsA26() {
    if(document.getElementById("imgSqrs26").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs26").src = "img/sqrs/blSqr.png"
};
};
function sqrsA27() {
    if(document.getElementById("imgSqrs27").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs27").src = "img/sqrs/blSqr.png"
};
};
function sqrsA28() {
    if(document.getElementById("imgSqrs28").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs28").src = "img/sqrs/blSqr.png"
};
};
function sqrsA29() {
    if(document.getElementById("imgSqrs29").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs29").src = "img/sqrs/blSqr.png"
};
};
function sqrsA30() {
    if(document.getElementById("imgSqrs30").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs30").src = "img/sqrs/blSqr.png"
};
};
function sqrsA31() {
    if(document.getElementById("imgSqrs31").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs31").src = "img/sqrs/blSqr.png"
};
};
function sqrsA32() {
    if(document.getElementById("imgSqrs32").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs32").src = "img/sqrs/blSqr.png"
};
};
function sqrsA33() {
    if(document.getElementById("imgSqrs33").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs33").src = "img/sqrs/blSqr.png"
};
};
function sqrsA34() {
    if(document.getElementById("imgSqrs34").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs34").src = "img/sqrs/blSqr.png"
};
};
function sqrsA35() {
    if(document.getElementById("imgSqrs35").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs35").src = "img/sqrs/blSqr.png"
};
};
function sqrsA36() {
    if(document.getElementById("imgSqrs36").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs36").src = "img/sqrs/blSqr.png"
};
};
function sqrsA37() {
    if(document.getElementById("imgSqrs37").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs37").src = "img/sqrs/blSqr.png"
};
};
function sqrsA38() {
    if(document.getElementById("imgSqrs38").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs38").src = "img/sqrs/blSqr.png"
};
};
function sqrsA39() {
    if(document.getElementById("imgSqrs39").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs39").src = "img/sqrs/blSqr.png"
};
};
function sqrsA40() {
    if(document.getElementById("imgSqrs40").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs40").src = "img/sqrs/blSqr.png"
};
};
function sqrsA41() {
    if(document.getElementById("imgSqrs41").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs41").src = "img/sqrs/blSqr.png"
};
};
function sqrsA42() {
    if(document.getElementById("imgSqrs42").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs42").src = "img/sqrs/blSqr.png"
};
};
function sqrsA43() {
    if(document.getElementById("imgSqrs43").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs43").src = "img/sqrs/blSqr.png"
};
};
function sqrsA44() {
    if(document.getElementById("imgSqrs44").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs44").src = "img/sqrs/blSqr.png"
};
};
function sqrsA45() {
    if(document.getElementById("imgSqrs45").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs45").src = "img/sqrs/blSqr.png"
};
};
function sqrsA46() {
    if(document.getElementById("imgSqrs46").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs46").src = "img/sqrs/blSqr.png"
};
};
function sqrsA47() {
    if(document.getElementById("imgSqrs47").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs47").src = "img/sqrs/blSqr.png"
};
};
function sqrsA48() {
    if(document.getElementById("imgSqrs48").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs48").src = "img/sqrs/blSqr.png"
};
};
function sqrsA49() {
    if(document.getElementById("imgSqrs49").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs49").src = "img/sqrs/blSqr.png"
};
};
function sqrsA50() {
    if(document.getElementById("imgSqrs50").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs50").src = "img/sqrs/blSqr.png"
};
};
function sqrsB51() {
    if(document.getElementById("imgSqrs51").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs51").src = "img/sqrs/blSqr.png"
};
};
function sqrsB52() {
    if(document.getElementById("imgSqrs52").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs52").src = "img/sqrs/blSqr.png"
};
};
function sqrsB53() {
    if(document.getElementById("imgSqrs53").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs53").src = "img/sqrs/blSqr.png"
};
};
function sqrsB54() {
    if(document.getElementById("imgSqrs54").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs54").src = "img/sqrs/blSqr.png"
};
};
function sqrsB55() {
    if(document.getElementById("imgSqrs55").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs55").src = "img/sqrs/blSqr.png"
};
};
function sqrsB56() {
    if(document.getElementById("imgSqrs56").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs56").src = "img/sqrs/blSqr.png"
};
};
function sqrsB57() {
    if(document.getElementById("imgSqrs57").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs57").src = "img/sqrs/blSqr.png"
};
};
function sqrsB58() {
    if(document.getElementById("imgSqrs58").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs58").src = "img/sqrs/blSqr.png"
};
};
function sqrsB59() {
    if(document.getElementById("imgSqrs59").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs59").src = "img/sqrs/blSqr.png"
};
};
function sqrsB60() {
    if(document.getElementById("imgSqrs60").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs60").src = "img/sqrs/blSqr.png"
};
};
function sqrsB61() {
    if(document.getElementById("imgSqrs61").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs61").src = "img/sqrs/blSqr.png"
};
};
function sqrsB62() {
    if(document.getElementById("imgSqrs62").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs62").src = "img/sqrs/blSqr.png"
};
};
function sqrsB63() {
    if(document.getElementById("imgSqrs63").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs63").src = "img/sqrs/blSqr.png"
};
};
function sqrsB64() {
    if(document.getElementById("imgSqrs64").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs64").src = "img/sqrs/blSqr.png"
};
};
function sqrsB65() {
    if(document.getElementById("imgSqrs65").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs65").src = "img/sqrs/blSqr.png"
};
};
function sqrsB66() {
    if(document.getElementById("imgSqrs66").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs66").src = "img/sqrs/blSqr.png"
};
};
function sqrsB67() {
    if(document.getElementById("imgSqrs67").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs67").src = "img/sqrs/blSqr.png"
};
};
function sqrsB68() {
    if(document.getElementById("imgSqrs68").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs68").src = "img/sqrs/blSqr.png"
};
};
function sqrsB69() {
    if(document.getElementById("imgSqrs69").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs69").src = "img/sqrs/blSqr.png"
};
};
function sqrsB70() {
    if(document.getElementById("imgSqrs70").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs70").src = "img/sqrs/blSqr.png"
};
};
function sqrsB71() {
    if(document.getElementById("imgSqrs71").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs71").src = "img/sqrs/blSqr.png"
};
};
function sqrsB72() {
    if(document.getElementById("imgSqrs72").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs72").src = "img/sqrs/blSqr.png"
};
};
function sqrsB73() {
    if(document.getElementById("imgSqrs73").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs73").src = "img/sqrs/blSqr.png"
};
};
function sqrsB74() {
    if(document.getElementById("imgSqrs74").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs74").src = "img/sqrs/blSqr.png"
};
};
function sqrsB75() {
    if(document.getElementById("imgSqrs75").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs75").src = "img/sqrs/blSqr.png"
};
};
function sqrsB76() {
    if(document.getElementById("imgSqrs76").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs76").src = "img/sqrs/blSqr.png"
};
};
function sqrsB77() {
    if(document.getElementById("imgSqrs77").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs77").src = "img/sqrs/blSqr.png"
};
};
function sqrsB78() {
    if(document.getElementById("imgSqrs78").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs78").src = "img/sqrs/blSqr.png"
};
};
function sqrsB79() {
    if(document.getElementById("imgSqrs79").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs79").src = "img/sqrs/blSqr.png"
};
};
function sqrsB80() {
    if(document.getElementById("imgSqrs80").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs80").src = "img/sqrs/blSqr.png"
};
};
function sqrsB81() {
    if(document.getElementById("imgSqrs81").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs81").src = "img/sqrs/blSqr.png"
};
};
function sqrsB82() {
    if(document.getElementById("imgSqrs82").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs82").src = "img/sqrs/blSqr.png"
};
};
function sqrsB83() {
    if(document.getElementById("imgSqrs83").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs83").src = "img/sqrs/blSqr.png"
};
};
function sqrsB84() {
    if(document.getElementById("imgSqrs84").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs84").src = "img/sqrs/blSqr.png"
};
};
function sqrsB85() {
    if(document.getElementById("imgSqrs85").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs85").src = "img/sqrs/blSqr.png"
};
};
function sqrsB86() {
    if(document.getElementById("imgSqrs86").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs86").src = "img/sqrs/blSqr.png"
};
};
function sqrsB87() {
    if(document.getElementById("imgSqrs87").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs87").src = "img/sqrs/blSqr.png"
};
};
function sqrsB88() {
    if(document.getElementById("imgSqrs88").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs88").src = "img/sqrs/blSqr.png"
};
};
function sqrsB89() {
    if(document.getElementById("imgSqrs89").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs89").src = "img/sqrs/blSqr.png"
};
};
function sqrsB90() {
    if(document.getElementById("imgSqrs90").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs90").src = "img/sqrs/blSqr.png"
};
};
function sqrsB91() {
    if(document.getElementById("imgSqrs91").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs91").src = "img/sqrs/blSqr.png"
};
};
function sqrsB92() {
    if(document.getElementById("imgSqrs92").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs92").src = "img/sqrs/blSqr.png"
};
};
function sqrsB93() {
    if(document.getElementById("imgSqrs93").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs93").src = "img/sqrs/blSqr.png"
};
};
function sqrsB94() {
    if(document.getElementById("imgSqrs94").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs94").src = "img/sqrs/blSqr.png"
};
};
function sqrsB95() {
    if(document.getElementById("imgSqrs95").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs95").src = "img/sqrs/blSqr.png"
};
};
function sqrsB96() {
    if(document.getElementById("imgSqrs96").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs96").src = "img/sqrs/blSqr.png"
};
};
function sqrsB97() {
    if(document.getElementById("imgSqrs97").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs97").src = "img/sqrs/blSqr.png"
};
};
function sqrsB98() {
    if(document.getElementById("imgSqrs98").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs98").src = "img/sqrs/blSqr.png"
};
};
function sqrsB99() {
    if(document.getElementById("imgSqrs99").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs99").src = "img/sqrs/blSqr.png"
};
};
function sqrsB100() {
    if(document.getElementById("imgSqrs100").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs100").src = "img/sqrs/blSqr.png"
};
};
function sqrsC101() {
    if(document.getElementById("imgSqrs101").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs101").src = "img/sqrs/blSqr.png"
};
};
function sqrsC102() {
    if(document.getElementById("imgSqrs102").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs102").src = "img/sqrs/blSqr.png"
};
};
function sqrsC103() {
    if(document.getElementById("imgSqrs103").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs103").src = "img/sqrs/blSqr.png"
};
};
function sqrsC104() {
    if(document.getElementById("imgSqrs104").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs104").src = "img/sqrs/blSqr.png"
};
};
function sqrsC105() {
    if(document.getElementById("imgSqrs105").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs105").src = "img/sqrs/blSqr.png"
};
};
function sqrsC106() {
    if(document.getElementById("imgSqrs106").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs106").src = "img/sqrs/blSqr.png"
};
};
function sqrsC107() {
    if(document.getElementById("imgSqrs107").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs107").src = "img/sqrs/blSqr.png"
};
};
function sqrsC108() {
    if(document.getElementById("imgSqrs108").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs108").src = "img/sqrs/blSqr.png"
};
};
function sqrsC109() {
    if(document.getElementById("imgSqrs109").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs109").src = "img/sqrs/blSqr.png"
};
};
function sqrsC110() {
    if(document.getElementById("imgSqrs110").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs110").src = "img/sqrs/blSqr.png"
};
};
function sqrsC111() {
    if(document.getElementById("imgSqrs111").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs111").src = "img/sqrs/blSqr.png"
};
};
function sqrsC112() {
    if(document.getElementById("imgSqrs112").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs112").src = "img/sqrs/blSqr.png"
};
};
function sqrsC113() {
    if(document.getElementById("imgSqrs113").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs113").src = "img/sqrs/blSqr.png"
};
};
function sqrsC114() {
    if(document.getElementById("imgSqrs114").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs114").src = "img/sqrs/blSqr.png"
};
};
function sqrsC115() {
    if(document.getElementById("imgSqrs115").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs115").src = "img/sqrs/blSqr.png"
};
};
function sqrsC116() {
    if(document.getElementById("imgSqrs116").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs116").src = "img/sqrs/blSqr.png"
};
};
function sqrsC117() {
    if(document.getElementById("imgSqrs117").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs117").src = "img/sqrs/blSqr.png"
};
};
function sqrsC118() {
    if(document.getElementById("imgSqrs118").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs118").src = "img/sqrs/blSqr.png"
};
};
function sqrsC119() {
    if(document.getElementById("imgSqrs119").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs119").src = "img/sqrs/blSqr.png"
};
};
function sqrsC120() {
    if(document.getElementById("imgSqrs120").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs120").src = "img/sqrs/blSqr.png"
};
};
function sqrsC121() {
    if(document.getElementById("imgSqrs121").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs121").src = "img/sqrs/blSqr.png"
};
};
function sqrsC122() {
    if(document.getElementById("imgSqrs122").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs122").src = "img/sqrs/blSqr.png"
};
};
function sqrsC123() {
    if(document.getElementById("imgSqrs123").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs123").src = "img/sqrs/blSqr.png"
};
};
function sqrsC124() {
    if(document.getElementById("imgSqrs124").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs124").src = "img/sqrs/blSqr.png"
};
};
function sqrsC125() {
    if(document.getElementById("imgSqrs125").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs125").src = "img/sqrs/blSqr.png"
};
};
function sqrsC126() {
    if(document.getElementById("imgSqrs126").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs126").src = "img/sqrs/blSqr.png"
};
};
function sqrsC127() {
    if(document.getElementById("imgSqrs127").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs127").src = "img/sqrs/blSqr.png"
};
};
function sqrsC128() {
    if(document.getElementById("imgSqrs128").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs128").src = "img/sqrs/blSqr.png"
};
};
function sqrsC129() {
    if(document.getElementById("imgSqrs129").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs129").src = "img/sqrs/blSqr.png"
};
};
function sqrsC130() {
    if(document.getElementById("imgSqrs130").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs130").src = "img/sqrs/blSqr.png"
};
};
function sqrsC131() {
    if(document.getElementById("imgSqrs131").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs131").src = "img/sqrs/blSqr.png"
};
};
function sqrsC132() {
    if(document.getElementById("imgSqrs132").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs132").src = "img/sqrs/blSqr.png"
};
};
function sqrsC133() {
    if(document.getElementById("imgSqrs133").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs133").src = "img/sqrs/blSqr.png"
};
};
function sqrsC134() {
    if(document.getElementById("imgSqrs134").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs134").src = "img/sqrs/blSqr.png"
};
};
function sqrsC135() {
    if(document.getElementById("imgSqrs135").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs135").src = "img/sqrs/blSqr.png"
};
};
function sqrsC136() {
    if(document.getElementById("imgSqrs136").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs136").src = "img/sqrs/blSqr.png"
};
};
function sqrsC137() {
    if(document.getElementById("imgSqrs137").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs137").src = "img/sqrs/blSqr.png"
};
};
function sqrsC138() {
    if(document.getElementById("imgSqrs138").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs138").src = "img/sqrs/blSqr.png"
};
};
function sqrsC139() {
    if(document.getElementById("imgSqrs139").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs139").src = "img/sqrs/blSqr.png"
};
};
function sqrsC140() {
    if(document.getElementById("imgSqrs140").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs140").src = "img/sqrs/blSqr.png"
};
};
function sqrsC141() {
    if(document.getElementById("imgSqrs141").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs141").src = "img/sqrs/blSqr.png"
};
};
function sqrsC142() {
    if(document.getElementById("imgSqrs142").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs142").src = "img/sqrs/blSqr.png"
};
};
function sqrsC143() {
    if(document.getElementById("imgSqrs143").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs143").src = "img/sqrs/blSqr.png"
};
};
function sqrsC144() {
    if(document.getElementById("imgSqrs144").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs144").src = "img/sqrs/blSqr.png"
};
};
function sqrsC145() {
    if(document.getElementById("imgSqrs145").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs145").src = "img/sqrs/blSqr.png"
};
};
function sqrsC146() {
    if(document.getElementById("imgSqrs146").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs146").src = "img/sqrs/blSqr.png"
};
};
function sqrsC147() {
    if(document.getElementById("imgSqrs147").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs147").src = "img/sqrs/blSqr.png"
};
};
function sqrsC148() {
    if(document.getElementById("imgSqrs148").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs148").src = "img/sqrs/blSqr.png"
};
};
function sqrsC149() {
    if(document.getElementById("imgSqrs149").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs149").src = "img/sqrs/blSqr.png"
};
};
function sqrsC150() {
    if(document.getElementById("imgSqrs150").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs150").src = "img/sqrs/blSqr.png"
};
};
function sqrsD151() {
    if(document.getElementById("imgSqrs151").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs151").src = "img/sqrs/blSqr.png"
};
};
function sqrsD152() {
    if(document.getElementById("imgSqrs152").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs152").src = "img/sqrs/blSqr.png"
};
};
function sqrsD153() {
    if(document.getElementById("imgSqrs153").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs153").src = "img/sqrs/blSqr.png"
};
};
function sqrsD154() {
    if(document.getElementById("imgSqrs154").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs154").src = "img/sqrs/blSqr.png"
};
};
function sqrsD155() {
    if(document.getElementById("imgSqrs155").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs155").src = "img/sqrs/blSqr.png"
};
};
function sqrsD156() {
    if(document.getElementById("imgSqrs156").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs156").src = "img/sqrs/blSqr.png"
};
};
function sqrsD157() {
    if(document.getElementById("imgSqrs157").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs157").src = "img/sqrs/blSqr.png"
};
};
function sqrsD158() {
    if(document.getElementById("imgSqrs158").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs158").src = "img/sqrs/blSqr.png"
};
};
function sqrsD159() {
    if(document.getElementById("imgSqrs159").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs159").src = "img/sqrs/blSqr.png"
};
};
function sqrsD160() {
    if(document.getElementById("imgSqrs160").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs160").src = "img/sqrs/blSqr.png"
};
};
function sqrsD161() {
    if(document.getElementById("imgSqrs161").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs161").src = "img/sqrs/blSqr.png"
};
};
function sqrsD162() {
    if(document.getElementById("imgSqrs162").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs162").src = "img/sqrs/blSqr.png"
};
};
function sqrsD163() {
    if(document.getElementById("imgSqrs163").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs163").src = "img/sqrs/blSqr.png"
};
};
function sqrsD164() {
    if(document.getElementById("imgSqrs164").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs164").src = "img/sqrs/blSqr.png"
};
};
function sqrsD165() {
    if(document.getElementById("imgSqrs165").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs165").src = "img/sqrs/blSqr.png"
};
};
function sqrsD166() {
    if(document.getElementById("imgSqrs166").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs166").src = "img/sqrs/blSqr.png"
};
};
function sqrsD167() {
    if(document.getElementById("imgSqrs167").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs167").src = "img/sqrs/blSqr.png"
};
};
function sqrsD168() {
    if(document.getElementById("imgSqrs168").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs168").src = "img/sqrs/blSqr.png"
};
};
function sqrsD169() {
    if(document.getElementById("imgSqrs169").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs169").src = "img/sqrs/blSqr.png"
};
};
function sqrsD170() {
    if(document.getElementById("imgSqrs170").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs170").src = "img/sqrs/blSqr.png"
};
};
function sqrsD171() {
    if(document.getElementById("imgSqrs171").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs171").src = "img/sqrs/blSqr.png"
};
};
function sqrsD172() {
    if(document.getElementById("imgSqrs172").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs172").src = "img/sqrs/blSqr.png"
};
};
function sqrsD173() {
    if(document.getElementById("imgSqrs173").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs173").src = "img/sqrs/blSqr.png"
};
};
function sqrsD174() {
    if(document.getElementById("imgSqrs174").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs174").src = "img/sqrs/blSqr.png"
};
};
function sqrsD175() {
    if(document.getElementById("imgSqrs175").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs175").src = "img/sqrs/blSqr.png"
};
};
function sqrsD176() {
    if(document.getElementById("imgSqrs176").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs176").src = "img/sqrs/blSqr.png"
};
};
function sqrsD177() {
    if(document.getElementById("imgSqrs177").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs177").src = "img/sqrs/blSqr.png"
};
};
function sqrsD178() {
    if(document.getElementById("imgSqrs178").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs178").src = "img/sqrs/blSqr.png"
};
};
function sqrsD179() {
    if(document.getElementById("imgSqrs179").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs179").src = "img/sqrs/blSqr.png"
};
};
function sqrsD180() {
    if(document.getElementById("imgSqrs180").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs180").src = "img/sqrs/blSqr.png"
};
};
function sqrsD181() {
    if(document.getElementById("imgSqrs181").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs181").src = "img/sqrs/blSqr.png"
};
};
function sqrsD182() {
    if(document.getElementById("imgSqrs182").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs182").src = "img/sqrs/blSqr.png"
};
};
function sqrsD183() {
    if(document.getElementById("imgSqrs183").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs183").src = "img/sqrs/blSqr.png"
};
};
function sqrsD184() {
    if(document.getElementById("imgSqrs184").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs184").src = "img/sqrs/blSqr.png"
};
};
function sqrsD185() {
    if(document.getElementById("imgSqrs185").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs185").src = "img/sqrs/blSqr.png"
};
};
function sqrsD186() {
    if(document.getElementById("imgSqrs186").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs186").src = "img/sqrs/blSqr.png"
};
};
function sqrsD187() {
    if(document.getElementById("imgSqrs187").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs187").src = "img/sqrs/blSqr.png"
};
};
function sqrsD188() {
    if(document.getElementById("imgSqrs188").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs188").src = "img/sqrs/blSqr.png"
};
};
function sqrsD189() {
    if(document.getElementById("imgSqrs189").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs189").src = "img/sqrs/blSqr.png"
};
};
function sqrsD190() {
    if(document.getElementById("imgSqrs190").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs190").src = "img/sqrs/blSqr.png"
};
};
function sqrsD191() {
    if(document.getElementById("imgSqrs191").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs191").src = "img/sqrs/blSqr.png"
};
};
function sqrsD192() {
    if(document.getElementById("imgSqrs192").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs192").src = "img/sqrs/blSqr.png"
};
};
function sqrsD193() {
    if(document.getElementById("imgSqrs193").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs193").src = "img/sqrs/blSqr.png"
};
};
function sqrsD194() {
    if(document.getElementById("imgSqrs194").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs194").src = "img/sqrs/blSqr.png"
};
};
function sqrsD195() {
    if(document.getElementById("imgSqrs195").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs195").src = "img/sqrs/blSqr.png"
};
};
function sqrsD196() {
    if(document.getElementById("imgSqrs196").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs196").src = "img/sqrs/blSqr.png"
};
};
function sqrsD197() {
    if(document.getElementById("imgSqrs197").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs197").src = "img/sqrs/blSqr.png"
};
};
function sqrsD198() {
    if(document.getElementById("imgSqrs198").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs198").src = "img/sqrs/blSqr.png"
};
};
function sqrsD199() {
    if(document.getElementById("imgSqrs199").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs199").src = "img/sqrs/blSqr.png"
};
};
function sqrsD200() {
    if(document.getElementById("imgSqrs200").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs200").src = "img/sqrs/blSqr.png"
};
};
function sqrsE201() {
    if(document.getElementById("imgSqrs201").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs201").src = "img/sqrs/blSqr.png"
};
};
function sqrsE202() {
    if(document.getElementById("imgSqrs202").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs202").src = "img/sqrs/blSqr.png"
};
};
function sqrsE203() {
    if(document.getElementById("imgSqrs203").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs203").src = "img/sqrs/blSqr.png"
};
};
function sqrsE204() {
    if(document.getElementById("imgSqrs204").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs204").src = "img/sqrs/blSqr.png"
};
};
function sqrsE205() {
    if(document.getElementById("imgSqrs205").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs205").src = "img/sqrs/blSqr.png"
};
};
function sqrsE206() {
    if(document.getElementById("imgSqrs206").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs206").src = "img/sqrs/blSqr.png"
};
};
function sqrsE207() {
    if(document.getElementById("imgSqrs207").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs207").src = "img/sqrs/blSqr.png"
};
};
function sqrsE208() {
    if(document.getElementById("imgSqrs208").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs208").src = "img/sqrs/blSqr.png"
};
};
function sqrsE209() {
    if(document.getElementById("imgSqrs209").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs209").src = "img/sqrs/blSqr.png"
};
};
function sqrsE210() {
    if(document.getElementById("imgSqrs210").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs210").src = "img/sqrs/blSqr.png"
};
};
function sqrsE211() {
    if(document.getElementById("imgSqrs211").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs211").src = "img/sqrs/blSqr.png"
};
};
function sqrsE212() {
    if(document.getElementById("imgSqrs212").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs212").src = "img/sqrs/blSqr.png"
};
};
function sqrsE213() {
    if(document.getElementById("imgSqrs213").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs213").src = "img/sqrs/blSqr.png"
};
};
function sqrsE214() {
    if(document.getElementById("imgSqrs214").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs214").src = "img/sqrs/blSqr.png"
};
};
function sqrsE215() {
    if(document.getElementById("imgSqrs215").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs215").src = "img/sqrs/blSqr.png"
};
};
function sqrsE216() {
    if(document.getElementById("imgSqrs216").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs216").src = "img/sqrs/blSqr.png"
};
};
function sqrsE217() {
    if(document.getElementById("imgSqrs217").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs217").src = "img/sqrs/blSqr.png"
};
};
function sqrsE218() {
    if(document.getElementById("imgSqrs218").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs218").src = "img/sqrs/blSqr.png"
};
};
function sqrsE219() {
    if(document.getElementById("imgSqrs219").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs219").src = "img/sqrs/blSqr.png"
};
};
function sqrsE220() {
    if(document.getElementById("imgSqrs220").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs220").src = "img/sqrs/blSqr.png"
};
};
function sqrsE221() {
    if(document.getElementById("imgSqrs221").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs221").src = "img/sqrs/blSqr.png"
};
};
function sqrsE222() {
    if(document.getElementById("imgSqrs222").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs222").src = "img/sqrs/blSqr.png"
};
};
function sqrsE223() {
    if(document.getElementById("imgSqrs223").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs223").src = "img/sqrs/blSqr.png"
};
};
function sqrsE224() {
    if(document.getElementById("imgSqrs224").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs224").src = "img/sqrs/blSqr.png"
};
};
function sqrsE225() {
    if(document.getElementById("imgSqrs225").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs225").src = "img/sqrs/blSqr.png"
};
};
function sqrsE226() {
    if(document.getElementById("imgSqrs226").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs226").src = "img/sqrs/blSqr.png"
};
};
function sqrsE227() {
    if(document.getElementById("imgSqrs227").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs227").src = "img/sqrs/blSqr.png"
};
};
function sqrsE228() {
    if(document.getElementById("imgSqrs228").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs228").src = "img/sqrs/blSqr.png"
};
};
function sqrsE229() {
    if(document.getElementById("imgSqrs229").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs229").src = "img/sqrs/blSqr.png"
};
};
function sqrsE230() {
    if(document.getElementById("imgSqrs230").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs230").src = "img/sqrs/blSqr.png"
};
};
function sqrsE231() {
    if(document.getElementById("imgSqrs231").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs231").src = "img/sqrs/blSqr.png"
};
};
function sqrsE232() {
    if(document.getElementById("imgSqrs232").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs232").src = "img/sqrs/blSqr.png"
};
};
function sqrsE233() {
    if(document.getElementById("imgSqrs233").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs233").src = "img/sqrs/blSqr.png"
};
};
function sqrsE234() {
    if(document.getElementById("imgSqrs234").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs234").src = "img/sqrs/blSqr.png"
};
};
function sqrsE235() {
    if(document.getElementById("imgSqrs235").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs235").src = "img/sqrs/blSqr.png"
};
};
function sqrsE236() {
    if(document.getElementById("imgSqrs236").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs236").src = "img/sqrs/blSqr.png"
};
};
function sqrsE237() {
    if(document.getElementById("imgSqrs237").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs237").src = "img/sqrs/blSqr.png"
};
};
function sqrsE238() {
    if(document.getElementById("imgSqrs238").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs238").src = "img/sqrs/blSqr.png"
};
};
function sqrsE239() {
    if(document.getElementById("imgSqrs239").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs239").src = "img/sqrs/blSqr.png"
};
};
function sqrsE240() {
    if(document.getElementById("imgSqrs240").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs240").src = "img/sqrs/blSqr.png"
};
};
function sqrsE241() {
    if(document.getElementById("imgSqrs241").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs241").src = "img/sqrs/blSqr.png"
};
};
function sqrsE242() {
    if(document.getElementById("imgSqrs242").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs242").src = "img/sqrs/blSqr.png"
};
};
function sqrsE243() {
    if(document.getElementById("imgSqrs243").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs243").src = "img/sqrs/blSqr.png"
};
};
function sqrsE244() {
    if(document.getElementById("imgSqrs244").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs244").src = "img/sqrs/blSqr.png"
};
};
function sqrsE245() {
    if(document.getElementById("imgSqrs245").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs245").src = "img/sqrs/blSqr.png"
};
};
function sqrsE246() {
    if(document.getElementById("imgSqrs246").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs246").src = "img/sqrs/blSqr.png"
};
};
function sqrsE247() {
    if(document.getElementById("imgSqrs247").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs247").src = "img/sqrs/blSqr.png"
};
};
function sqrsE248() {
    if(document.getElementById("imgSqrs248").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs248").src = "img/sqrs/blSqr.png"
};
};
function sqrsE249() {
    if(document.getElementById("imgSqrs249").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs249").src = "img/sqrs/blSqr.png"
};
};
function sqrsE250() {
    if(document.getElementById("imgSqrs250").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs250").src = "img/sqrs/blSqr.png"
};
};
function sqrsF251() {
    if(document.getElementById("imgSqrs251").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs251").src = "img/sqrs/blSqr.png"
};
};
function sqrsF252() {
    if(document.getElementById("imgSqrs252").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs252").src = "img/sqrs/blSqr.png"
};
};
function sqrsF253() {
    if(document.getElementById("imgSqrs253").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs253").src = "img/sqrs/blSqr.png"
};
};
function sqrsF254() {
    if(document.getElementById("imgSqrs254").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs254").src = "img/sqrs/blSqr.png"
};
};
function sqrsF255() {
    if(document.getElementById("imgSqrs255").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs255").src = "img/sqrs/blSqr.png"
};
};
function sqrsF256() {
    if(document.getElementById("imgSqrs256").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs256").src = "img/sqrs/blSqr.png"
};
};
function sqrsF257() {
    if(document.getElementById("imgSqrs257").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs257").src = "img/sqrs/blSqr.png"
};
};
function sqrsF258() {
    if(document.getElementById("imgSqrs258").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs258").src = "img/sqrs/blSqr.png"
};
};
function sqrsF259() {
    if(document.getElementById("imgSqrs259").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs259").src = "img/sqrs/blSqr.png"
};
};
function sqrsF260() {
    if(document.getElementById("imgSqrs260").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs260").src = "img/sqrs/blSqr.png"
};
};
function sqrsF261() {
    if(document.getElementById("imgSqrs261").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs261").src = "img/sqrs/blSqr.png"
};
};
function sqrsF262() {
    if(document.getElementById("imgSqrs262").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs262").src = "img/sqrs/blSqr.png"
};
};
function sqrsF263() {
    if(document.getElementById("imgSqrs263").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs263").src = "img/sqrs/blSqr.png"
};
};
function sqrsF264() {
    if(document.getElementById("imgSqrs264").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs264").src = "img/sqrs/blSqr.png"
};
};
function sqrsF265() {
    if(document.getElementById("imgSqrs265").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs265").src = "img/sqrs/blSqr.png"
};
};
function sqrsF266() {
    if(document.getElementById("imgSqrs266").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs266").src = "img/sqrs/blSqr.png"
};
};
function sqrsF267() {
    if(document.getElementById("imgSqrs267").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs267").src = "img/sqrs/blSqr.png"
};
};
function sqrsF268() {
    if(document.getElementById("imgSqrs268").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs268").src = "img/sqrs/blSqr.png"
};
};
function sqrsF269() {
    if(document.getElementById("imgSqrs269").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs269").src = "img/sqrs/blSqr.png"
};
};
function sqrsF270() {
    if(document.getElementById("imgSqrs270").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs270").src = "img/sqrs/blSqr.png"
};
};
function sqrsF271() {
    if(document.getElementById("imgSqrs271").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs271").src = "img/sqrs/blSqr.png"
};
};
function sqrsF272() {
    if(document.getElementById("imgSqrs272").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs272").src = "img/sqrs/blSqr.png"
};
};
function sqrsF273() {
    if(document.getElementById("imgSqrs273").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs273").src = "img/sqrs/blSqr.png"
};
};
function sqrsF274() {
    if(document.getElementById("imgSqrs274").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs274").src = "img/sqrs/blSqr.png"
};
};
function sqrsF275() {
    if(document.getElementById("imgSqrs275").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs275").src = "img/sqrs/blSqr.png"
};
};
function sqrsF276() {
    if(document.getElementById("imgSqrs276").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs276").src = "img/sqrs/blSqr.png"
};
};
function sqrsF277() {
    if(document.getElementById("imgSqrs277").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs277").src = "img/sqrs/blSqr.png"
};
};
function sqrsF278() {
    if(document.getElementById("imgSqrs278").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs278").src = "img/sqrs/blSqr.png"
};
};
function sqrsF279() {
    if(document.getElementById("imgSqrs279").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs279").src = "img/sqrs/blSqr.png"
};
};
function sqrsF280() {
    if(document.getElementById("imgSqrs280").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs280").src = "img/sqrs/blSqr.png"
};
};
function sqrsF281() {
    if(document.getElementById("imgSqrs281").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs281").src = "img/sqrs/blSqr.png"
};
};
function sqrsF282() {
    if(document.getElementById("imgSqrs282").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs282").src = "img/sqrs/blSqr.png"
};
};
function sqrsF283() {
    if(document.getElementById("imgSqrs283").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs283").src = "img/sqrs/blSqr.png"
};
};
function sqrsF284() {
    if(document.getElementById("imgSqrs284").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs284").src = "img/sqrs/blSqr.png"
};
};
function sqrsF285() {
    if(document.getElementById("imgSqrs285").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs285").src = "img/sqrs/blSqr.png"
};
};
function sqrsF286() {
    if(document.getElementById("imgSqrs286").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs286").src = "img/sqrs/blSqr.png"
};
};
function sqrsF287() {
    if(document.getElementById("imgSqrs287").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs287").src = "img/sqrs/blSqr.png"
};
};
function sqrsF288() {
    if(document.getElementById("imgSqrs288").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs288").src = "img/sqrs/blSqr.png"
};
};
function sqrsF289() {
    if(document.getElementById("imgSqrs289").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs289").src = "img/sqrs/blSqr.png"
};
};
function sqrsF290() {
    if(document.getElementById("imgSqrs290").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs290").src = "img/sqrs/blSqr.png"
};
};
function sqrsF291() {
    if(document.getElementById("imgSqrs291").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs291").src = "img/sqrs/blSqr.png"
};
};
function sqrsF292() {
    if(document.getElementById("imgSqrs292").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs292").src = "img/sqrs/blSqr.png"
};
};
function sqrsF293() {
    if(document.getElementById("imgSqrs293").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs293").src = "img/sqrs/blSqr.png"
};
};
function sqrsF294() {
    if(document.getElementById("imgSqrs294").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs294").src = "img/sqrs/blSqr.png"
};
};
function sqrsF295() {
    if(document.getElementById("imgSqrs295").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs295").src = "img/sqrs/blSqr.png"
};
};
function sqrsF296() {
    if(document.getElementById("imgSqrs296").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs296").src = "img/sqrs/blSqr.png"
};
};
function sqrsF297() {
    if(document.getElementById("imgSqrs297").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs297").src = "img/sqrs/blSqr.png"
};
};
function sqrsF298() {
    if(document.getElementById("imgSqrs298").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs298").src = "img/sqrs/blSqr.png"
};
};
function sqrsF299() {
    if(document.getElementById("imgSqrs299").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs299").src = "img/sqrs/blSqr.png"
};
};
function sqrsF300() {
    if(document.getElementById("imgSqrs300").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs300").src = "img/sqrs/blSqr.png"
};
};
function sqrsG301() {
    if(document.getElementById("imgSqrs301").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs301").src = "img/sqrs/blSqr.png"
};
};
function sqrsG302() {
    if(document.getElementById("imgSqrs302").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs302").src = "img/sqrs/blSqr.png"
};
};
function sqrsG303() {
    if(document.getElementById("imgSqrs303").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs303").src = "img/sqrs/blSqr.png"
};
};
function sqrsG304() {
    if(document.getElementById("imgSqrs304").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs304").src = "img/sqrs/blSqr.png"
};
};
function sqrsG305() {
    if(document.getElementById("imgSqrs305").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs305").src = "img/sqrs/blSqr.png"
};
};
function sqrsG306() {
    if(document.getElementById("imgSqrs306").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs306").src = "img/sqrs/blSqr.png"
};
};
function sqrsG307() {
    if(document.getElementById("imgSqrs307").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs307").src = "img/sqrs/blSqr.png"
};
};
function sqrsG308() {
    if(document.getElementById("imgSqrs308").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs308").src = "img/sqrs/blSqr.png"
};
};
function sqrsG309() {
    if(document.getElementById("imgSqrs309").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs309").src = "img/sqrs/blSqr.png"
};
};
function sqrsG310() {
    if(document.getElementById("imgSqrs310").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs310").src = "img/sqrs/blSqr.png"
};
};
function sqrsG311() {
    if(document.getElementById("imgSqrs311").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs311").src = "img/sqrs/blSqr.png"
};
};
function sqrsG312() {
    if(document.getElementById("imgSqrs312").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs312").src = "img/sqrs/blSqr.png"
};
};
function sqrsG313() {
    if(document.getElementById("imgSqrs313").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs313").src = "img/sqrs/blSqr.png"
};
};
function sqrsG314() {
    if(document.getElementById("imgSqrs314").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs314").src = "img/sqrs/blSqr.png"
};
};
function sqrsG315() {
    if(document.getElementById("imgSqrs315").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs315").src = "img/sqrs/blSqr.png"
};
};
function sqrsG316() {
    if(document.getElementById("imgSqrs316").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs316").src = "img/sqrs/blSqr.png"
};
};
function sqrsG317() {
    if(document.getElementById("imgSqrs317").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs317").src = "img/sqrs/blSqr.png"
};
};
function sqrsG318() {
    if(document.getElementById("imgSqrs318").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs318").src = "img/sqrs/blSqr.png"
};
};
function sqrsG319() {
    if(document.getElementById("imgSqrs319").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs319").src = "img/sqrs/blSqr.png"
};
};
function sqrsG320() {
    if(document.getElementById("imgSqrs320").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs320").src = "img/sqrs/blSqr.png"
};
};
function sqrsG321() {
    if(document.getElementById("imgSqrs321").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs321").src = "img/sqrs/blSqr.png"
};
};
function sqrsG322() {
    if(document.getElementById("imgSqrs322").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs322").src = "img/sqrs/blSqr.png"
};
};
function sqrsG323() {
    if(document.getElementById("imgSqrs323").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs323").src = "img/sqrs/blSqr.png"
};
};
function sqrsG324() {
    if(document.getElementById("imgSqrs324").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs324").src = "img/sqrs/blSqr.png"
};
};
function sqrsG325() {
    if(document.getElementById("imgSqrs325").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs325").src = "img/sqrs/blSqr.png"
};
};
function sqrsG326() {
    if(document.getElementById("imgSqrs326").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs326").src = "img/sqrs/blSqr.png"
};
};
function sqrsG327() {
    if(document.getElementById("imgSqrs327").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs327").src = "img/sqrs/blSqr.png"
};
};
function sqrsG328() {
    if(document.getElementById("imgSqrs328").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs328").src = "img/sqrs/blSqr.png"
};
};
function sqrsG329() {
    if(document.getElementById("imgSqrs329").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs329").src = "img/sqrs/blSqr.png"
};
};
function sqrsG330() {
    if(document.getElementById("imgSqrs330").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs330").src = "img/sqrs/blSqr.png"
};
};
function sqrsG331() {
    if(document.getElementById("imgSqrs331").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs331").src = "img/sqrs/blSqr.png"
};
};
function sqrsG332() {
    if(document.getElementById("imgSqrs332").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs332").src = "img/sqrs/blSqr.png"
};
};
function sqrsG333() {
    if(document.getElementById("imgSqrs333").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs333").src = "img/sqrs/blSqr.png"
};
};
function sqrsG334() {
    if(document.getElementById("imgSqrs334").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs334").src = "img/sqrs/blSqr.png"
};
};
function sqrsG335() {
    if(document.getElementById("imgSqrs335").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs335").src = "img/sqrs/blSqr.png"
};
};
function sqrsG336() {
    if(document.getElementById("imgSqrs336").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs336").src = "img/sqrs/blSqr.png"
};
};
function sqrsG337() {
    if(document.getElementById("imgSqrs337").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs337").src = "img/sqrs/blSqr.png"
};
};
function sqrsG338() {
    if(document.getElementById("imgSqrs338").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs338").src = "img/sqrs/blSqr.png"
};
};
function sqrsG339() {
    if(document.getElementById("imgSqrs339").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs339").src = "img/sqrs/blSqr.png"
};
};
function sqrsG340() {
    if(document.getElementById("imgSqrs340").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs340").src = "img/sqrs/blSqr.png"
};
};
function sqrsG341() {
    if(document.getElementById("imgSqrs341").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs341").src = "img/sqrs/blSqr.png"
};
};
function sqrsG342() {
    if(document.getElementById("imgSqrs342").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs342").src = "img/sqrs/blSqr.png"
};
};
function sqrsG343() {
    if(document.getElementById("imgSqrs343").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs343").src = "img/sqrs/blSqr.png"
};
};
function sqrsG344() {
    if(document.getElementById("imgSqrs344").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs344").src = "img/sqrs/blSqr.png"
};
};
function sqrsG345() {
    if(document.getElementById("imgSqrs345").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs345").src = "img/sqrs/blSqr.png"
};
};
function sqrsG346() {
    if(document.getElementById("imgSqrs346").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs346").src = "img/sqrs/blSqr.png"
};
};
function sqrsG347() {
    if(document.getElementById("imgSqrs347").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs347").src = "img/sqrs/blSqr.png"
};
};
function sqrsG348() {
    if(document.getElementById("imgSqrs348").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs348").src = "img/sqrs/blSqr.png"
};
};
function sqrsG349() {
    if(document.getElementById("imgSqrs349").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs349").src = "img/sqrs/blSqr.png"
};
};
function sqrsG350() {
    if(document.getElementById("imgSqrs350").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs350").src = "img/sqrs/blSqr.png"
};
};
function sqrsH351() {
    if(document.getElementById("imgSqrs351").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs351").src = "img/sqrs/blSqr.png"
};
};
function sqrsH352() {
    if(document.getElementById("imgSqrs352").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs352").src = "img/sqrs/blSqr.png"
};
};
function sqrsH353() {
    if(document.getElementById("imgSqrs353").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs353").src = "img/sqrs/blSqr.png"
};
};
function sqrsH354() {
    if(document.getElementById("imgSqrs354").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs354").src = "img/sqrs/blSqr.png"
};
};
function sqrsH355() {
    if(document.getElementById("imgSqrs355").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs355").src = "img/sqrs/blSqr.png"
};
};
function sqrsH356() {
    if(document.getElementById("imgSqrs356").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs356").src = "img/sqrs/blSqr.png"
};
};
function sqrsH357() {
    if(document.getElementById("imgSqrs357").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs357").src = "img/sqrs/blSqr.png"
};
};
function sqrsH358() {
    if(document.getElementById("imgSqrs358").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs358").src = "img/sqrs/blSqr.png"
};
};
function sqrsH359() {
    if(document.getElementById("imgSqrs359").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs359").src = "img/sqrs/blSqr.png"
};
};
function sqrsH360() {
    if(document.getElementById("imgSqrs360").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs360").src = "img/sqrs/blSqr.png"
};
};
function sqrsH361() {
    if(document.getElementById("imgSqrs361").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs361").src = "img/sqrs/blSqr.png"
};
};
function sqrsH362() {
    if(document.getElementById("imgSqrs362").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs362").src = "img/sqrs/blSqr.png"
};
};
function sqrsH363() {
    if(document.getElementById("imgSqrs363").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs363").src = "img/sqrs/blSqr.png"
};
};
function sqrsH364() {
    if(document.getElementById("imgSqrs364").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs364").src = "img/sqrs/blSqr.png"
};
};
function sqrsH365() {
    if(document.getElementById("imgSqrs365").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs365").src = "img/sqrs/blSqr.png"
};
};
function sqrsH366() {
    if(document.getElementById("imgSqrs366").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs366").src = "img/sqrs/blSqr.png"
};
};
function sqrsH367() {
    if(document.getElementById("imgSqrs367").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs367").src = "img/sqrs/blSqr.png"
};
};
function sqrsH368() {
    if(document.getElementById("imgSqrs368").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs368").src = "img/sqrs/blSqr.png"
};
};
function sqrsH369() {
    if(document.getElementById("imgSqrs369").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs369").src = "img/sqrs/blSqr.png"
};
};
function sqrsH370() {
    if(document.getElementById("imgSqrs370").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs370").src = "img/sqrs/blSqr.png"
};
};
function sqrsH371() {
    if(document.getElementById("imgSqrs371").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs371").src = "img/sqrs/blSqr.png"
};
};
function sqrsH372() {
    if(document.getElementById("imgSqrs372").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs372").src = "img/sqrs/blSqr.png"
};
};
function sqrsH373() {
    if(document.getElementById("imgSqrs373").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs373").src = "img/sqrs/blSqr.png"
};
};
function sqrsH374() {
    if(document.getElementById("imgSqrs374").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs374").src = "img/sqrs/blSqr.png"
};
};
function sqrsH375() {
    if(document.getElementById("imgSqrs375").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs375").src = "img/sqrs/blSqr.png"
};
};
function sqrsH376() {
    if(document.getElementById("imgSqrs376").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs376").src = "img/sqrs/blSqr.png"
};
};
function sqrsH377() {
    if(document.getElementById("imgSqrs377").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs377").src = "img/sqrs/blSqr.png"
};
};
function sqrsH378() {
    if(document.getElementById("imgSqrs378").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs378").src = "img/sqrs/blSqr.png"
};
};
function sqrsH379() {
    if(document.getElementById("imgSqrs379").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs379").src = "img/sqrs/blSqr.png"
};
};
function sqrsH380() {
    if(document.getElementById("imgSqrs380").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs380").src = "img/sqrs/blSqr.png"
};
};
function sqrsH381() {
    if(document.getElementById("imgSqrs381").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs381").src = "img/sqrs/blSqr.png"
};
};
function sqrsH382() {
    if(document.getElementById("imgSqrs382").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs382").src = "img/sqrs/blSqr.png"
};
};
function sqrsH383() {
    if(document.getElementById("imgSqrs383").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs383").src = "img/sqrs/blSqr.png"
};
};
function sqrsH384() {
    if(document.getElementById("imgSqrs384").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs384").src = "img/sqrs/blSqr.png"
};
};
function sqrsH385() {
    if(document.getElementById("imgSqrs385").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs385").src = "img/sqrs/blSqr.png"
};
};
function sqrsH386() {
    if(document.getElementById("imgSqrs386").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs386").src = "img/sqrs/blSqr.png"
};
};
function sqrsH387() {
    if(document.getElementById("imgSqrs387").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs387").src = "img/sqrs/blSqr.png"
};
};
function sqrsH388() {
    if(document.getElementById("imgSqrs388").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs388").src = "img/sqrs/blSqr.png"
};
};
function sqrsH389() {
    if(document.getElementById("imgSqrs389").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs389").src = "img/sqrs/blSqr.png"
};
};
function sqrsH390() {
    if(document.getElementById("imgSqrs390").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs390").src = "img/sqrs/blSqr.png"
};
};
function sqrsH391() {
    if(document.getElementById("imgSqrs391").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs391").src = "img/sqrs/blSqr.png"
};
};
function sqrsH392() {
    if(document.getElementById("imgSqrs392").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs392").src = "img/sqrs/blSqr.png"
};
};
function sqrsH393() {
    if(document.getElementById("imgSqrs393").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs393").src = "img/sqrs/blSqr.png"
};
};
function sqrsH394() {
    if(document.getElementById("imgSqrs394").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs394").src = "img/sqrs/blSqr.png"
};
};
function sqrsH395() {
    if(document.getElementById("imgSqrs395").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs395").src = "img/sqrs/blSqr.png"
};
};
function sqrsH396() {
    if(document.getElementById("imgSqrs396").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs396").src = "img/sqrs/blSqr.png"
};
};
function sqrsH397() {
    if(document.getElementById("imgSqrs397").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs397").src = "img/sqrs/blSqr.png"
};
};
function sqrsH398() {
    if(document.getElementById("imgSqrs398").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs398").src = "img/sqrs/blSqr.png"
};
};
function sqrsH399() {
    if(document.getElementById("imgSqrs399").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs399").src = "img/sqrs/blSqr.png"
};
};
function sqrsH400() {
    if(document.getElementById("imgSqrs400").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs400").src = "img/sqrs/blSqr.png"
};
};
function sqrsI401() {
    if(document.getElementById("imgSqrs401").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs401").src = "img/sqrs/blSqr.png"
};
};
function sqrsI402() {
    if(document.getElementById("imgSqrs402").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs402").src = "img/sqrs/blSqr.png"
};
};
function sqrsI403() {
    if(document.getElementById("imgSqrs403").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs403").src = "img/sqrs/blSqr.png"
};
};
function sqrsI404() {
    if(document.getElementById("imgSqrs404").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs404").src = "img/sqrs/blSqr.png"
};
};
function sqrsI405() {
    if(document.getElementById("imgSqrs405").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs405").src = "img/sqrs/blSqr.png"
};
};
function sqrsI406() {
    if(document.getElementById("imgSqrs406").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs406").src = "img/sqrs/blSqr.png"
};
};
function sqrsI407() {
    if(document.getElementById("imgSqrs407").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs407").src = "img/sqrs/blSqr.png"
};
};
function sqrsI408() {
    if(document.getElementById("imgSqrs408").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs408").src = "img/sqrs/blSqr.png"
};
};
function sqrsI409() {
    if(document.getElementById("imgSqrs409").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs409").src = "img/sqrs/blSqr.png"
};
};
function sqrsI410() {
    if(document.getElementById("imgSqrs410").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs410").src = "img/sqrs/blSqr.png"
};
};
function sqrsI411() {
    if(document.getElementById("imgSqrs411").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs411").src = "img/sqrs/blSqr.png"
};
};
function sqrsI412() {
    if(document.getElementById("imgSqrs412").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs412").src = "img/sqrs/blSqr.png"
};
};
function sqrsI413() {
    if(document.getElementById("imgSqrs413").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs413").src = "img/sqrs/blSqr.png"
};
};
function sqrsI414() {
    if(document.getElementById("imgSqrs414").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs414").src = "img/sqrs/blSqr.png"
};
};
function sqrsI415() {
    if(document.getElementById("imgSqrs415").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs415").src = "img/sqrs/blSqr.png"
};
};
function sqrsI416() {
    if(document.getElementById("imgSqrs416").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs416").src = "img/sqrs/blSqr.png"
};
};
function sqrsI417() {
    if(document.getElementById("imgSqrs417").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs417").src = "img/sqrs/blSqr.png"
};
};
function sqrsI418() {
    if(document.getElementById("imgSqrs418").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs418").src = "img/sqrs/blSqr.png"
};
};
function sqrsI419() {
    if(document.getElementById("imgSqrs419").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs419").src = "img/sqrs/blSqr.png"
};
};
function sqrsI420() {
    if(document.getElementById("imgSqrs420").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs420").src = "img/sqrs/blSqr.png"
};
};
function sqrsI421() {
    if(document.getElementById("imgSqrs421").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs421").src = "img/sqrs/blSqr.png"
};
};
function sqrsI422() {
    if(document.getElementById("imgSqrs422").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs422").src = "img/sqrs/blSqr.png"
};
};
function sqrsI423() {
    if(document.getElementById("imgSqrs423").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs423").src = "img/sqrs/blSqr.png"
};
};
function sqrsI424() {
    if(document.getElementById("imgSqrs424").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs424").src = "img/sqrs/blSqr.png"
};
};
function sqrsI425() {
    if(document.getElementById("imgSqrs425").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs425").src = "img/sqrs/blSqr.png"
};
};
function sqrsI426() {
    if(document.getElementById("imgSqrs426").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs426").src = "img/sqrs/blSqr.png"
};
};
function sqrsI427() {
    if(document.getElementById("imgSqrs427").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs427").src = "img/sqrs/blSqr.png"
};
};
function sqrsI428() {
    if(document.getElementById("imgSqrs428").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs428").src = "img/sqrs/blSqr.png"
};
};
function sqrsI429() {
    if(document.getElementById("imgSqrs429").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs429").src = "img/sqrs/blSqr.png"
};
};
function sqrsI430() {
    if(document.getElementById("imgSqrs430").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs430").src = "img/sqrs/blSqr.png"
};
};
function sqrsI431() {
    if(document.getElementById("imgSqrs431").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs431").src = "img/sqrs/blSqr.png"
};
};
function sqrsI432() {
    if(document.getElementById("imgSqrs432").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs432").src = "img/sqrs/blSqr.png"
};
};
function sqrsI433() {
    if(document.getElementById("imgSqrs433").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs433").src = "img/sqrs/blSqr.png"
};
};
function sqrsI434() {
    if(document.getElementById("imgSqrs434").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs434").src = "img/sqrs/blSqr.png"
};
};
function sqrsI435() {
    if(document.getElementById("imgSqrs435").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs435").src = "img/sqrs/blSqr.png"
};
};
function sqrsI436() {
    if(document.getElementById("imgSqrs436").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs436").src = "img/sqrs/blSqr.png"
};
};
function sqrsI437() {
    if(document.getElementById("imgSqrs437").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs437").src = "img/sqrs/blSqr.png"
};
};
function sqrsI438() {
    if(document.getElementById("imgSqrs438").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs438").src = "img/sqrs/blSqr.png"
};
};
function sqrsI439() {
    if(document.getElementById("imgSqrs439").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs439").src = "img/sqrs/blSqr.png"
};
};
function sqrsI440() {
    if(document.getElementById("imgSqrs440").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs440").src = "img/sqrs/blSqr.png"
};
};
function sqrsI441() {
    if(document.getElementById("imgSqrs441").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs441").src = "img/sqrs/blSqr.png"
};
};
function sqrsI442() {
    if(document.getElementById("imgSqrs442").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs442").src = "img/sqrs/blSqr.png"
};
};
function sqrsI443() {
    if(document.getElementById("imgSqrs443").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs443").src = "img/sqrs/blSqr.png"
};
};
function sqrsI444() {
    if(document.getElementById("imgSqrs444").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs444").src = "img/sqrs/blSqr.png"
};
};
function sqrsI445() {
    if(document.getElementById("imgSqrs445").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs445").src = "img/sqrs/blSqr.png"
};
};
function sqrsI446() {
    if(document.getElementById("imgSqrs446").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs446").src = "img/sqrs/blSqr.png"
};
};
function sqrsI447() {
    if(document.getElementById("imgSqrs447").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs447").src = "img/sqrs/blSqr.png"
};
};
function sqrsI448() {
    if(document.getElementById("imgSqrs448").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs448").src = "img/sqrs/blSqr.png"
};
};
function sqrsI449() {
    if(document.getElementById("imgSqrs449").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs449").src = "img/sqrs/blSqr.png"
};
};
function sqrsI450() {
    if(document.getElementById("imgSqrs450").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs450").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ451() {
    if(document.getElementById("imgSqrs451").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs451").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ452() {
    if(document.getElementById("imgSqrs452").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs452").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ453() {
    if(document.getElementById("imgSqrs453").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs453").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ454() {
    if(document.getElementById("imgSqrs454").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs454").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ455() {
    if(document.getElementById("imgSqrs455").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs455").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ456() {
    if(document.getElementById("imgSqrs456").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs456").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ457() {
    if(document.getElementById("imgSqrs457").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs457").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ458() {
    if(document.getElementById("imgSqrs458").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs458").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ459() {
    if(document.getElementById("imgSqrs459").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs459").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ460() {
    if(document.getElementById("imgSqrs460").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs460").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ461() {
    if(document.getElementById("imgSqrs461").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs461").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ462() {
    if(document.getElementById("imgSqrs462").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs462").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ463() {
    if(document.getElementById("imgSqrs463").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs463").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ464() {
    if(document.getElementById("imgSqrs464").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs464").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ465() {
    if(document.getElementById("imgSqrs465").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs465").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ466() {
    if(document.getElementById("imgSqrs466").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs466").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ467() {
    if(document.getElementById("imgSqrs467").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs467").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ468() {
    if(document.getElementById("imgSqrs468").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs468").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ469() {
    if(document.getElementById("imgSqrs469").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs469").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ470() {
    if(document.getElementById("imgSqrs470").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs470").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ471() {
    if(document.getElementById("imgSqrs471").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs471").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ472() {
    if(document.getElementById("imgSqrs472").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs472").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ473() {
    if(document.getElementById("imgSqrs473").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs473").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ474() {
    if(document.getElementById("imgSqrs474").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs474").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ475() {
    if(document.getElementById("imgSqrs475").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs475").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ476() {
    if(document.getElementById("imgSqrs476").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs476").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ477() {
    if(document.getElementById("imgSqrs477").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs477").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ478() {
    if(document.getElementById("imgSqrs478").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs478").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ479() {
    if(document.getElementById("imgSqrs479").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs479").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ480() {
    if(document.getElementById("imgSqrs480").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs480").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ481() {
    if(document.getElementById("imgSqrs481").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs481").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ482() {
    if(document.getElementById("imgSqrs482").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs482").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ483() {
    if(document.getElementById("imgSqrs483").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs483").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ484() {
    if(document.getElementById("imgSqrs484").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs484").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ485() {
    if(document.getElementById("imgSqrs485").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs485").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ486() {
    if(document.getElementById("imgSqrs486").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs486").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ487() {
    if(document.getElementById("imgSqrs487").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs487").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ488() {
    if(document.getElementById("imgSqrs488").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs488").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ489() {
    if(document.getElementById("imgSqrs489").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs489").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ490() {
    if(document.getElementById("imgSqrs490").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs490").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ491() {
    if(document.getElementById("imgSqrs491").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs491").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ492() {
    if(document.getElementById("imgSqrs492").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs492").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ493() {
    if(document.getElementById("imgSqrs493").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs493").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ494() {
    if(document.getElementById("imgSqrs494").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs494").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ495() {
    if(document.getElementById("imgSqrs495").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs495").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ496() {
    if(document.getElementById("imgSqrs496").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs496").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ497() {
    if(document.getElementById("imgSqrs497").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs497").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ498() {
    if(document.getElementById("imgSqrs498").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs498").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ499() {
    if(document.getElementById("imgSqrs499").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs499").src = "img/sqrs/blSqr.png"
};
};
function sqrsJ500() {
    if(document.getElementById("imgSqrs500").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs500").src = "img/sqrs/blSqr.png"
};
};
function sqrsK501() {
    if(document.getElementById("imgSqrs501").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs501").src = "img/sqrs/blSqr.png"
};
};
function sqrsK502() {
    if(document.getElementById("imgSqrs502").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs502").src = "img/sqrs/blSqr.png"
};
};
function sqrsK503() {
    if(document.getElementById("imgSqrs503").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs503").src = "img/sqrs/blSqr.png"
};
};
function sqrsK504() {
    if(document.getElementById("imgSqrs504").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs504").src = "img/sqrs/blSqr.png"
};
};
function sqrsK505() {
    if(document.getElementById("imgSqrs505").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs505").src = "img/sqrs/blSqr.png"
};
};
function sqrsK506() {
    if(document.getElementById("imgSqrs506").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs506").src = "img/sqrs/blSqr.png"
};
};
function sqrsK507() {
    if(document.getElementById("imgSqrs507").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs507").src = "img/sqrs/blSqr.png"
};
};
function sqrsK508() {
    if(document.getElementById("imgSqrs508").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs508").src = "img/sqrs/blSqr.png"
};
};
function sqrsK509() {
    if(document.getElementById("imgSqrs509").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs509").src = "img/sqrs/blSqr.png"
};
};
function sqrsK510() {
    if(document.getElementById("imgSqrs510").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs510").src = "img/sqrs/blSqr.png"
};
};
function sqrsK511() {
    if(document.getElementById("imgSqrs511").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs511").src = "img/sqrs/blSqr.png"
};
};
function sqrsK512() {
    if(document.getElementById("imgSqrs512").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs512").src = "img/sqrs/blSqr.png"
};
};
function sqrsK513() {
    if(document.getElementById("imgSqrs513").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs513").src = "img/sqrs/blSqr.png"
};
};
function sqrsK514() {
    if(document.getElementById("imgSqrs514").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs514").src = "img/sqrs/blSqr.png"
};
};
function sqrsK515() {
    if(document.getElementById("imgSqrs515").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs515").src = "img/sqrs/blSqr.png"
};
};
function sqrsK516() {
    if(document.getElementById("imgSqrs516").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs516").src = "img/sqrs/blSqr.png"
};
};
function sqrsK517() {
    if(document.getElementById("imgSqrs517").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs517").src = "img/sqrs/blSqr.png"
};
};
function sqrsK518() {
    if(document.getElementById("imgSqrs518").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs518").src = "img/sqrs/blSqr.png"
};
};
function sqrsK519() {
    if(document.getElementById("imgSqrs519").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs519").src = "img/sqrs/blSqr.png"
};
};
function sqrsK520() {
    if(document.getElementById("imgSqrs520").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs520").src = "img/sqrs/blSqr.png"
};
};
function sqrsK521() {
    if(document.getElementById("imgSqrs521").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs521").src = "img/sqrs/blSqr.png"
};
};
function sqrsK522() {
    if(document.getElementById("imgSqrs522").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs522").src = "img/sqrs/blSqr.png"
};
};
function sqrsK523() {
    if(document.getElementById("imgSqrs523").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs523").src = "img/sqrs/blSqr.png"
};
};
function sqrsK524() {
    if(document.getElementById("imgSqrs524").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs524").src = "img/sqrs/blSqr.png"
};
};
function sqrsK525() {
    if(document.getElementById("imgSqrs525").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs525").src = "img/sqrs/blSqr.png"
};
};
function sqrsK526() {
    if(document.getElementById("imgSqrs526").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs526").src = "img/sqrs/blSqr.png"
};
};
function sqrsK527() {
    if(document.getElementById("imgSqrs527").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs527").src = "img/sqrs/blSqr.png"
};
};
function sqrsK528() {
    if(document.getElementById("imgSqrs528").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs528").src = "img/sqrs/blSqr.png"
};
};
function sqrsK529() {
    if(document.getElementById("imgSqrs529").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs529").src = "img/sqrs/blSqr.png"
};
};
function sqrsK530() {
    if(document.getElementById("imgSqrs530").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs530").src = "img/sqrs/blSqr.png"
};
};
function sqrsK531() {
    if(document.getElementById("imgSqrs531").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs531").src = "img/sqrs/blSqr.png"
};
};
function sqrsK532() {
    if(document.getElementById("imgSqrs532").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs532").src = "img/sqrs/blSqr.png"
};
};
function sqrsK533() {
    if(document.getElementById("imgSqrs533").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs533").src = "img/sqrs/blSqr.png"
};
};
function sqrsK534() {
    if(document.getElementById("imgSqrs534").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs534").src = "img/sqrs/blSqr.png"
};
};
function sqrsK535() {
    if(document.getElementById("imgSqrs535").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs535").src = "img/sqrs/blSqr.png"
};
};
function sqrsK536() {
    if(document.getElementById("imgSqrs536").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs536").src = "img/sqrs/blSqr.png"
};
};
function sqrsK537() {
    if(document.getElementById("imgSqrs537").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs537").src = "img/sqrs/blSqr.png"
};
};
function sqrsK538() {
    if(document.getElementById("imgSqrs538").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs538").src = "img/sqrs/blSqr.png"
};
};
function sqrsK539() {
    if(document.getElementById("imgSqrs539").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs539").src = "img/sqrs/blSqr.png"
};
};
function sqrsK540() {
    if(document.getElementById("imgSqrs540").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs540").src = "img/sqrs/blSqr.png"
};
};
function sqrsK541() {
    if(document.getElementById("imgSqrs541").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs541").src = "img/sqrs/blSqr.png"
};
};
function sqrsK542() {
    if(document.getElementById("imgSqrs542").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs542").src = "img/sqrs/blSqr.png"
};
};
function sqrsK543() {
    if(document.getElementById("imgSqrs543").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs543").src = "img/sqrs/blSqr.png"
};
};
function sqrsK544() {
    if(document.getElementById("imgSqrs544").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs544").src = "img/sqrs/blSqr.png"
};
};
function sqrsK545() {
    if(document.getElementById("imgSqrs545").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs545").src = "img/sqrs/blSqr.png"
};
};
function sqrsK546() {
    if(document.getElementById("imgSqrs546").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs546").src = "img/sqrs/blSqr.png"
};
};
function sqrsK547() {
    if(document.getElementById("imgSqrs547").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs547").src = "img/sqrs/blSqr.png"
};
};
function sqrsK548() {
    if(document.getElementById("imgSqrs548").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs548").src = "img/sqrs/blSqr.png"
};
};
function sqrsK549() {
    if(document.getElementById("imgSqrs549").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs549").src = "img/sqrs/blSqr.png"
};
};
function sqrsK550() {
    if(document.getElementById("imgSqrs550").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs550").src = "img/sqrs/blSqr.png"
};
};
function sqrsL551() {
    if(document.getElementById("imgSqrs551").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs551").src = "img/sqrs/blSqr.png"
};
};
function sqrsL552() {
    if(document.getElementById("imgSqrs552").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs552").src = "img/sqrs/blSqr.png"
};
};
function sqrsL553() {
    if(document.getElementById("imgSqrs553").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs553").src = "img/sqrs/blSqr.png"
};
};
function sqrsL554() {
    if(document.getElementById("imgSqrs554").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs554").src = "img/sqrs/blSqr.png"
};
};
function sqrsL555() {
    if(document.getElementById("imgSqrs555").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs555").src = "img/sqrs/blSqr.png"
};
};
function sqrsL556() {
    if(document.getElementById("imgSqrs556").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs556").src = "img/sqrs/blSqr.png"
};
};
function sqrsL557() {
    if(document.getElementById("imgSqrs557").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs557").src = "img/sqrs/blSqr.png"
};
};
function sqrsL558() {
    if(document.getElementById("imgSqrs558").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs558").src = "img/sqrs/blSqr.png"
};
};
function sqrsL559() {
    if(document.getElementById("imgSqrs559").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs559").src = "img/sqrs/blSqr.png"
};
};
function sqrsL560() {
    if(document.getElementById("imgSqrs560").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs560").src = "img/sqrs/blSqr.png"
};
};
function sqrsL561() {
    if(document.getElementById("imgSqrs561").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs561").src = "img/sqrs/blSqr.png"
};
};
function sqrsL562() {
    if(document.getElementById("imgSqrs562").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs562").src = "img/sqrs/blSqr.png"
};
};
function sqrsL563() {
    if(document.getElementById("imgSqrs563").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs563").src = "img/sqrs/blSqr.png"
};
};
function sqrsL564() {
    if(document.getElementById("imgSqrs564").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs564").src = "img/sqrs/blSqr.png"
};
};
function sqrsL565() {
    if(document.getElementById("imgSqrs565").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs565").src = "img/sqrs/blSqr.png"
};
};
function sqrsL566() {
    if(document.getElementById("imgSqrs566").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs566").src = "img/sqrs/blSqr.png"
};
};
function sqrsL567() {
    if(document.getElementById("imgSqrs567").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs567").src = "img/sqrs/blSqr.png"
};
};
function sqrsL568() {
    if(document.getElementById("imgSqrs568").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs568").src = "img/sqrs/blSqr.png"
};
};
function sqrsL569() {
    if(document.getElementById("imgSqrs569").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs569").src = "img/sqrs/blSqr.png"
};
};
function sqrsL570() {
    if(document.getElementById("imgSqrs570").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs570").src = "img/sqrs/blSqr.png"
};
};
function sqrsL571() {
    if(document.getElementById("imgSqrs571").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs571").src = "img/sqrs/blSqr.png"
};
};
function sqrsL572() {
    if(document.getElementById("imgSqrs572").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs572").src = "img/sqrs/blSqr.png"
};
};
function sqrsL573() {
    if(document.getElementById("imgSqrs573").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs573").src = "img/sqrs/blSqr.png"
};
};
function sqrsL574() {
    if(document.getElementById("imgSqrs574").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs574").src = "img/sqrs/blSqr.png"
};
};
function sqrsL575() {
    if(document.getElementById("imgSqrs575").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs575").src = "img/sqrs/blSqr.png"
};
};
function sqrsL576() {
    if(document.getElementById("imgSqrs576").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs576").src = "img/sqrs/blSqr.png"
};
};
function sqrsL577() {
    if(document.getElementById("imgSqrs577").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs577").src = "img/sqrs/blSqr.png"
};
};
function sqrsL578() {
    if(document.getElementById("imgSqrs578").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs578").src = "img/sqrs/blSqr.png"
};
};
function sqrsL579() {
    if(document.getElementById("imgSqrs579").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs579").src = "img/sqrs/blSqr.png"
};
};
function sqrsL580() {
    if(document.getElementById("imgSqrs580").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs580").src = "img/sqrs/blSqr.png"
};
};
function sqrsL581() {
    if(document.getElementById("imgSqrs581").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs581").src = "img/sqrs/blSqr.png"
};
};
function sqrsL582() {
    if(document.getElementById("imgSqrs582").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs582").src = "img/sqrs/blSqr.png"
};
};
function sqrsL583() {
    if(document.getElementById("imgSqrs583").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs583").src = "img/sqrs/blSqr.png"
};
};
function sqrsL584() {
    if(document.getElementById("imgSqrs584").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs584").src = "img/sqrs/blSqr.png"
};
};
function sqrsL585() {
    if(document.getElementById("imgSqrs585").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs585").src = "img/sqrs/blSqr.png"
};
};
function sqrsL586() {
    if(document.getElementById("imgSqrs586").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs586").src = "img/sqrs/blSqr.png"
};
};
function sqrsL587() {
    if(document.getElementById("imgSqrs587").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs587").src = "img/sqrs/blSqr.png"
};
};
function sqrsL588() {
    if(document.getElementById("imgSqrs588").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs588").src = "img/sqrs/blSqr.png"
};
};
function sqrsL589() {
    if(document.getElementById("imgSqrs589").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs589").src = "img/sqrs/blSqr.png"
};
};
function sqrsL590() {
    if(document.getElementById("imgSqrs590").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs590").src = "img/sqrs/blSqr.png"
};
};
function sqrsL591() {
    if(document.getElementById("imgSqrs591").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs591").src = "img/sqrs/blSqr.png"
};
};
function sqrsL592() {
    if(document.getElementById("imgSqrs592").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs592").src = "img/sqrs/blSqr.png"
};
};
function sqrsL593() {
    if(document.getElementById("imgSqrs593").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs593").src = "img/sqrs/blSqr.png"
};
};
function sqrsL594() {
    if(document.getElementById("imgSqrs594").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs594").src = "img/sqrs/blSqr.png"
};
};
function sqrsL595() {
    if(document.getElementById("imgSqrs595").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs595").src = "img/sqrs/blSqr.png"
};
};
function sqrsL596() {
    if(document.getElementById("imgSqrs596").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs596").src = "img/sqrs/blSqr.png"
};
};
function sqrsL597() {
    if(document.getElementById("imgSqrs597").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs597").src = "img/sqrs/blSqr.png"
};
};
function sqrsL598() {
    if(document.getElementById("imgSqrs598").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs598").src = "img/sqrs/blSqr.png"
};
};
function sqrsL599() {
    if(document.getElementById("imgSqrs599").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs599").src = "img/sqrs/blSqr.png"
};
};
function sqrsL600() {
    if(document.getElementById("imgSqrs600").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs600").src = "img/sqrs/blSqr.png"
};
};
function sqrsM601() {
    if(document.getElementById("imgSqrs601").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs601").src = "img/sqrs/blSqr.png"
};
};
function sqrsM602() {
    if(document.getElementById("imgSqrs602").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs602").src = "img/sqrs/blSqr.png"
};
};
function sqrsM603() {
    if(document.getElementById("imgSqrs603").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs603").src = "img/sqrs/blSqr.png"
};
};
function sqrsM604() {
    if(document.getElementById("imgSqrs604").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs604").src = "img/sqrs/blSqr.png"
};
};
function sqrsM605() {
    if(document.getElementById("imgSqrs605").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs605").src = "img/sqrs/blSqr.png"
};
};
function sqrsM606() {
    if(document.getElementById("imgSqrs606").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs606").src = "img/sqrs/blSqr.png"
};
};
function sqrsM607() {
    if(document.getElementById("imgSqrs607").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs607").src = "img/sqrs/blSqr.png"
};
};
function sqrsM608() {
    if(document.getElementById("imgSqrs608").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs608").src = "img/sqrs/blSqr.png"
};
};
function sqrsM609() {
    if(document.getElementById("imgSqrs609").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs609").src = "img/sqrs/blSqr.png"
};
};
function sqrsM610() {
    if(document.getElementById("imgSqrs610").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs610").src = "img/sqrs/blSqr.png"
};
};
function sqrsM611() {
    if(document.getElementById("imgSqrs611").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs611").src = "img/sqrs/blSqr.png"
};
};
function sqrsM612() {
    if(document.getElementById("imgSqrs612").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs612").src = "img/sqrs/blSqr.png"
};
};
function sqrsM613() {
    if(document.getElementById("imgSqrs613").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs613").src = "img/sqrs/blSqr.png"
};
};
function sqrsM614() {
    if(document.getElementById("imgSqrs614").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs614").src = "img/sqrs/blSqr.png"
};
};
function sqrsM615() {
    if(document.getElementById("imgSqrs615").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs615").src = "img/sqrs/blSqr.png"
};
};
function sqrsM616() {
    if(document.getElementById("imgSqrs616").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs616").src = "img/sqrs/blSqr.png"
};
};
function sqrsM617() {
    if(document.getElementById("imgSqrs617").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs617").src = "img/sqrs/blSqr.png"
};
};
function sqrsM618() {
    if(document.getElementById("imgSqrs618").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs618").src = "img/sqrs/blSqr.png"
};
};
function sqrsM619() {
    if(document.getElementById("imgSqrs619").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs619").src = "img/sqrs/blSqr.png"
};
};
function sqrsM620() {
    if(document.getElementById("imgSqrs620").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs620").src = "img/sqrs/blSqr.png"
};
};
function sqrsM621() {
    if(document.getElementById("imgSqrs621").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs621").src = "img/sqrs/blSqr.png"
};
};
function sqrsM622() {
    if(document.getElementById("imgSqrs622").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs622").src = "img/sqrs/blSqr.png"
};
};
function sqrsM623() {
    if(document.getElementById("imgSqrs623").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs623").src = "img/sqrs/blSqr.png"
};
};
function sqrsM624() {
    if(document.getElementById("imgSqrs624").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs624").src = "img/sqrs/blSqr.png"
};
};
function sqrsM625() {
    if(document.getElementById("imgSqrs625").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs625").src = "img/sqrs/blSqr.png"
};
};
function sqrsM626() {
    if(document.getElementById("imgSqrs626").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs626").src = "img/sqrs/blSqr.png"
};
};
function sqrsM627() {
    if(document.getElementById("imgSqrs627").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs627").src = "img/sqrs/blSqr.png"
};
};
function sqrsM628() {
    if(document.getElementById("imgSqrs628").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs628").src = "img/sqrs/blSqr.png"
};
};
function sqrsM629() {
    if(document.getElementById("imgSqrs629").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs629").src = "img/sqrs/blSqr.png"
};
};
function sqrsM630() {
    if(document.getElementById("imgSqrs630").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs630").src = "img/sqrs/blSqr.png"
};
};
function sqrsM631() {
    if(document.getElementById("imgSqrs631").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs631").src = "img/sqrs/blSqr.png"
};
};
function sqrsM632() {
    if(document.getElementById("imgSqrs632").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs632").src = "img/sqrs/blSqr.png"
};
};
function sqrsM633() {
    if(document.getElementById("imgSqrs633").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs633").src = "img/sqrs/blSqr.png"
};
};
function sqrsM634() {
    if(document.getElementById("imgSqrs634").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs634").src = "img/sqrs/blSqr.png"
};
};
function sqrsM635() {
    if(document.getElementById("imgSqrs635").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs635").src = "img/sqrs/blSqr.png"
};
};
function sqrsM636() {
    if(document.getElementById("imgSqrs636").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs636").src = "img/sqrs/blSqr.png"
};
};
function sqrsM637() {
    if(document.getElementById("imgSqrs637").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs637").src = "img/sqrs/blSqr.png"
};
};
function sqrsM638() {
    if(document.getElementById("imgSqrs638").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs638").src = "img/sqrs/blSqr.png"
};
};
function sqrsM639() {
    if(document.getElementById("imgSqrs639").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs639").src = "img/sqrs/blSqr.png"
};
};
function sqrsM640() {
    if(document.getElementById("imgSqrs640").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs640").src = "img/sqrs/blSqr.png"
};
};
function sqrsM641() {
    if(document.getElementById("imgSqrs641").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs641").src = "img/sqrs/blSqr.png"
};
};
function sqrsM642() {
    if(document.getElementById("imgSqrs642").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs642").src = "img/sqrs/blSqr.png"
};
};
function sqrsM643() {
    if(document.getElementById("imgSqrs643").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs643").src = "img/sqrs/blSqr.png"
};
};
function sqrsM644() {
    if(document.getElementById("imgSqrs644").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs644").src = "img/sqrs/blSqr.png"
};
};
function sqrsM645() {
    if(document.getElementById("imgSqrs645").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs645").src = "img/sqrs/blSqr.png"
};
};
function sqrsM646() {
    if(document.getElementById("imgSqrs646").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs646").src = "img/sqrs/blSqr.png"
};
};
function sqrsM647() {
    if(document.getElementById("imgSqrs647").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs647").src = "img/sqrs/blSqr.png"
};
};
function sqrsM648() {
    if(document.getElementById("imgSqrs648").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs648").src = "img/sqrs/blSqr.png"
};
};
function sqrsM649() {
    if(document.getElementById("imgSqrs649").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs649").src = "img/sqrs/blSqr.png"
};
};
function sqrsM650() {
    if(document.getElementById("imgSqrs650").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs650").src = "img/sqrs/blSqr.png"
};
};
function sqrsN651() {
    if(document.getElementById("imgSqrs651").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs651").src = "img/sqrs/blSqr.png"
};
};
function sqrsN652() {
    if(document.getElementById("imgSqrs652").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs652").src = "img/sqrs/blSqr.png"
};
};
function sqrsN653() {
    if(document.getElementById("imgSqrs653").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs653").src = "img/sqrs/blSqr.png"
};
};
function sqrsN654() {
    if(document.getElementById("imgSqrs654").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs654").src = "img/sqrs/blSqr.png"
};
};
function sqrsN655() {
    if(document.getElementById("imgSqrs655").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs655").src = "img/sqrs/blSqr.png"
};
};
function sqrsN656() {
    if(document.getElementById("imgSqrs656").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs656").src = "img/sqrs/blSqr.png"
};
};
function sqrsN657() {
    if(document.getElementById("imgSqrs657").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs657").src = "img/sqrs/blSqr.png"
};
};
function sqrsN658() {
    if(document.getElementById("imgSqrs658").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs658").src = "img/sqrs/blSqr.png"
};
};
function sqrsN659() {
    if(document.getElementById("imgSqrs659").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs659").src = "img/sqrs/blSqr.png"
};
};
function sqrsN660() {
    if(document.getElementById("imgSqrs660").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs660").src = "img/sqrs/blSqr.png"
};
};
function sqrsN661() {
    if(document.getElementById("imgSqrs661").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs661").src = "img/sqrs/blSqr.png"
};
};
function sqrsN662() {
    if(document.getElementById("imgSqrs662").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs662").src = "img/sqrs/blSqr.png"
};
};
function sqrsN663() {
    if(document.getElementById("imgSqrs663").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs663").src = "img/sqrs/blSqr.png"
};
};
function sqrsN664() {
    if(document.getElementById("imgSqrs664").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs664").src = "img/sqrs/blSqr.png"
};
};
function sqrsN665() {
    if(document.getElementById("imgSqrs665").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs665").src = "img/sqrs/blSqr.png"
};
};
function sqrsN666() {
    if(document.getElementById("imgSqrs666").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs666").src = "img/sqrs/blSqr.png"
};
};
function sqrsN667() {
    if(document.getElementById("imgSqrs667").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs667").src = "img/sqrs/blSqr.png"
};
};
function sqrsN668() {
    if(document.getElementById("imgSqrs668").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs668").src = "img/sqrs/blSqr.png"
};
};
function sqrsN669() {
    if(document.getElementById("imgSqrs669").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs669").src = "img/sqrs/blSqr.png"
};
};
function sqrsN670() {
    if(document.getElementById("imgSqrs670").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs670").src = "img/sqrs/blSqr.png"
};
};
function sqrsN671() {
    if(document.getElementById("imgSqrs671").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs671").src = "img/sqrs/blSqr.png"
};
};
function sqrsN672() {
    if(document.getElementById("imgSqrs672").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs672").src = "img/sqrs/blSqr.png"
};
};
function sqrsN673() {
    if(document.getElementById("imgSqrs673").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs673").src = "img/sqrs/blSqr.png"
};
};
function sqrsN674() {
    if(document.getElementById("imgSqrs674").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs674").src = "img/sqrs/blSqr.png"
};
};
function sqrsN675() {
    if(document.getElementById("imgSqrs675").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs675").src = "img/sqrs/blSqr.png"
};
};
function sqrsN676() {
    if(document.getElementById("imgSqrs676").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs676").src = "img/sqrs/blSqr.png"
};
};
function sqrsN677() {
    if(document.getElementById("imgSqrs677").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs677").src = "img/sqrs/blSqr.png"
};
};
function sqrsN678() {
    if(document.getElementById("imgSqrs678").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs678").src = "img/sqrs/blSqr.png"
};
};
function sqrsN679() {
    if(document.getElementById("imgSqrs679").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs679").src = "img/sqrs/blSqr.png"
};
};
function sqrsN680() {
    if(document.getElementById("imgSqrs680").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs680").src = "img/sqrs/blSqr.png"
};
};
function sqrsN681() {
    if(document.getElementById("imgSqrs681").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs681").src = "img/sqrs/blSqr.png"
};
};
function sqrsN682() {
    if(document.getElementById("imgSqrs682").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs682").src = "img/sqrs/blSqr.png"
};
};
function sqrsN683() {
    if(document.getElementById("imgSqrs683").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs683").src = "img/sqrs/blSqr.png"
};
};
function sqrsN684() {
    if(document.getElementById("imgSqrs684").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs684").src = "img/sqrs/blSqr.png"
};
};
function sqrsN685() {
    if(document.getElementById("imgSqrs685").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs685").src = "img/sqrs/blSqr.png"
};
};
function sqrsN686() {
    if(document.getElementById("imgSqrs686").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs686").src = "img/sqrs/blSqr.png"
};
};
function sqrsN687() {
    if(document.getElementById("imgSqrs687").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs687").src = "img/sqrs/blSqr.png"
};
};
function sqrsN688() {
    if(document.getElementById("imgSqrs688").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs688").src = "img/sqrs/blSqr.png"
};
};
function sqrsN689() {
    if(document.getElementById("imgSqrs689").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs689").src = "img/sqrs/blSqr.png"
};
};
function sqrsN690() {
    if(document.getElementById("imgSqrs690").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs690").src = "img/sqrs/blSqr.png"
};
};
function sqrsN691() {
    if(document.getElementById("imgSqrs691").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs691").src = "img/sqrs/blSqr.png"
};
};
function sqrsN692() {
    if(document.getElementById("imgSqrs692").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs692").src = "img/sqrs/blSqr.png"
};
};
function sqrsN693() {
    if(document.getElementById("imgSqrs693").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs693").src = "img/sqrs/blSqr.png"
};
};
function sqrsN694() {
    if(document.getElementById("imgSqrs694").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs694").src = "img/sqrs/blSqr.png"
};
};
function sqrsN695() {
    if(document.getElementById("imgSqrs695").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs695").src = "img/sqrs/blSqr.png"
};
};
function sqrsN696() {
    if(document.getElementById("imgSqrs696").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs696").src = "img/sqrs/blSqr.png"
};
};
function sqrsN697() {
    if(document.getElementById("imgSqrs697").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs697").src = "img/sqrs/blSqr.png"
};
};
function sqrsN698() {
    if(document.getElementById("imgSqrs698").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs698").src = "img/sqrs/blSqr.png"
};
};
function sqrsN699() {
    if(document.getElementById("imgSqrs699").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs699").src = "img/sqrs/blSqr.png"
};
};
function sqrsN700() {
    if(document.getElementById("imgSqrs700").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs700").src = "img/sqrs/blSqr.png"
};
};
function sqrsO701() {
    if(document.getElementById("imgSqrs701").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs701").src = "img/sqrs/blSqr.png"
};
};
function sqrsO702() {
    if(document.getElementById("imgSqrs702").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs702").src = "img/sqrs/blSqr.png"
};
};
function sqrsO703() {
    if(document.getElementById("imgSqrs703").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs703").src = "img/sqrs/blSqr.png"
};
};
function sqrsO704() {
    if(document.getElementById("imgSqrs704").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs704").src = "img/sqrs/blSqr.png"
};
};
function sqrsO705() {
    if(document.getElementById("imgSqrs705").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs705").src = "img/sqrs/blSqr.png"
};
};
function sqrsO706() {
    if(document.getElementById("imgSqrs706").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs706").src = "img/sqrs/blSqr.png"
};
};
function sqrsO707() {
    if(document.getElementById("imgSqrs707").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs707").src = "img/sqrs/blSqr.png"
};
};
function sqrsO708() {
    if(document.getElementById("imgSqrs708").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs708").src = "img/sqrs/blSqr.png"
};
};
function sqrsO709() {
    if(document.getElementById("imgSqrs709").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs709").src = "img/sqrs/blSqr.png"
};
};
function sqrsO710() {
    if(document.getElementById("imgSqrs710").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs710").src = "img/sqrs/blSqr.png"
};
};
function sqrsO711() {
    if(document.getElementById("imgSqrs711").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs711").src = "img/sqrs/blSqr.png"
};
};
function sqrsO712() {
    if(document.getElementById("imgSqrs712").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs712").src = "img/sqrs/blSqr.png"
};
};
function sqrsO713() {
    if(document.getElementById("imgSqrs713").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs713").src = "img/sqrs/blSqr.png"
};
};
function sqrsO714() {
    if(document.getElementById("imgSqrs714").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs714").src = "img/sqrs/blSqr.png"
};
};
function sqrsO715() {
    if(document.getElementById("imgSqrs715").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs715").src = "img/sqrs/blSqr.png"
};
};
function sqrsO716() {
    if(document.getElementById("imgSqrs716").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs716").src = "img/sqrs/blSqr.png"
};
};
function sqrsO717() {
    if(document.getElementById("imgSqrs717").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs717").src = "img/sqrs/blSqr.png"
};
};
function sqrsO718() {
    if(document.getElementById("imgSqrs718").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs718").src = "img/sqrs/blSqr.png"
};
};
function sqrsO719() {
    if(document.getElementById("imgSqrs719").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs719").src = "img/sqrs/blSqr.png"
};
};
function sqrsO720() {
    if(document.getElementById("imgSqrs720").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs720").src = "img/sqrs/blSqr.png"
};
};
function sqrsO721() {
    if(document.getElementById("imgSqrs721").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs721").src = "img/sqrs/blSqr.png"
};
};
function sqrsO722() {
    if(document.getElementById("imgSqrs722").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs722").src = "img/sqrs/blSqr.png"
};
};
function sqrsO723() {
    if(document.getElementById("imgSqrs723").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs723").src = "img/sqrs/blSqr.png"
};
};
function sqrsO724() {
    if(document.getElementById("imgSqrs724").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs724").src = "img/sqrs/blSqr.png"
};
};
function sqrsO725() {
    if(document.getElementById("imgSqrs725").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs725").src = "img/sqrs/blSqr.png"
};
};
function sqrsO726() {
    if(document.getElementById("imgSqrs726").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs726").src = "img/sqrs/blSqr.png"
};
};
function sqrsO727() {
    if(document.getElementById("imgSqrs727").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs727").src = "img/sqrs/blSqr.png"
};
};
function sqrsO728() {
    if(document.getElementById("imgSqrs728").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs728").src = "img/sqrs/blSqr.png"
};
};
function sqrsO729() {
    if(document.getElementById("imgSqrs729").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs729").src = "img/sqrs/blSqr.png"
};
};
function sqrsO730() {
    if(document.getElementById("imgSqrs730").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs730").src = "img/sqrs/blSqr.png"
};
};
function sqrsO731() {
    if(document.getElementById("imgSqrs731").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs731").src = "img/sqrs/blSqr.png"
};
};
function sqrsO732() {
    if(document.getElementById("imgSqrs732").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs732").src = "img/sqrs/blSqr.png"
};
};
function sqrsO733() {
    if(document.getElementById("imgSqrs733").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs733").src = "img/sqrs/blSqr.png"
};
};
function sqrsO734() {
    if(document.getElementById("imgSqrs734").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs734").src = "img/sqrs/blSqr.png"
};
};
function sqrsO735() {
    if(document.getElementById("imgSqrs735").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs735").src = "img/sqrs/blSqr.png"
};
};
function sqrsO736() {
    if(document.getElementById("imgSqrs736").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs736").src = "img/sqrs/blSqr.png"
};
};
function sqrsO737() {
    if(document.getElementById("imgSqrs737").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs737").src = "img/sqrs/blSqr.png"
};
};
function sqrsO738() {
    if(document.getElementById("imgSqrs738").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs738").src = "img/sqrs/blSqr.png"
};
};
function sqrsO739() {
    if(document.getElementById("imgSqrs739").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs739").src = "img/sqrs/blSqr.png"
};
};
function sqrsO740() {
    if(document.getElementById("imgSqrs740").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs740").src = "img/sqrs/blSqr.png"
};
};
function sqrsO741() {
    if(document.getElementById("imgSqrs741").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs741").src = "img/sqrs/blSqr.png"
};
};
function sqrsO742() {
    if(document.getElementById("imgSqrs742").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs742").src = "img/sqrs/blSqr.png"
};
};
function sqrsO743() {
    if(document.getElementById("imgSqrs743").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs743").src = "img/sqrs/blSqr.png"
};
};
function sqrsO744() {
    if(document.getElementById("imgSqrs744").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs744").src = "img/sqrs/blSqr.png"
};
};
function sqrsO745() {
    if(document.getElementById("imgSqrs745").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs745").src = "img/sqrs/blSqr.png"
};
};
function sqrsO746() {
    if(document.getElementById("imgSqrs746").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs746").src = "img/sqrs/blSqr.png"
};
};
function sqrsO747() {
    if(document.getElementById("imgSqrs747").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs747").src = "img/sqrs/blSqr.png"
};
};
function sqrsO748() {
    if(document.getElementById("imgSqrs748").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs748").src = "img/sqrs/blSqr.png"
};
};
function sqrsO749() {
    if(document.getElementById("imgSqrs749").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs749").src = "img/sqrs/blSqr.png"
};
};
function sqrsO750() {
    if(document.getElementById("imgSqrs750").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs750").src = "img/sqrs/blSqr.png"
};
};
function sqrsP751() {
    if(document.getElementById("imgSqrs751").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs751").src = "img/sqrs/blSqr.png"
};
};
function sqrsP752() {
    if(document.getElementById("imgSqrs752").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs752").src = "img/sqrs/blSqr.png"
};
};
function sqrsP753() {
    if(document.getElementById("imgSqrs753").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs753").src = "img/sqrs/blSqr.png"
};
};
function sqrsP754() {
    if(document.getElementById("imgSqrs754").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs754").src = "img/sqrs/blSqr.png"
};
};
function sqrsP755() {
    if(document.getElementById("imgSqrs755").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs755").src = "img/sqrs/blSqr.png"
};
};
function sqrsP756() {
    if(document.getElementById("imgSqrs756").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs756").src = "img/sqrs/blSqr.png"
};
};
function sqrsP757() {
    if(document.getElementById("imgSqrs757").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs757").src = "img/sqrs/blSqr.png"
};
};
function sqrsP758() {
    if(document.getElementById("imgSqrs758").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs758").src = "img/sqrs/blSqr.png"
};
};
function sqrsP759() {
    if(document.getElementById("imgSqrs759").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs759").src = "img/sqrs/blSqr.png"
};
};
function sqrsP760() {
    if(document.getElementById("imgSqrs760").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs760").src = "img/sqrs/blSqr.png"
};
};
function sqrsP761() {
    if(document.getElementById("imgSqrs761").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs761").src = "img/sqrs/blSqr.png"
};
};
function sqrsP762() {
    if(document.getElementById("imgSqrs762").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs762").src = "img/sqrs/blSqr.png"
};
};
function sqrsP763() {
    if(document.getElementById("imgSqrs763").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs763").src = "img/sqrs/blSqr.png"
};
};
function sqrsP764() {
    if(document.getElementById("imgSqrs764").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs764").src = "img/sqrs/blSqr.png"
};
};
function sqrsP765() {
    if(document.getElementById("imgSqrs765").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs765").src = "img/sqrs/blSqr.png"
};
};
function sqrsP766() {
    if(document.getElementById("imgSqrs766").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs766").src = "img/sqrs/blSqr.png"
};
};
function sqrsP767() {
    if(document.getElementById("imgSqrs767").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs767").src = "img/sqrs/blSqr.png"
};
};
function sqrsP768() {
    if(document.getElementById("imgSqrs768").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs768").src = "img/sqrs/blSqr.png"
};
};
function sqrsP769() {
    if(document.getElementById("imgSqrs769").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs769").src = "img/sqrs/blSqr.png"
};
};
function sqrsP770() {
    if(document.getElementById("imgSqrs770").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs770").src = "img/sqrs/blSqr.png"
};
};
function sqrsP771() {
    if(document.getElementById("imgSqrs771").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs771").src = "img/sqrs/blSqr.png"
};
};
function sqrsP772() {
    if(document.getElementById("imgSqrs772").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs772").src = "img/sqrs/blSqr.png"
};
};
function sqrsP773() {
    if(document.getElementById("imgSqrs773").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs773").src = "img/sqrs/blSqr.png"
};
};
function sqrsP774() {
    if(document.getElementById("imgSqrs774").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs774").src = "img/sqrs/blSqr.png"
};
};
function sqrsP775() {
    if(document.getElementById("imgSqrs775").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs775").src = "img/sqrs/blSqr.png"
};
};
function sqrsP776() {
    if(document.getElementById("imgSqrs776").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs776").src = "img/sqrs/blSqr.png"
};
};
function sqrsP777() {
    if(document.getElementById("imgSqrs777").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs777").src = "img/sqrs/blSqr.png"
};
};
function sqrsP778() {
    if(document.getElementById("imgSqrs778").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs778").src = "img/sqrs/blSqr.png"
};
};
function sqrsP779() {
    if(document.getElementById("imgSqrs779").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs779").src = "img/sqrs/blSqr.png"
};
};
function sqrsP780() {
    if(document.getElementById("imgSqrs780").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs780").src = "img/sqrs/blSqr.png"
};
};
function sqrsP781() {
    if(document.getElementById("imgSqrs781").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs781").src = "img/sqrs/blSqr.png"
};
};
function sqrsP782() {
    if(document.getElementById("imgSqrs782").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs782").src = "img/sqrs/blSqr.png"
};
};
function sqrsP783() {
    if(document.getElementById("imgSqrs783").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs783").src = "img/sqrs/blSqr.png"
};
};
function sqrsP784() {
    if(document.getElementById("imgSqrs784").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs784").src = "img/sqrs/blSqr.png"
};
};
function sqrsP785() {
    if(document.getElementById("imgSqrs785").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs785").src = "img/sqrs/blSqr.png"
};
};
function sqrsP786() {
    if(document.getElementById("imgSqrs786").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs786").src = "img/sqrs/blSqr.png"
};
};
function sqrsP787() {
    if(document.getElementById("imgSqrs787").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs787").src = "img/sqrs/blSqr.png"
};
};
function sqrsP788() {
    if(document.getElementById("imgSqrs788").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs788").src = "img/sqrs/blSqr.png"
};
};
function sqrsP789() {
    if(document.getElementById("imgSqrs789").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs789").src = "img/sqrs/blSqr.png"
};
};
function sqrsP790() {
    if(document.getElementById("imgSqrs790").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs790").src = "img/sqrs/blSqr.png"
};
};
function sqrsP791() {
    if(document.getElementById("imgSqrs791").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs791").src = "img/sqrs/blSqr.png"
};
};
function sqrsP792() {
    if(document.getElementById("imgSqrs792").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs792").src = "img/sqrs/blSqr.png"
};
};
function sqrsP793() {
    if(document.getElementById("imgSqrs793").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs793").src = "img/sqrs/blSqr.png"
};
};
function sqrsP794() {
    if(document.getElementById("imgSqrs794").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs794").src = "img/sqrs/blSqr.png"
};
};
function sqrsP795() {
    if(document.getElementById("imgSqrs795").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs795").src = "img/sqrs/blSqr.png"
};
};
function sqrsP796() {
    if(document.getElementById("imgSqrs796").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs796").src = "img/sqrs/blSqr.png"
};
};
function sqrsP797() {
    if(document.getElementById("imgSqrs797").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs797").src = "img/sqrs/blSqr.png"
};
};
function sqrsP798() {
    if(document.getElementById("imgSqrs798").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs798").src = "img/sqrs/blSqr.png"
};
};
function sqrsP799() {
    if(document.getElementById("imgSqrs799").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs799").src = "img/sqrs/blSqr.png"
};
};
function sqrsP800() {
    if(document.getElementById("imgSqrs800").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs800").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ801() {
    if(document.getElementById("imgSqrs801").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs801").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ802() {
    if(document.getElementById("imgSqrs802").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs802").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ803() {
    if(document.getElementById("imgSqrs803").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs803").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ804() {
    if(document.getElementById("imgSqrs804").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs804").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ805() {
    if(document.getElementById("imgSqrs805").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs805").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ806() {
    if(document.getElementById("imgSqrs806").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs806").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ807() {
    if(document.getElementById("imgSqrs807").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs807").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ808() {
    if(document.getElementById("imgSqrs808").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs808").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ809() {
    if(document.getElementById("imgSqrs809").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs809").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ810() {
    if(document.getElementById("imgSqrs810").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs810").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ811() {
    if(document.getElementById("imgSqrs811").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs811").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ812() {
    if(document.getElementById("imgSqrs812").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs812").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ813() {
    if(document.getElementById("imgSqrs813").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs813").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ814() {
    if(document.getElementById("imgSqrs814").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs814").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ815() {
    if(document.getElementById("imgSqrs815").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs815").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ816() {
    if(document.getElementById("imgSqrs816").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs816").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ817() {
    if(document.getElementById("imgSqrs817").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs817").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ818() {
    if(document.getElementById("imgSqrs818").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs818").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ819() {
    if(document.getElementById("imgSqrs819").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs819").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ820() {
    if(document.getElementById("imgSqrs820").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs820").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ821() {
    if(document.getElementById("imgSqrs821").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs821").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ822() {
    if(document.getElementById("imgSqrs822").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs822").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ823() {
    if(document.getElementById("imgSqrs823").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs823").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ824() {
    if(document.getElementById("imgSqrs824").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs824").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ825() {
    if(document.getElementById("imgSqrs825").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs825").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ826() {
    if(document.getElementById("imgSqrs826").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs826").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ827() {
    if(document.getElementById("imgSqrs827").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs827").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ828() {
    if(document.getElementById("imgSqrs828").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs828").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ829() {
    if(document.getElementById("imgSqrs829").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs829").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ830() {
    if(document.getElementById("imgSqrs830").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs830").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ831() {
    if(document.getElementById("imgSqrs831").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs831").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ832() {
    if(document.getElementById("imgSqrs832").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs832").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ833() {
    if(document.getElementById("imgSqrs833").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs833").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ834() {
    if(document.getElementById("imgSqrs834").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs834").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ835() {
    if(document.getElementById("imgSqrs835").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs835").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ836() {
    if(document.getElementById("imgSqrs836").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs836").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ837() {
    if(document.getElementById("imgSqrs837").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs837").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ838() {
    if(document.getElementById("imgSqrs838").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs838").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ839() {
    if(document.getElementById("imgSqrs839").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs839").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ840() {
    if(document.getElementById("imgSqrs840").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs840").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ841() {
    if(document.getElementById("imgSqrs841").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs841").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ842() {
    if(document.getElementById("imgSqrs842").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs842").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ843() {
    if(document.getElementById("imgSqrs843").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs843").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ844() {
    if(document.getElementById("imgSqrs844").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs844").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ845() {
    if(document.getElementById("imgSqrs845").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs845").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ846() {
    if(document.getElementById("imgSqrs846").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs846").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ847() {
    if(document.getElementById("imgSqrs847").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs847").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ848() {
    if(document.getElementById("imgSqrs848").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs848").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ849() {
    if(document.getElementById("imgSqrs849").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs849").src = "img/sqrs/blSqr.png"
};
};
function sqrsQ850() {
    if(document.getElementById("imgSqrs850").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs850").src = "img/sqrs/blSqr.png"
};
};
function sqrsR851() {
    if(document.getElementById("imgSqrs851").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs851").src = "img/sqrs/blSqr.png"
};
};
function sqrsR852() {
    if(document.getElementById("imgSqrs852").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs852").src = "img/sqrs/blSqr.png"
};
};
function sqrsR853() {
    if(document.getElementById("imgSqrs853").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs853").src = "img/sqrs/blSqr.png"
};
};
function sqrsR854() {
    if(document.getElementById("imgSqrs854").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs854").src = "img/sqrs/blSqr.png"
};
};
function sqrsR855() {
    if(document.getElementById("imgSqrs855").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs855").src = "img/sqrs/blSqr.png"
};
};
function sqrsR856() {
    if(document.getElementById("imgSqrs856").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs856").src = "img/sqrs/blSqr.png"
};
};
function sqrsR857() {
    if(document.getElementById("imgSqrs857").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs857").src = "img/sqrs/blSqr.png"
};
};
function sqrsR858() {
    if(document.getElementById("imgSqrs858").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs858").src = "img/sqrs/blSqr.png"
};
};
function sqrsR859() {
    if(document.getElementById("imgSqrs859").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs859").src = "img/sqrs/blSqr.png"
};
};
function sqrsR860() {
    if(document.getElementById("imgSqrs860").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs860").src = "img/sqrs/blSqr.png"
};
};
function sqrsR861() {
    if(document.getElementById("imgSqrs861").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs861").src = "img/sqrs/blSqr.png"
};
};
function sqrsR862() {
    if(document.getElementById("imgSqrs862").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs862").src = "img/sqrs/blSqr.png"
};
};
function sqrsR863() {
    if(document.getElementById("imgSqrs863").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs863").src = "img/sqrs/blSqr.png"
};
};
function sqrsR864() {
    if(document.getElementById("imgSqrs864").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs864").src = "img/sqrs/blSqr.png"
};
};
function sqrsR865() {
    if(document.getElementById("imgSqrs865").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs865").src = "img/sqrs/blSqr.png"
};
};
function sqrsR866() {
    if(document.getElementById("imgSqrs866").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs866").src = "img/sqrs/blSqr.png"
};
};
function sqrsR867() {
    if(document.getElementById("imgSqrs867").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs867").src = "img/sqrs/blSqr.png"
};
};
function sqrsR868() {
    if(document.getElementById("imgSqrs868").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs868").src = "img/sqrs/blSqr.png"
};
};
function sqrsR869() {
    if(document.getElementById("imgSqrs869").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs869").src = "img/sqrs/blSqr.png"
};
};
function sqrsR870() {
    if(document.getElementById("imgSqrs870").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs870").src = "img/sqrs/blSqr.png"
};
};
function sqrsR871() {
    if(document.getElementById("imgSqrs871").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs871").src = "img/sqrs/blSqr.png"
};
};
function sqrsR872() {
    if(document.getElementById("imgSqrs872").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs872").src = "img/sqrs/blSqr.png"
};
};
function sqrsR873() {
    if(document.getElementById("imgSqrs873").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs873").src = "img/sqrs/blSqr.png"
};
};
function sqrsR874() {
    if(document.getElementById("imgSqrs874").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs874").src = "img/sqrs/blSqr.png"
};
};
function sqrsR875() {
    if(document.getElementById("imgSqrs875").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs875").src = "img/sqrs/blSqr.png"
};
};
function sqrsR876() {
    if(document.getElementById("imgSqrs876").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs876").src = "img/sqrs/blSqr.png"
};
};
function sqrsR877() {
    if(document.getElementById("imgSqrs877").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs877").src = "img/sqrs/blSqr.png"
};
};
function sqrsR878() {
    if(document.getElementById("imgSqrs878").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs878").src = "img/sqrs/blSqr.png"
};
};
function sqrsR879() {
    if(document.getElementById("imgSqrs879").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs879").src = "img/sqrs/blSqr.png"
};
};
function sqrsR880() {
    if(document.getElementById("imgSqrs880").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs880").src = "img/sqrs/blSqr.png"
};
};
function sqrsR881() {
    if(document.getElementById("imgSqrs881").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs881").src = "img/sqrs/blSqr.png"
};
};
function sqrsR882() {
    if(document.getElementById("imgSqrs882").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs882").src = "img/sqrs/blSqr.png"
};
};
function sqrsR883() {
    if(document.getElementById("imgSqrs883").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs883").src = "img/sqrs/blSqr.png"
};
};
function sqrsR884() {
    if(document.getElementById("imgSqrs884").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs884").src = "img/sqrs/blSqr.png"
};
};
function sqrsR885() {
    if(document.getElementById("imgSqrs885").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs885").src = "img/sqrs/blSqr.png"
};
};
function sqrsR886() {
    if(document.getElementById("imgSqrs886").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs886").src = "img/sqrs/blSqr.png"
};
};
function sqrsR887() {
    if(document.getElementById("imgSqrs887").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs887").src = "img/sqrs/blSqr.png"
};
};
function sqrsR888() {
    if(document.getElementById("imgSqrs888").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs888").src = "img/sqrs/blSqr.png"
};
};
function sqrsR889() {
    if(document.getElementById("imgSqrs889").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs889").src = "img/sqrs/blSqr.png"
};
};
function sqrsR890() {
    if(document.getElementById("imgSqrs890").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs890").src = "img/sqrs/blSqr.png"
};
};
function sqrsR891() {
    if(document.getElementById("imgSqrs891").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs891").src = "img/sqrs/blSqr.png"
};
};
function sqrsR892() {
    if(document.getElementById("imgSqrs892").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs892").src = "img/sqrs/blSqr.png"
};
};
function sqrsR893() {
    if(document.getElementById("imgSqrs893").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs893").src = "img/sqrs/blSqr.png"
};
};
function sqrsR894() {
    if(document.getElementById("imgSqrs894").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs894").src = "img/sqrs/blSqr.png"
};
};
function sqrsR895() {
    if(document.getElementById("imgSqrs895").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs895").src = "img/sqrs/blSqr.png"
};
};
function sqrsR896() {
    if(document.getElementById("imgSqrs896").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs896").src = "img/sqrs/blSqr.png"
};
};
function sqrsR897() {
    if(document.getElementById("imgSqrs897").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs897").src = "img/sqrs/blSqr.png"
};
};
function sqrsR898() {
    if(document.getElementById("imgSqrs898").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs898").src = "img/sqrs/blSqr.png"
};
};
function sqrsR899() {
    if(document.getElementById("imgSqrs899").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs899").src = "img/sqrs/blSqr.png"
};
};
function sqrsR900() {
    if(document.getElementById("imgSqrs900").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs900").src = "img/sqrs/blSqr.png"
};
};
function sqrsS901() {
    if(document.getElementById("imgSqrs901").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs901").src = "img/sqrs/blSqr.png"
};
};
function sqrsS902() {
    if(document.getElementById("imgSqrs902").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs902").src = "img/sqrs/blSqr.png"
};
};
function sqrsS903() {
    if(document.getElementById("imgSqrs903").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs903").src = "img/sqrs/blSqr.png"
};
};
function sqrsS904() {
    if(document.getElementById("imgSqrs904").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs904").src = "img/sqrs/blSqr.png"
};
};
function sqrsS905() {
    if(document.getElementById("imgSqrs905").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs905").src = "img/sqrs/blSqr.png"
};
};
function sqrsS906() {
    if(document.getElementById("imgSqrs906").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs906").src = "img/sqrs/blSqr.png"
};
};
function sqrsS907() {
    if(document.getElementById("imgSqrs907").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs907").src = "img/sqrs/blSqr.png"
};
};
function sqrsS908() {
    if(document.getElementById("imgSqrs908").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs908").src = "img/sqrs/blSqr.png"
};
};
function sqrsS909() {
    if(document.getElementById("imgSqrs909").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs909").src = "img/sqrs/blSqr.png"
};
};
function sqrsS910() {
    if(document.getElementById("imgSqrs910").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs910").src = "img/sqrs/blSqr.png"
};
};
function sqrsS911() {
    if(document.getElementById("imgSqrs911").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs911").src = "img/sqrs/blSqr.png"
};
};
function sqrsS912() {
    if(document.getElementById("imgSqrs912").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs912").src = "img/sqrs/blSqr.png"
};
};
function sqrsS913() {
    if(document.getElementById("imgSqrs913").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs913").src = "img/sqrs/blSqr.png"
};
};
function sqrsS914() {
    if(document.getElementById("imgSqrs914").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs914").src = "img/sqrs/blSqr.png"
};
};
function sqrsS915() {
    if(document.getElementById("imgSqrs915").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs915").src = "img/sqrs/blSqr.png"
};
};
function sqrsS916() {
    if(document.getElementById("imgSqrs916").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs916").src = "img/sqrs/blSqr.png"
};
};
function sqrsS917() {
    if(document.getElementById("imgSqrs917").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs917").src = "img/sqrs/blSqr.png"
};
};
function sqrsS918() {
    if(document.getElementById("imgSqrs918").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs918").src = "img/sqrs/blSqr.png"
};
};
function sqrsS919() {
    if(document.getElementById("imgSqrs919").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs919").src = "img/sqrs/blSqr.png"
};
};
function sqrsS920() {
    if(document.getElementById("imgSqrs920").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs920").src = "img/sqrs/blSqr.png"
};
};
function sqrsS921() {
    if(document.getElementById("imgSqrs921").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs921").src = "img/sqrs/blSqr.png"
};
};
function sqrsS922() {
    if(document.getElementById("imgSqrs922").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs922").src = "img/sqrs/blSqr.png"
};
};
function sqrsS923() {
    if(document.getElementById("imgSqrs923").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs923").src = "img/sqrs/blSqr.png"
};
};
function sqrsS924() {
    if(document.getElementById("imgSqrs924").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs924").src = "img/sqrs/blSqr.png"
};
};
function sqrsS925() {
    if(document.getElementById("imgSqrs925").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs925").src = "img/sqrs/blSqr.png"
};
};
function sqrsS926() {
    if(document.getElementById("imgSqrs926").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs926").src = "img/sqrs/blSqr.png"
};
};
function sqrsS927() {
    if(document.getElementById("imgSqrs927").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs927").src = "img/sqrs/blSqr.png"
};
};
function sqrsS928() {
    if(document.getElementById("imgSqrs928").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs928").src = "img/sqrs/blSqr.png"
};
};
function sqrsS929() {
    if(document.getElementById("imgSqrs929").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs929").src = "img/sqrs/blSqr.png"
};
};
function sqrsS930() {
    if(document.getElementById("imgSqrs930").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs930").src = "img/sqrs/blSqr.png"
};
};
function sqrsS931() {
    if(document.getElementById("imgSqrs931").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs931").src = "img/sqrs/blSqr.png"
};
};
function sqrsS932() {
    if(document.getElementById("imgSqrs932").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs932").src = "img/sqrs/blSqr.png"
};
};
function sqrsS933() {
    if(document.getElementById("imgSqrs933").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs933").src = "img/sqrs/blSqr.png"
};
};
function sqrsS934() {
    if(document.getElementById("imgSqrs934").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs934").src = "img/sqrs/blSqr.png"
};
};
function sqrsS935() {
    if(document.getElementById("imgSqrs935").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs935").src = "img/sqrs/blSqr.png"
};
};
function sqrsS936() {
    if(document.getElementById("imgSqrs936").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs936").src = "img/sqrs/blSqr.png"
};
};
function sqrsS937() {
    if(document.getElementById("imgSqrs937").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs937").src = "img/sqrs/blSqr.png"
};
};
function sqrsS938() {
    if(document.getElementById("imgSqrs938").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs938").src = "img/sqrs/blSqr.png"
};
};
function sqrsS939() {
    if(document.getElementById("imgSqrs939").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs939").src = "img/sqrs/blSqr.png"
};
};
function sqrsS940() {
    if(document.getElementById("imgSqrs940").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs940").src = "img/sqrs/blSqr.png"
};
};
function sqrsS941() {
    if(document.getElementById("imgSqrs941").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs941").src = "img/sqrs/blSqr.png"
};
};
function sqrsS942() {
    if(document.getElementById("imgSqrs942").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs942").src = "img/sqrs/blSqr.png"
};
};
function sqrsS943() {
    if(document.getElementById("imgSqrs943").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs943").src = "img/sqrs/blSqr.png"
};
};
function sqrsS944() {
    if(document.getElementById("imgSqrs944").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs944").src = "img/sqrs/blSqr.png"
};
};
function sqrsS945() {
    if(document.getElementById("imgSqrs945").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs945").src = "img/sqrs/blSqr.png"
};
};
function sqrsS946() {
    if(document.getElementById("imgSqrs946").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs946").src = "img/sqrs/blSqr.png"
};
};
function sqrsS947() {
    if(document.getElementById("imgSqrs947").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs947").src = "img/sqrs/blSqr.png"
};
};
function sqrsS948() {
    if(document.getElementById("imgSqrs948").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs948").src = "img/sqrs/blSqr.png"
};
};
function sqrsS949() {
    if(document.getElementById("imgSqrs949").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs949").src = "img/sqrs/blSqr.png"
};
};
function sqrsS950() {
    if(document.getElementById("imgSqrs950").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs950").src = "img/sqrs/blSqr.png"
};
};
function sqrsT951() {
    if(document.getElementById("imgSqrs951").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs951").src = "img/sqrs/blSqr.png"
};
};
function sqrsT952() {
    if(document.getElementById("imgSqrs952").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs952").src = "img/sqrs/blSqr.png"
};
};
function sqrsT953() {
    if(document.getElementById("imgSqrs953").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs953").src = "img/sqrs/blSqr.png"
};
};
function sqrsT954() {
    if(document.getElementById("imgSqrs954").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs954").src = "img/sqrs/blSqr.png"
};
};
function sqrsT955() {
    if(document.getElementById("imgSqrs955").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs955").src = "img/sqrs/blSqr.png"
};
};
function sqrsT956() {
    if(document.getElementById("imgSqrs956").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs956").src = "img/sqrs/blSqr.png"
};
};
function sqrsT957() {
    if(document.getElementById("imgSqrs957").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs957").src = "img/sqrs/blSqr.png"
};
};
function sqrsT958() {
    if(document.getElementById("imgSqrs958").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs958").src = "img/sqrs/blSqr.png"
};
};
function sqrsT959() {
    if(document.getElementById("imgSqrs959").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs959").src = "img/sqrs/blSqr.png"
};
};
function sqrsT960() {
    if(document.getElementById("imgSqrs960").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs960").src = "img/sqrs/blSqr.png"
};
};
function sqrsT961() {
    if(document.getElementById("imgSqrs961").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs961").src = "img/sqrs/blSqr.png"
};
};
function sqrsT962() {
    if(document.getElementById("imgSqrs962").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs962").src = "img/sqrs/blSqr.png"
};
};
function sqrsT963() {
    if(document.getElementById("imgSqrs963").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs963").src = "img/sqrs/blSqr.png"
};
};
function sqrsT964() {
    if(document.getElementById("imgSqrs964").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs964").src = "img/sqrs/blSqr.png"
};
};
function sqrsT965() {
    if(document.getElementById("imgSqrs965").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs965").src = "img/sqrs/blSqr.png"
};
};
function sqrsT966() {
    if(document.getElementById("imgSqrs966").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs966").src = "img/sqrs/blSqr.png"
};
};
function sqrsT967() {
    if(document.getElementById("imgSqrs967").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs967").src = "img/sqrs/blSqr.png"
};
};
function sqrsT968() {
    if(document.getElementById("imgSqrs968").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs968").src = "img/sqrs/blSqr.png"
};
};
function sqrsT969() {
    if(document.getElementById("imgSqrs969").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs969").src = "img/sqrs/blSqr.png"
};
};
function sqrsT970() {
    if(document.getElementById("imgSqrs970").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs970").src = "img/sqrs/blSqr.png"
};
};
function sqrsT971() {
    if(document.getElementById("imgSqrs971").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs971").src = "img/sqrs/blSqr.png"
};
};
function sqrsT972() {
    if(document.getElementById("imgSqrs972").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs972").src = "img/sqrs/blSqr.png"
};
};
function sqrsT973() {
    if(document.getElementById("imgSqrs973").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs973").src = "img/sqrs/blSqr.png"
};
};
function sqrsT974() {
    if(document.getElementById("imgSqrs974").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs974").src = "img/sqrs/blSqr.png"
};
};
function sqrsT975() {
    if(document.getElementById("imgSqrs975").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs975").src = "img/sqrs/blSqr.png"
};
};
function sqrsT976() {
    if(document.getElementById("imgSqrs976").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs976").src = "img/sqrs/blSqr.png"
};
};
function sqrsT977() {
    if(document.getElementById("imgSqrs977").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs977").src = "img/sqrs/blSqr.png"
};
};
function sqrsT978() {
    if(document.getElementById("imgSqrs978").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs978").src = "img/sqrs/blSqr.png"
};
};
function sqrsT979() {
    if(document.getElementById("imgSqrs979").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs979").src = "img/sqrs/blSqr.png"
};
};
function sqrsT980() {
    if(document.getElementById("imgSqrs980").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs980").src = "img/sqrs/blSqr.png"
};
};
function sqrsT981() {
    if(document.getElementById("imgSqrs981").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs981").src = "img/sqrs/blSqr.png"
};
};
function sqrsT982() {
    if(document.getElementById("imgSqrs982").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs982").src = "img/sqrs/blSqr.png"
};
};
function sqrsT983() {
    if(document.getElementById("imgSqrs983").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs983").src = "img/sqrs/blSqr.png"
};
};
function sqrsT984() {
    if(document.getElementById("imgSqrs984").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs984").src = "img/sqrs/blSqr.png"
};
};
function sqrsT985() {
    if(document.getElementById("imgSqrs985").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs985").src = "img/sqrs/blSqr.png"
};
};
function sqrsT986() {
    if(document.getElementById("imgSqrs986").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs986").src = "img/sqrs/blSqr.png"
};
};
function sqrsT987() {
    if(document.getElementById("imgSqrs987").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs987").src = "img/sqrs/blSqr.png"
};
};
function sqrsT988() {
    if(document.getElementById("imgSqrs988").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs988").src = "img/sqrs/blSqr.png"
};
};
function sqrsT989() {
    if(document.getElementById("imgSqrs989").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs989").src = "img/sqrs/blSqr.png"
};
};
function sqrsT990() {
    if(document.getElementById("imgSqrs990").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs990").src = "img/sqrs/blSqr.png"
};
};
function sqrsT991() {
    if(document.getElementById("imgSqrs991").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs991").src = "img/sqrs/blSqr.png"
};
};
function sqrsT992() {
    if(document.getElementById("imgSqrs992").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs992").src = "img/sqrs/blSqr.png"
};
};
function sqrsT993() {
    if(document.getElementById("imgSqrs993").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs993").src = "img/sqrs/blSqr.png"
};
};
function sqrsT994() {
    if(document.getElementById("imgSqrs994").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs994").src = "img/sqrs/blSqr.png"
};
};
function sqrsT995() {
    if(document.getElementById("imgSqrs995").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs995").src = "img/sqrs/blSqr.png"
};
};
function sqrsT996() {
    if(document.getElementById("imgSqrs996").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs996").src = "img/sqrs/blSqr.png"
};
};
function sqrsT997() {
    if(document.getElementById("imgSqrs997").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs997").src = "img/sqrs/blSqr.png"
};
};
function sqrsT998() {
    if(document.getElementById("imgSqrs998").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs998").src = "img/sqrs/blSqr.png"
};
};
function sqrsT999() {
    if(document.getElementById("imgSqrs999").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs999").src = "img/sqrs/blSqr.png"
};
};
function sqrsT1000() {
    if(document.getElementById("imgSqrs1000").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1000").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1001() {
    if(document.getElementById("imgSqrs1001").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1001").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1002() {
    if(document.getElementById("imgSqrs1002").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1002").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1003() {
    if(document.getElementById("imgSqrs1003").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1003").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1004() {
    if(document.getElementById("imgSqrs1004").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1004").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1005() {
    if(document.getElementById("imgSqrs1005").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1005").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1006() {
    if(document.getElementById("imgSqrs1006").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1006").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1007() {
    if(document.getElementById("imgSqrs1007").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1007").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1008() {
    if(document.getElementById("imgSqrs1008").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1008").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1009() {
    if(document.getElementById("imgSqrs1009").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1009").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1010() {
    if(document.getElementById("imgSqrs1010").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1010").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1011() {
    if(document.getElementById("imgSqrs1011").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1011").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1012() {
    if(document.getElementById("imgSqrs1012").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1012").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1013() {
    if(document.getElementById("imgSqrs1013").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1013").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1014() {
    if(document.getElementById("imgSqrs1014").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1014").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1015() {
    if(document.getElementById("imgSqrs1015").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1015").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1016() {
    if(document.getElementById("imgSqrs1016").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1016").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1017() {
    if(document.getElementById("imgSqrs1017").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1017").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1018() {
    if(document.getElementById("imgSqrs1018").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1018").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1019() {
    if(document.getElementById("imgSqrs1019").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1019").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1020() {
    if(document.getElementById("imgSqrs1020").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1020").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1021() {
    if(document.getElementById("imgSqrs1021").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1021").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1022() {
    if(document.getElementById("imgSqrs1022").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1022").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1023() {
    if(document.getElementById("imgSqrs1023").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1023").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1024() {
    if(document.getElementById("imgSqrs1024").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1024").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1025() {
    if(document.getElementById("imgSqrs1025").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1025").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1026() {
    if(document.getElementById("imgSqrs1026").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1026").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1027() {
    if(document.getElementById("imgSqrs1027").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1027").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1028() {
    if(document.getElementById("imgSqrs1028").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1028").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1029() {
    if(document.getElementById("imgSqrs1029").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1029").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1030() {
    if(document.getElementById("imgSqrs1030").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1030").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1031() {
    if(document.getElementById("imgSqrs1031").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1031").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1032() {
    if(document.getElementById("imgSqrs1032").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1032").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1033() {
    if(document.getElementById("imgSqrs1033").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1033").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1034() {
    if(document.getElementById("imgSqrs1034").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1034").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1035() {
    if(document.getElementById("imgSqrs1035").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1035").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1036() {
    if(document.getElementById("imgSqrs1036").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1036").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1037() {
    if(document.getElementById("imgSqrs1037").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1037").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1038() {
    if(document.getElementById("imgSqrs1038").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1038").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1039() {
    if(document.getElementById("imgSqrs1039").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1039").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1040() {
    if(document.getElementById("imgSqrs1040").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1040").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1041() {
    if(document.getElementById("imgSqrs1041").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1041").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1042() {
    if(document.getElementById("imgSqrs1042").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1042").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1043() {
    if(document.getElementById("imgSqrs1043").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1043").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1044() {
    if(document.getElementById("imgSqrs1044").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1044").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1045() {
    if(document.getElementById("imgSqrs1045").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1045").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1046() {
    if(document.getElementById("imgSqrs1046").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1046").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1047() {
    if(document.getElementById("imgSqrs1047").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1047").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1048() {
    if(document.getElementById("imgSqrs1048").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1048").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1049() {
    if(document.getElementById("imgSqrs1049").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1049").src = "img/sqrs/blSqr.png"
};
};
function sqrsU1050() {
    if(document.getElementById("imgSqrs1050").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1050").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1051() {
    if(document.getElementById("imgSqrs1051").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1051").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1052() {
    if(document.getElementById("imgSqrs1052").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1052").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1053() {
    if(document.getElementById("imgSqrs1053").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1053").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1054() {
    if(document.getElementById("imgSqrs1054").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1054").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1055() {
    if(document.getElementById("imgSqrs1055").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1055").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1056() {
    if(document.getElementById("imgSqrs1056").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1056").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1057() {
    if(document.getElementById("imgSqrs1057").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1057").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1058() {
    if(document.getElementById("imgSqrs1058").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1058").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1059() {
    if(document.getElementById("imgSqrs1059").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1059").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1060() {
    if(document.getElementById("imgSqrs1060").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1060").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1061() {
    if(document.getElementById("imgSqrs1061").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1061").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1062() {
    if(document.getElementById("imgSqrs1062").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1062").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1063() {
    if(document.getElementById("imgSqrs1063").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1063").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1064() {
    if(document.getElementById("imgSqrs1064").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1064").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1065() {
    if(document.getElementById("imgSqrs1065").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1065").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1066() {
    if(document.getElementById("imgSqrs1066").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1066").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1067() {
    if(document.getElementById("imgSqrs1067").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1067").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1068() {
    if(document.getElementById("imgSqrs1068").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1068").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1069() {
    if(document.getElementById("imgSqrs1069").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1069").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1070() {
    if(document.getElementById("imgSqrs1070").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1070").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1071() {
    if(document.getElementById("imgSqrs1071").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1071").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1072() {
    if(document.getElementById("imgSqrs1072").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1072").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1073() {
    if(document.getElementById("imgSqrs1073").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1073").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1074() {
    if(document.getElementById("imgSqrs1074").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1074").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1075() {
    if(document.getElementById("imgSqrs1075").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1075").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1076() {
    if(document.getElementById("imgSqrs1076").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1076").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1077() {
    if(document.getElementById("imgSqrs1077").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1077").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1078() {
    if(document.getElementById("imgSqrs1078").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1078").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1079() {
    if(document.getElementById("imgSqrs1079").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1079").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1080() {
    if(document.getElementById("imgSqrs1080").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1080").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1081() {
    if(document.getElementById("imgSqrs1081").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1081").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1082() {
    if(document.getElementById("imgSqrs1082").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1082").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1083() {
    if(document.getElementById("imgSqrs1083").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1083").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1084() {
    if(document.getElementById("imgSqrs1084").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1084").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1085() {
    if(document.getElementById("imgSqrs1085").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1085").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1086() {
    if(document.getElementById("imgSqrs1086").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1086").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1087() {
    if(document.getElementById("imgSqrs1087").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1087").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1088() {
    if(document.getElementById("imgSqrs1088").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1088").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1089() {
    if(document.getElementById("imgSqrs1089").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1089").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1090() {
    if(document.getElementById("imgSqrs1090").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1090").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1091() {
    if(document.getElementById("imgSqrs1091").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1091").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1092() {
    if(document.getElementById("imgSqrs1092").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1092").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1093() {
    if(document.getElementById("imgSqrs1093").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1093").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1094() {
    if(document.getElementById("imgSqrs1094").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1094").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1095() {
    if(document.getElementById("imgSqrs1095").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1095").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1096() {
    if(document.getElementById("imgSqrs1096").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1096").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1097() {
    if(document.getElementById("imgSqrs1097").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1097").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1098() {
    if(document.getElementById("imgSqrs1098").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1098").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1099() {
    if(document.getElementById("imgSqrs1099").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1099").src = "img/sqrs/blSqr.png"
};
};
function sqrsV1100() {
    if(document.getElementById("imgSqrs1100").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1100").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1101() {
    if(document.getElementById("imgSqrs1101").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1101").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1102() {
    if(document.getElementById("imgSqrs1102").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1102").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1103() {
    if(document.getElementById("imgSqrs1103").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1103").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1104() {
    if(document.getElementById("imgSqrs1104").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1104").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1105() {
    if(document.getElementById("imgSqrs1105").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1105").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1106() {
    if(document.getElementById("imgSqrs1106").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1106").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1107() {
    if(document.getElementById("imgSqrs1107").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1107").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1108() {
    if(document.getElementById("imgSqrs1108").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1108").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1109() {
    if(document.getElementById("imgSqrs1109").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1109").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1110() {
    if(document.getElementById("imgSqrs1110").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1110").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1111() {
    if(document.getElementById("imgSqrs1111").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1111").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1112() {
    if(document.getElementById("imgSqrs1112").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1112").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1113() {
    if(document.getElementById("imgSqrs1113").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1113").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1114() {
    if(document.getElementById("imgSqrs1114").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1114").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1115() {
    if(document.getElementById("imgSqrs1115").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1115").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1116() {
    if(document.getElementById("imgSqrs1116").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1116").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1117() {
    if(document.getElementById("imgSqrs1117").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1117").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1118() {
    if(document.getElementById("imgSqrs1118").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1118").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1119() {
    if(document.getElementById("imgSqrs1119").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1119").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1120() {
    if(document.getElementById("imgSqrs1120").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1120").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1121() {
    if(document.getElementById("imgSqrs1121").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1121").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1122() {
    if(document.getElementById("imgSqrs1122").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1122").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1123() {
    if(document.getElementById("imgSqrs1123").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1123").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1124() {
    if(document.getElementById("imgSqrs1124").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1124").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1125() {
    if(document.getElementById("imgSqrs1125").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1125").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1126() {
    if(document.getElementById("imgSqrs1126").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1126").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1127() {
    if(document.getElementById("imgSqrs1127").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1127").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1128() {
    if(document.getElementById("imgSqrs1128").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1128").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1129() {
    if(document.getElementById("imgSqrs1129").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1129").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1130() {
    if(document.getElementById("imgSqrs1130").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1130").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1131() {
    if(document.getElementById("imgSqrs1131").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1131").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1132() {
    if(document.getElementById("imgSqrs1132").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1132").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1133() {
    if(document.getElementById("imgSqrs1133").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1133").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1134() {
    if(document.getElementById("imgSqrs1134").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1134").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1135() {
    if(document.getElementById("imgSqrs1135").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1135").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1136() {
    if(document.getElementById("imgSqrs1136").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1136").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1137() {
    if(document.getElementById("imgSqrs1137").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1137").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1138() {
    if(document.getElementById("imgSqrs1138").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1138").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1139() {
    if(document.getElementById("imgSqrs1139").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1139").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1140() {
    if(document.getElementById("imgSqrs1140").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1140").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1141() {
    if(document.getElementById("imgSqrs1141").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1141").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1142() {
    if(document.getElementById("imgSqrs1142").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1142").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1143() {
    if(document.getElementById("imgSqrs1143").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1143").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1144() {
    if(document.getElementById("imgSqrs1144").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1144").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1145() {
    if(document.getElementById("imgSqrs1145").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1145").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1146() {
    if(document.getElementById("imgSqrs1146").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1146").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1147() {
    if(document.getElementById("imgSqrs1147").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1147").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1148() {
    if(document.getElementById("imgSqrs1148").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1148").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1149() {
    if(document.getElementById("imgSqrs1149").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1149").src = "img/sqrs/blSqr.png"
};
};
function sqrsW1150() {
    if(document.getElementById("imgSqrs1150").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1150").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1151() {
    if(document.getElementById("imgSqrs1151").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1151").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1152() {
    if(document.getElementById("imgSqrs1152").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1152").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1153() {
    if(document.getElementById("imgSqrs1153").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1153").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1154() {
    if(document.getElementById("imgSqrs1154").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1154").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1155() {
    if(document.getElementById("imgSqrs1155").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1155").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1156() {
    if(document.getElementById("imgSqrs1156").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1156").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1157() {
    if(document.getElementById("imgSqrs1157").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1157").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1158() {
    if(document.getElementById("imgSqrs1158").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1158").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1159() {
    if(document.getElementById("imgSqrs1159").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1159").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1160() {
    if(document.getElementById("imgSqrs1160").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1160").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1161() {
    if(document.getElementById("imgSqrs1161").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1161").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1162() {
    if(document.getElementById("imgSqrs1162").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1162").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1163() {
    if(document.getElementById("imgSqrs1163").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1163").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1164() {
    if(document.getElementById("imgSqrs1164").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1164").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1165() {
    if(document.getElementById("imgSqrs1165").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1165").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1166() {
    if(document.getElementById("imgSqrs1166").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1166").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1167() {
    if(document.getElementById("imgSqrs1167").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1167").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1168() {
    if(document.getElementById("imgSqrs1168").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1168").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1169() {
    if(document.getElementById("imgSqrs1169").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1169").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1170() {
    if(document.getElementById("imgSqrs1170").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1170").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1171() {
    if(document.getElementById("imgSqrs1171").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1171").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1172() {
    if(document.getElementById("imgSqrs1172").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1172").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1173() {
    if(document.getElementById("imgSqrs1173").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1173").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1174() {
    if(document.getElementById("imgSqrs1174").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1174").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1175() {
    if(document.getElementById("imgSqrs1175").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1175").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1176() {
    if(document.getElementById("imgSqrs1176").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1176").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1177() {
    if(document.getElementById("imgSqrs1177").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1177").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1178() {
    if(document.getElementById("imgSqrs1178").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1178").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1179() {
    if(document.getElementById("imgSqrs1179").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1179").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1180() {
    if(document.getElementById("imgSqrs1180").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1180").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1181() {
    if(document.getElementById("imgSqrs1181").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1181").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1182() {
    if(document.getElementById("imgSqrs1182").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1182").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1183() {
    if(document.getElementById("imgSqrs1183").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1183").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1184() {
    if(document.getElementById("imgSqrs1184").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1184").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1185() {
    if(document.getElementById("imgSqrs1185").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1185").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1186() {
    if(document.getElementById("imgSqrs1186").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1186").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1187() {
    if(document.getElementById("imgSqrs1187").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1187").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1188() {
    if(document.getElementById("imgSqrs1188").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1188").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1189() {
    if(document.getElementById("imgSqrs1189").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1189").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1190() {
    if(document.getElementById("imgSqrs1190").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1190").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1191() {
    if(document.getElementById("imgSqrs1191").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1191").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1192() {
    if(document.getElementById("imgSqrs1192").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1192").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1193() {
    if(document.getElementById("imgSqrs1193").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1193").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1194() {
    if(document.getElementById("imgSqrs1194").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1194").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1195() {
    if(document.getElementById("imgSqrs1195").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1195").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1196() {
    if(document.getElementById("imgSqrs1196").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1196").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1197() {
    if(document.getElementById("imgSqrs1197").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1197").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1198() {
    if(document.getElementById("imgSqrs1198").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1198").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1199() {
    if(document.getElementById("imgSqrs1199").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1199").src = "img/sqrs/blSqr.png"
};
};
function sqrsX1200() {
    if(document.getElementById("imgSqrs1200").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1200").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1201() {
    if(document.getElementById("imgSqrs1201").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1201").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1202() {
    if(document.getElementById("imgSqrs1202").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1202").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1203() {
    if(document.getElementById("imgSqrs1203").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1203").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1204() {
    if(document.getElementById("imgSqrs1204").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1204").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1205() {
    if(document.getElementById("imgSqrs1205").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1205").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1206() {
    if(document.getElementById("imgSqrs1206").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1206").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1207() {
    if(document.getElementById("imgSqrs1207").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1207").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1208() {
    if(document.getElementById("imgSqrs1208").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1208").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1209() {
    if(document.getElementById("imgSqrs1209").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1209").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1210() {
    if(document.getElementById("imgSqrs1210").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1210").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1211() {
    if(document.getElementById("imgSqrs1211").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1211").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1212() {
    if(document.getElementById("imgSqrs1212").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1212").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1213() {
    if(document.getElementById("imgSqrs1213").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1213").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1214() {
    if(document.getElementById("imgSqrs1214").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1214").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1215() {
    if(document.getElementById("imgSqrs1215").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1215").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1216() {
    if(document.getElementById("imgSqrs1216").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1216").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1217() {
    if(document.getElementById("imgSqrs1217").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1217").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1218() {
    if(document.getElementById("imgSqrs1218").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1218").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1219() {
    if(document.getElementById("imgSqrs1219").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1219").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1220() {
    if(document.getElementById("imgSqrs1220").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1220").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1221() {
    if(document.getElementById("imgSqrs1221").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1221").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1222() {
    if(document.getElementById("imgSqrs1222").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1222").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1223() {
    if(document.getElementById("imgSqrs1223").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1223").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1224() {
    if(document.getElementById("imgSqrs1224").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1224").src = "img/sqrs/blSqr.png"
};
};
function sqrsY1225() {
    if(document.getElementById("imgSqrs1225").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1225").src = "img/sqrs/blSqr.png"
};
};

function sqrsA1b() {
    if(document.getElementById("imgSqrs1").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1").src = "img/sqrs/wSqr.png"
};
};
function sqrsA2b() {
    if(document.getElementById("imgSqrs2").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2").src = "img/sqrs/wSqr.png"
};
};
function sqrsA3b() {
    if(document.getElementById("imgSqrs3").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs3").src = "img/sqrs/wSqr.png"
};
};
function sqrsA4b() {
    if(document.getElementById("imgSqrs4").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs4").src = "img/sqrs/wSqr.png"
};
};
function sqrsA5b() {
    if(document.getElementById("imgSqrs5").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs5").src = "img/sqrs/wSqr.png"
};
};
function sqrsA6b() {
    if(document.getElementById("imgSqrs6").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs6").src = "img/sqrs/wSqr.png"
};
};
function sqrsA7b() {
    if(document.getElementById("imgSqrs7").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs7").src = "img/sqrs/wSqr.png"
};
};
function sqrsA8b() {
    if(document.getElementById("imgSqrs8").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs8").src = "img/sqrs/wSqr.png"
};
};
function sqrsA9b() {
    if(document.getElementById("imgSqrs9").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs9").src = "img/sqrs/wSqr.png"
};
};
function sqrsA10b() {
    if(document.getElementById("imgSqrs10").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs10").src = "img/sqrs/wSqr.png"
};
};
function sqrsA11b() {
    if(document.getElementById("imgSqrs11").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs11").src = "img/sqrs/wSqr.png"
};
};
function sqrsA12b() {
    if(document.getElementById("imgSqrs12").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs12").src = "img/sqrs/wSqr.png"
};
};
function sqrsA13b() {
    if(document.getElementById("imgSqrs13").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs13").src = "img/sqrs/wSqr.png"
};
};
function sqrsA14b() {
    if(document.getElementById("imgSqrs14").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs14").src = "img/sqrs/wSqr.png"
};
};
function sqrsA15b() {
    if(document.getElementById("imgSqrs15").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs15").src = "img/sqrs/wSqr.png"
};
};
function sqrsA16b() {
    if(document.getElementById("imgSqrs16").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs16").src = "img/sqrs/wSqr.png"
};
};
function sqrsA17b() {
    if(document.getElementById("imgSqrs17").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs17").src = "img/sqrs/wSqr.png"
};
};
function sqrsA18b() {
    if(document.getElementById("imgSqrs18").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs18").src = "img/sqrs/wSqr.png"
};
};
function sqrsA19b() {
    if(document.getElementById("imgSqrs19").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs19").src = "img/sqrs/wSqr.png"
};
};
function sqrsA20b() {
    if(document.getElementById("imgSqrs20").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs20").src = "img/sqrs/wSqr.png"
};
};
function sqrsA21b() {
    if(document.getElementById("imgSqrs21").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs21").src = "img/sqrs/wSqr.png"
};
};
function sqrsA22b() {
    if(document.getElementById("imgSqrs22").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs22").src = "img/sqrs/wSqr.png"
};
};
function sqrsA23b() {
    if(document.getElementById("imgSqrs23").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs23").src = "img/sqrs/wSqr.png"
};
};
function sqrsA24b() {
    if(document.getElementById("imgSqrs24").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs24").src = "img/sqrs/wSqr.png"
};
};
function sqrsA25b() {
    if(document.getElementById("imgSqrs25").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs25").src = "img/sqrs/wSqr.png"
};
};
function sqrsA26b() {
    if(document.getElementById("imgSqrs26").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs26").src = "img/sqrs/wSqr.png"
};
};
function sqrsA27b() {
    if(document.getElementById("imgSqrs27").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs27").src = "img/sqrs/wSqr.png"
};
};
function sqrsA28b() {
    if(document.getElementById("imgSqrs28").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs28").src = "img/sqrs/wSqr.png"
};
};
function sqrsA29b() {
    if(document.getElementById("imgSqrs29").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs29").src = "img/sqrs/wSqr.png"
};
};
function sqrsA30b() {
    if(document.getElementById("imgSqrs30").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs30").src = "img/sqrs/wSqr.png"
};
};
function sqrsA31b() {
    if(document.getElementById("imgSqrs31").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs31").src = "img/sqrs/wSqr.png"
};
};
function sqrsA32b() {
    if(document.getElementById("imgSqrs32").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs32").src = "img/sqrs/wSqr.png"
};
};
function sqrsA33b() {
    if(document.getElementById("imgSqrs33").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs33").src = "img/sqrs/wSqr.png"
};
};
function sqrsA34b() {
    if(document.getElementById("imgSqrs34").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs34").src = "img/sqrs/wSqr.png"
};
};
function sqrsA35b() {
    if(document.getElementById("imgSqrs35").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs35").src = "img/sqrs/wSqr.png"
};
};
function sqrsA36b() {
    if(document.getElementById("imgSqrs36").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs36").src = "img/sqrs/wSqr.png"
};
};
function sqrsA37b() {
    if(document.getElementById("imgSqrs37").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs37").src = "img/sqrs/wSqr.png"
};
};
function sqrsA38b() {
    if(document.getElementById("imgSqrs38").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs38").src = "img/sqrs/wSqr.png"
};
};
function sqrsA39b() {
    if(document.getElementById("imgSqrs39").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs39").src = "img/sqrs/wSqr.png"
};
};
function sqrsA40b() {
    if(document.getElementById("imgSqrs40").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs40").src = "img/sqrs/wSqr.png"
};
};
function sqrsA41b() {
    if(document.getElementById("imgSqrs41").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs41").src = "img/sqrs/wSqr.png"
};
};
function sqrsA42b() {
    if(document.getElementById("imgSqrs42").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs42").src = "img/sqrs/wSqr.png"
};
};
function sqrsA43b() {
    if(document.getElementById("imgSqrs43").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs43").src = "img/sqrs/wSqr.png"
};
};
function sqrsA44b() {
    if(document.getElementById("imgSqrs44").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs44").src = "img/sqrs/wSqr.png"
};
};
function sqrsA45b() {
    if(document.getElementById("imgSqrs45").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs45").src = "img/sqrs/wSqr.png"
};
};
function sqrsA46b() {
    if(document.getElementById("imgSqrs46").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs46").src = "img/sqrs/wSqr.png"
};
};
function sqrsA47b() {
    if(document.getElementById("imgSqrs47").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs47").src = "img/sqrs/wSqr.png"
};
};
function sqrsA48b() {
    if(document.getElementById("imgSqrs48").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs48").src = "img/sqrs/wSqr.png"
};
};
function sqrsA49b() {
    if(document.getElementById("imgSqrs49").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs49").src = "img/sqrs/wSqr.png"
};
};
function sqrsA50b() {
    if(document.getElementById("imgSqrs50").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs50").src = "img/sqrs/wSqr.png"
};
};
function sqrsB51b() {
    if(document.getElementById("imgSqrs51").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs51").src = "img/sqrs/wSqr.png"
};
};
function sqrsB52b() {
    if(document.getElementById("imgSqrs52").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs52").src = "img/sqrs/wSqr.png"
};
};
function sqrsB53b() {
    if(document.getElementById("imgSqrs53").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs53").src = "img/sqrs/wSqr.png"
};
};
function sqrsB54b() {
    if(document.getElementById("imgSqrs54").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs54").src = "img/sqrs/wSqr.png"
};
};
function sqrsB55b() {
    if(document.getElementById("imgSqrs55").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs55").src = "img/sqrs/wSqr.png"
};
};
function sqrsB56b() {
    if(document.getElementById("imgSqrs56").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs56").src = "img/sqrs/wSqr.png"
};
};
function sqrsB57b() {
    if(document.getElementById("imgSqrs57").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs57").src = "img/sqrs/wSqr.png"
};
};
function sqrsB58b() {
    if(document.getElementById("imgSqrs58").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs58").src = "img/sqrs/wSqr.png"
};
};
function sqrsB59b() {
    if(document.getElementById("imgSqrs59").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs59").src = "img/sqrs/wSqr.png"
};
};
function sqrsB60b() {
    if(document.getElementById("imgSqrs60").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs60").src = "img/sqrs/wSqr.png"
};
};
function sqrsB61b() {
    if(document.getElementById("imgSqrs61").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs61").src = "img/sqrs/wSqr.png"
};
};
function sqrsB62b() {
    if(document.getElementById("imgSqrs62").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs62").src = "img/sqrs/wSqr.png"
};
};
function sqrsB63b() {
    if(document.getElementById("imgSqrs63").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs63").src = "img/sqrs/wSqr.png"
};
};
function sqrsB64b() {
    if(document.getElementById("imgSqrs64").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs64").src = "img/sqrs/wSqr.png"
};
};
function sqrsB65b() {
    if(document.getElementById("imgSqrs65").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs65").src = "img/sqrs/wSqr.png"
};
};
function sqrsB66b() {
    if(document.getElementById("imgSqrs66").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs66").src = "img/sqrs/wSqr.png"
};
};
function sqrsB67b() {
    if(document.getElementById("imgSqrs67").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs67").src = "img/sqrs/wSqr.png"
};
};
function sqrsB68b() {
    if(document.getElementById("imgSqrs68").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs68").src = "img/sqrs/wSqr.png"
};
};
function sqrsB69b() {
    if(document.getElementById("imgSqrs69").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs69").src = "img/sqrs/wSqr.png"
};
};
function sqrsB70b() {
    if(document.getElementById("imgSqrs70").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs70").src = "img/sqrs/wSqr.png"
};
};
function sqrsB71b() {
    if(document.getElementById("imgSqrs71").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs71").src = "img/sqrs/wSqr.png"
};
};
function sqrsB72b() {
    if(document.getElementById("imgSqrs72").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs72").src = "img/sqrs/wSqr.png"
};
};
function sqrsB73b() {
    if(document.getElementById("imgSqrs73").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs73").src = "img/sqrs/wSqr.png"
};
};
function sqrsB74b() {
    if(document.getElementById("imgSqrs74").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs74").src = "img/sqrs/wSqr.png"
};
};
function sqrsB75b() {
    if(document.getElementById("imgSqrs75").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs75").src = "img/sqrs/wSqr.png"
};
};
function sqrsB76b() {
    if(document.getElementById("imgSqrs76").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs76").src = "img/sqrs/wSqr.png"
};
};
function sqrsB77b() {
    if(document.getElementById("imgSqrs77").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs77").src = "img/sqrs/wSqr.png"
};
};
function sqrsB78b() {
    if(document.getElementById("imgSqrs78").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs78").src = "img/sqrs/wSqr.png"
};
};
function sqrsB79b() {
    if(document.getElementById("imgSqrs79").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs79").src = "img/sqrs/wSqr.png"
};
};
function sqrsB80b() {
    if(document.getElementById("imgSqrs80").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs80").src = "img/sqrs/wSqr.png"
};
};
function sqrsB81b() {
    if(document.getElementById("imgSqrs81").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs81").src = "img/sqrs/wSqr.png"
};
};
function sqrsB82b() {
    if(document.getElementById("imgSqrs82").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs82").src = "img/sqrs/wSqr.png"
};
};
function sqrsB83b() {
    if(document.getElementById("imgSqrs83").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs83").src = "img/sqrs/wSqr.png"
};
};
function sqrsB84b() {
    if(document.getElementById("imgSqrs84").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs84").src = "img/sqrs/wSqr.png"
};
};
function sqrsB85b() {
    if(document.getElementById("imgSqrs85").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs85").src = "img/sqrs/wSqr.png"
};
};
function sqrsB86b() {
    if(document.getElementById("imgSqrs86").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs86").src = "img/sqrs/wSqr.png"
};
};
function sqrsB87b() {
    if(document.getElementById("imgSqrs87").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs87").src = "img/sqrs/wSqr.png"
};
};
function sqrsB88b() {
    if(document.getElementById("imgSqrs88").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs88").src = "img/sqrs/wSqr.png"
};
};
function sqrsB89b() {
    if(document.getElementById("imgSqrs89").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs89").src = "img/sqrs/wSqr.png"
};
};
function sqrsB90b() {
    if(document.getElementById("imgSqrs90").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs90").src = "img/sqrs/wSqr.png"
};
};
function sqrsB91b() {
    if(document.getElementById("imgSqrs91").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs91").src = "img/sqrs/wSqr.png"
};
};
function sqrsB92b() {
    if(document.getElementById("imgSqrs92").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs92").src = "img/sqrs/wSqr.png"
};
};
function sqrsB93b() {
    if(document.getElementById("imgSqrs93").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs93").src = "img/sqrs/wSqr.png"
};
};
function sqrsB94b() {
    if(document.getElementById("imgSqrs94").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs94").src = "img/sqrs/wSqr.png"
};
};
function sqrsB95b() {
    if(document.getElementById("imgSqrs95").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs95").src = "img/sqrs/wSqr.png"
};
};
function sqrsB96b() {
    if(document.getElementById("imgSqrs96").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs96").src = "img/sqrs/wSqr.png"
};
};
function sqrsB97b() {
    if(document.getElementById("imgSqrs97").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs97").src = "img/sqrs/wSqr.png"
};
};
function sqrsB98b() {
    if(document.getElementById("imgSqrs98").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs98").src = "img/sqrs/wSqr.png"
};
};
function sqrsB99b() {
    if(document.getElementById("imgSqrs99").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs99").src = "img/sqrs/wSqr.png"
};
};
function sqrsB100b() {
    if(document.getElementById("imgSqrs100").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs100").src = "img/sqrs/wSqr.png"
};
};
function sqrsC101b() {
    if(document.getElementById("imgSqrs101").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs101").src = "img/sqrs/wSqr.png"
};
};
function sqrsC102b() {
    if(document.getElementById("imgSqrs102").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs102").src = "img/sqrs/wSqr.png"
};
};
function sqrsC103b() {
    if(document.getElementById("imgSqrs103").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs103").src = "img/sqrs/wSqr.png"
};
};
function sqrsC104b() {
    if(document.getElementById("imgSqrs104").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs104").src = "img/sqrs/wSqr.png"
};
};
function sqrsC105b() {
    if(document.getElementById("imgSqrs105").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs105").src = "img/sqrs/wSqr.png"
};
};
function sqrsC106b() {
    if(document.getElementById("imgSqrs106").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs106").src = "img/sqrs/wSqr.png"
};
};
function sqrsC107b() {
    if(document.getElementById("imgSqrs107").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs107").src = "img/sqrs/wSqr.png"
};
};
function sqrsC108b() {
    if(document.getElementById("imgSqrs108").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs108").src = "img/sqrs/wSqr.png"
};
};
function sqrsC109b() {
    if(document.getElementById("imgSqrs109").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs109").src = "img/sqrs/wSqr.png"
};
};
function sqrsC110b() {
    if(document.getElementById("imgSqrs110").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs110").src = "img/sqrs/wSqr.png"
};
};
function sqrsC111b() {
    if(document.getElementById("imgSqrs111").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs111").src = "img/sqrs/wSqr.png"
};
};
function sqrsC112b() {
    if(document.getElementById("imgSqrs112").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs112").src = "img/sqrs/wSqr.png"
};
};
function sqrsC113b() {
    if(document.getElementById("imgSqrs113").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs113").src = "img/sqrs/wSqr.png"
};
};
function sqrsC114b() {
    if(document.getElementById("imgSqrs114").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs114").src = "img/sqrs/wSqr.png"
};
};
function sqrsC115b() {
    if(document.getElementById("imgSqrs115").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs115").src = "img/sqrs/wSqr.png"
};
};
function sqrsC116b() {
    if(document.getElementById("imgSqrs116").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs116").src = "img/sqrs/wSqr.png"
};
};
function sqrsC117b() {
    if(document.getElementById("imgSqrs117").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs117").src = "img/sqrs/wSqr.png"
};
};
function sqrsC118b() {
    if(document.getElementById("imgSqrs118").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs118").src = "img/sqrs/wSqr.png"
};
};
function sqrsC119b() {
    if(document.getElementById("imgSqrs119").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs119").src = "img/sqrs/wSqr.png"
};
};
function sqrsC120b() {
    if(document.getElementById("imgSqrs120").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs120").src = "img/sqrs/wSqr.png"
};
};
function sqrsC121b() {
    if(document.getElementById("imgSqrs121").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs121").src = "img/sqrs/wSqr.png"
};
};
function sqrsC122b() {
    if(document.getElementById("imgSqrs122").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs122").src = "img/sqrs/wSqr.png"
};
};
function sqrsC123b() {
    if(document.getElementById("imgSqrs123").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs123").src = "img/sqrs/wSqr.png"
};
};
function sqrsC124b() {
    if(document.getElementById("imgSqrs124").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs124").src = "img/sqrs/wSqr.png"
};
};
function sqrsC125b() {
    if(document.getElementById("imgSqrs125").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs125").src = "img/sqrs/wSqr.png"
};
};
function sqrsC126b() {
    if(document.getElementById("imgSqrs126").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs126").src = "img/sqrs/wSqr.png"
};
};
function sqrsC127b() {
    if(document.getElementById("imgSqrs127").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs127").src = "img/sqrs/wSqr.png"
};
};
function sqrsC128b() {
    if(document.getElementById("imgSqrs128").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs128").src = "img/sqrs/wSqr.png"
};
};
function sqrsC129b() {
    if(document.getElementById("imgSqrs129").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs129").src = "img/sqrs/wSqr.png"
};
};
function sqrsC130b() {
    if(document.getElementById("imgSqrs130").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs130").src = "img/sqrs/wSqr.png"
};
};
function sqrsC131b() {
    if(document.getElementById("imgSqrs131").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs131").src = "img/sqrs/wSqr.png"
};
};
function sqrsC132b() {
    if(document.getElementById("imgSqrs132").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs132").src = "img/sqrs/wSqr.png"
};
};
function sqrsC133b() {
    if(document.getElementById("imgSqrs133").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs133").src = "img/sqrs/wSqr.png"
};
};
function sqrsC134b() {
    if(document.getElementById("imgSqrs134").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs134").src = "img/sqrs/wSqr.png"
};
};
function sqrsC135b() {
    if(document.getElementById("imgSqrs135").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs135").src = "img/sqrs/wSqr.png"
};
};
function sqrsC136b() {
    if(document.getElementById("imgSqrs136").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs136").src = "img/sqrs/wSqr.png"
};
};
function sqrsC137b() {
    if(document.getElementById("imgSqrs137").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs137").src = "img/sqrs/wSqr.png"
};
};
function sqrsC138b() {
    if(document.getElementById("imgSqrs138").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs138").src = "img/sqrs/wSqr.png"
};
};
function sqrsC139b() {
    if(document.getElementById("imgSqrs139").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs139").src = "img/sqrs/wSqr.png"
};
};
function sqrsC140b() {
    if(document.getElementById("imgSqrs140").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs140").src = "img/sqrs/wSqr.png"
};
};
function sqrsC141b() {
    if(document.getElementById("imgSqrs141").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs141").src = "img/sqrs/wSqr.png"
};
};
function sqrsC142b() {
    if(document.getElementById("imgSqrs142").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs142").src = "img/sqrs/wSqr.png"
};
};
function sqrsC143b() {
    if(document.getElementById("imgSqrs143").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs143").src = "img/sqrs/wSqr.png"
};
};
function sqrsC144b() {
    if(document.getElementById("imgSqrs144").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs144").src = "img/sqrs/wSqr.png"
};
};
function sqrsC145b() {
    if(document.getElementById("imgSqrs145").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs145").src = "img/sqrs/wSqr.png"
};
};
function sqrsC146b() {
    if(document.getElementById("imgSqrs146").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs146").src = "img/sqrs/wSqr.png"
};
};
function sqrsC147b() {
    if(document.getElementById("imgSqrs147").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs147").src = "img/sqrs/wSqr.png"
};
};
function sqrsC148b() {
    if(document.getElementById("imgSqrs148").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs148").src = "img/sqrs/wSqr.png"
};
};
function sqrsC149b() {
    if(document.getElementById("imgSqrs149").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs149").src = "img/sqrs/wSqr.png"
};
};
function sqrsC150b() {
    if(document.getElementById("imgSqrs150").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs150").src = "img/sqrs/wSqr.png"
};
};
function sqrsD151b() {
    if(document.getElementById("imgSqrs151").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs151").src = "img/sqrs/wSqr.png"
};
};
function sqrsD152b() {
    if(document.getElementById("imgSqrs152").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs152").src = "img/sqrs/wSqr.png"
};
};
function sqrsD153b() {
    if(document.getElementById("imgSqrs153").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs153").src = "img/sqrs/wSqr.png"
};
};
function sqrsD154b() {
    if(document.getElementById("imgSqrs154").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs154").src = "img/sqrs/wSqr.png"
};
};
function sqrsD155b() {
    if(document.getElementById("imgSqrs155").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs155").src = "img/sqrs/wSqr.png"
};
};
function sqrsD156b() {
    if(document.getElementById("imgSqrs156").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs156").src = "img/sqrs/wSqr.png"
};
};
function sqrsD157b() {
    if(document.getElementById("imgSqrs157").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs157").src = "img/sqrs/wSqr.png"
};
};
function sqrsD158b() {
    if(document.getElementById("imgSqrs158").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs158").src = "img/sqrs/wSqr.png"
};
};
function sqrsD159b() {
    if(document.getElementById("imgSqrs159").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs159").src = "img/sqrs/wSqr.png"
};
};
function sqrsD160b() {
    if(document.getElementById("imgSqrs160").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs160").src = "img/sqrs/wSqr.png"
};
};
function sqrsD161b() {
    if(document.getElementById("imgSqrs161").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs161").src = "img/sqrs/wSqr.png"
};
};
function sqrsD162b() {
    if(document.getElementById("imgSqrs162").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs162").src = "img/sqrs/wSqr.png"
};
};
function sqrsD163b() {
    if(document.getElementById("imgSqrs163").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs163").src = "img/sqrs/wSqr.png"
};
};
function sqrsD164b() {
    if(document.getElementById("imgSqrs164").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs164").src = "img/sqrs/wSqr.png"
};
};
function sqrsD165b() {
    if(document.getElementById("imgSqrs165").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs165").src = "img/sqrs/wSqr.png"
};
};
function sqrsD166b() {
    if(document.getElementById("imgSqrs166").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs166").src = "img/sqrs/wSqr.png"
};
};
function sqrsD167b() {
    if(document.getElementById("imgSqrs167").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs167").src = "img/sqrs/wSqr.png"
};
};
function sqrsD168b() {
    if(document.getElementById("imgSqrs168").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs168").src = "img/sqrs/wSqr.png"
};
};
function sqrsD169b() {
    if(document.getElementById("imgSqrs169").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs169").src = "img/sqrs/wSqr.png"
};
};
function sqrsD170b() {
    if(document.getElementById("imgSqrs170").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs170").src = "img/sqrs/wSqr.png"
};
};
function sqrsD171b() {
    if(document.getElementById("imgSqrs171").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs171").src = "img/sqrs/wSqr.png"
};
};
function sqrsD172b() {
    if(document.getElementById("imgSqrs172").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs172").src = "img/sqrs/wSqr.png"
};
};
function sqrsD173b() {
    if(document.getElementById("imgSqrs173").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs173").src = "img/sqrs/wSqr.png"
};
};
function sqrsD174b() {
    if(document.getElementById("imgSqrs174").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs174").src = "img/sqrs/wSqr.png"
};
};
function sqrsD175b() {
    if(document.getElementById("imgSqrs175").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs175").src = "img/sqrs/wSqr.png"
};
};
function sqrsD176b() {
    if(document.getElementById("imgSqrs176").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs176").src = "img/sqrs/wSqr.png"
};
};
function sqrsD177b() {
    if(document.getElementById("imgSqrs177").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs177").src = "img/sqrs/wSqr.png"
};
};
function sqrsD178b() {
    if(document.getElementById("imgSqrs178").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs178").src = "img/sqrs/wSqr.png"
};
};
function sqrsD179b() {
    if(document.getElementById("imgSqrs179").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs179").src = "img/sqrs/wSqr.png"
};
};
function sqrsD180b() {
    if(document.getElementById("imgSqrs180").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs180").src = "img/sqrs/wSqr.png"
};
};
function sqrsD181b() {
    if(document.getElementById("imgSqrs181").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs181").src = "img/sqrs/wSqr.png"
};
};
function sqrsD182b() {
    if(document.getElementById("imgSqrs182").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs182").src = "img/sqrs/wSqr.png"
};
};
function sqrsD183b() {
    if(document.getElementById("imgSqrs183").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs183").src = "img/sqrs/wSqr.png"
};
};
function sqrsD184b() {
    if(document.getElementById("imgSqrs184").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs184").src = "img/sqrs/wSqr.png"
};
};
function sqrsD185b() {
    if(document.getElementById("imgSqrs185").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs185").src = "img/sqrs/wSqr.png"
};
};
function sqrsD186b() {
    if(document.getElementById("imgSqrs186").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs186").src = "img/sqrs/wSqr.png"
};
};
function sqrsD187b() {
    if(document.getElementById("imgSqrs187").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs187").src = "img/sqrs/wSqr.png"
};
};
function sqrsD188b() {
    if(document.getElementById("imgSqrs188").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs188").src = "img/sqrs/wSqr.png"
};
};
function sqrsD189b() {
    if(document.getElementById("imgSqrs189").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs189").src = "img/sqrs/wSqr.png"
};
};
function sqrsD190b() {
    if(document.getElementById("imgSqrs190").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs190").src = "img/sqrs/wSqr.png"
};
};
function sqrsD191b() {
    if(document.getElementById("imgSqrs191").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs191").src = "img/sqrs/wSqr.png"
};
};
function sqrsD192b() {
    if(document.getElementById("imgSqrs192").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs192").src = "img/sqrs/wSqr.png"
};
};
function sqrsD193b() {
    if(document.getElementById("imgSqrs193").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs193").src = "img/sqrs/wSqr.png"
};
};
function sqrsD194b() {
    if(document.getElementById("imgSqrs194").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs194").src = "img/sqrs/wSqr.png"
};
};
function sqrsD195b() {
    if(document.getElementById("imgSqrs195").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs195").src = "img/sqrs/wSqr.png"
};
};
function sqrsD196b() {
    if(document.getElementById("imgSqrs196").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs196").src = "img/sqrs/wSqr.png"
};
};
function sqrsD197b() {
    if(document.getElementById("imgSqrs197").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs197").src = "img/sqrs/wSqr.png"
};
};
function sqrsD198b() {
    if(document.getElementById("imgSqrs198").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs198").src = "img/sqrs/wSqr.png"
};
};
function sqrsD199b() {
    if(document.getElementById("imgSqrs199").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs199").src = "img/sqrs/wSqr.png"
};
};
function sqrsD200b() {
    if(document.getElementById("imgSqrs200").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs200").src = "img/sqrs/wSqr.png"
};
};
function sqrsE201b() {
    if(document.getElementById("imgSqrs201").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs201").src = "img/sqrs/wSqr.png"
};
};
function sqrsE202b() {
    if(document.getElementById("imgSqrs202").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs202").src = "img/sqrs/wSqr.png"
};
};
function sqrsE203b() {
    if(document.getElementById("imgSqrs203").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs203").src = "img/sqrs/wSqr.png"
};
};
function sqrsE204b() {
    if(document.getElementById("imgSqrs204").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs204").src = "img/sqrs/wSqr.png"
};
};
function sqrsE205b() {
    if(document.getElementById("imgSqrs205").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs205").src = "img/sqrs/wSqr.png"
};
};
function sqrsE206b() {
    if(document.getElementById("imgSqrs206").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs206").src = "img/sqrs/wSqr.png"
};
};
function sqrsE207b() {
    if(document.getElementById("imgSqrs207").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs207").src = "img/sqrs/wSqr.png"
};
};
function sqrsE208b() {
    if(document.getElementById("imgSqrs208").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs208").src = "img/sqrs/wSqr.png"
};
};
function sqrsE209b() {
    if(document.getElementById("imgSqrs209").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs209").src = "img/sqrs/wSqr.png"
};
};
function sqrsE210b() {
    if(document.getElementById("imgSqrs210").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs210").src = "img/sqrs/wSqr.png"
};
};
function sqrsE211b() {
    if(document.getElementById("imgSqrs211").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs211").src = "img/sqrs/wSqr.png"
};
};
function sqrsE212b() {
    if(document.getElementById("imgSqrs212").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs212").src = "img/sqrs/wSqr.png"
};
};
function sqrsE213b() {
    if(document.getElementById("imgSqrs213").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs213").src = "img/sqrs/wSqr.png"
};
};
function sqrsE214b() {
    if(document.getElementById("imgSqrs214").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs214").src = "img/sqrs/wSqr.png"
};
};
function sqrsE215b() {
    if(document.getElementById("imgSqrs215").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs215").src = "img/sqrs/wSqr.png"
};
};
function sqrsE216b() {
    if(document.getElementById("imgSqrs216").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs216").src = "img/sqrs/wSqr.png"
};
};
function sqrsE217b() {
    if(document.getElementById("imgSqrs217").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs217").src = "img/sqrs/wSqr.png"
};
};
function sqrsE218b() {
    if(document.getElementById("imgSqrs218").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs218").src = "img/sqrs/wSqr.png"
};
};
function sqrsE219b() {
    if(document.getElementById("imgSqrs219").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs219").src = "img/sqrs/wSqr.png"
};
};
function sqrsE220b() {
    if(document.getElementById("imgSqrs220").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs220").src = "img/sqrs/wSqr.png"
};
};
function sqrsE221b() {
    if(document.getElementById("imgSqrs221").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs221").src = "img/sqrs/wSqr.png"
};
};
function sqrsE222b() {
    if(document.getElementById("imgSqrs222").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs222").src = "img/sqrs/wSqr.png"
};
};
function sqrsE223b() {
    if(document.getElementById("imgSqrs223").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs223").src = "img/sqrs/wSqr.png"
};
};
function sqrsE224b() {
    if(document.getElementById("imgSqrs224").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs224").src = "img/sqrs/wSqr.png"
};
};
function sqrsE225b() {
    if(document.getElementById("imgSqrs225").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs225").src = "img/sqrs/wSqr.png"
};
};
function sqrsE226b() {
    if(document.getElementById("imgSqrs226").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs226").src = "img/sqrs/wSqr.png"
};
};
function sqrsE227b() {
    if(document.getElementById("imgSqrs227").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs227").src = "img/sqrs/wSqr.png"
};
};
function sqrsE228b() {
    if(document.getElementById("imgSqrs228").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs228").src = "img/sqrs/wSqr.png"
};
};
function sqrsE229b() {
    if(document.getElementById("imgSqrs229").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs229").src = "img/sqrs/wSqr.png"
};
};
function sqrsE230b() {
    if(document.getElementById("imgSqrs230").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs230").src = "img/sqrs/wSqr.png"
};
};
function sqrsE231b() {
    if(document.getElementById("imgSqrs231").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs231").src = "img/sqrs/wSqr.png"
};
};
function sqrsE232b() {
    if(document.getElementById("imgSqrs232").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs232").src = "img/sqrs/wSqr.png"
};
};
function sqrsE233b() {
    if(document.getElementById("imgSqrs233").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs233").src = "img/sqrs/wSqr.png"
};
};
function sqrsE234b() {
    if(document.getElementById("imgSqrs234").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs234").src = "img/sqrs/wSqr.png"
};
};
function sqrsE235b() {
    if(document.getElementById("imgSqrs235").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs235").src = "img/sqrs/wSqr.png"
};
};
function sqrsE236b() {
    if(document.getElementById("imgSqrs236").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs236").src = "img/sqrs/wSqr.png"
};
};
function sqrsE237b() {
    if(document.getElementById("imgSqrs237").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs237").src = "img/sqrs/wSqr.png"
};
};
function sqrsE238b() {
    if(document.getElementById("imgSqrs238").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs238").src = "img/sqrs/wSqr.png"
};
};
function sqrsE239b() {
    if(document.getElementById("imgSqrs239").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs239").src = "img/sqrs/wSqr.png"
};
};
function sqrsE240b() {
    if(document.getElementById("imgSqrs240").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs240").src = "img/sqrs/wSqr.png"
};
};
function sqrsE241b() {
    if(document.getElementById("imgSqrs241").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs241").src = "img/sqrs/wSqr.png"
};
};
function sqrsE242b() {
    if(document.getElementById("imgSqrs242").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs242").src = "img/sqrs/wSqr.png"
};
};
function sqrsE243b() {
    if(document.getElementById("imgSqrs243").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs243").src = "img/sqrs/wSqr.png"
};
};
function sqrsE244b() {
    if(document.getElementById("imgSqrs244").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs244").src = "img/sqrs/wSqr.png"
};
};
function sqrsE245b() {
    if(document.getElementById("imgSqrs245").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs245").src = "img/sqrs/wSqr.png"
};
};
function sqrsE246b() {
    if(document.getElementById("imgSqrs246").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs246").src = "img/sqrs/wSqr.png"
};
};
function sqrsE247b() {
    if(document.getElementById("imgSqrs247").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs247").src = "img/sqrs/wSqr.png"
};
};
function sqrsE248b() {
    if(document.getElementById("imgSqrs248").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs248").src = "img/sqrs/wSqr.png"
};
};
function sqrsE249b() {
    if(document.getElementById("imgSqrs249").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs249").src = "img/sqrs/wSqr.png"
};
};
function sqrsE250b() {
    if(document.getElementById("imgSqrs250").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs250").src = "img/sqrs/wSqr.png"
};
};
function sqrsF251b() {
    if(document.getElementById("imgSqrs251").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs251").src = "img/sqrs/wSqr.png"
};
};
function sqrsF252b() {
    if(document.getElementById("imgSqrs252").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs252").src = "img/sqrs/wSqr.png"
};
};
function sqrsF253b() {
    if(document.getElementById("imgSqrs253").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs253").src = "img/sqrs/wSqr.png"
};
};
function sqrsF254b() {
    if(document.getElementById("imgSqrs254").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs254").src = "img/sqrs/wSqr.png"
};
};
function sqrsF255b() {
    if(document.getElementById("imgSqrs255").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs255").src = "img/sqrs/wSqr.png"
};
};
function sqrsF256b() {
    if(document.getElementById("imgSqrs256").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs256").src = "img/sqrs/wSqr.png"
};
};
function sqrsF257b() {
    if(document.getElementById("imgSqrs257").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs257").src = "img/sqrs/wSqr.png"
};
};
function sqrsF258b() {
    if(document.getElementById("imgSqrs258").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs258").src = "img/sqrs/wSqr.png"
};
};
function sqrsF259b() {
    if(document.getElementById("imgSqrs259").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs259").src = "img/sqrs/wSqr.png"
};
};
function sqrsF260b() {
    if(document.getElementById("imgSqrs260").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs260").src = "img/sqrs/wSqr.png"
};
};
function sqrsF261b() {
    if(document.getElementById("imgSqrs261").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs261").src = "img/sqrs/wSqr.png"
};
};
function sqrsF262b() {
    if(document.getElementById("imgSqrs262").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs262").src = "img/sqrs/wSqr.png"
};
};
function sqrsF263b() {
    if(document.getElementById("imgSqrs263").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs263").src = "img/sqrs/wSqr.png"
};
};
function sqrsF264b() {
    if(document.getElementById("imgSqrs264").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs264").src = "img/sqrs/wSqr.png"
};
};
function sqrsF265b() {
    if(document.getElementById("imgSqrs265").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs265").src = "img/sqrs/wSqr.png"
};
};
function sqrsF266b() {
    if(document.getElementById("imgSqrs266").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs266").src = "img/sqrs/wSqr.png"
};
};
function sqrsF267b() {
    if(document.getElementById("imgSqrs267").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs267").src = "img/sqrs/wSqr.png"
};
};
function sqrsF268b() {
    if(document.getElementById("imgSqrs268").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs268").src = "img/sqrs/wSqr.png"
};
};
function sqrsF269b() {
    if(document.getElementById("imgSqrs269").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs269").src = "img/sqrs/wSqr.png"
};
};
function sqrsF270b() {
    if(document.getElementById("imgSqrs270").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs270").src = "img/sqrs/wSqr.png"
};
};
function sqrsF271b() {
    if(document.getElementById("imgSqrs271").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs271").src = "img/sqrs/wSqr.png"
};
};
function sqrsF272b() {
    if(document.getElementById("imgSqrs272").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs272").src = "img/sqrs/wSqr.png"
};
};
function sqrsF273b() {
    if(document.getElementById("imgSqrs273").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs273").src = "img/sqrs/wSqr.png"
};
};
function sqrsF274b() {
    if(document.getElementById("imgSqrs274").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs274").src = "img/sqrs/wSqr.png"
};
};
function sqrsF275b() {
    if(document.getElementById("imgSqrs275").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs275").src = "img/sqrs/wSqr.png"
};
};
function sqrsF276b() {
    if(document.getElementById("imgSqrs276").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs276").src = "img/sqrs/wSqr.png"
};
};
function sqrsF277b() {
    if(document.getElementById("imgSqrs277").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs277").src = "img/sqrs/wSqr.png"
};
};
function sqrsF278b() {
    if(document.getElementById("imgSqrs278").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs278").src = "img/sqrs/wSqr.png"
};
};
function sqrsF279b() {
    if(document.getElementById("imgSqrs279").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs279").src = "img/sqrs/wSqr.png"
};
};
function sqrsF280b() {
    if(document.getElementById("imgSqrs280").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs280").src = "img/sqrs/wSqr.png"
};
};
function sqrsF281b() {
    if(document.getElementById("imgSqrs281").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs281").src = "img/sqrs/wSqr.png"
};
};
function sqrsF282b() {
    if(document.getElementById("imgSqrs282").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs282").src = "img/sqrs/wSqr.png"
};
};
function sqrsF283b() {
    if(document.getElementById("imgSqrs283").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs283").src = "img/sqrs/wSqr.png"
};
};
function sqrsF284b() {
    if(document.getElementById("imgSqrs284").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs284").src = "img/sqrs/wSqr.png"
};
};
function sqrsF285b() {
    if(document.getElementById("imgSqrs285").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs285").src = "img/sqrs/wSqr.png"
};
};
function sqrsF286b() {
    if(document.getElementById("imgSqrs286").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs286").src = "img/sqrs/wSqr.png"
};
};
function sqrsF287b() {
    if(document.getElementById("imgSqrs287").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs287").src = "img/sqrs/wSqr.png"
};
};
function sqrsF288b() {
    if(document.getElementById("imgSqrs288").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs288").src = "img/sqrs/wSqr.png"
};
};
function sqrsF289b() {
    if(document.getElementById("imgSqrs289").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs289").src = "img/sqrs/wSqr.png"
};
};
function sqrsF290b() {
    if(document.getElementById("imgSqrs290").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs290").src = "img/sqrs/wSqr.png"
};
};
function sqrsF291b() {
    if(document.getElementById("imgSqrs291").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs291").src = "img/sqrs/wSqr.png"
};
};
function sqrsF292b() {
    if(document.getElementById("imgSqrs292").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs292").src = "img/sqrs/wSqr.png"
};
};
function sqrsF293b() {
    if(document.getElementById("imgSqrs293").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs293").src = "img/sqrs/wSqr.png"
};
};
function sqrsF294b() {
    if(document.getElementById("imgSqrs294").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs294").src = "img/sqrs/wSqr.png"
};
};
function sqrsF295b() {
    if(document.getElementById("imgSqrs295").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs295").src = "img/sqrs/wSqr.png"
};
};
function sqrsF296b() {
    if(document.getElementById("imgSqrs296").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs296").src = "img/sqrs/wSqr.png"
};
};
function sqrsF297b() {
    if(document.getElementById("imgSqrs297").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs297").src = "img/sqrs/wSqr.png"
};
};
function sqrsF298b() {
    if(document.getElementById("imgSqrs298").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs298").src = "img/sqrs/wSqr.png"
};
};
function sqrsF299b() {
    if(document.getElementById("imgSqrs299").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs299").src = "img/sqrs/wSqr.png"
};
};
function sqrsF300b() {
    if(document.getElementById("imgSqrs300").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs300").src = "img/sqrs/wSqr.png"
};
};
function sqrsG301b() {
    if(document.getElementById("imgSqrs301").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs301").src = "img/sqrs/wSqr.png"
};
};
function sqrsG302b() {
    if(document.getElementById("imgSqrs302").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs302").src = "img/sqrs/wSqr.png"
};
};
function sqrsG303b() {
    if(document.getElementById("imgSqrs303").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs303").src = "img/sqrs/wSqr.png"
};
};
function sqrsG304b() {
    if(document.getElementById("imgSqrs304").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs304").src = "img/sqrs/wSqr.png"
};
};
function sqrsG305b() {
    if(document.getElementById("imgSqrs305").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs305").src = "img/sqrs/wSqr.png"
};
};
function sqrsG306b() {
    if(document.getElementById("imgSqrs306").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs306").src = "img/sqrs/wSqr.png"
};
};
function sqrsG307b() {
    if(document.getElementById("imgSqrs307").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs307").src = "img/sqrs/wSqr.png"
};
};
function sqrsG308b() {
    if(document.getElementById("imgSqrs308").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs308").src = "img/sqrs/wSqr.png"
};
};
function sqrsG309b() {
    if(document.getElementById("imgSqrs309").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs309").src = "img/sqrs/wSqr.png"
};
};
function sqrsG310b() {
    if(document.getElementById("imgSqrs310").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs310").src = "img/sqrs/wSqr.png"
};
};
function sqrsG311b() {
    if(document.getElementById("imgSqrs311").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs311").src = "img/sqrs/wSqr.png"
};
};
function sqrsG312b() {
    if(document.getElementById("imgSqrs312").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs312").src = "img/sqrs/wSqr.png"
};
};
function sqrsG313b() {
    if(document.getElementById("imgSqrs313").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs313").src = "img/sqrs/wSqr.png"
};
};
function sqrsG314b() {
    if(document.getElementById("imgSqrs314").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs314").src = "img/sqrs/wSqr.png"
};
};
function sqrsG315b() {
    if(document.getElementById("imgSqrs315").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs315").src = "img/sqrs/wSqr.png"
};
};
function sqrsG316b() {
    if(document.getElementById("imgSqrs316").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs316").src = "img/sqrs/wSqr.png"
};
};
function sqrsG317b() {
    if(document.getElementById("imgSqrs317").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs317").src = "img/sqrs/wSqr.png"
};
};
function sqrsG318b() {
    if(document.getElementById("imgSqrs318").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs318").src = "img/sqrs/wSqr.png"
};
};
function sqrsG319b() {
    if(document.getElementById("imgSqrs319").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs319").src = "img/sqrs/wSqr.png"
};
};
function sqrsG320b() {
    if(document.getElementById("imgSqrs320").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs320").src = "img/sqrs/wSqr.png"
};
};
function sqrsG321b() {
    if(document.getElementById("imgSqrs321").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs321").src = "img/sqrs/wSqr.png"
};
};
function sqrsG322b() {
    if(document.getElementById("imgSqrs322").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs322").src = "img/sqrs/wSqr.png"
};
};
function sqrsG323b() {
    if(document.getElementById("imgSqrs323").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs323").src = "img/sqrs/wSqr.png"
};
};
function sqrsG324b() {
    if(document.getElementById("imgSqrs324").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs324").src = "img/sqrs/wSqr.png"
};
};
function sqrsG325b() {
    if(document.getElementById("imgSqrs325").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs325").src = "img/sqrs/wSqr.png"
};
};
function sqrsG326b() {
    if(document.getElementById("imgSqrs326").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs326").src = "img/sqrs/wSqr.png"
};
};
function sqrsG327b() {
    if(document.getElementById("imgSqrs327").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs327").src = "img/sqrs/wSqr.png"
};
};
function sqrsG328b() {
    if(document.getElementById("imgSqrs328").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs328").src = "img/sqrs/wSqr.png"
};
};
function sqrsG329b() {
    if(document.getElementById("imgSqrs329").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs329").src = "img/sqrs/wSqr.png"
};
};
function sqrsG330b() {
    if(document.getElementById("imgSqrs330").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs330").src = "img/sqrs/wSqr.png"
};
};
function sqrsG331b() {
    if(document.getElementById("imgSqrs331").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs331").src = "img/sqrs/wSqr.png"
};
};
function sqrsG332b() {
    if(document.getElementById("imgSqrs332").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs332").src = "img/sqrs/wSqr.png"
};
};
function sqrsG333b() {
    if(document.getElementById("imgSqrs333").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs333").src = "img/sqrs/wSqr.png"
};
};
function sqrsG334b() {
    if(document.getElementById("imgSqrs334").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs334").src = "img/sqrs/wSqr.png"
};
};
function sqrsG335b() {
    if(document.getElementById("imgSqrs335").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs335").src = "img/sqrs/wSqr.png"
};
};
function sqrsG336b() {
    if(document.getElementById("imgSqrs336").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs336").src = "img/sqrs/wSqr.png"
};
};
function sqrsG337b() {
    if(document.getElementById("imgSqrs337").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs337").src = "img/sqrs/wSqr.png"
};
};
function sqrsG338b() {
    if(document.getElementById("imgSqrs338").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs338").src = "img/sqrs/wSqr.png"
};
};
function sqrsG339b() {
    if(document.getElementById("imgSqrs339").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs339").src = "img/sqrs/wSqr.png"
};
};
function sqrsG340b() {
    if(document.getElementById("imgSqrs340").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs340").src = "img/sqrs/wSqr.png"
};
};
function sqrsG341b() {
    if(document.getElementById("imgSqrs341").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs341").src = "img/sqrs/wSqr.png"
};
};
function sqrsG342b() {
    if(document.getElementById("imgSqrs342").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs342").src = "img/sqrs/wSqr.png"
};
};
function sqrsG343b() {
    if(document.getElementById("imgSqrs343").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs343").src = "img/sqrs/wSqr.png"
};
};
function sqrsG344b() {
    if(document.getElementById("imgSqrs344").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs344").src = "img/sqrs/wSqr.png"
};
};
function sqrsG345b() {
    if(document.getElementById("imgSqrs345").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs345").src = "img/sqrs/wSqr.png"
};
};
function sqrsG346b() {
    if(document.getElementById("imgSqrs346").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs346").src = "img/sqrs/wSqr.png"
};
};
function sqrsG347b() {
    if(document.getElementById("imgSqrs347").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs347").src = "img/sqrs/wSqr.png"
};
};
function sqrsG348b() {
    if(document.getElementById("imgSqrs348").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs348").src = "img/sqrs/wSqr.png"
};
};
function sqrsG349b() {
    if(document.getElementById("imgSqrs349").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs349").src = "img/sqrs/wSqr.png"
};
};
function sqrsG350b() {
    if(document.getElementById("imgSqrs350").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs350").src = "img/sqrs/wSqr.png"
};
};
function sqrsH351b() {
    if(document.getElementById("imgSqrs351").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs351").src = "img/sqrs/wSqr.png"
};
};
function sqrsH352b() {
    if(document.getElementById("imgSqrs352").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs352").src = "img/sqrs/wSqr.png"
};
};
function sqrsH353b() {
    if(document.getElementById("imgSqrs353").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs353").src = "img/sqrs/wSqr.png"
};
};
function sqrsH354b() {
    if(document.getElementById("imgSqrs354").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs354").src = "img/sqrs/wSqr.png"
};
};
function sqrsH355b() {
    if(document.getElementById("imgSqrs355").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs355").src = "img/sqrs/wSqr.png"
};
};
function sqrsH356b() {
    if(document.getElementById("imgSqrs356").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs356").src = "img/sqrs/wSqr.png"
};
};
function sqrsH357b() {
    if(document.getElementById("imgSqrs357").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs357").src = "img/sqrs/wSqr.png"
};
};
function sqrsH358b() {
    if(document.getElementById("imgSqrs358").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs358").src = "img/sqrs/wSqr.png"
};
};
function sqrsH359b() {
    if(document.getElementById("imgSqrs359").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs359").src = "img/sqrs/wSqr.png"
};
};
function sqrsH360b() {
    if(document.getElementById("imgSqrs360").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs360").src = "img/sqrs/wSqr.png"
};
};
function sqrsH361b() {
    if(document.getElementById("imgSqrs361").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs361").src = "img/sqrs/wSqr.png"
};
};
function sqrsH362b() {
    if(document.getElementById("imgSqrs362").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs362").src = "img/sqrs/wSqr.png"
};
};
function sqrsH363b() {
    if(document.getElementById("imgSqrs363").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs363").src = "img/sqrs/wSqr.png"
};
};
function sqrsH364b() {
    if(document.getElementById("imgSqrs364").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs364").src = "img/sqrs/wSqr.png"
};
};
function sqrsH365b() {
    if(document.getElementById("imgSqrs365").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs365").src = "img/sqrs/wSqr.png"
};
};
function sqrsH366b() {
    if(document.getElementById("imgSqrs366").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs366").src = "img/sqrs/wSqr.png"
};
};
function sqrsH367b() {
    if(document.getElementById("imgSqrs367").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs367").src = "img/sqrs/wSqr.png"
};
};
function sqrsH368b() {
    if(document.getElementById("imgSqrs368").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs368").src = "img/sqrs/wSqr.png"
};
};
function sqrsH369b() {
    if(document.getElementById("imgSqrs369").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs369").src = "img/sqrs/wSqr.png"
};
};
function sqrsH370b() {
    if(document.getElementById("imgSqrs370").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs370").src = "img/sqrs/wSqr.png"
};
};
function sqrsH371b() {
    if(document.getElementById("imgSqrs371").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs371").src = "img/sqrs/wSqr.png"
};
};
function sqrsH372b() {
    if(document.getElementById("imgSqrs372").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs372").src = "img/sqrs/wSqr.png"
};
};
function sqrsH373b() {
    if(document.getElementById("imgSqrs373").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs373").src = "img/sqrs/wSqr.png"
};
};
function sqrsH374b() {
    if(document.getElementById("imgSqrs374").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs374").src = "img/sqrs/wSqr.png"
};
};
function sqrsH375b() {
    if(document.getElementById("imgSqrs375").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs375").src = "img/sqrs/wSqr.png"
};
};
function sqrsH376b() {
    if(document.getElementById("imgSqrs376").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs376").src = "img/sqrs/wSqr.png"
};
};
function sqrsH377b() {
    if(document.getElementById("imgSqrs377").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs377").src = "img/sqrs/wSqr.png"
};
};
function sqrsH378b() {
    if(document.getElementById("imgSqrs378").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs378").src = "img/sqrs/wSqr.png"
};
};
function sqrsH379b() {
    if(document.getElementById("imgSqrs379").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs379").src = "img/sqrs/wSqr.png"
};
};
function sqrsH380b() {
    if(document.getElementById("imgSqrs380").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs380").src = "img/sqrs/wSqr.png"
};
};
function sqrsH381b() {
    if(document.getElementById("imgSqrs381").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs381").src = "img/sqrs/wSqr.png"
};
};
function sqrsH382b() {
    if(document.getElementById("imgSqrs382").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs382").src = "img/sqrs/wSqr.png"
};
};
function sqrsH383b() {
    if(document.getElementById("imgSqrs383").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs383").src = "img/sqrs/wSqr.png"
};
};
function sqrsH384b() {
    if(document.getElementById("imgSqrs384").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs384").src = "img/sqrs/wSqr.png"
};
};
function sqrsH385b() {
    if(document.getElementById("imgSqrs385").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs385").src = "img/sqrs/wSqr.png"
};
};
function sqrsH386b() {
    if(document.getElementById("imgSqrs386").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs386").src = "img/sqrs/wSqr.png"
};
};
function sqrsH387b() {
    if(document.getElementById("imgSqrs387").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs387").src = "img/sqrs/wSqr.png"
};
};
function sqrsH388b() {
    if(document.getElementById("imgSqrs388").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs388").src = "img/sqrs/wSqr.png"
};
};
function sqrsH389b() {
    if(document.getElementById("imgSqrs389").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs389").src = "img/sqrs/wSqr.png"
};
};
function sqrsH390b() {
    if(document.getElementById("imgSqrs390").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs390").src = "img/sqrs/wSqr.png"
};
};
function sqrsH391b() {
    if(document.getElementById("imgSqrs391").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs391").src = "img/sqrs/wSqr.png"
};
};
function sqrsH392b() {
    if(document.getElementById("imgSqrs392").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs392").src = "img/sqrs/wSqr.png"
};
};
function sqrsH393b() {
    if(document.getElementById("imgSqrs393").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs393").src = "img/sqrs/wSqr.png"
};
};
function sqrsH394b() {
    if(document.getElementById("imgSqrs394").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs394").src = "img/sqrs/wSqr.png"
};
};
function sqrsH395b() {
    if(document.getElementById("imgSqrs395").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs395").src = "img/sqrs/wSqr.png"
};
};
function sqrsH396b() {
    if(document.getElementById("imgSqrs396").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs396").src = "img/sqrs/wSqr.png"
};
};
function sqrsH397b() {
    if(document.getElementById("imgSqrs397").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs397").src = "img/sqrs/wSqr.png"
};
};
function sqrsH398b() {
    if(document.getElementById("imgSqrs398").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs398").src = "img/sqrs/wSqr.png"
};
};
function sqrsH399b() {
    if(document.getElementById("imgSqrs399").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs399").src = "img/sqrs/wSqr.png"
};
};
function sqrsH400b() {
    if(document.getElementById("imgSqrs400").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs400").src = "img/sqrs/wSqr.png"
};
};
function sqrsI401b() {
    if(document.getElementById("imgSqrs401").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs401").src = "img/sqrs/wSqr.png"
};
};
function sqrsI402b() {
    if(document.getElementById("imgSqrs402").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs402").src = "img/sqrs/wSqr.png"
};
};
function sqrsI403b() {
    if(document.getElementById("imgSqrs403").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs403").src = "img/sqrs/wSqr.png"
};
};
function sqrsI404b() {
    if(document.getElementById("imgSqrs404").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs404").src = "img/sqrs/wSqr.png"
};
};
function sqrsI405b() {
    if(document.getElementById("imgSqrs405").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs405").src = "img/sqrs/wSqr.png"
};
};
function sqrsI406b() {
    if(document.getElementById("imgSqrs406").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs406").src = "img/sqrs/wSqr.png"
};
};
function sqrsI407b() {
    if(document.getElementById("imgSqrs407").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs407").src = "img/sqrs/wSqr.png"
};
};
function sqrsI408b() {
    if(document.getElementById("imgSqrs408").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs408").src = "img/sqrs/wSqr.png"
};
};
function sqrsI409b() {
    if(document.getElementById("imgSqrs409").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs409").src = "img/sqrs/wSqr.png"
};
};
function sqrsI410b() {
    if(document.getElementById("imgSqrs410").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs410").src = "img/sqrs/wSqr.png"
};
};
function sqrsI411b() {
    if(document.getElementById("imgSqrs411").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs411").src = "img/sqrs/wSqr.png"
};
};
function sqrsI412b() {
    if(document.getElementById("imgSqrs412").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs412").src = "img/sqrs/wSqr.png"
};
};
function sqrsI413b() {
    if(document.getElementById("imgSqrs413").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs413").src = "img/sqrs/wSqr.png"
};
};
function sqrsI414b() {
    if(document.getElementById("imgSqrs414").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs414").src = "img/sqrs/wSqr.png"
};
};
function sqrsI415b() {
    if(document.getElementById("imgSqrs415").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs415").src = "img/sqrs/wSqr.png"
};
};
function sqrsI416b() {
    if(document.getElementById("imgSqrs416").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs416").src = "img/sqrs/wSqr.png"
};
};
function sqrsI417b() {
    if(document.getElementById("imgSqrs417").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs417").src = "img/sqrs/wSqr.png"
};
};
function sqrsI418b() {
    if(document.getElementById("imgSqrs418").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs418").src = "img/sqrs/wSqr.png"
};
};
function sqrsI419b() {
    if(document.getElementById("imgSqrs419").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs419").src = "img/sqrs/wSqr.png"
};
};
function sqrsI420b() {
    if(document.getElementById("imgSqrs420").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs420").src = "img/sqrs/wSqr.png"
};
};
function sqrsI421b() {
    if(document.getElementById("imgSqrs421").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs421").src = "img/sqrs/wSqr.png"
};
};
function sqrsI422b() {
    if(document.getElementById("imgSqrs422").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs422").src = "img/sqrs/wSqr.png"
};
};
function sqrsI423b() {
    if(document.getElementById("imgSqrs423").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs423").src = "img/sqrs/wSqr.png"
};
};
function sqrsI424b() {
    if(document.getElementById("imgSqrs424").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs424").src = "img/sqrs/wSqr.png"
};
};
function sqrsI425b() {
    if(document.getElementById("imgSqrs425").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs425").src = "img/sqrs/wSqr.png"
};
};
function sqrsI426b() {
    if(document.getElementById("imgSqrs426").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs426").src = "img/sqrs/wSqr.png"
};
};
function sqrsI427b() {
    if(document.getElementById("imgSqrs427").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs427").src = "img/sqrs/wSqr.png"
};
};
function sqrsI428b() {
    if(document.getElementById("imgSqrs428").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs428").src = "img/sqrs/wSqr.png"
};
};
function sqrsI429b() {
    if(document.getElementById("imgSqrs429").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs429").src = "img/sqrs/wSqr.png"
};
};
function sqrsI430b() {
    if(document.getElementById("imgSqrs430").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs430").src = "img/sqrs/wSqr.png"
};
};
function sqrsI431b() {
    if(document.getElementById("imgSqrs431").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs431").src = "img/sqrs/wSqr.png"
};
};
function sqrsI432b() {
    if(document.getElementById("imgSqrs432").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs432").src = "img/sqrs/wSqr.png"
};
};
function sqrsI433b() {
    if(document.getElementById("imgSqrs433").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs433").src = "img/sqrs/wSqr.png"
};
};
function sqrsI434b() {
    if(document.getElementById("imgSqrs434").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs434").src = "img/sqrs/wSqr.png"
};
};
function sqrsI435b() {
    if(document.getElementById("imgSqrs435").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs435").src = "img/sqrs/wSqr.png"
};
};
function sqrsI436b() {
    if(document.getElementById("imgSqrs436").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs436").src = "img/sqrs/wSqr.png"
};
};
function sqrsI437b() {
    if(document.getElementById("imgSqrs437").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs437").src = "img/sqrs/wSqr.png"
};
};
function sqrsI438b() {
    if(document.getElementById("imgSqrs438").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs438").src = "img/sqrs/wSqr.png"
};
};
function sqrsI439b() {
    if(document.getElementById("imgSqrs439").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs439").src = "img/sqrs/wSqr.png"
};
};
function sqrsI440b() {
    if(document.getElementById("imgSqrs440").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs440").src = "img/sqrs/wSqr.png"
};
};
function sqrsI441b() {
    if(document.getElementById("imgSqrs441").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs441").src = "img/sqrs/wSqr.png"
};
};
function sqrsI442b() {
    if(document.getElementById("imgSqrs442").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs442").src = "img/sqrs/wSqr.png"
};
};
function sqrsI443b() {
    if(document.getElementById("imgSqrs443").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs443").src = "img/sqrs/wSqr.png"
};
};
function sqrsI444b() {
    if(document.getElementById("imgSqrs444").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs444").src = "img/sqrs/wSqr.png"
};
};
function sqrsI445b() {
    if(document.getElementById("imgSqrs445").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs445").src = "img/sqrs/wSqr.png"
};
};
function sqrsI446b() {
    if(document.getElementById("imgSqrs446").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs446").src = "img/sqrs/wSqr.png"
};
};
function sqrsI447b() {
    if(document.getElementById("imgSqrs447").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs447").src = "img/sqrs/wSqr.png"
};
};
function sqrsI448b() {
    if(document.getElementById("imgSqrs448").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs448").src = "img/sqrs/wSqr.png"
};
};
function sqrsI449b() {
    if(document.getElementById("imgSqrs449").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs449").src = "img/sqrs/wSqr.png"
};
};
function sqrsI450b() {
    if(document.getElementById("imgSqrs450").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs450").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ451b() {
    if(document.getElementById("imgSqrs451").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs451").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ452b() {
    if(document.getElementById("imgSqrs452").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs452").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ453b() {
    if(document.getElementById("imgSqrs453").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs453").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ454b() {
    if(document.getElementById("imgSqrs454").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs454").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ455b() {
    if(document.getElementById("imgSqrs455").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs455").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ456b() {
    if(document.getElementById("imgSqrs456").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs456").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ457b() {
    if(document.getElementById("imgSqrs457").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs457").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ458b() {
    if(document.getElementById("imgSqrs458").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs458").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ459b() {
    if(document.getElementById("imgSqrs459").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs459").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ460b() {
    if(document.getElementById("imgSqrs460").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs460").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ461b() {
    if(document.getElementById("imgSqrs461").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs461").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ462b() {
    if(document.getElementById("imgSqrs462").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs462").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ463b() {
    if(document.getElementById("imgSqrs463").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs463").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ464b() {
    if(document.getElementById("imgSqrs464").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs464").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ465b() {
    if(document.getElementById("imgSqrs465").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs465").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ466b() {
    if(document.getElementById("imgSqrs466").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs466").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ467b() {
    if(document.getElementById("imgSqrs467").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs467").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ468b() {
    if(document.getElementById("imgSqrs468").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs468").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ469b() {
    if(document.getElementById("imgSqrs469").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs469").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ470b() {
    if(document.getElementById("imgSqrs470").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs470").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ471b() {
    if(document.getElementById("imgSqrs471").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs471").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ472b() {
    if(document.getElementById("imgSqrs472").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs472").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ473b() {
    if(document.getElementById("imgSqrs473").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs473").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ474b() {
    if(document.getElementById("imgSqrs474").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs474").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ475b() {
    if(document.getElementById("imgSqrs475").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs475").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ476b() {
    if(document.getElementById("imgSqrs476").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs476").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ477b() {
    if(document.getElementById("imgSqrs477").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs477").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ478b() {
    if(document.getElementById("imgSqrs478").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs478").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ479b() {
    if(document.getElementById("imgSqrs479").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs479").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ480b() {
    if(document.getElementById("imgSqrs480").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs480").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ481b() {
    if(document.getElementById("imgSqrs481").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs481").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ482b() {
    if(document.getElementById("imgSqrs482").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs482").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ483b() {
    if(document.getElementById("imgSqrs483").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs483").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ484b() {
    if(document.getElementById("imgSqrs484").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs484").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ485b() {
    if(document.getElementById("imgSqrs485").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs485").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ486b() {
    if(document.getElementById("imgSqrs486").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs486").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ487b() {
    if(document.getElementById("imgSqrs487").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs487").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ488b() {
    if(document.getElementById("imgSqrs488").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs488").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ489b() {
    if(document.getElementById("imgSqrs489").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs489").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ490b() {
    if(document.getElementById("imgSqrs490").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs490").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ491b() {
    if(document.getElementById("imgSqrs491").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs491").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ492b() {
    if(document.getElementById("imgSqrs492").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs492").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ493b() {
    if(document.getElementById("imgSqrs493").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs493").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ494b() {
    if(document.getElementById("imgSqrs494").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs494").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ495b() {
    if(document.getElementById("imgSqrs495").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs495").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ496b() {
    if(document.getElementById("imgSqrs496").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs496").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ497b() {
    if(document.getElementById("imgSqrs497").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs497").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ498b() {
    if(document.getElementById("imgSqrs498").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs498").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ499b() {
    if(document.getElementById("imgSqrs499").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs499").src = "img/sqrs/wSqr.png"
};
};
function sqrsJ500b() {
    if(document.getElementById("imgSqrs500").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs500").src = "img/sqrs/wSqr.png"
};
};
function sqrsK501b() {
    if(document.getElementById("imgSqrs501").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs501").src = "img/sqrs/wSqr.png"
};
};
function sqrsK502b() {
    if(document.getElementById("imgSqrs502").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs502").src = "img/sqrs/wSqr.png"
};
};
function sqrsK503b() {
    if(document.getElementById("imgSqrs503").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs503").src = "img/sqrs/wSqr.png"
};
};
function sqrsK504b() {
    if(document.getElementById("imgSqrs504").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs504").src = "img/sqrs/wSqr.png"
};
};
function sqrsK505b() {
    if(document.getElementById("imgSqrs505").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs505").src = "img/sqrs/wSqr.png"
};
};
function sqrsK506b() {
    if(document.getElementById("imgSqrs506").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs506").src = "img/sqrs/wSqr.png"
};
};
function sqrsK507b() {
    if(document.getElementById("imgSqrs507").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs507").src = "img/sqrs/wSqr.png"
};
};
function sqrsK508b() {
    if(document.getElementById("imgSqrs508").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs508").src = "img/sqrs/wSqr.png"
};
};
function sqrsK509b() {
    if(document.getElementById("imgSqrs509").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs509").src = "img/sqrs/wSqr.png"
};
};
function sqrsK510b() {
    if(document.getElementById("imgSqrs510").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs510").src = "img/sqrs/wSqr.png"
};
};
function sqrsK511b() {
    if(document.getElementById("imgSqrs511").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs511").src = "img/sqrs/wSqr.png"
};
};
function sqrsK512b() {
    if(document.getElementById("imgSqrs512").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs512").src = "img/sqrs/wSqr.png"
};
};
function sqrsK513b() {
    if(document.getElementById("imgSqrs513").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs513").src = "img/sqrs/wSqr.png"
};
};
function sqrsK514b() {
    if(document.getElementById("imgSqrs514").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs514").src = "img/sqrs/wSqr.png"
};
};
function sqrsK515b() {
    if(document.getElementById("imgSqrs515").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs515").src = "img/sqrs/wSqr.png"
};
};
function sqrsK516b() {
    if(document.getElementById("imgSqrs516").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs516").src = "img/sqrs/wSqr.png"
};
};
function sqrsK517b() {
    if(document.getElementById("imgSqrs517").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs517").src = "img/sqrs/wSqr.png"
};
};
function sqrsK518b() {
    if(document.getElementById("imgSqrs518").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs518").src = "img/sqrs/wSqr.png"
};
};
function sqrsK519b() {
    if(document.getElementById("imgSqrs519").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs519").src = "img/sqrs/wSqr.png"
};
};
function sqrsK520b() {
    if(document.getElementById("imgSqrs520").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs520").src = "img/sqrs/wSqr.png"
};
};
function sqrsK521b() {
    if(document.getElementById("imgSqrs521").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs521").src = "img/sqrs/wSqr.png"
};
};
function sqrsK522b() {
    if(document.getElementById("imgSqrs522").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs522").src = "img/sqrs/wSqr.png"
};
};
function sqrsK523b() {
    if(document.getElementById("imgSqrs523").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs523").src = "img/sqrs/wSqr.png"
};
};
function sqrsK524b() {
    if(document.getElementById("imgSqrs524").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs524").src = "img/sqrs/wSqr.png"
};
};
function sqrsK525b() {
    if(document.getElementById("imgSqrs525").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs525").src = "img/sqrs/wSqr.png"
};
};
function sqrsK526b() {
    if(document.getElementById("imgSqrs526").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs526").src = "img/sqrs/wSqr.png"
};
};
function sqrsK527b() {
    if(document.getElementById("imgSqrs527").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs527").src = "img/sqrs/wSqr.png"
};
};
function sqrsK528b() {
    if(document.getElementById("imgSqrs528").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs528").src = "img/sqrs/wSqr.png"
};
};
function sqrsK529b() {
    if(document.getElementById("imgSqrs529").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs529").src = "img/sqrs/wSqr.png"
};
};
function sqrsK530b() {
    if(document.getElementById("imgSqrs530").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs530").src = "img/sqrs/wSqr.png"
};
};
function sqrsK531b() {
    if(document.getElementById("imgSqrs531").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs531").src = "img/sqrs/wSqr.png"
};
};
function sqrsK532b() {
    if(document.getElementById("imgSqrs532").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs532").src = "img/sqrs/wSqr.png"
};
};
function sqrsK533b() {
    if(document.getElementById("imgSqrs533").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs533").src = "img/sqrs/wSqr.png"
};
};
function sqrsK534b() {
    if(document.getElementById("imgSqrs534").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs534").src = "img/sqrs/wSqr.png"
};
};
function sqrsK535b() {
    if(document.getElementById("imgSqrs535").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs535").src = "img/sqrs/wSqr.png"
};
};
function sqrsK536b() {
    if(document.getElementById("imgSqrs536").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs536").src = "img/sqrs/wSqr.png"
};
};
function sqrsK537b() {
    if(document.getElementById("imgSqrs537").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs537").src = "img/sqrs/wSqr.png"
};
};
function sqrsK538b() {
    if(document.getElementById("imgSqrs538").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs538").src = "img/sqrs/wSqr.png"
};
};
function sqrsK539b() {
    if(document.getElementById("imgSqrs539").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs539").src = "img/sqrs/wSqr.png"
};
};
function sqrsK540b() {
    if(document.getElementById("imgSqrs540").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs540").src = "img/sqrs/wSqr.png"
};
};
function sqrsK541b() {
    if(document.getElementById("imgSqrs541").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs541").src = "img/sqrs/wSqr.png"
};
};
function sqrsK542b() {
    if(document.getElementById("imgSqrs542").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs542").src = "img/sqrs/wSqr.png"
};
};
function sqrsK543b() {
    if(document.getElementById("imgSqrs543").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs543").src = "img/sqrs/wSqr.png"
};
};
function sqrsK544b() {
    if(document.getElementById("imgSqrs544").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs544").src = "img/sqrs/wSqr.png"
};
};
function sqrsK545b() {
    if(document.getElementById("imgSqrs545").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs545").src = "img/sqrs/wSqr.png"
};
};
function sqrsK546b() {
    if(document.getElementById("imgSqrs546").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs546").src = "img/sqrs/wSqr.png"
};
};
function sqrsK547b() {
    if(document.getElementById("imgSqrs547").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs547").src = "img/sqrs/wSqr.png"
};
};
function sqrsK548b() {
    if(document.getElementById("imgSqrs548").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs548").src = "img/sqrs/wSqr.png"
};
};
function sqrsK549b() {
    if(document.getElementById("imgSqrs549").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs549").src = "img/sqrs/wSqr.png"
};
};
function sqrsK550b() {
    if(document.getElementById("imgSqrs550").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs550").src = "img/sqrs/wSqr.png"
};
};
function sqrsL551b() {
    if(document.getElementById("imgSqrs551").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs551").src = "img/sqrs/wSqr.png"
};
};
function sqrsL552b() {
    if(document.getElementById("imgSqrs552").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs552").src = "img/sqrs/wSqr.png"
};
};
function sqrsL553b() {
    if(document.getElementById("imgSqrs553").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs553").src = "img/sqrs/wSqr.png"
};
};
function sqrsL554b() {
    if(document.getElementById("imgSqrs554").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs554").src = "img/sqrs/wSqr.png"
};
};
function sqrsL555b() {
    if(document.getElementById("imgSqrs555").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs555").src = "img/sqrs/wSqr.png"
};
};
function sqrsL556b() {
    if(document.getElementById("imgSqrs556").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs556").src = "img/sqrs/wSqr.png"
};
};
function sqrsL557b() {
    if(document.getElementById("imgSqrs557").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs557").src = "img/sqrs/wSqr.png"
};
};
function sqrsL558b() {
    if(document.getElementById("imgSqrs558").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs558").src = "img/sqrs/wSqr.png"
};
};
function sqrsL559b() {
    if(document.getElementById("imgSqrs559").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs559").src = "img/sqrs/wSqr.png"
};
};
function sqrsL560b() {
    if(document.getElementById("imgSqrs560").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs560").src = "img/sqrs/wSqr.png"
};
};
function sqrsL561b() {
    if(document.getElementById("imgSqrs561").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs561").src = "img/sqrs/wSqr.png"
};
};
function sqrsL562b() {
    if(document.getElementById("imgSqrs562").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs562").src = "img/sqrs/wSqr.png"
};
};
function sqrsL563b() {
    if(document.getElementById("imgSqrs563").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs563").src = "img/sqrs/wSqr.png"
};
};
function sqrsL564b() {
    if(document.getElementById("imgSqrs564").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs564").src = "img/sqrs/wSqr.png"
};
};
function sqrsL565b() {
    if(document.getElementById("imgSqrs565").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs565").src = "img/sqrs/wSqr.png"
};
};
function sqrsL566b() {
    if(document.getElementById("imgSqrs566").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs566").src = "img/sqrs/wSqr.png"
};
};
function sqrsL567b() {
    if(document.getElementById("imgSqrs567").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs567").src = "img/sqrs/wSqr.png"
};
};
function sqrsL568b() {
    if(document.getElementById("imgSqrs568").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs568").src = "img/sqrs/wSqr.png"
};
};
function sqrsL569b() {
    if(document.getElementById("imgSqrs569").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs569").src = "img/sqrs/wSqr.png"
};
};
function sqrsL570b() {
    if(document.getElementById("imgSqrs570").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs570").src = "img/sqrs/wSqr.png"
};
};
function sqrsL571b() {
    if(document.getElementById("imgSqrs571").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs571").src = "img/sqrs/wSqr.png"
};
};
function sqrsL572b() {
    if(document.getElementById("imgSqrs572").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs572").src = "img/sqrs/wSqr.png"
};
};
function sqrsL573b() {
    if(document.getElementById("imgSqrs573").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs573").src = "img/sqrs/wSqr.png"
};
};
function sqrsL574b() {
    if(document.getElementById("imgSqrs574").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs574").src = "img/sqrs/wSqr.png"
};
};
function sqrsL575b() {
    if(document.getElementById("imgSqrs575").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs575").src = "img/sqrs/wSqr.png"
};
};
function sqrsL576b() {
    if(document.getElementById("imgSqrs576").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs576").src = "img/sqrs/wSqr.png"
};
};
function sqrsL577b() {
    if(document.getElementById("imgSqrs577").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs577").src = "img/sqrs/wSqr.png"
};
};
function sqrsL578b() {
    if(document.getElementById("imgSqrs578").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs578").src = "img/sqrs/wSqr.png"
};
};
function sqrsL579b() {
    if(document.getElementById("imgSqrs579").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs579").src = "img/sqrs/wSqr.png"
};
};
function sqrsL580b() {
    if(document.getElementById("imgSqrs580").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs580").src = "img/sqrs/wSqr.png"
};
};
function sqrsL581b() {
    if(document.getElementById("imgSqrs581").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs581").src = "img/sqrs/wSqr.png"
};
};
function sqrsL582b() {
    if(document.getElementById("imgSqrs582").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs582").src = "img/sqrs/wSqr.png"
};
};
function sqrsL583b() {
    if(document.getElementById("imgSqrs583").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs583").src = "img/sqrs/wSqr.png"
};
};
function sqrsL584b() {
    if(document.getElementById("imgSqrs584").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs584").src = "img/sqrs/wSqr.png"
};
};
function sqrsL585b() {
    if(document.getElementById("imgSqrs585").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs585").src = "img/sqrs/wSqr.png"
};
};
function sqrsL586b() {
    if(document.getElementById("imgSqrs586").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs586").src = "img/sqrs/wSqr.png"
};
};
function sqrsL587b() {
    if(document.getElementById("imgSqrs587").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs587").src = "img/sqrs/wSqr.png"
};
};
function sqrsL588b() {
    if(document.getElementById("imgSqrs588").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs588").src = "img/sqrs/wSqr.png"
};
};
function sqrsL589b() {
    if(document.getElementById("imgSqrs589").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs589").src = "img/sqrs/wSqr.png"
};
};
function sqrsL590b() {
    if(document.getElementById("imgSqrs590").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs590").src = "img/sqrs/wSqr.png"
};
};
function sqrsL591b() {
    if(document.getElementById("imgSqrs591").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs591").src = "img/sqrs/wSqr.png"
};
};
function sqrsL592b() {
    if(document.getElementById("imgSqrs592").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs592").src = "img/sqrs/wSqr.png"
};
};
function sqrsL593b() {
    if(document.getElementById("imgSqrs593").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs593").src = "img/sqrs/wSqr.png"
};
};
function sqrsL594b() {
    if(document.getElementById("imgSqrs594").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs594").src = "img/sqrs/wSqr.png"
};
};
function sqrsL595b() {
    if(document.getElementById("imgSqrs595").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs595").src = "img/sqrs/wSqr.png"
};
};
function sqrsL596b() {
    if(document.getElementById("imgSqrs596").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs596").src = "img/sqrs/wSqr.png"
};
};
function sqrsL597b() {
    if(document.getElementById("imgSqrs597").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs597").src = "img/sqrs/wSqr.png"
};
};
function sqrsL598b() {
    if(document.getElementById("imgSqrs598").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs598").src = "img/sqrs/wSqr.png"
};
};
function sqrsL599b() {
    if(document.getElementById("imgSqrs599").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs599").src = "img/sqrs/wSqr.png"
};
};
function sqrsL600b() {
    if(document.getElementById("imgSqrs600").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs600").src = "img/sqrs/wSqr.png"
};
};
function sqrsM601b() {
    if(document.getElementById("imgSqrs601").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs601").src = "img/sqrs/wSqr.png"
};
};
function sqrsM602b() {
    if(document.getElementById("imgSqrs602").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs602").src = "img/sqrs/wSqr.png"
};
};
function sqrsM603b() {
    if(document.getElementById("imgSqrs603").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs603").src = "img/sqrs/wSqr.png"
};
};
function sqrsM604b() {
    if(document.getElementById("imgSqrs604").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs604").src = "img/sqrs/wSqr.png"
};
};
function sqrsM605b() {
    if(document.getElementById("imgSqrs605").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs605").src = "img/sqrs/wSqr.png"
};
};
function sqrsM606b() {
    if(document.getElementById("imgSqrs606").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs606").src = "img/sqrs/wSqr.png"
};
};
function sqrsM607b() {
    if(document.getElementById("imgSqrs607").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs607").src = "img/sqrs/wSqr.png"
};
};
function sqrsM608b() {
    if(document.getElementById("imgSqrs608").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs608").src = "img/sqrs/wSqr.png"
};
};
function sqrsM609b() {
    if(document.getElementById("imgSqrs609").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs609").src = "img/sqrs/wSqr.png"
};
};
function sqrsM610b() {
    if(document.getElementById("imgSqrs610").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs610").src = "img/sqrs/wSqr.png"
};
};
function sqrsM611b() {
    if(document.getElementById("imgSqrs611").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs611").src = "img/sqrs/wSqr.png"
};
};
function sqrsM612b() {
    if(document.getElementById("imgSqrs612").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs612").src = "img/sqrs/wSqr.png"
};
};
function sqrsM613b() {
    if(document.getElementById("imgSqrs613").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs613").src = "img/sqrs/wSqr.png"
};
};
function sqrsM614b() {
    if(document.getElementById("imgSqrs614").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs614").src = "img/sqrs/wSqr.png"
};
};
function sqrsM615b() {
    if(document.getElementById("imgSqrs615").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs615").src = "img/sqrs/wSqr.png"
};
};
function sqrsM616b() {
    if(document.getElementById("imgSqrs616").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs616").src = "img/sqrs/wSqr.png"
};
};
function sqrsM617b() {
    if(document.getElementById("imgSqrs617").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs617").src = "img/sqrs/wSqr.png"
};
};
function sqrsM618b() {
    if(document.getElementById("imgSqrs618").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs618").src = "img/sqrs/wSqr.png"
};
};
function sqrsM619b() {
    if(document.getElementById("imgSqrs619").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs619").src = "img/sqrs/wSqr.png"
};
};
function sqrsM620b() {
    if(document.getElementById("imgSqrs620").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs620").src = "img/sqrs/wSqr.png"
};
};
function sqrsM621b() {
    if(document.getElementById("imgSqrs621").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs621").src = "img/sqrs/wSqr.png"
};
};
function sqrsM622b() {
    if(document.getElementById("imgSqrs622").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs622").src = "img/sqrs/wSqr.png"
};
};
function sqrsM623b() {
    if(document.getElementById("imgSqrs623").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs623").src = "img/sqrs/wSqr.png"
};
};
function sqrsM624b() {
    if(document.getElementById("imgSqrs624").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs624").src = "img/sqrs/wSqr.png"
};
};
function sqrsM625b() {
    if(document.getElementById("imgSqrs625").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs625").src = "img/sqrs/wSqr.png"
};
};
function sqrsM626b() {
    if(document.getElementById("imgSqrs626").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs626").src = "img/sqrs/wSqr.png"
};
};
function sqrsM627b() {
    if(document.getElementById("imgSqrs627").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs627").src = "img/sqrs/wSqr.png"
};
};
function sqrsM628b() {
    if(document.getElementById("imgSqrs628").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs628").src = "img/sqrs/wSqr.png"
};
};
function sqrsM629b() {
    if(document.getElementById("imgSqrs629").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs629").src = "img/sqrs/wSqr.png"
};
};
function sqrsM630b() {
    if(document.getElementById("imgSqrs630").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs630").src = "img/sqrs/wSqr.png"
};
};
function sqrsM631b() {
    if(document.getElementById("imgSqrs631").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs631").src = "img/sqrs/wSqr.png"
};
};
function sqrsM632b() {
    if(document.getElementById("imgSqrs632").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs632").src = "img/sqrs/wSqr.png"
};
};
function sqrsM633b() {
    if(document.getElementById("imgSqrs633").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs633").src = "img/sqrs/wSqr.png"
};
};
function sqrsM634b() {
    if(document.getElementById("imgSqrs634").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs634").src = "img/sqrs/wSqr.png"
};
};
function sqrsM635b() {
    if(document.getElementById("imgSqrs635").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs635").src = "img/sqrs/wSqr.png"
};
};
function sqrsM636b() {
    if(document.getElementById("imgSqrs636").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs636").src = "img/sqrs/wSqr.png"
};
};
function sqrsM637b() {
    if(document.getElementById("imgSqrs637").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs637").src = "img/sqrs/wSqr.png"
};
};
function sqrsM638b() {
    if(document.getElementById("imgSqrs638").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs638").src = "img/sqrs/wSqr.png"
};
};
function sqrsM639b() {
    if(document.getElementById("imgSqrs639").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs639").src = "img/sqrs/wSqr.png"
};
};
function sqrsM640b() {
    if(document.getElementById("imgSqrs640").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs640").src = "img/sqrs/wSqr.png"
};
};
function sqrsM641b() {
    if(document.getElementById("imgSqrs641").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs641").src = "img/sqrs/wSqr.png"
};
};
function sqrsM642b() {
    if(document.getElementById("imgSqrs642").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs642").src = "img/sqrs/wSqr.png"
};
};
function sqrsM643b() {
    if(document.getElementById("imgSqrs643").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs643").src = "img/sqrs/wSqr.png"
};
};
function sqrsM644b() {
    if(document.getElementById("imgSqrs644").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs644").src = "img/sqrs/wSqr.png"
};
};
function sqrsM645b() {
    if(document.getElementById("imgSqrs645").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs645").src = "img/sqrs/wSqr.png"
};
};
function sqrsM646b() {
    if(document.getElementById("imgSqrs646").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs646").src = "img/sqrs/wSqr.png"
};
};
function sqrsM647b() {
    if(document.getElementById("imgSqrs647").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs647").src = "img/sqrs/wSqr.png"
};
};
function sqrsM648b() {
    if(document.getElementById("imgSqrs648").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs648").src = "img/sqrs/wSqr.png"
};
};
function sqrsM649b() {
    if(document.getElementById("imgSqrs649").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs649").src = "img/sqrs/wSqr.png"
};
};
function sqrsM650b() {
    if(document.getElementById("imgSqrs650").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs650").src = "img/sqrs/wSqr.png"
};
};
function sqrsN651b() {
    if(document.getElementById("imgSqrs651").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs651").src = "img/sqrs/wSqr.png"
};
};
function sqrsN652b() {
    if(document.getElementById("imgSqrs652").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs652").src = "img/sqrs/wSqr.png"
};
};
function sqrsN653b() {
    if(document.getElementById("imgSqrs653").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs653").src = "img/sqrs/wSqr.png"
};
};
function sqrsN654b() {
    if(document.getElementById("imgSqrs654").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs654").src = "img/sqrs/wSqr.png"
};
};
function sqrsN655b() {
    if(document.getElementById("imgSqrs655").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs655").src = "img/sqrs/wSqr.png"
};
};
function sqrsN656b() {
    if(document.getElementById("imgSqrs656").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs656").src = "img/sqrs/wSqr.png"
};
};
function sqrsN657b() {
    if(document.getElementById("imgSqrs657").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs657").src = "img/sqrs/wSqr.png"
};
};
function sqrsN658b() {
    if(document.getElementById("imgSqrs658").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs658").src = "img/sqrs/wSqr.png"
};
};
function sqrsN659b() {
    if(document.getElementById("imgSqrs659").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs659").src = "img/sqrs/wSqr.png"
};
};
function sqrsN660b() {
    if(document.getElementById("imgSqrs660").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs660").src = "img/sqrs/wSqr.png"
};
};
function sqrsN661b() {
    if(document.getElementById("imgSqrs661").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs661").src = "img/sqrs/wSqr.png"
};
};
function sqrsN662b() {
    if(document.getElementById("imgSqrs662").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs662").src = "img/sqrs/wSqr.png"
};
};
function sqrsN663b() {
    if(document.getElementById("imgSqrs663").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs663").src = "img/sqrs/wSqr.png"
};
};
function sqrsN664b() {
    if(document.getElementById("imgSqrs664").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs664").src = "img/sqrs/wSqr.png"
};
};
function sqrsN665b() {
    if(document.getElementById("imgSqrs665").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs665").src = "img/sqrs/wSqr.png"
};
};
function sqrsN666b() {
    if(document.getElementById("imgSqrs666").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs666").src = "img/sqrs/wSqr.png"
};
};
function sqrsN667b() {
    if(document.getElementById("imgSqrs667").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs667").src = "img/sqrs/wSqr.png"
};
};
function sqrsN668b() {
    if(document.getElementById("imgSqrs668").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs668").src = "img/sqrs/wSqr.png"
};
};
function sqrsN669b() {
    if(document.getElementById("imgSqrs669").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs669").src = "img/sqrs/wSqr.png"
};
};
function sqrsN670b() {
    if(document.getElementById("imgSqrs670").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs670").src = "img/sqrs/wSqr.png"
};
};
function sqrsN671b() {
    if(document.getElementById("imgSqrs671").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs671").src = "img/sqrs/wSqr.png"
};
};
function sqrsN672b() {
    if(document.getElementById("imgSqrs672").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs672").src = "img/sqrs/wSqr.png"
};
};
function sqrsN673b() {
    if(document.getElementById("imgSqrs673").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs673").src = "img/sqrs/wSqr.png"
};
};
function sqrsN674b() {
    if(document.getElementById("imgSqrs674").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs674").src = "img/sqrs/wSqr.png"
};
};
function sqrsN675b() {
    if(document.getElementById("imgSqrs675").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs675").src = "img/sqrs/wSqr.png"
};
};
function sqrsN676b() {
    if(document.getElementById("imgSqrs676").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs676").src = "img/sqrs/wSqr.png"
};
};
function sqrsN677b() {
    if(document.getElementById("imgSqrs677").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs677").src = "img/sqrs/wSqr.png"
};
};
function sqrsN678b() {
    if(document.getElementById("imgSqrs678").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs678").src = "img/sqrs/wSqr.png"
};
};
function sqrsN679b() {
    if(document.getElementById("imgSqrs679").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs679").src = "img/sqrs/wSqr.png"
};
};
function sqrsN680b() {
    if(document.getElementById("imgSqrs680").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs680").src = "img/sqrs/wSqr.png"
};
};
function sqrsN681b() {
    if(document.getElementById("imgSqrs681").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs681").src = "img/sqrs/wSqr.png"
};
};
function sqrsN682b() {
    if(document.getElementById("imgSqrs682").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs682").src = "img/sqrs/wSqr.png"
};
};
function sqrsN683b() {
    if(document.getElementById("imgSqrs683").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs683").src = "img/sqrs/wSqr.png"
};
};
function sqrsN684b() {
    if(document.getElementById("imgSqrs684").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs684").src = "img/sqrs/wSqr.png"
};
};
function sqrsN685b() {
    if(document.getElementById("imgSqrs685").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs685").src = "img/sqrs/wSqr.png"
};
};
function sqrsN686b() {
    if(document.getElementById("imgSqrs686").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs686").src = "img/sqrs/wSqr.png"
};
};
function sqrsN687b() {
    if(document.getElementById("imgSqrs687").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs687").src = "img/sqrs/wSqr.png"
};
};
function sqrsN688b() {
    if(document.getElementById("imgSqrs688").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs688").src = "img/sqrs/wSqr.png"
};
};
function sqrsN689b() {
    if(document.getElementById("imgSqrs689").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs689").src = "img/sqrs/wSqr.png"
};
};
function sqrsN690b() {
    if(document.getElementById("imgSqrs690").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs690").src = "img/sqrs/wSqr.png"
};
};
function sqrsN691b() {
    if(document.getElementById("imgSqrs691").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs691").src = "img/sqrs/wSqr.png"
};
};
function sqrsN692b() {
    if(document.getElementById("imgSqrs692").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs692").src = "img/sqrs/wSqr.png"
};
};
function sqrsN693b() {
    if(document.getElementById("imgSqrs693").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs693").src = "img/sqrs/wSqr.png"
};
};
function sqrsN694b() {
    if(document.getElementById("imgSqrs694").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs694").src = "img/sqrs/wSqr.png"
};
};
function sqrsN695b() {
    if(document.getElementById("imgSqrs695").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs695").src = "img/sqrs/wSqr.png"
};
};
function sqrsN696b() {
    if(document.getElementById("imgSqrs696").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs696").src = "img/sqrs/wSqr.png"
};
};
function sqrsN697b() {
    if(document.getElementById("imgSqrs697").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs697").src = "img/sqrs/wSqr.png"
};
};
function sqrsN698b() {
    if(document.getElementById("imgSqrs698").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs698").src = "img/sqrs/wSqr.png"
};
};
function sqrsN699b() {
    if(document.getElementById("imgSqrs699").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs699").src = "img/sqrs/wSqr.png"
};
};
function sqrsN700b() {
    if(document.getElementById("imgSqrs700").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs700").src = "img/sqrs/wSqr.png"
};
};
function sqrsO701b() {
    if(document.getElementById("imgSqrs701").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs701").src = "img/sqrs/wSqr.png"
};
};
function sqrsO702b() {
    if(document.getElementById("imgSqrs702").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs702").src = "img/sqrs/wSqr.png"
};
};
function sqrsO703b() {
    if(document.getElementById("imgSqrs703").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs703").src = "img/sqrs/wSqr.png"
};
};
function sqrsO704b() {
    if(document.getElementById("imgSqrs704").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs704").src = "img/sqrs/wSqr.png"
};
};
function sqrsO705b() {
    if(document.getElementById("imgSqrs705").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs705").src = "img/sqrs/wSqr.png"
};
};
function sqrsO706b() {
    if(document.getElementById("imgSqrs706").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs706").src = "img/sqrs/wSqr.png"
};
};
function sqrsO707b() {
    if(document.getElementById("imgSqrs707").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs707").src = "img/sqrs/wSqr.png"
};
};
function sqrsO708b() {
    if(document.getElementById("imgSqrs708").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs708").src = "img/sqrs/wSqr.png"
};
};
function sqrsO709b() {
    if(document.getElementById("imgSqrs709").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs709").src = "img/sqrs/wSqr.png"
};
};
function sqrsO710b() {
    if(document.getElementById("imgSqrs710").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs710").src = "img/sqrs/wSqr.png"
};
};
function sqrsO711b() {
    if(document.getElementById("imgSqrs711").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs711").src = "img/sqrs/wSqr.png"
};
};
function sqrsO712b() {
    if(document.getElementById("imgSqrs712").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs712").src = "img/sqrs/wSqr.png"
};
};
function sqrsO713b() {
    if(document.getElementById("imgSqrs713").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs713").src = "img/sqrs/wSqr.png"
};
};
function sqrsO714b() {
    if(document.getElementById("imgSqrs714").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs714").src = "img/sqrs/wSqr.png"
};
};
function sqrsO715b() {
    if(document.getElementById("imgSqrs715").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs715").src = "img/sqrs/wSqr.png"
};
};
function sqrsO716b() {
    if(document.getElementById("imgSqrs716").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs716").src = "img/sqrs/wSqr.png"
};
};
function sqrsO717b() {
    if(document.getElementById("imgSqrs717").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs717").src = "img/sqrs/wSqr.png"
};
};
function sqrsO718b() {
    if(document.getElementById("imgSqrs718").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs718").src = "img/sqrs/wSqr.png"
};
};
function sqrsO719b() {
    if(document.getElementById("imgSqrs719").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs719").src = "img/sqrs/wSqr.png"
};
};
function sqrsO720b() {
    if(document.getElementById("imgSqrs720").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs720").src = "img/sqrs/wSqr.png"
};
};
function sqrsO721b() {
    if(document.getElementById("imgSqrs721").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs721").src = "img/sqrs/wSqr.png"
};
};
function sqrsO722b() {
    if(document.getElementById("imgSqrs722").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs722").src = "img/sqrs/wSqr.png"
};
};
function sqrsO723b() {
    if(document.getElementById("imgSqrs723").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs723").src = "img/sqrs/wSqr.png"
};
};
function sqrsO724b() {
    if(document.getElementById("imgSqrs724").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs724").src = "img/sqrs/wSqr.png"
};
};
function sqrsO725b() {
    if(document.getElementById("imgSqrs725").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs725").src = "img/sqrs/wSqr.png"
};
};
function sqrsO726b() {
    if(document.getElementById("imgSqrs726").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs726").src = "img/sqrs/wSqr.png"
};
};
function sqrsO727b() {
    if(document.getElementById("imgSqrs727").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs727").src = "img/sqrs/wSqr.png"
};
};
function sqrsO728b() {
    if(document.getElementById("imgSqrs728").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs728").src = "img/sqrs/wSqr.png"
};
};
function sqrsO729b() {
    if(document.getElementById("imgSqrs729").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs729").src = "img/sqrs/wSqr.png"
};
};
function sqrsO730b() {
    if(document.getElementById("imgSqrs730").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs730").src = "img/sqrs/wSqr.png"
};
};
function sqrsO731b() {
    if(document.getElementById("imgSqrs731").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs731").src = "img/sqrs/wSqr.png"
};
};
function sqrsO732b() {
    if(document.getElementById("imgSqrs732").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs732").src = "img/sqrs/wSqr.png"
};
};
function sqrsO733b() {
    if(document.getElementById("imgSqrs733").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs733").src = "img/sqrs/wSqr.png"
};
};
function sqrsO734b() {
    if(document.getElementById("imgSqrs734").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs734").src = "img/sqrs/wSqr.png"
};
};
function sqrsO735b() {
    if(document.getElementById("imgSqrs735").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs735").src = "img/sqrs/wSqr.png"
};
};
function sqrsO736b() {
    if(document.getElementById("imgSqrs736").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs736").src = "img/sqrs/wSqr.png"
};
};
function sqrsO737b() {
    if(document.getElementById("imgSqrs737").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs737").src = "img/sqrs/wSqr.png"
};
};
function sqrsO738b() {
    if(document.getElementById("imgSqrs738").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs738").src = "img/sqrs/wSqr.png"
};
};
function sqrsO739b() {
    if(document.getElementById("imgSqrs739").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs739").src = "img/sqrs/wSqr.png"
};
};
function sqrsO740b() {
    if(document.getElementById("imgSqrs740").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs740").src = "img/sqrs/wSqr.png"
};
};
function sqrsO741b() {
    if(document.getElementById("imgSqrs741").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs741").src = "img/sqrs/wSqr.png"
};
};
function sqrsO742b() {
    if(document.getElementById("imgSqrs742").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs742").src = "img/sqrs/wSqr.png"
};
};
function sqrsO743b() {
    if(document.getElementById("imgSqrs743").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs743").src = "img/sqrs/wSqr.png"
};
};
function sqrsO744b() {
    if(document.getElementById("imgSqrs744").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs744").src = "img/sqrs/wSqr.png"
};
};
function sqrsO745b() {
    if(document.getElementById("imgSqrs745").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs745").src = "img/sqrs/wSqr.png"
};
};
function sqrsO746b() {
    if(document.getElementById("imgSqrs746").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs746").src = "img/sqrs/wSqr.png"
};
};
function sqrsO747b() {
    if(document.getElementById("imgSqrs747").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs747").src = "img/sqrs/wSqr.png"
};
};
function sqrsO748b() {
    if(document.getElementById("imgSqrs748").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs748").src = "img/sqrs/wSqr.png"
};
};
function sqrsO749b() {
    if(document.getElementById("imgSqrs749").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs749").src = "img/sqrs/wSqr.png"
};
};
function sqrsO750b() {
    if(document.getElementById("imgSqrs750").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs750").src = "img/sqrs/wSqr.png"
};
};
function sqrsP751b() {
    if(document.getElementById("imgSqrs751").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs751").src = "img/sqrs/wSqr.png"
};
};
function sqrsP752b() {
    if(document.getElementById("imgSqrs752").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs752").src = "img/sqrs/wSqr.png"
};
};
function sqrsP753b() {
    if(document.getElementById("imgSqrs753").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs753").src = "img/sqrs/wSqr.png"
};
};
function sqrsP754b() {
    if(document.getElementById("imgSqrs754").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs754").src = "img/sqrs/wSqr.png"
};
};
function sqrsP755b() {
    if(document.getElementById("imgSqrs755").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs755").src = "img/sqrs/wSqr.png"
};
};
function sqrsP756b() {
    if(document.getElementById("imgSqrs756").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs756").src = "img/sqrs/wSqr.png"
};
};
function sqrsP757b() {
    if(document.getElementById("imgSqrs757").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs757").src = "img/sqrs/wSqr.png"
};
};
function sqrsP758b() {
    if(document.getElementById("imgSqrs758").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs758").src = "img/sqrs/wSqr.png"
};
};
function sqrsP759b() {
    if(document.getElementById("imgSqrs759").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs759").src = "img/sqrs/wSqr.png"
};
};
function sqrsP760b() {
    if(document.getElementById("imgSqrs760").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs760").src = "img/sqrs/wSqr.png"
};
};
function sqrsP761b() {
    if(document.getElementById("imgSqrs761").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs761").src = "img/sqrs/wSqr.png"
};
};
function sqrsP762b() {
    if(document.getElementById("imgSqrs762").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs762").src = "img/sqrs/wSqr.png"
};
};
function sqrsP763b() {
    if(document.getElementById("imgSqrs763").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs763").src = "img/sqrs/wSqr.png"
};
};
function sqrsP764b() {
    if(document.getElementById("imgSqrs764").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs764").src = "img/sqrs/wSqr.png"
};
};
function sqrsP765b() {
    if(document.getElementById("imgSqrs765").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs765").src = "img/sqrs/wSqr.png"
};
};
function sqrsP766b() {
    if(document.getElementById("imgSqrs766").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs766").src = "img/sqrs/wSqr.png"
};
};
function sqrsP767b() {
    if(document.getElementById("imgSqrs767").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs767").src = "img/sqrs/wSqr.png"
};
};
function sqrsP768b() {
    if(document.getElementById("imgSqrs768").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs768").src = "img/sqrs/wSqr.png"
};
};
function sqrsP769b() {
    if(document.getElementById("imgSqrs769").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs769").src = "img/sqrs/wSqr.png"
};
};
function sqrsP770b() {
    if(document.getElementById("imgSqrs770").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs770").src = "img/sqrs/wSqr.png"
};
};
function sqrsP771b() {
    if(document.getElementById("imgSqrs771").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs771").src = "img/sqrs/wSqr.png"
};
};
function sqrsP772b() {
    if(document.getElementById("imgSqrs772").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs772").src = "img/sqrs/wSqr.png"
};
};
function sqrsP773b() {
    if(document.getElementById("imgSqrs773").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs773").src = "img/sqrs/wSqr.png"
};
};
function sqrsP774b() {
    if(document.getElementById("imgSqrs774").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs774").src = "img/sqrs/wSqr.png"
};
};
function sqrsP775b() {
    if(document.getElementById("imgSqrs775").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs775").src = "img/sqrs/wSqr.png"
};
};
function sqrsP776b() {
    if(document.getElementById("imgSqrs776").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs776").src = "img/sqrs/wSqr.png"
};
};
function sqrsP777b() {
    if(document.getElementById("imgSqrs777").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs777").src = "img/sqrs/wSqr.png"
};
};
function sqrsP778b() {
    if(document.getElementById("imgSqrs778").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs778").src = "img/sqrs/wSqr.png"
};
};
function sqrsP779b() {
    if(document.getElementById("imgSqrs779").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs779").src = "img/sqrs/wSqr.png"
};
};
function sqrsP780b() {
    if(document.getElementById("imgSqrs780").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs780").src = "img/sqrs/wSqr.png"
};
};
function sqrsP781b() {
    if(document.getElementById("imgSqrs781").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs781").src = "img/sqrs/wSqr.png"
};
};
function sqrsP782b() {
    if(document.getElementById("imgSqrs782").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs782").src = "img/sqrs/wSqr.png"
};
};
function sqrsP783b() {
    if(document.getElementById("imgSqrs783").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs783").src = "img/sqrs/wSqr.png"
};
};
function sqrsP784b() {
    if(document.getElementById("imgSqrs784").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs784").src = "img/sqrs/wSqr.png"
};
};
function sqrsP785b() {
    if(document.getElementById("imgSqrs785").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs785").src = "img/sqrs/wSqr.png"
};
};
function sqrsP786b() {
    if(document.getElementById("imgSqrs786").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs786").src = "img/sqrs/wSqr.png"
};
};
function sqrsP787b() {
    if(document.getElementById("imgSqrs787").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs787").src = "img/sqrs/wSqr.png"
};
};
function sqrsP788b() {
    if(document.getElementById("imgSqrs788").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs788").src = "img/sqrs/wSqr.png"
};
};
function sqrsP789b() {
    if(document.getElementById("imgSqrs789").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs789").src = "img/sqrs/wSqr.png"
};
};
function sqrsP790b() {
    if(document.getElementById("imgSqrs790").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs790").src = "img/sqrs/wSqr.png"
};
};
function sqrsP791b() {
    if(document.getElementById("imgSqrs791").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs791").src = "img/sqrs/wSqr.png"
};
};
function sqrsP792b() {
    if(document.getElementById("imgSqrs792").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs792").src = "img/sqrs/wSqr.png"
};
};
function sqrsP793b() {
    if(document.getElementById("imgSqrs793").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs793").src = "img/sqrs/wSqr.png"
};
};
function sqrsP794b() {
    if(document.getElementById("imgSqrs794").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs794").src = "img/sqrs/wSqr.png"
};
};
function sqrsP795b() {
    if(document.getElementById("imgSqrs795").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs795").src = "img/sqrs/wSqr.png"
};
};
function sqrsP796b() {
    if(document.getElementById("imgSqrs796").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs796").src = "img/sqrs/wSqr.png"
};
};
function sqrsP797b() {
    if(document.getElementById("imgSqrs797").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs797").src = "img/sqrs/wSqr.png"
};
};
function sqrsP798b() {
    if(document.getElementById("imgSqrs798").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs798").src = "img/sqrs/wSqr.png"
};
};
function sqrsP799b() {
    if(document.getElementById("imgSqrs799").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs799").src = "img/sqrs/wSqr.png"
};
};
function sqrsP800b() {
    if(document.getElementById("imgSqrs800").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs800").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ801b() {
    if(document.getElementById("imgSqrs801").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs801").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ802b() {
    if(document.getElementById("imgSqrs802").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs802").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ803b() {
    if(document.getElementById("imgSqrs803").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs803").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ804b() {
    if(document.getElementById("imgSqrs804").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs804").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ805b() {
    if(document.getElementById("imgSqrs805").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs805").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ806b() {
    if(document.getElementById("imgSqrs806").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs806").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ807b() {
    if(document.getElementById("imgSqrs807").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs807").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ808b() {
    if(document.getElementById("imgSqrs808").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs808").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ809b() {
    if(document.getElementById("imgSqrs809").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs809").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ810b() {
    if(document.getElementById("imgSqrs810").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs810").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ811b() {
    if(document.getElementById("imgSqrs811").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs811").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ812b() {
    if(document.getElementById("imgSqrs812").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs812").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ813b() {
    if(document.getElementById("imgSqrs813").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs813").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ814b() {
    if(document.getElementById("imgSqrs814").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs814").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ815b() {
    if(document.getElementById("imgSqrs815").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs815").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ816b() {
    if(document.getElementById("imgSqrs816").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs816").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ817b() {
    if(document.getElementById("imgSqrs817").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs817").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ818b() {
    if(document.getElementById("imgSqrs818").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs818").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ819b() {
    if(document.getElementById("imgSqrs819").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs819").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ820b() {
    if(document.getElementById("imgSqrs820").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs820").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ821b() {
    if(document.getElementById("imgSqrs821").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs821").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ822b() {
    if(document.getElementById("imgSqrs822").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs822").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ823b() {
    if(document.getElementById("imgSqrs823").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs823").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ824b() {
    if(document.getElementById("imgSqrs824").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs824").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ825b() {
    if(document.getElementById("imgSqrs825").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs825").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ826b() {
    if(document.getElementById("imgSqrs826").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs826").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ827b() {
    if(document.getElementById("imgSqrs827").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs827").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ828b() {
    if(document.getElementById("imgSqrs828").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs828").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ829b() {
    if(document.getElementById("imgSqrs829").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs829").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ830b() {
    if(document.getElementById("imgSqrs830").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs830").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ831b() {
    if(document.getElementById("imgSqrs831").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs831").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ832b() {
    if(document.getElementById("imgSqrs832").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs832").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ833b() {
    if(document.getElementById("imgSqrs833").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs833").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ834b() {
    if(document.getElementById("imgSqrs834").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs834").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ835b() {
    if(document.getElementById("imgSqrs835").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs835").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ836b() {
    if(document.getElementById("imgSqrs836").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs836").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ837b() {
    if(document.getElementById("imgSqrs837").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs837").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ838b() {
    if(document.getElementById("imgSqrs838").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs838").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ839b() {
    if(document.getElementById("imgSqrs839").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs839").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ840b() {
    if(document.getElementById("imgSqrs840").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs840").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ841b() {
    if(document.getElementById("imgSqrs841").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs841").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ842b() {
    if(document.getElementById("imgSqrs842").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs842").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ843b() {
    if(document.getElementById("imgSqrs843").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs843").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ844b() {
    if(document.getElementById("imgSqrs844").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs844").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ845b() {
    if(document.getElementById("imgSqrs845").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs845").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ846b() {
    if(document.getElementById("imgSqrs846").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs846").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ847b() {
    if(document.getElementById("imgSqrs847").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs847").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ848b() {
    if(document.getElementById("imgSqrs848").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs848").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ849b() {
    if(document.getElementById("imgSqrs849").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs849").src = "img/sqrs/wSqr.png"
};
};
function sqrsQ850b() {
    if(document.getElementById("imgSqrs850").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs850").src = "img/sqrs/wSqr.png"
};
};
function sqrsR851b() {
    if(document.getElementById("imgSqrs851").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs851").src = "img/sqrs/wSqr.png"
};
};
function sqrsR852b() {
    if(document.getElementById("imgSqrs852").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs852").src = "img/sqrs/wSqr.png"
};
};
function sqrsR853b() {
    if(document.getElementById("imgSqrs853").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs853").src = "img/sqrs/wSqr.png"
};
};
function sqrsR854b() {
    if(document.getElementById("imgSqrs854").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs854").src = "img/sqrs/wSqr.png"
};
};
function sqrsR855b() {
    if(document.getElementById("imgSqrs855").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs855").src = "img/sqrs/wSqr.png"
};
};
function sqrsR856b() {
    if(document.getElementById("imgSqrs856").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs856").src = "img/sqrs/wSqr.png"
};
};
function sqrsR857b() {
    if(document.getElementById("imgSqrs857").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs857").src = "img/sqrs/wSqr.png"
};
};
function sqrsR858b() {
    if(document.getElementById("imgSqrs858").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs858").src = "img/sqrs/wSqr.png"
};
};
function sqrsR859b() {
    if(document.getElementById("imgSqrs859").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs859").src = "img/sqrs/wSqr.png"
};
};
function sqrsR860b() {
    if(document.getElementById("imgSqrs860").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs860").src = "img/sqrs/wSqr.png"
};
};
function sqrsR861b() {
    if(document.getElementById("imgSqrs861").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs861").src = "img/sqrs/wSqr.png"
};
};
function sqrsR862b() {
    if(document.getElementById("imgSqrs862").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs862").src = "img/sqrs/wSqr.png"
};
};
function sqrsR863b() {
    if(document.getElementById("imgSqrs863").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs863").src = "img/sqrs/wSqr.png"
};
};
function sqrsR864b() {
    if(document.getElementById("imgSqrs864").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs864").src = "img/sqrs/wSqr.png"
};
};
function sqrsR865b() {
    if(document.getElementById("imgSqrs865").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs865").src = "img/sqrs/wSqr.png"
};
};
function sqrsR866b() {
    if(document.getElementById("imgSqrs866").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs866").src = "img/sqrs/wSqr.png"
};
};
function sqrsR867b() {
    if(document.getElementById("imgSqrs867").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs867").src = "img/sqrs/wSqr.png"
};
};
function sqrsR868b() {
    if(document.getElementById("imgSqrs868").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs868").src = "img/sqrs/wSqr.png"
};
};
function sqrsR869b() {
    if(document.getElementById("imgSqrs869").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs869").src = "img/sqrs/wSqr.png"
};
};
function sqrsR870b() {
    if(document.getElementById("imgSqrs870").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs870").src = "img/sqrs/wSqr.png"
};
};
function sqrsR871b() {
    if(document.getElementById("imgSqrs871").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs871").src = "img/sqrs/wSqr.png"
};
};
function sqrsR872b() {
    if(document.getElementById("imgSqrs872").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs872").src = "img/sqrs/wSqr.png"
};
};
function sqrsR873b() {
    if(document.getElementById("imgSqrs873").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs873").src = "img/sqrs/wSqr.png"
};
};
function sqrsR874b() {
    if(document.getElementById("imgSqrs874").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs874").src = "img/sqrs/wSqr.png"
};
};
function sqrsR875b() {
    if(document.getElementById("imgSqrs875").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs875").src = "img/sqrs/wSqr.png"
};
};
function sqrsR876b() {
    if(document.getElementById("imgSqrs876").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs876").src = "img/sqrs/wSqr.png"
};
};
function sqrsR877b() {
    if(document.getElementById("imgSqrs877").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs877").src = "img/sqrs/wSqr.png"
};
};
function sqrsR878b() {
    if(document.getElementById("imgSqrs878").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs878").src = "img/sqrs/wSqr.png"
};
};
function sqrsR879b() {
    if(document.getElementById("imgSqrs879").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs879").src = "img/sqrs/wSqr.png"
};
};
function sqrsR880b() {
    if(document.getElementById("imgSqrs880").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs880").src = "img/sqrs/wSqr.png"
};
};
function sqrsR881b() {
    if(document.getElementById("imgSqrs881").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs881").src = "img/sqrs/wSqr.png"
};
};
function sqrsR882b() {
    if(document.getElementById("imgSqrs882").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs882").src = "img/sqrs/wSqr.png"
};
};
function sqrsR883b() {
    if(document.getElementById("imgSqrs883").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs883").src = "img/sqrs/wSqr.png"
};
};
function sqrsR884b() {
    if(document.getElementById("imgSqrs884").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs884").src = "img/sqrs/wSqr.png"
};
};
function sqrsR885b() {
    if(document.getElementById("imgSqrs885").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs885").src = "img/sqrs/wSqr.png"
};
};
function sqrsR886b() {
    if(document.getElementById("imgSqrs886").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs886").src = "img/sqrs/wSqr.png"
};
};
function sqrsR887b() {
    if(document.getElementById("imgSqrs887").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs887").src = "img/sqrs/wSqr.png"
};
};
function sqrsR888b() {
    if(document.getElementById("imgSqrs888").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs888").src = "img/sqrs/wSqr.png"
};
};
function sqrsR889b() {
    if(document.getElementById("imgSqrs889").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs889").src = "img/sqrs/wSqr.png"
};
};
function sqrsR890b() {
    if(document.getElementById("imgSqrs890").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs890").src = "img/sqrs/wSqr.png"
};
};
function sqrsR891b() {
    if(document.getElementById("imgSqrs891").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs891").src = "img/sqrs/wSqr.png"
};
};
function sqrsR892b() {
    if(document.getElementById("imgSqrs892").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs892").src = "img/sqrs/wSqr.png"
};
};
function sqrsR893b() {
    if(document.getElementById("imgSqrs893").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs893").src = "img/sqrs/wSqr.png"
};
};
function sqrsR894b() {
    if(document.getElementById("imgSqrs894").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs894").src = "img/sqrs/wSqr.png"
};
};
function sqrsR895b() {
    if(document.getElementById("imgSqrs895").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs895").src = "img/sqrs/wSqr.png"
};
};
function sqrsR896b() {
    if(document.getElementById("imgSqrs896").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs896").src = "img/sqrs/wSqr.png"
};
};
function sqrsR897b() {
    if(document.getElementById("imgSqrs897").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs897").src = "img/sqrs/wSqr.png"
};
};
function sqrsR898b() {
    if(document.getElementById("imgSqrs898").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs898").src = "img/sqrs/wSqr.png"
};
};
function sqrsR899b() {
    if(document.getElementById("imgSqrs899").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs899").src = "img/sqrs/wSqr.png"
};
};
function sqrsR900b() {
    if(document.getElementById("imgSqrs900").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs900").src = "img/sqrs/wSqr.png"
};
};
function sqrsS901b() {
    if(document.getElementById("imgSqrs901").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs901").src = "img/sqrs/wSqr.png"
};
};
function sqrsS902b() {
    if(document.getElementById("imgSqrs902").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs902").src = "img/sqrs/wSqr.png"
};
};
function sqrsS903b() {
    if(document.getElementById("imgSqrs903").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs903").src = "img/sqrs/wSqr.png"
};
};
function sqrsS904b() {
    if(document.getElementById("imgSqrs904").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs904").src = "img/sqrs/wSqr.png"
};
};
function sqrsS905b() {
    if(document.getElementById("imgSqrs905").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs905").src = "img/sqrs/wSqr.png"
};
};
function sqrsS906b() {
    if(document.getElementById("imgSqrs906").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs906").src = "img/sqrs/wSqr.png"
};
};
function sqrsS907b() {
    if(document.getElementById("imgSqrs907").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs907").src = "img/sqrs/wSqr.png"
};
};
function sqrsS908b() {
    if(document.getElementById("imgSqrs908").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs908").src = "img/sqrs/wSqr.png"
};
};
function sqrsS909b() {
    if(document.getElementById("imgSqrs909").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs909").src = "img/sqrs/wSqr.png"
};
};
function sqrsS910b() {
    if(document.getElementById("imgSqrs910").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs910").src = "img/sqrs/wSqr.png"
};
};
function sqrsS911b() {
    if(document.getElementById("imgSqrs911").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs911").src = "img/sqrs/wSqr.png"
};
};
function sqrsS912b() {
    if(document.getElementById("imgSqrs912").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs912").src = "img/sqrs/wSqr.png"
};
};
function sqrsS913b() {
    if(document.getElementById("imgSqrs913").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs913").src = "img/sqrs/wSqr.png"
};
};
function sqrsS914b() {
    if(document.getElementById("imgSqrs914").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs914").src = "img/sqrs/wSqr.png"
};
};
function sqrsS915b() {
    if(document.getElementById("imgSqrs915").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs915").src = "img/sqrs/wSqr.png"
};
};
function sqrsS916b() {
    if(document.getElementById("imgSqrs916").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs916").src = "img/sqrs/wSqr.png"
};
};
function sqrsS917b() {
    if(document.getElementById("imgSqrs917").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs917").src = "img/sqrs/wSqr.png"
};
};
function sqrsS918b() {
    if(document.getElementById("imgSqrs918").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs918").src = "img/sqrs/wSqr.png"
};
};
function sqrsS919b() {
    if(document.getElementById("imgSqrs919").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs919").src = "img/sqrs/wSqr.png"
};
};
function sqrsS920b() {
    if(document.getElementById("imgSqrs920").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs920").src = "img/sqrs/wSqr.png"
};
};
function sqrsS921b() {
    if(document.getElementById("imgSqrs921").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs921").src = "img/sqrs/wSqr.png"
};
};
function sqrsS922b() {
    if(document.getElementById("imgSqrs922").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs922").src = "img/sqrs/wSqr.png"
};
};
function sqrsS923b() {
    if(document.getElementById("imgSqrs923").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs923").src = "img/sqrs/wSqr.png"
};
};
function sqrsS924b() {
    if(document.getElementById("imgSqrs924").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs924").src = "img/sqrs/wSqr.png"
};
};
function sqrsS925b() {
    if(document.getElementById("imgSqrs925").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs925").src = "img/sqrs/wSqr.png"
};
};
function sqrsS926b() {
    if(document.getElementById("imgSqrs926").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs926").src = "img/sqrs/wSqr.png"
};
};
function sqrsS927b() {
    if(document.getElementById("imgSqrs927").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs927").src = "img/sqrs/wSqr.png"
};
};
function sqrsS928b() {
    if(document.getElementById("imgSqrs928").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs928").src = "img/sqrs/wSqr.png"
};
};
function sqrsS929b() {
    if(document.getElementById("imgSqrs929").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs929").src = "img/sqrs/wSqr.png"
};
};
function sqrsS930b() {
    if(document.getElementById("imgSqrs930").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs930").src = "img/sqrs/wSqr.png"
};
};
function sqrsS931b() {
    if(document.getElementById("imgSqrs931").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs931").src = "img/sqrs/wSqr.png"
};
};
function sqrsS932b() {
    if(document.getElementById("imgSqrs932").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs932").src = "img/sqrs/wSqr.png"
};
};
function sqrsS933b() {
    if(document.getElementById("imgSqrs933").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs933").src = "img/sqrs/wSqr.png"
};
};
function sqrsS934b() {
    if(document.getElementById("imgSqrs934").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs934").src = "img/sqrs/wSqr.png"
};
};
function sqrsS935b() {
    if(document.getElementById("imgSqrs935").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs935").src = "img/sqrs/wSqr.png"
};
};
function sqrsS936b() {
    if(document.getElementById("imgSqrs936").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs936").src = "img/sqrs/wSqr.png"
};
};
function sqrsS937b() {
    if(document.getElementById("imgSqrs937").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs937").src = "img/sqrs/wSqr.png"
};
};
function sqrsS938b() {
    if(document.getElementById("imgSqrs938").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs938").src = "img/sqrs/wSqr.png"
};
};
function sqrsS939b() {
    if(document.getElementById("imgSqrs939").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs939").src = "img/sqrs/wSqr.png"
};
};
function sqrsS940b() {
    if(document.getElementById("imgSqrs940").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs940").src = "img/sqrs/wSqr.png"
};
};
function sqrsS941b() {
    if(document.getElementById("imgSqrs941").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs941").src = "img/sqrs/wSqr.png"
};
};
function sqrsS942b() {
    if(document.getElementById("imgSqrs942").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs942").src = "img/sqrs/wSqr.png"
};
};
function sqrsS943b() {
    if(document.getElementById("imgSqrs943").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs943").src = "img/sqrs/wSqr.png"
};
};
function sqrsS944b() {
    if(document.getElementById("imgSqrs944").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs944").src = "img/sqrs/wSqr.png"
};
};
function sqrsS945b() {
    if(document.getElementById("imgSqrs945").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs945").src = "img/sqrs/wSqr.png"
};
};
function sqrsS946b() {
    if(document.getElementById("imgSqrs946").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs946").src = "img/sqrs/wSqr.png"
};
};
function sqrsS947b() {
    if(document.getElementById("imgSqrs947").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs947").src = "img/sqrs/wSqr.png"
};
};
function sqrsS948b() {
    if(document.getElementById("imgSqrs948").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs948").src = "img/sqrs/wSqr.png"
};
};
function sqrsS949b() {
    if(document.getElementById("imgSqrs949").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs949").src = "img/sqrs/wSqr.png"
};
};
function sqrsS950b() {
    if(document.getElementById("imgSqrs950").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs950").src = "img/sqrs/wSqr.png"
};
};
function sqrsT951b() {
    if(document.getElementById("imgSqrs951").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs951").src = "img/sqrs/wSqr.png"
};
};
function sqrsT952b() {
    if(document.getElementById("imgSqrs952").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs952").src = "img/sqrs/wSqr.png"
};
};
function sqrsT953b() {
    if(document.getElementById("imgSqrs953").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs953").src = "img/sqrs/wSqr.png"
};
};
function sqrsT954b() {
    if(document.getElementById("imgSqrs954").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs954").src = "img/sqrs/wSqr.png"
};
};
function sqrsT955b() {
    if(document.getElementById("imgSqrs955").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs955").src = "img/sqrs/wSqr.png"
};
};
function sqrsT956b() {
    if(document.getElementById("imgSqrs956").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs956").src = "img/sqrs/wSqr.png"
};
};
function sqrsT957b() {
    if(document.getElementById("imgSqrs957").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs957").src = "img/sqrs/wSqr.png"
};
};
function sqrsT958b() {
    if(document.getElementById("imgSqrs958").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs958").src = "img/sqrs/wSqr.png"
};
};
function sqrsT959b() {
    if(document.getElementById("imgSqrs959").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs959").src = "img/sqrs/wSqr.png"
};
};
function sqrsT960b() {
    if(document.getElementById("imgSqrs960").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs960").src = "img/sqrs/wSqr.png"
};
};
function sqrsT961b() {
    if(document.getElementById("imgSqrs961").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs961").src = "img/sqrs/wSqr.png"
};
};
function sqrsT962b() {
    if(document.getElementById("imgSqrs962").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs962").src = "img/sqrs/wSqr.png"
};
};
function sqrsT963b() {
    if(document.getElementById("imgSqrs963").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs963").src = "img/sqrs/wSqr.png"
};
};
function sqrsT964b() {
    if(document.getElementById("imgSqrs964").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs964").src = "img/sqrs/wSqr.png"
};
};
function sqrsT965b() {
    if(document.getElementById("imgSqrs965").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs965").src = "img/sqrs/wSqr.png"
};
};
function sqrsT966b() {
    if(document.getElementById("imgSqrs966").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs966").src = "img/sqrs/wSqr.png"
};
};
function sqrsT967b() {
    if(document.getElementById("imgSqrs967").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs967").src = "img/sqrs/wSqr.png"
};
};
function sqrsT968b() {
    if(document.getElementById("imgSqrs968").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs968").src = "img/sqrs/wSqr.png"
};
};
function sqrsT969b() {
    if(document.getElementById("imgSqrs969").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs969").src = "img/sqrs/wSqr.png"
};
};
function sqrsT970b() {
    if(document.getElementById("imgSqrs970").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs970").src = "img/sqrs/wSqr.png"
};
};
function sqrsT971b() {
    if(document.getElementById("imgSqrs971").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs971").src = "img/sqrs/wSqr.png"
};
};
function sqrsT972b() {
    if(document.getElementById("imgSqrs972").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs972").src = "img/sqrs/wSqr.png"
};
};
function sqrsT973b() {
    if(document.getElementById("imgSqrs973").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs973").src = "img/sqrs/wSqr.png"
};
};
function sqrsT974b() {
    if(document.getElementById("imgSqrs974").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs974").src = "img/sqrs/wSqr.png"
};
};
function sqrsT975b() {
    if(document.getElementById("imgSqrs975").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs975").src = "img/sqrs/wSqr.png"
};
};
function sqrsT976b() {
    if(document.getElementById("imgSqrs976").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs976").src = "img/sqrs/wSqr.png"
};
};
function sqrsT977b() {
    if(document.getElementById("imgSqrs977").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs977").src = "img/sqrs/wSqr.png"
};
};
function sqrsT978b() {
    if(document.getElementById("imgSqrs978").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs978").src = "img/sqrs/wSqr.png"
};
};
function sqrsT979b() {
    if(document.getElementById("imgSqrs979").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs979").src = "img/sqrs/wSqr.png"
};
};
function sqrsT980b() {
    if(document.getElementById("imgSqrs980").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs980").src = "img/sqrs/wSqr.png"
};
};
function sqrsT981b() {
    if(document.getElementById("imgSqrs981").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs981").src = "img/sqrs/wSqr.png"
};
};
function sqrsT982b() {
    if(document.getElementById("imgSqrs982").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs982").src = "img/sqrs/wSqr.png"
};
};
function sqrsT983b() {
    if(document.getElementById("imgSqrs983").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs983").src = "img/sqrs/wSqr.png"
};
};
function sqrsT984b() {
    if(document.getElementById("imgSqrs984").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs984").src = "img/sqrs/wSqr.png"
};
};
function sqrsT985b() {
    if(document.getElementById("imgSqrs985").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs985").src = "img/sqrs/wSqr.png"
};
};
function sqrsT986b() {
    if(document.getElementById("imgSqrs986").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs986").src = "img/sqrs/wSqr.png"
};
};
function sqrsT987b() {
    if(document.getElementById("imgSqrs987").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs987").src = "img/sqrs/wSqr.png"
};
};
function sqrsT988b() {
    if(document.getElementById("imgSqrs988").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs988").src = "img/sqrs/wSqr.png"
};
};
function sqrsT989b() {
    if(document.getElementById("imgSqrs989").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs989").src = "img/sqrs/wSqr.png"
};
};
function sqrsT990b() {
    if(document.getElementById("imgSqrs990").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs990").src = "img/sqrs/wSqr.png"
};
};
function sqrsT991b() {
    if(document.getElementById("imgSqrs991").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs991").src = "img/sqrs/wSqr.png"
};
};
function sqrsT992b() {
    if(document.getElementById("imgSqrs992").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs992").src = "img/sqrs/wSqr.png"
};
};
function sqrsT993b() {
    if(document.getElementById("imgSqrs993").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs993").src = "img/sqrs/wSqr.png"
};
};
function sqrsT994b() {
    if(document.getElementById("imgSqrs994").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs994").src = "img/sqrs/wSqr.png"
};
};
function sqrsT995b() {
    if(document.getElementById("imgSqrs995").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs995").src = "img/sqrs/wSqr.png"
};
};
function sqrsT996b() {
    if(document.getElementById("imgSqrs996").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs996").src = "img/sqrs/wSqr.png"
};
};
function sqrsT997b() {
    if(document.getElementById("imgSqrs997").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs997").src = "img/sqrs/wSqr.png"
};
};
function sqrsT998b() {
    if(document.getElementById("imgSqrs998").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs998").src = "img/sqrs/wSqr.png"
};
};
function sqrsT999b() {
    if(document.getElementById("imgSqrs999").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs999").src = "img/sqrs/wSqr.png"
};
};
function sqrsT1000b() {
    if(document.getElementById("imgSqrs1000").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1000").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1001b() {
    if(document.getElementById("imgSqrs1001").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1001").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1002b() {
    if(document.getElementById("imgSqrs1002").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1002").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1003b() {
    if(document.getElementById("imgSqrs1003").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1003").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1004b() {
    if(document.getElementById("imgSqrs1004").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1004").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1005b() {
    if(document.getElementById("imgSqrs1005").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1005").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1006b() {
    if(document.getElementById("imgSqrs1006").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1006").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1007b() {
    if(document.getElementById("imgSqrs1007").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1007").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1008b() {
    if(document.getElementById("imgSqrs1008").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1008").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1009b() {
    if(document.getElementById("imgSqrs1009").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1009").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1010b() {
    if(document.getElementById("imgSqrs1010").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1010").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1011b() {
    if(document.getElementById("imgSqrs1011").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1011").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1012b() {
    if(document.getElementById("imgSqrs1012").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1012").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1013b() {
    if(document.getElementById("imgSqrs1013").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1013").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1014b() {
    if(document.getElementById("imgSqrs1014").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1014").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1015b() {
    if(document.getElementById("imgSqrs1015").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1015").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1016b() {
    if(document.getElementById("imgSqrs1016").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1016").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1017b() {
    if(document.getElementById("imgSqrs1017").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1017").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1018b() {
    if(document.getElementById("imgSqrs1018").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1018").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1019b() {
    if(document.getElementById("imgSqrs1019").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1019").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1020b() {
    if(document.getElementById("imgSqrs1020").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1020").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1021b() {
    if(document.getElementById("imgSqrs1021").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1021").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1022b() {
    if(document.getElementById("imgSqrs1022").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1022").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1023b() {
    if(document.getElementById("imgSqrs1023").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1023").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1024b() {
    if(document.getElementById("imgSqrs1024").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1024").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1025b() {
    if(document.getElementById("imgSqrs1025").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1025").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1026b() {
    if(document.getElementById("imgSqrs1026").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1026").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1027b() {
    if(document.getElementById("imgSqrs1027").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1027").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1028b() {
    if(document.getElementById("imgSqrs1028").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1028").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1029b() {
    if(document.getElementById("imgSqrs1029").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1029").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1030b() {
    if(document.getElementById("imgSqrs1030").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1030").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1031b() {
    if(document.getElementById("imgSqrs1031").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1031").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1032b() {
    if(document.getElementById("imgSqrs1032").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1032").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1033b() {
    if(document.getElementById("imgSqrs1033").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1033").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1034b() {
    if(document.getElementById("imgSqrs1034").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1034").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1035b() {
    if(document.getElementById("imgSqrs1035").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1035").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1036b() {
    if(document.getElementById("imgSqrs1036").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1036").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1037b() {
    if(document.getElementById("imgSqrs1037").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1037").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1038b() {
    if(document.getElementById("imgSqrs1038").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1038").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1039b() {
    if(document.getElementById("imgSqrs1039").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1039").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1040b() {
    if(document.getElementById("imgSqrs1040").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1040").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1041b() {
    if(document.getElementById("imgSqrs1041").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1041").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1042b() {
    if(document.getElementById("imgSqrs1042").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1042").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1043b() {
    if(document.getElementById("imgSqrs1043").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1043").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1044b() {
    if(document.getElementById("imgSqrs1044").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1044").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1045b() {
    if(document.getElementById("imgSqrs1045").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1045").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1046b() {
    if(document.getElementById("imgSqrs1046").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1046").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1047b() {
    if(document.getElementById("imgSqrs1047").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1047").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1048b() {
    if(document.getElementById("imgSqrs1048").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1048").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1049b() {
    if(document.getElementById("imgSqrs1049").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1049").src = "img/sqrs/wSqr.png"
};
};
function sqrsU1050b() {
    if(document.getElementById("imgSqrs1050").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1050").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1051b() {
    if(document.getElementById("imgSqrs1051").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1051").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1052b() {
    if(document.getElementById("imgSqrs1052").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1052").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1053b() {
    if(document.getElementById("imgSqrs1053").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1053").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1054b() {
    if(document.getElementById("imgSqrs1054").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1054").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1055b() {
    if(document.getElementById("imgSqrs1055").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1055").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1056b() {
    if(document.getElementById("imgSqrs1056").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1056").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1057b() {
    if(document.getElementById("imgSqrs1057").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1057").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1058b() {
    if(document.getElementById("imgSqrs1058").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1058").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1059b() {
    if(document.getElementById("imgSqrs1059").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1059").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1060b() {
    if(document.getElementById("imgSqrs1060").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1060").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1061b() {
    if(document.getElementById("imgSqrs1061").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1061").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1062b() {
    if(document.getElementById("imgSqrs1062").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1062").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1063b() {
    if(document.getElementById("imgSqrs1063").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1063").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1064b() {
    if(document.getElementById("imgSqrs1064").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1064").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1065b() {
    if(document.getElementById("imgSqrs1065").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1065").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1066b() {
    if(document.getElementById("imgSqrs1066").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1066").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1067b() {
    if(document.getElementById("imgSqrs1067").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1067").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1068b() {
    if(document.getElementById("imgSqrs1068").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1068").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1069b() {
    if(document.getElementById("imgSqrs1069").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1069").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1070b() {
    if(document.getElementById("imgSqrs1070").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1070").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1071b() {
    if(document.getElementById("imgSqrs1071").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1071").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1072b() {
    if(document.getElementById("imgSqrs1072").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1072").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1073b() {
    if(document.getElementById("imgSqrs1073").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1073").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1074b() {
    if(document.getElementById("imgSqrs1074").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1074").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1075b() {
    if(document.getElementById("imgSqrs1075").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1075").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1076b() {
    if(document.getElementById("imgSqrs1076").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1076").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1077b() {
    if(document.getElementById("imgSqrs1077").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1077").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1078b() {
    if(document.getElementById("imgSqrs1078").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1078").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1079b() {
    if(document.getElementById("imgSqrs1079").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1079").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1080b() {
    if(document.getElementById("imgSqrs1080").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1080").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1081b() {
    if(document.getElementById("imgSqrs1081").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1081").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1082b() {
    if(document.getElementById("imgSqrs1082").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1082").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1083b() {
    if(document.getElementById("imgSqrs1083").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1083").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1084b() {
    if(document.getElementById("imgSqrs1084").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1084").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1085b() {
    if(document.getElementById("imgSqrs1085").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1085").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1086b() {
    if(document.getElementById("imgSqrs1086").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1086").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1087b() {
    if(document.getElementById("imgSqrs1087").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1087").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1088b() {
    if(document.getElementById("imgSqrs1088").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1088").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1089b() {
    if(document.getElementById("imgSqrs1089").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1089").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1090b() {
    if(document.getElementById("imgSqrs1090").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1090").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1091b() {
    if(document.getElementById("imgSqrs1091").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1091").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1092b() {
    if(document.getElementById("imgSqrs1092").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1092").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1093b() {
    if(document.getElementById("imgSqrs1093").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1093").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1094b() {
    if(document.getElementById("imgSqrs1094").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1094").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1095b() {
    if(document.getElementById("imgSqrs1095").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1095").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1096b() {
    if(document.getElementById("imgSqrs1096").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1096").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1097b() {
    if(document.getElementById("imgSqrs1097").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1097").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1098b() {
    if(document.getElementById("imgSqrs1098").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1098").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1099b() {
    if(document.getElementById("imgSqrs1099").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1099").src = "img/sqrs/wSqr.png"
};
};
function sqrsV1100b() {
    if(document.getElementById("imgSqrs1100").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1100").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1101b() {
    if(document.getElementById("imgSqrs1101").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1101").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1102b() {
    if(document.getElementById("imgSqrs1102").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1102").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1103b() {
    if(document.getElementById("imgSqrs1103").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1103").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1104b() {
    if(document.getElementById("imgSqrs1104").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1104").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1105b() {
    if(document.getElementById("imgSqrs1105").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1105").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1106b() {
    if(document.getElementById("imgSqrs1106").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1106").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1107b() {
    if(document.getElementById("imgSqrs1107").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1107").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1108b() {
    if(document.getElementById("imgSqrs1108").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1108").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1109b() {
    if(document.getElementById("imgSqrs1109").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1109").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1110b() {
    if(document.getElementById("imgSqrs1110").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1110").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1111b() {
    if(document.getElementById("imgSqrs1111").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1111").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1112b() {
    if(document.getElementById("imgSqrs1112").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1112").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1113b() {
    if(document.getElementById("imgSqrs1113").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1113").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1114b() {
    if(document.getElementById("imgSqrs1114").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1114").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1115b() {
    if(document.getElementById("imgSqrs1115").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1115").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1116b() {
    if(document.getElementById("imgSqrs1116").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1116").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1117b() {
    if(document.getElementById("imgSqrs1117").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1117").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1118b() {
    if(document.getElementById("imgSqrs1118").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1118").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1119b() {
    if(document.getElementById("imgSqrs1119").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1119").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1120b() {
    if(document.getElementById("imgSqrs1120").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1120").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1121b() {
    if(document.getElementById("imgSqrs1121").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1121").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1122b() {
    if(document.getElementById("imgSqrs1122").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1122").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1123b() {
    if(document.getElementById("imgSqrs1123").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1123").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1124b() {
    if(document.getElementById("imgSqrs1124").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1124").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1125b() {
    if(document.getElementById("imgSqrs1125").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1125").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1126b() {
    if(document.getElementById("imgSqrs1126").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1126").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1127b() {
    if(document.getElementById("imgSqrs1127").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1127").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1128b() {
    if(document.getElementById("imgSqrs1128").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1128").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1129b() {
    if(document.getElementById("imgSqrs1129").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1129").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1130b() {
    if(document.getElementById("imgSqrs1130").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1130").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1131b() {
    if(document.getElementById("imgSqrs1131").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1131").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1132b() {
    if(document.getElementById("imgSqrs1132").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1132").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1133b() {
    if(document.getElementById("imgSqrs1133").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1133").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1134b() {
    if(document.getElementById("imgSqrs1134").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1134").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1135b() {
    if(document.getElementById("imgSqrs1135").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1135").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1136b() {
    if(document.getElementById("imgSqrs1136").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1136").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1137b() {
    if(document.getElementById("imgSqrs1137").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1137").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1138b() {
    if(document.getElementById("imgSqrs1138").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1138").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1139b() {
    if(document.getElementById("imgSqrs1139").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1139").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1140b() {
    if(document.getElementById("imgSqrs1140").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1140").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1141b() {
    if(document.getElementById("imgSqrs1141").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1141").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1142b() {
    if(document.getElementById("imgSqrs1142").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1142").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1143b() {
    if(document.getElementById("imgSqrs1143").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1143").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1144b() {
    if(document.getElementById("imgSqrs1144").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1144").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1145b() {
    if(document.getElementById("imgSqrs1145").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1145").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1146b() {
    if(document.getElementById("imgSqrs1146").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1146").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1147b() {
    if(document.getElementById("imgSqrs1147").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1147").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1148b() {
    if(document.getElementById("imgSqrs1148").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1148").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1149b() {
    if(document.getElementById("imgSqrs1149").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1149").src = "img/sqrs/wSqr.png"
};
};
function sqrsW1150b() {
    if(document.getElementById("imgSqrs1150").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1150").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1151b() {
    if(document.getElementById("imgSqrs1151").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1151").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1152b() {
    if(document.getElementById("imgSqrs1152").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1152").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1153b() {
    if(document.getElementById("imgSqrs1153").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1153").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1154b() {
    if(document.getElementById("imgSqrs1154").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1154").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1155b() {
    if(document.getElementById("imgSqrs1155").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1155").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1156b() {
    if(document.getElementById("imgSqrs1156").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1156").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1157b() {
    if(document.getElementById("imgSqrs1157").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1157").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1158b() {
    if(document.getElementById("imgSqrs1158").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1158").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1159b() {
    if(document.getElementById("imgSqrs1159").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1159").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1160b() {
    if(document.getElementById("imgSqrs1160").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1160").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1161b() {
    if(document.getElementById("imgSqrs1161").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1161").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1162b() {
    if(document.getElementById("imgSqrs1162").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1162").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1163b() {
    if(document.getElementById("imgSqrs1163").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1163").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1164b() {
    if(document.getElementById("imgSqrs1164").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1164").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1165b() {
    if(document.getElementById("imgSqrs1165").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1165").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1166b() {
    if(document.getElementById("imgSqrs1166").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1166").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1167b() {
    if(document.getElementById("imgSqrs1167").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1167").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1168b() {
    if(document.getElementById("imgSqrs1168").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1168").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1169b() {
    if(document.getElementById("imgSqrs1169").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1169").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1170b() {
    if(document.getElementById("imgSqrs1170").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1170").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1171b() {
    if(document.getElementById("imgSqrs1171").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1171").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1172b() {
    if(document.getElementById("imgSqrs1172").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1172").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1173b() {
    if(document.getElementById("imgSqrs1173").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1173").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1174b() {
    if(document.getElementById("imgSqrs1174").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1174").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1175b() {
    if(document.getElementById("imgSqrs1175").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1175").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1176b() {
    if(document.getElementById("imgSqrs1176").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1176").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1177b() {
    if(document.getElementById("imgSqrs1177").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1177").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1178b() {
    if(document.getElementById("imgSqrs1178").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1178").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1179b() {
    if(document.getElementById("imgSqrs1179").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1179").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1180b() {
    if(document.getElementById("imgSqrs1180").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1180").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1181b() {
    if(document.getElementById("imgSqrs1181").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1181").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1182b() {
    if(document.getElementById("imgSqrs1182").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1182").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1183b() {
    if(document.getElementById("imgSqrs1183").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1183").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1184b() {
    if(document.getElementById("imgSqrs1184").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1184").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1185b() {
    if(document.getElementById("imgSqrs1185").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1185").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1186b() {
    if(document.getElementById("imgSqrs1186").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1186").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1187b() {
    if(document.getElementById("imgSqrs1187").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1187").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1188b() {
    if(document.getElementById("imgSqrs1188").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1188").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1189b() {
    if(document.getElementById("imgSqrs1189").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1189").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1190b() {
    if(document.getElementById("imgSqrs1190").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1190").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1191b() {
    if(document.getElementById("imgSqrs1191").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1191").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1192b() {
    if(document.getElementById("imgSqrs1192").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1192").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1193b() {
    if(document.getElementById("imgSqrs1193").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1193").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1194b() {
    if(document.getElementById("imgSqrs1194").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1194").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1195b() {
    if(document.getElementById("imgSqrs1195").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1195").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1196b() {
    if(document.getElementById("imgSqrs1196").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1196").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1197b() {
    if(document.getElementById("imgSqrs1197").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1197").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1198b() {
    if(document.getElementById("imgSqrs1198").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1198").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1199b() {
    if(document.getElementById("imgSqrs1199").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1199").src = "img/sqrs/wSqr.png"
};
};
function sqrsX1200b() {
    if(document.getElementById("imgSqrs1200").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1200").src = "img/sqrs/wSqr.png"
};
};
function sqrsY1201b() {
    if(document.getElementById("imgSqrs1201").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1201").src = "img/sqrs/wSqr.png"
};
};
function sqrsY1202b() {
    if(document.getElementById("imgSqrs1202").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1202").src = "img/sqrs/wSqr.png"
};
};
function sqrsY1203b() {
    if(document.getElementById("imgSqrs1203").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1203").src = "img/sqrs/wSqr.png"
};
};
function sqrsY1204b() {
    if(document.getElementById("imgSqrs1204").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1204").src = "img/sqrs/wSqr.png"
};
};
function sqrsY1205b() {
    if(document.getElementById("imgSqrs1205").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1205").src = "img/sqrs/wSqr.png"
};
};
function sqrsY1206b() {
    if(document.getElementById("imgSqrs1206").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1206").src = "img/sqrs/wSqr.png"
};
};
function sqrsY1207b() {
    if(document.getElementById("imgSqrs1207").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1207").src = "img/sqrs/wSqr.png"
};
};
function sqrsY1208b() {
    if(document.getElementById("imgSqrs1208").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1208").src = "img/sqrs/wSqr.png"
};
};
function sqrsY1209b() {
    if(document.getElementById("imgSqrs1209").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1209").src = "img/sqrs/wSqr.png"
};
};
function sqrsY1210b() {
    if(document.getElementById("imgSqrs1210").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1210").src = "img/sqrs/wSqr.png"
};
};
function sqrsY1211b() {
    if(document.getElementById("imgSqrs1211").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1211").src = "img/sqrs/wSqr.png"
};
};
function sqrsY1212b() {
    if(document.getElementById("imgSqrs1212").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1212").src = "img/sqrs/wSqr.png"
};
};
function sqrsY1213b() {
    if(document.getElementById("imgSqrs1213").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1213").src = "img/sqrs/wSqr.png"
};
};
function sqrsY1214b() {
    if(document.getElementById("imgSqrs1214").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1214").src = "img/sqrs/wSqr.png"
};
};
function sqrsY1215b() {
    if(document.getElementById("imgSqrs1215").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1215").src = "img/sqrs/wSqr.png"
};
};
function sqrsY1216b() {
    if(document.getElementById("imgSqrs1216").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1216").src = "img/sqrs/wSqr.png"
};
};
function sqrsY1217b() {
    if(document.getElementById("imgSqrs1217").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1217").src = "img/sqrs/wSqr.png"
};
};
function sqrsY1218b() {
    if(document.getElementById("imgSqrs1218").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1218").src = "img/sqrs/wSqr.png"
};
};
function sqrsY1219b() {
    if(document.getElementById("imgSqrs1219").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1219").src = "img/sqrs/wSqr.png"
};
};
function sqrsY1220b() {
    if(document.getElementById("imgSqrs1220").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1220").src = "img/sqrs/wSqr.png"
};
};
function sqrsY1221b() {
    if(document.getElementById("imgSqrs1221").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1221").src = "img/sqrs/wSqr.png"
};
};
function sqrsY1222b() {
    if(document.getElementById("imgSqrs1222").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1222").src = "img/sqrs/wSqr.png"
};
};
function sqrsY1223b() {
    if(document.getElementById("imgSqrs1223").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1223").src = "img/sqrs/wSqr.png"
};
};
function sqrsY1224b() {
    if(document.getElementById("imgSqrs1224").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1224").src = "img/sqrs/wSqr.png"
};
};
function sqrsY1225b() {
    if(document.getElementById("imgSqrs1225").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1225").src = "img/sqrs/wSqr.png"
};
};