function sqrA1() {
    if(document.getElementById("imgSqrs1").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1").src = "img/sqrs/blSqr.png"
};
};

function sqrA2() {
    if(document.getElementById("imgSqrs2").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs2").src = "img/sqrs/blSqr.png"
};
};

function sqrA3() {
    if(document.getElementById("imgSqrs3").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs3").src = "img/sqrs/blSqr.png"
};
};

function sqrA4() {
    if(document.getElementById("imgSqrs4").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs4").src = "img/sqrs/blSqr.png"
};
};

function sqrA5() {
    if(document.getElementById("imgSqrs5").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs5").src = "img/sqrs/blSqr.png"
};
};

function sqrA6() {
    if(document.getElementById("imgSqrs6").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs6").src = "img/sqrs/blSqr.png"
};
};

function sqrA7() {
    if(document.getElementById("imgSqrs7").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs7").src = "img/sqrs/blSqr.png"
};
};

function sqrA8() {
    if(document.getElementById("imgSqrs8").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs8").src = "img/sqrs/blSqr.png"
};
};

function sqrA9() {
    if(document.getElementById("imgSqrs9").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs9").src = "img/sqrs/blSqr.png"
};
};

function sqrA10() {
    if(document.getElementById("imgSqrs10").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs10").src = "img/sqrs/blSqr.png"
};
};

function sqrA11() {
    if(document.getElementById("imgSqrs11").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs11").src = "img/sqrs/blSqr.png"
};
};

function sqrA12() {
    if(document.getElementById("imgSqrs12").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs12").src = "img/sqrs/blSqr.png"
};
};

function sqrA13() {
    if(document.getElementById("imgSqrs13").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs13").src = "img/sqrs/blSqr.png"
};
};

function sqrA14() {
    if(document.getElementById("imgSqrs14").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs14").src = "img/sqrs/blSqr.png"
};
};

function sqrA15() {
    if(document.getElementById("imgSqrs15").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs15").src = "img/sqrs/blSqr.png"
};
};

function sqrA16() {
    if(document.getElementById("imgSqrs16").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs16").src = "img/sqrs/blSqr.png"
};
};

function sqrA17() {
    if(document.getElementById("imgSqrs17").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs17").src = "img/sqrs/blSqr.png"
};
};

function sqrA18() {
    if(document.getElementById("imgSqrs18").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs18").src = "img/sqrs/blSqr.png"
};
};

function sqrA19() {
    if(document.getElementById("imgSqrs19").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs19").src = "img/sqrs/blSqr.png"
};
};

function sqrA20() {
    if(document.getElementById("imgSqrs20").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs20").src = "img/sqrs/blSqr.png"
};
};

function sqrA21() {
    if(document.getElementById("imgSqrs21").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs21").src = "img/sqrs/blSqr.png"
};
};

function sqrA22() {
    if(document.getElementById("imgSqrs22").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs22").src = "img/sqrs/blSqr.png"
};
};

function sqrA23() {
    if(document.getElementById("imgSqrs23").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs23").src = "img/sqrs/blSqr.png"
};
};

function sqrA24() {
    if(document.getElementById("imgSqrs24").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs24").src = "img/sqrs/blSqr.png"
};
};

function sqrA25() {
    if(document.getElementById("imgSqrs25").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs25").src = "img/sqrs/blSqr.png"
};
};

function sqrB1() {
    if(document.getElementById("imgSqrs26").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs26").src = "img/sqrs/blSqr.png"
};
};

function sqrB2() {
    if(document.getElementById("imgSqrs27").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs27").src = "img/sqrs/blSqr.png"
};
};

function sqrB3() {
    if(document.getElementById("imgSqrs28").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs28").src = "img/sqrs/blSqr.png"
};
};

function sqrB4() {
    if(document.getElementById("imgSqrs29").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs29").src = "img/sqrs/blSqr.png"
};
};

function sqrB5() {
    if(document.getElementById("imgSqrs30").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs30").src = "img/sqrs/blSqr.png"
};
};

function sqrB6() {
    if(document.getElementById("imgSqrs31").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs31").src = "img/sqrs/blSqr.png"
};
};

function sqrB7() {
    if(document.getElementById("imgSqrs32").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs32").src = "img/sqrs/blSqr.png"
};
};

function sqrB8() {
    if(document.getElementById("imgSqrs33").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs33").src = "img/sqrs/blSqr.png"
};
};

function sqrB9() {
    if(document.getElementById("imgSqrs34").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs34").src = "img/sqrs/blSqr.png"
};
};

function sqrB10() {
    if(document.getElementById("imgSqrs35").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs35").src = "img/sqrs/blSqr.png"
};
};

function sqrB11() {
    if(document.getElementById("imgSqrs36").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs36").src = "img/sqrs/blSqr.png"
};
};

function sqrB12() {
    if(document.getElementById("imgSqrs37").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs37").src = "img/sqrs/blSqr.png"
};
};

function sqrB13() {
    if(document.getElementById("imgSqrs38").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs38").src = "img/sqrs/blSqr.png"
};
};

function sqrB14() {
    if(document.getElementById("imgSqrs39").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs39").src = "img/sqrs/blSqr.png"
};
};

function sqrB15() {
    if(document.getElementById("imgSqrs40").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs40").src = "img/sqrs/blSqr.png"
};
};

function sqrB16() {
    if(document.getElementById("imgSqrs41").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs41").src = "img/sqrs/blSqr.png"
};
};

function sqrB17() {
    if(document.getElementById("imgSqrs42").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs42").src = "img/sqrs/blSqr.png"
};
};

function sqrB18() {
    if(document.getElementById("imgSqrs43").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs43").src = "img/sqrs/blSqr.png"
};
};

function sqrB19() {
    if(document.getElementById("imgSqrs44").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs44").src = "img/sqrs/blSqr.png"
};
};

function sqrB20() {
    if(document.getElementById("imgSqrs45").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs45").src = "img/sqrs/blSqr.png"
};
};

function sqrB21() {
    if(document.getElementById("imgSqrs46").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs46").src = "img/sqrs/blSqr.png"
};
};

function sqrB22() {
    if(document.getElementById("imgSqrs47").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs47").src = "img/sqrs/blSqr.png"
};
};

function sqrB23() {
    if(document.getElementById("imgSqrs48").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs48").src = "img/sqrs/blSqr.png"
};
};

function sqrB24() {
    if(document.getElementById("imgSqrs49").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs49").src = "img/sqrs/blSqr.png"
};
};

function sqrB25() {
    if(document.getElementById("imgSqrs50").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs50").src = "img/sqrs/blSqr.png"
};
};

function sqrC1() {
    if(document.getElementById("imgSqrs51").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs51").src = "img/sqrs/blSqr.png"
};
};

function sqrC2() {
    if(document.getElementById("imgSqrs52").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs52").src = "img/sqrs/blSqr.png"
};
};

function sqrC3() {
    if(document.getElementById("imgSqrs53").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs53").src = "img/sqrs/blSqr.png"
};
};

function sqrC4() {
    if(document.getElementById("imgSqrs54").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs54").src = "img/sqrs/blSqr.png"
};
};

function sqrC5() {
    if(document.getElementById("imgSqrs55").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs55").src = "img/sqrs/blSqr.png"
};
};

function sqrC6() {
    if(document.getElementById("imgSqrs56").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs56").src = "img/sqrs/blSqr.png"
};
};

function sqrC7() {
    if(document.getElementById("imgSqrs57").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs57").src = "img/sqrs/blSqr.png"
};
};

function sqrC8() {
    if(document.getElementById("imgSqrs58").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs58").src = "img/sqrs/blSqr.png"
};
};

function sqrC9() {
    if(document.getElementById("imgSqrs59").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs59").src = "img/sqrs/blSqr.png"
};
};

function sqrC10() {
    if(document.getElementById("imgSqrs60").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs60").src = "img/sqrs/blSqr.png"
};
};

function sqrC11() {
    if(document.getElementById("imgSqrs61").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs61").src = "img/sqrs/blSqr.png"
};
};

function sqrC12() {
    if(document.getElementById("imgSqrs62").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs62").src = "img/sqrs/blSqr.png"
};
};

function sqrC13() {
    if(document.getElementById("imgSqrs63").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs63").src = "img/sqrs/blSqr.png"
};
};

function sqrC14() {
    if(document.getElementById("imgSqrs64").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs64").src = "img/sqrs/blSqr.png"
};
};

function sqrC15() {
    if(document.getElementById("imgSqrs65").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs65").src = "img/sqrs/blSqr.png"
};
};

function sqrC16() {
    if(document.getElementById("imgSqrs66").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs66").src = "img/sqrs/blSqr.png"
};
};

function sqrC17() {
    if(document.getElementById("imgSqrs67").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs67").src = "img/sqrs/blSqr.png"
};
};

function sqrC18() {
    if(document.getElementById("imgSqrs68").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs68").src = "img/sqrs/blSqr.png"
};
};

function sqrC19() {
    if(document.getElementById("imgSqrs69").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs69").src = "img/sqrs/blSqr.png"
};
};

function sqrC20() {
    if(document.getElementById("imgSqrs70").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs70").src = "img/sqrs/blSqr.png"
};
};

function sqrC21() {
    if(document.getElementById("imgSqrs71").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs71").src = "img/sqrs/blSqr.png"
};
};

function sqrC22() {
    if(document.getElementById("imgSqrs72").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs72").src = "img/sqrs/blSqr.png"
};
};

function sqrC23() {
    if(document.getElementById("imgSqrs73").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs73").src = "img/sqrs/blSqr.png"
};
};

function sqrC24() {
    if(document.getElementById("imgSqrs74").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs74").src = "img/sqrs/blSqr.png"
};
};

function sqrC25() {
    if(document.getElementById("imgSqrs75").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs75").src = "img/sqrs/blSqr.png"
 };
};

function sqrD1() {
    if(document.getElementById("imgSqrs76").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs76").src = "img/sqrs/blSqr.png"
};
};

function sqrD2() {
    if(document.getElementById("imgSqrs77").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs77").src = "img/sqrs/blSqr.png"
};
};

function sqrD3() {
    if(document.getElementById("imgSqrs78").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs78").src = "img/sqrs/blSqr.png"
};
};

function sqrD4() {
    if(document.getElementById("imgSqrs79").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs79").src = "img/sqrs/blSqr.png"
};
};

function sqrD5() {
    if(document.getElementById("imgSqrs80").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs80").src = "img/sqrs/blSqr.png"
};
};

function sqrD6() {
    if(document.getElementById("imgSqrs81").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs81").src = "img/sqrs/blSqr.png"
};
};

function sqrD7() {
    if(document.getElementById("imgSqrs82").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs82").src = "img/sqrs/blSqr.png"
};
};

function sqrD8() {
    if(document.getElementById("imgSqrs83").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs83").src = "img/sqrs/blSqr.png"
};
};

function sqrD9() {
    if(document.getElementById("imgSqrs84").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs84").src = "img/sqrs/blSqr.png"
};
};

function sqrD10() {
    if(document.getElementById("imgSqrs85").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs85").src = "img/sqrs/blSqr.png"
};
};

function sqrD11() {
    if(document.getElementById("imgSqrs86").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs86").src = "img/sqrs/blSqr.png"
};
};

function sqrD12() {
    if(document.getElementById("imgSqrs87").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs87").src = "img/sqrs/blSqr.png"
};
};

function sqrD13() {
    if(document.getElementById("imgSqrs88").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs88").src = "img/sqrs/blSqr.png"
};
};

function sqrD14() {
    if(document.getElementById("imgSqrs89").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs89").src = "img/sqrs/blSqr.png"
};
};

function sqrD15() {
    if(document.getElementById("imgSqrs90").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs90").src = "img/sqrs/blSqr.png"
};
};

function sqrD16() {
    if(document.getElementById("imgSqrs91").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs91").src = "img/sqrs/blSqr.png"
};
};

function sqrD17() {
    if(document.getElementById("imgSqrs92").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs92").src = "img/sqrs/blSqr.png"
};
};

function sqrD18() {
    if(document.getElementById("imgSqrs93").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs93").src = "img/sqrs/blSqr.png"
};
};

function sqrD19() {
    if(document.getElementById("imgSqrs94").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs94").src = "img/sqrs/blSqr.png"
};
};

function sqrD20() {
    if(document.getElementById("imgSqrs95").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs95").src = "img/sqrs/blSqr.png"
};
};

function sqrD21() {
    if(document.getElementById("imgSqrs96").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs96").src = "img/sqrs/blSqr.png"
};
};

function sqrD22() {
    if(document.getElementById("imgSqrs97").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs97").src = "img/sqrs/blSqr.png"
};
};

function sqrD23() {
    if(document.getElementById("imgSqrs98").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs98").src = "img/sqrs/blSqr.png"
};
};

function sqrD24() {
    if(document.getElementById("imgSqrs99").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs99").src = "img/sqrs/blSqr.png"
};
};

function sqrD25() {
    if(document.getElementById("imgSqrs100").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs100").src = "img/sqrs/blSqr.png"
 };
};

function sqrE1() {
    if(document.getElementById("imgSqrs101").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs101").src = "img/sqrs/blSqr.png"
};
};

function sqrE2() {
    if(document.getElementById("imgSqrs102").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs102").src = "img/sqrs/blSqr.png"
};
};

function sqrE3() {
    if(document.getElementById("imgSqrs103").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs103").src = "img/sqrs/blSqr.png"
};
};

function sqrE4() {
    if(document.getElementById("imgSqrs104").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs104").src = "img/sqrs/blSqr.png"
};
};

function sqrE5() {
    if(document.getElementById("imgSqrs105").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs105").src = "img/sqrs/blSqr.png"
};
};

function sqrE6() {
    if(document.getElementById("imgSqrs106").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs106").src = "img/sqrs/blSqr.png"
};
};

function sqrE7() {
    if(document.getElementById("imgSqrs107").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs107").src = "img/sqrs/blSqr.png"
};
};

function sqrE8() {
    if(document.getElementById("imgSqrs108").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs108").src = "img/sqrs/blSqr.png"
};
};

function sqrE9() {
    if(document.getElementById("imgSqrs109").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs109").src = "img/sqrs/blSqr.png"
};
};

function sqrE10() {
    if(document.getElementById("imgSqrs100").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs110").src = "img/sqrs/blSqr.png"
};
};

function sqrE11() {
    if(document.getElementById("imgSqrs111").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs111").src = "img/sqrs/blSqr.png"
};
};

function sqrE12() {
    if(document.getElementById("imgSqrs112").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs112").src = "img/sqrs/blSqr.png"
};
};

function sqrE13() {
    if(document.getElementById("imgSqrs113").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs113").src = "img/sqrs/blSqr.png"
};
};

function sqrE14() {
    if(document.getElementById("imgSqrs114").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs114").src = "img/sqrs/blSqr.png"
};
};

function sqrE15() {
    if(document.getElementById("imgSqrs115").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs115").src = "img/sqrs/blSqr.png"
};
};

function sqrE16() {
    if(document.getElementById("imgSqrs116").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs116").src = "img/sqrs/blSqr.png"
};
};

function sqrE17() {
    if(document.getElementById("imgSqrs117").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs117").src = "img/sqrs/blSqr.png"
};
};

function sqrE18() {
    if(document.getElementById("imgSqrs118").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs118").src = "img/sqrs/blSqr.png"
};
};

function sqrE19() {
    if(document.getElementById("imgSqrs119").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs119").src = "img/sqrs/blSqr.png"
};
};

function sqrE20() {
    if(document.getElementById("imgSqrs120").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs120").src = "img/sqrs/blSqr.png"
};
};

function sqrE21() {
    if(document.getElementById("imgSqrs121").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs121").src = "img/sqrs/blSqr.png"
};
};

function sqrE22() {
    if(document.getElementById("imgSqrs122").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs122").src = "img/sqrs/blSqr.png"
};
};

function sqrE23() {
    if(document.getElementById("imgSqrs123").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs123").src = "img/sqrs/blSqr.png"
};
};

function sqrE24() {
    if(document.getElementById("imgSqrs124").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs124").src = "img/sqrs/blSqr.png"
};
};

function sqrE25() {
    if(document.getElementById("imgSqrs125").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs125").src = "img/sqrs/blSqr.png"
 };
};

function sqrF1() {
    if(document.getElementById("imgSqrs126").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs126").src = "img/sqrs/blSqr.png"
};
};

function sqrF2() {
    if(document.getElementById("imgSqrs127").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs127").src = "img/sqrs/blSqr.png"
};
};

function sqrF3() {
    if(document.getElementById("imgSqrs128").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs128").src = "img/sqrs/blSqr.png"
};
};

function sqrF4() {
    if(document.getElementById("imgSqrs129").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs129").src = "img/sqrs/blSqr.png"
};
};

function sqrF5() {
    if(document.getElementById("imgSqrs130").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs130").src = "img/sqrs/blSqr.png"
};
};

function sqrF6() {
    if(document.getElementById("imgSqrs131").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs131").src = "img/sqrs/blSqr.png"
};
};

function sqrF7() {
    if(document.getElementById("imgSqrs132").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs132").src = "img/sqrs/blSqr.png"
};
};

function sqrF8() {
    if(document.getElementById("imgSqrs133").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs133").src = "img/sqrs/blSqr.png"
};
};

function sqrF9() {
    if(document.getElementById("imgSqrs134").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs134").src = "img/sqrs/blSqr.png"
};
};

function sqrF10() {
    if(document.getElementById("imgSqrs135").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs135").src = "img/sqrs/blSqr.png"
};
};

function sqrF11() {
    if(document.getElementById("imgSqrs136").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs136").src = "img/sqrs/blSqr.png"
};
};

function sqrF12() {
    if(document.getElementById("imgSqrs137").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs137").src = "img/sqrs/blSqr.png"
};
};

function sqrF13() {
    if(document.getElementById("imgSqrs138").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs138").src = "img/sqrs/blSqr.png"
};
};

function sqrF14() {
    if(document.getElementById("imgSqrs139").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs139").src = "img/sqrs/blSqr.png"
};
};

function sqrF15() {
    if(document.getElementById("imgSqrs140").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs140").src = "img/sqrs/blSqr.png"
};
};

function sqrF16() {
    if(document.getElementById("imgSqrs141").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs141").src = "img/sqrs/blSqr.png"
};
};

function sqrF17() {
    if(document.getElementById("imgSqrs142").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs142").src = "img/sqrs/blSqr.png"
};
};

function sqrF18() {
    if(document.getElementById("imgSqrs143").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs143").src = "img/sqrs/blSqr.png"
};
};

function sqrF19() {
    if(document.getElementById("imgSqrs144").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs144").src = "img/sqrs/blSqr.png"
};
};

function sqrF20() {
    if(document.getElementById("imgSqrs145").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs145").src = "img/sqrs/blSqr.png"
};
};

function sqrF21() {
    if(document.getElementById("imgSqrs146").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs146").src = "img/sqrs/blSqr.png"
};
};

function sqrF22() {
    if(document.getElementById("imgSqrs147").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs147").src = "img/sqrs/blSqr.png"
};
};

function sqrF23() {
    if(document.getElementById("imgSqrs148").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs148").src = "img/sqrs/blSqr.png"
};
};

function sqrF24() {
    if(document.getElementById("imgSqrs149").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs149").src = "img/sqrs/blSqr.png"
};
};

function sqrF25() {
    if(document.getElementById("imgSqrs150").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs150").src = "img/sqrs/blSqr.png"
 };
};

function sqrG1() {
    if(document.getElementById("imgSqrs151").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs151").src = "img/sqrs/blSqr.png"
};
};

function sqrG2() {
    if(document.getElementById("imgSqrs152").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs152").src = "img/sqrs/blSqr.png"
};
};

function sqrG3() {
    if(document.getElementById("imgSqrs153").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs153").src = "img/sqrs/blSqr.png"
};
};

function sqrG4() {
    if(document.getElementById("imgSqrs154").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs154").src = "img/sqrs/blSqr.png"
};
};

function sqrG5() {
    if(document.getElementById("imgSqrs155").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs155").src = "img/sqrs/blSqr.png"
};
};

function sqrG6() {
    if(document.getElementById("imgSqrs156").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs156").src = "img/sqrs/blSqr.png"
};
};

function sqrG7() {
    if(document.getElementById("imgSqrs157").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs157").src = "img/sqrs/blSqr.png"
};
};

function sqrG8() {
    if(document.getElementById("imgSqrs158").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs158").src = "img/sqrs/blSqr.png"
};
};

function sqrG9() {
    if(document.getElementById("imgSqrs159").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs159").src = "img/sqrs/blSqr.png"
};
};

function sqrG10() {
    if(document.getElementById("imgSqrs160").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs160").src = "img/sqrs/blSqr.png"
};
};

function sqrG11() {
    if(document.getElementById("imgSqrs161").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs161").src = "img/sqrs/blSqr.png"
};
};

function sqrG12() {
    if(document.getElementById("imgSqrs162").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs162").src = "img/sqrs/blSqr.png"
};
};

function sqrG13() {
    if(document.getElementById("imgSqrs163").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs163").src = "img/sqrs/blSqr.png"
};
};

function sqrG14() {
    if(document.getElementById("imgSqrs164").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs164").src = "img/sqrs/blSqr.png"
};
};

function sqrG15() {
    if(document.getElementById("imgSqrs165").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs165").src = "img/sqrs/blSqr.png"
};
};

function sqrG16() {
    if(document.getElementById("imgSqrs166").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs166").src = "img/sqrs/blSqr.png"
};
};

function sqrG17() {
    if(document.getElementById("imgSqrs167").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs167").src = "img/sqrs/blSqr.png"
};
};

function sqrG18() {
    if(document.getElementById("imgSqrs168").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs168").src = "img/sqrs/blSqr.png"
};
};

function sqrG19() {
    if(document.getElementById("imgSqrs169").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs169").src = "img/sqrs/blSqr.png"
};
};

function sqrG20() {
    if(document.getElementById("imgSqrs170").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs170").src = "img/sqrs/blSqr.png"
};
};

function sqrG21() {
    if(document.getElementById("imgSqrs171").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs171").src = "img/sqrs/blSqr.png"
};
};

function sqrG22() {
    if(document.getElementById("imgSqrs172").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs172").src = "img/sqrs/blSqr.png"
};
};

function sqrG23() {
    if(document.getElementById("imgSqrs173").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs173").src = "img/sqrs/blSqr.png"
};
};

function sqrG24() {
    if(document.getElementById("imgSqrs174").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs174").src = "img/sqrs/blSqr.png"
};
};

function sqrG25() {
    if(document.getElementById("imgSqrs175").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs175").src = "img/sqrs/blSqr.png"
 };
};

function sqrH1() {
    if(document.getElementById("imgSqrs176").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs176").src = "img/sqrs/blSqr.png"
};
};

function sqrH2() {
    if(document.getElementById("imgSqrs177").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs177").src = "img/sqrs/blSqr.png"
};
};

function sqrH3() {
    if(document.getElementById("imgSqrs178").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs178").src = "img/sqrs/blSqr.png"
};
};

function sqrH4() {
    if(document.getElementById("imgSqrs179").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs179").src = "img/sqrs/blSqr.png"
};
};

function sqrH5() {
    if(document.getElementById("imgSqrs180").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs180").src = "img/sqrs/blSqr.png"
};
};

function sqrH6() {
    if(document.getElementById("imgSqrs181").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs181").src = "img/sqrs/blSqr.png"
};
};

function sqrH7() {
    if(document.getElementById("imgSqrs182").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs182").src = "img/sqrs/blSqr.png"
};
};

function sqrH8() {
    if(document.getElementById("imgSqrs183").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs183").src = "img/sqrs/blSqr.png"
};
};

function sqrH9() {
    if(document.getElementById("imgSqrs184").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs184").src = "img/sqrs/blSqr.png"
};
};

function sqrH10() {
    if(document.getElementById("imgSqrs185").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs185").src = "img/sqrs/blSqr.png"
};
};

function sqrH11() {
    if(document.getElementById("imgSqrs186").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs186").src = "img/sqrs/blSqr.png"
};
};

function sqrH12() {
    if(document.getElementById("imgSqrs187").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs187").src = "img/sqrs/blSqr.png"
};
};

function sqrH13() {
    if(document.getElementById("imgSqrs188").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs188").src = "img/sqrs/blSqr.png"
};
};

function sqrH14() {
    if(document.getElementById("imgSqrs189").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs189").src = "img/sqrs/blSqr.png"
};
};

function sqrH15() {
    if(document.getElementById("imgSqrs190").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs190").src = "img/sqrs/blSqr.png"
};
};

function sqrH16() {
    if(document.getElementById("imgSqrs191").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs191").src = "img/sqrs/blSqr.png"
};
};

function sqrH17() {
    if(document.getElementById("imgSqrs192").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs192").src = "img/sqrs/blSqr.png"
};
};

function sqrH18() {
    if(document.getElementById("imgSqrs193").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs193").src = "img/sqrs/blSqr.png"
};
};

function sqrH19() {
    if(document.getElementById("imgSqrs194").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs194").src = "img/sqrs/blSqr.png"
};
};

function sqrH20() {
    if(document.getElementById("imgSqrs195").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs195").src = "img/sqrs/blSqr.png"
};
};

function sqrH21() {
    if(document.getElementById("imgSqrs196").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs196").src = "img/sqrs/blSqr.png"
};
};

function sqrH22() {
    if(document.getElementById("imgSqrs197").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs197").src = "img/sqrs/blSqr.png"
};
};

function sqrH23() {
    if(document.getElementById("imgSqrs198").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs198").src = "img/sqrs/blSqr.png"
};
};

function sqrH24() {
    if(document.getElementById("imgSqrs199").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs199").src = "img/sqrs/blSqr.png"
};
};

function sqrH25() {
    if(document.getElementById("imgSqrs200").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs200").src = "img/sqrs/blSqr.png"
 };
};

function sqrI1() {
    if(document.getElementById("imgSqrs201").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs201").src = "img/sqrs/blSqr.png"
};
};

function sqrI2() {
    if(document.getElementById("imgSqrs202").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs202").src = "img/sqrs/blSqr.png"
};
};

function sqrI3() {
    if(document.getElementById("imgSqrs203").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs203").src = "img/sqrs/blSqr.png"
};
};

function sqrI4() {
    if(document.getElementById("imgSqrs204").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs204").src = "img/sqrs/blSqr.png"
};
};

function sqrI5() {
    if(document.getElementById("imgSqrs205").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs205").src = "img/sqrs/blSqr.png"
};
};

function sqrI6() {
    if(document.getElementById("imgSqrs206").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs206").src = "img/sqrs/blSqr.png"
};
};

function sqrI7() {
    if(document.getElementById("imgSqrs207").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs207").src = "img/sqrs/blSqr.png"
};
};

function sqrI8() {
    if(document.getElementById("imgSqrs208").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs208").src = "img/sqrs/blSqr.png"
};
};

function sqrI9() {
    if(document.getElementById("imgSqrs209").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs209").src = "img/sqrs/blSqr.png"
};
};

function sqrI10() {
    if(document.getElementById("imgSqrs210").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs210").src = "img/sqrs/blSqr.png"
};
};

function sqrI11() {
    if(document.getElementById("imgSqrs211").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs211").src = "img/sqrs/blSqr.png"
};
};

function sqrI12() {
    if(document.getElementById("imgSqrs212").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs212").src = "img/sqrs/blSqr.png"
};
};

function sqrI13() {
    if(document.getElementById("imgSqrs213").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs213").src = "img/sqrs/blSqr.png"
};
};

function sqrI14() {
    if(document.getElementById("imgSqrs214").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs214").src = "img/sqrs/blSqr.png"
};
};

function sqrI15() {
    if(document.getElementById("imgSqrs215").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs215").src = "img/sqrs/blSqr.png"
};
};

function sqrI16() {
    if(document.getElementById("imgSqrs216").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs216").src = "img/sqrs/blSqr.png"
};
};

function sqrI17() {
    if(document.getElementById("imgSqrs217").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs217").src = "img/sqrs/blSqr.png"
};
};

function sqrI18() {
    if(document.getElementById("imgSqrs218").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs218").src = "img/sqrs/blSqr.png"
};
};

function sqrI19() {
    if(document.getElementById("imgSqrs219").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs219").src = "img/sqrs/blSqr.png"
};
};

function sqrI20() {
    if(document.getElementById("imgSqrs220").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs220").src = "img/sqrs/blSqr.png"
};
};

function sqrI21() {
    if(document.getElementById("imgSqrs221").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs221").src = "img/sqrs/blSqr.png"
};
};

function sqrI22() {
    if(document.getElementById("imgSqrs222").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs222").src = "img/sqrs/blSqr.png"
};
};

function sqrI23() {
    if(document.getElementById("imgSqrs223").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs223").src = "img/sqrs/blSqr.png"
};
};

function sqrI24() {
    if(document.getElementById("imgSqrs224").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs224").src = "img/sqrs/blSqr.png"
};
};

function sqrI25() {
    if(document.getElementById("imgSqrs225").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs225").src = "img/sqrs/blSqr.png"
 };
};

function sqrJ1() {
    if(document.getElementById("imgSqrs226").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs226").src = "img/sqrs/blSqr.png"
};
};

function sqrJ2() {
    if(document.getElementById("imgSqrs227").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs227").src = "img/sqrs/blSqr.png"
};
};

function sqrJ3() {
    if(document.getElementById("imgSqrs228").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs228").src = "img/sqrs/blSqr.png"
};
};

function sqrJ4() {
    if(document.getElementById("imgSqrs229").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs229").src = "img/sqrs/blSqr.png"
};
};

function sqrJ5() {
    if(document.getElementById("imgSqrs230").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs230").src = "img/sqrs/blSqr.png"
};
};

function sqrJ6() {
    if(document.getElementById("imgSqrs231").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs231").src = "img/sqrs/blSqr.png"
};
};

function sqrJ7() {
    if(document.getElementById("imgSqrs232").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs232").src = "img/sqrs/blSqr.png"
};
};

function sqrJ8() {
    if(document.getElementById("imgSqrs233").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs233").src = "img/sqrs/blSqr.png"
};
};

function sqrJ9() {
    if(document.getElementById("imgSqrs234").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs234").src = "img/sqrs/blSqr.png"
};
};

function sqrJ10() {
    if(document.getElementById("imgSqrs235").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs235").src = "img/sqrs/blSqr.png"
};
};

function sqrJ11() {
    if(document.getElementById("imgSqrs236").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs236").src = "img/sqrs/blSqr.png"
};
};

function sqrJ12() {
    if(document.getElementById("imgSqrs237").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs237").src = "img/sqrs/blSqr.png"
};
};

function sqrJ13() {
    if(document.getElementById("imgSqrs238").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs238").src = "img/sqrs/blSqr.png"
};
};

function sqrJ14() {
    if(document.getElementById("imgSqrs239").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs239").src = "img/sqrs/blSqr.png"
};
};

function sqrJ15() {
    if(document.getElementById("imgSqrs240").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs240").src = "img/sqrs/blSqr.png"
};
};

function sqrJ16() {
    if(document.getElementById("imgSqrs241").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs241").src = "img/sqrs/blSqr.png"
};
};

function sqrJ17() {
    if(document.getElementById("imgSqrs242").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs242").src = "img/sqrs/blSqr.png"
};
};

function sqrJ18() {
    if(document.getElementById("imgSqrs243").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs243").src = "img/sqrs/blSqr.png"
};
};

function sqrJ19() {
    if(document.getElementById("imgSqrs244").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs244").src = "img/sqrs/blSqr.png"
};
};

function sqrJ20() {
    if(document.getElementById("imgSqrs245").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs245").src = "img/sqrs/blSqr.png"
};
};

function sqrJ21() {
    if(document.getElementById("imgSqrs246").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs246").src = "img/sqrs/blSqr.png"
};
};

function sqrJ22() {
    if(document.getElementById("imgSqrs247").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs247").src = "img/sqrs/blSqr.png"
};
};

function sqrJ23() {
    if(document.getElementById("imgSqrs248").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs248").src = "img/sqrs/blSqr.png"
};
};

function sqrJ24() {
    if(document.getElementById("imgSqrs249").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs249").src = "img/sqrs/blSqr.png"
};
};

function sqrJ25() {
    if(document.getElementById("imgSqrs250").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs250").src = "img/sqrs/blSqr.png"
 };
};

function sqrK1() {
    if(document.getElementById("imgSqrs251").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs251").src = "img/sqrs/blSqr.png"
};
};

function sqrK2() {
    if(document.getElementById("imgSqrs252").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs252").src = "img/sqrs/blSqr.png"
};
};

function sqrK3() {
    if(document.getElementById("imgSqrs253").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs253").src = "img/sqrs/blSqr.png"
};
};

function sqrK4() {
    if(document.getElementById("imgSqrs254").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs254").src = "img/sqrs/blSqr.png"
};
};

function sqrK5() {
    if(document.getElementById("imgSqrs255").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs255").src = "img/sqrs/blSqr.png"
};
};

function sqrK6() {
    if(document.getElementById("imgSqrs256").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs256").src = "img/sqrs/blSqr.png"
};
};

function sqrK7() {
    if(document.getElementById("imgSqrs257").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs257").src = "img/sqrs/blSqr.png"
};
};

function sqrK8() {
    if(document.getElementById("imgSqrs258").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs258").src = "img/sqrs/blSqr.png"
};
};

function sqrK9() {
    if(document.getElementById("imgSqrs259").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs259").src = "img/sqrs/blSqr.png"
};
};

function sqrK10() {
    if(document.getElementById("imgSqrs260").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs260").src = "img/sqrs/blSqr.png"
};
};

function sqrK11() {
    if(document.getElementById("imgSqrs261").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs261").src = "img/sqrs/blSqr.png"
};
};

function sqrK12() {
    if(document.getElementById("imgSqrs262").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs262").src = "img/sqrs/blSqr.png"
};
};

function sqrK13() {
    if(document.getElementById("imgSqrs263").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs263").src = "img/sqrs/blSqr.png"
};
};

function sqrK14() {
    if(document.getElementById("imgSqrs264").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs264").src = "img/sqrs/blSqr.png"
};
};

function sqrK15() {
    if(document.getElementById("imgSqrs265").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs265").src = "img/sqrs/blSqr.png"
};
};

function sqrK16() {
    if(document.getElementById("imgSqrs266").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs266").src = "img/sqrs/blSqr.png"
};
};

function sqrK17() {
    if(document.getElementById("imgSqrs267").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs267").src = "img/sqrs/blSqr.png"
};
};

function sqrK18() {
    if(document.getElementById("imgSqrs268").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs268").src = "img/sqrs/blSqr.png"
};
};

function sqrK19() {
    if(document.getElementById("imgSqrs269").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs269").src = "img/sqrs/blSqr.png"
};
};

function sqrK20() {
    if(document.getElementById("imgSqrs270").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs270").src = "img/sqrs/blSqr.png"
};
};

function sqrK21() {
    if(document.getElementById("imgSqrs271").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs271").src = "img/sqrs/blSqr.png"
};
};

function sqrK22() {
    if(document.getElementById("imgSqrs272").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs272").src = "img/sqrs/blSqr.png"
};
};

function sqrK23() {
    if(document.getElementById("imgSqrs273").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs273").src = "img/sqrs/blSqr.png"
};
};

function sqrK24() {
    if(document.getElementById("imgSqrs274").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs274").src = "img/sqrs/blSqr.png"
};
};

function sqrK25() {
    if(document.getElementById("imgSqrs275").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs275").src = "img/sqrs/blSqr.png"
 };
};

function sqrL1() {
    if(document.getElementById("imgSqrs276").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs276").src = "img/sqrs/blSqr.png"
};
};

function sqrL2() {
    if(document.getElementById("imgSqrs277").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs277").src = "img/sqrs/blSqr.png"
};
};

function sqrL3() {
    if(document.getElementById("imgSqrs278").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs278").src = "img/sqrs/blSqr.png"
};
};

function sqrL4() {
    if(document.getElementById("imgSqrs279").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs279").src = "img/sqrs/blSqr.png"
};
};

function sqrL5() {
    if(document.getElementById("imgSqrs280").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs280").src = "img/sqrs/blSqr.png"
};
};

function sqrL6() {
    if(document.getElementById("imgSqrs281").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs281").src = "img/sqrs/blSqr.png"
};
};

function sqrL7() {
    if(document.getElementById("imgSqrs282").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs282").src = "img/sqrs/blSqr.png"
};
};

function sqrL8() {
    if(document.getElementById("imgSqrs283").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs283").src = "img/sqrs/blSqr.png"
};
};

function sqrL9() {
    if(document.getElementById("imgSqrs284").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs284").src = "img/sqrs/blSqr.png"
};
};

function sqrL10() {
    if(document.getElementById("imgSqrs285").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs285").src = "img/sqrs/blSqr.png"
};
};

function sqrL11() {
    if(document.getElementById("imgSqrs286").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs286").src = "img/sqrs/blSqr.png"
};
};

function sqrL12() {
    if(document.getElementById("imgSqrs287").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs287").src = "img/sqrs/blSqr.png"
};
};

function sqrL13() {
    if(document.getElementById("imgSqrs288").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs288").src = "img/sqrs/blSqr.png"
};
};

function sqrL14() {
    if(document.getElementById("imgSqrs289").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs289").src = "img/sqrs/blSqr.png"
};
};

function sqrL15() {
    if(document.getElementById("imgSqrs290").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs290").src = "img/sqrs/blSqr.png"
};
};

function sqrL16() {
    if(document.getElementById("imgSqrs291").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs291").src = "img/sqrs/blSqr.png"
};
};

function sqrL17() {
    if(document.getElementById("imgSqrs292").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs292").src = "img/sqrs/blSqr.png"
};
};

function sqrL18() {
    if(document.getElementById("imgSqrs293").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs293").src = "img/sqrs/blSqr.png"
};
};

function sqrL19() {
    if(document.getElementById("imgSqrs294").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs294").src = "img/sqrs/blSqr.png"
};
};

function sqrL20() {
    if(document.getElementById("imgSqrs295").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs295").src = "img/sqrs/blSqr.png"
};
};

function sqrL21() {
    if(document.getElementById("imgSqrs296").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs296").src = "img/sqrs/blSqr.png"
};
};

function sqrL22() {
    if(document.getElementById("imgSqrs297").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs297").src = "img/sqrs/blSqr.png"
};
};

function sqrL23() {
    if(document.getElementById("imgSqrs298").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs298").src = "img/sqrs/blSqr.png"
};
};

function sqrL24() {
    if(document.getElementById("imgSqrs299").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs299").src = "img/sqrs/blSqr.png"
};
};

function sqrL25() {
    if(document.getElementById("imgSqrs300").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs300").src = "img/sqrs/blSqr.png"
 };
};

function sqrM1() {
    if(document.getElementById("imgSqrs301").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs301").src = "img/sqrs/blSqr.png"
};
};

function sqrM2() {
    if(document.getElementById("imgSqrs302").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs302").src = "img/sqrs/blSqr.png"
};
};

function sqrM3() {
    if(document.getElementById("imgSqrs303").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs303").src = "img/sqrs/blSqr.png"
};
};

function sqrM4() {
    if(document.getElementById("imgSqrs304").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs304").src = "img/sqrs/blSqr.png"
};
};

function sqrM5() {
    if(document.getElementById("imgSqrs305").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs305").src = "img/sqrs/blSqr.png"
};
};

function sqrM6() {
    if(document.getElementById("imgSqrs306").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs306").src = "img/sqrs/blSqr.png"
};
};

function sqrM7() {
    if(document.getElementById("imgSqrs307").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs307").src = "img/sqrs/blSqr.png"
};
};

function sqrM8() {
    if(document.getElementById("imgSqrs308").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs308").src = "img/sqrs/blSqr.png"
};
};

function sqrM9() {
    if(document.getElementById("imgSqrs309").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs309").src = "img/sqrs/blSqr.png"
};
};

function sqrM10() {
    if(document.getElementById("imgSqrs310").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs310").src = "img/sqrs/blSqr.png"
};
};

function sqrM11() {
    if(document.getElementById("imgSqrs311").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs311").src = "img/sqrs/blSqr.png"
};
};

function sqrM12() {
    if(document.getElementById("imgSqrs312").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs312").src = "img/sqrs/blSqr.png"
};
};

function sqrM13() {
    if(document.getElementById("imgSqrs313").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs313").src = "img/sqrs/blSqr.png"
};
};

function sqrM14() {
    if(document.getElementById("imgSqrs314").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs314").src = "img/sqrs/blSqr.png"
};
};

function sqrM15() {
    if(document.getElementById("imgSqrs315").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs315").src = "img/sqrs/blSqr.png"
};
};

function sqrM16() {
    if(document.getElementById("imgSqrs316").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs316").src = "img/sqrs/blSqr.png"
};
};

function sqrM17() {
    if(document.getElementById("imgSqrs317").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs317").src = "img/sqrs/blSqr.png"
};
};

function sqrM18() {
    if(document.getElementById("imgSqrs318").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs318").src = "img/sqrs/blSqr.png"
};
};

function sqrM19() {
    if(document.getElementById("imgSqrs319").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs319").src = "img/sqrs/blSqr.png"
};
};

function sqrM20() {
    if(document.getElementById("imgSqrs320").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs320").src = "img/sqrs/blSqr.png"
};
};

function sqrM21() {
    if(document.getElementById("imgSqrs321").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs321").src = "img/sqrs/blSqr.png"
};
};

function sqrM22() {
    if(document.getElementById("imgSqrs322").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs322").src = "img/sqrs/blSqr.png"
};
};

function sqrM23() {
    if(document.getElementById("imgSqrs323").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs323").src = "img/sqrs/blSqr.png"
};
};

function sqrM24() {
    if(document.getElementById("imgSqrs324").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs324").src = "img/sqrs/blSqr.png"
};
};

function sqrM25() {
    if(document.getElementById("imgSqrs325").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs325").src = "img/sqrs/blSqr.png"
 };
};

function sqrN1() {
    if(document.getElementById("imgSqrs326").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs326").src = "img/sqrs/blSqr.png"
};
};

function sqrN2() {
    if(document.getElementById("imgSqrs327").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs327").src = "img/sqrs/blSqr.png"
};
};

function sqrN3() {
    if(document.getElementById("imgSqrs328").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs328").src = "img/sqrs/blSqr.png"
};
};

function sqrN4() {
    if(document.getElementById("imgSqrs329").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs329").src = "img/sqrs/blSqr.png"
};
};

function sqrN5() {
    if(document.getElementById("imgSqrs330").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs330").src = "img/sqrs/blSqr.png"
};
};

function sqrN6() {
    if(document.getElementById("imgSqrs331").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs331").src = "img/sqrs/blSqr.png"
};
};

function sqrN7() {
    if(document.getElementById("imgSqrs332").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs332").src = "img/sqrs/blSqr.png"
};
};

function sqrN8() {
    if(document.getElementById("imgSqrs333").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs333").src = "img/sqrs/blSqr.png"
};
};

function sqrN9() {
    if(document.getElementById("imgSqrs334").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs334").src = "img/sqrs/blSqr.png"
};
};

function sqrN10() {
    if(document.getElementById("imgSqrs335").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs335").src = "img/sqrs/blSqr.png"
};
};

function sqrN11() {
    if(document.getElementById("imgSqrs336").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs336").src = "img/sqrs/blSqr.png"
};
};

function sqrN12() {
    if(document.getElementById("imgSqrs337").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs337").src = "img/sqrs/blSqr.png"
};
};

function sqrN13() {
    if(document.getElementById("imgSqrs338").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs338").src = "img/sqrs/blSqr.png"
};
};

function sqrN14() {
    if(document.getElementById("imgSqrs339").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs339").src = "img/sqrs/blSqr.png"
};
};

function sqrN15() {
    if(document.getElementById("imgSqrs340").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs340").src = "img/sqrs/blSqr.png"
};
};

function sqrN16() {
    if(document.getElementById("imgSqrs341").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs341").src = "img/sqrs/blSqr.png"
};
};

function sqrN17() {
    if(document.getElementById("imgSqrs342").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs342").src = "img/sqrs/blSqr.png"
};
};

function sqrN18() {
    if(document.getElementById("imgSqrs343").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs343").src = "img/sqrs/blSqr.png"
};
};

function sqrN19() {
    if(document.getElementById("imgSqrs344").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs344").src = "img/sqrs/blSqr.png"
};
};

function sqrN20() {
    if(document.getElementById("imgSqrs345").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs345").src = "img/sqrs/blSqr.png"
};
};

function sqrN21() {
    if(document.getElementById("imgSqrs346").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs346").src = "img/sqrs/blSqr.png"
};
};

function sqrN22() {
    if(document.getElementById("imgSqrs347").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs347").src = "img/sqrs/blSqr.png"
};
};

function sqrN23() {
    if(document.getElementById("imgSqrs348").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs348").src = "img/sqrs/blSqr.png"
};
};

function sqrN24() {
    if(document.getElementById("imgSqrs349").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs349").src = "img/sqrs/blSqr.png"
};
};

function sqrN25() {
    if(document.getElementById("imgSqrs350").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs350").src = "img/sqrs/blSqr.png"
 };
};

function sqrO1() {
    if(document.getElementById("imgSqrs351").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs351").src = "img/sqrs/blSqr.png"
};
};

function sqrO2() {
    if(document.getElementById("imgSqrs352").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs352").src = "img/sqrs/blSqr.png"
};
};

function sqrO3() {
    if(document.getElementById("imgSqrs353").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs353").src = "img/sqrs/blSqr.png"
};
};

function sqrO4() {
    if(document.getElementById("imgSqrs354").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs354").src = "img/sqrs/blSqr.png"
};
};

function sqrO5() {
    if(document.getElementById("imgSqrs355").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs355").src = "img/sqrs/blSqr.png"
};
};

function sqrO6() {
    if(document.getElementById("imgSqrs356").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs356").src = "img/sqrs/blSqr.png"
};
};

function sqrO7() {
    if(document.getElementById("imgSqrs357").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs357").src = "img/sqrs/blSqr.png"
};
};

function sqrO8() {
    if(document.getElementById("imgSqrs358").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs358").src = "img/sqrs/blSqr.png"
};
};

function sqrO9() {
    if(document.getElementById("imgSqrs359").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs359").src = "img/sqrs/blSqr.png"
};
};

function sqrO10() {
    if(document.getElementById("imgSqrs360").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs360").src = "img/sqrs/blSqr.png"
};
};

function sqrO11() {
    if(document.getElementById("imgSqrs361").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs361").src = "img/sqrs/blSqr.png"
};
};

function sqrO12() {
    if(document.getElementById("imgSqrs362").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs362").src = "img/sqrs/blSqr.png"
};
};

function sqrO13() {
    if(document.getElementById("imgSqrs363").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs363").src = "img/sqrs/blSqr.png"
};
};

function sqrO14() {
    if(document.getElementById("imgSqrs364").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs364").src = "img/sqrs/blSqr.png"
};
};

function sqrO15() {
    if(document.getElementById("imgSqrs365").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs365").src = "img/sqrs/blSqr.png"
};
};

function sqrO16() {
    if(document.getElementById("imgSqrs366").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs366").src = "img/sqrs/blSqr.png"
};
};

function sqrO17() {
    if(document.getElementById("imgSqrs367").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs367").src = "img/sqrs/blSqr.png"
};
};

function sqrO18() {
    if(document.getElementById("imgSqrs368").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs368").src = "img/sqrs/blSqr.png"
};
};

function sqrO19() {
    if(document.getElementById("imgSqrs369").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs369").src = "img/sqrs/blSqr.png"
};
};

function sqrO20() {
    if(document.getElementById("imgSqrs370").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs370").src = "img/sqrs/blSqr.png"
};
};

function sqrO21() {
    if(document.getElementById("imgSqrs371").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs371").src = "img/sqrs/blSqr.png"
};
};

function sqrO22() {
    if(document.getElementById("imgSqrs372").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs372").src = "img/sqrs/blSqr.png"
};
};

function sqrO23() {
    if(document.getElementById("imgSqrs373").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs373").src = "img/sqrs/blSqr.png"
};
};

function sqrO24() {
    if(document.getElementById("imgSqrs374").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs374").src = "img/sqrs/blSqr.png"
};
};

function sqrO25() {
    if(document.getElementById("imgSqrs375").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs375").src = "img/sqrs/blSqr.png"
 };
};

function sqrP1() {
    if(document.getElementById("imgSqrs376").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs376").src = "img/sqrs/blSqr.png"
};
};

function sqrP2() {
    if(document.getElementById("imgSqrs377").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs377").src = "img/sqrs/blSqr.png"
};
};

function sqrP3() {
    if(document.getElementById("imgSqrs378").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs378").src = "img/sqrs/blSqr.png"
};
};

function sqrP4() {
    if(document.getElementById("imgSqrs379").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs379").src = "img/sqrs/blSqr.png"
};
};

function sqrP5() {
    if(document.getElementById("imgSqrs380").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs380").src = "img/sqrs/blSqr.png"
};
};

function sqrP6() {
    if(document.getElementById("imgSqrs381").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs381").src = "img/sqrs/blSqr.png"
};
};

function sqrP7() {
    if(document.getElementById("imgSqrs382").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs382").src = "img/sqrs/blSqr.png"
};
};

function sqrP8() {
    if(document.getElementById("imgSqrs383").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs383").src = "img/sqrs/blSqr.png"
};
};

function sqrP9() {
    if(document.getElementById("imgSqrs384").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs384").src = "img/sqrs/blSqr.png"
};
};

function sqrP10() {
    if(document.getElementById("imgSqrs385").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs385").src = "img/sqrs/blSqr.png"
};
};

function sqrP11() {
    if(document.getElementById("imgSqrs386").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs386").src = "img/sqrs/blSqr.png"
};
};

function sqrP12() {
    if(document.getElementById("imgSqrs387").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs387").src = "img/sqrs/blSqr.png"
};
};

function sqrP13() {
    if(document.getElementById("imgSqrs388").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs388").src = "img/sqrs/blSqr.png"
};
};

function sqrP14() {
    if(document.getElementById("imgSqrs389").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs389").src = "img/sqrs/blSqr.png"
};
};

function sqrP15() {
    if(document.getElementById("imgSqrs390").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs390").src = "img/sqrs/blSqr.png"
};
};

function sqrP16() {
    if(document.getElementById("imgSqrs391").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs391").src = "img/sqrs/blSqr.png"
};
};

function sqrP17() {
    if(document.getElementById("imgSqrs392").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs392").src = "img/sqrs/blSqr.png"
};
};

function sqrP18() {
    if(document.getElementById("imgSqrs393").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs393").src = "img/sqrs/blSqr.png"
};
};

function sqrP19() {
    if(document.getElementById("imgSqrs394").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs394").src = "img/sqrs/blSqr.png"
};
};

function sqrP20() {
    if(document.getElementById("imgSqrs395").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs395").src = "img/sqrs/blSqr.png"
};
};

function sqrP21() {
    if(document.getElementById("imgSqrs396").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs396").src = "img/sqrs/blSqr.png"
};
};

function sqrP22() {
    if(document.getElementById("imgSqrs397").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs397").src = "img/sqrs/blSqr.png"
};
};

function sqrP23() {
    if(document.getElementById("imgSqrs398").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs398").src = "img/sqrs/blSqr.png"
};
};

function sqrP24() {
    if(document.getElementById("imgSqrs399").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs399").src = "img/sqrs/blSqr.png"
};
};

function sqrP25() {
    if(document.getElementById("imgSqrs400").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs400").src = "img/sqrs/blSqr.png"
 };
};

function sqrQ1() {
    if(document.getElementById("imgSqrs401").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs401").src = "img/sqrs/blSqr.png"
};
};

function sqrQ2() {
    if(document.getElementById("imgSqrs402").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs402").src = "img/sqrs/blSqr.png"
};
};

function sqrQ3() {
    if(document.getElementById("imgSqrs403").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs403").src = "img/sqrs/blSqr.png"
};
};

function sqrQ4() {
    if(document.getElementById("imgSqrs404").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs404").src = "img/sqrs/blSqr.png"
};
};

function sqrQ5() {
    if(document.getElementById("imgSqrs405").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs405").src = "img/sqrs/blSqr.png"
};
};

function sqrQ6() {
    if(document.getElementById("imgSqrs406").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs406").src = "img/sqrs/blSqr.png"
};
};

function sqrQ7() {
    if(document.getElementById("imgSqrs407").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs407").src = "img/sqrs/blSqr.png"
};
};

function sqrQ8() {
    if(document.getElementById("imgSqrs408").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs408").src = "img/sqrs/blSqr.png"
};
};

function sqrQ9() {
    if(document.getElementById("imgSqrs409").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs409").src = "img/sqrs/blSqr.png"
};
};

function sqrQ10() {
    if(document.getElementById("imgSqrs410").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs410").src = "img/sqrs/blSqr.png"
};
};

function sqrQ11() {
    if(document.getElementById("imgSqrs411").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs411").src = "img/sqrs/blSqr.png"
};
};

function sqrQ12() {
    if(document.getElementById("imgSqrs412").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs412").src = "img/sqrs/blSqr.png"
};
};

function sqrQ13() {
    if(document.getElementById("imgSqrs413").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs413").src = "img/sqrs/blSqr.png"
};
};

function sqrQ14() {
    if(document.getElementById("imgSqrs414").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs414").src = "img/sqrs/blSqr.png"
};
};

function sqrQ15() {
    if(document.getElementById("imgSqrs415").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs415").src = "img/sqrs/blSqr.png"
};
};

function sqrQ16() {
    if(document.getElementById("imgSqrs416").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs416").src = "img/sqrs/blSqr.png"
};
};

function sqrQ17() {
    if(document.getElementById("imgSqrs417").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs417").src = "img/sqrs/blSqr.png"
};
};

function sqrQ18() {
    if(document.getElementById("imgSqrs418").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs418").src = "img/sqrs/blSqr.png"
};
};

function sqrQ19() {
    if(document.getElementById("imgSqrs419").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs419").src = "img/sqrs/blSqr.png"
};
};

function sqrQ20() {
    if(document.getElementById("imgSqrs420").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs420").src = "img/sqrs/blSqr.png"
};
};

function sqrQ21() {
    if(document.getElementById("imgSqrs421").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs421").src = "img/sqrs/blSqr.png"
};
};

function sqrQ22() {
    if(document.getElementById("imgSqrs422").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs422").src = "img/sqrs/blSqr.png"
};
};

function sqrQ23() {
    if(document.getElementById("imgSqrs423").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs423").src = "img/sqrs/blSqr.png"
};
};

function sqrQ24() {
    if(document.getElementById("imgSqrs424").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs424").src = "img/sqrs/blSqr.png"
};
};

function sqrQ25() {
    if(document.getElementById("imgSqrs425").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs425").src = "img/sqrs/blSqr.png"
 };
};

function sqrR1() {
    if(document.getElementById("imgSqrs426").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs426").src = "img/sqrs/blSqr.png"
};
};

function sqrR2() {
    if(document.getElementById("imgSqrs427").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs427").src = "img/sqrs/blSqr.png"
};
};

function sqrR3() {
    if(document.getElementById("imgSqrs428").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs428").src = "img/sqrs/blSqr.png"
};
};

function sqrR4() {
    if(document.getElementById("imgSqrs429").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs429").src = "img/sqrs/blSqr.png"
};
};

function sqrR5() {
    if(document.getElementById("imgSqrs430").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs430").src = "img/sqrs/blSqr.png"
};
};

function sqrR6() {
    if(document.getElementById("imgSqrs431").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs431").src = "img/sqrs/blSqr.png"
};
};

function sqrR7() {
    if(document.getElementById("imgSqrs432").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs432").src = "img/sqrs/blSqr.png"
};
};

function sqrR8() {
    if(document.getElementById("imgSqrs433").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs433").src = "img/sqrs/blSqr.png"
};
};

function sqrR9() {
    if(document.getElementById("imgSqrs434").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs434").src = "img/sqrs/blSqr.png"
};
};

function sqrR10() {
    if(document.getElementById("imgSqrs435").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs435").src = "img/sqrs/blSqr.png"
};
};

function sqrR11() {
    if(document.getElementById("imgSqrs436").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs436").src = "img/sqrs/blSqr.png"
};
};

function sqrR12() {
    if(document.getElementById("imgSqrs437").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs437").src = "img/sqrs/blSqr.png"
};
};

function sqrR13() {
    if(document.getElementById("imgSqrs438").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs438").src = "img/sqrs/blSqr.png"
};
};

function sqrR14() {
    if(document.getElementById("imgSqrs439").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs439").src = "img/sqrs/blSqr.png"
};
};

function sqrR15() {
    if(document.getElementById("imgSqrs440").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs440").src = "img/sqrs/blSqr.png"
};
};

function sqrR16() {
    if(document.getElementById("imgSqrs441").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs441").src = "img/sqrs/blSqr.png"
};
};

function sqrR17() {
    if(document.getElementById("imgSqrs442").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs442").src = "img/sqrs/blSqr.png"
};
};

function sqrR18() {
    if(document.getElementById("imgSqrs443").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs443").src = "img/sqrs/blSqr.png"
};
};

function sqrR19() {
    if(document.getElementById("imgSqrs444").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs444").src = "img/sqrs/blSqr.png"
};
};

function sqrR20() {
    if(document.getElementById("imgSqrs445").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs445").src = "img/sqrs/blSqr.png"
};
};

function sqrR21() {
    if(document.getElementById("imgSqrs446").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs446").src = "img/sqrs/blSqr.png"
};
};

function sqrR22() {
    if(document.getElementById("imgSqrs447").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs447").src = "img/sqrs/blSqr.png"
};
};

function sqrR23() {
    if(document.getElementById("imgSqrs448").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs448").src = "img/sqrs/blSqr.png"
};
};

function sqrR24() {
    if(document.getElementById("imgSqrs449").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs449").src = "img/sqrs/blSqr.png"
};
};

function sqrR25() {
    if(document.getElementById("imgSqrs450").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs450").src = "img/sqrs/blSqr.png"
 };
};

function sqrS1() {
    if(document.getElementById("imgSqrs451").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs451").src = "img/sqrs/blSqr.png"
};
};

function sqrS2() {
    if(document.getElementById("imgSqrs452").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs452").src = "img/sqrs/blSqr.png"
};
};

function sqrS3() {
    if(document.getElementById("imgSqrs453").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs453").src = "img/sqrs/blSqr.png"
};
};

function sqrS4() {
    if(document.getElementById("imgSqrs454").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs454").src = "img/sqrs/blSqr.png"
};
};

function sqrS5() {
    if(document.getElementById("imgSqrs455").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs455").src = "img/sqrs/blSqr.png"
};
};

function sqrS6() {
    if(document.getElementById("imgSqrs456").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs456").src = "img/sqrs/blSqr.png"
};
};

function sqrS7() {
    if(document.getElementById("imgSqrs457").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs457").src = "img/sqrs/blSqr.png"
};
};

function sqrS8() {
    if(document.getElementById("imgSqrs458").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs458").src = "img/sqrs/blSqr.png"
};
};

function sqrS9() {
    if(document.getElementById("imgSqrs459").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs459").src = "img/sqrs/blSqr.png"
};
};

function sqrS10() {
    if(document.getElementById("imgSqrs460").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs460").src = "img/sqrs/blSqr.png"
};
};

function sqrS11() {
    if(document.getElementById("imgSqrs461").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs461").src = "img/sqrs/blSqr.png"
};
};

function sqrS12() {
    if(document.getElementById("imgSqrs462").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs462").src = "img/sqrs/blSqr.png"
};
};

function sqrS13() {
    if(document.getElementById("imgSqrs463").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs463").src = "img/sqrs/blSqr.png"
};
};

function sqrS14() {
    if(document.getElementById("imgSqrs464").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs464").src = "img/sqrs/blSqr.png"
};
};

function sqrS15() {
    if(document.getElementById("imgSqrs465").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs465").src = "img/sqrs/blSqr.png"
};
};

function sqrS16() {
    if(document.getElementById("imgSqrs466").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs466").src = "img/sqrs/blSqr.png"
};
};

function sqrS17() {
    if(document.getElementById("imgSqrs467").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs467").src = "img/sqrs/blSqr.png"
};
};

function sqrS18() {
    if(document.getElementById("imgSqrs468").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs468").src = "img/sqrs/blSqr.png"
};
};

function sqrS19() {
    if(document.getElementById("imgSqrs469").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs469").src = "img/sqrs/blSqr.png"
};
};

function sqrS20() {
    if(document.getElementById("imgSqrs470").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs470").src = "img/sqrs/blSqr.png"
};
};

function sqrS21() {
    if(document.getElementById("imgSqrs471").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs471").src = "img/sqrs/blSqr.png"
};
};

function sqrS22() {
    if(document.getElementById("imgSqrs472").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs472").src = "img/sqrs/blSqr.png"
};
};

function sqrS23() {
    if(document.getElementById("imgSqrs473").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs473").src = "img/sqrs/blSqr.png"
};
};

function sqrS24() {
    if(document.getElementById("imgSqrs474").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs474").src = "img/sqrs/blSqr.png"
};
};

function sqrS25() {
    if(document.getElementById("imgSqrs475").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs475").src = "img/sqrs/blSqr.png"
 };
};

function sqrT1() {
    if(document.getElementById("imgSqrs476").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs476").src = "img/sqrs/blSqr.png"
};
};

function sqrT2() {
    if(document.getElementById("imgSqrs477").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs477").src = "img/sqrs/blSqr.png"
};
};

function sqrT3() {
    if(document.getElementById("imgSqrs478").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs478").src = "img/sqrs/blSqr.png"
};
};

function sqrT4() {
    if(document.getElementById("imgSqrs479").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs479").src = "img/sqrs/blSqr.png"
};
};

function sqrT5() {
    if(document.getElementById("imgSqrs480").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs480").src = "img/sqrs/blSqr.png"
};
};

function sqrT6() {
    if(document.getElementById("imgSqrs481").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs481").src = "img/sqrs/blSqr.png"
};
};

function sqrT7() {
    if(document.getElementById("imgSqrs482").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs482").src = "img/sqrs/blSqr.png"
};
};

function sqrT8() {
    if(document.getElementById("imgSqrs483").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs483").src = "img/sqrs/blSqr.png"
};
};

function sqrT9() {
    if(document.getElementById("imgSqrs484").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs484").src = "img/sqrs/blSqr.png"
};
};

function sqrT10() {
    if(document.getElementById("imgSqrs485").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs485").src = "img/sqrs/blSqr.png"
};
};

function sqrT11() {
    if(document.getElementById("imgSqrs486").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs486").src = "img/sqrs/blSqr.png"
};
};

function sqrT12() {
    if(document.getElementById("imgSqrs487").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs487").src = "img/sqrs/blSqr.png"
};
};

function sqrT13() {
    if(document.getElementById("imgSqrs488").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs488").src = "img/sqrs/blSqr.png"
};
};

function sqrT14() {
    if(document.getElementById("imgSqrs489").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs489").src = "img/sqrs/blSqr.png"
};
};

function sqrT15() {
    if(document.getElementById("imgSqrs490").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs490").src = "img/sqrs/blSqr.png"
};
};

function sqrT16() {
    if(document.getElementById("imgSqrs491").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs491").src = "img/sqrs/blSqr.png"
};
};

function sqrT17() {
    if(document.getElementById("imgSqrs492").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs492").src = "img/sqrs/blSqr.png"
};
};

function sqrT18() {
    if(document.getElementById("imgSqrs493").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs493").src = "img/sqrs/blSqr.png"
};
};

function sqrT19() {
    if(document.getElementById("imgSqrs494").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs494").src = "img/sqrs/blSqr.png"
};
};

function sqrT20() {
    if(document.getElementById("imgSqrs495").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs495").src = "img/sqrs/blSqr.png"
};
};

function sqrT21() {
    if(document.getElementById("imgSqrs496").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs496").src = "img/sqrs/blSqr.png"
};
};

function sqrT22() {
    if(document.getElementById("imgSqrs497").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs497").src = "img/sqrs/blSqr.png"
};
};

function sqrT23() {
    if(document.getElementById("imgSqrs498").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs498").src = "img/sqrs/blSqr.png"
};
};

function sqrT24() {
    if(document.getElementById("imgSqrs499").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs499").src = "img/sqrs/blSqr.png"
};
};

function sqrT25() {
    if(document.getElementById("imgSqrs500").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs500").src = "img/sqrs/blSqr.png"
 };
};

function sqrU1() {
    if(document.getElementById("imgSqrs501").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs501").src = "img/sqrs/blSqr.png"
};
};

function sqrU2() {
    if(document.getElementById("imgSqrs502").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs502").src = "img/sqrs/blSqr.png"
};
};

function sqrU3() {
    if(document.getElementById("imgSqrs503").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs503").src = "img/sqrs/blSqr.png"
};
};

function sqrU4() {
    if(document.getElementById("imgSqrs504").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs504").src = "img/sqrs/blSqr.png"
};
};

function sqrU5() {
    if(document.getElementById("imgSqrs505").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs505").src = "img/sqrs/blSqr.png"
};
};

function sqrU6() {
    if(document.getElementById("imgSqrs506").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs506").src = "img/sqrs/blSqr.png"
};
};

function sqrU7() {
    if(document.getElementById("imgSqrs507").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs507").src = "img/sqrs/blSqr.png"
};
};

function sqrU8() {
    if(document.getElementById("imgSqrs508").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs508").src = "img/sqrs/blSqr.png"
};
};

function sqrU9() {
    if(document.getElementById("imgSqrs509").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs509").src = "img/sqrs/blSqr.png"
};
};

function sqrU10() {
    if(document.getElementById("imgSqrs510").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs510").src = "img/sqrs/blSqr.png"
};
};

function sqrU11() {
    if(document.getElementById("imgSqrs511").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs511").src = "img/sqrs/blSqr.png"
};
};

function sqrU12() {
    if(document.getElementById("imgSqrs512").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs512").src = "img/sqrs/blSqr.png"
};
};

function sqrU13() {
    if(document.getElementById("imgSqrs513").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs513").src = "img/sqrs/blSqr.png"
};
};

function sqrU14() {
    if(document.getElementById("imgSqrs514").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs514").src = "img/sqrs/blSqr.png"
};
};

function sqrU15() {
    if(document.getElementById("imgSqrs515").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs515").src = "img/sqrs/blSqr.png"
};
};

function sqrU16() {
    if(document.getElementById("imgSqrs516").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs516").src = "img/sqrs/blSqr.png"
};
};

function sqrU17() {
    if(document.getElementById("imgSqrs517").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs517").src = "img/sqrs/blSqr.png"
};
};

function sqrU18() {
    if(document.getElementById("imgSqrs518").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs518").src = "img/sqrs/blSqr.png"
};
};

function sqrU19() {
    if(document.getElementById("imgSqrs519").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs519").src = "img/sqrs/blSqr.png"
};
};

function sqrU20() {
    if(document.getElementById("imgSqrs520").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs520").src = "img/sqrs/blSqr.png"
};
};

function sqrU21() {
    if(document.getElementById("imgSqrs521").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs521").src = "img/sqrs/blSqr.png"
};
};

function sqrU22() {
    if(document.getElementById("imgSqrs522").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs522").src = "img/sqrs/blSqr.png"
};
};

function sqrU23() {
    if(document.getElementById("imgSqrs523").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs523").src = "img/sqrs/blSqr.png"
};
};

function sqrU24() {
    if(document.getElementById("imgSqrs524").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs524").src = "img/sqrs/blSqr.png"
};
};

function sqrU25() {
    if(document.getElementById("imgSqrs525").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs525").src = "img/sqrs/blSqr.png"
 };
};

function sqrV1() {
    if(document.getElementById("imgSqrs526").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs526").src = "img/sqrs/blSqr.png"
};
};

function sqrV2() {
    if(document.getElementById("imgSqrs527").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs527").src = "img/sqrs/blSqr.png"
};
};

function sqrV3() {
    if(document.getElementById("imgSqrs528").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs528").src = "img/sqrs/blSqr.png"
};
};

function sqrV4() {
    if(document.getElementById("imgSqrs529").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs529").src = "img/sqrs/blSqr.png"
};
};

function sqrV5() {
    if(document.getElementById("imgSqrs530").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs530").src = "img/sqrs/blSqr.png"
};
};

function sqrV6() {
    if(document.getElementById("imgSqrs531").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs531").src = "img/sqrs/blSqr.png"
};
};

function sqrV7() {
    if(document.getElementById("imgSqrs532").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs532").src = "img/sqrs/blSqr.png"
};
};

function sqrV8() {
    if(document.getElementById("imgSqrs533").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs533").src = "img/sqrs/blSqr.png"
};
};

function sqrV9() {
    if(document.getElementById("imgSqrs534").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs534").src = "img/sqrs/blSqr.png"
};
};

function sqrV10() {
    if(document.getElementById("imgSqrs535").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs535").src = "img/sqrs/blSqr.png"
};
};

function sqrV11() {
    if(document.getElementById("imgSqrs536").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs536").src = "img/sqrs/blSqr.png"
};
};

function sqrV12() {
    if(document.getElementById("imgSqrs537").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs537").src = "img/sqrs/blSqr.png"
};
};

function sqrV13() {
    if(document.getElementById("imgSqrs538").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs538").src = "img/sqrs/blSqr.png"
};
};

function sqrV14() {
    if(document.getElementById("imgSqrs539").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs539").src = "img/sqrs/blSqr.png"
};
};

function sqrV15() {
    if(document.getElementById("imgSqrs540").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs540").src = "img/sqrs/blSqr.png"
};
};

function sqrV16() {
    if(document.getElementById("imgSqrs541").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs541").src = "img/sqrs/blSqr.png"
};
};

function sqrV17() {
    if(document.getElementById("imgSqrs542").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs542").src = "img/sqrs/blSqr.png"
};
};

function sqrV18() {
    if(document.getElementById("imgSqrs543").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs543").src = "img/sqrs/blSqr.png"
};
};

function sqrV19() {
    if(document.getElementById("imgSqrs544").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs544").src = "img/sqrs/blSqr.png"
};
};

function sqrV20() {
    if(document.getElementById("imgSqrs545").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs545").src = "img/sqrs/blSqr.png"
};
};

function sqrV21() {
    if(document.getElementById("imgSqrs546").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs546").src = "img/sqrs/blSqr.png"
};
};

function sqrV22() {
    if(document.getElementById("imgSqrs547").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs547").src = "img/sqrs/blSqr.png"
};
};

function sqrV23() {
    if(document.getElementById("imgSqrs548").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs548").src = "img/sqrs/blSqr.png"
};
};

function sqrV24() {
    if(document.getElementById("imgSqrs549").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs549").src = "img/sqrs/blSqr.png"
};
};

function sqrV25() {
    if(document.getElementById("imgSqrs550").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs550").src = "img/sqrs/blSqr.png"
 };
};

function sqrW1() {
    if(document.getElementById("imgSqrs551").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs551").src = "img/sqrs/blSqr.png"
};
};

function sqrW2() {
    if(document.getElementById("imgSqrs552").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs552").src = "img/sqrs/blSqr.png"
};
};

function sqrW3() {
    if(document.getElementById("imgSqrs553").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs553").src = "img/sqrs/blSqr.png"
};
};

function sqrW4() {
    if(document.getElementById("imgSqrs554").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs554").src = "img/sqrs/blSqr.png"
};
};

function sqrW5() {
    if(document.getElementById("imgSqrs555").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs555").src = "img/sqrs/blSqr.png"
};
};

function sqrW6() {
    if(document.getElementById("imgSqrs556").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs556").src = "img/sqrs/blSqr.png"
};
};

function sqrW7() {
    if(document.getElementById("imgSqrs557").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs557").src = "img/sqrs/blSqr.png"
};
};

function sqrW8() {
    if(document.getElementById("imgSqrs558").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs558").src = "img/sqrs/blSqr.png"
};
};

function sqrW9() {
    if(document.getElementById("imgSqrs559").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs559").src = "img/sqrs/blSqr.png"
};
};

function sqrW10() {
    if(document.getElementById("imgSqrs560").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs560").src = "img/sqrs/blSqr.png"
};
};

function sqrW11() {
    if(document.getElementById("imgSqrs561").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs561").src = "img/sqrs/blSqr.png"
};
};

function sqrW12() {
    if(document.getElementById("imgSqrs562").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs562").src = "img/sqrs/blSqr.png"
};
};

function sqrW13() {
    if(document.getElementById("imgSqrs563").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs563").src = "img/sqrs/blSqr.png"
};
};

function sqrW14() {
    if(document.getElementById("imgSqrs564").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs564").src = "img/sqrs/blSqr.png"
};
};

function sqrW15() {
    if(document.getElementById("imgSqrs565").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs565").src = "img/sqrs/blSqr.png"
};
};

function sqrW16() {
    if(document.getElementById("imgSqrs566").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs566").src = "img/sqrs/blSqr.png"
};
};

function sqrW17() {
    if(document.getElementById("imgSqrs567").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs567").src = "img/sqrs/blSqr.png"
};
};

function sqrW18() {
    if(document.getElementById("imgSqrs568").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs568").src = "img/sqrs/blSqr.png"
};
};

function sqrW19() {
    if(document.getElementById("imgSqrs569").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs569").src = "img/sqrs/blSqr.png"
};
};

function sqrW20() {
    if(document.getElementById("imgSqrs570").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs570").src = "img/sqrs/blSqr.png"
};
};

function sqrW21() {
    if(document.getElementById("imgSqrs571").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs571").src = "img/sqrs/blSqr.png"
};
};

function sqrW22() {
    if(document.getElementById("imgSqrs572").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs572").src = "img/sqrs/blSqr.png"
};
};

function sqrW23() {
    if(document.getElementById("imgSqrs573").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs573").src = "img/sqrs/blSqr.png"
};
};

function sqrW24() {
    if(document.getElementById("imgSqrs574").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs574").src = "img/sqrs/blSqr.png"
};
};

function sqrW25() {
    if(document.getElementById("imgSqrs575").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs575").src = "img/sqrs/blSqr.png"
 };
};

function sqrX1() {
    if(document.getElementById("imgSqrs576").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs576").src = "img/sqrs/blSqr.png"
};
};

function sqrX2() {
    if(document.getElementById("imgSqrs577").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs577").src = "img/sqrs/blSqr.png"
};
};

function sqrX3() {
    if(document.getElementById("imgSqrs578").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs578").src = "img/sqrs/blSqr.png"
};
};

function sqrX4() {
    if(document.getElementById("imgSqrs579").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs579").src = "img/sqrs/blSqr.png"
};
};

function sqrX5() {
    if(document.getElementById("imgSqrs580").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs580").src = "img/sqrs/blSqr.png"
};
};

function sqrX6() {
    if(document.getElementById("imgSqrs581").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs581").src = "img/sqrs/blSqr.png"
};
};

function sqrX7() {
    if(document.getElementById("imgSqrs582").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs582").src = "img/sqrs/blSqr.png"
};
};

function sqrX8() {
    if(document.getElementById("imgSqrs583").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs583").src = "img/sqrs/blSqr.png"
};
};

function sqrX9() {
    if(document.getElementById("imgSqrs584").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs584").src = "img/sqrs/blSqr.png"
};
};

function sqrX10() {
    if(document.getElementById("imgSqrs585").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs585").src = "img/sqrs/blSqr.png"
};
};

function sqrX11() {
    if(document.getElementById("imgSqrs586").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs586").src = "img/sqrs/blSqr.png"
};
};

function sqrX12() {
    if(document.getElementById("imgSqrs587").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs587").src = "img/sqrs/blSqr.png"
};
};

function sqrX13() {
    if(document.getElementById("imgSqrs588").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs588").src = "img/sqrs/blSqr.png"
};
};

function sqrX14() {
    if(document.getElementById("imgSqrs589").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs589").src = "img/sqrs/blSqr.png"
};
};

function sqrX15() {
    if(document.getElementById("imgSqrs590").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs590").src = "img/sqrs/blSqr.png"
};
};

function sqrX16() {
    if(document.getElementById("imgSqrs591").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs591").src = "img/sqrs/blSqr.png"
};
};

function sqrX17() {
    if(document.getElementById("imgSqrs592").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs592").src = "img/sqrs/blSqr.png"
};
};

function sqrX18() {
    if(document.getElementById("imgSqrs593").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs593").src = "img/sqrs/blSqr.png"
};
};

function sqrX19() {
    if(document.getElementById("imgSqrs594").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs594").src = "img/sqrs/blSqr.png"
};
};

function sqrX20() {
    if(document.getElementById("imgSqrs595").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs595").src = "img/sqrs/blSqr.png"
};
};

function sqrX21() {
    if(document.getElementById("imgSqrs596").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs596").src = "img/sqrs/blSqr.png"
};
};

function sqrX22() {
    if(document.getElementById("imgSqrs597").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs597").src = "img/sqrs/blSqr.png"
};
};

function sqrX23() {
    if(document.getElementById("imgSqrs598").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs598").src = "img/sqrs/blSqr.png"
};
};

function sqrX24() {
    if(document.getElementById("imgSqrs599").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs599").src = "img/sqrs/blSqr.png"
};
};

function sqrX25() {
    if(document.getElementById("imgSqrs600").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs600").src = "img/sqrs/blSqr.png"
 };
};

function sqrY1() {
    if(document.getElementById("imgSqrs601").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs601").src = "img/sqrs/blSqr.png"
};
};

function sqrY2() {
    if(document.getElementById("imgSqrs602").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs602").src = "img/sqrs/blSqr.png"
};
};

function sqrY3() {
    if(document.getElementById("imgSqrs603").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs603").src = "img/sqrs/blSqr.png"
};
};

function sqrY4() {
    if(document.getElementById("imgSqrs604").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs604").src = "img/sqrs/blSqr.png"
};
};

function sqrY5() {
    if(document.getElementById("imgSqrs605").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs605").src = "img/sqrs/blSqr.png"
};
};

function sqrY6() {
    if(document.getElementById("imgSqrs606").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs606").src = "img/sqrs/blSqr.png"
};
};

function sqrY7() {
    if(document.getElementById("imgSqrs607").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs607").src = "img/sqrs/blSqr.png"
};
};

function sqrY8() {
    if(document.getElementById("imgSqrs608").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs608").src = "img/sqrs/blSqr.png"
};
};

function sqrY9() {
    if(document.getElementById("imgSqrs609").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs609").src = "img/sqrs/blSqr.png"
};
};

function sqrY10() {
    if(document.getElementById("imgSqrs610").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs610").src = "img/sqrs/blSqr.png"
};
};

function sqrY11() {
    if(document.getElementById("imgSqrs611").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs611").src = "img/sqrs/blSqr.png"
};
};

function sqrY12() {
    if(document.getElementById("imgSqrs612").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs612").src = "img/sqrs/blSqr.png"
};
};

function sqrY13() {
    if(document.getElementById("imgSqrs613").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs613").src = "img/sqrs/blSqr.png"
};
};

function sqrY14() {
    if(document.getElementById("imgSqrs614").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs614").src = "img/sqrs/blSqr.png"
};
};

function sqrY15() {
    if(document.getElementById("imgSqrs615").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs615").src = "img/sqrs/blSqr.png"
};
};

function sqrY16() {
    if(document.getElementById("imgSqrs616").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs616").src = "img/sqrs/blSqr.png"
};
};

function sqrY17() {
    if(document.getElementById("imgSqrs617").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs617").src = "img/sqrs/blSqr.png"
};
};

function sqrY18() {
    if(document.getElementById("imgSqrs618").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs618").src = "img/sqrs/blSqr.png"
};
};

function sqrY19() {
    if(document.getElementById("imgSqrs619").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs619").src = "img/sqrs/blSqr.png"
};
};

function sqrY20() {
    if(document.getElementById("imgSqrs620").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs620").src = "img/sqrs/blSqr.png"
};
};

function sqrY21() {
    if(document.getElementById("imgSqrs621").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs621").src = "img/sqrs/blSqr.png"
};
};

function sqrY22() {
    if(document.getElementById("imgSqrs622").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs622").src = "img/sqrs/blSqr.png"
};
};

function sqrY23() {
    if(document.getElementById("imgSqrs623").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs623").src = "img/sqrs/blSqr.png"
};
};

function sqrY24() {
    if(document.getElementById("imgSqrs624").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs624").src = "img/sqrs/blSqr.png"
};
};

function sqrY25() {
    if(document.getElementById("imgSqrs625").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs625").src = "img/sqrs/blSqr.png"
};
};

function sqrA1b() {
    if(document.getElementById("imgSqrs1").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs1").src = "img/sqrs/wSqr.png"
};
};

function sqrA2b() {
    if(document.getElementById("imgSqrs2").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs2").src = "img/sqrs/wSqr.png"
};
};

function sqrA3b() {
    if(document.getElementById("imgSqrs3").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs3").src = "img/sqrs/wSqr.png"
};
};

function sqrA4b() {
    if(document.getElementById("imgSqrs4").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs4").src = "img/sqrs/wSqr.png"
};
};

function sqrA5b() {
    if(document.getElementById("imgSqrs5").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs5").src = "img/sqrs/wSqr.png"
};
};

function sqrA6b() {
    if(document.getElementById("imgSqrs6").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs6").src = "img/sqrs/wSqr.png"
};
};

function sqrA7b() {
    if(document.getElementById("imgSqrs7").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs7").src = "img/sqrs/wSqr.png"
};
};

function sqrA8b() {
    if(document.getElementById("imgSqrs8").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs8").src = "img/sqrs/wSqr.png"
};
};

function sqrA9b() {
    if(document.getElementById("imgSqrs9").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs9").src = "img/sqrs/wSqr.png"
};
};

function sqrA10b() {
    if(document.getElementById("imgSqrs10").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs10").src = "img/sqrs/wSqr.png"
};
};

function sqrA11b() {
    if(document.getElementById("imgSqrs11").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs11").src = "img/sqrs/wSqr.png"
};
};

function sqrA12b() {
    if(document.getElementById("imgSqrs12").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs12").src = "img/sqrs/wSqr.png"
};
};

function sqrA13b() {
    if(document.getElementById("imgSqrs13").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs13").src = "img/sqrs/wSqr.png"
};
};

function sqrA14b() {
    if(document.getElementById("imgSqrs14").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs14").src = "img/sqrs/wSqr.png"
};
};

function sqrA15b() {
    if(document.getElementById("imgSqrs15").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs15").src = "img/sqrs/wSqr.png"
};
};

function sqrA16b() {
    if(document.getElementById("imgSqrs16").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs16").src = "img/sqrs/wSqr.png"
};
};

function sqrA17b() {
    if(document.getElementById("imgSqrs17").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs17").src = "img/sqrs/wSqr.png"
};
};

function sqrA18b() {
    if(document.getElementById("imgSqrs18").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs18").src = "img/sqrs/wSqr.png"
};
};

function sqrA19b() {
    if(document.getElementById("imgSqrs19").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs19").src = "img/sqrs/wSqr.png"
};
};

function sqrA20b() {
    if(document.getElementById("imgSqrs20").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs20").src = "img/sqrs/wSqr.png"
};
};

function sqrA21b() {
    if(document.getElementById("imgSqrs21").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs21").src = "img/sqrs/wSqr.png"
};
};

function sqrA22b() {
    if(document.getElementById("imgSqrs22").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs22").src = "img/sqrs/wSqr.png"
};
};

function sqrA23b() {
    if(document.getElementById("imgSqrs23").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs23").src = "img/sqrs/wSqr.png"
};
};

function sqrA24b() {
    if(document.getElementById("imgSqrs24").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs24").src = "img/sqrs/wSqr.png"
};
};

function sqrA25b() {
    if(document.getElementById("imgSqrs25").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs25").src = "img/sqrs/wSqr.png"
 };
};

function sqrB1b() {
    if(document.getElementById("imgSqrs26").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs26").src = "img/sqrs/wSqr.png"
};
};

function sqrB2b() {
    if(document.getElementById("imgSqrs27").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs27").src = "img/sqrs/wSqr.png"
};
};

function sqrB3b() {
    if(document.getElementById("imgSqrs28").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs28").src = "img/sqrs/wSqr.png"
};
};

function sqrB4b() {
    if(document.getElementById("imgSqrs29").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs29").src = "img/sqrs/wSqr.png"
};
};

function sqrB5b() {
    if(document.getElementById("imgSqrs30").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs30").src = "img/sqrs/wSqr.png"
};
};

function sqrB6b() {
    if(document.getElementById("imgSqrs31").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs31").src = "img/sqrs/wSqr.png"
};
};

function sqrB7b() {
    if(document.getElementById("imgSqrs32").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs32").src = "img/sqrs/wSqr.png"
};
};

function sqrB8b() {
    if(document.getElementById("imgSqrs33").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs33").src = "img/sqrs/wSqr.png"
};
};

function sqrB9b() {
    if(document.getElementById("imgSqrs34").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs34").src = "img/sqrs/wSqr.png"
};
};

function sqrB10b() {
    if(document.getElementById("imgSqrs35").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs35").src = "img/sqrs/wSqr.png"
};
};

function sqrB11b() {
    if(document.getElementById("imgSqrs36").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs36").src = "img/sqrs/wSqr.png"
};
};

function sqrB12b() {
    if(document.getElementById("imgSqrs37").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs37").src = "img/sqrs/wSqr.png"
};
};

function sqrB13b() {
    if(document.getElementById("imgSqrs38").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs38").src = "img/sqrs/wSqr.png"
};
};

function sqrB14b() {
    if(document.getElementById("imgSqrs39").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs39").src = "img/sqrs/wSqr.png"
};
};

function sqrB15b() {
    if(document.getElementById("imgSqrs40").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs40").src = "img/sqrs/wSqr.png"
};
};

function sqrB16b() {
    if(document.getElementById("imgSqrs41").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs41").src = "img/sqrs/wSqr.png"
};
};

function sqrB17b() {
    if(document.getElementById("imgSqrs42").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs42").src = "img/sqrs/wSqr.png"
};
};

function sqrB18b() {
    if(document.getElementById("imgSqrs43").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs43").src = "img/sqrs/wSqr.png"
};
};

function sqrB19b() {
    if(document.getElementById("imgSqrs44").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs44").src = "img/sqrs/wSqr.png"
};
};

function sqrB20b() {
    if(document.getElementById("imgSqrs45").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs45").src = "img/sqrs/wSqr.png"
};
};

function sqrB21b() {
    if(document.getElementById("imgSqrs46").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs46").src = "img/sqrs/wSqr.png"
};
};

function sqrB22b() {
    if(document.getElementById("imgSqrs47").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs47").src = "img/sqrs/wSqr.png"
};
};

function sqrB23b() {
    if(document.getElementById("imgSqrs48").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs48").src = "img/sqrs/wSqr.png"
};
};

function sqrB24b() {
    if(document.getElementById("imgSqrs49").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs49").src = "img/sqrs/wSqr.png"
};
};

function sqrB25b() {
    if(document.getElementById("imgSqrs50").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs50").src = "img/sqrs/wSqr.png"
};
};

function sqrC1b() {
    if(document.getElementById("imgSqrs51").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs51").src = "img/sqrs/wSqr.png"
};
};

function sqrC2b() {
    if(document.getElementById("imgSqrs52").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs52").src = "img/sqrs/wSqr.png"
};
};

function sqrC3b() {
    if(document.getElementById("imgSqrs53").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs53").src = "img/sqrs/wSqr.png"
};
};

function sqrC4b() {
    if(document.getElementById("imgSqrs54").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs54").src = "img/sqrs/wSqr.png"
};
};

function sqrC5b() {
    if(document.getElementById("imgSqrs55").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs55").src = "img/sqrs/wSqr.png"
};
};

function sqrC6b() {
    if(document.getElementById("imgSqrs56").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs56").src = "img/sqrs/wSqr.png"
};
};

function sqrC7b() {
    if(document.getElementById("imgSqrs57").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs57").src = "img/sqrs/wSqr.png"
};
};

function sqrC8b() {
    if(document.getElementById("imgSqrs58").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs58").src = "img/sqrs/wSqr.png"
};
};

function sqrC9b() {
    if(document.getElementById("imgSqrs59").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs59").src = "img/sqrs/wSqr.png"
};
};

function sqrC10b() {
    if(document.getElementById("imgSqrs60").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs60").src = "img/sqrs/wSqr.png"
};
};

function sqrC11b() {
    if(document.getElementById("imgSqrs61").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs61").src = "img/sqrs/wSqr.png"
};
};

function sqrC12b() {
    if(document.getElementById("imgSqrs62").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs62").src = "img/sqrs/wSqr.png"
};
};

function sqrC13b() {
    if(document.getElementById("imgSqrs63").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs63").src = "img/sqrs/wSqr.png"
};
};

function sqrC14b() {
    if(document.getElementById("imgSqrs64").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs64").src = "img/sqrs/wSqr.png"
};
};

function sqrC15b() {
    if(document.getElementById("imgSqrs65").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs65").src = "img/sqrs/wSqr.png"
};
};

function sqrC16b() {
    if(document.getElementById("imgSqrs66").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs66").src = "img/sqrs/wSqr.png"
};
};

function sqrC17b() {
    if(document.getElementById("imgSqrs67").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs67").src = "img/sqrs/wSqr.png"
};
};

function sqrC18b() {
    if(document.getElementById("imgSqrs68").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs68").src = "img/sqrs/wSqr.png"
};
};

function sqrC19b() {
    if(document.getElementById("imgSqrs69").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs69").src = "img/sqrs/wSqr.png"
};
};

function sqrC20b() {
    if(document.getElementById("imgSqrs70").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs70").src = "img/sqrs/wSqr.png"
};
};

function sqrC21b() {
    if(document.getElementById("imgSqrs71").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs71").src = "img/sqrs/wSqr.png"
};
};

function sqrC22b() {
    if(document.getElementById("imgSqrs72").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs72").src = "img/sqrs/wSqr.png"
};
};

function sqrC23b() {
    if(document.getElementById("imgSqrs73").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs73").src = "img/sqrs/wSqr.png"
};
};

function sqrC24b() {
    if(document.getElementById("imgSqrs74").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs74").src = "img/sqrs/wSqr.png"
};
};

function sqrC25b() {
    if(document.getElementById("imgSqrs75").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs75").src = "img/sqrs/wSqr.png"
 };
};

function sqrD1b() {
    if(document.getElementById("imgSqrs76").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs76").src = "img/sqrs/wSqr.png"
};
};

function sqrD2b() {
    if(document.getElementById("imgSqrs77").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs77").src = "img/sqrs/wSqr.png"
};
};

function sqrD3b() {
    if(document.getElementById("imgSqrs78").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs78").src = "img/sqrs/wSqr.png"
};
};

function sqrD4b() {
    if(document.getElementById("imgSqrs79").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs79").src = "img/sqrs/wSqr.png"
};
};

function sqrD5b() {
    if(document.getElementById("imgSqrs80").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs80").src = "img/sqrs/wSqr.png"
};
};

function sqrD6b() {
    if(document.getElementById("imgSqrs81").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs81").src = "img/sqrs/wSqr.png"
};
};

function sqrD7b() {
    if(document.getElementById("imgSqrs82").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs82").src = "img/sqrs/wSqr.png"
};
};

function sqrD8b() {
    if(document.getElementById("imgSqrs83").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs83").src = "img/sqrs/wSqr.png"
};
};

function sqrD9b() {
    if(document.getElementById("imgSqrs84").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs84").src = "img/sqrs/wSqr.png"
};
};

function sqrD10b() {
    if(document.getElementById("imgSqrs85").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs85").src = "img/sqrs/wSqr.png"
};
};

function sqrD11b() {
    if(document.getElementById("imgSqrs86").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs86").src = "img/sqrs/wSqr.png"
};
};

function sqrD12b() {
    if(document.getElementById("imgSqrs87").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs87").src = "img/sqrs/wSqr.png"
};
};

function sqrD13b() {
    if(document.getElementById("imgSqrs88").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs88").src = "img/sqrs/wSqr.png"
};
};

function sqrD14b() {
    if(document.getElementById("imgSqrs89").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs89").src = "img/sqrs/wSqr.png"
};
};

function sqrD15b() {
    if(document.getElementById("imgSqrs90").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs90").src = "img/sqrs/wSqr.png"
};
};

function sqrD16b() {
    if(document.getElementById("imgSqrs91").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs91").src = "img/sqrs/wSqr.png"
};
};

function sqrD17b() {
    if(document.getElementById("imgSqrs92").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs92").src = "img/sqrs/wSqr.png"
};
};

function sqrD18b() {
    if(document.getElementById("imgSqrs93").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs93").src = "img/sqrs/wSqr.png"
};
};

function sqrD19b() {
    if(document.getElementById("imgSqrs94").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs94").src = "img/sqrs/wSqr.png"
};
};

function sqrD20b() {
    if(document.getElementById("imgSqrs95").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs95").src = "img/sqrs/wSqr.png"
};
};

function sqrD21b() {
    if(document.getElementById("imgSqrs96").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs96").src = "img/sqrs/wSqr.png"
};
};

function sqrD22b() {
    if(document.getElementById("imgSqrs97").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs97").src = "img/sqrs/wSqr.png"
};
};

function sqrD23b() {
    if(document.getElementById("imgSqrs98").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs98").src = "img/sqrs/wSqr.png"
};
};

function sqrD24b() {
    if(document.getElementById("imgSqrs99").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs99").src = "img/sqrs/wSqr.png"
};
};

function sqrD25b() {
    if(document.getElementById("imgSqrs100").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs100").src = "img/sqrs/wSqr.png"
 };
};

function sqrE1b() {
    if(document.getElementById("imgSqrs101").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs101").src = "img/sqrs/wSqr.png"
};
};

function sqrE2b() {
    if(document.getElementById("imgSqrs102").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs102").src = "img/sqrs/wSqr.png"
};
};

function sqrE3b() {
    if(document.getElementById("imgSqrs103").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs103").src = "img/sqrs/wSqr.png"
};
};

function sqrE4b() {
    if(document.getElementById("imgSqrs104").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs104").src = "img/sqrs/wSqr.png"
};
};

function sqrE5b() {
    if(document.getElementById("imgSqrs105").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs105").src = "img/sqrs/wSqr.png"
};
};

function sqrE6b() {
    if(document.getElementById("imgSqrs106").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs106").src = "img/sqrs/wSqr.png"
};
};

function sqrE7b() {
    if(document.getElementById("imgSqrs107").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs107").src = "img/sqrs/wSqr.png"
};
};

function sqrE8b() {
    if(document.getElementById("imgSqrs108").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs108").src = "img/sqrs/wSqr.png"
};
};

function sqrE9b() {
    if(document.getElementById("imgSqrs109").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs109").src = "img/sqrs/wSqr.png"
};
};

function sqrE10b() {
    if(document.getElementById("imgSqrs100").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs110").src = "img/sqrs/wSqr.png"
};
};

function sqrE11b() {
    if(document.getElementById("imgSqrs111").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs111").src = "img/sqrs/wSqr.png"
};
};

function sqrE12b() {
    if(document.getElementById("imgSqrs112").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs112").src = "img/sqrs/wSqr.png"
};
};

function sqrE13b() {
    if(document.getElementById("imgSqrs113").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs113").src = "img/sqrs/wSqr.png"
};
};

function sqrE14b() {
    if(document.getElementById("imgSqrs114").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs114").src = "img/sqrs/wSqr.png"
};
};

function sqrE15b() {
    if(document.getElementById("imgSqrs115").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs115").src = "img/sqrs/wSqr.png"
};
};

function sqrE16b() {
    if(document.getElementById("imgSqrs116").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs116").src = "img/sqrs/wSqr.png"
};
};

function sqrE17b() {
    if(document.getElementById("imgSqrs117").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs117").src = "img/sqrs/wSqr.png"
};
};

function sqrE18b() {
    if(document.getElementById("imgSqrs118").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs118").src = "img/sqrs/wSqr.png"
};
};

function sqrE19b() {
    if(document.getElementById("imgSqrs119").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs119").src = "img/sqrs/wSqr.png"
};
};

function sqrE20b() {
    if(document.getElementById("imgSqrs120").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs120").src = "img/sqrs/wSqr.png"
};
};

function sqrE21b() {
    if(document.getElementById("imgSqrs121").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs121").src = "img/sqrs/wSqr.png"
};
};

function sqrE22b() {
    if(document.getElementById("imgSqrs122").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs122").src = "img/sqrs/wSqr.png"
};
};

function sqrE23b() {
    if(document.getElementById("imgSqrs123").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs123").src = "img/sqrs/wSqr.png"
};
};

function sqrE24b() {
    if(document.getElementById("imgSqrs124").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs124").src = "img/sqrs/wSqr.png"
};
};

function sqrE25b() {
    if(document.getElementById("imgSqrs125").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs125").src = "img/sqrs/wSqr.png"
 };
};

function sqrF1b() {
    if(document.getElementById("imgSqrs126").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs126").src = "img/sqrs/wSqr.png"
};
};

function sqrF2b() {
    if(document.getElementById("imgSqrs127").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs127").src = "img/sqrs/wSqr.png"
};
};

function sqrF3b() {
    if(document.getElementById("imgSqrs128").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs128").src = "img/sqrs/wSqr.png"
};
};

function sqrF4b() {
    if(document.getElementById("imgSqrs129").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs129").src = "img/sqrs/wSqr.png"
};
};

function sqrF5b() {
    if(document.getElementById("imgSqrs130").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs130").src = "img/sqrs/wSqr.png"
};
};

function sqrF6b() {
    if(document.getElementById("imgSqrs131").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs131").src = "img/sqrs/wSqr.png"
};
};

function sqrF7b() {
    if(document.getElementById("imgSqrs132").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs132").src = "img/sqrs/wSqr.png"
};
};

function sqrF8b() {
    if(document.getElementById("imgSqrs133").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs133").src = "img/sqrs/wSqr.png"
};
};

function sqrF9b() {
    if(document.getElementById("imgSqrs134").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs134").src = "img/sqrs/wSqr.png"
};
};

function sqrF10b() {
    if(document.getElementById("imgSqrs135").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs135").src = "img/sqrs/wSqr.png"
};
};

function sqrF11b() {
    if(document.getElementById("imgSqrs136").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs136").src = "img/sqrs/wSqr.png"
};
};

function sqrF12b() {
    if(document.getElementById("imgSqrs137").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs137").src = "img/sqrs/wSqr.png"
};
};

function sqrF13b() {
    if(document.getElementById("imgSqrs138").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs138").src = "img/sqrs/wSqr.png"
};
};

function sqrF14b() {
    if(document.getElementById("imgSqrs139").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs139").src = "img/sqrs/wSqr.png"
};
};

function sqrF15b() {
    if(document.getElementById("imgSqrs140").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs140").src = "img/sqrs/wSqr.png"
};
};

function sqrF16b() {
    if(document.getElementById("imgSqrs141").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs141").src = "img/sqrs/wSqr.png"
};
};

function sqrF17b() {
    if(document.getElementById("imgSqrs142").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs142").src = "img/sqrs/wSqr.png"
};
};

function sqrF18b() {
    if(document.getElementById("imgSqrs143").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs143").src = "img/sqrs/wSqr.png"
};
};

function sqrF19b() {
    if(document.getElementById("imgSqrs144").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs144").src = "img/sqrs/wSqr.png"
};
};

function sqrF20b() {
    if(document.getElementById("imgSqrs145").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs145").src = "img/sqrs/wSqr.png"
};
};

function sqrF21b() {
    if(document.getElementById("imgSqrs146").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs146").src = "img/sqrs/wSqr.png"
};
};

function sqrF22b() {
    if(document.getElementById("imgSqrs147").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs147").src = "img/sqrs/wSqr.png"
};
};

function sqrF23b() {
    if(document.getElementById("imgSqrs148").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs148").src = "img/sqrs/wSqr.png"
};
};

function sqrF24b() {
    if(document.getElementById("imgSqrs149").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs149").src = "img/sqrs/wSqr.png"
};
};

function sqrF25b() {
    if(document.getElementById("imgSqrs150").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs150").src = "img/sqrs/wSqr.png"
 };
};

function sqrG1b() {
    if(document.getElementById("imgSqrs151").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs151").src = "img/sqrs/wSqr.png"
};
};

function sqrG2b() {
    if(document.getElementById("imgSqrs152").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs152").src = "img/sqrs/wSqr.png"
};
};

function sqrG3b() {
    if(document.getElementById("imgSqrs153").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs153").src = "img/sqrs/wSqr.png"
};
};

function sqrG4b() {
    if(document.getElementById("imgSqrs154").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs154").src = "img/sqrs/wSqr.png"
};
};

function sqrG5b() {
    if(document.getElementById("imgSqrs155").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs155").src = "img/sqrs/wSqr.png"
};
};

function sqrG6b() {
    if(document.getElementById("imgSqrs156").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs156").src = "img/sqrs/wSqr.png"
};
};

function sqrG7b() {
    if(document.getElementById("imgSqrs157").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs157").src = "img/sqrs/wSqr.png"
};
};

function sqrG8b() {
    if(document.getElementById("imgSqrs158").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs158").src = "img/sqrs/wSqr.png"
};
};

function sqrG9b() {
    if(document.getElementById("imgSqrs159").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs159").src = "img/sqrs/wSqr.png"
};
};

function sqrG10b() {
    if(document.getElementById("imgSqrs160").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs160").src = "img/sqrs/wSqr.png"
};
};

function sqrG11b() {
    if(document.getElementById("imgSqrs161").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs161").src = "img/sqrs/wSqr.png"
};
};

function sqrG12b() {
    if(document.getElementById("imgSqrs162").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs162").src = "img/sqrs/wSqr.png"
};
};

function sqrG13b() {
    if(document.getElementById("imgSqrs163").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs163").src = "img/sqrs/wSqr.png"
};
};

function sqrG14b() {
    if(document.getElementById("imgSqrs164").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs164").src = "img/sqrs/wSqr.png"
};
};

function sqrG15b() {
    if(document.getElementById("imgSqrs165").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs165").src = "img/sqrs/wSqr.png"
};
};

function sqrG16b() {
    if(document.getElementById("imgSqrs166").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs166").src = "img/sqrs/wSqr.png"
};
};

function sqrG17b() {
    if(document.getElementById("imgSqrs167").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs167").src = "img/sqrs/wSqr.png"
};
};

function sqrG18b() {
    if(document.getElementById("imgSqrs168").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs168").src = "img/sqrs/wSqr.png"
};
};

function sqrG19b() {
    if(document.getElementById("imgSqrs169").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs169").src = "img/sqrs/wSqr.png"
};
};

function sqrG20b() {
    if(document.getElementById("imgSqrs170").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs170").src = "img/sqrs/wSqr.png"
};
};

function sqrG21b() {
    if(document.getElementById("imgSqrs171").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs171").src = "img/sqrs/wSqr.png"
};
};

function sqrG22b() {
    if(document.getElementById("imgSqrs172").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs172").src = "img/sqrs/wSqr.png"
};
};

function sqrG23b() {
    if(document.getElementById("imgSqrs173").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs173").src = "img/sqrs/wSqr.png"
};
};

function sqrG24b() {
    if(document.getElementById("imgSqrs174").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs174").src = "img/sqrs/wSqr.png"
};
};

function sqrG25b() {
    if(document.getElementById("imgSqrs175").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs175").src = "img/sqrs/wSqr.png"
};
};

function sqrH1b() {
    if(document.getElementById("imgSqrs176").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs176").src = "img/sqrs/wSqr.png"
};
};

function sqrH2b() {
    if(document.getElementById("imgSqrs177").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs177").src = "img/sqrs/wSqr.png"
};
};

function sqrH3b() {
    if(document.getElementById("imgSqrs178").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs178").src = "img/sqrs/wSqr.png"
};
};

function sqrH4b() {
    if(document.getElementById("imgSqrs179").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs179").src = "img/sqrs/wSqr.png"
};
};

function sqrH5b() {
    if(document.getElementById("imgSqrs180").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs180").src = "img/sqrs/wSqr.png"
};
};

function sqrH6b() {
    if(document.getElementById("imgSqrs181").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs181").src = "img/sqrs/wSqr.png"
};
};

function sqrH7b() {
    if(document.getElementById("imgSqrs182").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs182").src = "img/sqrs/wSqr.png"
};
};

function sqrH8b() {
    if(document.getElementById("imgSqrs183").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs183").src = "img/sqrs/wSqr.png"
};
};

function sqrH9b() {
    if(document.getElementById("imgSqrs184").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs184").src = "img/sqrs/wSqr.png"
};
};

function sqrH10b() {
    if(document.getElementById("imgSqrs185").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs185").src = "img/sqrs/wSqr.png"
};
};

function sqrH11b() {
    if(document.getElementById("imgSqrs186").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs186").src = "img/sqrs/wSqr.png"
};
};

function sqrH12b() {
    if(document.getElementById("imgSqrs187").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs187").src = "img/sqrs/wSqr.png"
};
};

function sqrH13b() {
    if(document.getElementById("imgSqrs188").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs188").src = "img/sqrs/wSqr.png"
};
};

function sqrH14b() {
    if(document.getElementById("imgSqrs189").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs189").src = "img/sqrs/wSqr.png"
};
};

function sqrH15b() {
    if(document.getElementById("imgSqrs190").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs190").src = "img/sqrs/wSqr.png"
};
};

function sqrH16b() {
    if(document.getElementById("imgSqrs191").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs191").src = "img/sqrs/wSqr.png"
};
};

function sqrH17b() {
    if(document.getElementById("imgSqrs192").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs192").src = "img/sqrs/wSqr.png"
};
};

function sqrH18b() {
    if(document.getElementById("imgSqrs193").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs193").src = "img/sqrs/wSqr.png"
};
};

function sqrH19b() {
    if(document.getElementById("imgSqrs194").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs194").src = "img/sqrs/wSqr.png"
};
};

function sqrH20b() {
    if(document.getElementById("imgSqrs195").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs195").src = "img/sqrs/wSqr.png"
};
};

function sqrH21b() {
    if(document.getElementById("imgSqrs196").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs196").src = "img/sqrs/wSqr.png"
};
};

function sqrH22b() {
    if(document.getElementById("imgSqrs197").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs197").src = "img/sqrs/wSqr.png"
};
};

function sqrH23b() {
    if(document.getElementById("imgSqrs198").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs198").src = "img/sqrs/wSqr.png"
};
};

function sqrH24b() {
    if(document.getElementById("imgSqrs199").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs199").src = "img/sqrs/wSqr.png"
};
};

function sqrH25b() {
    if(document.getElementById("imgSqrs200").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs200").src = "img/sqrs/wSqr.png"
 };
};

function sqrI1b() {
    if(document.getElementById("imgSqrs201").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs201").src = "img/sqrs/wSqr.png"
};
};

function sqrI2b() {
    if(document.getElementById("imgSqrs202").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs202").src = "img/sqrs/wSqr.png"
};
};

function sqrI3b() {
    if(document.getElementById("imgSqrs203").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs203").src = "img/sqrs/wSqr.png"
};
};

function sqrI4b() {
    if(document.getElementById("imgSqrs204").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs204").src = "img/sqrs/wSqr.png"
};
};

function sqrI5b() {
    if(document.getElementById("imgSqrs205").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs205").src = "img/sqrs/wSqr.png"
};
};

function sqrI6b() {
    if(document.getElementById("imgSqrs206").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs206").src = "img/sqrs/wSqr.png"
};
};

function sqrI7b() {
    if(document.getElementById("imgSqrs207").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs207").src = "img/sqrs/wSqr.png"
};
};

function sqrI8b() {
    if(document.getElementById("imgSqrs208").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs208").src = "img/sqrs/wSqr.png"
};
};

function sqrI9b() {
    if(document.getElementById("imgSqrs209").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs209").src = "img/sqrs/wSqr.png"
};
};

function sqrI10b() {
    if(document.getElementById("imgSqrs210").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs210").src = "img/sqrs/wSqr.png"
};
};

function sqrI11b() {
    if(document.getElementById("imgSqrs211").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs211").src = "img/sqrs/wSqr.png"
};
};

function sqrI12b() {
    if(document.getElementById("imgSqrs212").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs212").src = "img/sqrs/wSqr.png"
};
};

function sqrI13b() {
    if(document.getElementById("imgSqrs213").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs213").src = "img/sqrs/wSqr.png"
};
};

function sqrI14b() {
    if(document.getElementById("imgSqrs214").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs214").src = "img/sqrs/wSqr.png"
};
};

function sqrI15b() {
    if(document.getElementById("imgSqrs215").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs215").src = "img/sqrs/wSqr.png"
};
};

function sqrI16b() {
    if(document.getElementById("imgSqrs216").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs216").src = "img/sqrs/wSqr.png"
};
};

function sqrI17b() {
    if(document.getElementById("imgSqrs217").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs217").src = "img/sqrs/wSqr.png"
};
};

function sqrI18b() {
    if(document.getElementById("imgSqrs218").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs218").src = "img/sqrs/wSqr.png"
};
};

function sqrI19b() {
    if(document.getElementById("imgSqrs219").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs219").src = "img/sqrs/wSqr.png"
};
};

function sqrI20b() {
    if(document.getElementById("imgSqrs220").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs220").src = "img/sqrs/wSqr.png"
};
};

function sqrI21b() {
    if(document.getElementById("imgSqrs221").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs221").src = "img/sqrs/wSqr.png"
};
};

function sqrI22b() {
    if(document.getElementById("imgSqrs222").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs222").src = "img/sqrs/wSqr.png"
};
};

function sqrI23b() {
    if(document.getElementById("imgSqrs223").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs223").src = "img/sqrs/wSqr.png"
};
};

function sqrI24b() {
    if(document.getElementById("imgSqrs224").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs224").src = "img/sqrs/wSqr.png"
};
};

function sqrI25b() {
    if(document.getElementById("imgSqrs225").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs225").src = "img/sqrs/wSqr.png"
 };
};

function sqrJ1b() {
    if(document.getElementById("imgSqrs226").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs226").src = "img/sqrs/wSqr.png"
};
};

function sqrJ2b() {
    if(document.getElementById("imgSqrs227").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs227").src = "img/sqrs/wSqr.png"
};
};

function sqrJ3b() {
    if(document.getElementById("imgSqrs228").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs228").src = "img/sqrs/wSqr.png"
};
};

function sqrJ4b() {
    if(document.getElementById("imgSqrs229").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs229").src = "img/sqrs/wSqr.png"
};
};

function sqrJ5b() {
    if(document.getElementById("imgSqrs230").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs230").src = "img/sqrs/wSqr.png"
};
};

function sqrJ6b() {
    if(document.getElementById("imgSqrs231").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs231").src = "img/sqrs/wSqr.png"
};
};

function sqrJ7b() {
    if(document.getElementById("imgSqrs232").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs232").src = "img/sqrs/wSqr.png"
};
};

function sqrJ8b() {
    if(document.getElementById("imgSqrs233").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs233").src = "img/sqrs/wSqr.png"
};
};

function sqrJ9b() {
    if(document.getElementById("imgSqrs234").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs234").src = "img/sqrs/wSqr.png"
};
};

function sqrJ10b() {
    if(document.getElementById("imgSqrs235").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs235").src = "img/sqrs/wSqr.png"
};
};

function sqrJ11b() {
    if(document.getElementById("imgSqrs236").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs236").src = "img/sqrs/wSqr.png"
};
};

function sqrJ12b() {
    if(document.getElementById("imgSqrs237").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs237").src = "img/sqrs/wSqr.png"
};
};

function sqrJ13b() {
    if(document.getElementById("imgSqrs238").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs238").src = "img/sqrs/wSqr.png"
};
};

function sqrJ14b() {
    if(document.getElementById("imgSqrs239").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs239").src = "img/sqrs/wSqr.png"
};
};

function sqrJ15b() {
    if(document.getElementById("imgSqrs240").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs240").src = "img/sqrs/wSqr.png"
};
};

function sqrJ16b() {
    if(document.getElementById("imgSqrs241").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs241").src = "img/sqrs/wSqr.png"
};
};

function sqrJ17b() {
    if(document.getElementById("imgSqrs242").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs242").src = "img/sqrs/wSqr.png"
};
};

function sqrJ18b() {
    if(document.getElementById("imgSqrs243").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs243").src = "img/sqrs/wSqr.png"
};
};

function sqrJ19b() {
    if(document.getElementById("imgSqrs244").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs244").src = "img/sqrs/wSqr.png"
};
};

function sqrJ20b() {
    if(document.getElementById("imgSqrs245").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs245").src = "img/sqrs/wSqr.png"
};
};

function sqrJ21b() {
    if(document.getElementById("imgSqrs246").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs246").src = "img/sqrs/wSqr.png"
};
};

function sqrJ22b() {
    if(document.getElementById("imgSqrs247").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs247").src = "img/sqrs/wSqr.png"
};
};

function sqrJ23b() {
    if(document.getElementById("imgSqrs248").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs248").src = "img/sqrs/wSqr.png"
};
};

function sqrJ24b() {
    if(document.getElementById("imgSqrs249").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs249").src = "img/sqrs/wSqr.png"
};
};

function sqrJ25b() {
    if(document.getElementById("imgSqrs250").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs250").src = "img/sqrs/wSqr.png"
 };
};

function sqrK1b() {
    if(document.getElementById("imgSqrs251").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs251").src = "img/sqrs/wSqr.png"
};
};

function sqrK2b() {
    if(document.getElementById("imgSqrs252").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs252").src = "img/sqrs/wSqr.png"
};
};

function sqrK3b() {
    if(document.getElementById("imgSqrs253").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs253").src = "img/sqrs/wSqr.png"
};
};

function sqrK4b() {
    if(document.getElementById("imgSqrs254").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs254").src = "img/sqrs/wSqr.png"
};
};

function sqrK5b() {
    if(document.getElementById("imgSqrs255").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs255").src = "img/sqrs/wSqr.png"
};
};

function sqrK6b() {
    if(document.getElementById("imgSqrs256").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs256").src = "img/sqrs/wSqr.png"
};
};

function sqrK7b() {
    if(document.getElementById("imgSqrs257").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs257").src = "img/sqrs/wSqr.png"
};
};

function sqrK8b() {
    if(document.getElementById("imgSqrs258").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs258").src = "img/sqrs/wSqr.png"
};
};

function sqrK9b() {
    if(document.getElementById("imgSqrs259").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs259").src = "img/sqrs/wSqr.png"
};
};

function sqrK10b() {
    if(document.getElementById("imgSqrs260").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs260").src = "img/sqrs/wSqr.png"
};
};

function sqrK11b() {
    if(document.getElementById("imgSqrs261").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs261").src = "img/sqrs/wSqr.png"
};
};

function sqrK12b() {
    if(document.getElementById("imgSqrs262").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs262").src = "img/sqrs/wSqr.png"
};
};

function sqrK13b() {
    if(document.getElementById("imgSqrs263").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs263").src = "img/sqrs/wSqr.png"
};
};

function sqrK14b() {
    if(document.getElementById("imgSqrs264").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs264").src = "img/sqrs/wSqr.png"
};
};

function sqrK15b() {
    if(document.getElementById("imgSqrs265").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs265").src = "img/sqrs/wSqr.png"
};
};

function sqrK16b() {
    if(document.getElementById("imgSqrs266").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs266").src = "img/sqrs/wSqr.png"
};
};

function sqrK17b() {
    if(document.getElementById("imgSqrs267").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs267").src = "img/sqrs/wSqr.png"
};
};

function sqrK18b() {
    if(document.getElementById("imgSqrs268").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs268").src = "img/sqrs/wSqr.png"
};
};

function sqrK19b() {
    if(document.getElementById("imgSqrs269").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs269").src = "img/sqrs/wSqr.png"
};
};

function sqrK20b() {
    if(document.getElementById("imgSqrs270").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs270").src = "img/sqrs/wSqr.png"
};
};

function sqrK21b() {
    if(document.getElementById("imgSqrs271").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs271").src = "img/sqrs/wSqr.png"
};
};

function sqrK22b() {
    if(document.getElementById("imgSqrs272").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs272").src = "img/sqrs/wSqr.png"
};
};

function sqrK23b() {
    if(document.getElementById("imgSqrs273").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs273").src = "img/sqrs/wSqr.png"
};
};

function sqrK24b() {
    if(document.getElementById("imgSqrs274").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs274").src = "img/sqrs/wSqr.png"
};
};

function sqrK25b() {
    if(document.getElementById("imgSqrs275").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs275").src = "img/sqrs/wSqr.png"
 };
};

function sqrL1b() {
    if(document.getElementById("imgSqrs276").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs276").src = "img/sqrs/wSqr.png"
};
};

function sqrL2b() {
    if(document.getElementById("imgSqrs277").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs277").src = "img/sqrs/wSqr.png"
};
};

function sqrL3b() {
    if(document.getElementById("imgSqrs278").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs278").src = "img/sqrs/wSqr.png"
};
};

function sqrL4b() {
    if(document.getElementById("imgSqrs279").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs279").src = "img/sqrs/wSqr.png"
};
};

function sqrL5b() {
    if(document.getElementById("imgSqrs280").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs280").src = "img/sqrs/wSqr.png"
};
};

function sqrL6b() {
    if(document.getElementById("imgSqrs281").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs281").src = "img/sqrs/wSqr.png"
};
};

function sqrL7b() {
    if(document.getElementById("imgSqrs282").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs282").src = "img/sqrs/wSqr.png"
};
};

function sqrL8b() {
    if(document.getElementById("imgSqrs283").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs283").src = "img/sqrs/wSqr.png"
};
};

function sqrL9b() {
    if(document.getElementById("imgSqrs284").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs284").src = "img/sqrs/wSqr.png"
};
};

function sqrL10b() {
    if(document.getElementById("imgSqrs285").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs285").src = "img/sqrs/wSqr.png"
};
};

function sqrL11b() {
    if(document.getElementById("imgSqrs286").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs286").src = "img/sqrs/wSqr.png"
};
};

function sqrL12b() {
    if(document.getElementById("imgSqrs287").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs287").src = "img/sqrs/wSqr.png"
};
};

function sqrL13b() {
    if(document.getElementById("imgSqrs288").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs288").src = "img/sqrs/wSqr.png"
};
};

function sqrL14b() {
    if(document.getElementById("imgSqrs289").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs289").src = "img/sqrs/wSqr.png"
};
};

function sqrL15b() {
    if(document.getElementById("imgSqrs290").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs290").src = "img/sqrs/wSqr.png"
};
};

function sqrL16b() {
    if(document.getElementById("imgSqrs291").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs291").src = "img/sqrs/wSqr.png"
};
};

function sqrL17b() {
    if(document.getElementById("imgSqrs292").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs292").src = "img/sqrs/wSqr.png"
};
};

function sqrL18b() {
    if(document.getElementById("imgSqrs293").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs293").src = "img/sqrs/wSqr.png"
};
};

function sqrL19b() {
    if(document.getElementById("imgSqrs294").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs294").src = "img/sqrs/wSqr.png"
};
};

function sqrL20b() {
    if(document.getElementById("imgSqrs295").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs295").src = "img/sqrs/wSqr.png"
};
};

function sqrL21b() {
    if(document.getElementById("imgSqrs296").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs296").src = "img/sqrs/wSqr.png"
};
};

function sqrL22b() {
    if(document.getElementById("imgSqrs297").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs297").src = "img/sqrs/wSqr.png"
};
};

function sqrL23b() {
    if(document.getElementById("imgSqrs298").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs298").src = "img/sqrs/wSqr.png"
};
};

function sqrL24b() {
    if(document.getElementById("imgSqrs299").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs299").src = "img/sqrs/wSqr.png"
};
};

function sqrL25b() {
    if(document.getElementById("imgSqrs300").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs300").src = "img/sqrs/wSqr.png"
 };
};

function sqrM1b() {
    if(document.getElementById("imgSqrs301").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs301").src = "img/sqrs/wSqr.png"
};
};

function sqrM2b() {
    if(document.getElementById("imgSqrs302").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs302").src = "img/sqrs/wSqr.png"
};
};

function sqrM3b() {
    if(document.getElementById("imgSqrs303").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs303").src = "img/sqrs/wSqr.png"
};
};

function sqrM4b() {
    if(document.getElementById("imgSqrs304").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs304").src = "img/sqrs/wSqr.png"
};
};

function sqrM5b() {
    if(document.getElementById("imgSqrs305").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs305").src = "img/sqrs/wSqr.png"
};
};

function sqrM6b() {
    if(document.getElementById("imgSqrs306").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs306").src = "img/sqrs/wSqr.png"
};
};

function sqrM7b() {
    if(document.getElementById("imgSqrs307").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs307").src = "img/sqrs/wSqr.png"
};
};

function sqrM8b() {
    if(document.getElementById("imgSqrs308").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs308").src = "img/sqrs/wSqr.png"
};
};

function sqrM9b() {
    if(document.getElementById("imgSqrs309").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs309").src = "img/sqrs/wSqr.png"
};
};

function sqrM10b() {
    if(document.getElementById("imgSqrs310").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs310").src = "img/sqrs/wSqr.png"
};
};

function sqrM11b() {
    if(document.getElementById("imgSqrs311").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs311").src = "img/sqrs/wSqr.png"
};
};

function sqrM12b() {
    if(document.getElementById("imgSqrs312").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs312").src = "img/sqrs/wSqr.png"
};
};

function sqrM13b() {
    if(document.getElementById("imgSqrs313").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs313").src = "img/sqrs/wSqr.png"
};
};

function sqrM14b() {
    if(document.getElementById("imgSqrs314").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs314").src = "img/sqrs/wSqr.png"
};
};

function sqrM15b() {
    if(document.getElementById("imgSqrs315").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs315").src = "img/sqrs/wSqr.png"
};
};

function sqrM16b() {
    if(document.getElementById("imgSqrs316").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs316").src = "img/sqrs/wSqr.png"
};
};

function sqrM17b() {
    if(document.getElementById("imgSqrs317").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs317").src = "img/sqrs/wSqr.png"
};
};

function sqrM18b() {
    if(document.getElementById("imgSqrs318").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs318").src = "img/sqrs/wSqr.png"
};
};

function sqrM19b() {
    if(document.getElementById("imgSqrs319").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs319").src = "img/sqrs/wSqr.png"
};
};

function sqrM20b() {
    if(document.getElementById("imgSqrs320").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs320").src = "img/sqrs/wSqr.png"
};
};

function sqrM21b() {
    if(document.getElementById("imgSqrs321").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs321").src = "img/sqrs/wSqr.png"
};
};

function sqrM22b() {
    if(document.getElementById("imgSqrs322").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs322").src = "img/sqrs/wSqr.png"
};
};

function sqrM23b() {
    if(document.getElementById("imgSqrs323").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs323").src = "img/sqrs/wSqr.png"
};
};

function sqrM24b() {
    if(document.getElementById("imgSqrs324").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs324").src = "img/sqrs/wSqr.png"
};
};

function sqrM25b() {
    if(document.getElementById("imgSqrs325").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs325").src = "img/sqrs/wSqr.png"
 };
};

function sqrN1b() {
    if(document.getElementById("imgSqrs326").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs326").src = "img/sqrs/wSqr.png"
};
};

function sqrN2b() {
    if(document.getElementById("imgSqrs327").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs327").src = "img/sqrs/wSqr.png"
};
};

function sqrN3b() {
    if(document.getElementById("imgSqrs328").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs328").src = "img/sqrs/wSqr.png"
};
};

function sqrN4b() {
    if(document.getElementById("imgSqrs329").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs329").src = "img/sqrs/wSqr.png"
};
};

function sqrN5b() {
    if(document.getElementById("imgSqrs330").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs330").src = "img/sqrs/wSqr.png"
};
};

function sqrN6b() {
    if(document.getElementById("imgSqrs331").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs331").src = "img/sqrs/wSqr.png"
};
};

function sqrN7b() {
    if(document.getElementById("imgSqrs332").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs332").src = "img/sqrs/wSqr.png"
};
};

function sqrN8b() {
    if(document.getElementById("imgSqrs333").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs333").src = "img/sqrs/wSqr.png"
};
};

function sqrN9b() {
    if(document.getElementById("imgSqrs334").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs334").src = "img/sqrs/wSqr.png"
};
};

function sqrN10b() {
    if(document.getElementById("imgSqrs335").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs335").src = "img/sqrs/wSqr.png"
};
};

function sqrN11b() {
    if(document.getElementById("imgSqrs336").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs336").src = "img/sqrs/wSqr.png"
};
};

function sqrN12b() {
    if(document.getElementById("imgSqrs337").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs337").src = "img/sqrs/wSqr.png"
};
};

function sqrN13b() {
    if(document.getElementById("imgSqrs338").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs338").src = "img/sqrs/wSqr.png"
};
};

function sqrN14b() {
    if(document.getElementById("imgSqrs339").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs339").src = "img/sqrs/wSqr.png"
};
};

function sqrN15b() {
    if(document.getElementById("imgSqrs340").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs340").src = "img/sqrs/wSqr.png"
};
};

function sqrN16b() {
    if(document.getElementById("imgSqrs341").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs341").src = "img/sqrs/wSqr.png"
};
};

function sqrN17b() {
    if(document.getElementById("imgSqrs342").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs342").src = "img/sqrs/wSqr.png"
};
};

function sqrN18b() {
    if(document.getElementById("imgSqrs343").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs343").src = "img/sqrs/wSqr.png"
};
};

function sqrN19b() {
    if(document.getElementById("imgSqrs344").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs344").src = "img/sqrs/wSqr.png"
};
};

function sqrN20b() {
    if(document.getElementById("imgSqrs345").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs345").src = "img/sqrs/wSqr.png"
};
};

function sqrN21b() {
    if(document.getElementById("imgSqrs346").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs346").src = "img/sqrs/wSqr.png"
};
};

function sqrN22b() {
    if(document.getElementById("imgSqrs347").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs347").src = "img/sqrs/wSqr.png"
};
};

function sqrN23b() {
    if(document.getElementById("imgSqrs348").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs348").src = "img/sqrs/wSqr.png"
};
};

function sqrN24b() {
    if(document.getElementById("imgSqrs349").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs349").src = "img/sqrs/wSqr.png"
};
};

function sqrN25b() {
    if(document.getElementById("imgSqrs350").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs350").src = "img/sqrs/wSqr.png"
 };
};

function sqrO1b() {
    if(document.getElementById("imgSqrs351").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs351").src = "img/sqrs/wSqr.png"
};
};

function sqrO2b() {
    if(document.getElementById("imgSqrs352").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs352").src = "img/sqrs/wSqr.png"
};
};

function sqrO3b() {
    if(document.getElementById("imgSqrs353").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs353").src = "img/sqrs/wSqr.png"
};
};

function sqrO4b() {
    if(document.getElementById("imgSqrs354").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs354").src = "img/sqrs/wSqr.png"
};
};

function sqrO5b() {
    if(document.getElementById("imgSqrs355").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs355").src = "img/sqrs/wSqr.png"
};
};

function sqrO6b() {
    if(document.getElementById("imgSqrs356").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs356").src = "img/sqrs/wSqr.png"
};
};

function sqrO7b() {
    if(document.getElementById("imgSqrs357").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs357").src = "img/sqrs/wSqr.png"
};
};

function sqrO8b() {
    if(document.getElementById("imgSqrs358").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs358").src = "img/sqrs/wSqr.png"
};
};

function sqrO9b() {
    if(document.getElementById("imgSqrs359").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs359").src = "img/sqrs/wSqr.png"
};
};

function sqrO10b() {
    if(document.getElementById("imgSqrs360").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs360").src = "img/sqrs/wSqr.png"
};
};

function sqrO11b() {
    if(document.getElementById("imgSqrs361").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs361").src = "img/sqrs/wSqr.png"
};
};

function sqrO12b() {
    if(document.getElementById("imgSqrs362").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs362").src = "img/sqrs/wSqr.png"
};
};

function sqrO13b() {
    if(document.getElementById("imgSqrs363").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs363").src = "img/sqrs/wSqr.png"
};
};

function sqrO14b() {
    if(document.getElementById("imgSqrs364").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs364").src = "img/sqrs/wSqr.png"
};
};

function sqrO15b() {
    if(document.getElementById("imgSqrs365").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs365").src = "img/sqrs/wSqr.png"
};
};

function sqrO16b() {
    if(document.getElementById("imgSqrs366").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs366").src = "img/sqrs/wSqr.png"
};
};

function sqrO17b() {
    if(document.getElementById("imgSqrs367").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs367").src = "img/sqrs/wSqr.png"
};
};

function sqrO18b() {
    if(document.getElementById("imgSqrs368").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs368").src = "img/sqrs/wSqr.png"
};
};

function sqrO19b() {
    if(document.getElementById("imgSqrs369").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs369").src = "img/sqrs/wSqr.png"
};
};

function sqrO20b() {
    if(document.getElementById("imgSqrs370").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs370").src = "img/sqrs/wSqr.png"
};
};

function sqrO21b() {
    if(document.getElementById("imgSqrs371").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs371").src = "img/sqrs/wSqr.png"
};
};

function sqrO22b() {
    if(document.getElementById("imgSqrs372").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs372").src = "img/sqrs/wSqr.png"
};
};

function sqrO23b() {
    if(document.getElementById("imgSqrs373").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs373").src = "img/sqrs/wSqr.png"
};
};

function sqrO24b() {
    if(document.getElementById("imgSqrs374").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs374").src = "img/sqrs/wSqr.png"
};
};

function sqrO25b() {
    if(document.getElementById("imgSqrs375").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs375").src = "img/sqrs/wSqr.png"
 };
};

function sqrP1b() {
    if(document.getElementById("imgSqrs376").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs376").src = "img/sqrs/wSqr.png"
};
};

function sqrP2b() {
    if(document.getElementById("imgSqrs377").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs377").src = "img/sqrs/wSqr.png"
};
};

function sqrP3b() {
    if(document.getElementById("imgSqrs378").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs378").src = "img/sqrs/wSqr.png"
};
};

function sqrP4b() {
    if(document.getElementById("imgSqrs379").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs379").src = "img/sqrs/wSqr.png"
};
};

function sqrP5b() {
    if(document.getElementById("imgSqrs380").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs380").src = "img/sqrs/wSqr.png"
};
};

function sqrP6b() {
    if(document.getElementById("imgSqrs381").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs381").src = "img/sqrs/wSqr.png"
};
};

function sqrP7b() {
    if(document.getElementById("imgSqrs382").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs382").src = "img/sqrs/wSqr.png"
};
};

function sqrP8b() {
    if(document.getElementById("imgSqrs383").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs383").src = "img/sqrs/wSqr.png"
};
};

function sqrP9b() {
    if(document.getElementById("imgSqrs384").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs384").src = "img/sqrs/wSqr.png"
};
};

function sqrP10b() {
    if(document.getElementById("imgSqrs385").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs385").src = "img/sqrs/wSqr.png"
};
};

function sqrP11b() {
    if(document.getElementById("imgSqrs386").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs386").src = "img/sqrs/wSqr.png"
};
};

function sqrP12b() {
    if(document.getElementById("imgSqrs387").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs387").src = "img/sqrs/wSqr.png"
};
};

function sqrP13b() {
    if(document.getElementById("imgSqrs388").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs388").src = "img/sqrs/wSqr.png"
};
};

function sqrP14b() {
    if(document.getElementById("imgSqrs389").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs389").src = "img/sqrs/wSqr.png"
};
};

function sqrP15b() {
    if(document.getElementById("imgSqrs390").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs390").src = "img/sqrs/wSqr.png"
};
};

function sqrP16b() {
    if(document.getElementById("imgSqrs391").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs391").src = "img/sqrs/wSqr.png"
};
};

function sqrP17b() {
    if(document.getElementById("imgSqrs392").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs392").src = "img/sqrs/wSqr.png"
};
};

function sqrP18b() {
    if(document.getElementById("imgSqrs393").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs393").src = "img/sqrs/wSqr.png"
};
};

function sqrP19b() {
    if(document.getElementById("imgSqrs394").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs394").src = "img/sqrs/wSqr.png"
};
};

function sqrP20b() {
    if(document.getElementById("imgSqrs395").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs395").src = "img/sqrs/wSqr.png"
};
};

function sqrP21b() {
    if(document.getElementById("imgSqrs396").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs396").src = "img/sqrs/wSqr.png"
};
};

function sqrP22b() {
    if(document.getElementById("imgSqrs397").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs397").src = "img/sqrs/wSqr.png"
};
};

function sqrP23b() {
    if(document.getElementById("imgSqrs398").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs398").src = "img/sqrs/wSqr.png"
};
};

function sqrP24b() {
    if(document.getElementById("imgSqrs399").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs399").src = "img/sqrs/wSqr.png"
};
};

function sqrP25b() {
    if(document.getElementById("imgSqrs400").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs400").src = "img/sqrs/wSqr.png"
 };
};

function sqrQ1b() {
    if(document.getElementById("imgSqrs401").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs401").src = "img/sqrs/wSqr.png"
};
};

function sqrQ2b() {
    if(document.getElementById("imgSqrs402").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs402").src = "img/sqrs/wSqr.png"
};
};

function sqrQ3b() {
    if(document.getElementById("imgSqrs403").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs403").src = "img/sqrs/wSqr.png"
};
};

function sqrQ4b() {
    if(document.getElementById("imgSqrs404").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs404").src = "img/sqrs/wSqr.png"
};
};

function sqrQ5b() {
    if(document.getElementById("imgSqrs405").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs405").src = "img/sqrs/wSqr.png"
};
};

function sqrQ6b() {
    if(document.getElementById("imgSqrs406").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs406").src = "img/sqrs/wSqr.png"
};
};

function sqrQ7b() {
    if(document.getElementById("imgSqrs407").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs407").src = "img/sqrs/wSqr.png"
};
};

function sqrQ8b() {
    if(document.getElementById("imgSqrs408").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs408").src = "img/sqrs/wSqr.png"
};
};

function sqrQ9b() {
    if(document.getElementById("imgSqrs409").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs409").src = "img/sqrs/wSqr.png"
};
};

function sqrQ10b() {
    if(document.getElementById("imgSqrs410").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs410").src = "img/sqrs/wSqr.png"
};
};

function sqrQ11b() {
    if(document.getElementById("imgSqrs411").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs411").src = "img/sqrs/wSqr.png"
};
};

function sqrQ12b() {
    if(document.getElementById("imgSqrs412").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs412").src = "img/sqrs/wSqr.png"
};
};

function sqrQ13b() {
    if(document.getElementById("imgSqrs413").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs413").src = "img/sqrs/wSqr.png"
};
};

function sqrQ14b() {
    if(document.getElementById("imgSqrs414").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs414").src = "img/sqrs/wSqr.png"
};
};

function sqrQ15b() {
    if(document.getElementById("imgSqrs415").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs415").src = "img/sqrs/wSqr.png"
};
};

function sqrQ16b() {
    if(document.getElementById("imgSqrs416").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs416").src = "img/sqrs/wSqr.png"
};
};

function sqrQ17b() {
    if(document.getElementById("imgSqrs417").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs417").src = "img/sqrs/wSqr.png"
};
};

function sqrQ18b() {
    if(document.getElementById("imgSqrs418").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs418").src = "img/sqrs/wSqr.png"
};
};

function sqrQ19b() {
    if(document.getElementById("imgSqrs419").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs419").src = "img/sqrs/wSqr.png"
};
};

function sqrQ20b() {
    if(document.getElementById("imgSqrs420").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs420").src = "img/sqrs/wSqr.png"
};
};

function sqrQ21b() {
    if(document.getElementById("imgSqrs421").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs421").src = "img/sqrs/wSqr.png"
};
};

function sqrQ22b() {
    if(document.getElementById("imgSqrs422").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs422").src = "img/sqrs/wSqr.png"
};
};

function sqrQ23b() {
    if(document.getElementById("imgSqrs423").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs423").src = "img/sqrs/wSqr.png"
};
};

function sqrQ24b() {
    if(document.getElementById("imgSqrs424").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs424").src = "img/sqrs/wSqr.png"
};
};

function sqrQ25b() {
    if(document.getElementById("imgSqrs425").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs425").src = "img/sqrs/wSqr.png"
 };
};

function sqrR1b() {
    if(document.getElementById("imgSqrs426").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs426").src = "img/sqrs/wSqr.png"
};
};

function sqrR2b() {
    if(document.getElementById("imgSqrs427").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs427").src = "img/sqrs/wSqr.png"
};
};

function sqrR3b() {
    if(document.getElementById("imgSqrs428").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs428").src = "img/sqrs/wSqr.png"
};
};

function sqrR4b() {
    if(document.getElementById("imgSqrs429").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs429").src = "img/sqrs/wSqr.png"
};
};

function sqrR5b() {
    if(document.getElementById("imgSqrs430").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs430").src = "img/sqrs/wSqr.png"
};
};

function sqrR6b() {
    if(document.getElementById("imgSqrs431").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs431").src = "img/sqrs/wSqr.png"
};
};

function sqrR7b() {
    if(document.getElementById("imgSqrs432").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs432").src = "img/sqrs/wSqr.png"
};
};

function sqrR8b() {
    if(document.getElementById("imgSqrs433").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs433").src = "img/sqrs/wSqr.png"
};
};

function sqrR9b() {
    if(document.getElementById("imgSqrs434").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs434").src = "img/sqrs/wSqr.png"
};
};

function sqrR10b() {
    if(document.getElementById("imgSqrs435").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs435").src = "img/sqrs/wSqr.png"
};
};

function sqrR11b() {
    if(document.getElementById("imgSqrs436").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs436").src = "img/sqrs/wSqr.png"
};
};

function sqrR12b() {
    if(document.getElementById("imgSqrs437").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs437").src = "img/sqrs/wSqr.png"
};
};

function sqrR13b() {
    if(document.getElementById("imgSqrs438").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs438").src = "img/sqrs/wSqr.png"
};
};

function sqrR14b() {
    if(document.getElementById("imgSqrs439").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs439").src = "img/sqrs/wSqr.png"
};
};

function sqrR15b() {
    if(document.getElementById("imgSqrs440").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs440").src = "img/sqrs/wSqr.png"
};
};

function sqrR16b() {
    if(document.getElementById("imgSqrs441").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs441").src = "img/sqrs/wSqr.png"
};
};

function sqrR17b() {
    if(document.getElementById("imgSqrs442").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs442").src = "img/sqrs/wSqr.png"
};
};

function sqrR18b() {
    if(document.getElementById("imgSqrs443").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs443").src = "img/sqrs/wSqr.png"
};
};

function sqrR19b() {
    if(document.getElementById("imgSqrs444").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs444").src = "img/sqrs/wSqr.png"
};
};

function sqrR20b() {
    if(document.getElementById("imgSqrs445").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs445").src = "img/sqrs/wSqr.png"
};
};

function sqrR21b() {
    if(document.getElementById("imgSqrs446").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs446").src = "img/sqrs/wSqr.png"
};
};

function sqrR22b() {
    if(document.getElementById("imgSqrs447").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs447").src = "img/sqrs/wSqr.png"
};
};

function sqrR23b() {
    if(document.getElementById("imgSqrs448").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs448").src = "img/sqrs/wSqr.png"
};
};

function sqrR24b() {
    if(document.getElementById("imgSqrs449").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs449").src = "img/sqrs/wSqr.png"
};
};

function sqrR25b() {
    if(document.getElementById("imgSqrs450").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs450").src = "img/sqrs/wSqr.png"
 };
};

function sqrS1b() {
    if(document.getElementById("imgSqrs451").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs451").src = "img/sqrs/wSqr.png"
};
};

function sqrS2b() {
    if(document.getElementById("imgSqrs452").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs452").src = "img/sqrs/wSqr.png"
};
};

function sqrS3b() {
    if(document.getElementById("imgSqrs453").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs453").src = "img/sqrs/wSqr.png"
};
};

function sqrS4b() {
    if(document.getElementById("imgSqrs454").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs454").src = "img/sqrs/wSqr.png"
};
};

function sqrS5b() {
    if(document.getElementById("imgSqrs455").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs455").src = "img/sqrs/wSqr.png"
};
};

function sqrS6b() {
    if(document.getElementById("imgSqrs456").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs456").src = "img/sqrs/wSqr.png"
};
};

function sqrS7b() {
    if(document.getElementById("imgSqrs457").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs457").src = "img/sqrs/wSqr.png"
};
};

function sqrS8b() {
    if(document.getElementById("imgSqrs458").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs458").src = "img/sqrs/wSqr.png"
};
};

function sqrS9b() {
    if(document.getElementById("imgSqrs459").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs459").src = "img/sqrs/wSqr.png"
};
};

function sqrS10b() {
    if(document.getElementById("imgSqrs460").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs460").src = "img/sqrs/wSqr.png"
};
};

function sqrS11b() {
    if(document.getElementById("imgSqrs461").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs461").src = "img/sqrs/wSqr.png"
};
};

function sqrS12b() {
    if(document.getElementById("imgSqrs462").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs462").src = "img/sqrs/wSqr.png"
};
};

function sqrS13b() {
    if(document.getElementById("imgSqrs463").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs463").src = "img/sqrs/wSqr.png"
};
};

function sqrS14b() {
    if(document.getElementById("imgSqrs464").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs464").src = "img/sqrs/wSqr.png"
};
};

function sqrS15b() {
    if(document.getElementById("imgSqrs465").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs465").src = "img/sqrs/wSqr.png"
};
};

function sqrS16b() {
    if(document.getElementById("imgSqrs466").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs466").src = "img/sqrs/wSqr.png"
};
};

function sqrS17b() {
    if(document.getElementById("imgSqrs467").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs467").src = "img/sqrs/wSqr.png"
};
};

function sqrS18b() {
    if(document.getElementById("imgSqrs468").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs468").src = "img/sqrs/wSqr.png"
};
};

function sqrS19b() {
    if(document.getElementById("imgSqrs469").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs469").src = "img/sqrs/wSqr.png"
};
};

function sqrS20b() {
    if(document.getElementById("imgSqrs470").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs470").src = "img/sqrs/wSqr.png"
};
};

function sqrS21b() {
    if(document.getElementById("imgSqrs471").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs471").src = "img/sqrs/wSqr.png"
};
};

function sqrS22b() {
    if(document.getElementById("imgSqrs472").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs472").src = "img/sqrs/wSqr.png"
};
};

function sqrS23b() {
    if(document.getElementById("imgSqrs473").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs473").src = "img/sqrs/wSqr.png"
};
};

function sqrS24b() {
    if(document.getElementById("imgSqrs474").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs474").src = "img/sqrs/wSqr.png"
};
};

function sqrS25b() {
    if(document.getElementById("imgSqrs475").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs475").src = "img/sqrs/wSqr.png"
 };
};

function sqrT1b() {
    if(document.getElementById("imgSqrs476").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs476").src = "img/sqrs/wSqr.png"
};
};

function sqrT2b() {
    if(document.getElementById("imgSqrs477").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs477").src = "img/sqrs/wSqr.png"
};
};

function sqrT3b() {
    if(document.getElementById("imgSqrs478").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs478").src = "img/sqrs/wSqr.png"
};
};

function sqrT4b() {
    if(document.getElementById("imgSqrs479").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs479").src = "img/sqrs/wSqr.png"
};
};

function sqrT5b() {
    if(document.getElementById("imgSqrs480").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs480").src = "img/sqrs/wSqr.png"
};
};

function sqrT6b() {
    if(document.getElementById("imgSqrs481").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs481").src = "img/sqrs/wSqr.png"
};
};

function sqrT7b() {
    if(document.getElementById("imgSqrs482").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs482").src = "img/sqrs/wSqr.png"
};
};

function sqrT8b() {
    if(document.getElementById("imgSqrs483").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs483").src = "img/sqrs/wSqr.png"
};
};

function sqrT9b() {
    if(document.getElementById("imgSqrs484").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs484").src = "img/sqrs/wSqr.png"
};
};

function sqrT10b() {
    if(document.getElementById("imgSqrs485").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs485").src = "img/sqrs/wSqr.png"
};
};

function sqrT11b() {
    if(document.getElementById("imgSqrs486").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs486").src = "img/sqrs/wSqr.png"
};
};

function sqrT12b() {
    if(document.getElementById("imgSqrs487").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs487").src = "img/sqrs/wSqr.png"
};
};

function sqrT13b() {
    if(document.getElementById("imgSqrs488").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs488").src = "img/sqrs/wSqr.png"
};
};

function sqrT14b() {
    if(document.getElementById("imgSqrs489").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs489").src = "img/sqrs/wSqr.png"
};
};

function sqrT15b() {
    if(document.getElementById("imgSqrs490").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs490").src = "img/sqrs/wSqr.png"
};
};

function sqrT16b() {
    if(document.getElementById("imgSqrs491").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs491").src = "img/sqrs/wSqr.png"
};
};

function sqrT17b() {
    if(document.getElementById("imgSqrs492").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs492").src = "img/sqrs/wSqr.png"
};
};

function sqrT18b() {
    if(document.getElementById("imgSqrs493").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs493").src = "img/sqrs/wSqr.png"
};
};

function sqrT19b() {
    if(document.getElementById("imgSqrs494").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs494").src = "img/sqrs/wSqr.png"
};
};

function sqrT20b() {
    if(document.getElementById("imgSqrs495").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs495").src = "img/sqrs/wSqr.png"
};
};

function sqrT21b() {
    if(document.getElementById("imgSqrs496").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs496").src = "img/sqrs/wSqr.png"
};
};

function sqrT22b() {
    if(document.getElementById("imgSqrs497").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs497").src = "img/sqrs/wSqr.png"
};
};

function sqrT23b() {
    if(document.getElementById("imgSqrs498").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs498").src = "img/sqrs/wSqr.png"
};
};

function sqrT24b() {
    if(document.getElementById("imgSqrs499").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs499").src = "img/sqrs/wSqr.png"
};
};

function sqrT25b() {
    if(document.getElementById("imgSqrs500").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs500").src = "img/sqrs/wSqr.png"
 };
};

function sqrU1b() {
    if(document.getElementById("imgSqrs501").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs501").src = "img/sqrs/wSqr.png"
};
};

function sqrU2b() {
    if(document.getElementById("imgSqrs502").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs502").src = "img/sqrs/wSqr.png"
};
};

function sqrU3b() {
    if(document.getElementById("imgSqrs503").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs503").src = "img/sqrs/wSqr.png"
};
};

function sqrU4b() {
    if(document.getElementById("imgSqrs504").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs504").src = "img/sqrs/wSqr.png"
};
};

function sqrU5b() {
    if(document.getElementById("imgSqrs505").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs505").src = "img/sqrs/wSqr.png"
};
};

function sqrU6b() {
    if(document.getElementById("imgSqrs506").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs506").src = "img/sqrs/wSqr.png"
};
};

function sqrU7b() {
    if(document.getElementById("imgSqrs507").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs507").src = "img/sqrs/wSqr.png"
};
};

function sqrU8b() {
    if(document.getElementById("imgSqrs508").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs508").src = "img/sqrs/wSqr.png"
};
};

function sqrU9b() {
    if(document.getElementById("imgSqrs509").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs509").src = "img/sqrs/wSqr.png"
};
};

function sqrU10b() {
    if(document.getElementById("imgSqrs510").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs510").src = "img/sqrs/wSqr.png"
};
};

function sqrU11b() {
    if(document.getElementById("imgSqrs511").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs511").src = "img/sqrs/wSqr.png"
};
};

function sqrU12b() {
    if(document.getElementById("imgSqrs512").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs512").src = "img/sqrs/wSqr.png"
};
};

function sqrU13b() {
    if(document.getElementById("imgSqrs513").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs513").src = "img/sqrs/wSqr.png"
};
};

function sqrU14b() {
    if(document.getElementById("imgSqrs514").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs514").src = "img/sqrs/wSqr.png"
};
};

function sqrU15b() {
    if(document.getElementById("imgSqrs515").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs515").src = "img/sqrs/wSqr.png"
};
};

function sqrU16b() {
    if(document.getElementById("imgSqrs516").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs516").src = "img/sqrs/wSqr.png"
};
};

function sqrU17b() {
    if(document.getElementById("imgSqrs517").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs517").src = "img/sqrs/wSqr.png"
};
};

function sqrU18b() {
    if(document.getElementById("imgSqrs518").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs518").src = "img/sqrs/wSqr.png"
};
};

function sqrU19b() {
    if(document.getElementById("imgSqrs519").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs519").src = "img/sqrs/wSqr.png"
};
};

function sqrU20b() {
    if(document.getElementById("imgSqrs520").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs520").src = "img/sqrs/wSqr.png"
};
};

function sqrU21b() {
    if(document.getElementById("imgSqrs521").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs521").src = "img/sqrs/wSqr.png"
};
};

function sqrU22b() {
    if(document.getElementById("imgSqrs522").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs522").src = "img/sqrs/wSqr.png"
};
};

function sqrU23b() {
    if(document.getElementById("imgSqrs523").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs523").src = "img/sqrs/wSqr.png"
};
};

function sqrU24b() {
    if(document.getElementById("imgSqrs524").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs524").src = "img/sqrs/wSqr.png"
};
};

function sqrU25b() {
    if(document.getElementById("imgSqrs525").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs525").src = "img/sqrs/wSqr.png"
 };
};

function sqrV1b() {
    if(document.getElementById("imgSqrs526").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs526").src = "img/sqrs/wSqr.png"
};
};

function sqrV2b() {
    if(document.getElementById("imgSqrs527").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs527").src = "img/sqrs/wSqr.png"
};
};

function sqrV3b() {
    if(document.getElementById("imgSqrs528").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs528").src = "img/sqrs/wSqr.png"
};
};

function sqrV4b() {
    if(document.getElementById("imgSqrs529").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs529").src = "img/sqrs/wSqr.png"
};
};

function sqrV5b() {
    if(document.getElementById("imgSqrs530").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs530").src = "img/sqrs/wSqr.png"
};
};

function sqrV6b() {
    if(document.getElementById("imgSqrs531").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs531").src = "img/sqrs/wSqr.png"
};
};

function sqrV7b() {
    if(document.getElementById("imgSqrs532").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs532").src = "img/sqrs/wSqr.png"
};
};

function sqrV8b() {
    if(document.getElementById("imgSqrs533").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs533").src = "img/sqrs/wSqr.png"
};
};

function sqrV9b() {
    if(document.getElementById("imgSqrs534").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs534").src = "img/sqrs/wSqr.png"
};
};

function sqrV10b() {
    if(document.getElementById("imgSqrs535").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs535").src = "img/sqrs/wSqr.png"
};
};

function sqrV11b() {
    if(document.getElementById("imgSqrs536").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs536").src = "img/sqrs/wSqr.png"
};
};

function sqrV12b() {
    if(document.getElementById("imgSqrs537").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs537").src = "img/sqrs/wSqr.png"
};
};

function sqrV13b() {
    if(document.getElementById("imgSqrs538").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs538").src = "img/sqrs/wSqr.png"
};
};

function sqrV14b() {
    if(document.getElementById("imgSqrs539").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs539").src = "img/sqrs/wSqr.png"
};
};

function sqrV15b() {
    if(document.getElementById("imgSqrs540").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs540").src = "img/sqrs/wSqr.png"
};
};

function sqrV16b() {
    if(document.getElementById("imgSqrs541").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs541").src = "img/sqrs/wSqr.png"
};
};

function sqrV17b() {
    if(document.getElementById("imgSqrs542").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs542").src = "img/sqrs/wSqr.png"
};
};

function sqrV18b() {
    if(document.getElementById("imgSqrs543").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs543").src = "img/sqrs/wSqr.png"
};
};

function sqrV19b() {
    if(document.getElementById("imgSqrs544").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs544").src = "img/sqrs/wSqr.png"
};
};

function sqrV20b() {
    if(document.getElementById("imgSqrs545").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs545").src = "img/sqrs/wSqr.png"
};
};

function sqrV21b() {
    if(document.getElementById("imgSqrs546").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs546").src = "img/sqrs/wSqr.png"
};
};

function sqrV22b() {
    if(document.getElementById("imgSqrs547").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs547").src = "img/sqrs/wSqr.png"
};
};

function sqrV23b() {
    if(document.getElementById("imgSqrs548").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs548").src = "img/sqrs/wSqr.png"
};
};

function sqrV24b() {
    if(document.getElementById("imgSqrs549").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs549").src = "img/sqrs/wSqr.png"
};
};

function sqrV25b() {
    if(document.getElementById("imgSqrs550").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs550").src = "img/sqrs/wSqr.png"
 };
};

function sqrW1b() {
    if(document.getElementById("imgSqrs551").src = "img/sqrs/blSqr.png") {
         document.getElementById("imgSqrs551").src = "img/sqrs/wSqr.png"
};
};

function sqrW2b() {
    if(document.getElementById("imgSqrs552").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs552").src = "img/sqrs/wSqr.png"
};
};

function sqrW3b() {
    if(document.getElementById("imgSqrs553").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs553").src = "img/sqrs/wSqr.png"
};
};

function sqrW4b() {
    if(document.getElementById("imgSqrs554").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs554").src = "img/sqrs/wSqr.png"
};
};

function sqrW5b() {
    if(document.getElementById("imgSqrs555").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs555").src = "img/sqrs/wSqr.png"
};
};

function sqrW6b() {
    if(document.getElementById("imgSqrs556").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs556").src = "img/sqrs/wSqr.png"
};
};

function sqrW7b() {
    if(document.getElementById("imgSqrs557").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs557").src = "img/sqrs/wSqr.png"
};
};

function sqrW8b() {
    if(document.getElementById("imgSqrs558").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs558").src = "img/sqrs/wSqr.png"
};
};

function sqrW9b() {
    if(document.getElementById("imgSqrs559").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs559").src = "img/sqrs/wSqr.png"
};
};

function sqrW10b() {
    if(document.getElementById("imgSqrs560").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs560").src = "img/sqrs/wSqr.png"
};
};

function sqrW11b() {
    if(document.getElementById("imgSqrs561").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs561").src = "img/sqrs/wSqr.png"
};
};

function sqrW12b() {
    if(document.getElementById("imgSqrs562").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs562").src = "img/sqrs/wSqr.png"
};
};

function sqrW13b() {
    if(document.getElementById("imgSqrs563").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs563").src = "img/sqrs/wSqr.png"
};
};

function sqrW14b() {
    if(document.getElementById("imgSqrs564").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs564").src = "img/sqrs/wSqr.png"
};
};

function sqrW15b() {
    if(document.getElementById("imgSqrs565").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs565").src = "img/sqrs/wSqr.png"
};
};

function sqrW16b() {
    if(document.getElementById("imgSqrs566").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs566").src = "img/sqrs/wSqr.png"
};
};

function sqrW17b() {
    if(document.getElementById("imgSqrs567").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs567").src = "img/sqrs/wSqr.png"
};
};

function sqrW18b() {
    if(document.getElementById("imgSqrs568").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs568").src = "img/sqrs/wSqr.png"
};
};

function sqrW19b() {
    if(document.getElementById("imgSqrs569").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs569").src = "img/sqrs/wSqr.png"
};
};

function sqrW20b() {
    if(document.getElementById("imgSqrs570").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs570").src = "img/sqrs/wSqr.png"
};
};

function sqrW21b() {
    if(document.getElementById("imgSqrs571").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs571").src = "img/sqrs/wSqr.png"
};
};

function sqrW22b() {
    if(document.getElementById("imgSqrs572").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs572").src = "img/sqrs/wSqr.png"
};
};

function sqrW23b() {
    if(document.getElementById("imgSqrs573").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs573").src = "img/sqrs/wSqr.png"
};
};

function sqrW24b() {
    if(document.getElementById("imgSqrs574").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs574").src = "img/sqrs/wSqr.png"
};
};

function sqrW25b() {
    if(document.getElementById("imgSqrs575").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs575").src = "img/sqrs/wSqr.png"
 };
};

function sqrX1b() {
    if(document.getElementById("imgSqrs576").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs576").src = "img/sqrs/wSqr.png"
};
};

function sqrX2b() {
    if(document.getElementById("imgSqrs577").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs577").src = "img/sqrs/wSqr.png"
};
};

function sqrX3b() {
    if(document.getElementById("imgSqrs578").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs578").src = "img/sqrs/wSqr.png"
};
};

function sqrX4b() {
    if(document.getElementById("imgSqrs579").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs579").src = "img/sqrs/wSqr.png"
};
};

function sqrX5b() {
    if(document.getElementById("imgSqrs580").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs580").src = "img/sqrs/wSqr.png"
};
};

function sqrX6b() {
    if(document.getElementById("imgSqrs581").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs581").src = "img/sqrs/wSqr.png"
};
};

function sqrX7b() {
    if(document.getElementById("imgSqrs582").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs582").src = "img/sqrs/wSqr.png"
};
};

function sqrX8b() {
    if(document.getElementById("imgSqrs583").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs583").src = "img/sqrs/wSqr.png"
};
};

function sqrX9b() {
    if(document.getElementById("imgSqrs584").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs584").src = "img/sqrs/wSqr.png"
};
};

function sqrX10b() {
    if(document.getElementById("imgSqrs585").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs585").src = "img/sqrs/wSqr.png"
};
};

function sqrX11b() {
    if(document.getElementById("imgSqrs586").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs586").src = "img/sqrs/wSqr.png"
};
};

function sqrX12b() {
    if(document.getElementById("imgSqrs587").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs587").src = "img/sqrs/wSqr.png"
};
};

function sqrX13b() {
    if(document.getElementById("imgSqrs588").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs588").src = "img/sqrs/wSqr.png"
};
};

function sqrX14b() {
    if(document.getElementById("imgSqrs589").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs589").src = "img/sqrs/wSqr.png"
};
};

function sqrX15b() {
    if(document.getElementById("imgSqrs590").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs590").src = "img/sqrs/wSqr.png"
};
};

function sqrX16b() {
    if(document.getElementById("imgSqrs591").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs591").src = "img/sqrs/wSqr.png"
};
};

function sqrX17b() {
    if(document.getElementById("imgSqrs592").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs592").src = "img/sqrs/wSqr.png"
};
};

function sqrX18b() {
    if(document.getElementById("imgSqrs593").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs593").src = "img/sqrs/wSqr.png"
};
};

function sqrX19b() {
    if(document.getElementById("imgSqrs594").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs594").src = "img/sqrs/wSqr.png"
};
};

function sqrX20b() {
    if(document.getElementById("imgSqrs595").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs595").src = "img/sqrs/wSqr.png"
};
};

function sqrX21b() {
    if(document.getElementById("imgSqrs596").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs596").src = "img/sqrs/wSqr.png"
};
};

function sqrX22b() {
    if(document.getElementById("imgSqrs597").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs597").src = "img/sqrs/wSqr.png"
};
};

function sqrX23b() {
    if(document.getElementById("imgSqrs598").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs598").src = "img/sqrs/wSqr.png"
};
};

function sqrX24b() {
    if(document.getElementById("imgSqrs599").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs599").src = "img/sqrs/wSqr.png"
};
};

function sqrX25b() {
    if(document.getElementById("imgSqrs600").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs600").src = "img/sqrs/wSqr.png"
 };
};

function sqrY1b() {
    if(document.getElementById("imgSqrs601").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs601").src = "img/sqrs/wSqr.png"
};
};

function sqrY2b() {
    if(document.getElementById("imgSqrs602").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs602").src = "img/sqrs/wSqr.png"
};
};

function sqrY3b() {
    if(document.getElementById("imgSqrs603").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs603").src = "img/sqrs/wSqr.png"
};
};

function sqrY4b() {
    if(document.getElementById("imgSqrs604").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs604").src = "img/sqrs/wSqr.png"
};
};

function sqrY5b() {
    if(document.getElementById("imgSqrs605").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs605").src = "img/sqrs/wSqr.png"
};
};

function sqrY6b() {
    if(document.getElementById("imgSqrs606").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs606").src = "img/sqrs/wSqr.png"
};
};

function sqrY7b() {
    if(document.getElementById("imgSqrs607").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs607").src = "img/sqrs/wSqr.png"
};
};

function sqrY8b() {
    if(document.getElementById("imgSqrs608").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs608").src = "img/sqrs/wSqr.png"
};
};

function sqrY9b() {
    if(document.getElementById("imgSqrs609").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs609").src = "img/sqrs/wSqr.png"
};
};

function sqrY10b() {
    if(document.getElementById("imgSqrs610").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs610").src = "img/sqrs/wSqr.png"
};
};

function sqrY11b() {
    if(document.getElementById("imgSqrs611").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs611").src = "img/sqrs/wSqr.png"
};
};

function sqrY12b() {
    if(document.getElementById("imgSqrs612").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs612").src = "img/sqrs/wSqr.png"
};
};

function sqrY13b() {
    if(document.getElementById("imgSqrs613").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs613").src = "img/sqrs/wSqr.png"
};
};

function sqrY14b() {
    if(document.getElementById("imgSqrs614").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs614").src = "img/sqrs/wSqr.png"
};
};

function sqrY15b() {
    if(document.getElementById("imgSqrs615").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs615").src = "img/sqrs/wSqr.png"
};
};

function sqrY16b() {
    if(document.getElementById("imgSqrs616").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs616").src = "img/sqrs/wSqr.png"
};
};

function sqrY17b() {
    if(document.getElementById("imgSqrs617").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs617").src = "img/sqrs/wSqr.png"
};
};

function sqrY18b() {
    if(document.getElementById("imgSqrs618").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs618").src = "img/sqrs/wSqr.png"
};
};

function sqrY19b() {
    if(document.getElementById("imgSqrs619").src = "img/sqrs/blSqr.png") {
     document.getElementById("imgSqrs619").src = "img/sqrs/wSqr.png"
};
};

function sqrY20b() {
    if(document.getElementById("imgSqrs620").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs620").src = "img/sqrs/wSqr.png"
};
};

function sqrY21b() {
    if(document.getElementById("imgSqrs621").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs621").src = "img/sqrs/wSqr.png"
};
};

function sqrY22b() {
    if(document.getElementById("imgSqrs622").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs622").src = "img/sqrs/wSqr.png"
};
};

function sqrY23b() {
    if(document.getElementById("imgSqrs623").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs623").src = "img/sqrs/wSqr.png"
};
};

function sqrY24b() {
    if(document.getElementById("imgSqrs624").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs624").src = "img/sqrs/wSqr.png"
};
};

function sqrY25b() {
    if(document.getElementById("imgSqrs625").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs625").src = "img/sqrs/wSqr.png"
};
};