function varC1() {
	valueSaveSS120 = "valueSaveSS120";
	var valuewjA = document.getElementById("blur").value;
	localStorage.setItem(valueSaveSS120, valuewjA);
 };
function varC2() {
	valueSaveSS121 = "valueSaveSS121";
	var valuewjB = document.getElementById("brightness").value;
	localStorage.setItem(valueSaveSS121, valuewjB);
};
function varC3() {
	valueSaveSS122 = "valueSaveSS122";
	var valuewjC = document.getElementById("contrast").value;
	localStorage.setItem(valueSaveSS122, valuewjC);
};
function varC4() {
	valueSaveSS123 = "valueSaveSS123";
	var valuewjD = document.getElementById("grayscale").value;
	localStorage.setItem(valueSaveSS123, valuewjD);
};
function varC5() {
	valueSaveSS124 = "valueSaveSS124";
	var valuewjE = document.getElementById("huerotate").value;
	localStorage.setItem(valueSaveSS124, valuewjE);
	};
function varC6() {
	valueSaveSS125 = "valueSaveSS125";
	var valuewjF = document.getElementById("invert").value;
	localStorage.setItem(valueSaveSS125, valuewjF);
	};
function varC7() {
	valueSaveSS126 = "valueSaveSS126";
	var valuewjG = document.getElementById("opacity").value;
	localStorage.setItem(valueSaveSS126, valuewjG);
	};
function varC8() {
	valueSaveSS127 = "valueSaveSS127";
	var valuewjH = document.getElementById("saturate").value;
	localStorage.setItem(valueSaveSS127, valuewjH);
	};
function varC9() {
	valueSaveSS128 = "valueSaveSS128";
	var valuewjI = document.getElementById("sepia").value;
	localStorage.setItem(valueSaveSS128, valuewjI);
	};
function varC10() {
	valueSaveSS129 = "valueSaveSS129";
	var valuewjJ = document.getElementById("widthNheight").value;
	localStorage.setItem(valueSaveSS129, valuewjJ);
	};
function varC11() {
	valueSaveSS130 = "valueSaveSS130";
	var valuewjK = document.getElementById("Background_Color-R").value;
	localStorage.setItem(valueSaveSS130, valuewjK);
	};
function varC12() {
	valueSaveSS131 = "valueSaveSS131";
	var valuewjL = document.getElementById("Background_Color-G").value;
	localStorage.setItem(valueSaveSS131, valuewjL);
	};
function varC13() {
	valueSaveSS132 = "valueSaveSS132";
	var valuewjM = document.getElementById("Background_Color-B").value;
	localStorage.setItem(valueSaveSS132, valuewjM);
	};
function varC14() {
	valueSaveSS133 = "valueSaveSS133";
	var valuewjN = document.getElementById("Font_Color-R").value;
	localStorage.setItem(valueSaveSS133, valuewjN);
	};
function varC15() {
	valueSaveSS134 = "valueSaveSS134";
	var valuewjO = document.getElementById("Font_Color-G").value;
	localStorage.setItem(valueSaveSS134, valuewjO);
	};
function varC16() {
    valueSaveSS135 = "valueSaveSS135";
	var valuewjA1 = document.getElementById("Font_Color-B").value;
	localStorage.setItem(valueSaveSS135, valuewjA1);
	};
function varD1() {
	valuewjA = "valueSaveSS120";
	var tripleZeroZ1 = localStorage.getItem(valuewjA);
	
	document.getElementById("blur").value = tripleZeroZ1;
	};
function varD2() {
	
    valuewjB = "valueSaveSS121";
	var tripleZeroZ2 = localStorage.getItem(valuewjB);
	
	document.getElementById("brightness").value = tripleZeroZ2;
	};
function varD3() {
	
    valuewjC = "valueSaveSS122";
	var tripleZeroZ3 = localStorage.getItem(valuewjC);
	
	document.getElementById("contrast").value = tripleZeroZ3;
	};
function varD4() {
	
    valuewjD = "valueSaveSS123";
	var tripleZeroZ4 = localStorage.getItem(valuewjD);
	
	document.getElementById("grayscale").value = tripleZeroZ4;
	};
function varD5() {
	
    valuewjE = "valueSaveSS124";
	var tripleZeroZ5 = localStorage.getItem(valuewjE);
	
	document.getElementById("huerotate").value = tripleZeroZ5;
	};
function varD6() {
	
    valuewjF = "valueSaveSS125";
	var tripleZeroZ6 = localStorage.getItem(valuewjF);
	
	document.getElementById("invert").value = tripleZeroZ6;
	};
function varD7() {
	
    valuewjG = "valueSaveSS126";
	var tripleZeroZ7 = localStorage.getItem(valuewjG);
	
	document.getElementById("opacity").value = tripleZeroZ7;
	};
function varD8() {
	
    valuewjH = "valueSaveSS127";
	var tripleZeroZ8 = localStorage.getItem(valuewjH);
	
	document.getElementById("saturate").value = tripleZeroZ8;
	};
function varD9() {
	
    valuewjI = "valueSaveSS128";
	var tripleZeroZ9 = localStorage.getItem(valuewjI);
	
	document.getElementById("sepia").value = tripleZeroZ9;
	};
function varD10() {
	
    valuewjJ = "valueSaveSS129";
	var tripleZeroZ10 = localStorage.getItem(valuewjJ);
	
	document.getElementById("widthNheight").value = tripleZeroZ10;
	};
function varD11() {
	
    valuewjK = "valueSaveSS130";
	var tripleZeroZ11 = localStorage.getItem(valuewjK);
	
	document.getElementById("Background_Color-R").value = tripleZeroZ11;
	};
function varD12() {
	
    valuewjL = "valueSaveSS131";
	var tripleZeroZ12 = localStorage.getItem(valuewjL);
	
	document.getElementById("Background_Color-G").value = tripleZeroZ12;
	};
function varD13() {
	
    valuewjM = "valueSaveSS132";
	var tripleZeroZ13 = localStorage.getItem(valuewjM);
	
	document.getElementById("Background_Color-B").value = tripleZeroZ13;
	};
function varD14() {
	
    valuewjN = "valueSaveSS133";
	var tripleZeroZ14 = localStorage.getItem(valuewjN);
	
	document.getElementById("Font_Color-R").value = tripleZeroZ14;
	};
function varD15() {
	
    valuewjO = "valueSaveSS134";
	var tripleZeroZ15 = localStorage.getItem(valuewjO);
	
	document.getElementById("Font_Color-G").value = tripleZeroZ15;
	};
function varD16() {
	
    valuewjA1 = "valueSaveSS135";
	var tripleZeroZ16 = localStorage.getItem(valuewjA1);
	
	document.getElementById("Font_Color-B").value = tripleZeroZ16;
	};
function varD() {
	varC1();
	varC2();
	varC3();
	varC4();
	varC5();
	varC6();
	varC7();
	varC8();
	varC9();
	varC10();
	varC11();
	varC12();
	varC13();
	varC14();
	varC15();
	varC16();
	alert("Effects Saved.");
	
};
function varE() {
	varD1();
	varD2();
	varD3();
	varD4();
	varD5();
	varD6();
	varD7();
	varD8();
	varD9();
	varD10();
	varD11();
	varD12();
	varD13();
	varD14();
	varD15();
	varD16();
	alert("Effects.");
	backgroundCrgb()
	fontCrgb()
	someCocepts()
	someCocepts2()
	someCoceptsA()
	someCocepts8()
	
};