function autoB20() {
     let a1 = Math.floor((Math.random() * 20) + 1);
	let a2 = Math.floor(((Math.random() * 20) + 1) + 20);
	let a3 = Math.floor(((Math.random() * 20) + 1) + 40);
	let a4 = Math.floor(((Math.random() * 20) + 1) + 60);
	let a5 = Math.floor(((Math.random() * 20) + 1) + 80);
	let a6 = Math.floor(((Math.random() * 20) + 1) + 100);
	let a7 = Math.floor(((Math.random() * 20) + 1) + 120);
	let a8 = Math.floor(((Math.random() * 20) + 1) + 140);
	let a9 = Math.floor(((Math.random() * 20) + 1) + 160);
	let a10 = Math.floor(((Math.random() * 20) + 1) + 180);
	let a11 = a10 + 20;
    let a12 = a9 + 60;
	let a13 = a8 + 100;
	let a14 = a7 + 140;
	let a15 = a6 + 180;
	let a16 = a5 + 220;
	let a17 = a4 + 260;
	let a18 = a3 + 300;
	let a19 = a2 + 340;
	let a20 = a1 + 380;
	
	var s1 = a1;
	var s2 = a2;
	var s3 = a3;
	var s4 = a4;
	var s5 = a5;
	var s6 = a6;
 	var s7 = a7;
	var s8 = a8;
	var s9 = a9;
	var s10 = a10;
	var s11 = a11;
	var s12 = a12;
	var s13 = a13;
	var s14 = a14;
	var s15 = a15;
	var s16 = a16;
	var s17 = a17;
	var s18 = a18;
	var s19 = a19;
	var s20 = a20;
	var t1 = 'imgSqrs' + s1;
	var t2 = 'imgSqrs' + s2;
	var t3 = 'imgSqrs' + s3;
	var t4 = 'imgSqrs' + s4;
	var t5 = 'imgSqrs' + s5;
	var t6 = 'imgSqrs' + s6;
	var t7 = 'imgSqrs' + s7;
	var t8 = 'imgSqrs' + s8;
	var t9 = 'imgSqrs' + s9;
	var t10 = 'imgSqrs' + s10;
	var t11 = 'imgSqrs' + s11;
	var t12 = 'imgSqrs' + s12;
	var t13 = 'imgSqrs' + s13;
	var t14 = 'imgSqrs' + s14;
	var t15 = 'imgSqrs' + s15;
	var t16 = 'imgSqrs' + s16;
	var t17 = 'imgSqrs' + s17;
	var t18 = 'imgSqrs' + s18;
	var t19 = 'imgSqrs' + s19;
	var t20 = 'imgSqrs' + s20;
	
	if(document.getElementById(t1).src = "img/sqrs/blSqr.png") {
		document.getElementById(t1).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t2).src = "img/sqrs/blSqr.png") {
		document.getElementById(t2).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t3).src = "img/sqrs/blSqr.png") {
		document.getElementById(t3).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t4).src = "img/sqrs/blSqr.png") {
		document.getElementById(t4).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t5).src = "img/sqrs/blSqr.png") {
		document.getElementById(t5).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t6).src = "img/sqrs/blSqr.png") {
		document.getElementById(t6).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t7).src = "img/sqrs/blSqr.png") {
		document.getElementById(t7).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t8).src = "img/sqrs/blSqr.png") {
		document.getElementById(t8).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t9).src = "img/sqrs/blSqr.png") {
		document.getElementById(t9).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t10).src = "img/sqrs/blSqr.png") {
		document.getElementById(t10).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t11).src = "img/sqrs/blSqr.png") {
		document.getElementById(t11).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t12).src = "img/sqrs/blSqr.png") {
		document.getElementById(t12).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t13).src = "img/sqrs/blSqr.png") {
		document.getElementById(t13).src = "img/sqrs/wSqr.png"
	};
    if(document.getElementById(t14).src = "img/sqrs/blSqr.png") {
		document.getElementById(t14).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t15).src = "img/sqrs/blSqr.png") {
		document.getElementById(t15).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t16).src = "img/sqrs/blSqr.png") {
		document.getElementById(t16).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t17).src = "img/sqrs/blSqr.png") {
		document.getElementById(t17).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t18).src = "img/sqrs/blSqr.png") {
		document.getElementById(t18).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t19).src = "img/sqrs/blSqr.png") {
		document.getElementById(t19).src = "img/sqrs/wSqr.png"
	};

    if(document.getElementById(t20).src = "img/sqrs/blSqr.png") {
		document.getElementById(t20).src = "img/sqrs/wSqr.png"
	};
};