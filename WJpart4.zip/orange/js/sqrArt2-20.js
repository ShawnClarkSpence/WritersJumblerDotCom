function ssqrsA1() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs1").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs1").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA2() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs2").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs2").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA3() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs3").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs3").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA4() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs4").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs4").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA5() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs5").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs5").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA6() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs6").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs6").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA7() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs7").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs7").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA8() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs8").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs8").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA9() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs9").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs9").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA10() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs10").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs10").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA11() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs11").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs11").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA12() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs12").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs12").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA13() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs13").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs13").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA14() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs14").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs14").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA15() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs15").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs15").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA16() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs16").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs16").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA17() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs17").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs17").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA18() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs18").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs18").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA19() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs19").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs19").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA20() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs20").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs20").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA21() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs21").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs21").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA22() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs22").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs22").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA23() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs23").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs23").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA24() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs24").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs24").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA25() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs25").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs25").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA26() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs26").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs26").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA27() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs27").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs27").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA28() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs28").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs28").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA29() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs29").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs29").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA30() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs30").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs30").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA31() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs31").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs31").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA32() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs32").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs32").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA33() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs33").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs33").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA34() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs34").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs34").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA35() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs35").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs35").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA36() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs36").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs36").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA37() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs37").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs37").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA38() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs38").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs38").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA39() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs39").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs39").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA40() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs40").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs40").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA41() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs41").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs41").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA42() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs42").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs42").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA43() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs43").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs43").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA44() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs44").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs44").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA45() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs45").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs45").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA46() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs46").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs46").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA47() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs47").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs47").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA48() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs48").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs48").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA49() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs49").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs49").src = "img/sqrs/blSqr.png"
};};};

function ssqrsA50() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs50").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs50").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB51() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs51").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs51").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB52() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs52").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs52").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB53() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs53").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs53").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB54() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs54").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs54").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB55() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs55").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs55").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB56() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs56").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs56").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB57() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs57").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs57").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB58() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs58").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs58").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB59() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs59").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs59").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB60() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs60").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs60").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB61() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs61").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs61").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB62() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs62").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs62").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB63() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs63").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs63").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB64() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs64").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs64").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB65() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs65").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs65").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB66() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs66").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs66").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB67() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs67").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs67").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB68() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs68").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs68").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB69() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs69").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs69").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB70() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs70").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs70").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB71() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs71").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs71").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB72() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs72").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs72").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB73() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs73").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs73").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB74() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs74").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs74").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB75() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs75").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs75").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB76() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs76").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs76").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB77() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs77").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs77").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB78() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs78").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs78").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB79() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs79").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs79").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB80() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs80").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs80").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB81() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs81").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs81").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB82() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs82").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs82").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB83() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs83").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs83").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB84() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs84").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs84").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB85() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs85").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs85").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB86() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs86").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs86").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB87() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs87").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs87").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB88() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs88").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs88").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB89() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs89").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs89").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB90() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs90").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs90").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB91() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs91").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs91").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB92() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs92").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs92").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB93() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs93").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs93").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB94() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs94").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs94").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB95() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs95").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs95").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB96() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs96").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs96").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB97() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs97").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs97").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB98() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs98").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs98").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB99() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs99").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs99").src = "img/sqrs/blSqr.png"
};};};

function ssqrsB100() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs100").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs100").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC101() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs101").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs101").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC102() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs102").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs102").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC103() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs103").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs103").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC104() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs104").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs104").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC105() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs105").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs105").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC106() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs106").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs106").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC107() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs107").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs107").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC108() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs108").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs108").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC109() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs109").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs109").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC110() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs110").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs110").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC111() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs111").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs111").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC112() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs112").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs112").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC113() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs113").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs113").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC114() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs114").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs114").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC115() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs115").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs115").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC116() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs116").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs116").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC117() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs117").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs117").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC118() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs118").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs118").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC119() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs119").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs119").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC120() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs120").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs120").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC121() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs121").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs121").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC122() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs122").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs122").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC123() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs123").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs123").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC124() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs124").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs124").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC125() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs125").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs125").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC126() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs126").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs126").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC127() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs127").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs127").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC128() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs128").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs128").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC129() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs129").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs129").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC130() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs130").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs130").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC131() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs131").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs131").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC132() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs132").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs132").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC133() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs133").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs133").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC134() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs134").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs134").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC135() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs135").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs135").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC136() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs136").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs136").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC137() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs137").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs137").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC138() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs138").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs138").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC139() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs139").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs139").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC140() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs140").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs140").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC141() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs141").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs141").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC142() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs142").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs142").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC143() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs143").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs143").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC144() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs144").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs144").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC145() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs145").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs145").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC146() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs146").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs146").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC147() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs147").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs147").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC148() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs148").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs148").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC149() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs149").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs149").src = "img/sqrs/blSqr.png"
};};};

function ssqrsC150() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs150").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs150").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD151() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs151").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs151").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD152() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs152").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs152").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD153() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs153").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs153").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD154() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs154").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs154").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD155() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs155").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs155").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD156() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs156").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs156").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD157() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs157").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs157").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD158() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs158").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs158").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD159() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs159").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs159").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD160() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs160").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs160").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD161() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs161").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs161").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD162() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs162").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs162").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD163() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs163").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs163").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD164() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs164").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs164").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD165() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs165").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs165").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD166() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs166").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs166").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD167() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs167").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs167").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD168() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs168").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs168").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD169() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs169").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs169").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD170() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs170").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs170").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD171() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs171").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs171").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD172() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs172").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs172").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD173() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs173").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs173").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD174() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs174").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs174").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD175() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs175").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs175").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD176() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs176").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs176").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD177() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs177").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs177").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD178() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs178").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs178").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD179() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs179").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs179").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD180() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs180").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs180").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD181() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs181").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs181").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD182() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs182").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs182").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD183() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs183").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs183").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD184() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs184").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs184").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD185() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs185").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs185").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD186() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs186").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs186").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD187() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs187").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs187").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD188() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs188").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs188").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD189() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs189").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs189").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD190() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs190").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs190").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD191() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs191").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs191").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD192() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs192").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs192").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD193() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs193").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs193").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD194() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs194").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs194").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD195() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs195").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs195").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD196() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs196").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs196").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD197() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs197").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs197").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD198() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs198").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs198").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD199() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs199").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs199").src = "img/sqrs/blSqr.png"
};};};

function ssqrsD200() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs200").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs200").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE201() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs201").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs201").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE202() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs202").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs202").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE203() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs203").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs203").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE204() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs204").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs204").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE205() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs205").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs205").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE206() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs206").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs206").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE207() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs207").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs207").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE208() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs208").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs208").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE209() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs209").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs209").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE210() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs210").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs210").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE211() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs211").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs211").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE212() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs212").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs212").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE213() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs213").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs213").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE214() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs214").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs214").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE215() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs215").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs215").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE216() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs216").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs216").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE217() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs217").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs217").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE218() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs218").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs218").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE219() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs219").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs219").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE220() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs220").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs220").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE221() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs221").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs221").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE222() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs222").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs222").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE223() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs223").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs223").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE224() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs224").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs224").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE225() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs225").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs225").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE226() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs226").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs226").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE227() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs227").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs227").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE228() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs228").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs228").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE229() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs229").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs229").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE230() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs230").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs230").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE231() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs231").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs231").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE232() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs232").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs232").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE233() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs233").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs233").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE234() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs234").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs234").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE235() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs235").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs235").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE236() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs236").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs236").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE237() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs237").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs237").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE238() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs238").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs238").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE239() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs239").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs239").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE240() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs240").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs240").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE241() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs241").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs241").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE242() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs242").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs242").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE243() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs243").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs243").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE244() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs244").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs244").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE245() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs245").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs245").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE246() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs246").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs246").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE247() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs247").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs247").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE248() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs248").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs248").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE249() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs249").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs249").src = "img/sqrs/blSqr.png"
};};};

function ssqrsE250() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs250").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs250").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF251() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs251").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs251").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF252() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs252").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs252").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF253() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs253").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs253").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF254() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs254").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs254").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF255() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs255").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs255").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF256() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs256").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs256").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF257() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs257").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs257").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF258() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs258").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs258").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF259() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs259").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs259").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF260() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs260").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs260").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF261() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs261").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs261").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF262() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs262").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs262").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF263() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs263").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs263").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF264() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs264").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs264").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF265() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs265").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs265").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF266() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs266").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs266").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF267() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs267").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs267").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF268() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs268").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs268").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF269() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs269").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs269").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF270() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs270").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs270").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF271() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs271").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs271").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF272() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs272").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs272").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF273() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs273").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs273").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF274() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs274").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs274").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF275() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs275").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs275").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF276() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs276").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs276").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF277() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs277").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs277").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF278() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs278").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs278").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF279() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs279").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs279").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF280() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs280").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs280").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF281() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs281").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs281").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF282() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs282").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs282").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF283() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs283").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs283").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF284() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs284").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs284").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF285() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs285").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs285").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF286() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs286").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs286").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF287() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs287").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs287").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF288() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs288").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs288").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF289() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs289").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs289").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF290() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs290").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs290").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF291() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs291").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs291").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF292() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs292").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs292").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF293() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs293").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs293").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF294() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs294").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs294").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF295() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs295").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs295").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF296() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs296").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs296").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF297() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs297").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs297").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF298() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs298").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs298").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF299() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs299").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs299").src = "img/sqrs/blSqr.png"
};};};

function ssqrsF300() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs300").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs300").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG301() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs301").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs301").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG302() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs302").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs302").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG303() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs303").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs303").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG304() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs304").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs304").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG305() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs305").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs305").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG306() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs306").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs306").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG307() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs307").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs307").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG308() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs308").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs308").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG309() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs309").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs309").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG310() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs310").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs310").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG311() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs311").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs311").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG312() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs312").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs312").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG313() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs313").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs313").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG314() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs314").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs314").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG315() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs315").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs315").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG316() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs316").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs316").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG317() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs317").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs317").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG318() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs318").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs318").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG319() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs319").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs319").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG320() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs320").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs320").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG321() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs321").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs321").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG322() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs322").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs322").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG323() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs323").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs323").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG324() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs324").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs324").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG325() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs325").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs325").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG326() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs326").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs326").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG327() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs327").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs327").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG328() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs328").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs328").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG329() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs329").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs329").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG330() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs330").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs330").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG331() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs331").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs331").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG332() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs332").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs332").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG333() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs333").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs333").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG334() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs334").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs334").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG335() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs335").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs335").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG336() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs336").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs336").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG337() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs337").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs337").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG338() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs338").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs338").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG339() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs339").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs339").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG340() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs340").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs340").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG341() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs341").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs341").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG342() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs342").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs342").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG343() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs343").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs343").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG344() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs344").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs344").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG345() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs345").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs345").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG346() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs346").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs346").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG347() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs347").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs347").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG348() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs348").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs348").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG349() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs349").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs349").src = "img/sqrs/blSqr.png"
};};};

function ssqrsG350() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs350").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs350").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH351() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs351").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs351").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH352() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs352").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs352").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH353() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs353").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs353").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH354() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs354").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs354").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH355() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs355").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs355").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH356() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs356").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs356").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH357() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs357").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs357").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH358() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs358").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs358").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH359() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs359").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs359").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH360() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs360").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs360").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH361() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs361").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs361").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH362() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs362").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs362").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH363() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs363").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs363").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH364() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs364").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs364").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH365() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs365").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs365").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH366() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs366").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs366").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH367() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs367").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs367").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH368() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs368").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs368").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH369() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs369").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs369").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH370() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs370").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs370").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH371() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs371").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs371").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH372() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs372").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs372").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH373() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs373").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs373").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH374() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs374").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs374").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH375() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs375").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs375").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH376() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs376").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs376").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH377() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs377").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs377").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH378() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs378").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs378").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH379() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs379").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs379").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH380() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs380").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs380").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH381() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs381").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs381").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH382() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs382").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs382").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH383() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs383").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs383").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH384() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs384").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs384").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH385() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs385").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs385").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH386() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs386").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs386").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH387() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs387").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs387").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH388() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs388").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs388").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH389() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs389").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs389").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH390() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs390").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs390").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH391() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs391").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs391").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH392() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs392").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs392").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH393() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs393").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs393").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH394() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs394").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs394").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH395() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs395").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs395").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH396() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs396").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs396").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH397() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs397").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs397").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH398() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs398").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs398").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH399() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs399").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs399").src = "img/sqrs/blSqr.png"
};};};

function ssqrsH400() {
 if(document.getElementById("check3").checked == true) {
    if(document.getElementById("imgSqrs400").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqrs400").src = "img/sqrs/blSqr.png"
};};};
