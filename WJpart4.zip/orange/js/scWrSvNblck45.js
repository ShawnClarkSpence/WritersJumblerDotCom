function square1(){

    var sQz1 = document.getElementById("imgSqrs1").src;

    value45Save1 = "zSqrArtSpecz1";

    localStorage.setItem(value45Save1, sQz1);
};

function square2(){

    var sQz2 = document.getElementById("imgSqrs2").src;

    value45Save2 = "zSqrArtSpecz2";

    localStorage.setItem(value45Save2, sQz2);
};

function square3(){

    var sQz3 = document.getElementById("imgSqrs3").src;

    value45Save3 = "zSqrArtSpecz3";

    localStorage.setItem(value45Save3, sQz3);
};

function square4(){

    var sQz4 = document.getElementById("imgSqrs4").src;

    value45Save4 = "zSqrArtSpecz4";

    localStorage.setItem(value45Save4, sQz4);
};

function square5(){

    var sQz5 = document.getElementById("imgSqrs5").src;

    value45Save5 = "zSqrArtSpecz5";

    localStorage.setItem(value45Save5, sQz5);
};

function square6(){

    var sQz6 = document.getElementById("imgSqrs6").src;

    value45Save6 = "zSqrArtSpecz6";

    localStorage.setItem(value45Save6, sQz6);
};

function square7(){

    var sQz7 = document.getElementById("imgSqrs7").src;

    value45Save7 = "zSqrArtSpecz7";

    localStorage.setItem(value45Save7, sQz7);
};

function square8(){

    var sQz8 = document.getElementById("imgSqrs8").src;

    value45Save8 = "zSqrArtSpecz8";

    localStorage.setItem(value45Save8, sQz8);
};

function square9(){

    var sQz9 = document.getElementById("imgSqrs9").src;

    value45Save9 = "zSqrArtSpecz9";

    localStorage.setItem(value45Save9, sQz9);
};

function square10(){

    var sQz10 = document.getElementById("imgSqrs10").src;

    value45Save10 = "zSqrArtSpecz10";

    localStorage.setItem(value45Save10, sQz10);
};

function square11(){

    var sQz11 = document.getElementById("imgSqrs11").src;

    value45Save11 = "zSqrArtSpecz11";

    localStorage.setItem(value45Save11, sQz11);
};

function square12(){

    var sQz12 = document.getElementById("imgSqrs12").src;

    value45Save12 = "zSqrArtSpecz12";

    localStorage.setItem(value45Save12, sQz12);
};

function square13(){

    var sQz13 = document.getElementById("imgSqrs13").src;

    value45Save13 = "zSqrArtSpecz13";

    localStorage.setItem(value45Save13, sQz13);
};

function square14(){

    var sQz14 = document.getElementById("imgSqrs14").src;

    value45Save14 = "zSqrArtSpecz14";

    localStorage.setItem(value45Save14, sQz14);
};

function square15(){

    var sQz15 = document.getElementById("imgSqrs15").src;

    value45Save15 = "zSqrArtSpecz15";

    localStorage.setItem(value45Save15, sQz15);
};

function square16(){

    var sQz16 = document.getElementById("imgSqrs16").src;

    value45Save16 = "zSqrArtSpecz16";

    localStorage.setItem(value45Save16, sQz16);
};

function square17(){

    var sQz17 = document.getElementById("imgSqrs17").src;

    value45Save17 = "zSqrArtSpecz17";

    localStorage.setItem(value45Save17, sQz17);
};

function square18(){

    var sQz18 = document.getElementById("imgSqrs18").src;

    value45Save18 = "zSqrArtSpecz18";

    localStorage.setItem(value45Save18, sQz18);
};

function square19(){

    var sQz19 = document.getElementById("imgSqrs19").src;

    value45Save19 = "zSqrArtSpecz19";

    localStorage.setItem(value45Save19, sQz19);
};

function square20(){

    var sQz20 = document.getElementById("imgSqrs20").src;

    value45Save20 = "zSqrArtSpecz20";

    localStorage.setItem(value45Save20, sQz20);
};

function square21(){

    var sQz21 = document.getElementById("imgSqrs21").src;

    value45Save21 = "zSqrArtSpecz21";

    localStorage.setItem(value45Save21, sQz21);
};

function square22(){

    var sQz22 = document.getElementById("imgSqrs22").src;

    value45Save22 = "zSqrArtSpecz22";

    localStorage.setItem(value45Save22, sQz22);
};

function square23(){

    var sQz23 = document.getElementById("imgSqrs23").src;

    value45Save23 = "zSqrArtSpecz23";

    localStorage.setItem(value45Save23, sQz23);
};

function square24(){

    var sQz24 = document.getElementById("imgSqrs24").src;

    value45Save24 = "zSqrArtSpecz24";

    localStorage.setItem(value45Save24, sQz24);
};

function square25(){

    var sQz25 = document.getElementById("imgSqrs25").src;

    value45Save25 = "zSqrArtSpecz25";

    localStorage.setItem(value45Save25, sQz25);
};

function square26(){

    var sQz26 = document.getElementById("imgSqrs26").src;

    value45Save26 = "zSqrArtSpecz26";

    localStorage.setItem(value45Save26, sQz26);
};

function square27(){

    var sQz27 = document.getElementById("imgSqrs27").src;

    value45Save27 = "zSqrArtSpecz27";

    localStorage.setItem(value45Save27, sQz27);
};

function square28(){

    var sQz28 = document.getElementById("imgSqrs28").src;

    value45Save28 = "zSqrArtSpecz28";

    localStorage.setItem(value45Save28, sQz28);
};

function square29(){

    var sQz29 = document.getElementById("imgSqrs29").src;

    value45Save29 = "zSqrArtSpecz29";

    localStorage.setItem(value45Save29, sQz29);
};

function square30(){

    var sQz30 = document.getElementById("imgSqrs30").src;

    value45Save30 = "zSqrArtSpecz30";

    localStorage.setItem(value45Save30, sQz30);
};

function square31(){

    var sQz31 = document.getElementById("imgSqrs31").src;

    value45Save31 = "zSqrArtSpecz31";

    localStorage.setItem(value45Save31, sQz31);
};

function square32(){

    var sQz32 = document.getElementById("imgSqrs32").src;

    value45Save32 = "zSqrArtSpecz32";

    localStorage.setItem(value45Save32, sQz32);
};

function square33(){

    var sQz33 = document.getElementById("imgSqrs33").src;

    value45Save33 = "zSqrArtSpecz33";

    localStorage.setItem(value45Save33, sQz33);
};

function square34(){

    var sQz34 = document.getElementById("imgSqrs34").src;

    value45Save34 = "zSqrArtSpecz34";

    localStorage.setItem(value45Save34, sQz34);
};

function square35(){

    var sQz35 = document.getElementById("imgSqrs35").src;

    value45Save35 = "zSqrArtSpecz35";

    localStorage.setItem(value45Save35, sQz35);
};

function square36(){

    var sQz36 = document.getElementById("imgSqrs36").src;

    value45Save36 = "zSqrArtSpecz36";

    localStorage.setItem(value45Save36, sQz36);
};

function square37(){

    var sQz37 = document.getElementById("imgSqrs37").src;

    value45Save37 = "zSqrArtSpecz37";

    localStorage.setItem(value45Save37, sQz37);
};

function square38(){

    var sQz38 = document.getElementById("imgSqrs38").src;

    value45Save38 = "zSqrArtSpecz38";

    localStorage.setItem(value45Save38, sQz38);
};

function square39(){

    var sQz39 = document.getElementById("imgSqrs39").src;

    value45Save39 = "zSqrArtSpecz39";

    localStorage.setItem(value45Save39, sQz39);
};

function square40(){

    var sQz40 = document.getElementById("imgSqrs40").src;

    value45Save40 = "zSqrArtSpecz40";

    localStorage.setItem(value45Save40, sQz40);
};

function square41(){

    var sQz41 = document.getElementById("imgSqrs41").src;

    value45Save41 = "zSqrArtSpecz41";

    localStorage.setItem(value45Save41, sQz41);
};

function square42(){

    var sQz42 = document.getElementById("imgSqrs42").src;

    value45Save42 = "zSqrArtSpecz42";

    localStorage.setItem(value45Save42, sQz42);
};

function square43(){

    var sQz43 = document.getElementById("imgSqrs43").src;

    value45Save43 = "zSqrArtSpecz43";

    localStorage.setItem(value45Save43, sQz43);
};

function square44(){

    var sQz44 = document.getElementById("imgSqrs44").src;

    value45Save44 = "zSqrArtSpecz44";

    localStorage.setItem(value45Save44, sQz44);
};

function square45(){

    var sQz45 = document.getElementById("imgSqrs45").src;

    value45Save45 = "zSqrArtSpecz45";

    localStorage.setItem(value45Save45, sQz45);
};

function square46(){

    var sQz46 = document.getElementById("imgSqrs46").src;

    value45Save46 = "zSqrArtSpecz46";

    localStorage.setItem(value45Save46, sQz46);
};

function square47(){

    var sQz47 = document.getElementById("imgSqrs47").src;

    value45Save47 = "zSqrArtSpecz47";

    localStorage.setItem(value45Save47, sQz47);
};

function square48(){

    var sQz48 = document.getElementById("imgSqrs48").src;

    value45Save48 = "zSqrArtSpecz48";

    localStorage.setItem(value45Save48, sQz48);
};

function square49(){

    var sQz49 = document.getElementById("imgSqrs49").src;

    value45Save49 = "zSqrArtSpecz49";

    localStorage.setItem(value45Save49, sQz49);
};

function square50(){

    var sQz50 = document.getElementById("imgSqrs50").src;

    value45Save50 = "zSqrArtSpecz50";

    localStorage.setItem(value45Save50, sQz50);
};

function square51(){

    var sQz51 = document.getElementById("imgSqrs51").src;

    value45Save51 = "zSqrArtSpecz51";

    localStorage.setItem(value45Save51, sQz51);
};

function square52(){

    var sQz52 = document.getElementById("imgSqrs52").src;

    value45Save52 = "zSqrArtSpecz52";

    localStorage.setItem(value45Save52, sQz52);
};

function square53(){

    var sQz53 = document.getElementById("imgSqrs53").src;

    value45Save53 = "zSqrArtSpecz53";

    localStorage.setItem(value45Save53, sQz53);
};

function square54(){

    var sQz54 = document.getElementById("imgSqrs54").src;

    value45Save54 = "zSqrArtSpecz54";

    localStorage.setItem(value45Save54, sQz54);
};

function square55(){

    var sQz55 = document.getElementById("imgSqrs55").src;

    value45Save55 = "zSqrArtSpecz55";

    localStorage.setItem(value45Save55, sQz55);
};

function square56(){

    var sQz56 = document.getElementById("imgSqrs56").src;

    value45Save56 = "zSqrArtSpecz56";

    localStorage.setItem(value45Save56, sQz56);
};

function square57(){

    var sQz57 = document.getElementById("imgSqrs57").src;

    value45Save57 = "zSqrArtSpecz57";

    localStorage.setItem(value45Save57, sQz57);
};

function square58(){

    var sQz58 = document.getElementById("imgSqrs58").src;

    value45Save58 = "zSqrArtSpecz58";

    localStorage.setItem(value45Save58, sQz58);
};

function square59(){

    var sQz59 = document.getElementById("imgSqrs59").src;

    value45Save59 = "zSqrArtSpecz59";

    localStorage.setItem(value45Save59, sQz59);
};

function square60(){

    var sQz60 = document.getElementById("imgSqrs60").src;

    value45Save60 = "zSqrArtSpecz60";

    localStorage.setItem(value45Save60, sQz60);
};

function square61(){

    var sQz61 = document.getElementById("imgSqrs61").src;

    value45Save61 = "zSqrArtSpecz61";

    localStorage.setItem(value45Save61, sQz61);
};

function square62(){

    var sQz62 = document.getElementById("imgSqrs62").src;

    value45Save62 = "zSqrArtSpecz62";

    localStorage.setItem(value45Save62, sQz62);
};

function square63(){

    var sQz63 = document.getElementById("imgSqrs63").src;

    value45Save63 = "zSqrArtSpecz63";

    localStorage.setItem(value45Save63, sQz63);
};

function square64(){

    var sQz64 = document.getElementById("imgSqrs64").src;

    value45Save64 = "zSqrArtSpecz64";

    localStorage.setItem(value45Save64, sQz64);
};

function square65(){

    var sQz65 = document.getElementById("imgSqrs65").src;

    value45Save65 = "zSqrArtSpecz65";

    localStorage.setItem(value45Save65, sQz65);
};

function square66(){

    var sQz66 = document.getElementById("imgSqrs66").src;

    value45Save66 = "zSqrArtSpecz66";

    localStorage.setItem(value45Save66, sQz66);
};

function square67(){

    var sQz67 = document.getElementById("imgSqrs67").src;

    value45Save67 = "zSqrArtSpecz67";

    localStorage.setItem(value45Save67, sQz67);
};

function square68(){

    var sQz68 = document.getElementById("imgSqrs68").src;

    value45Save68 = "zSqrArtSpecz68";

    localStorage.setItem(value45Save68, sQz68);
};

function square69(){

    var sQz69 = document.getElementById("imgSqrs69").src;

    value45Save69 = "zSqrArtSpecz69";

    localStorage.setItem(value45Save69, sQz69);
};

function square70(){

    var sQz70 = document.getElementById("imgSqrs70").src;

    value45Save70 = "zSqrArtSpecz70";

    localStorage.setItem(value45Save70, sQz70);
};

function square71(){

    var sQz71 = document.getElementById("imgSqrs71").src;

    value45Save71 = "zSqrArtSpecz71";

    localStorage.setItem(value45Save71, sQz71);
};

function square72(){

    var sQz72 = document.getElementById("imgSqrs72").src;

    value45Save72 = "zSqrArtSpecz72";

    localStorage.setItem(value45Save72, sQz72);
};

function square73(){

    var sQz73 = document.getElementById("imgSqrs73").src;

    value45Save73 = "zSqrArtSpecz73";

    localStorage.setItem(value45Save73, sQz73);
};

function square74(){

    var sQz74 = document.getElementById("imgSqrs74").src;

    value45Save74 = "zSqrArtSpecz74";

    localStorage.setItem(value45Save74, sQz74);
};

function square75(){

    var sQz75 = document.getElementById("imgSqrs75").src;

    value45Save75 = "zSqrArtSpecz75";

    localStorage.setItem(value45Save75, sQz75);
};

function square76(){

    var sQz76 = document.getElementById("imgSqrs76").src;

    value45Save76 = "zSqrArtSpecz76";

    localStorage.setItem(value45Save76, sQz76);
};

function square77(){

    var sQz77 = document.getElementById("imgSqrs77").src;

    value45Save77 = "zSqrArtSpecz77";

    localStorage.setItem(value45Save77, sQz77);
};

function square78(){

    var sQz78 = document.getElementById("imgSqrs78").src;

    value45Save78 = "zSqrArtSpecz78";

    localStorage.setItem(value45Save78, sQz78);
};

function square79(){

    var sQz79 = document.getElementById("imgSqrs79").src;

    value45Save79 = "zSqrArtSpecz79";

    localStorage.setItem(value45Save79, sQz79);
};

function square80(){

    var sQz80 = document.getElementById("imgSqrs80").src;

    value45Save80 = "zSqrArtSpecz80";

    localStorage.setItem(value45Save80, sQz80);
};

function square81(){

    var sQz81 = document.getElementById("imgSqrs81").src;

    value45Save81 = "zSqrArtSpecz81";

    localStorage.setItem(value45Save81, sQz81);
};

function square82(){

    var sQz82 = document.getElementById("imgSqrs82").src;

    value45Save82 = "zSqrArtSpecz82";

    localStorage.setItem(value45Save82, sQz82);
};

function square83(){

    var sQz83 = document.getElementById("imgSqrs83").src;

    value45Save83 = "zSqrArtSpecz83";

    localStorage.setItem(value45Save83, sQz83);
};

function square84(){

    var sQz84 = document.getElementById("imgSqrs84").src;

    value45Save84 = "zSqrArtSpecz84";

    localStorage.setItem(value45Save84, sQz84);
};

function square85(){

    var sQz85 = document.getElementById("imgSqrs85").src;

    value45Save85 = "zSqrArtSpecz85";

    localStorage.setItem(value45Save85, sQz85);
};

function square86(){

    var sQz86 = document.getElementById("imgSqrs86").src;

    value45Save86 = "zSqrArtSpecz86";

    localStorage.setItem(value45Save86, sQz86);
};

function square87(){

    var sQz87 = document.getElementById("imgSqrs87").src;

    value45Save87 = "zSqrArtSpecz87";

    localStorage.setItem(value45Save87, sQz87);
};

function square88(){

    var sQz88 = document.getElementById("imgSqrs88").src;

    value45Save88 = "zSqrArtSpecz88";

    localStorage.setItem(value45Save88, sQz88);
};

function square89(){

    var sQz89 = document.getElementById("imgSqrs89").src;

    value45Save89 = "zSqrArtSpecz89";

    localStorage.setItem(value45Save89, sQz89);
};

function square90(){

    var sQz90 = document.getElementById("imgSqrs90").src;

    value45Save90 = "zSqrArtSpecz90";

    localStorage.setItem(value45Save90, sQz90);
};

function square91(){

    var sQz91 = document.getElementById("imgSqrs91").src;

    value45Save91 = "zSqrArtSpecz91";

    localStorage.setItem(value45Save91, sQz91);
};

function square92(){

    var sQz92 = document.getElementById("imgSqrs92").src;

    value45Save92 = "zSqrArtSpecz92";

    localStorage.setItem(value45Save92, sQz92);
};

function square93(){

    var sQz93 = document.getElementById("imgSqrs93").src;

    value45Save93 = "zSqrArtSpecz93";

    localStorage.setItem(value45Save93, sQz93);
};

function square94(){

    var sQz94 = document.getElementById("imgSqrs94").src;

    value45Save94 = "zSqrArtSpecz94";

    localStorage.setItem(value45Save94, sQz94);
};

function square95(){

    var sQz95 = document.getElementById("imgSqrs95").src;

    value45Save95 = "zSqrArtSpecz95";

    localStorage.setItem(value45Save95, sQz95);
};

function square96(){

    var sQz96 = document.getElementById("imgSqrs96").src;

    value45Save96 = "zSqrArtSpecz96";

    localStorage.setItem(value45Save96, sQz96);
};

function square97(){

    var sQz97 = document.getElementById("imgSqrs97").src;

    value45Save97 = "zSqrArtSpecz97";

    localStorage.setItem(value45Save97, sQz97);
};

function square98(){

    var sQz98 = document.getElementById("imgSqrs98").src;

    value45Save98 = "zSqrArtSpecz98";

    localStorage.setItem(value45Save98, sQz98);
};

function square99(){

    var sQz99 = document.getElementById("imgSqrs99").src;

    value45Save99 = "zSqrArtSpecz99";

    localStorage.setItem(value45Save99, sQz99);
};

function square100(){

    var sQz100 = document.getElementById("imgSqrs100").src;

    value45Save100 = "zSqrArtSpecz100";

    localStorage.setItem(value45Save100, sQz100);
};

function square101(){

    var sQz101 = document.getElementById("imgSqrs101").src;

    value45Save101 = "zSqrArtSpecz101";

    localStorage.setItem(value45Save101, sQz101);
};

function square102(){

    var sQz102 = document.getElementById("imgSqrs102").src;

    value45Save102 = "zSqrArtSpecz102";

    localStorage.setItem(value45Save102, sQz102);
};

function square103(){

    var sQz103 = document.getElementById("imgSqrs103").src;

    value45Save103 = "zSqrArtSpecz103";

    localStorage.setItem(value45Save103, sQz103);
};

function square104(){

    var sQz104 = document.getElementById("imgSqrs104").src;

    value45Save104 = "zSqrArtSpecz104";

    localStorage.setItem(value45Save104, sQz104);
};

function square105(){

    var sQz105 = document.getElementById("imgSqrs105").src;

    value45Save105 = "zSqrArtSpecz105";

    localStorage.setItem(value45Save105, sQz105);
};

function square106(){

    var sQz106 = document.getElementById("imgSqrs106").src;

    value45Save106 = "zSqrArtSpecz106";

    localStorage.setItem(value45Save106, sQz106);
};

function square107(){

    var sQz107 = document.getElementById("imgSqrs107").src;

    value45Save107 = "zSqrArtSpecz107";

    localStorage.setItem(value45Save107, sQz107);
};

function square108(){

    var sQz108 = document.getElementById("imgSqrs108").src;

    value45Save108 = "zSqrArtSpecz108";

    localStorage.setItem(value45Save108, sQz108);
};

function square109(){

    var sQz109 = document.getElementById("imgSqrs109").src;

    value45Save109 = "zSqrArtSpecz109";

    localStorage.setItem(value45Save109, sQz109);
};

function square110(){

    var sQz110 = document.getElementById("imgSqrs110").src;

    value45Save110 = "zSqrArtSpecz110";

    localStorage.setItem(value45Save110, sQz110);
};

function square111(){

    var sQz111 = document.getElementById("imgSqrs111").src;

    value45Save111 = "zSqrArtSpecz111";

    localStorage.setItem(value45Save111, sQz111);
};

function square112(){

    var sQz112 = document.getElementById("imgSqrs112").src;

    value45Save112 = "zSqrArtSpecz112";

    localStorage.setItem(value45Save112, sQz112);
};

function square113(){

    var sQz113 = document.getElementById("imgSqrs113").src;

    value45Save113 = "zSqrArtSpecz113";

    localStorage.setItem(value45Save113, sQz113);
};

function square114(){

    var sQz114 = document.getElementById("imgSqrs114").src;

    value45Save114 = "zSqrArtSpecz114";

    localStorage.setItem(value45Save114, sQz114);
};

function square115(){

    var sQz115 = document.getElementById("imgSqrs115").src;

    value45Save115 = "zSqrArtSpecz115";

    localStorage.setItem(value45Save115, sQz115);
};

function square116(){

    var sQz116 = document.getElementById("imgSqrs116").src;

    value45Save116 = "zSqrArtSpecz116";

    localStorage.setItem(value45Save116, sQz116);
};

function square117(){

    var sQz117 = document.getElementById("imgSqrs117").src;

    value45Save117 = "zSqrArtSpecz117";

    localStorage.setItem(value45Save117, sQz117);
};

function square118(){

    var sQz118 = document.getElementById("imgSqrs118").src;

    value45Save118 = "zSqrArtSpecz118";

    localStorage.setItem(value45Save118, sQz118);
};

function square119(){

    var sQz119 = document.getElementById("imgSqrs119").src;

    value45Save119 = "zSqrArtSpecz119";

    localStorage.setItem(value45Save119, sQz119);
};

function square120(){

    var sQz120 = document.getElementById("imgSqrs120").src;

    value45Save120 = "zSqrArtSpecz120";

    localStorage.setItem(value45Save120, sQz120);
};

function square121(){

    var sQz121 = document.getElementById("imgSqrs121").src;

    value45Save121 = "zSqrArtSpecz121";

    localStorage.setItem(value45Save121, sQz121);
};

function square122(){

    var sQz122 = document.getElementById("imgSqrs122").src;

    value45Save122 = "zSqrArtSpecz122";

    localStorage.setItem(value45Save122, sQz122);
};

function square123(){

    var sQz123 = document.getElementById("imgSqrs123").src;

    value45Save123 = "zSqrArtSpecz123";

    localStorage.setItem(value45Save123, sQz123);
};

function square124(){

    var sQz124 = document.getElementById("imgSqrs124").src;

    value45Save124 = "zSqrArtSpecz124";

    localStorage.setItem(value45Save124, sQz124);
};

function square125(){

    var sQz125 = document.getElementById("imgSqrs125").src;

    value45Save125 = "zSqrArtSpecz125";

    localStorage.setItem(value45Save125, sQz125);
};

function square126(){

    var sQz126 = document.getElementById("imgSqrs126").src;

    value45Save126 = "zSqrArtSpecz126";

    localStorage.setItem(value45Save126, sQz126);
};

function square127(){

    var sQz127 = document.getElementById("imgSqrs127").src;

    value45Save127 = "zSqrArtSpecz127";

    localStorage.setItem(value45Save127, sQz127);
};

function square128(){

    var sQz128 = document.getElementById("imgSqrs128").src;

    value45Save128 = "zSqrArtSpecz128";

    localStorage.setItem(value45Save128, sQz128);
};

function square129(){

    var sQz129 = document.getElementById("imgSqrs129").src;

    value45Save129 = "zSqrArtSpecz129";

    localStorage.setItem(value45Save129, sQz129);
};

function square130(){

    var sQz130 = document.getElementById("imgSqrs130").src;

    value45Save130 = "zSqrArtSpecz130";

    localStorage.setItem(value45Save130, sQz130);
};

function square131(){

    var sQz131 = document.getElementById("imgSqrs131").src;

    value45Save131 = "zSqrArtSpecz131";

    localStorage.setItem(value45Save131, sQz131);
};

function square132(){

    var sQz132 = document.getElementById("imgSqrs132").src;

    value45Save132 = "zSqrArtSpecz132";

    localStorage.setItem(value45Save132, sQz132);
};

function square133(){

    var sQz133 = document.getElementById("imgSqrs133").src;

    value45Save133 = "zSqrArtSpecz133";

    localStorage.setItem(value45Save133, sQz133);
};

function square134(){

    var sQz134 = document.getElementById("imgSqrs134").src;

    value45Save134 = "zSqrArtSpecz134";

    localStorage.setItem(value45Save134, sQz134);
};

function square135(){

    var sQz135 = document.getElementById("imgSqrs135").src;

    value45Save135 = "zSqrArtSpecz135";

    localStorage.setItem(value45Save135, sQz135);
};

function square136(){

    var sQz136 = document.getElementById("imgSqrs136").src;

    value45Save136 = "zSqrArtSpecz136";

    localStorage.setItem(value45Save136, sQz136);
};

function square137(){

    var sQz137 = document.getElementById("imgSqrs137").src;

    value45Save137 = "zSqrArtSpecz137";

    localStorage.setItem(value45Save137, sQz137);
};

function square138(){

    var sQz138 = document.getElementById("imgSqrs138").src;

    value45Save138 = "zSqrArtSpecz138";

    localStorage.setItem(value45Save138, sQz138);
};

function square139(){

    var sQz139 = document.getElementById("imgSqrs139").src;

    value45Save139 = "zSqrArtSpecz139";

    localStorage.setItem(value45Save139, sQz139);
};

function square140(){

    var sQz140 = document.getElementById("imgSqrs140").src;

    value45Save140 = "zSqrArtSpecz140";

    localStorage.setItem(value45Save140, sQz140);
};

function square141(){

    var sQz141 = document.getElementById("imgSqrs141").src;

    value45Save141 = "zSqrArtSpecz141";

    localStorage.setItem(value45Save141, sQz141);
};

function square142(){

    var sQz142 = document.getElementById("imgSqrs142").src;

    value45Save142 = "zSqrArtSpecz142";

    localStorage.setItem(value45Save142, sQz142);
};

function square143(){

    var sQz143 = document.getElementById("imgSqrs143").src;

    value45Save143 = "zSqrArtSpecz143";

    localStorage.setItem(value45Save143, sQz143);
};

function square144(){

    var sQz144 = document.getElementById("imgSqrs144").src;

    value45Save144 = "zSqrArtSpecz144";

    localStorage.setItem(value45Save144, sQz144);
};

function square145(){

    var sQz145 = document.getElementById("imgSqrs145").src;

    value45Save145 = "zSqrArtSpecz145";

    localStorage.setItem(value45Save145, sQz145);
};

function square146(){

    var sQz146 = document.getElementById("imgSqrs146").src;

    value45Save146 = "zSqrArtSpecz146";

    localStorage.setItem(value45Save146, sQz146);
};

function square147(){

    var sQz147 = document.getElementById("imgSqrs147").src;

    value45Save147 = "zSqrArtSpecz147";

    localStorage.setItem(value45Save147, sQz147);
};

function square148(){

    var sQz148 = document.getElementById("imgSqrs148").src;

    value45Save148 = "zSqrArtSpecz148";

    localStorage.setItem(value45Save148, sQz148);
};

function square149(){

    var sQz149 = document.getElementById("imgSqrs149").src;

    value45Save149 = "zSqrArtSpecz149";

    localStorage.setItem(value45Save149, sQz149);
};

function square150(){

    var sQz150 = document.getElementById("imgSqrs150").src;

    value45Save150 = "zSqrArtSpecz150";

    localStorage.setItem(value45Save150, sQz150);
};

function square151(){

    var sQz151 = document.getElementById("imgSqrs151").src;

    value45Save151 = "zSqrArtSpecz151";

    localStorage.setItem(value45Save151, sQz151);
};

function square152(){

    var sQz152 = document.getElementById("imgSqrs152").src;

    value45Save152 = "zSqrArtSpecz152";

    localStorage.setItem(value45Save152, sQz152);
};

function square153(){

    var sQz153 = document.getElementById("imgSqrs153").src;

    value45Save153 = "zSqrArtSpecz153";

    localStorage.setItem(value45Save153, sQz153);
};

function square154(){

    var sQz154 = document.getElementById("imgSqrs154").src;

    value45Save154 = "zSqrArtSpecz154";

    localStorage.setItem(value45Save154, sQz154);
};

function square155(){

    var sQz155 = document.getElementById("imgSqrs155").src;

    value45Save155 = "zSqrArtSpecz155";

    localStorage.setItem(value45Save155, sQz155);
};

function square156(){

    var sQz156 = document.getElementById("imgSqrs156").src;

    value45Save156 = "zSqrArtSpecz156";

    localStorage.setItem(value45Save156, sQz156);
};

function square157(){

    var sQz157 = document.getElementById("imgSqrs157").src;

    value45Save157 = "zSqrArtSpecz157";

    localStorage.setItem(value45Save157, sQz157);
};

function square158(){

    var sQz158 = document.getElementById("imgSqrs158").src;

    value45Save158 = "zSqrArtSpecz158";

    localStorage.setItem(value45Save158, sQz158);
};

function square159(){

    var sQz159 = document.getElementById("imgSqrs159").src;

    value45Save159 = "zSqrArtSpecz159";

    localStorage.setItem(value45Save159, sQz159);
};

function square160(){

    var sQz160 = document.getElementById("imgSqrs160").src;

    value45Save160 = "zSqrArtSpecz160";

    localStorage.setItem(value45Save160, sQz160);
};

function square161(){

    var sQz161 = document.getElementById("imgSqrs161").src;

    value45Save161 = "zSqrArtSpecz161";

    localStorage.setItem(value45Save161, sQz161);
};

function square162(){

    var sQz162 = document.getElementById("imgSqrs162").src;

    value45Save162 = "zSqrArtSpecz162";

    localStorage.setItem(value45Save162, sQz162);
};

function square163(){

    var sQz163 = document.getElementById("imgSqrs163").src;

    value45Save163 = "zSqrArtSpecz163";

    localStorage.setItem(value45Save163, sQz163);
};

function square164(){

    var sQz164 = document.getElementById("imgSqrs164").src;

    value45Save164 = "zSqrArtSpecz164";

    localStorage.setItem(value45Save164, sQz164);
};

function square165(){

    var sQz165 = document.getElementById("imgSqrs165").src;

    value45Save165 = "zSqrArtSpecz165";

    localStorage.setItem(value45Save165, sQz165);
};

function square166(){

    var sQz166 = document.getElementById("imgSqrs166").src;

    value45Save166 = "zSqrArtSpecz166";

    localStorage.setItem(value45Save166, sQz166);
};

function square167(){

    var sQz167 = document.getElementById("imgSqrs167").src;

    value45Save167 = "zSqrArtSpecz167";

    localStorage.setItem(value45Save167, sQz167);
};

function square168(){

    var sQz168 = document.getElementById("imgSqrs168").src;

    value45Save168 = "zSqrArtSpecz168";

    localStorage.setItem(value45Save168, sQz168);
};

function square169(){

    var sQz169 = document.getElementById("imgSqrs169").src;

    value45Save169 = "zSqrArtSpecz169";

    localStorage.setItem(value45Save169, sQz169);
};

function square170(){

    var sQz170 = document.getElementById("imgSqrs170").src;

    value45Save170 = "zSqrArtSpecz170";

    localStorage.setItem(value45Save170, sQz170);
};

function square171(){

    var sQz171 = document.getElementById("imgSqrs171").src;

    value45Save171 = "zSqrArtSpecz171";

    localStorage.setItem(value45Save171, sQz171);
};

function square172(){

    var sQz172 = document.getElementById("imgSqrs172").src;

    value45Save172 = "zSqrArtSpecz172";

    localStorage.setItem(value45Save172, sQz172);
};

function square173(){

    var sQz173 = document.getElementById("imgSqrs173").src;

    value45Save173 = "zSqrArtSpecz173";

    localStorage.setItem(value45Save173, sQz173);
};

function square174(){

    var sQz174 = document.getElementById("imgSqrs174").src;

    value45Save174 = "zSqrArtSpecz174";

    localStorage.setItem(value45Save174, sQz174);
};

function square175(){

    var sQz175 = document.getElementById("imgSqrs175").src;

    value45Save175 = "zSqrArtSpecz175";

    localStorage.setItem(value45Save175, sQz175);
};

function square176(){

    var sQz176 = document.getElementById("imgSqrs176").src;

    value45Save176 = "zSqrArtSpecz176";

    localStorage.setItem(value45Save176, sQz176);
};

function square177(){

    var sQz177 = document.getElementById("imgSqrs177").src;

    value45Save177 = "zSqrArtSpecz177";

    localStorage.setItem(value45Save177, sQz177);
};

function square178(){

    var sQz178 = document.getElementById("imgSqrs178").src;

    value45Save178 = "zSqrArtSpecz178";

    localStorage.setItem(value45Save178, sQz178);
};

function square179(){

    var sQz179 = document.getElementById("imgSqrs179").src;

    value45Save179 = "zSqrArtSpecz179";

    localStorage.setItem(value45Save179, sQz179);
};

function square180(){

    var sQz180 = document.getElementById("imgSqrs180").src;

    value45Save180 = "zSqrArtSpecz180";

    localStorage.setItem(value45Save180, sQz180);
};

function square181(){

    var sQz181 = document.getElementById("imgSqrs181").src;

    value45Save181 = "zSqrArtSpecz181";

    localStorage.setItem(value45Save181, sQz181);
};

function square182(){

    var sQz182 = document.getElementById("imgSqrs182").src;

    value45Save182 = "zSqrArtSpecz182";

    localStorage.setItem(value45Save182, sQz182);
};

function square183(){

    var sQz183 = document.getElementById("imgSqrs183").src;

    value45Save183 = "zSqrArtSpecz183";

    localStorage.setItem(value45Save183, sQz183);
};

function square184(){

    var sQz184 = document.getElementById("imgSqrs184").src;

    value45Save184 = "zSqrArtSpecz184";

    localStorage.setItem(value45Save184, sQz184);
};

function square185(){

    var sQz185 = document.getElementById("imgSqrs185").src;

    value45Save185 = "zSqrArtSpecz185";

    localStorage.setItem(value45Save185, sQz185);
};

function square186(){

    var sQz186 = document.getElementById("imgSqrs186").src;

    value45Save186 = "zSqrArtSpecz186";

    localStorage.setItem(value45Save186, sQz186);
};

function square187(){

    var sQz187 = document.getElementById("imgSqrs187").src;

    value45Save187 = "zSqrArtSpecz187";

    localStorage.setItem(value45Save187, sQz187);
};

function square188(){

    var sQz188 = document.getElementById("imgSqrs188").src;

    value45Save188 = "zSqrArtSpecz188";

    localStorage.setItem(value45Save188, sQz188);
};

function square189(){

    var sQz189 = document.getElementById("imgSqrs189").src;

    value45Save189 = "zSqrArtSpecz189";

    localStorage.setItem(value45Save189, sQz189);
};

function square190(){

    var sQz190 = document.getElementById("imgSqrs190").src;

    value45Save190 = "zSqrArtSpecz190";

    localStorage.setItem(value45Save190, sQz190);
};

function square191(){

    var sQz191 = document.getElementById("imgSqrs191").src;

    value45Save191 = "zSqrArtSpecz191";

    localStorage.setItem(value45Save191, sQz191);
};

function square192(){

    var sQz192 = document.getElementById("imgSqrs192").src;

    value45Save192 = "zSqrArtSpecz192";

    localStorage.setItem(value45Save192, sQz192);
};

function square193(){

    var sQz193 = document.getElementById("imgSqrs193").src;

    value45Save193 = "zSqrArtSpecz193";

    localStorage.setItem(value45Save193, sQz193);
};

function square194(){

    var sQz194 = document.getElementById("imgSqrs194").src;

    value45Save194 = "zSqrArtSpecz194";

    localStorage.setItem(value45Save194, sQz194);
};

function square195(){

    var sQz195 = document.getElementById("imgSqrs195").src;

    value45Save195 = "zSqrArtSpecz195";

    localStorage.setItem(value45Save195, sQz195);
};

function square196(){

    var sQz196 = document.getElementById("imgSqrs196").src;

    value45Save196 = "zSqrArtSpecz196";

    localStorage.setItem(value45Save196, sQz196);
};

function square197(){

    var sQz197 = document.getElementById("imgSqrs197").src;

    value45Save197 = "zSqrArtSpecz197";

    localStorage.setItem(value45Save197, sQz197);
};

function square198(){

    var sQz198 = document.getElementById("imgSqrs198").src;

    value45Save198 = "zSqrArtSpecz198";

    localStorage.setItem(value45Save198, sQz198);
};

function square199(){

    var sQz199 = document.getElementById("imgSqrs199").src;

    value45Save199 = "zSqrArtSpecz199";

    localStorage.setItem(value45Save199, sQz199);
};

function square200(){

    var sQz200 = document.getElementById("imgSqrs200").src;

    value45Save200 = "zSqrArtSpecz200";

    localStorage.setItem(value45Save200, sQz200);
};

function square201(){

    var sQz201 = document.getElementById("imgSqrs201").src;

    value45Save201 = "zSqrArtSpecz201";

    localStorage.setItem(value45Save201, sQz201);
};

function square202(){

    var sQz202 = document.getElementById("imgSqrs202").src;

    value45Save202 = "zSqrArtSpecz202";

    localStorage.setItem(value45Save202, sQz202);
};

function square203(){

    var sQz203 = document.getElementById("imgSqrs203").src;

    value45Save203 = "zSqrArtSpecz203";

    localStorage.setItem(value45Save203, sQz203);
};

function square204(){

    var sQz204 = document.getElementById("imgSqrs204").src;

    value45Save204 = "zSqrArtSpecz204";

    localStorage.setItem(value45Save204, sQz204);
};

function square205(){

    var sQz205 = document.getElementById("imgSqrs205").src;

    value45Save205 = "zSqrArtSpecz205";

    localStorage.setItem(value45Save205, sQz205);
};

function square206(){

    var sQz206 = document.getElementById("imgSqrs206").src;

    value45Save206 = "zSqrArtSpecz206";

    localStorage.setItem(value45Save206, sQz206);
};

function square207(){

    var sQz207 = document.getElementById("imgSqrs207").src;

    value45Save207 = "zSqrArtSpecz207";

    localStorage.setItem(value45Save207, sQz207);
};

function square208(){

    var sQz208 = document.getElementById("imgSqrs208").src;

    value45Save208 = "zSqrArtSpecz208";

    localStorage.setItem(value45Save208, sQz208);
};

function square209(){

    var sQz209 = document.getElementById("imgSqrs209").src;

    value45Save209 = "zSqrArtSpecz209";

    localStorage.setItem(value45Save209, sQz209);
};

function square210(){

    var sQz210 = document.getElementById("imgSqrs210").src;

    value45Save210 = "zSqrArtSpecz210";

    localStorage.setItem(value45Save210, sQz210);
};

function square211(){

    var sQz211 = document.getElementById("imgSqrs211").src;

    value45Save211 = "zSqrArtSpecz211";

    localStorage.setItem(value45Save211, sQz211);
};

function square212(){

    var sQz212 = document.getElementById("imgSqrs212").src;

    value45Save212 = "zSqrArtSpecz212";

    localStorage.setItem(value45Save212, sQz212);
};

function square213(){

    var sQz213 = document.getElementById("imgSqrs213").src;

    value45Save213 = "zSqrArtSpecz213";

    localStorage.setItem(value45Save213, sQz213);
};

function square214(){

    var sQz214 = document.getElementById("imgSqrs214").src;

    value45Save214 = "zSqrArtSpecz214";

    localStorage.setItem(value45Save214, sQz214);
};

function square215(){

    var sQz215 = document.getElementById("imgSqrs215").src;

    value45Save215 = "zSqrArtSpecz215";

    localStorage.setItem(value45Save215, sQz215);
};

function square216(){

    var sQz216 = document.getElementById("imgSqrs216").src;

    value45Save216 = "zSqrArtSpecz216";

    localStorage.setItem(value45Save216, sQz216);
};

function square217(){

    var sQz217 = document.getElementById("imgSqrs217").src;

    value45Save217 = "zSqrArtSpecz217";

    localStorage.setItem(value45Save217, sQz217);
};

function square218(){

    var sQz218 = document.getElementById("imgSqrs218").src;

    value45Save218 = "zSqrArtSpecz218";

    localStorage.setItem(value45Save218, sQz218);
};

function square219(){

    var sQz219 = document.getElementById("imgSqrs219").src;

    value45Save219 = "zSqrArtSpecz219";

    localStorage.setItem(value45Save219, sQz219);
};

function square220(){

    var sQz220 = document.getElementById("imgSqrs220").src;

    value45Save220 = "zSqrArtSpecz220";

    localStorage.setItem(value45Save220, sQz220);
};

function square221(){

    var sQz221 = document.getElementById("imgSqrs221").src;

    value45Save221 = "zSqrArtSpecz221";

    localStorage.setItem(value45Save221, sQz221);
};

function square222(){

    var sQz222 = document.getElementById("imgSqrs222").src;

    value45Save222 = "zSqrArtSpecz222";

    localStorage.setItem(value45Save222, sQz222);
};

function square223(){

    var sQz223 = document.getElementById("imgSqrs223").src;

    value45Save223 = "zSqrArtSpecz223";

    localStorage.setItem(value45Save223, sQz223);
};

function square224(){

    var sQz224 = document.getElementById("imgSqrs224").src;

    value45Save224 = "zSqrArtSpecz224";

    localStorage.setItem(value45Save224, sQz224);
};

function square225(){

    var sQz225 = document.getElementById("imgSqrs225").src;

    value45Save225 = "zSqrArtSpecz225";

    localStorage.setItem(value45Save225, sQz225);
};

function square226(){

    var sQz226 = document.getElementById("imgSqrs226").src;

    value45Save226 = "zSqrArtSpecz226";

    localStorage.setItem(value45Save226, sQz226);
};

function square227(){

    var sQz227 = document.getElementById("imgSqrs227").src;

    value45Save227 = "zSqrArtSpecz227";

    localStorage.setItem(value45Save227, sQz227);
};

function square228(){

    var sQz228 = document.getElementById("imgSqrs228").src;

    value45Save228 = "zSqrArtSpecz228";

    localStorage.setItem(value45Save228, sQz228);
};

function square229(){

    var sQz229 = document.getElementById("imgSqrs229").src;

    value45Save229 = "zSqrArtSpecz229";

    localStorage.setItem(value45Save229, sQz229);
};

function square230(){

    var sQz230 = document.getElementById("imgSqrs230").src;

    value45Save230 = "zSqrArtSpecz230";

    localStorage.setItem(value45Save230, sQz230);
};

function square231(){

    var sQz231 = document.getElementById("imgSqrs231").src;

    value45Save231 = "zSqrArtSpecz231";

    localStorage.setItem(value45Save231, sQz231);
};

function square232(){

    var sQz232 = document.getElementById("imgSqrs232").src;

    value45Save232 = "zSqrArtSpecz232";

    localStorage.setItem(value45Save232, sQz232);
};

function square233(){

    var sQz233 = document.getElementById("imgSqrs233").src;

    value45Save233 = "zSqrArtSpecz233";

    localStorage.setItem(value45Save233, sQz233);
};

function square234(){

    var sQz234 = document.getElementById("imgSqrs234").src;

    value45Save234 = "zSqrArtSpecz234";

    localStorage.setItem(value45Save234, sQz234);
};

function square235(){

    var sQz235 = document.getElementById("imgSqrs235").src;

    value45Save235 = "zSqrArtSpecz235";

    localStorage.setItem(value45Save235, sQz235);
};

function square236(){

    var sQz236 = document.getElementById("imgSqrs236").src;

    value45Save236 = "zSqrArtSpecz236";

    localStorage.setItem(value45Save236, sQz236);
};

function square237(){

    var sQz237 = document.getElementById("imgSqrs237").src;

    value45Save237 = "zSqrArtSpecz237";

    localStorage.setItem(value45Save237, sQz237);
};

function square238(){

    var sQz238 = document.getElementById("imgSqrs238").src;

    value45Save238 = "zSqrArtSpecz238";

    localStorage.setItem(value45Save238, sQz238);
};

function square239(){

    var sQz239 = document.getElementById("imgSqrs239").src;

    value45Save239 = "zSqrArtSpecz239";

    localStorage.setItem(value45Save239, sQz239);
};

function square240(){

    var sQz240 = document.getElementById("imgSqrs240").src;

    value45Save240 = "zSqrArtSpecz240";

    localStorage.setItem(value45Save240, sQz240);
};

function square241(){

    var sQz241 = document.getElementById("imgSqrs241").src;

    value45Save241 = "zSqrArtSpecz241";

    localStorage.setItem(value45Save241, sQz241);
};

function square242(){

    var sQz242 = document.getElementById("imgSqrs242").src;

    value45Save242 = "zSqrArtSpecz242";

    localStorage.setItem(value45Save242, sQz242);
};

function square243(){

    var sQz243 = document.getElementById("imgSqrs243").src;

    value45Save243 = "zSqrArtSpecz243";

    localStorage.setItem(value45Save243, sQz243);
};

function square244(){

    var sQz244 = document.getElementById("imgSqrs244").src;

    value45Save244 = "zSqrArtSpecz244";

    localStorage.setItem(value45Save244, sQz244);
};

function square245(){

    var sQz245 = document.getElementById("imgSqrs245").src;

    value45Save245 = "zSqrArtSpecz245";

    localStorage.setItem(value45Save245, sQz245);
};

function square246(){

    var sQz246 = document.getElementById("imgSqrs246").src;

    value45Save246 = "zSqrArtSpecz246";

    localStorage.setItem(value45Save246, sQz246);
};

function square247(){

    var sQz247 = document.getElementById("imgSqrs247").src;

    value45Save247 = "zSqrArtSpecz247";

    localStorage.setItem(value45Save247, sQz247);
};

function square248(){

    var sQz248 = document.getElementById("imgSqrs248").src;

    value45Save248 = "zSqrArtSpecz248";

    localStorage.setItem(value45Save248, sQz248);
};

function square249(){

    var sQz249 = document.getElementById("imgSqrs249").src;

    value45Save249 = "zSqrArtSpecz249";

    localStorage.setItem(value45Save249, sQz249);
};

function square250(){

    var sQz250 = document.getElementById("imgSqrs250").src;

    value45Save250 = "zSqrArtSpecz250";

    localStorage.setItem(value45Save250, sQz250);
};

function square251(){

    var sQz251 = document.getElementById("imgSqrs251").src;

    value45Save251 = "zSqrArtSpecz251";

    localStorage.setItem(value45Save251, sQz251);
};

function square252(){

    var sQz252 = document.getElementById("imgSqrs252").src;

    value45Save252 = "zSqrArtSpecz252";

    localStorage.setItem(value45Save252, sQz252);
};

function square253(){

    var sQz253 = document.getElementById("imgSqrs253").src;

    value45Save253 = "zSqrArtSpecz253";

    localStorage.setItem(value45Save253, sQz253);
};

function square254(){

    var sQz254 = document.getElementById("imgSqrs254").src;

    value45Save254 = "zSqrArtSpecz254";

    localStorage.setItem(value45Save254, sQz254);
};

function square255(){

    var sQz255 = document.getElementById("imgSqrs255").src;

    value45Save255 = "zSqrArtSpecz255";

    localStorage.setItem(value45Save255, sQz255);
};

function square256(){

    var sQz256 = document.getElementById("imgSqrs256").src;

    value45Save256 = "zSqrArtSpecz256";

    localStorage.setItem(value45Save256, sQz256);
};

function square257(){

    var sQz257 = document.getElementById("imgSqrs257").src;

    value45Save257 = "zSqrArtSpecz257";

    localStorage.setItem(value45Save257, sQz257);
};

function square258(){

    var sQz258 = document.getElementById("imgSqrs258").src;

    value45Save258 = "zSqrArtSpecz258";

    localStorage.setItem(value45Save258, sQz258);
};

function square259(){

    var sQz259 = document.getElementById("imgSqrs259").src;

    value45Save259 = "zSqrArtSpecz259";

    localStorage.setItem(value45Save259, sQz259);
};

function square260(){

    var sQz260 = document.getElementById("imgSqrs260").src;

    value45Save260 = "zSqrArtSpecz260";

    localStorage.setItem(value45Save260, sQz260);
};

function square261(){

    var sQz261 = document.getElementById("imgSqrs261").src;

    value45Save261 = "zSqrArtSpecz261";

    localStorage.setItem(value45Save261, sQz261);
};

function square262(){

    var sQz262 = document.getElementById("imgSqrs262").src;

    value45Save262 = "zSqrArtSpecz262";

    localStorage.setItem(value45Save262, sQz262);
};

function square263(){

    var sQz263 = document.getElementById("imgSqrs263").src;

    value45Save263 = "zSqrArtSpecz263";

    localStorage.setItem(value45Save263, sQz263);
};

function square264(){

    var sQz264 = document.getElementById("imgSqrs264").src;

    value45Save264 = "zSqrArtSpecz264";

    localStorage.setItem(value45Save264, sQz264);
};

function square265(){

    var sQz265 = document.getElementById("imgSqrs265").src;

    value45Save265 = "zSqrArtSpecz265";

    localStorage.setItem(value45Save265, sQz265);
};

function square266(){

    var sQz266 = document.getElementById("imgSqrs266").src;

    value45Save266 = "zSqrArtSpecz266";

    localStorage.setItem(value45Save266, sQz266);
};

function square267(){

    var sQz267 = document.getElementById("imgSqrs267").src;

    value45Save267 = "zSqrArtSpecz267";

    localStorage.setItem(value45Save267, sQz267);
};

function square268(){

    var sQz268 = document.getElementById("imgSqrs268").src;

    value45Save268 = "zSqrArtSpecz268";

    localStorage.setItem(value45Save268, sQz268);
};

function square269(){

    var sQz269 = document.getElementById("imgSqrs269").src;

    value45Save269 = "zSqrArtSpecz269";

    localStorage.setItem(value45Save269, sQz269);
};

function square270(){

    var sQz270 = document.getElementById("imgSqrs270").src;

    value45Save270 = "zSqrArtSpecz270";

    localStorage.setItem(value45Save270, sQz270);
};

function square271(){

    var sQz271 = document.getElementById("imgSqrs271").src;

    value45Save271 = "zSqrArtSpecz271";

    localStorage.setItem(value45Save271, sQz271);
};

function square272(){

    var sQz272 = document.getElementById("imgSqrs272").src;

    value45Save272 = "zSqrArtSpecz272";

    localStorage.setItem(value45Save272, sQz272);
};

function square273(){

    var sQz273 = document.getElementById("imgSqrs273").src;

    value45Save273 = "zSqrArtSpecz273";

    localStorage.setItem(value45Save273, sQz273);
};

function square274(){

    var sQz274 = document.getElementById("imgSqrs274").src;

    value45Save274 = "zSqrArtSpecz274";

    localStorage.setItem(value45Save274, sQz274);
};

function square275(){

    var sQz275 = document.getElementById("imgSqrs275").src;

    value45Save275 = "zSqrArtSpecz275";

    localStorage.setItem(value45Save275, sQz275);
};

function square276(){

    var sQz276 = document.getElementById("imgSqrs276").src;

    value45Save276 = "zSqrArtSpecz276";

    localStorage.setItem(value45Save276, sQz276);
};

function square277(){

    var sQz277 = document.getElementById("imgSqrs277").src;

    value45Save277 = "zSqrArtSpecz277";

    localStorage.setItem(value45Save277, sQz277);
};

function square278(){

    var sQz278 = document.getElementById("imgSqrs278").src;

    value45Save278 = "zSqrArtSpecz278";

    localStorage.setItem(value45Save278, sQz278);
};

function square279(){

    var sQz279 = document.getElementById("imgSqrs279").src;

    value45Save279 = "zSqrArtSpecz279";

    localStorage.setItem(value45Save279, sQz279);
};

function square280(){

    var sQz280 = document.getElementById("imgSqrs280").src;

    value45Save280 = "zSqrArtSpecz280";

    localStorage.setItem(value45Save280, sQz280);
};

function square281(){

    var sQz281 = document.getElementById("imgSqrs281").src;

    value45Save281 = "zSqrArtSpecz281";

    localStorage.setItem(value45Save281, sQz281);
};

function square282(){

    var sQz282 = document.getElementById("imgSqrs282").src;

    value45Save282 = "zSqrArtSpecz282";

    localStorage.setItem(value45Save282, sQz282);
};

function square283(){

    var sQz283 = document.getElementById("imgSqrs283").src;

    value45Save283 = "zSqrArtSpecz283";

    localStorage.setItem(value45Save283, sQz283);
};

function square284(){

    var sQz284 = document.getElementById("imgSqrs284").src;

    value45Save284 = "zSqrArtSpecz284";

    localStorage.setItem(value45Save284, sQz284);
};

function square285(){

    var sQz285 = document.getElementById("imgSqrs285").src;

    value45Save285 = "zSqrArtSpecz285";

    localStorage.setItem(value45Save285, sQz285);
};

function square286(){

    var sQz286 = document.getElementById("imgSqrs286").src;

    value45Save286 = "zSqrArtSpecz286";

    localStorage.setItem(value45Save286, sQz286);
};

function square287(){

    var sQz287 = document.getElementById("imgSqrs287").src;

    value45Save287 = "zSqrArtSpecz287";

    localStorage.setItem(value45Save287, sQz287);
};

function square288(){

    var sQz288 = document.getElementById("imgSqrs288").src;

    value45Save288 = "zSqrArtSpecz288";

    localStorage.setItem(value45Save288, sQz288);
};

function square289(){

    var sQz289 = document.getElementById("imgSqrs289").src;

    value45Save289 = "zSqrArtSpecz289";

    localStorage.setItem(value45Save289, sQz289);
};

function square290(){

    var sQz290 = document.getElementById("imgSqrs290").src;

    value45Save290 = "zSqrArtSpecz290";

    localStorage.setItem(value45Save290, sQz290);
};

function square291(){

    var sQz291 = document.getElementById("imgSqrs291").src;

    value45Save291 = "zSqrArtSpecz291";

    localStorage.setItem(value45Save291, sQz291);
};

function square292(){

    var sQz292 = document.getElementById("imgSqrs292").src;

    value45Save292 = "zSqrArtSpecz292";

    localStorage.setItem(value45Save292, sQz292);
};

function square293(){

    var sQz293 = document.getElementById("imgSqrs293").src;

    value45Save293 = "zSqrArtSpecz293";

    localStorage.setItem(value45Save293, sQz293);
};

function square294(){

    var sQz294 = document.getElementById("imgSqrs294").src;

    value45Save294 = "zSqrArtSpecz294";

    localStorage.setItem(value45Save294, sQz294);
};

function square295(){

    var sQz295 = document.getElementById("imgSqrs295").src;

    value45Save295 = "zSqrArtSpecz295";

    localStorage.setItem(value45Save295, sQz295);
};

function square296(){

    var sQz296 = document.getElementById("imgSqrs296").src;

    value45Save296 = "zSqrArtSpecz296";

    localStorage.setItem(value45Save296, sQz296);
};

function square297(){

    var sQz297 = document.getElementById("imgSqrs297").src;

    value45Save297 = "zSqrArtSpecz297";

    localStorage.setItem(value45Save297, sQz297);
};

function square298(){

    var sQz298 = document.getElementById("imgSqrs298").src;

    value45Save298 = "zSqrArtSpecz298";

    localStorage.setItem(value45Save298, sQz298);
};

function square299(){

    var sQz299 = document.getElementById("imgSqrs299").src;

    value45Save299 = "zSqrArtSpecz299";

    localStorage.setItem(value45Save299, sQz299);
};

function square300(){

    var sQz300 = document.getElementById("imgSqrs300").src;

    value45Save300 = "zSqrArtSpecz300";

    localStorage.setItem(value45Save300, sQz300);
};

function square301(){

    var sQz301 = document.getElementById("imgSqrs301").src;

    value45Save301 = "zSqrArtSpecz301";

    localStorage.setItem(value45Save301, sQz301);
};

function square302(){

    var sQz302 = document.getElementById("imgSqrs302").src;

    value45Save302 = "zSqrArtSpecz302";

    localStorage.setItem(value45Save302, sQz302);
};

function square303(){

    var sQz303 = document.getElementById("imgSqrs303").src;

    value45Save303 = "zSqrArtSpecz303";

    localStorage.setItem(value45Save303, sQz303);
};

function square304(){

    var sQz304 = document.getElementById("imgSqrs304").src;

    value45Save304 = "zSqrArtSpecz304";

    localStorage.setItem(value45Save304, sQz304);
};

function square305(){

    var sQz305 = document.getElementById("imgSqrs305").src;

    value45Save305 = "zSqrArtSpecz305";

    localStorage.setItem(value45Save305, sQz305);
};

function square306(){

    var sQz306 = document.getElementById("imgSqrs306").src;

    value45Save306 = "zSqrArtSpecz306";

    localStorage.setItem(value45Save306, sQz306);
};

function square307(){

    var sQz307 = document.getElementById("imgSqrs307").src;

    value45Save307 = "zSqrArtSpecz307";

    localStorage.setItem(value45Save307, sQz307);
};

function square308(){

    var sQz308 = document.getElementById("imgSqrs308").src;

    value45Save308 = "zSqrArtSpecz308";

    localStorage.setItem(value45Save308, sQz308);
};

function square309(){

    var sQz309 = document.getElementById("imgSqrs309").src;

    value45Save309 = "zSqrArtSpecz309";

    localStorage.setItem(value45Save309, sQz309);
};

function square310(){

    var sQz310 = document.getElementById("imgSqrs310").src;

    value45Save310 = "zSqrArtSpecz310";

    localStorage.setItem(value45Save310, sQz310);
};

function square311(){

    var sQz311 = document.getElementById("imgSqrs311").src;

    value45Save311 = "zSqrArtSpecz311";

    localStorage.setItem(value45Save311, sQz311);
};

function square312(){

    var sQz312 = document.getElementById("imgSqrs312").src;

    value45Save312 = "zSqrArtSpecz312";

    localStorage.setItem(value45Save312, sQz312);
};

function square313(){

    var sQz313 = document.getElementById("imgSqrs313").src;

    value45Save313 = "zSqrArtSpecz313";

    localStorage.setItem(value45Save313, sQz313);
};

function square314(){

    var sQz314 = document.getElementById("imgSqrs314").src;

    value45Save314 = "zSqrArtSpecz314";

    localStorage.setItem(value45Save314, sQz314);
};

function square315(){

    var sQz315 = document.getElementById("imgSqrs315").src;

    value45Save315 = "zSqrArtSpecz315";

    localStorage.setItem(value45Save315, sQz315);
};

function square316(){

    var sQz316 = document.getElementById("imgSqrs316").src;

    value45Save316 = "zSqrArtSpecz316";

    localStorage.setItem(value45Save316, sQz316);
};

function square317(){

    var sQz317 = document.getElementById("imgSqrs317").src;

    value45Save317 = "zSqrArtSpecz317";

    localStorage.setItem(value45Save317, sQz317);
};

function square318(){

    var sQz318 = document.getElementById("imgSqrs318").src;

    value45Save318 = "zSqrArtSpecz318";

    localStorage.setItem(value45Save318, sQz318);
};

function square319(){

    var sQz319 = document.getElementById("imgSqrs319").src;

    value45Save319 = "zSqrArtSpecz319";

    localStorage.setItem(value45Save319, sQz319);
};

function square320(){

    var sQz320 = document.getElementById("imgSqrs320").src;

    value45Save320 = "zSqrArtSpecz320";

    localStorage.setItem(value45Save320, sQz320);
};

function square321(){

    var sQz321 = document.getElementById("imgSqrs321").src;

    value45Save321 = "zSqrArtSpecz321";

    localStorage.setItem(value45Save321, sQz321);
};

function square322(){

    var sQz322 = document.getElementById("imgSqrs322").src;

    value45Save322 = "zSqrArtSpecz322";

    localStorage.setItem(value45Save322, sQz322);
};

function square323(){

    var sQz323 = document.getElementById("imgSqrs323").src;

    value45Save323 = "zSqrArtSpecz323";

    localStorage.setItem(value45Save323, sQz323);
};

function square324(){

    var sQz324 = document.getElementById("imgSqrs324").src;

    value45Save324 = "zSqrArtSpecz324";

    localStorage.setItem(value45Save324, sQz324);
};

function square325(){

    var sQz325 = document.getElementById("imgSqrs325").src;

    value45Save325 = "zSqrArtSpecz325";

    localStorage.setItem(value45Save325, sQz325);
};

function square326(){

    var sQz326 = document.getElementById("imgSqrs326").src;

    value45Save326 = "zSqrArtSpecz326";

    localStorage.setItem(value45Save326, sQz326);
};

function square327(){

    var sQz327 = document.getElementById("imgSqrs327").src;

    value45Save327 = "zSqrArtSpecz327";

    localStorage.setItem(value45Save327, sQz327);
};

function square328(){

    var sQz328 = document.getElementById("imgSqrs328").src;

    value45Save328 = "zSqrArtSpecz328";

    localStorage.setItem(value45Save328, sQz328);
};

function square329(){

    var sQz329 = document.getElementById("imgSqrs329").src;

    value45Save329 = "zSqrArtSpecz329";

    localStorage.setItem(value45Save329, sQz329);
};

function square330(){

    var sQz330 = document.getElementById("imgSqrs330").src;

    value45Save330 = "zSqrArtSpecz330";

    localStorage.setItem(value45Save330, sQz330);
};

function square331(){

    var sQz331 = document.getElementById("imgSqrs331").src;

    value45Save331 = "zSqrArtSpecz331";

    localStorage.setItem(value45Save331, sQz331);
};

function square332(){

    var sQz332 = document.getElementById("imgSqrs332").src;

    value45Save332 = "zSqrArtSpecz332";

    localStorage.setItem(value45Save332, sQz332);
};

function square333(){

    var sQz333 = document.getElementById("imgSqrs333").src;

    value45Save333 = "zSqrArtSpecz333";

    localStorage.setItem(value45Save333, sQz333);
};

function square334(){

    var sQz334 = document.getElementById("imgSqrs334").src;

    value45Save334 = "zSqrArtSpecz334";

    localStorage.setItem(value45Save334, sQz334);
};

function square335(){

    var sQz335 = document.getElementById("imgSqrs335").src;

    value45Save335 = "zSqrArtSpecz335";

    localStorage.setItem(value45Save335, sQz335);
};

function square336(){

    var sQz336 = document.getElementById("imgSqrs336").src;

    value45Save336 = "zSqrArtSpecz336";

    localStorage.setItem(value45Save336, sQz336);
};

function square337(){

    var sQz337 = document.getElementById("imgSqrs337").src;

    value45Save337 = "zSqrArtSpecz337";

    localStorage.setItem(value45Save337, sQz337);
};

function square338(){

    var sQz338 = document.getElementById("imgSqrs338").src;

    value45Save338 = "zSqrArtSpecz338";

    localStorage.setItem(value45Save338, sQz338);
};

function square339(){

    var sQz339 = document.getElementById("imgSqrs339").src;

    value45Save339 = "zSqrArtSpecz339";

    localStorage.setItem(value45Save339, sQz339);
};

function square340(){

    var sQz340 = document.getElementById("imgSqrs340").src;

    value45Save340 = "zSqrArtSpecz340";

    localStorage.setItem(value45Save340, sQz340);
};

function square341(){

    var sQz341 = document.getElementById("imgSqrs341").src;

    value45Save341 = "zSqrArtSpecz341";

    localStorage.setItem(value45Save341, sQz341);
};

function square342(){

    var sQz342 = document.getElementById("imgSqrs342").src;

    value45Save342 = "zSqrArtSpecz342";

    localStorage.setItem(value45Save342, sQz342);
};

function square343(){

    var sQz343 = document.getElementById("imgSqrs343").src;

    value45Save343 = "zSqrArtSpecz343";

    localStorage.setItem(value45Save343, sQz343);
};

function square344(){

    var sQz344 = document.getElementById("imgSqrs344").src;

    value45Save344 = "zSqrArtSpecz344";

    localStorage.setItem(value45Save344, sQz344);
};

function square345(){

    var sQz345 = document.getElementById("imgSqrs345").src;

    value45Save345 = "zSqrArtSpecz345";

    localStorage.setItem(value45Save345, sQz345);
};

function square346(){

    var sQz346 = document.getElementById("imgSqrs346").src;

    value45Save346 = "zSqrArtSpecz346";

    localStorage.setItem(value45Save346, sQz346);
};

function square347(){

    var sQz347 = document.getElementById("imgSqrs347").src;

    value45Save347 = "zSqrArtSpecz347";

    localStorage.setItem(value45Save347, sQz347);
};

function square348(){

    var sQz348 = document.getElementById("imgSqrs348").src;

    value45Save348 = "zSqrArtSpecz348";

    localStorage.setItem(value45Save348, sQz348);
};

function square349(){

    var sQz349 = document.getElementById("imgSqrs349").src;

    value45Save349 = "zSqrArtSpecz349";

    localStorage.setItem(value45Save349, sQz349);
};

function square350(){

    var sQz350 = document.getElementById("imgSqrs350").src;

    value45Save350 = "zSqrArtSpecz350";

    localStorage.setItem(value45Save350, sQz350);
};

function square351(){

    var sQz351 = document.getElementById("imgSqrs351").src;

    value45Save351 = "zSqrArtSpecz351";

    localStorage.setItem(value45Save351, sQz351);
};

function square352(){

    var sQz352 = document.getElementById("imgSqrs352").src;

    value45Save352 = "zSqrArtSpecz352";

    localStorage.setItem(value45Save352, sQz352);
};

function square353(){

    var sQz353 = document.getElementById("imgSqrs353").src;

    value45Save353 = "zSqrArtSpecz353";

    localStorage.setItem(value45Save353, sQz353);
};

function square354(){

    var sQz354 = document.getElementById("imgSqrs354").src;

    value45Save354 = "zSqrArtSpecz354";

    localStorage.setItem(value45Save354, sQz354);
};

function square355(){

    var sQz355 = document.getElementById("imgSqrs355").src;

    value45Save355 = "zSqrArtSpecz355";

    localStorage.setItem(value45Save355, sQz355);
};

function square356(){

    var sQz356 = document.getElementById("imgSqrs356").src;

    value45Save356 = "zSqrArtSpecz356";

    localStorage.setItem(value45Save356, sQz356);
};

function square357(){

    var sQz357 = document.getElementById("imgSqrs357").src;

    value45Save357 = "zSqrArtSpecz357";

    localStorage.setItem(value45Save357, sQz357);
};

function square358(){

    var sQz358 = document.getElementById("imgSqrs358").src;

    value45Save358 = "zSqrArtSpecz358";

    localStorage.setItem(value45Save358, sQz358);
};

function square359(){

    var sQz359 = document.getElementById("imgSqrs359").src;

    value45Save359 = "zSqrArtSpecz359";

    localStorage.setItem(value45Save359, sQz359);
};

function square360(){

    var sQz360 = document.getElementById("imgSqrs360").src;

    value45Save360 = "zSqrArtSpecz360";

    localStorage.setItem(value45Save360, sQz360);
};

function square361(){

    var sQz361 = document.getElementById("imgSqrs361").src;

    value45Save361 = "zSqrArtSpecz361";

    localStorage.setItem(value45Save361, sQz361);
};

function square362(){

    var sQz362 = document.getElementById("imgSqrs362").src;

    value45Save362 = "zSqrArtSpecz362";

    localStorage.setItem(value45Save362, sQz362);
};

function square363(){

    var sQz363 = document.getElementById("imgSqrs363").src;

    value45Save363 = "zSqrArtSpecz363";

    localStorage.setItem(value45Save363, sQz363);
};

function square364(){

    var sQz364 = document.getElementById("imgSqrs364").src;

    value45Save364 = "zSqrArtSpecz364";

    localStorage.setItem(value45Save364, sQz364);
};

function square365(){

    var sQz365 = document.getElementById("imgSqrs365").src;

    value45Save365 = "zSqrArtSpecz365";

    localStorage.setItem(value45Save365, sQz365);
};

function square366(){

    var sQz366 = document.getElementById("imgSqrs366").src;

    value45Save366 = "zSqrArtSpecz366";

    localStorage.setItem(value45Save366, sQz366);
};

function square367(){

    var sQz367 = document.getElementById("imgSqrs367").src;

    value45Save367 = "zSqrArtSpecz367";

    localStorage.setItem(value45Save367, sQz367);
};

function square368(){

    var sQz368 = document.getElementById("imgSqrs368").src;

    value45Save368 = "zSqrArtSpecz368";

    localStorage.setItem(value45Save368, sQz368);
};

function square369(){

    var sQz369 = document.getElementById("imgSqrs369").src;

    value45Save369 = "zSqrArtSpecz369";

    localStorage.setItem(value45Save369, sQz369);
};

function square370(){

    var sQz370 = document.getElementById("imgSqrs370").src;

    value45Save370 = "zSqrArtSpecz370";

    localStorage.setItem(value45Save370, sQz370);
};

function square371(){

    var sQz371 = document.getElementById("imgSqrs371").src;

    value45Save371 = "zSqrArtSpecz371";

    localStorage.setItem(value45Save371, sQz371);
};

function square372(){

    var sQz372 = document.getElementById("imgSqrs372").src;

    value45Save372 = "zSqrArtSpecz372";

    localStorage.setItem(value45Save372, sQz372);
};

function square373(){

    var sQz373 = document.getElementById("imgSqrs373").src;

    value45Save373 = "zSqrArtSpecz373";

    localStorage.setItem(value45Save373, sQz373);
};

function square374(){

    var sQz374 = document.getElementById("imgSqrs374").src;

    value45Save374 = "zSqrArtSpecz374";

    localStorage.setItem(value45Save374, sQz374);
};

function square375(){

    var sQz375 = document.getElementById("imgSqrs375").src;

    value45Save375 = "zSqrArtSpecz375";

    localStorage.setItem(value45Save375, sQz375);
};

function square376(){

    var sQz376 = document.getElementById("imgSqrs376").src;

    value45Save376 = "zSqrArtSpecz376";

    localStorage.setItem(value45Save376, sQz376);
};

function square377(){

    var sQz377 = document.getElementById("imgSqrs377").src;

    value45Save377 = "zSqrArtSpecz377";

    localStorage.setItem(value45Save377, sQz377);
};

function square378(){

    var sQz378 = document.getElementById("imgSqrs378").src;

    value45Save378 = "zSqrArtSpecz378";

    localStorage.setItem(value45Save378, sQz378);
};

function square379(){

    var sQz379 = document.getElementById("imgSqrs379").src;

    value45Save379 = "zSqrArtSpecz379";

    localStorage.setItem(value45Save379, sQz379);
};

function square380(){

    var sQz380 = document.getElementById("imgSqrs380").src;

    value45Save380 = "zSqrArtSpecz380";

    localStorage.setItem(value45Save380, sQz380);
};

function square381(){

    var sQz381 = document.getElementById("imgSqrs381").src;

    value45Save381 = "zSqrArtSpecz381";

    localStorage.setItem(value45Save381, sQz381);
};

function square382(){

    var sQz382 = document.getElementById("imgSqrs382").src;

    value45Save382 = "zSqrArtSpecz382";

    localStorage.setItem(value45Save382, sQz382);
};

function square383(){

    var sQz383 = document.getElementById("imgSqrs383").src;

    value45Save383 = "zSqrArtSpecz383";

    localStorage.setItem(value45Save383, sQz383);
};

function square384(){

    var sQz384 = document.getElementById("imgSqrs384").src;

    value45Save384 = "zSqrArtSpecz384";

    localStorage.setItem(value45Save384, sQz384);
};

function square385(){

    var sQz385 = document.getElementById("imgSqrs385").src;

    value45Save385 = "zSqrArtSpecz385";

    localStorage.setItem(value45Save385, sQz385);
};

function square386(){

    var sQz386 = document.getElementById("imgSqrs386").src;

    value45Save386 = "zSqrArtSpecz386";

    localStorage.setItem(value45Save386, sQz386);
};

function square387(){

    var sQz387 = document.getElementById("imgSqrs387").src;

    value45Save387 = "zSqrArtSpecz387";

    localStorage.setItem(value45Save387, sQz387);
};

function square388(){

    var sQz388 = document.getElementById("imgSqrs388").src;

    value45Save388 = "zSqrArtSpecz388";

    localStorage.setItem(value45Save388, sQz388);
};

function square389(){

    var sQz389 = document.getElementById("imgSqrs389").src;

    value45Save389 = "zSqrArtSpecz389";

    localStorage.setItem(value45Save389, sQz389);
};

function square390(){

    var sQz390 = document.getElementById("imgSqrs390").src;

    value45Save390 = "zSqrArtSpecz390";

    localStorage.setItem(value45Save390, sQz390);
};

function square391(){

    var sQz391 = document.getElementById("imgSqrs391").src;

    value45Save391 = "zSqrArtSpecz391";

    localStorage.setItem(value45Save391, sQz391);
};

function square392(){

    var sQz392 = document.getElementById("imgSqrs392").src;

    value45Save392 = "zSqrArtSpecz392";

    localStorage.setItem(value45Save392, sQz392);
};

function square393(){

    var sQz393 = document.getElementById("imgSqrs393").src;

    value45Save393 = "zSqrArtSpecz393";

    localStorage.setItem(value45Save393, sQz393);
};

function square394(){

    var sQz394 = document.getElementById("imgSqrs394").src;

    value45Save394 = "zSqrArtSpecz394";

    localStorage.setItem(value45Save394, sQz394);
};

function square395(){

    var sQz395 = document.getElementById("imgSqrs395").src;

    value45Save395 = "zSqrArtSpecz395";

    localStorage.setItem(value45Save395, sQz395);
};

function square396(){

    var sQz396 = document.getElementById("imgSqrs396").src;

    value45Save396 = "zSqrArtSpecz396";

    localStorage.setItem(value45Save396, sQz396);
};

function square397(){

    var sQz397 = document.getElementById("imgSqrs397").src;

    value45Save397 = "zSqrArtSpecz397";

    localStorage.setItem(value45Save397, sQz397);
};

function square398(){

    var sQz398 = document.getElementById("imgSqrs398").src;

    value45Save398 = "zSqrArtSpecz398";

    localStorage.setItem(value45Save398, sQz398);
};

function square399(){

    var sQz399 = document.getElementById("imgSqrs399").src;

    value45Save399 = "zSqrArtSpecz399";

    localStorage.setItem(value45Save399, sQz399);
};

function square400(){

    var sQz400 = document.getElementById("imgSqrs400").src;

    value45Save400 = "zSqrArtSpecz400";

    localStorage.setItem(value45Save400, sQz400);
};

function square401(){

    var sQz401 = document.getElementById("imgSqrs401").src;

    value45Save401 = "zSqrArtSpecz401";

    localStorage.setItem(value45Save401, sQz401);
};

function square402(){

    var sQz402 = document.getElementById("imgSqrs402").src;

    value45Save402 = "zSqrArtSpecz402";

    localStorage.setItem(value45Save402, sQz402);
};

function square403(){

    var sQz403 = document.getElementById("imgSqrs403").src;

    value45Save403 = "zSqrArtSpecz403";

    localStorage.setItem(value45Save403, sQz403);
};

function square404(){

    var sQz404 = document.getElementById("imgSqrs404").src;

    value45Save404 = "zSqrArtSpecz404";

    localStorage.setItem(value45Save404, sQz404);
};

function square405(){

    var sQz405 = document.getElementById("imgSqrs405").src;

    value45Save405 = "zSqrArtSpecz405";

    localStorage.setItem(value45Save405, sQz405);
};

function square406(){

    var sQz406 = document.getElementById("imgSqrs406").src;

    value45Save406 = "zSqrArtSpecz406";

    localStorage.setItem(value45Save406, sQz406);
};

function square407(){

    var sQz407 = document.getElementById("imgSqrs407").src;

    value45Save407 = "zSqrArtSpecz407";

    localStorage.setItem(value45Save407, sQz407);
};

function square408(){

    var sQz408 = document.getElementById("imgSqrs408").src;

    value45Save408 = "zSqrArtSpecz408";

    localStorage.setItem(value45Save408, sQz408);
};

function square409(){

    var sQz409 = document.getElementById("imgSqrs409").src;

    value45Save409 = "zSqrArtSpecz409";

    localStorage.setItem(value45Save409, sQz409);
};

function square410(){

    var sQz410 = document.getElementById("imgSqrs410").src;

    value45Save410 = "zSqrArtSpecz410";

    localStorage.setItem(value45Save410, sQz410);
};

function square411(){

    var sQz411 = document.getElementById("imgSqrs411").src;

    value45Save411 = "zSqrArtSpecz411";

    localStorage.setItem(value45Save411, sQz411);
};

function square412(){

    var sQz412 = document.getElementById("imgSqrs412").src;

    value45Save412 = "zSqrArtSpecz412";

    localStorage.setItem(value45Save412, sQz412);
};

function square413(){

    var sQz413 = document.getElementById("imgSqrs413").src;

    value45Save413 = "zSqrArtSpecz413";

    localStorage.setItem(value45Save413, sQz413);
};

function square414(){

    var sQz414 = document.getElementById("imgSqrs414").src;

    value45Save414 = "zSqrArtSpecz414";

    localStorage.setItem(value45Save414, sQz414);
};

function square415(){

    var sQz415 = document.getElementById("imgSqrs415").src;

    value45Save415 = "zSqrArtSpecz415";

    localStorage.setItem(value45Save415, sQz415);
};

function square416(){

    var sQz416 = document.getElementById("imgSqrs416").src;

    value45Save416 = "zSqrArtSpecz416";

    localStorage.setItem(value45Save416, sQz416);
};

function square417(){

    var sQz417 = document.getElementById("imgSqrs417").src;

    value45Save417 = "zSqrArtSpecz417";

    localStorage.setItem(value45Save417, sQz417);
};

function square418(){

    var sQz418 = document.getElementById("imgSqrs418").src;

    value45Save418 = "zSqrArtSpecz418";

    localStorage.setItem(value45Save418, sQz418);
};

function square419(){

    var sQz419 = document.getElementById("imgSqrs419").src;

    value45Save419 = "zSqrArtSpecz419";

    localStorage.setItem(value45Save419, sQz419);
};

function square420(){

    var sQz420 = document.getElementById("imgSqrs420").src;

    value45Save420 = "zSqrArtSpecz420";

    localStorage.setItem(value45Save420, sQz420);
};

function square421(){

    var sQz421 = document.getElementById("imgSqrs421").src;

    value45Save421 = "zSqrArtSpecz421";

    localStorage.setItem(value45Save421, sQz421);
};

function square422(){

    var sQz422 = document.getElementById("imgSqrs422").src;

    value45Save422 = "zSqrArtSpecz422";

    localStorage.setItem(value45Save422, sQz422);
};

function square423(){

    var sQz423 = document.getElementById("imgSqrs423").src;

    value45Save423 = "zSqrArtSpecz423";

    localStorage.setItem(value45Save423, sQz423);
};

function square424(){

    var sQz424 = document.getElementById("imgSqrs424").src;

    value45Save424 = "zSqrArtSpecz424";

    localStorage.setItem(value45Save424, sQz424);
};

function square425(){

    var sQz425 = document.getElementById("imgSqrs425").src;

    value45Save425 = "zSqrArtSpecz425";

    localStorage.setItem(value45Save425, sQz425);
};

function square426(){

    var sQz426 = document.getElementById("imgSqrs426").src;

    value45Save426 = "zSqrArtSpecz426";

    localStorage.setItem(value45Save426, sQz426);
};

function square427(){

    var sQz427 = document.getElementById("imgSqrs427").src;

    value45Save427 = "zSqrArtSpecz427";

    localStorage.setItem(value45Save427, sQz427);
};

function square428(){

    var sQz428 = document.getElementById("imgSqrs428").src;

    value45Save428 = "zSqrArtSpecz428";

    localStorage.setItem(value45Save428, sQz428);
};

function square429(){

    var sQz429 = document.getElementById("imgSqrs429").src;

    value45Save429 = "zSqrArtSpecz429";

    localStorage.setItem(value45Save429, sQz429);
};

function square430(){

    var sQz430 = document.getElementById("imgSqrs430").src;

    value45Save430 = "zSqrArtSpecz430";

    localStorage.setItem(value45Save430, sQz430);
};

function square431(){

    var sQz431 = document.getElementById("imgSqrs431").src;

    value45Save431 = "zSqrArtSpecz431";

    localStorage.setItem(value45Save431, sQz431);
};

function square432(){

    var sQz432 = document.getElementById("imgSqrs432").src;

    value45Save432 = "zSqrArtSpecz432";

    localStorage.setItem(value45Save432, sQz432);
};

function square433(){

    var sQz433 = document.getElementById("imgSqrs433").src;

    value45Save433 = "zSqrArtSpecz433";

    localStorage.setItem(value45Save433, sQz433);
};

function square434(){

    var sQz434 = document.getElementById("imgSqrs434").src;

    value45Save434 = "zSqrArtSpecz434";

    localStorage.setItem(value45Save434, sQz434);
};

function square435(){

    var sQz435 = document.getElementById("imgSqrs435").src;

    value45Save435 = "zSqrArtSpecz435";

    localStorage.setItem(value45Save435, sQz435);
};

function square436(){

    var sQz436 = document.getElementById("imgSqrs436").src;

    value45Save436 = "zSqrArtSpecz436";

    localStorage.setItem(value45Save436, sQz436);
};

function square437(){

    var sQz437 = document.getElementById("imgSqrs437").src;

    value45Save437 = "zSqrArtSpecz437";

    localStorage.setItem(value45Save437, sQz437);
};

function square438(){

    var sQz438 = document.getElementById("imgSqrs438").src;

    value45Save438 = "zSqrArtSpecz438";

    localStorage.setItem(value45Save438, sQz438);
};

function square439(){

    var sQz439 = document.getElementById("imgSqrs439").src;

    value45Save439 = "zSqrArtSpecz439";

    localStorage.setItem(value45Save439, sQz439);
};

function square440(){

    var sQz440 = document.getElementById("imgSqrs440").src;

    value45Save440 = "zSqrArtSpecz440";

    localStorage.setItem(value45Save440, sQz440);
};

function square441(){

    var sQz441 = document.getElementById("imgSqrs441").src;

    value45Save441 = "zSqrArtSpecz441";

    localStorage.setItem(value45Save441, sQz441);
};

function square442(){

    var sQz442 = document.getElementById("imgSqrs442").src;

    value45Save442 = "zSqrArtSpecz442";

    localStorage.setItem(value45Save442, sQz442);
};

function square443(){

    var sQz443 = document.getElementById("imgSqrs443").src;

    value45Save443 = "zSqrArtSpecz443";

    localStorage.setItem(value45Save443, sQz443);
};

function square444(){

    var sQz444 = document.getElementById("imgSqrs444").src;

    value45Save444 = "zSqrArtSpecz444";

    localStorage.setItem(value45Save444, sQz444);
};

function square445(){

    var sQz445 = document.getElementById("imgSqrs445").src;

    value45Save445 = "zSqrArtSpecz445";

    localStorage.setItem(value45Save445, sQz445);
};

function square446(){

    var sQz446 = document.getElementById("imgSqrs446").src;

    value45Save446 = "zSqrArtSpecz446";

    localStorage.setItem(value45Save446, sQz446);
};

function square447(){

    var sQz447 = document.getElementById("imgSqrs447").src;

    value45Save447 = "zSqrArtSpecz447";

    localStorage.setItem(value45Save447, sQz447);
};

function square448(){

    var sQz448 = document.getElementById("imgSqrs448").src;

    value45Save448 = "zSqrArtSpecz448";

    localStorage.setItem(value45Save448, sQz448);
};

function square449(){

    var sQz449 = document.getElementById("imgSqrs449").src;

    value45Save449 = "zSqrArtSpecz449";

    localStorage.setItem(value45Save449, sQz449);
};

function square450(){

    var sQz450 = document.getElementById("imgSqrs450").src;

    value45Save450 = "zSqrArtSpecz450";

    localStorage.setItem(value45Save450, sQz450);
};

function square451(){

    var sQz451 = document.getElementById("imgSqrs451").src;

    value45Save451 = "zSqrArtSpecz451";

    localStorage.setItem(value45Save451, sQz451);
};

function square452(){

    var sQz452 = document.getElementById("imgSqrs452").src;

    value45Save452 = "zSqrArtSpecz452";

    localStorage.setItem(value45Save452, sQz452);
};

function square453(){

    var sQz453 = document.getElementById("imgSqrs453").src;

    value45Save453 = "zSqrArtSpecz453";

    localStorage.setItem(value45Save453, sQz453);
};

function square454(){

    var sQz454 = document.getElementById("imgSqrs454").src;

    value45Save454 = "zSqrArtSpecz454";

    localStorage.setItem(value45Save454, sQz454);
};

function square455(){

    var sQz455 = document.getElementById("imgSqrs455").src;

    value45Save455 = "zSqrArtSpecz455";

    localStorage.setItem(value45Save455, sQz455);
};

function square456(){

    var sQz456 = document.getElementById("imgSqrs456").src;

    value45Save456 = "zSqrArtSpecz456";

    localStorage.setItem(value45Save456, sQz456);
};

function square457(){

    var sQz457 = document.getElementById("imgSqrs457").src;

    value45Save457 = "zSqrArtSpecz457";

    localStorage.setItem(value45Save457, sQz457);
};

function square458(){

    var sQz458 = document.getElementById("imgSqrs458").src;

    value45Save458 = "zSqrArtSpecz458";

    localStorage.setItem(value45Save458, sQz458);
};

function square459(){

    var sQz459 = document.getElementById("imgSqrs459").src;

    value45Save459 = "zSqrArtSpecz459";

    localStorage.setItem(value45Save459, sQz459);
};

function square460(){

    var sQz460 = document.getElementById("imgSqrs460").src;

    value45Save460 = "zSqrArtSpecz460";

    localStorage.setItem(value45Save460, sQz460);
};

function square461(){

    var sQz461 = document.getElementById("imgSqrs461").src;

    value45Save461 = "zSqrArtSpecz461";

    localStorage.setItem(value45Save461, sQz461);
};

function square462(){

    var sQz462 = document.getElementById("imgSqrs462").src;

    value45Save462 = "zSqrArtSpecz462";

    localStorage.setItem(value45Save462, sQz462);
};

function square463(){

    var sQz463 = document.getElementById("imgSqrs463").src;

    value45Save463 = "zSqrArtSpecz463";

    localStorage.setItem(value45Save463, sQz463);
};

function square464(){

    var sQz464 = document.getElementById("imgSqrs464").src;

    value45Save464 = "zSqrArtSpecz464";

    localStorage.setItem(value45Save464, sQz464);
};

function square465(){

    var sQz465 = document.getElementById("imgSqrs465").src;

    value45Save465 = "zSqrArtSpecz465";

    localStorage.setItem(value45Save465, sQz465);
};

function square466(){

    var sQz466 = document.getElementById("imgSqrs466").src;

    value45Save466 = "zSqrArtSpecz466";

    localStorage.setItem(value45Save466, sQz466);
};

function square467(){

    var sQz467 = document.getElementById("imgSqrs467").src;

    value45Save467 = "zSqrArtSpecz467";

    localStorage.setItem(value45Save467, sQz467);
};

function square468(){

    var sQz468 = document.getElementById("imgSqrs468").src;

    value45Save468 = "zSqrArtSpecz468";

    localStorage.setItem(value45Save468, sQz468);
};

function square469(){

    var sQz469 = document.getElementById("imgSqrs469").src;

    value45Save469 = "zSqrArtSpecz469";

    localStorage.setItem(value45Save469, sQz469);
};

function square470(){

    var sQz470 = document.getElementById("imgSqrs470").src;

    value45Save470 = "zSqrArtSpecz470";

    localStorage.setItem(value45Save470, sQz470);
};

function square471(){

    var sQz471 = document.getElementById("imgSqrs471").src;

    value45Save471 = "zSqrArtSpecz471";

    localStorage.setItem(value45Save471, sQz471);
};

function square472(){

    var sQz472 = document.getElementById("imgSqrs472").src;

    value45Save472 = "zSqrArtSpecz472";

    localStorage.setItem(value45Save472, sQz472);
};

function square473(){

    var sQz473 = document.getElementById("imgSqrs473").src;

    value45Save473 = "zSqrArtSpecz473";

    localStorage.setItem(value45Save473, sQz473);
};

function square474(){

    var sQz474 = document.getElementById("imgSqrs474").src;

    value45Save474 = "zSqrArtSpecz474";

    localStorage.setItem(value45Save474, sQz474);
};

function square475(){

    var sQz475 = document.getElementById("imgSqrs475").src;

    value45Save475 = "zSqrArtSpecz475";

    localStorage.setItem(value45Save475, sQz475);
};

function square476(){

    var sQz476 = document.getElementById("imgSqrs476").src;

    value45Save476 = "zSqrArtSpecz476";

    localStorage.setItem(value45Save476, sQz476);
};

function square477(){

    var sQz477 = document.getElementById("imgSqrs477").src;

    value45Save477 = "zSqrArtSpecz477";

    localStorage.setItem(value45Save477, sQz477);
};

function square478(){

    var sQz478 = document.getElementById("imgSqrs478").src;

    value45Save478 = "zSqrArtSpecz478";

    localStorage.setItem(value45Save478, sQz478);
};

function square479(){

    var sQz479 = document.getElementById("imgSqrs479").src;

    value45Save479 = "zSqrArtSpecz479";

    localStorage.setItem(value45Save479, sQz479);
};

function square480(){

    var sQz480 = document.getElementById("imgSqrs480").src;

    value45Save480 = "zSqrArtSpecz480";

    localStorage.setItem(value45Save480, sQz480);
};

function square481(){

    var sQz481 = document.getElementById("imgSqrs481").src;

    value45Save481 = "zSqrArtSpecz481";

    localStorage.setItem(value45Save481, sQz481);
};

function square482(){

    var sQz482 = document.getElementById("imgSqrs482").src;

    value45Save482 = "zSqrArtSpecz482";

    localStorage.setItem(value45Save482, sQz482);
};

function square483(){

    var sQz483 = document.getElementById("imgSqrs483").src;

    value45Save483 = "zSqrArtSpecz483";

    localStorage.setItem(value45Save483, sQz483);
};

function square484(){

    var sQz484 = document.getElementById("imgSqrs484").src;

    value45Save484 = "zSqrArtSpecz484";

    localStorage.setItem(value45Save484, sQz484);
};

function square485(){

    var sQz485 = document.getElementById("imgSqrs485").src;

    value45Save485 = "zSqrArtSpecz485";

    localStorage.setItem(value45Save485, sQz485);
};

function square486(){

    var sQz486 = document.getElementById("imgSqrs486").src;

    value45Save486 = "zSqrArtSpecz486";

    localStorage.setItem(value45Save486, sQz486);
};

function square487(){

    var sQz487 = document.getElementById("imgSqrs487").src;

    value45Save487 = "zSqrArtSpecz487";

    localStorage.setItem(value45Save487, sQz487);
};

function square488(){

    var sQz488 = document.getElementById("imgSqrs488").src;

    value45Save488 = "zSqrArtSpecz488";

    localStorage.setItem(value45Save488, sQz488);
};

function square489(){

    var sQz489 = document.getElementById("imgSqrs489").src;

    value45Save489 = "zSqrArtSpecz489";

    localStorage.setItem(value45Save489, sQz489);
};

function square490(){

    var sQz490 = document.getElementById("imgSqrs490").src;

    value45Save490 = "zSqrArtSpecz490";

    localStorage.setItem(value45Save490, sQz490);
};

function square491(){

    var sQz491 = document.getElementById("imgSqrs491").src;

    value45Save491 = "zSqrArtSpecz491";

    localStorage.setItem(value45Save491, sQz491);
};

function square492(){

    var sQz492 = document.getElementById("imgSqrs492").src;

    value45Save492 = "zSqrArtSpecz492";

    localStorage.setItem(value45Save492, sQz492);
};

function square493(){

    var sQz493 = document.getElementById("imgSqrs493").src;

    value45Save493 = "zSqrArtSpecz493";

    localStorage.setItem(value45Save493, sQz493);
};

function square494(){

    var sQz494 = document.getElementById("imgSqrs494").src;

    value45Save494 = "zSqrArtSpecz494";

    localStorage.setItem(value45Save494, sQz494);
};

function square495(){

    var sQz495 = document.getElementById("imgSqrs495").src;

    value45Save495 = "zSqrArtSpecz495";

    localStorage.setItem(value45Save495, sQz495);
};

function square496(){

    var sQz496 = document.getElementById("imgSqrs496").src;

    value45Save496 = "zSqrArtSpecz496";

    localStorage.setItem(value45Save496, sQz496);
};

function square497(){

    var sQz497 = document.getElementById("imgSqrs497").src;

    value45Save497 = "zSqrArtSpecz497";

    localStorage.setItem(value45Save497, sQz497);
};

function square498(){

    var sQz498 = document.getElementById("imgSqrs498").src;

    value45Save498 = "zSqrArtSpecz498";

    localStorage.setItem(value45Save498, sQz498);
};

function square499(){

    var sQz499 = document.getElementById("imgSqrs499").src;

    value45Save499 = "zSqrArtSpecz499";

    localStorage.setItem(value45Save499, sQz499);
};

function square500(){

    var sQz500 = document.getElementById("imgSqrs500").src;

    value45Save500 = "zSqrArtSpecz500";

    localStorage.setItem(value45Save500, sQz500);
};

function square501(){

    var sQz501 = document.getElementById("imgSqrs501").src;

    value45Save501 = "zSqrArtSpecz501";

    localStorage.setItem(value45Save501, sQz501);
};

function square502(){

    var sQz502 = document.getElementById("imgSqrs502").src;

    value45Save502 = "zSqrArtSpecz502";

    localStorage.setItem(value45Save502, sQz502);
};

function square503(){

    var sQz503 = document.getElementById("imgSqrs503").src;

    value45Save503 = "zSqrArtSpecz503";

    localStorage.setItem(value45Save503, sQz503);
};

function square504(){

    var sQz504 = document.getElementById("imgSqrs504").src;

    value45Save504 = "zSqrArtSpecz504";

    localStorage.setItem(value45Save504, sQz504);
};

function square505(){

    var sQz505 = document.getElementById("imgSqrs505").src;

    value45Save505 = "zSqrArtSpecz505";

    localStorage.setItem(value45Save505, sQz505);
};

function square506(){

    var sQz506 = document.getElementById("imgSqrs506").src;

    value45Save506 = "zSqrArtSpecz506";

    localStorage.setItem(value45Save506, sQz506);
};

function square507(){

    var sQz507 = document.getElementById("imgSqrs507").src;

    value45Save507 = "zSqrArtSpecz507";

    localStorage.setItem(value45Save507, sQz507);
};

function square508(){

    var sQz508 = document.getElementById("imgSqrs508").src;

    value45Save508 = "zSqrArtSpecz508";

    localStorage.setItem(value45Save508, sQz508);
};

function square509(){

    var sQz509 = document.getElementById("imgSqrs509").src;

    value45Save509 = "zSqrArtSpecz509";

    localStorage.setItem(value45Save509, sQz509);
};

function square510(){

    var sQz510 = document.getElementById("imgSqrs510").src;

    value45Save510 = "zSqrArtSpecz510";

    localStorage.setItem(value45Save510, sQz510);
};

function square511(){

    var sQz511 = document.getElementById("imgSqrs511").src;

    value45Save511 = "zSqrArtSpecz511";

    localStorage.setItem(value45Save511, sQz511);
};

function square512(){

    var sQz512 = document.getElementById("imgSqrs512").src;

    value45Save512 = "zSqrArtSpecz512";

    localStorage.setItem(value45Save512, sQz512);
};

function square513(){

    var sQz513 = document.getElementById("imgSqrs513").src;

    value45Save513 = "zSqrArtSpecz513";

    localStorage.setItem(value45Save513, sQz513);
};

function square514(){

    var sQz514 = document.getElementById("imgSqrs514").src;

    value45Save514 = "zSqrArtSpecz514";

    localStorage.setItem(value45Save514, sQz514);
};

function square515(){

    var sQz515 = document.getElementById("imgSqrs515").src;

    value45Save515 = "zSqrArtSpecz515";

    localStorage.setItem(value45Save515, sQz515);
};

function square516(){

    var sQz516 = document.getElementById("imgSqrs516").src;

    value45Save516 = "zSqrArtSpecz516";

    localStorage.setItem(value45Save516, sQz516);
};

function square517(){

    var sQz517 = document.getElementById("imgSqrs517").src;

    value45Save517 = "zSqrArtSpecz517";

    localStorage.setItem(value45Save517, sQz517);
};

function square518(){

    var sQz518 = document.getElementById("imgSqrs518").src;

    value45Save518 = "zSqrArtSpecz518";

    localStorage.setItem(value45Save518, sQz518);
};

function square519(){

    var sQz519 = document.getElementById("imgSqrs519").src;

    value45Save519 = "zSqrArtSpecz519";

    localStorage.setItem(value45Save519, sQz519);
};

function square520(){

    var sQz520 = document.getElementById("imgSqrs520").src;

    value45Save520 = "zSqrArtSpecz520";

    localStorage.setItem(value45Save520, sQz520);
};

function square521(){

    var sQz521 = document.getElementById("imgSqrs521").src;

    value45Save521 = "zSqrArtSpecz521";

    localStorage.setItem(value45Save521, sQz521);
};

function square522(){

    var sQz522 = document.getElementById("imgSqrs522").src;

    value45Save522 = "zSqrArtSpecz522";

    localStorage.setItem(value45Save522, sQz522);
};

function square523(){

    var sQz523 = document.getElementById("imgSqrs523").src;

    value45Save523 = "zSqrArtSpecz523";

    localStorage.setItem(value45Save523, sQz523);
};

function square524(){

    var sQz524 = document.getElementById("imgSqrs524").src;

    value45Save524 = "zSqrArtSpecz524";

    localStorage.setItem(value45Save524, sQz524);
};

function square525(){

    var sQz525 = document.getElementById("imgSqrs525").src;

    value45Save525 = "zSqrArtSpecz525";

    localStorage.setItem(value45Save525, sQz525);
};

function square526(){

    var sQz526 = document.getElementById("imgSqrs526").src;

    value45Save526 = "zSqrArtSpecz526";

    localStorage.setItem(value45Save526, sQz526);
};

function square527(){

    var sQz527 = document.getElementById("imgSqrs527").src;

    value45Save527 = "zSqrArtSpecz527";

    localStorage.setItem(value45Save527, sQz527);
};

function square528(){

    var sQz528 = document.getElementById("imgSqrs528").src;

    value45Save528 = "zSqrArtSpecz528";

    localStorage.setItem(value45Save528, sQz528);
};

function square529(){

    var sQz529 = document.getElementById("imgSqrs529").src;

    value45Save529 = "zSqrArtSpecz529";

    localStorage.setItem(value45Save529, sQz529);
};

function square530(){

    var sQz530 = document.getElementById("imgSqrs530").src;

    value45Save530 = "zSqrArtSpecz530";

    localStorage.setItem(value45Save530, sQz530);
};

function square531(){

    var sQz531 = document.getElementById("imgSqrs531").src;

    value45Save531 = "zSqrArtSpecz531";

    localStorage.setItem(value45Save531, sQz531);
};

function square532(){

    var sQz532 = document.getElementById("imgSqrs532").src;

    value45Save532 = "zSqrArtSpecz532";

    localStorage.setItem(value45Save532, sQz532);
};

function square533(){

    var sQz533 = document.getElementById("imgSqrs533").src;

    value45Save533 = "zSqrArtSpecz533";

    localStorage.setItem(value45Save533, sQz533);
};

function square534(){

    var sQz534 = document.getElementById("imgSqrs534").src;

    value45Save534 = "zSqrArtSpecz534";

    localStorage.setItem(value45Save534, sQz534);
};

function square535(){

    var sQz535 = document.getElementById("imgSqrs535").src;

    value45Save535 = "zSqrArtSpecz535";

    localStorage.setItem(value45Save535, sQz535);
};

function square536(){

    var sQz536 = document.getElementById("imgSqrs536").src;

    value45Save536 = "zSqrArtSpecz536";

    localStorage.setItem(value45Save536, sQz536);
};

function square537(){

    var sQz537 = document.getElementById("imgSqrs537").src;

    value45Save537 = "zSqrArtSpecz537";

    localStorage.setItem(value45Save537, sQz537);
};

function square538(){

    var sQz538 = document.getElementById("imgSqrs538").src;

    value45Save538 = "zSqrArtSpecz538";

    localStorage.setItem(value45Save538, sQz538);
};

function square539(){

    var sQz539 = document.getElementById("imgSqrs539").src;

    value45Save539 = "zSqrArtSpecz539";

    localStorage.setItem(value45Save539, sQz539);
};

function square540(){

    var sQz540 = document.getElementById("imgSqrs540").src;

    value45Save540 = "zSqrArtSpecz540";

    localStorage.setItem(value45Save540, sQz540);
};

function square541(){

    var sQz541 = document.getElementById("imgSqrs541").src;

    value45Save541 = "zSqrArtSpecz541";

    localStorage.setItem(value45Save541, sQz541);
};

function square542(){

    var sQz542 = document.getElementById("imgSqrs542").src;

    value45Save542 = "zSqrArtSpecz542";

    localStorage.setItem(value45Save542, sQz542);
};

function square543(){

    var sQz543 = document.getElementById("imgSqrs543").src;

    value45Save543 = "zSqrArtSpecz543";

    localStorage.setItem(value45Save543, sQz543);
};

function square544(){

    var sQz544 = document.getElementById("imgSqrs544").src;

    value45Save544 = "zSqrArtSpecz544";

    localStorage.setItem(value45Save544, sQz544);
};

function square545(){

    var sQz545 = document.getElementById("imgSqrs545").src;

    value45Save545 = "zSqrArtSpecz545";

    localStorage.setItem(value45Save545, sQz545);
};

function square546(){

    var sQz546 = document.getElementById("imgSqrs546").src;

    value45Save546 = "zSqrArtSpecz546";

    localStorage.setItem(value45Save546, sQz546);
};

function square547(){

    var sQz547 = document.getElementById("imgSqrs547").src;

    value45Save547 = "zSqrArtSpecz547";

    localStorage.setItem(value45Save547, sQz547);
};

function square548(){

    var sQz548 = document.getElementById("imgSqrs548").src;

    value45Save548 = "zSqrArtSpecz548";

    localStorage.setItem(value45Save548, sQz548);
};

function square549(){

    var sQz549 = document.getElementById("imgSqrs549").src;

    value45Save549 = "zSqrArtSpecz549";

    localStorage.setItem(value45Save549, sQz549);
};

function square550(){

    var sQz550 = document.getElementById("imgSqrs550").src;

    value45Save550 = "zSqrArtSpecz550";

    localStorage.setItem(value45Save550, sQz550);
};

function square551(){

    var sQz551 = document.getElementById("imgSqrs551").src;

    value45Save551 = "zSqrArtSpecz551";

    localStorage.setItem(value45Save551, sQz551);
};

function square552(){

    var sQz552 = document.getElementById("imgSqrs552").src;

    value45Save552 = "zSqrArtSpecz552";

    localStorage.setItem(value45Save552, sQz552);
};

function square553(){

    var sQz553 = document.getElementById("imgSqrs553").src;

    value45Save553 = "zSqrArtSpecz553";

    localStorage.setItem(value45Save553, sQz553);
};

function square554(){

    var sQz554 = document.getElementById("imgSqrs554").src;

    value45Save554 = "zSqrArtSpecz554";

    localStorage.setItem(value45Save554, sQz554);
};

function square555(){

    var sQz555 = document.getElementById("imgSqrs555").src;

    value45Save555 = "zSqrArtSpecz555";

    localStorage.setItem(value45Save555, sQz555);
};

function square556(){

    var sQz556 = document.getElementById("imgSqrs556").src;

    value45Save556 = "zSqrArtSpecz556";

    localStorage.setItem(value45Save556, sQz556);
};

function square557(){

    var sQz557 = document.getElementById("imgSqrs557").src;

    value45Save557 = "zSqrArtSpecz557";

    localStorage.setItem(value45Save557, sQz557);
};

function square558(){

    var sQz558 = document.getElementById("imgSqrs558").src;

    value45Save558 = "zSqrArtSpecz558";

    localStorage.setItem(value45Save558, sQz558);
};

function square559(){

    var sQz559 = document.getElementById("imgSqrs559").src;

    value45Save559 = "zSqrArtSpecz559";

    localStorage.setItem(value45Save559, sQz559);
};

function square560(){

    var sQz560 = document.getElementById("imgSqrs560").src;

    value45Save560 = "zSqrArtSpecz560";

    localStorage.setItem(value45Save560, sQz560);
};

function square561(){

    var sQz561 = document.getElementById("imgSqrs561").src;

    value45Save561 = "zSqrArtSpecz561";

    localStorage.setItem(value45Save561, sQz561);
};

function square562(){

    var sQz562 = document.getElementById("imgSqrs562").src;

    value45Save562 = "zSqrArtSpecz562";

    localStorage.setItem(value45Save562, sQz562);
};

function square563(){

    var sQz563 = document.getElementById("imgSqrs563").src;

    value45Save563 = "zSqrArtSpecz563";

    localStorage.setItem(value45Save563, sQz563);
};

function square564(){

    var sQz564 = document.getElementById("imgSqrs564").src;

    value45Save564 = "zSqrArtSpecz564";

    localStorage.setItem(value45Save564, sQz564);
};

function square565(){

    var sQz565 = document.getElementById("imgSqrs565").src;

    value45Save565 = "zSqrArtSpecz565";

    localStorage.setItem(value45Save565, sQz565);
};

function square566(){

    var sQz566 = document.getElementById("imgSqrs566").src;

    value45Save566 = "zSqrArtSpecz566";

    localStorage.setItem(value45Save566, sQz566);
};

function square567(){

    var sQz567 = document.getElementById("imgSqrs567").src;

    value45Save567 = "zSqrArtSpecz567";

    localStorage.setItem(value45Save567, sQz567);
};

function square568(){

    var sQz568 = document.getElementById("imgSqrs568").src;

    value45Save568 = "zSqrArtSpecz568";

    localStorage.setItem(value45Save568, sQz568);
};

function square569(){

    var sQz569 = document.getElementById("imgSqrs569").src;

    value45Save569 = "zSqrArtSpecz569";

    localStorage.setItem(value45Save569, sQz569);
};

function square570(){

    var sQz570 = document.getElementById("imgSqrs570").src;

    value45Save570 = "zSqrArtSpecz570";

    localStorage.setItem(value45Save570, sQz570);
};

function square571(){

    var sQz571 = document.getElementById("imgSqrs571").src;

    value45Save571 = "zSqrArtSpecz571";

    localStorage.setItem(value45Save571, sQz571);
};

function square572(){

    var sQz572 = document.getElementById("imgSqrs572").src;

    value45Save572 = "zSqrArtSpecz572";

    localStorage.setItem(value45Save572, sQz572);
};

function square573(){

    var sQz573 = document.getElementById("imgSqrs573").src;

    value45Save573 = "zSqrArtSpecz573";

    localStorage.setItem(value45Save573, sQz573);
};

function square574(){

    var sQz574 = document.getElementById("imgSqrs574").src;

    value45Save574 = "zSqrArtSpecz574";

    localStorage.setItem(value45Save574, sQz574);
};

function square575(){

    var sQz575 = document.getElementById("imgSqrs575").src;

    value45Save575 = "zSqrArtSpecz575";

    localStorage.setItem(value45Save575, sQz575);
};

function square576(){

    var sQz576 = document.getElementById("imgSqrs576").src;

    value45Save576 = "zSqrArtSpecz576";

    localStorage.setItem(value45Save576, sQz576);
};

function square577(){

    var sQz577 = document.getElementById("imgSqrs577").src;

    value45Save577 = "zSqrArtSpecz577";

    localStorage.setItem(value45Save577, sQz577);
};

function square578(){

    var sQz578 = document.getElementById("imgSqrs578").src;

    value45Save578 = "zSqrArtSpecz578";

    localStorage.setItem(value45Save578, sQz578);
};

function square579(){

    var sQz579 = document.getElementById("imgSqrs579").src;

    value45Save579 = "zSqrArtSpecz579";

    localStorage.setItem(value45Save579, sQz579);
};

function square580(){

    var sQz580 = document.getElementById("imgSqrs580").src;

    value45Save580 = "zSqrArtSpecz580";

    localStorage.setItem(value45Save580, sQz580);
};

function square581(){

    var sQz581 = document.getElementById("imgSqrs581").src;

    value45Save581 = "zSqrArtSpecz581";

    localStorage.setItem(value45Save581, sQz581);
};

function square582(){

    var sQz582 = document.getElementById("imgSqrs582").src;

    value45Save582 = "zSqrArtSpecz582";

    localStorage.setItem(value45Save582, sQz582);
};

function square583(){

    var sQz583 = document.getElementById("imgSqrs583").src;

    value45Save583 = "zSqrArtSpecz583";

    localStorage.setItem(value45Save583, sQz583);
};

function square584(){

    var sQz584 = document.getElementById("imgSqrs584").src;

    value45Save584 = "zSqrArtSpecz584";

    localStorage.setItem(value45Save584, sQz584);
};

function square585(){

    var sQz585 = document.getElementById("imgSqrs585").src;

    value45Save585 = "zSqrArtSpecz585";

    localStorage.setItem(value45Save585, sQz585);
};

function square586(){

    var sQz586 = document.getElementById("imgSqrs586").src;

    value45Save586 = "zSqrArtSpecz586";

    localStorage.setItem(value45Save586, sQz586);
};

function square587(){

    var sQz587 = document.getElementById("imgSqrs587").src;

    value45Save587 = "zSqrArtSpecz587";

    localStorage.setItem(value45Save587, sQz587);
};

function square588(){

    var sQz588 = document.getElementById("imgSqrs588").src;

    value45Save588 = "zSqrArtSpecz588";

    localStorage.setItem(value45Save588, sQz588);
};

function square589(){

    var sQz589 = document.getElementById("imgSqrs589").src;

    value45Save589 = "zSqrArtSpecz589";

    localStorage.setItem(value45Save589, sQz589);
};

function square590(){

    var sQz590 = document.getElementById("imgSqrs590").src;

    value45Save590 = "zSqrArtSpecz590";

    localStorage.setItem(value45Save590, sQz590);
};

function square591(){

    var sQz591 = document.getElementById("imgSqrs591").src;

    value45Save591 = "zSqrArtSpecz591";

    localStorage.setItem(value45Save591, sQz591);
};

function square592(){

    var sQz592 = document.getElementById("imgSqrs592").src;

    value45Save592 = "zSqrArtSpecz592";

    localStorage.setItem(value45Save592, sQz592);
};

function square593(){

    var sQz593 = document.getElementById("imgSqrs593").src;

    value45Save593 = "zSqrArtSpecz593";

    localStorage.setItem(value45Save593, sQz593);
};

function square594(){

    var sQz594 = document.getElementById("imgSqrs594").src;

    value45Save594 = "zSqrArtSpecz594";

    localStorage.setItem(value45Save594, sQz594);
};

function square595(){

    var sQz595 = document.getElementById("imgSqrs595").src;

    value45Save595 = "zSqrArtSpecz595";

    localStorage.setItem(value45Save595, sQz595);
};

function square596(){

    var sQz596 = document.getElementById("imgSqrs596").src;

    value45Save596 = "zSqrArtSpecz596";

    localStorage.setItem(value45Save596, sQz596);
};

function square597(){

    var sQz597 = document.getElementById("imgSqrs597").src;

    value45Save597 = "zSqrArtSpecz597";

    localStorage.setItem(value45Save597, sQz597);
};

function square598(){

    var sQz598 = document.getElementById("imgSqrs598").src;

    value45Save598 = "zSqrArtSpecz598";

    localStorage.setItem(value45Save598, sQz598);
};

function square599(){

    var sQz599 = document.getElementById("imgSqrs599").src;

    value45Save599 = "zSqrArtSpecz599";

    localStorage.setItem(value45Save599, sQz599);
};

function square600(){

    var sQz600 = document.getElementById("imgSqrs600").src;

    value45Save600 = "zSqrArtSpecz600";

    localStorage.setItem(value45Save600, sQz600);
};

function square601(){

    var sQz601 = document.getElementById("imgSqrs601").src;

    value45Save601 = "zSqrArtSpecz601";

    localStorage.setItem(value45Save601, sQz601);
};

function square602(){

    var sQz602 = document.getElementById("imgSqrs602").src;

    value45Save602 = "zSqrArtSpecz602";

    localStorage.setItem(value45Save602, sQz602);
};

function square603(){

    var sQz603 = document.getElementById("imgSqrs603").src;

    value45Save603 = "zSqrArtSpecz603";

    localStorage.setItem(value45Save603, sQz603);
};

function square604(){

    var sQz604 = document.getElementById("imgSqrs604").src;

    value45Save604 = "zSqrArtSpecz604";

    localStorage.setItem(value45Save604, sQz604);
};

function square605(){

    var sQz605 = document.getElementById("imgSqrs605").src;

    value45Save605 = "zSqrArtSpecz605";

    localStorage.setItem(value45Save605, sQz605);
};

function square606(){

    var sQz606 = document.getElementById("imgSqrs606").src;

    value45Save606 = "zSqrArtSpecz606";

    localStorage.setItem(value45Save606, sQz606);
};

function square607(){

    var sQz607 = document.getElementById("imgSqrs607").src;

    value45Save607 = "zSqrArtSpecz607";

    localStorage.setItem(value45Save607, sQz607);
};

function square608(){

    var sQz608 = document.getElementById("imgSqrs608").src;

    value45Save608 = "zSqrArtSpecz608";

    localStorage.setItem(value45Save608, sQz608);
};

function square609(){

    var sQz609 = document.getElementById("imgSqrs609").src;

    value45Save609 = "zSqrArtSpecz609";

    localStorage.setItem(value45Save609, sQz609);
};

function square610(){

    var sQz610 = document.getElementById("imgSqrs610").src;

    value45Save610 = "zSqrArtSpecz610";

    localStorage.setItem(value45Save610, sQz610);
};

function square611(){

    var sQz611 = document.getElementById("imgSqrs611").src;

    value45Save611 = "zSqrArtSpecz611";

    localStorage.setItem(value45Save611, sQz611);
};

function square612(){

    var sQz612 = document.getElementById("imgSqrs612").src;

    value45Save612 = "zSqrArtSpecz612";

    localStorage.setItem(value45Save612, sQz612);
};

function square613(){

    var sQz613 = document.getElementById("imgSqrs613").src;

    value45Save613 = "zSqrArtSpecz613";

    localStorage.setItem(value45Save613, sQz613);
};

function square614(){

    var sQz614 = document.getElementById("imgSqrs614").src;

    value45Save614 = "zSqrArtSpecz614";

    localStorage.setItem(value45Save614, sQz614);
};

function square615(){

    var sQz615 = document.getElementById("imgSqrs615").src;

    value45Save615 = "zSqrArtSpecz615";

    localStorage.setItem(value45Save615, sQz615);
};

function square616(){

    var sQz616 = document.getElementById("imgSqrs616").src;

    value45Save616 = "zSqrArtSpecz616";

    localStorage.setItem(value45Save616, sQz616);
};

function square617(){

    var sQz617 = document.getElementById("imgSqrs617").src;

    value45Save617 = "zSqrArtSpecz617";

    localStorage.setItem(value45Save617, sQz617);
};

function square618(){

    var sQz618 = document.getElementById("imgSqrs618").src;

    value45Save618 = "zSqrArtSpecz618";

    localStorage.setItem(value45Save618, sQz618);
};

function square619(){

    var sQz619 = document.getElementById("imgSqrs619").src;

    value45Save619 = "zSqrArtSpecz619";

    localStorage.setItem(value45Save619, sQz619);
};

function square620(){

    var sQz620 = document.getElementById("imgSqrs620").src;

    value45Save620 = "zSqrArtSpecz620";

    localStorage.setItem(value45Save620, sQz620);
};

function square621(){

    var sQz621 = document.getElementById("imgSqrs621").src;

    value45Save621 = "zSqrArtSpecz621";

    localStorage.setItem(value45Save621, sQz621);
};

function square622(){

    var sQz622 = document.getElementById("imgSqrs622").src;

    value45Save622 = "zSqrArtSpecz622";

    localStorage.setItem(value45Save622, sQz622);
};

function square623(){

    var sQz623 = document.getElementById("imgSqrs623").src;

    value45Save623 = "zSqrArtSpecz623";

    localStorage.setItem(value45Save623, sQz623);
};

function square624(){

    var sQz624 = document.getElementById("imgSqrs624").src;

    value45Save624 = "zSqrArtSpecz624";

    localStorage.setItem(value45Save624, sQz624);
};

function square625(){

    var sQz625 = document.getElementById("imgSqrs625").src;

    value45Save625 = "zSqrArtSpecz625";

    localStorage.setItem(value45Save625, sQz625);
};

function square626(){

    var sQz626 = document.getElementById("imgSqrs626").src;

    value45Save626 = "zSqrArtSpecz626";

    localStorage.setItem(value45Save626, sQz626);
};

function square627(){

    var sQz627 = document.getElementById("imgSqrs627").src;

    value45Save627 = "zSqrArtSpecz627";

    localStorage.setItem(value45Save627, sQz627);
};

function square628(){

    var sQz628 = document.getElementById("imgSqrs628").src;

    value45Save628 = "zSqrArtSpecz628";

    localStorage.setItem(value45Save628, sQz628);
};

function square629(){

    var sQz629 = document.getElementById("imgSqrs629").src;

    value45Save629 = "zSqrArtSpecz629";

    localStorage.setItem(value45Save629, sQz629);
};

function square630(){

    var sQz630 = document.getElementById("imgSqrs630").src;

    value45Save630 = "zSqrArtSpecz630";

    localStorage.setItem(value45Save630, sQz630);
};

function square631(){

    var sQz631 = document.getElementById("imgSqrs631").src;

    value45Save631 = "zSqrArtSpecz631";

    localStorage.setItem(value45Save631, sQz631);
};

function square632(){

    var sQz632 = document.getElementById("imgSqrs632").src;

    value45Save632 = "zSqrArtSpecz632";

    localStorage.setItem(value45Save632, sQz632);
};

function square633(){

    var sQz633 = document.getElementById("imgSqrs633").src;

    value45Save633 = "zSqrArtSpecz633";

    localStorage.setItem(value45Save633, sQz633);
};

function square634(){

    var sQz634 = document.getElementById("imgSqrs634").src;

    value45Save634 = "zSqrArtSpecz634";

    localStorage.setItem(value45Save634, sQz634);
};

function square635(){

    var sQz635 = document.getElementById("imgSqrs635").src;

    value45Save635 = "zSqrArtSpecz635";

    localStorage.setItem(value45Save635, sQz635);
};

function square636(){

    var sQz636 = document.getElementById("imgSqrs636").src;

    value45Save636 = "zSqrArtSpecz636";

    localStorage.setItem(value45Save636, sQz636);
};

function square637(){

    var sQz637 = document.getElementById("imgSqrs637").src;

    value45Save637 = "zSqrArtSpecz637";

    localStorage.setItem(value45Save637, sQz637);
};

function square638(){

    var sQz638 = document.getElementById("imgSqrs638").src;

    value45Save638 = "zSqrArtSpecz638";

    localStorage.setItem(value45Save638, sQz638);
};

function square639(){

    var sQz639 = document.getElementById("imgSqrs639").src;

    value45Save639 = "zSqrArtSpecz639";

    localStorage.setItem(value45Save639, sQz639);
};

function square640(){

    var sQz640 = document.getElementById("imgSqrs640").src;

    value45Save640 = "zSqrArtSpecz640";

    localStorage.setItem(value45Save640, sQz640);
};

function square641(){

    var sQz641 = document.getElementById("imgSqrs641").src;

    value45Save641 = "zSqrArtSpecz641";

    localStorage.setItem(value45Save641, sQz641);
};

function square642(){

    var sQz642 = document.getElementById("imgSqrs642").src;

    value45Save642 = "zSqrArtSpecz642";

    localStorage.setItem(value45Save642, sQz642);
};

function square643(){

    var sQz643 = document.getElementById("imgSqrs643").src;

    value45Save643 = "zSqrArtSpecz643";

    localStorage.setItem(value45Save643, sQz643);
};

function square644(){

    var sQz644 = document.getElementById("imgSqrs644").src;

    value45Save644 = "zSqrArtSpecz644";

    localStorage.setItem(value45Save644, sQz644);
};

function square645(){

    var sQz645 = document.getElementById("imgSqrs645").src;

    value45Save645 = "zSqrArtSpecz645";

    localStorage.setItem(value45Save645, sQz645);
};

function square646(){

    var sQz646 = document.getElementById("imgSqrs646").src;

    value45Save646 = "zSqrArtSpecz646";

    localStorage.setItem(value45Save646, sQz646);
};

function square647(){

    var sQz647 = document.getElementById("imgSqrs647").src;

    value45Save647 = "zSqrArtSpecz647";

    localStorage.setItem(value45Save647, sQz647);
};

function square648(){

    var sQz648 = document.getElementById("imgSqrs648").src;

    value45Save648 = "zSqrArtSpecz648";

    localStorage.setItem(value45Save648, sQz648);
};

function square649(){

    var sQz649 = document.getElementById("imgSqrs649").src;

    value45Save649 = "zSqrArtSpecz649";

    localStorage.setItem(value45Save649, sQz649);
};

function square650(){

    var sQz650 = document.getElementById("imgSqrs650").src;

    value45Save650 = "zSqrArtSpecz650";

    localStorage.setItem(value45Save650, sQz650);
};

function square651(){

    var sQz651 = document.getElementById("imgSqrs651").src;

    value45Save651 = "zSqrArtSpecz651";

    localStorage.setItem(value45Save651, sQz651);
};

function square652(){

    var sQz652 = document.getElementById("imgSqrs652").src;

    value45Save652 = "zSqrArtSpecz652";

    localStorage.setItem(value45Save652, sQz652);
};

function square653(){

    var sQz653 = document.getElementById("imgSqrs653").src;

    value45Save653 = "zSqrArtSpecz653";

    localStorage.setItem(value45Save653, sQz653);
};

function square654(){

    var sQz654 = document.getElementById("imgSqrs654").src;

    value45Save654 = "zSqrArtSpecz654";

    localStorage.setItem(value45Save654, sQz654);
};

function square655(){

    var sQz655 = document.getElementById("imgSqrs655").src;

    value45Save655 = "zSqrArtSpecz655";

    localStorage.setItem(value45Save655, sQz655);
};

function square656(){

    var sQz656 = document.getElementById("imgSqrs656").src;

    value45Save656 = "zSqrArtSpecz656";

    localStorage.setItem(value45Save656, sQz656);
};

function square657(){

    var sQz657 = document.getElementById("imgSqrs657").src;

    value45Save657 = "zSqrArtSpecz657";

    localStorage.setItem(value45Save657, sQz657);
};

function square658(){

    var sQz658 = document.getElementById("imgSqrs658").src;

    value45Save658 = "zSqrArtSpecz658";

    localStorage.setItem(value45Save658, sQz658);
};

function square659(){

    var sQz659 = document.getElementById("imgSqrs659").src;

    value45Save659 = "zSqrArtSpecz659";

    localStorage.setItem(value45Save659, sQz659);
};

function square660(){

    var sQz660 = document.getElementById("imgSqrs660").src;

    value45Save660 = "zSqrArtSpecz660";

    localStorage.setItem(value45Save660, sQz660);
};

function square661(){

    var sQz661 = document.getElementById("imgSqrs661").src;

    value45Save661 = "zSqrArtSpecz661";

    localStorage.setItem(value45Save661, sQz661);
};

function square662(){

    var sQz662 = document.getElementById("imgSqrs662").src;

    value45Save662 = "zSqrArtSpecz662";

    localStorage.setItem(value45Save662, sQz662);
};

function square663(){

    var sQz663 = document.getElementById("imgSqrs663").src;

    value45Save663 = "zSqrArtSpecz663";

    localStorage.setItem(value45Save663, sQz663);
};

function square664(){

    var sQz664 = document.getElementById("imgSqrs664").src;

    value45Save664 = "zSqrArtSpecz664";

    localStorage.setItem(value45Save664, sQz664);
};

function square665(){

    var sQz665 = document.getElementById("imgSqrs665").src;

    value45Save665 = "zSqrArtSpecz665";

    localStorage.setItem(value45Save665, sQz665);
};

function square666(){

    var sQz666 = document.getElementById("imgSqrs666").src;

    value45Save666 = "zSqrArtSpecz666";

    localStorage.setItem(value45Save666, sQz666);
};

function square667(){

    var sQz667 = document.getElementById("imgSqrs667").src;

    value45Save667 = "zSqrArtSpecz667";

    localStorage.setItem(value45Save667, sQz667);
};

function square668(){

    var sQz668 = document.getElementById("imgSqrs668").src;

    value45Save668 = "zSqrArtSpecz668";

    localStorage.setItem(value45Save668, sQz668);
};

function square669(){

    var sQz669 = document.getElementById("imgSqrs669").src;

    value45Save669 = "zSqrArtSpecz669";

    localStorage.setItem(value45Save669, sQz669);
};

function square670(){

    var sQz670 = document.getElementById("imgSqrs670").src;

    value45Save670 = "zSqrArtSpecz670";

    localStorage.setItem(value45Save670, sQz670);
};

function square671(){

    var sQz671 = document.getElementById("imgSqrs671").src;

    value45Save671 = "zSqrArtSpecz671";

    localStorage.setItem(value45Save671, sQz671);
};

function square672(){

    var sQz672 = document.getElementById("imgSqrs672").src;

    value45Save672 = "zSqrArtSpecz672";

    localStorage.setItem(value45Save672, sQz672);
};

function square673(){

    var sQz673 = document.getElementById("imgSqrs673").src;

    value45Save673 = "zSqrArtSpecz673";

    localStorage.setItem(value45Save673, sQz673);
};

function square674(){

    var sQz674 = document.getElementById("imgSqrs674").src;

    value45Save674 = "zSqrArtSpecz674";

    localStorage.setItem(value45Save674, sQz674);
};

function square675(){

    var sQz675 = document.getElementById("imgSqrs675").src;

    value45Save675 = "zSqrArtSpecz675";

    localStorage.setItem(value45Save675, sQz675);
};

function square676(){

    var sQz676 = document.getElementById("imgSqrs676").src;

    value45Save676 = "zSqrArtSpecz676";

    localStorage.setItem(value45Save676, sQz676);
};

function square677(){

    var sQz677 = document.getElementById("imgSqrs677").src;

    value45Save677 = "zSqrArtSpecz677";

    localStorage.setItem(value45Save677, sQz677);
};

function square678(){

    var sQz678 = document.getElementById("imgSqrs678").src;

    value45Save678 = "zSqrArtSpecz678";

    localStorage.setItem(value45Save678, sQz678);
};

function square679(){

    var sQz679 = document.getElementById("imgSqrs679").src;

    value45Save679 = "zSqrArtSpecz679";

    localStorage.setItem(value45Save679, sQz679);
};

function square680(){

    var sQz680 = document.getElementById("imgSqrs680").src;

    value45Save680 = "zSqrArtSpecz680";

    localStorage.setItem(value45Save680, sQz680);
};

function square681(){

    var sQz681 = document.getElementById("imgSqrs681").src;

    value45Save681 = "zSqrArtSpecz681";

    localStorage.setItem(value45Save681, sQz681);
};

function square682(){

    var sQz682 = document.getElementById("imgSqrs682").src;

    value45Save682 = "zSqrArtSpecz682";

    localStorage.setItem(value45Save682, sQz682);
};

function square683(){

    var sQz683 = document.getElementById("imgSqrs683").src;

    value45Save683 = "zSqrArtSpecz683";

    localStorage.setItem(value45Save683, sQz683);
};

function square684(){

    var sQz684 = document.getElementById("imgSqrs684").src;

    value45Save684 = "zSqrArtSpecz684";

    localStorage.setItem(value45Save684, sQz684);
};

function square685(){

    var sQz685 = document.getElementById("imgSqrs685").src;

    value45Save685 = "zSqrArtSpecz685";

    localStorage.setItem(value45Save685, sQz685);
};

function square686(){

    var sQz686 = document.getElementById("imgSqrs686").src;

    value45Save686 = "zSqrArtSpecz686";

    localStorage.setItem(value45Save686, sQz686);
};

function square687(){

    var sQz687 = document.getElementById("imgSqrs687").src;

    value45Save687 = "zSqrArtSpecz687";

    localStorage.setItem(value45Save687, sQz687);
};

function square688(){

    var sQz688 = document.getElementById("imgSqrs688").src;

    value45Save688 = "zSqrArtSpecz688";

    localStorage.setItem(value45Save688, sQz688);
};

function square689(){

    var sQz689 = document.getElementById("imgSqrs689").src;

    value45Save689 = "zSqrArtSpecz689";

    localStorage.setItem(value45Save689, sQz689);
};

function square690(){

    var sQz690 = document.getElementById("imgSqrs690").src;

    value45Save690 = "zSqrArtSpecz690";

    localStorage.setItem(value45Save690, sQz690);
};

function square691(){

    var sQz691 = document.getElementById("imgSqrs691").src;

    value45Save691 = "zSqrArtSpecz691";

    localStorage.setItem(value45Save691, sQz691);
};

function square692(){

    var sQz692 = document.getElementById("imgSqrs692").src;

    value45Save692 = "zSqrArtSpecz692";

    localStorage.setItem(value45Save692, sQz692);
};

function square693(){

    var sQz693 = document.getElementById("imgSqrs693").src;

    value45Save693 = "zSqrArtSpecz693";

    localStorage.setItem(value45Save693, sQz693);
};

function square694(){

    var sQz694 = document.getElementById("imgSqrs694").src;

    value45Save694 = "zSqrArtSpecz694";

    localStorage.setItem(value45Save694, sQz694);
};

function square695(){

    var sQz695 = document.getElementById("imgSqrs695").src;

    value45Save695 = "zSqrArtSpecz695";

    localStorage.setItem(value45Save695, sQz695);
};

function square696(){

    var sQz696 = document.getElementById("imgSqrs696").src;

    value45Save696 = "zSqrArtSpecz696";

    localStorage.setItem(value45Save696, sQz696);
};

function square697(){

    var sQz697 = document.getElementById("imgSqrs697").src;

    value45Save697 = "zSqrArtSpecz697";

    localStorage.setItem(value45Save697, sQz697);
};

function square698(){

    var sQz698 = document.getElementById("imgSqrs698").src;

    value45Save698 = "zSqrArtSpecz698";

    localStorage.setItem(value45Save698, sQz698);
};

function square699(){

    var sQz699 = document.getElementById("imgSqrs699").src;

    value45Save699 = "zSqrArtSpecz699";

    localStorage.setItem(value45Save699, sQz699);
};

function square700(){

    var sQz700 = document.getElementById("imgSqrs700").src;

    value45Save700 = "zSqrArtSpecz700";

    localStorage.setItem(value45Save700, sQz700);
};

function square701(){

    var sQz701 = document.getElementById("imgSqrs701").src;

    value45Save701 = "zSqrArtSpecz701";

    localStorage.setItem(value45Save701, sQz701);
};

function square702(){

    var sQz702 = document.getElementById("imgSqrs702").src;

    value45Save702 = "zSqrArtSpecz702";

    localStorage.setItem(value45Save702, sQz702);
};

function square703(){

    var sQz703 = document.getElementById("imgSqrs703").src;

    value45Save703 = "zSqrArtSpecz703";

    localStorage.setItem(value45Save703, sQz703);
};

function square704(){

    var sQz704 = document.getElementById("imgSqrs704").src;

    value45Save704 = "zSqrArtSpecz704";

    localStorage.setItem(value45Save704, sQz704);
};

function square705(){

    var sQz705 = document.getElementById("imgSqrs705").src;

    value45Save705 = "zSqrArtSpecz705";

    localStorage.setItem(value45Save705, sQz705);
};

function square706(){

    var sQz706 = document.getElementById("imgSqrs706").src;

    value45Save706 = "zSqrArtSpecz706";

    localStorage.setItem(value45Save706, sQz706);
};

function square707(){

    var sQz707 = document.getElementById("imgSqrs707").src;

    value45Save707 = "zSqrArtSpecz707";

    localStorage.setItem(value45Save707, sQz707);
};

function square708(){

    var sQz708 = document.getElementById("imgSqrs708").src;

    value45Save708 = "zSqrArtSpecz708";

    localStorage.setItem(value45Save708, sQz708);
};

function square709(){

    var sQz709 = document.getElementById("imgSqrs709").src;

    value45Save709 = "zSqrArtSpecz709";

    localStorage.setItem(value45Save709, sQz709);
};

function square710(){

    var sQz710 = document.getElementById("imgSqrs710").src;

    value45Save710 = "zSqrArtSpecz710";

    localStorage.setItem(value45Save710, sQz710);
};

function square711(){

    var sQz711 = document.getElementById("imgSqrs711").src;

    value45Save711 = "zSqrArtSpecz711";

    localStorage.setItem(value45Save711, sQz711);
};

function square712(){

    var sQz712 = document.getElementById("imgSqrs712").src;

    value45Save712 = "zSqrArtSpecz712";

    localStorage.setItem(value45Save712, sQz712);
};

function square713(){

    var sQz713 = document.getElementById("imgSqrs713").src;

    value45Save713 = "zSqrArtSpecz713";

    localStorage.setItem(value45Save713, sQz713);
};

function square714(){

    var sQz714 = document.getElementById("imgSqrs714").src;

    value45Save714 = "zSqrArtSpecz714";

    localStorage.setItem(value45Save714, sQz714);
};

function square715(){

    var sQz715 = document.getElementById("imgSqrs715").src;

    value45Save715 = "zSqrArtSpecz715";

    localStorage.setItem(value45Save715, sQz715);
};

function square716(){

    var sQz716 = document.getElementById("imgSqrs716").src;

    value45Save716 = "zSqrArtSpecz716";

    localStorage.setItem(value45Save716, sQz716);
};

function square717(){

    var sQz717 = document.getElementById("imgSqrs717").src;

    value45Save717 = "zSqrArtSpecz717";

    localStorage.setItem(value45Save717, sQz717);
};

function square718(){

    var sQz718 = document.getElementById("imgSqrs718").src;

    value45Save718 = "zSqrArtSpecz718";

    localStorage.setItem(value45Save718, sQz718);
};

function square719(){

    var sQz719 = document.getElementById("imgSqrs719").src;

    value45Save719 = "zSqrArtSpecz719";

    localStorage.setItem(value45Save719, sQz719);
};

function square720(){

    var sQz720 = document.getElementById("imgSqrs720").src;

    value45Save720 = "zSqrArtSpecz720";

    localStorage.setItem(value45Save720, sQz720);
};

function square721(){

    var sQz721 = document.getElementById("imgSqrs721").src;

    value45Save721 = "zSqrArtSpecz721";

    localStorage.setItem(value45Save721, sQz721);
};

function square722(){

    var sQz722 = document.getElementById("imgSqrs722").src;

    value45Save722 = "zSqrArtSpecz722";

    localStorage.setItem(value45Save722, sQz722);
};

function square723(){

    var sQz723 = document.getElementById("imgSqrs723").src;

    value45Save723 = "zSqrArtSpecz723";

    localStorage.setItem(value45Save723, sQz723);
};

function square724(){

    var sQz724 = document.getElementById("imgSqrs724").src;

    value45Save724 = "zSqrArtSpecz724";

    localStorage.setItem(value45Save724, sQz724);
};

function square725(){

    var sQz725 = document.getElementById("imgSqrs725").src;

    value45Save725 = "zSqrArtSpecz725";

    localStorage.setItem(value45Save725, sQz725);
};

function square726(){

    var sQz726 = document.getElementById("imgSqrs726").src;

    value45Save726 = "zSqrArtSpecz726";

    localStorage.setItem(value45Save726, sQz726);
};

function square727(){

    var sQz727 = document.getElementById("imgSqrs727").src;

    value45Save727 = "zSqrArtSpecz727";

    localStorage.setItem(value45Save727, sQz727);
};

function square728(){

    var sQz728 = document.getElementById("imgSqrs728").src;

    value45Save728 = "zSqrArtSpecz728";

    localStorage.setItem(value45Save728, sQz728);
};

function square729(){

    var sQz729 = document.getElementById("imgSqrs729").src;

    value45Save729 = "zSqrArtSpecz729";

    localStorage.setItem(value45Save729, sQz729);
};

function square730(){

    var sQz730 = document.getElementById("imgSqrs730").src;

    value45Save730 = "zSqrArtSpecz730";

    localStorage.setItem(value45Save730, sQz730);
};

function square731(){

    var sQz731 = document.getElementById("imgSqrs731").src;

    value45Save731 = "zSqrArtSpecz731";

    localStorage.setItem(value45Save731, sQz731);
};

function square732(){

    var sQz732 = document.getElementById("imgSqrs732").src;

    value45Save732 = "zSqrArtSpecz732";

    localStorage.setItem(value45Save732, sQz732);
};

function square733(){

    var sQz733 = document.getElementById("imgSqrs733").src;

    value45Save733 = "zSqrArtSpecz733";

    localStorage.setItem(value45Save733, sQz733);
};

function square734(){

    var sQz734 = document.getElementById("imgSqrs734").src;

    value45Save734 = "zSqrArtSpecz734";

    localStorage.setItem(value45Save734, sQz734);
};

function square735(){

    var sQz735 = document.getElementById("imgSqrs735").src;

    value45Save735 = "zSqrArtSpecz735";

    localStorage.setItem(value45Save735, sQz735);
};

function square736(){

    var sQz736 = document.getElementById("imgSqrs736").src;

    value45Save736 = "zSqrArtSpecz736";

    localStorage.setItem(value45Save736, sQz736);
};

function square737(){

    var sQz737 = document.getElementById("imgSqrs737").src;

    value45Save737 = "zSqrArtSpecz737";

    localStorage.setItem(value45Save737, sQz737);
};

function square738(){

    var sQz738 = document.getElementById("imgSqrs738").src;

    value45Save738 = "zSqrArtSpecz738";

    localStorage.setItem(value45Save738, sQz738);
};

function square739(){

    var sQz739 = document.getElementById("imgSqrs739").src;

    value45Save739 = "zSqrArtSpecz739";

    localStorage.setItem(value45Save739, sQz739);
};

function square740(){

    var sQz740 = document.getElementById("imgSqrs740").src;

    value45Save740 = "zSqrArtSpecz740";

    localStorage.setItem(value45Save740, sQz740);
};

function square741(){

    var sQz741 = document.getElementById("imgSqrs741").src;

    value45Save741 = "zSqrArtSpecz741";

    localStorage.setItem(value45Save741, sQz741);
};

function square742(){

    var sQz742 = document.getElementById("imgSqrs742").src;

    value45Save742 = "zSqrArtSpecz742";

    localStorage.setItem(value45Save742, sQz742);
};

function square743(){

    var sQz743 = document.getElementById("imgSqrs743").src;

    value45Save743 = "zSqrArtSpecz743";

    localStorage.setItem(value45Save743, sQz743);
};

function square744(){

    var sQz744 = document.getElementById("imgSqrs744").src;

    value45Save744 = "zSqrArtSpecz744";

    localStorage.setItem(value45Save744, sQz744);
};

function square745(){

    var sQz745 = document.getElementById("imgSqrs745").src;

    value45Save745 = "zSqrArtSpecz745";

    localStorage.setItem(value45Save745, sQz745);
};

function square746(){

    var sQz746 = document.getElementById("imgSqrs746").src;

    value45Save746 = "zSqrArtSpecz746";

    localStorage.setItem(value45Save746, sQz746);
};

function square747(){

    var sQz747 = document.getElementById("imgSqrs747").src;

    value45Save747 = "zSqrArtSpecz747";

    localStorage.setItem(value45Save747, sQz747);
};

function square748(){

    var sQz748 = document.getElementById("imgSqrs748").src;

    value45Save748 = "zSqrArtSpecz748";

    localStorage.setItem(value45Save748, sQz748);
};

function square749(){

    var sQz749 = document.getElementById("imgSqrs749").src;

    value45Save749 = "zSqrArtSpecz749";

    localStorage.setItem(value45Save749, sQz749);
};

function square750(){

    var sQz750 = document.getElementById("imgSqrs750").src;

    value45Save750 = "zSqrArtSpecz750";

    localStorage.setItem(value45Save750, sQz750);
};

function square751(){

    var sQz751 = document.getElementById("imgSqrs751").src;

    value45Save751 = "zSqrArtSpecz751";

    localStorage.setItem(value45Save751, sQz751);
};

function square752(){

    var sQz752 = document.getElementById("imgSqrs752").src;

    value45Save752 = "zSqrArtSpecz752";

    localStorage.setItem(value45Save752, sQz752);
};

function square753(){

    var sQz753 = document.getElementById("imgSqrs753").src;

    value45Save753 = "zSqrArtSpecz753";

    localStorage.setItem(value45Save753, sQz753);
};

function square754(){

    var sQz754 = document.getElementById("imgSqrs754").src;

    value45Save754 = "zSqrArtSpecz754";

    localStorage.setItem(value45Save754, sQz754);
};

function square755(){

    var sQz755 = document.getElementById("imgSqrs755").src;

    value45Save755 = "zSqrArtSpecz755";

    localStorage.setItem(value45Save755, sQz755);
};

function square756(){

    var sQz756 = document.getElementById("imgSqrs756").src;

    value45Save756 = "zSqrArtSpecz756";

    localStorage.setItem(value45Save756, sQz756);
};

function square757(){

    var sQz757 = document.getElementById("imgSqrs757").src;

    value45Save757 = "zSqrArtSpecz757";

    localStorage.setItem(value45Save757, sQz757);
};

function square758(){

    var sQz758 = document.getElementById("imgSqrs758").src;

    value45Save758 = "zSqrArtSpecz758";

    localStorage.setItem(value45Save758, sQz758);
};

function square759(){

    var sQz759 = document.getElementById("imgSqrs759").src;

    value45Save759 = "zSqrArtSpecz759";

    localStorage.setItem(value45Save759, sQz759);
};

function square760(){

    var sQz760 = document.getElementById("imgSqrs760").src;

    value45Save760 = "zSqrArtSpecz760";

    localStorage.setItem(value45Save760, sQz760);
};

function square761(){

    var sQz761 = document.getElementById("imgSqrs761").src;

    value45Save761 = "zSqrArtSpecz761";

    localStorage.setItem(value45Save761, sQz761);
};

function square762(){

    var sQz762 = document.getElementById("imgSqrs762").src;

    value45Save762 = "zSqrArtSpecz762";

    localStorage.setItem(value45Save762, sQz762);
};

function square763(){

    var sQz763 = document.getElementById("imgSqrs763").src;

    value45Save763 = "zSqrArtSpecz763";

    localStorage.setItem(value45Save763, sQz763);
};

function square764(){

    var sQz764 = document.getElementById("imgSqrs764").src;

    value45Save764 = "zSqrArtSpecz764";

    localStorage.setItem(value45Save764, sQz764);
};

function square765(){

    var sQz765 = document.getElementById("imgSqrs765").src;

    value45Save765 = "zSqrArtSpecz765";

    localStorage.setItem(value45Save765, sQz765);
};

function square766(){

    var sQz766 = document.getElementById("imgSqrs766").src;

    value45Save766 = "zSqrArtSpecz766";

    localStorage.setItem(value45Save766, sQz766);
};

function square767(){

    var sQz767 = document.getElementById("imgSqrs767").src;

    value45Save767 = "zSqrArtSpecz767";

    localStorage.setItem(value45Save767, sQz767);
};

function square768(){

    var sQz768 = document.getElementById("imgSqrs768").src;

    value45Save768 = "zSqrArtSpecz768";

    localStorage.setItem(value45Save768, sQz768);
};

function square769(){

    var sQz769 = document.getElementById("imgSqrs769").src;

    value45Save769 = "zSqrArtSpecz769";

    localStorage.setItem(value45Save769, sQz769);
};

function square770(){

    var sQz770 = document.getElementById("imgSqrs770").src;

    value45Save770 = "zSqrArtSpecz770";

    localStorage.setItem(value45Save770, sQz770);
};

function square771(){

    var sQz771 = document.getElementById("imgSqrs771").src;

    value45Save771 = "zSqrArtSpecz771";

    localStorage.setItem(value45Save771, sQz771);
};

function square772(){

    var sQz772 = document.getElementById("imgSqrs772").src;

    value45Save772 = "zSqrArtSpecz772";

    localStorage.setItem(value45Save772, sQz772);
};

function square773(){

    var sQz773 = document.getElementById("imgSqrs773").src;

    value45Save773 = "zSqrArtSpecz773";

    localStorage.setItem(value45Save773, sQz773);
};

function square774(){

    var sQz774 = document.getElementById("imgSqrs774").src;

    value45Save774 = "zSqrArtSpecz774";

    localStorage.setItem(value45Save774, sQz774);
};

function square775(){

    var sQz775 = document.getElementById("imgSqrs775").src;

    value45Save775 = "zSqrArtSpecz775";

    localStorage.setItem(value45Save775, sQz775);
};

function square776(){

    var sQz776 = document.getElementById("imgSqrs776").src;

    value45Save776 = "zSqrArtSpecz776";

    localStorage.setItem(value45Save776, sQz776);
};

function square777(){

    var sQz777 = document.getElementById("imgSqrs777").src;

    value45Save777 = "zSqrArtSpecz777";

    localStorage.setItem(value45Save777, sQz777);
};

function square778(){

    var sQz778 = document.getElementById("imgSqrs778").src;

    value45Save778 = "zSqrArtSpecz778";

    localStorage.setItem(value45Save778, sQz778);
};

function square779(){

    var sQz779 = document.getElementById("imgSqrs779").src;

    value45Save779 = "zSqrArtSpecz779";

    localStorage.setItem(value45Save779, sQz779);
};

function square780(){

    var sQz780 = document.getElementById("imgSqrs780").src;

    value45Save780 = "zSqrArtSpecz780";

    localStorage.setItem(value45Save780, sQz780);
};

function square781(){

    var sQz781 = document.getElementById("imgSqrs781").src;

    value45Save781 = "zSqrArtSpecz781";

    localStorage.setItem(value45Save781, sQz781);
};

function square782(){

    var sQz782 = document.getElementById("imgSqrs782").src;

    value45Save782 = "zSqrArtSpecz782";

    localStorage.setItem(value45Save782, sQz782);
};

function square783(){

    var sQz783 = document.getElementById("imgSqrs783").src;

    value45Save783 = "zSqrArtSpecz783";

    localStorage.setItem(value45Save783, sQz783);
};

function square784(){

    var sQz784 = document.getElementById("imgSqrs784").src;

    value45Save784 = "zSqrArtSpecz784";

    localStorage.setItem(value45Save784, sQz784);
};

function square785(){

    var sQz785 = document.getElementById("imgSqrs785").src;

    value45Save785 = "zSqrArtSpecz785";

    localStorage.setItem(value45Save785, sQz785);
};

function square786(){

    var sQz786 = document.getElementById("imgSqrs786").src;

    value45Save786 = "zSqrArtSpecz786";

    localStorage.setItem(value45Save786, sQz786);
};

function square787(){

    var sQz787 = document.getElementById("imgSqrs787").src;

    value45Save787 = "zSqrArtSpecz787";

    localStorage.setItem(value45Save787, sQz787);
};

function square788(){

    var sQz788 = document.getElementById("imgSqrs788").src;

    value45Save788 = "zSqrArtSpecz788";

    localStorage.setItem(value45Save788, sQz788);
};

function square789(){

    var sQz789 = document.getElementById("imgSqrs789").src;

    value45Save789 = "zSqrArtSpecz789";

    localStorage.setItem(value45Save789, sQz789);
};

function square790(){

    var sQz790 = document.getElementById("imgSqrs790").src;

    value45Save790 = "zSqrArtSpecz790";

    localStorage.setItem(value45Save790, sQz790);
};

function square791(){

    var sQz791 = document.getElementById("imgSqrs791").src;

    value45Save791 = "zSqrArtSpecz791";

    localStorage.setItem(value45Save791, sQz791);
};

function square792(){

    var sQz792 = document.getElementById("imgSqrs792").src;

    value45Save792 = "zSqrArtSpecz792";

    localStorage.setItem(value45Save792, sQz792);
};

function square793(){

    var sQz793 = document.getElementById("imgSqrs793").src;

    value45Save793 = "zSqrArtSpecz793";

    localStorage.setItem(value45Save793, sQz793);
};

function square794(){

    var sQz794 = document.getElementById("imgSqrs794").src;

    value45Save794 = "zSqrArtSpecz794";

    localStorage.setItem(value45Save794, sQz794);
};

function square795(){

    var sQz795 = document.getElementById("imgSqrs795").src;

    value45Save795 = "zSqrArtSpecz795";

    localStorage.setItem(value45Save795, sQz795);
};

function square796(){

    var sQz796 = document.getElementById("imgSqrs796").src;

    value45Save796 = "zSqrArtSpecz796";

    localStorage.setItem(value45Save796, sQz796);
};

function square797(){

    var sQz797 = document.getElementById("imgSqrs797").src;

    value45Save797 = "zSqrArtSpecz797";

    localStorage.setItem(value45Save797, sQz797);
};

function square798(){

    var sQz798 = document.getElementById("imgSqrs798").src;

    value45Save798 = "zSqrArtSpecz798";

    localStorage.setItem(value45Save798, sQz798);
};

function square799(){

    var sQz799 = document.getElementById("imgSqrs799").src;

    value45Save799 = "zSqrArtSpecz799";

    localStorage.setItem(value45Save799, sQz799);
};

function square800(){

    var sQz800 = document.getElementById("imgSqrs800").src;

    value45Save800 = "zSqrArtSpecz800";

    localStorage.setItem(value45Save800, sQz800);
};

function square801(){

    var sQz801 = document.getElementById("imgSqrs801").src;

    value45Save801 = "zSqrArtSpecz801";

    localStorage.setItem(value45Save801, sQz801);
};

function square802(){

    var sQz802 = document.getElementById("imgSqrs802").src;

    value45Save802 = "zSqrArtSpecz802";

    localStorage.setItem(value45Save802, sQz802);
};

function square803(){

    var sQz803 = document.getElementById("imgSqrs803").src;

    value45Save803 = "zSqrArtSpecz803";

    localStorage.setItem(value45Save803, sQz803);
};

function square804(){

    var sQz804 = document.getElementById("imgSqrs804").src;

    value45Save804 = "zSqrArtSpecz804";

    localStorage.setItem(value45Save804, sQz804);
};

function square805(){

    var sQz805 = document.getElementById("imgSqrs805").src;

    value45Save805 = "zSqrArtSpecz805";

    localStorage.setItem(value45Save805, sQz805);
};

function square806(){

    var sQz806 = document.getElementById("imgSqrs806").src;

    value45Save806 = "zSqrArtSpecz806";

    localStorage.setItem(value45Save806, sQz806);
};

function square807(){

    var sQz807 = document.getElementById("imgSqrs807").src;

    value45Save807 = "zSqrArtSpecz807";

    localStorage.setItem(value45Save807, sQz807);
};

function square808(){

    var sQz808 = document.getElementById("imgSqrs808").src;

    value45Save808 = "zSqrArtSpecz808";

    localStorage.setItem(value45Save808, sQz808);
};

function square809(){

    var sQz809 = document.getElementById("imgSqrs809").src;

    value45Save809 = "zSqrArtSpecz809";

    localStorage.setItem(value45Save809, sQz809);
};

function square810(){

    var sQz810 = document.getElementById("imgSqrs810").src;

    value45Save810 = "zSqrArtSpecz810";

    localStorage.setItem(value45Save810, sQz810);
};

function square811(){

    var sQz811 = document.getElementById("imgSqrs811").src;

    value45Save811 = "zSqrArtSpecz811";

    localStorage.setItem(value45Save811, sQz811);
};

function square812(){

    var sQz812 = document.getElementById("imgSqrs812").src;

    value45Save812 = "zSqrArtSpecz812";

    localStorage.setItem(value45Save812, sQz812);
};

function square813(){

    var sQz813 = document.getElementById("imgSqrs813").src;

    value45Save813 = "zSqrArtSpecz813";

    localStorage.setItem(value45Save813, sQz813);
};

function square814(){

    var sQz814 = document.getElementById("imgSqrs814").src;

    value45Save814 = "zSqrArtSpecz814";

    localStorage.setItem(value45Save814, sQz814);
};

function square815(){

    var sQz815 = document.getElementById("imgSqrs815").src;

    value45Save815 = "zSqrArtSpecz815";

    localStorage.setItem(value45Save815, sQz815);
};

function square816(){

    var sQz816 = document.getElementById("imgSqrs816").src;

    value45Save816 = "zSqrArtSpecz816";

    localStorage.setItem(value45Save816, sQz816);
};

function square817(){

    var sQz817 = document.getElementById("imgSqrs817").src;

    value45Save817 = "zSqrArtSpecz817";

    localStorage.setItem(value45Save817, sQz817);
};

function square818(){

    var sQz818 = document.getElementById("imgSqrs818").src;

    value45Save818 = "zSqrArtSpecz818";

    localStorage.setItem(value45Save818, sQz818);
};

function square819(){

    var sQz819 = document.getElementById("imgSqrs819").src;

    value45Save819 = "zSqrArtSpecz819";

    localStorage.setItem(value45Save819, sQz819);
};

function square820(){

    var sQz820 = document.getElementById("imgSqrs820").src;

    value45Save820 = "zSqrArtSpecz820";

    localStorage.setItem(value45Save820, sQz820);
};

function square821(){

    var sQz821 = document.getElementById("imgSqrs821").src;

    value45Save821 = "zSqrArtSpecz821";

    localStorage.setItem(value45Save821, sQz821);
};

function square822(){

    var sQz822 = document.getElementById("imgSqrs822").src;

    value45Save822 = "zSqrArtSpecz822";

    localStorage.setItem(value45Save822, sQz822);
};

function square823(){

    var sQz823 = document.getElementById("imgSqrs823").src;

    value45Save823 = "zSqrArtSpecz823";

    localStorage.setItem(value45Save823, sQz823);
};

function square824(){

    var sQz824 = document.getElementById("imgSqrs824").src;

    value45Save824 = "zSqrArtSpecz824";

    localStorage.setItem(value45Save824, sQz824);
};

function square825(){

    var sQz825 = document.getElementById("imgSqrs825").src;

    value45Save825 = "zSqrArtSpecz825";

    localStorage.setItem(value45Save825, sQz825);
};

function square826(){

    var sQz826 = document.getElementById("imgSqrs826").src;

    value45Save826 = "zSqrArtSpecz826";

    localStorage.setItem(value45Save826, sQz826);
};

function square827(){

    var sQz827 = document.getElementById("imgSqrs827").src;

    value45Save827 = "zSqrArtSpecz827";

    localStorage.setItem(value45Save827, sQz827);
};

function square828(){

    var sQz828 = document.getElementById("imgSqrs828").src;

    value45Save828 = "zSqrArtSpecz828";

    localStorage.setItem(value45Save828, sQz828);
};

function square829(){

    var sQz829 = document.getElementById("imgSqrs829").src;

    value45Save829 = "zSqrArtSpecz829";

    localStorage.setItem(value45Save829, sQz829);
};

function square830(){

    var sQz830 = document.getElementById("imgSqrs830").src;

    value45Save830 = "zSqrArtSpecz830";

    localStorage.setItem(value45Save830, sQz830);
};

function square831(){

    var sQz831 = document.getElementById("imgSqrs831").src;

    value45Save831 = "zSqrArtSpecz831";

    localStorage.setItem(value45Save831, sQz831);
};

function square832(){

    var sQz832 = document.getElementById("imgSqrs832").src;

    value45Save832 = "zSqrArtSpecz832";

    localStorage.setItem(value45Save832, sQz832);
};

function square833(){

    var sQz833 = document.getElementById("imgSqrs833").src;

    value45Save833 = "zSqrArtSpecz833";

    localStorage.setItem(value45Save833, sQz833);
};

function square834(){

    var sQz834 = document.getElementById("imgSqrs834").src;

    value45Save834 = "zSqrArtSpecz834";

    localStorage.setItem(value45Save834, sQz834);
};

function square835(){

    var sQz835 = document.getElementById("imgSqrs835").src;

    value45Save835 = "zSqrArtSpecz835";

    localStorage.setItem(value45Save835, sQz835);
};

function square836(){

    var sQz836 = document.getElementById("imgSqrs836").src;

    value45Save836 = "zSqrArtSpecz836";

    localStorage.setItem(value45Save836, sQz836);
};

function square837(){

    var sQz837 = document.getElementById("imgSqrs837").src;

    value45Save837 = "zSqrArtSpecz837";

    localStorage.setItem(value45Save837, sQz837);
};

function square838(){

    var sQz838 = document.getElementById("imgSqrs838").src;

    value45Save838 = "zSqrArtSpecz838";

    localStorage.setItem(value45Save838, sQz838);
};

function square839(){

    var sQz839 = document.getElementById("imgSqrs839").src;

    value45Save839 = "zSqrArtSpecz839";

    localStorage.setItem(value45Save839, sQz839);
};

function square840(){

    var sQz840 = document.getElementById("imgSqrs840").src;

    value45Save840 = "zSqrArtSpecz840";

    localStorage.setItem(value45Save840, sQz840);
};

function square841(){

    var sQz841 = document.getElementById("imgSqrs841").src;

    value45Save841 = "zSqrArtSpecz841";

    localStorage.setItem(value45Save841, sQz841);
};

function square842(){

    var sQz842 = document.getElementById("imgSqrs842").src;

    value45Save842 = "zSqrArtSpecz842";

    localStorage.setItem(value45Save842, sQz842);
};

function square843(){

    var sQz843 = document.getElementById("imgSqrs843").src;

    value45Save843 = "zSqrArtSpecz843";

    localStorage.setItem(value45Save843, sQz843);
};

function square844(){

    var sQz844 = document.getElementById("imgSqrs844").src;

    value45Save844 = "zSqrArtSpecz844";

    localStorage.setItem(value45Save844, sQz844);
};

function square845(){

    var sQz845 = document.getElementById("imgSqrs845").src;

    value45Save845 = "zSqrArtSpecz845";

    localStorage.setItem(value45Save845, sQz845);
};

function square846(){

    var sQz846 = document.getElementById("imgSqrs846").src;

    value45Save846 = "zSqrArtSpecz846";

    localStorage.setItem(value45Save846, sQz846);
};

function square847(){

    var sQz847 = document.getElementById("imgSqrs847").src;

    value45Save847 = "zSqrArtSpecz847";

    localStorage.setItem(value45Save847, sQz847);
};

function square848(){

    var sQz848 = document.getElementById("imgSqrs848").src;

    value45Save848 = "zSqrArtSpecz848";

    localStorage.setItem(value45Save848, sQz848);
};

function square849(){

    var sQz849 = document.getElementById("imgSqrs849").src;

    value45Save849 = "zSqrArtSpecz849";

    localStorage.setItem(value45Save849, sQz849);
};

function square850(){

    var sQz850 = document.getElementById("imgSqrs850").src;

    value45Save850 = "zSqrArtSpecz850";

    localStorage.setItem(value45Save850, sQz850);
};

function square851(){

    var sQz851 = document.getElementById("imgSqrs851").src;

    value45Save851 = "zSqrArtSpecz851";

    localStorage.setItem(value45Save851, sQz851);
};

function square852(){

    var sQz852 = document.getElementById("imgSqrs852").src;

    value45Save852 = "zSqrArtSpecz852";

    localStorage.setItem(value45Save852, sQz852);
};

function square853(){

    var sQz853 = document.getElementById("imgSqrs853").src;

    value45Save853 = "zSqrArtSpecz853";

    localStorage.setItem(value45Save853, sQz853);
};

function square854(){

    var sQz854 = document.getElementById("imgSqrs854").src;

    value45Save854 = "zSqrArtSpecz854";

    localStorage.setItem(value45Save854, sQz854);
};

function square855(){

    var sQz855 = document.getElementById("imgSqrs855").src;

    value45Save855 = "zSqrArtSpecz855";

    localStorage.setItem(value45Save855, sQz855);
};

function square856(){

    var sQz856 = document.getElementById("imgSqrs856").src;

    value45Save856 = "zSqrArtSpecz856";

    localStorage.setItem(value45Save856, sQz856);
};

function square857(){

    var sQz857 = document.getElementById("imgSqrs857").src;

    value45Save857 = "zSqrArtSpecz857";

    localStorage.setItem(value45Save857, sQz857);
};

function square858(){

    var sQz858 = document.getElementById("imgSqrs858").src;

    value45Save858 = "zSqrArtSpecz858";

    localStorage.setItem(value45Save858, sQz858);
};

function square859(){

    var sQz859 = document.getElementById("imgSqrs859").src;

    value45Save859 = "zSqrArtSpecz859";

    localStorage.setItem(value45Save859, sQz859);
};

function square860(){

    var sQz860 = document.getElementById("imgSqrs860").src;

    value45Save860 = "zSqrArtSpecz860";

    localStorage.setItem(value45Save860, sQz860);
};

function square861(){

    var sQz861 = document.getElementById("imgSqrs861").src;

    value45Save861 = "zSqrArtSpecz861";

    localStorage.setItem(value45Save861, sQz861);
};

function square862(){

    var sQz862 = document.getElementById("imgSqrs862").src;

    value45Save862 = "zSqrArtSpecz862";

    localStorage.setItem(value45Save862, sQz862);
};

function square863(){

    var sQz863 = document.getElementById("imgSqrs863").src;

    value45Save863 = "zSqrArtSpecz863";

    localStorage.setItem(value45Save863, sQz863);
};

function square864(){

    var sQz864 = document.getElementById("imgSqrs864").src;

    value45Save864 = "zSqrArtSpecz864";

    localStorage.setItem(value45Save864, sQz864);
};

function square865(){

    var sQz865 = document.getElementById("imgSqrs865").src;

    value45Save865 = "zSqrArtSpecz865";

    localStorage.setItem(value45Save865, sQz865);
};

function square866(){

    var sQz866 = document.getElementById("imgSqrs866").src;

    value45Save866 = "zSqrArtSpecz866";

    localStorage.setItem(value45Save866, sQz866);
};

function square867(){

    var sQz867 = document.getElementById("imgSqrs867").src;

    value45Save867 = "zSqrArtSpecz867";

    localStorage.setItem(value45Save867, sQz867);
};

function square868(){

    var sQz868 = document.getElementById("imgSqrs868").src;

    value45Save868 = "zSqrArtSpecz868";

    localStorage.setItem(value45Save868, sQz868);
};

function square869(){

    var sQz869 = document.getElementById("imgSqrs869").src;

    value45Save869 = "zSqrArtSpecz869";

    localStorage.setItem(value45Save869, sQz869);
};

function square870(){

    var sQz870 = document.getElementById("imgSqrs870").src;

    value45Save870 = "zSqrArtSpecz870";

    localStorage.setItem(value45Save870, sQz870);
};

function square871(){

    var sQz871 = document.getElementById("imgSqrs871").src;

    value45Save871 = "zSqrArtSpecz871";

    localStorage.setItem(value45Save871, sQz871);
};

function square872(){

    var sQz872 = document.getElementById("imgSqrs872").src;

    value45Save872 = "zSqrArtSpecz872";

    localStorage.setItem(value45Save872, sQz872);
};

function square873(){

    var sQz873 = document.getElementById("imgSqrs873").src;

    value45Save873 = "zSqrArtSpecz873";

    localStorage.setItem(value45Save873, sQz873);
};

function square874(){

    var sQz874 = document.getElementById("imgSqrs874").src;

    value45Save874 = "zSqrArtSpecz874";

    localStorage.setItem(value45Save874, sQz874);
};

function square875(){

    var sQz875 = document.getElementById("imgSqrs875").src;

    value45Save875 = "zSqrArtSpecz875";

    localStorage.setItem(value45Save875, sQz875);
};

function square876(){

    var sQz876 = document.getElementById("imgSqrs876").src;

    value45Save876 = "zSqrArtSpecz876";

    localStorage.setItem(value45Save876, sQz876);
};

function square877(){

    var sQz877 = document.getElementById("imgSqrs877").src;

    value45Save877 = "zSqrArtSpecz877";

    localStorage.setItem(value45Save877, sQz877);
};

function square878(){

    var sQz878 = document.getElementById("imgSqrs878").src;

    value45Save878 = "zSqrArtSpecz878";

    localStorage.setItem(value45Save878, sQz878);
};

function square879(){

    var sQz879 = document.getElementById("imgSqrs879").src;

    value45Save879 = "zSqrArtSpecz879";

    localStorage.setItem(value45Save879, sQz879);
};

function square880(){

    var sQz880 = document.getElementById("imgSqrs880").src;

    value45Save880 = "zSqrArtSpecz880";

    localStorage.setItem(value45Save880, sQz880);
};

function square881(){

    var sQz881 = document.getElementById("imgSqrs881").src;

    value45Save881 = "zSqrArtSpecz881";

    localStorage.setItem(value45Save881, sQz881);
};

function square882(){

    var sQz882 = document.getElementById("imgSqrs882").src;

    value45Save882 = "zSqrArtSpecz882";

    localStorage.setItem(value45Save882, sQz882);
};

function square883(){

    var sQz883 = document.getElementById("imgSqrs883").src;

    value45Save883 = "zSqrArtSpecz883";

    localStorage.setItem(value45Save883, sQz883);
};

function square884(){

    var sQz884 = document.getElementById("imgSqrs884").src;

    value45Save884 = "zSqrArtSpecz884";

    localStorage.setItem(value45Save884, sQz884);
};

function square885(){

    var sQz885 = document.getElementById("imgSqrs885").src;

    value45Save885 = "zSqrArtSpecz885";

    localStorage.setItem(value45Save885, sQz885);
};

function square886(){

    var sQz886 = document.getElementById("imgSqrs886").src;

    value45Save886 = "zSqrArtSpecz886";

    localStorage.setItem(value45Save886, sQz886);
};

function square887(){

    var sQz887 = document.getElementById("imgSqrs887").src;

    value45Save887 = "zSqrArtSpecz887";

    localStorage.setItem(value45Save887, sQz887);
};

function square888(){

    var sQz888 = document.getElementById("imgSqrs888").src;

    value45Save888 = "zSqrArtSpecz888";

    localStorage.setItem(value45Save888, sQz888);
};

function square889(){

    var sQz889 = document.getElementById("imgSqrs889").src;

    value45Save889 = "zSqrArtSpecz889";

    localStorage.setItem(value45Save889, sQz889);
};

function square890(){

    var sQz890 = document.getElementById("imgSqrs890").src;

    value45Save890 = "zSqrArtSpecz890";

    localStorage.setItem(value45Save890, sQz890);
};

function square891(){

    var sQz891 = document.getElementById("imgSqrs891").src;

    value45Save891 = "zSqrArtSpecz891";

    localStorage.setItem(value45Save891, sQz891);
};

function square892(){

    var sQz892 = document.getElementById("imgSqrs892").src;

    value45Save892 = "zSqrArtSpecz892";

    localStorage.setItem(value45Save892, sQz892);
};

function square893(){

    var sQz893 = document.getElementById("imgSqrs893").src;

    value45Save893 = "zSqrArtSpecz893";

    localStorage.setItem(value45Save893, sQz893);
};

function square894(){

    var sQz894 = document.getElementById("imgSqrs894").src;

    value45Save894 = "zSqrArtSpecz894";

    localStorage.setItem(value45Save894, sQz894);
};

function square895(){

    var sQz895 = document.getElementById("imgSqrs895").src;

    value45Save895 = "zSqrArtSpecz895";

    localStorage.setItem(value45Save895, sQz895);
};

function square896(){

    var sQz896 = document.getElementById("imgSqrs896").src;

    value45Save896 = "zSqrArtSpecz896";

    localStorage.setItem(value45Save896, sQz896);
};

function square897(){

    var sQz897 = document.getElementById("imgSqrs897").src;

    value45Save897 = "zSqrArtSpecz897";

    localStorage.setItem(value45Save897, sQz897);
};

function square898(){

    var sQz898 = document.getElementById("imgSqrs898").src;

    value45Save898 = "zSqrArtSpecz898";

    localStorage.setItem(value45Save898, sQz898);
};

function square899(){

    var sQz899 = document.getElementById("imgSqrs899").src;

    value45Save899 = "zSqrArtSpecz899";

    localStorage.setItem(value45Save899, sQz899);
};

function square900(){

    var sQz900 = document.getElementById("imgSqrs900").src;

    value45Save900 = "zSqrArtSpecz900";

    localStorage.setItem(value45Save900, sQz900);
};

function square901(){

    var sQz901 = document.getElementById("imgSqrs901").src;

    value45Save901 = "zSqrArtSpecz901";

    localStorage.setItem(value45Save901, sQz901);
};

function square902(){

    var sQz902 = document.getElementById("imgSqrs902").src;

    value45Save902 = "zSqrArtSpecz902";

    localStorage.setItem(value45Save902, sQz902);
};

function square903(){

    var sQz903 = document.getElementById("imgSqrs903").src;

    value45Save903 = "zSqrArtSpecz903";

    localStorage.setItem(value45Save903, sQz903);
};

function square904(){

    var sQz904 = document.getElementById("imgSqrs904").src;

    value45Save904 = "zSqrArtSpecz904";

    localStorage.setItem(value45Save904, sQz904);
};

function square905(){

    var sQz905 = document.getElementById("imgSqrs905").src;

    value45Save905 = "zSqrArtSpecz905";

    localStorage.setItem(value45Save905, sQz905);
};

function square906(){

    var sQz906 = document.getElementById("imgSqrs906").src;

    value45Save906 = "zSqrArtSpecz906";

    localStorage.setItem(value45Save906, sQz906);
};

function square907(){

    var sQz907 = document.getElementById("imgSqrs907").src;

    value45Save907 = "zSqrArtSpecz907";

    localStorage.setItem(value45Save907, sQz907);
};

function square908(){

    var sQz908 = document.getElementById("imgSqrs908").src;

    value45Save908 = "zSqrArtSpecz908";

    localStorage.setItem(value45Save908, sQz908);
};

function square909(){

    var sQz909 = document.getElementById("imgSqrs909").src;

    value45Save909 = "zSqrArtSpecz909";

    localStorage.setItem(value45Save909, sQz909);
};

function square910(){

    var sQz910 = document.getElementById("imgSqrs910").src;

    value45Save910 = "zSqrArtSpecz910";

    localStorage.setItem(value45Save910, sQz910);
};

function square911(){

    var sQz911 = document.getElementById("imgSqrs911").src;

    value45Save911 = "zSqrArtSpecz911";

    localStorage.setItem(value45Save911, sQz911);
};

function square912(){

    var sQz912 = document.getElementById("imgSqrs912").src;

    value45Save912 = "zSqrArtSpecz912";

    localStorage.setItem(value45Save912, sQz912);
};

function square913(){

    var sQz913 = document.getElementById("imgSqrs913").src;

    value45Save913 = "zSqrArtSpecz913";

    localStorage.setItem(value45Save913, sQz913);
};

function square914(){

    var sQz914 = document.getElementById("imgSqrs914").src;

    value45Save914 = "zSqrArtSpecz914";

    localStorage.setItem(value45Save914, sQz914);
};

function square915(){

    var sQz915 = document.getElementById("imgSqrs915").src;

    value45Save915 = "zSqrArtSpecz915";

    localStorage.setItem(value45Save915, sQz915);
};

function square916(){

    var sQz916 = document.getElementById("imgSqrs916").src;

    value45Save916 = "zSqrArtSpecz916";

    localStorage.setItem(value45Save916, sQz916);
};

function square917(){

    var sQz917 = document.getElementById("imgSqrs917").src;

    value45Save917 = "zSqrArtSpecz917";

    localStorage.setItem(value45Save917, sQz917);
};

function square918(){

    var sQz918 = document.getElementById("imgSqrs918").src;

    value45Save918 = "zSqrArtSpecz918";

    localStorage.setItem(value45Save918, sQz918);
};

function square919(){

    var sQz919 = document.getElementById("imgSqrs919").src;

    value45Save919 = "zSqrArtSpecz919";

    localStorage.setItem(value45Save919, sQz919);
};

function square920(){

    var sQz920 = document.getElementById("imgSqrs920").src;

    value45Save920 = "zSqrArtSpecz920";

    localStorage.setItem(value45Save920, sQz920);
};

function square921(){

    var sQz921 = document.getElementById("imgSqrs921").src;

    value45Save921 = "zSqrArtSpecz921";

    localStorage.setItem(value45Save921, sQz921);
};

function square922(){

    var sQz922 = document.getElementById("imgSqrs922").src;

    value45Save922 = "zSqrArtSpecz922";

    localStorage.setItem(value45Save922, sQz922);
};

function square923(){

    var sQz923 = document.getElementById("imgSqrs923").src;

    value45Save923 = "zSqrArtSpecz923";

    localStorage.setItem(value45Save923, sQz923);
};

function square924(){

    var sQz924 = document.getElementById("imgSqrs924").src;

    value45Save924 = "zSqrArtSpecz924";

    localStorage.setItem(value45Save924, sQz924);
};

function square925(){

    var sQz925 = document.getElementById("imgSqrs925").src;

    value45Save925 = "zSqrArtSpecz925";

    localStorage.setItem(value45Save925, sQz925);
};

function square926(){

    var sQz926 = document.getElementById("imgSqrs926").src;

    value45Save926 = "zSqrArtSpecz926";

    localStorage.setItem(value45Save926, sQz926);
};

function square927(){

    var sQz927 = document.getElementById("imgSqrs927").src;

    value45Save927 = "zSqrArtSpecz927";

    localStorage.setItem(value45Save927, sQz927);
};

function square928(){

    var sQz928 = document.getElementById("imgSqrs928").src;

    value45Save928 = "zSqrArtSpecz928";

    localStorage.setItem(value45Save928, sQz928);
};

function square929(){

    var sQz929 = document.getElementById("imgSqrs929").src;

    value45Save929 = "zSqrArtSpecz929";

    localStorage.setItem(value45Save929, sQz929);
};

function square930(){

    var sQz930 = document.getElementById("imgSqrs930").src;

    value45Save930 = "zSqrArtSpecz930";

    localStorage.setItem(value45Save930, sQz930);
};

function square931(){

    var sQz931 = document.getElementById("imgSqrs931").src;

    value45Save931 = "zSqrArtSpecz931";

    localStorage.setItem(value45Save931, sQz931);
};

function square932(){

    var sQz932 = document.getElementById("imgSqrs932").src;

    value45Save932 = "zSqrArtSpecz932";

    localStorage.setItem(value45Save932, sQz932);
};

function square933(){

    var sQz933 = document.getElementById("imgSqrs933").src;

    value45Save933 = "zSqrArtSpecz933";

    localStorage.setItem(value45Save933, sQz933);
};

function square934(){

    var sQz934 = document.getElementById("imgSqrs934").src;

    value45Save934 = "zSqrArtSpecz934";

    localStorage.setItem(value45Save934, sQz934);
};

function square935(){

    var sQz935 = document.getElementById("imgSqrs935").src;

    value45Save935 = "zSqrArtSpecz935";

    localStorage.setItem(value45Save935, sQz935);
};

function square936(){

    var sQz936 = document.getElementById("imgSqrs936").src;

    value45Save936 = "zSqrArtSpecz936";

    localStorage.setItem(value45Save936, sQz936);
};

function square937(){

    var sQz937 = document.getElementById("imgSqrs937").src;

    value45Save937 = "zSqrArtSpecz937";

    localStorage.setItem(value45Save937, sQz937);
};

function square938(){

    var sQz938 = document.getElementById("imgSqrs938").src;

    value45Save938 = "zSqrArtSpecz938";

    localStorage.setItem(value45Save938, sQz938);
};

function square939(){

    var sQz939 = document.getElementById("imgSqrs939").src;

    value45Save939 = "zSqrArtSpecz939";

    localStorage.setItem(value45Save939, sQz939);
};

function square940(){

    var sQz940 = document.getElementById("imgSqrs940").src;

    value45Save940 = "zSqrArtSpecz940";

    localStorage.setItem(value45Save940, sQz940);
};

function square941(){

    var sQz941 = document.getElementById("imgSqrs941").src;

    value45Save941 = "zSqrArtSpecz941";

    localStorage.setItem(value45Save941, sQz941);
};

function square942(){

    var sQz942 = document.getElementById("imgSqrs942").src;

    value45Save942 = "zSqrArtSpecz942";

    localStorage.setItem(value45Save942, sQz942);
};

function square943(){

    var sQz943 = document.getElementById("imgSqrs943").src;

    value45Save943 = "zSqrArtSpecz943";

    localStorage.setItem(value45Save943, sQz943);
};

function square944(){

    var sQz944 = document.getElementById("imgSqrs944").src;

    value45Save944 = "zSqrArtSpecz944";

    localStorage.setItem(value45Save944, sQz944);
};

function square945(){

    var sQz945 = document.getElementById("imgSqrs945").src;

    value45Save945 = "zSqrArtSpecz945";

    localStorage.setItem(value45Save945, sQz945);
};

function square946(){

    var sQz946 = document.getElementById("imgSqrs946").src;

    value45Save946 = "zSqrArtSpecz946";

    localStorage.setItem(value45Save946, sQz946);
};

function square947(){

    var sQz947 = document.getElementById("imgSqrs947").src;

    value45Save947 = "zSqrArtSpecz947";

    localStorage.setItem(value45Save947, sQz947);
};

function square948(){

    var sQz948 = document.getElementById("imgSqrs948").src;

    value45Save948 = "zSqrArtSpecz948";

    localStorage.setItem(value45Save948, sQz948);
};

function square949(){

    var sQz949 = document.getElementById("imgSqrs949").src;

    value45Save949 = "zSqrArtSpecz949";

    localStorage.setItem(value45Save949, sQz949);
};

function square950(){

    var sQz950 = document.getElementById("imgSqrs950").src;

    value45Save950 = "zSqrArtSpecz950";

    localStorage.setItem(value45Save950, sQz950);
};

function square951(){

    var sQz951 = document.getElementById("imgSqrs951").src;

    value45Save951 = "zSqrArtSpecz951";

    localStorage.setItem(value45Save951, sQz951);
};

function square952(){

    var sQz952 = document.getElementById("imgSqrs952").src;

    value45Save952 = "zSqrArtSpecz952";

    localStorage.setItem(value45Save952, sQz952);
};

function square953(){

    var sQz953 = document.getElementById("imgSqrs953").src;

    value45Save953 = "zSqrArtSpecz953";

    localStorage.setItem(value45Save953, sQz953);
};

function square954(){

    var sQz954 = document.getElementById("imgSqrs954").src;

    value45Save954 = "zSqrArtSpecz954";

    localStorage.setItem(value45Save954, sQz954);
};

function square955(){

    var sQz955 = document.getElementById("imgSqrs955").src;

    value45Save955 = "zSqrArtSpecz955";

    localStorage.setItem(value45Save955, sQz955);
};

function square956(){

    var sQz956 = document.getElementById("imgSqrs956").src;

    value45Save956 = "zSqrArtSpecz956";

    localStorage.setItem(value45Save956, sQz956);
};

function square957(){

    var sQz957 = document.getElementById("imgSqrs957").src;

    value45Save957 = "zSqrArtSpecz957";

    localStorage.setItem(value45Save957, sQz957);
};

function square958(){

    var sQz958 = document.getElementById("imgSqrs958").src;

    value45Save958 = "zSqrArtSpecz958";

    localStorage.setItem(value45Save958, sQz958);
};

function square959(){

    var sQz959 = document.getElementById("imgSqrs959").src;

    value45Save959 = "zSqrArtSpecz959";

    localStorage.setItem(value45Save959, sQz959);
};

function square960(){

    var sQz960 = document.getElementById("imgSqrs960").src;

    value45Save960 = "zSqrArtSpecz960";

    localStorage.setItem(value45Save960, sQz960);
};

function square961(){

    var sQz961 = document.getElementById("imgSqrs961").src;

    value45Save961 = "zSqrArtSpecz961";

    localStorage.setItem(value45Save961, sQz961);
};

function square962(){

    var sQz962 = document.getElementById("imgSqrs962").src;

    value45Save962 = "zSqrArtSpecz962";

    localStorage.setItem(value45Save962, sQz962);
};

function square963(){

    var sQz963 = document.getElementById("imgSqrs963").src;

    value45Save963 = "zSqrArtSpecz963";

    localStorage.setItem(value45Save963, sQz963);
};

function square964(){

    var sQz964 = document.getElementById("imgSqrs964").src;

    value45Save964 = "zSqrArtSpecz964";

    localStorage.setItem(value45Save964, sQz964);
};

function square965(){

    var sQz965 = document.getElementById("imgSqrs965").src;

    value45Save965 = "zSqrArtSpecz965";

    localStorage.setItem(value45Save965, sQz965);
};

function square966(){

    var sQz966 = document.getElementById("imgSqrs966").src;

    value45Save966 = "zSqrArtSpecz966";

    localStorage.setItem(value45Save966, sQz966);
};

function square967(){

    var sQz967 = document.getElementById("imgSqrs967").src;

    value45Save967 = "zSqrArtSpecz967";

    localStorage.setItem(value45Save967, sQz967);
};

function square968(){

    var sQz968 = document.getElementById("imgSqrs968").src;

    value45Save968 = "zSqrArtSpecz968";

    localStorage.setItem(value45Save968, sQz968);
};

function square969(){

    var sQz969 = document.getElementById("imgSqrs969").src;

    value45Save969 = "zSqrArtSpecz969";

    localStorage.setItem(value45Save969, sQz969);
};

function square970(){

    var sQz970 = document.getElementById("imgSqrs970").src;

    value45Save970 = "zSqrArtSpecz970";

    localStorage.setItem(value45Save970, sQz970);
};

function square971(){

    var sQz971 = document.getElementById("imgSqrs971").src;

    value45Save971 = "zSqrArtSpecz971";

    localStorage.setItem(value45Save971, sQz971);
};

function square972(){

    var sQz972 = document.getElementById("imgSqrs972").src;

    value45Save972 = "zSqrArtSpecz972";

    localStorage.setItem(value45Save972, sQz972);
};

function square973(){

    var sQz973 = document.getElementById("imgSqrs973").src;

    value45Save973 = "zSqrArtSpecz973";

    localStorage.setItem(value45Save973, sQz973);
};

function square974(){

    var sQz974 = document.getElementById("imgSqrs974").src;

    value45Save974 = "zSqrArtSpecz974";

    localStorage.setItem(value45Save974, sQz974);
};

function square975(){

    var sQz975 = document.getElementById("imgSqrs975").src;

    value45Save975 = "zSqrArtSpecz975";

    localStorage.setItem(value45Save975, sQz975);
};

function square976(){

    var sQz976 = document.getElementById("imgSqrs976").src;

    value45Save976 = "zSqrArtSpecz976";

    localStorage.setItem(value45Save976, sQz976);
};

function square977(){

    var sQz977 = document.getElementById("imgSqrs977").src;

    value45Save977 = "zSqrArtSpecz977";

    localStorage.setItem(value45Save977, sQz977);
};

function square978(){

    var sQz978 = document.getElementById("imgSqrs978").src;

    value45Save978 = "zSqrArtSpecz978";

    localStorage.setItem(value45Save978, sQz978);
};

function square979(){

    var sQz979 = document.getElementById("imgSqrs979").src;

    value45Save979 = "zSqrArtSpecz979";

    localStorage.setItem(value45Save979, sQz979);
};

function square980(){

    var sQz980 = document.getElementById("imgSqrs980").src;

    value45Save980 = "zSqrArtSpecz980";

    localStorage.setItem(value45Save980, sQz980);
};

function square981(){

    var sQz981 = document.getElementById("imgSqrs981").src;

    value45Save981 = "zSqrArtSpecz981";

    localStorage.setItem(value45Save981, sQz981);
};

function square982(){

    var sQz982 = document.getElementById("imgSqrs982").src;

    value45Save982 = "zSqrArtSpecz982";

    localStorage.setItem(value45Save982, sQz982);
};

function square983(){

    var sQz983 = document.getElementById("imgSqrs983").src;

    value45Save983 = "zSqrArtSpecz983";

    localStorage.setItem(value45Save983, sQz983);
};

function square984(){

    var sQz984 = document.getElementById("imgSqrs984").src;

    value45Save984 = "zSqrArtSpecz984";

    localStorage.setItem(value45Save984, sQz984);
};

function square985(){

    var sQz985 = document.getElementById("imgSqrs985").src;

    value45Save985 = "zSqrArtSpecz985";

    localStorage.setItem(value45Save985, sQz985);
};

function square986(){

    var sQz986 = document.getElementById("imgSqrs986").src;

    value45Save986 = "zSqrArtSpecz986";

    localStorage.setItem(value45Save986, sQz986);
};

function square987(){

    var sQz987 = document.getElementById("imgSqrs987").src;

    value45Save987 = "zSqrArtSpecz987";

    localStorage.setItem(value45Save987, sQz987);
};

function square988(){

    var sQz988 = document.getElementById("imgSqrs988").src;

    value45Save988 = "zSqrArtSpecz988";

    localStorage.setItem(value45Save988, sQz988);
};

function square989(){

    var sQz989 = document.getElementById("imgSqrs989").src;

    value45Save989 = "zSqrArtSpecz989";

    localStorage.setItem(value45Save989, sQz989);
};

function square990(){

    var sQz990 = document.getElementById("imgSqrs990").src;

    value45Save990 = "zSqrArtSpecz990";

    localStorage.setItem(value45Save990, sQz990);
};

function square991(){

    var sQz991 = document.getElementById("imgSqrs991").src;

    value45Save991 = "zSqrArtSpecz991";

    localStorage.setItem(value45Save991, sQz991);
};

function square992(){

    var sQz992 = document.getElementById("imgSqrs992").src;

    value45Save992 = "zSqrArtSpecz992";

    localStorage.setItem(value45Save992, sQz992);
};

function square993(){

    var sQz993 = document.getElementById("imgSqrs993").src;

    value45Save993 = "zSqrArtSpecz993";

    localStorage.setItem(value45Save993, sQz993);
};

function square994(){

    var sQz994 = document.getElementById("imgSqrs994").src;

    value45Save994 = "zSqrArtSpecz994";

    localStorage.setItem(value45Save994, sQz994);
};

function square995(){

    var sQz995 = document.getElementById("imgSqrs995").src;

    value45Save995 = "zSqrArtSpecz995";

    localStorage.setItem(value45Save995, sQz995);
};

function square996(){

    var sQz996 = document.getElementById("imgSqrs996").src;

    value45Save996 = "zSqrArtSpecz996";

    localStorage.setItem(value45Save996, sQz996);
};

function square997(){

    var sQz997 = document.getElementById("imgSqrs997").src;

    value45Save997 = "zSqrArtSpecz997";

    localStorage.setItem(value45Save997, sQz997);
};

function square998(){

    var sQz998 = document.getElementById("imgSqrs998").src;

    value45Save998 = "zSqrArtSpecz998";

    localStorage.setItem(value45Save998, sQz998);
};

function square999(){

    var sQz999 = document.getElementById("imgSqrs999").src;

    value45Save999 = "zSqrArtSpecz999";

    localStorage.setItem(value45Save999, sQz999);
};

function square1000(){

    var sQz1000 = document.getElementById("imgSqrs1000").src;

    value45Save1000 = "zSqrArtSpecz1000";

    localStorage.setItem(value45Save1000, sQz1000);
};

function square1001(){

    var sQz1001 = document.getElementById("imgSqrs1001").src;

    value45Save1001 = "zSqrArtSpecz1001";

    localStorage.setItem(value45Save1001, sQz1001);
};

function square1002(){

    var sQz1002 = document.getElementById("imgSqrs1002").src;

    value45Save1002 = "zSqrArtSpecz1002";

    localStorage.setItem(value45Save1002, sQz1002);
};

function square1003(){

    var sQz1003 = document.getElementById("imgSqrs1003").src;

    value45Save1003 = "zSqrArtSpecz1003";

    localStorage.setItem(value45Save1003, sQz1003);
};

function square1004(){

    var sQz1004 = document.getElementById("imgSqrs1004").src;

    value45Save1004 = "zSqrArtSpecz1004";

    localStorage.setItem(value45Save1004, sQz1004);
};

function square1005(){

    var sQz1005 = document.getElementById("imgSqrs1005").src;

    value45Save1005 = "zSqrArtSpecz1005";

    localStorage.setItem(value45Save1005, sQz1005);
};

function square1006(){

    var sQz1006 = document.getElementById("imgSqrs1006").src;

    value45Save1006 = "zSqrArtSpecz1006";

    localStorage.setItem(value45Save1006, sQz1006);
};

function square1007(){

    var sQz1007 = document.getElementById("imgSqrs1007").src;

    value45Save1007 = "zSqrArtSpecz1007";

    localStorage.setItem(value45Save1007, sQz1007);
};

function square1008(){

    var sQz1008 = document.getElementById("imgSqrs1008").src;

    value45Save1008 = "zSqrArtSpecz1008";

    localStorage.setItem(value45Save1008, sQz1008);
};

function square1009(){

    var sQz1009 = document.getElementById("imgSqrs1009").src;

    value45Save1009 = "zSqrArtSpecz1009";

    localStorage.setItem(value45Save1009, sQz1009);
};

function square1010(){

    var sQz1010 = document.getElementById("imgSqrs1010").src;

    value45Save1010 = "zSqrArtSpecz1010";

    localStorage.setItem(value45Save1010, sQz1010);
};

function square1011(){

    var sQz1011 = document.getElementById("imgSqrs1011").src;

    value45Save1011 = "zSqrArtSpecz1011";

    localStorage.setItem(value45Save1011, sQz1011);
};

function square1012(){

    var sQz1012 = document.getElementById("imgSqrs1012").src;

    value45Save1012 = "zSqrArtSpecz1012";

    localStorage.setItem(value45Save1012, sQz1012);
};

function square1013(){

    var sQz1013 = document.getElementById("imgSqrs1013").src;

    value45Save1013 = "zSqrArtSpecz1013";

    localStorage.setItem(value45Save1013, sQz1013);
};

function square1014(){

    var sQz1014 = document.getElementById("imgSqrs1014").src;

    value45Save1014 = "zSqrArtSpecz1014";

    localStorage.setItem(value45Save1014, sQz1014);
};

function square1015(){

    var sQz1015 = document.getElementById("imgSqrs1015").src;

    value45Save1015 = "zSqrArtSpecz1015";

    localStorage.setItem(value45Save1015, sQz1015);
};

function square1016(){

    var sQz1016 = document.getElementById("imgSqrs1016").src;

    value45Save1016 = "zSqrArtSpecz1016";

    localStorage.setItem(value45Save1016, sQz1016);
};

function square1017(){

    var sQz1017 = document.getElementById("imgSqrs1017").src;

    value45Save1017 = "zSqrArtSpecz1017";

    localStorage.setItem(value45Save1017, sQz1017);
};

function square1018(){

    var sQz1018 = document.getElementById("imgSqrs1018").src;

    value45Save1018 = "zSqrArtSpecz1018";

    localStorage.setItem(value45Save1018, sQz1018);
};

function square1019(){

    var sQz1019 = document.getElementById("imgSqrs1019").src;

    value45Save1019 = "zSqrArtSpecz1019";

    localStorage.setItem(value45Save1019, sQz1019);
};

function square1020(){

    var sQz1020 = document.getElementById("imgSqrs1020").src;

    value45Save1020 = "zSqrArtSpecz1020";

    localStorage.setItem(value45Save1020, sQz1020);
};

function square1021(){

    var sQz1021 = document.getElementById("imgSqrs1021").src;

    value45Save1021 = "zSqrArtSpecz1021";

    localStorage.setItem(value45Save1021, sQz1021);
};

function square1022(){

    var sQz1022 = document.getElementById("imgSqrs1022").src;

    value45Save1022 = "zSqrArtSpecz1022";

    localStorage.setItem(value45Save1022, sQz1022);
};

function square1023(){

    var sQz1023 = document.getElementById("imgSqrs1023").src;

    value45Save1023 = "zSqrArtSpecz1023";

    localStorage.setItem(value45Save1023, sQz1023);
};

function square1024(){

    var sQz1024 = document.getElementById("imgSqrs1024").src;

    value45Save1024 = "zSqrArtSpecz1024";

    localStorage.setItem(value45Save1024, sQz1024);
};

function square1025(){

    var sQz1025 = document.getElementById("imgSqrs1025").src;

    value45Save1025 = "zSqrArtSpecz1025";

    localStorage.setItem(value45Save1025, sQz1025);
};

function square1026(){

    var sQz1026 = document.getElementById("imgSqrs1026").src;

    value45Save1026 = "zSqrArtSpecz1026";

    localStorage.setItem(value45Save1026, sQz1026);
};

function square1027(){

    var sQz1027 = document.getElementById("imgSqrs1027").src;

    value45Save1027 = "zSqrArtSpecz1027";

    localStorage.setItem(value45Save1027, sQz1027);
};

function square1028(){

    var sQz1028 = document.getElementById("imgSqrs1028").src;

    value45Save1028 = "zSqrArtSpecz1028";

    localStorage.setItem(value45Save1028, sQz1028);
};

function square1029(){

    var sQz1029 = document.getElementById("imgSqrs1029").src;

    value45Save1029 = "zSqrArtSpecz1029";

    localStorage.setItem(value45Save1029, sQz1029);
};

function square1030(){

    var sQz1030 = document.getElementById("imgSqrs1030").src;

    value45Save1030 = "zSqrArtSpecz1030";

    localStorage.setItem(value45Save1030, sQz1030);
};

function square1031(){

    var sQz1031 = document.getElementById("imgSqrs1031").src;

    value45Save1031 = "zSqrArtSpecz1031";

    localStorage.setItem(value45Save1031, sQz1031);
};

function square1032(){

    var sQz1032 = document.getElementById("imgSqrs1032").src;

    value45Save1032 = "zSqrArtSpecz1032";

    localStorage.setItem(value45Save1032, sQz1032);
};

function square1033(){

    var sQz1033 = document.getElementById("imgSqrs1033").src;

    value45Save1033 = "zSqrArtSpecz1033";

    localStorage.setItem(value45Save1033, sQz1033);
};

function square1034(){

    var sQz1034 = document.getElementById("imgSqrs1034").src;

    value45Save1034 = "zSqrArtSpecz1034";

    localStorage.setItem(value45Save1034, sQz1034);
};

function square1035(){

    var sQz1035 = document.getElementById("imgSqrs1035").src;

    value45Save1035 = "zSqrArtSpecz1035";

    localStorage.setItem(value45Save1035, sQz1035);
};

function square1036(){

    var sQz1036 = document.getElementById("imgSqrs1036").src;

    value45Save1036 = "zSqrArtSpecz1036";

    localStorage.setItem(value45Save1036, sQz1036);
};

function square1037(){

    var sQz1037 = document.getElementById("imgSqrs1037").src;

    value45Save1037 = "zSqrArtSpecz1037";

    localStorage.setItem(value45Save1037, sQz1037);
};

function square1038(){

    var sQz1038 = document.getElementById("imgSqrs1038").src;

    value45Save1038 = "zSqrArtSpecz1038";

    localStorage.setItem(value45Save1038, sQz1038);
};

function square1039(){

    var sQz1039 = document.getElementById("imgSqrs1039").src;

    value45Save1039 = "zSqrArtSpecz1039";

    localStorage.setItem(value45Save1039, sQz1039);
};

function square1040(){

    var sQz1040 = document.getElementById("imgSqrs1040").src;

    value45Save1040 = "zSqrArtSpecz1040";

    localStorage.setItem(value45Save1040, sQz1040);
};

function square1041(){

    var sQz1041 = document.getElementById("imgSqrs1041").src;

    value45Save1041 = "zSqrArtSpecz1041";

    localStorage.setItem(value45Save1041, sQz1041);
};

function square1042(){

    var sQz1042 = document.getElementById("imgSqrs1042").src;

    value45Save1042 = "zSqrArtSpecz1042";

    localStorage.setItem(value45Save1042, sQz1042);
};

function square1043(){

    var sQz1043 = document.getElementById("imgSqrs1043").src;

    value45Save1043 = "zSqrArtSpecz1043";

    localStorage.setItem(value45Save1043, sQz1043);
};

function square1044(){

    var sQz1044 = document.getElementById("imgSqrs1044").src;

    value45Save1044 = "zSqrArtSpecz1044";

    localStorage.setItem(value45Save1044, sQz1044);
};

function square1045(){

    var sQz1045 = document.getElementById("imgSqrs1045").src;

    value45Save1045 = "zSqrArtSpecz1045";

    localStorage.setItem(value45Save1045, sQz1045);
};

function square1046(){

    var sQz1046 = document.getElementById("imgSqrs1046").src;

    value45Save1046 = "zSqrArtSpecz1046";

    localStorage.setItem(value45Save1046, sQz1046);
};

function square1047(){

    var sQz1047 = document.getElementById("imgSqrs1047").src;

    value45Save1047 = "zSqrArtSpecz1047";

    localStorage.setItem(value45Save1047, sQz1047);
};

function square1048(){

    var sQz1048 = document.getElementById("imgSqrs1048").src;

    value45Save1048 = "zSqrArtSpecz1048";

    localStorage.setItem(value45Save1048, sQz1048);
};

function square1049(){

    var sQz1049 = document.getElementById("imgSqrs1049").src;

    value45Save1049 = "zSqrArtSpecz1049";

    localStorage.setItem(value45Save1049, sQz1049);
};

function square1050(){

    var sQz1050 = document.getElementById("imgSqrs1050").src;

    value45Save1050 = "zSqrArtSpecz1050";

    localStorage.setItem(value45Save1050, sQz1050);
};

function square1051(){

    var sQz1051 = document.getElementById("imgSqrs1051").src;

    value45Save1051 = "zSqrArtSpecz1051";

    localStorage.setItem(value45Save1051, sQz1051);
};

function square1052(){

    var sQz1052 = document.getElementById("imgSqrs1052").src;

    value45Save1052 = "zSqrArtSpecz1052";

    localStorage.setItem(value45Save1052, sQz1052);
};

function square1053(){

    var sQz1053 = document.getElementById("imgSqrs1053").src;

    value45Save1053 = "zSqrArtSpecz1053";

    localStorage.setItem(value45Save1053, sQz1053);
};

function square1054(){

    var sQz1054 = document.getElementById("imgSqrs1054").src;

    value45Save1054 = "zSqrArtSpecz1054";

    localStorage.setItem(value45Save1054, sQz1054);
};

function square1055(){

    var sQz1055 = document.getElementById("imgSqrs1055").src;

    value45Save1055 = "zSqrArtSpecz1055";

    localStorage.setItem(value45Save1055, sQz1055);
};

function square1056(){

    var sQz1056 = document.getElementById("imgSqrs1056").src;

    value45Save1056 = "zSqrArtSpecz1056";

    localStorage.setItem(value45Save1056, sQz1056);
};

function square1057(){

    var sQz1057 = document.getElementById("imgSqrs1057").src;

    value45Save1057 = "zSqrArtSpecz1057";

    localStorage.setItem(value45Save1057, sQz1057);
};

function square1058(){

    var sQz1058 = document.getElementById("imgSqrs1058").src;

    value45Save1058 = "zSqrArtSpecz1058";

    localStorage.setItem(value45Save1058, sQz1058);
};

function square1059(){

    var sQz1059 = document.getElementById("imgSqrs1059").src;

    value45Save1059 = "zSqrArtSpecz1059";

    localStorage.setItem(value45Save1059, sQz1059);
};

function square1060(){

    var sQz1060 = document.getElementById("imgSqrs1060").src;

    value45Save1060 = "zSqrArtSpecz1060";

    localStorage.setItem(value45Save1060, sQz1060);
};

function square1061(){

    var sQz1061 = document.getElementById("imgSqrs1061").src;

    value45Save1061 = "zSqrArtSpecz1061";

    localStorage.setItem(value45Save1061, sQz1061);
};

function square1062(){

    var sQz1062 = document.getElementById("imgSqrs1062").src;

    value45Save1062 = "zSqrArtSpecz1062";

    localStorage.setItem(value45Save1062, sQz1062);
};

function square1063(){

    var sQz1063 = document.getElementById("imgSqrs1063").src;

    value45Save1063 = "zSqrArtSpecz1063";

    localStorage.setItem(value45Save1063, sQz1063);
};

function square1064(){

    var sQz1064 = document.getElementById("imgSqrs1064").src;

    value45Save1064 = "zSqrArtSpecz1064";

    localStorage.setItem(value45Save1064, sQz1064);
};

function square1065(){

    var sQz1065 = document.getElementById("imgSqrs1065").src;

    value45Save1065 = "zSqrArtSpecz1065";

    localStorage.setItem(value45Save1065, sQz1065);
};

function square1066(){

    var sQz1066 = document.getElementById("imgSqrs1066").src;

    value45Save1066 = "zSqrArtSpecz1066";

    localStorage.setItem(value45Save1066, sQz1066);
};

function square1067(){

    var sQz1067 = document.getElementById("imgSqrs1067").src;

    value45Save1067 = "zSqrArtSpecz1067";

    localStorage.setItem(value45Save1067, sQz1067);
};

function square1068(){

    var sQz1068 = document.getElementById("imgSqrs1068").src;

    value45Save1068 = "zSqrArtSpecz1068";

    localStorage.setItem(value45Save1068, sQz1068);
};

function square1069(){

    var sQz1069 = document.getElementById("imgSqrs1069").src;

    value45Save1069 = "zSqrArtSpecz1069";

    localStorage.setItem(value45Save1069, sQz1069);
};

function square1070(){

    var sQz1070 = document.getElementById("imgSqrs1070").src;

    value45Save1070 = "zSqrArtSpecz1070";

    localStorage.setItem(value45Save1070, sQz1070);
};

function square1071(){

    var sQz1071 = document.getElementById("imgSqrs1071").src;

    value45Save1071 = "zSqrArtSpecz1071";

    localStorage.setItem(value45Save1071, sQz1071);
};

function square1072(){

    var sQz1072 = document.getElementById("imgSqrs1072").src;

    value45Save1072 = "zSqrArtSpecz1072";

    localStorage.setItem(value45Save1072, sQz1072);
};

function square1073(){

    var sQz1073 = document.getElementById("imgSqrs1073").src;

    value45Save1073 = "zSqrArtSpecz1073";

    localStorage.setItem(value45Save1073, sQz1073);
};

function square1074(){

    var sQz1074 = document.getElementById("imgSqrs1074").src;

    value45Save1074 = "zSqrArtSpecz1074";

    localStorage.setItem(value45Save1074, sQz1074);
};

function square1075(){

    var sQz1075 = document.getElementById("imgSqrs1075").src;

    value45Save1075 = "zSqrArtSpecz1075";

    localStorage.setItem(value45Save1075, sQz1075);
};

function square1076(){

    var sQz1076 = document.getElementById("imgSqrs1076").src;

    value45Save1076 = "zSqrArtSpecz1076";

    localStorage.setItem(value45Save1076, sQz1076);
};

function square1077(){

    var sQz1077 = document.getElementById("imgSqrs1077").src;

    value45Save1077 = "zSqrArtSpecz1077";

    localStorage.setItem(value45Save1077, sQz1077);
};

function square1078(){

    var sQz1078 = document.getElementById("imgSqrs1078").src;

    value45Save1078 = "zSqrArtSpecz1078";

    localStorage.setItem(value45Save1078, sQz1078);
};

function square1079(){

    var sQz1079 = document.getElementById("imgSqrs1079").src;

    value45Save1079 = "zSqrArtSpecz1079";

    localStorage.setItem(value45Save1079, sQz1079);
};

function square1080(){

    var sQz1080 = document.getElementById("imgSqrs1080").src;

    value45Save1080 = "zSqrArtSpecz1080";

    localStorage.setItem(value45Save1080, sQz1080);
};

function square1081(){

    var sQz1081 = document.getElementById("imgSqrs1081").src;

    value45Save1081 = "zSqrArtSpecz1081";

    localStorage.setItem(value45Save1081, sQz1081);
};

function square1082(){

    var sQz1082 = document.getElementById("imgSqrs1082").src;

    value45Save1082 = "zSqrArtSpecz1082";

    localStorage.setItem(value45Save1082, sQz1082);
};

function square1083(){

    var sQz1083 = document.getElementById("imgSqrs1083").src;

    value45Save1083 = "zSqrArtSpecz1083";

    localStorage.setItem(value45Save1083, sQz1083);
};

function square1084(){

    var sQz1084 = document.getElementById("imgSqrs1084").src;

    value45Save1084 = "zSqrArtSpecz1084";

    localStorage.setItem(value45Save1084, sQz1084);
};

function square1085(){

    var sQz1085 = document.getElementById("imgSqrs1085").src;

    value45Save1085 = "zSqrArtSpecz1085";

    localStorage.setItem(value45Save1085, sQz1085);
};

function square1086(){

    var sQz1086 = document.getElementById("imgSqrs1086").src;

    value45Save1086 = "zSqrArtSpecz1086";

    localStorage.setItem(value45Save1086, sQz1086);
};

function square1087(){

    var sQz1087 = document.getElementById("imgSqrs1087").src;

    value45Save1087 = "zSqrArtSpecz1087";

    localStorage.setItem(value45Save1087, sQz1087);
};

function square1088(){

    var sQz1088 = document.getElementById("imgSqrs1088").src;

    value45Save1088 = "zSqrArtSpecz1088";

    localStorage.setItem(value45Save1088, sQz1088);
};

function square1089(){

    var sQz1089 = document.getElementById("imgSqrs1089").src;

    value45Save1089 = "zSqrArtSpecz1089";

    localStorage.setItem(value45Save1089, sQz1089);
};

function square1090(){

    var sQz1090 = document.getElementById("imgSqrs1090").src;

    value45Save1090 = "zSqrArtSpecz1090";

    localStorage.setItem(value45Save1090, sQz1090);
};

function square1091(){

    var sQz1091 = document.getElementById("imgSqrs1091").src;

    value45Save1091 = "zSqrArtSpecz1091";

    localStorage.setItem(value45Save1091, sQz1091);
};

function square1092(){

    var sQz1092 = document.getElementById("imgSqrs1092").src;

    value45Save1092 = "zSqrArtSpecz1092";

    localStorage.setItem(value45Save1092, sQz1092);
};

function square1093(){

    var sQz1093 = document.getElementById("imgSqrs1093").src;

    value45Save1093 = "zSqrArtSpecz1093";

    localStorage.setItem(value45Save1093, sQz1093);
};

function square1094(){

    var sQz1094 = document.getElementById("imgSqrs1094").src;

    value45Save1094 = "zSqrArtSpecz1094";

    localStorage.setItem(value45Save1094, sQz1094);
};

function square1095(){

    var sQz1095 = document.getElementById("imgSqrs1095").src;

    value45Save1095 = "zSqrArtSpecz1095";

    localStorage.setItem(value45Save1095, sQz1095);
};

function square1096(){

    var sQz1096 = document.getElementById("imgSqrs1096").src;

    value45Save1096 = "zSqrArtSpecz1096";

    localStorage.setItem(value45Save1096, sQz1096);
};

function square1097(){

    var sQz1097 = document.getElementById("imgSqrs1097").src;

    value45Save1097 = "zSqrArtSpecz1097";

    localStorage.setItem(value45Save1097, sQz1097);
};

function square1098(){

    var sQz1098 = document.getElementById("imgSqrs1098").src;

    value45Save1098 = "zSqrArtSpecz1098";

    localStorage.setItem(value45Save1098, sQz1098);
};

function square1099(){

    var sQz1099 = document.getElementById("imgSqrs1099").src;

    value45Save1099 = "zSqrArtSpecz1099";

    localStorage.setItem(value45Save1099, sQz1099);
};

function square1100(){

    var sQz1100 = document.getElementById("imgSqrs1100").src;

    value45Save1100 = "zSqrArtSpecz1100";

    localStorage.setItem(value45Save1100, sQz1100);
};

function square1101(){

    var sQz1101 = document.getElementById("imgSqrs1101").src;

    value45Save1101 = "zSqrArtSpecz1101";

    localStorage.setItem(value45Save1101, sQz1101);
};

function square1102(){

    var sQz1102 = document.getElementById("imgSqrs1102").src;

    value45Save1102 = "zSqrArtSpecz1102";

    localStorage.setItem(value45Save1102, sQz1102);
};

function square1103(){

    var sQz1103 = document.getElementById("imgSqrs1103").src;

    value45Save1103 = "zSqrArtSpecz1103";

    localStorage.setItem(value45Save1103, sQz1103);
};

function square1104(){

    var sQz1104 = document.getElementById("imgSqrs1104").src;

    value45Save1104 = "zSqrArtSpecz1104";

    localStorage.setItem(value45Save1104, sQz1104);
};

function square1105(){

    var sQz1105 = document.getElementById("imgSqrs1105").src;

    value45Save1105 = "zSqrArtSpecz1105";

    localStorage.setItem(value45Save1105, sQz1105);
};

function square1106(){

    var sQz1106 = document.getElementById("imgSqrs1106").src;

    value45Save1106 = "zSqrArtSpecz1106";

    localStorage.setItem(value45Save1106, sQz1106);
};

function square1107(){

    var sQz1107 = document.getElementById("imgSqrs1107").src;

    value45Save1107 = "zSqrArtSpecz1107";

    localStorage.setItem(value45Save1107, sQz1107);
};

function square1108(){

    var sQz1108 = document.getElementById("imgSqrs1108").src;

    value45Save1108 = "zSqrArtSpecz1108";

    localStorage.setItem(value45Save1108, sQz1108);
};

function square1109(){

    var sQz1109 = document.getElementById("imgSqrs1109").src;

    value45Save1109 = "zSqrArtSpecz1109";

    localStorage.setItem(value45Save1109, sQz1109);
};

function square1110(){

    var sQz1110 = document.getElementById("imgSqrs1110").src;

    value45Save1110 = "zSqrArtSpecz1110";

    localStorage.setItem(value45Save1110, sQz1110);
};

function square1111(){

    var sQz1111 = document.getElementById("imgSqrs1111").src;

    value45Save1111 = "zSqrArtSpecz1111";

    localStorage.setItem(value45Save1111, sQz1111);
};

function square1112(){

    var sQz1112 = document.getElementById("imgSqrs1112").src;

    value45Save1112 = "zSqrArtSpecz1112";

    localStorage.setItem(value45Save1112, sQz1112);
};

function square1113(){

    var sQz1113 = document.getElementById("imgSqrs1113").src;

    value45Save1113 = "zSqrArtSpecz1113";

    localStorage.setItem(value45Save1113, sQz1113);
};

function square1114(){

    var sQz1114 = document.getElementById("imgSqrs1114").src;

    value45Save1114 = "zSqrArtSpecz1114";

    localStorage.setItem(value45Save1114, sQz1114);
};

function square1115(){

    var sQz1115 = document.getElementById("imgSqrs1115").src;

    value45Save1115 = "zSqrArtSpecz1115";

    localStorage.setItem(value45Save1115, sQz1115);
};

function square1116(){

    var sQz1116 = document.getElementById("imgSqrs1116").src;

    value45Save1116 = "zSqrArtSpecz1116";

    localStorage.setItem(value45Save1116, sQz1116);
};

function square1117(){

    var sQz1117 = document.getElementById("imgSqrs1117").src;

    value45Save1117 = "zSqrArtSpecz1117";

    localStorage.setItem(value45Save1117, sQz1117);
};

function square1118(){

    var sQz1118 = document.getElementById("imgSqrs1118").src;

    value45Save1118 = "zSqrArtSpecz1118";

    localStorage.setItem(value45Save1118, sQz1118);
};

function square1119(){

    var sQz1119 = document.getElementById("imgSqrs1119").src;

    value45Save1119 = "zSqrArtSpecz1119";

    localStorage.setItem(value45Save1119, sQz1119);
};

function square1120(){

    var sQz1120 = document.getElementById("imgSqrs1120").src;

    value45Save1120 = "zSqrArtSpecz1120";

    localStorage.setItem(value45Save1120, sQz1120);
};

function square1121(){

    var sQz1121 = document.getElementById("imgSqrs1121").src;

    value45Save1121 = "zSqrArtSpecz1121";

    localStorage.setItem(value45Save1121, sQz1121);
};

function square1122(){

    var sQz1122 = document.getElementById("imgSqrs1122").src;

    value45Save1122 = "zSqrArtSpecz1122";

    localStorage.setItem(value45Save1122, sQz1122);
};

function square1123(){

    var sQz1123 = document.getElementById("imgSqrs1123").src;

    value45Save1123 = "zSqrArtSpecz1123";

    localStorage.setItem(value45Save1123, sQz1123);
};

function square1124(){

    var sQz1124 = document.getElementById("imgSqrs1124").src;

    value45Save1124 = "zSqrArtSpecz1124";

    localStorage.setItem(value45Save1124, sQz1124);
};

function square1125(){

    var sQz1125 = document.getElementById("imgSqrs1125").src;

    value45Save1125 = "zSqrArtSpecz1125";

    localStorage.setItem(value45Save1125, sQz1125);
};

function square1126(){

    var sQz1126 = document.getElementById("imgSqrs1126").src;

    value45Save1126 = "zSqrArtSpecz1126";

    localStorage.setItem(value45Save1126, sQz1126);
};

function square1127(){

    var sQz1127 = document.getElementById("imgSqrs1127").src;

    value45Save1127 = "zSqrArtSpecz1127";

    localStorage.setItem(value45Save1127, sQz1127);
};

function square1128(){

    var sQz1128 = document.getElementById("imgSqrs1128").src;

    value45Save1128 = "zSqrArtSpecz1128";

    localStorage.setItem(value45Save1128, sQz1128);
};

function square1129(){

    var sQz1129 = document.getElementById("imgSqrs1129").src;

    value45Save1129 = "zSqrArtSpecz1129";

    localStorage.setItem(value45Save1129, sQz1129);
};

function square1130(){

    var sQz1130 = document.getElementById("imgSqrs1130").src;

    value45Save1130 = "zSqrArtSpecz1130";

    localStorage.setItem(value45Save1130, sQz1130);
};

function square1131(){

    var sQz1131 = document.getElementById("imgSqrs1131").src;

    value45Save1131 = "zSqrArtSpecz1131";

    localStorage.setItem(value45Save1131, sQz1131);
};

function square1132(){

    var sQz1132 = document.getElementById("imgSqrs1132").src;

    value45Save1132 = "zSqrArtSpecz1132";

    localStorage.setItem(value45Save1132, sQz1132);
};

function square1133(){

    var sQz1133 = document.getElementById("imgSqrs1133").src;

    value45Save1133 = "zSqrArtSpecz1133";

    localStorage.setItem(value45Save1133, sQz1133);
};

function square1134(){

    var sQz1134 = document.getElementById("imgSqrs1134").src;

    value45Save1134 = "zSqrArtSpecz1134";

    localStorage.setItem(value45Save1134, sQz1134);
};

function square1135(){

    var sQz1135 = document.getElementById("imgSqrs1135").src;

    value45Save1135 = "zSqrArtSpecz1135";

    localStorage.setItem(value45Save1135, sQz1135);
};

function square1136(){

    var sQz1136 = document.getElementById("imgSqrs1136").src;

    value45Save1136 = "zSqrArtSpecz1136";

    localStorage.setItem(value45Save1136, sQz1136);
};

function square1137(){

    var sQz1137 = document.getElementById("imgSqrs1137").src;

    value45Save1137 = "zSqrArtSpecz1137";

    localStorage.setItem(value45Save1137, sQz1137);
};

function square1138(){

    var sQz1138 = document.getElementById("imgSqrs1138").src;

    value45Save1138 = "zSqrArtSpecz1138";

    localStorage.setItem(value45Save1138, sQz1138);
};

function square1139(){

    var sQz1139 = document.getElementById("imgSqrs1139").src;

    value45Save1139 = "zSqrArtSpecz1139";

    localStorage.setItem(value45Save1139, sQz1139);
};

function square1140(){

    var sQz1140 = document.getElementById("imgSqrs1140").src;

    value45Save1140 = "zSqrArtSpecz1140";

    localStorage.setItem(value45Save1140, sQz1140);
};

function square1141(){

    var sQz1141 = document.getElementById("imgSqrs1141").src;

    value45Save1141 = "zSqrArtSpecz1141";

    localStorage.setItem(value45Save1141, sQz1141);
};

function square1142(){

    var sQz1142 = document.getElementById("imgSqrs1142").src;

    value45Save1142 = "zSqrArtSpecz1142";

    localStorage.setItem(value45Save1142, sQz1142);
};

function square1143(){

    var sQz1143 = document.getElementById("imgSqrs1143").src;

    value45Save1143 = "zSqrArtSpecz1143";

    localStorage.setItem(value45Save1143, sQz1143);
};

function square1144(){

    var sQz1144 = document.getElementById("imgSqrs1144").src;

    value45Save1144 = "zSqrArtSpecz1144";

    localStorage.setItem(value45Save1144, sQz1144);
};

function square1145(){

    var sQz1145 = document.getElementById("imgSqrs1145").src;

    value45Save1145 = "zSqrArtSpecz1145";

    localStorage.setItem(value45Save1145, sQz1145);
};

function square1146(){

    var sQz1146 = document.getElementById("imgSqrs1146").src;

    value45Save1146 = "zSqrArtSpecz1146";

    localStorage.setItem(value45Save1146, sQz1146);
};

function square1147(){

    var sQz1147 = document.getElementById("imgSqrs1147").src;

    value45Save1147 = "zSqrArtSpecz1147";

    localStorage.setItem(value45Save1147, sQz1147);
};

function square1148(){

    var sQz1148 = document.getElementById("imgSqrs1148").src;

    value45Save1148 = "zSqrArtSpecz1148";

    localStorage.setItem(value45Save1148, sQz1148);
};

function square1149(){

    var sQz1149 = document.getElementById("imgSqrs1149").src;

    value45Save1149 = "zSqrArtSpecz1149";

    localStorage.setItem(value45Save1149, sQz1149);
};

function square1150(){

    var sQz1150 = document.getElementById("imgSqrs1150").src;

    value45Save1150 = "zSqrArtSpecz1150";

    localStorage.setItem(value45Save1150, sQz1150);
};

function square1151(){

    var sQz1151 = document.getElementById("imgSqrs1151").src;

    value45Save1151 = "zSqrArtSpecz1151";

    localStorage.setItem(value45Save1151, sQz1151);
};

function square1152(){

    var sQz1152 = document.getElementById("imgSqrs1152").src;

    value45Save1152 = "zSqrArtSpecz1152";

    localStorage.setItem(value45Save1152, sQz1152);
};

function square1153(){

    var sQz1153 = document.getElementById("imgSqrs1153").src;

    value45Save1153 = "zSqrArtSpecz1153";

    localStorage.setItem(value45Save1153, sQz1153);
};

function square1154(){

    var sQz1154 = document.getElementById("imgSqrs1154").src;

    value45Save1154 = "zSqrArtSpecz1154";

    localStorage.setItem(value45Save1154, sQz1154);
};

function square1155(){

    var sQz1155 = document.getElementById("imgSqrs1155").src;

    value45Save1155 = "zSqrArtSpecz1155";

    localStorage.setItem(value45Save1155, sQz1155);
};

function square1156(){

    var sQz1156 = document.getElementById("imgSqrs1156").src;

    value45Save1156 = "zSqrArtSpecz1156";

    localStorage.setItem(value45Save1156, sQz1156);
};

function square1157(){

    var sQz1157 = document.getElementById("imgSqrs1157").src;

    value45Save1157 = "zSqrArtSpecz1157";

    localStorage.setItem(value45Save1157, sQz1157);
};

function square1158(){

    var sQz1158 = document.getElementById("imgSqrs1158").src;

    value45Save1158 = "zSqrArtSpecz1158";

    localStorage.setItem(value45Save1158, sQz1158);
};

function square1159(){

    var sQz1159 = document.getElementById("imgSqrs1159").src;

    value45Save1159 = "zSqrArtSpecz1159";

    localStorage.setItem(value45Save1159, sQz1159);
};

function square1160(){

    var sQz1160 = document.getElementById("imgSqrs1160").src;

    value45Save1160 = "zSqrArtSpecz1160";

    localStorage.setItem(value45Save1160, sQz1160);
};

function square1161(){

    var sQz1161 = document.getElementById("imgSqrs1161").src;

    value45Save1161 = "zSqrArtSpecz1161";

    localStorage.setItem(value45Save1161, sQz1161);
};

function square1162(){

    var sQz1162 = document.getElementById("imgSqrs1162").src;

    value45Save1162 = "zSqrArtSpecz1162";

    localStorage.setItem(value45Save1162, sQz1162);
};

function square1163(){

    var sQz1163 = document.getElementById("imgSqrs1163").src;

    value45Save1163 = "zSqrArtSpecz1163";

    localStorage.setItem(value45Save1163, sQz1163);
};

function square1164(){

    var sQz1164 = document.getElementById("imgSqrs1164").src;

    value45Save1164 = "zSqrArtSpecz1164";

    localStorage.setItem(value45Save1164, sQz1164);
};

function square1165(){

    var sQz1165 = document.getElementById("imgSqrs1165").src;

    value45Save1165 = "zSqrArtSpecz1165";

    localStorage.setItem(value45Save1165, sQz1165);
};

function square1166(){

    var sQz1166 = document.getElementById("imgSqrs1166").src;

    value45Save1166 = "zSqrArtSpecz1166";

    localStorage.setItem(value45Save1166, sQz1166);
};

function square1167(){

    var sQz1167 = document.getElementById("imgSqrs1167").src;

    value45Save1167 = "zSqrArtSpecz1167";

    localStorage.setItem(value45Save1167, sQz1167);
};

function square1168(){

    var sQz1168 = document.getElementById("imgSqrs1168").src;

    value45Save1168 = "zSqrArtSpecz1168";

    localStorage.setItem(value45Save1168, sQz1168);
};

function square1169(){

    var sQz1169 = document.getElementById("imgSqrs1169").src;

    value45Save1169 = "zSqrArtSpecz1169";

    localStorage.setItem(value45Save1169, sQz1169);
};

function square1170(){

    var sQz1170 = document.getElementById("imgSqrs1170").src;

    value45Save1170 = "zSqrArtSpecz1170";

    localStorage.setItem(value45Save1170, sQz1170);
};

function square1171(){

    var sQz1171 = document.getElementById("imgSqrs1171").src;

    value45Save1171 = "zSqrArtSpecz1171";

    localStorage.setItem(value45Save1171, sQz1171);
};

function square1172(){

    var sQz1172 = document.getElementById("imgSqrs1172").src;

    value45Save1172 = "zSqrArtSpecz1172";

    localStorage.setItem(value45Save1172, sQz1172);
};

function square1173(){

    var sQz1173 = document.getElementById("imgSqrs1173").src;

    value45Save1173 = "zSqrArtSpecz1173";

    localStorage.setItem(value45Save1173, sQz1173);
};

function square1174(){

    var sQz1174 = document.getElementById("imgSqrs1174").src;

    value45Save1174 = "zSqrArtSpecz1174";

    localStorage.setItem(value45Save1174, sQz1174);
};

function square1175(){

    var sQz1175 = document.getElementById("imgSqrs1175").src;

    value45Save1175 = "zSqrArtSpecz1175";

    localStorage.setItem(value45Save1175, sQz1175);
};

function square1176(){

    var sQz1176 = document.getElementById("imgSqrs1176").src;

    value45Save1176 = "zSqrArtSpecz1176";

    localStorage.setItem(value45Save1176, sQz1176);
};

function square1177(){

    var sQz1177 = document.getElementById("imgSqrs1177").src;

    value45Save1177 = "zSqrArtSpecz1177";

    localStorage.setItem(value45Save1177, sQz1177);
};

function square1178(){

    var sQz1178 = document.getElementById("imgSqrs1178").src;

    value45Save1178 = "zSqrArtSpecz1178";

    localStorage.setItem(value45Save1178, sQz1178);
};

function square1179(){

    var sQz1179 = document.getElementById("imgSqrs1179").src;

    value45Save1179 = "zSqrArtSpecz1179";

    localStorage.setItem(value45Save1179, sQz1179);
};

function square1180(){

    var sQz1180 = document.getElementById("imgSqrs1180").src;

    value45Save1180 = "zSqrArtSpecz1180";

    localStorage.setItem(value45Save1180, sQz1180);
};

function square1181(){

    var sQz1181 = document.getElementById("imgSqrs1181").src;

    value45Save1181 = "zSqrArtSpecz1181";

    localStorage.setItem(value45Save1181, sQz1181);
};

function square1182(){

    var sQz1182 = document.getElementById("imgSqrs1182").src;

    value45Save1182 = "zSqrArtSpecz1182";

    localStorage.setItem(value45Save1182, sQz1182);
};

function square1183(){

    var sQz1183 = document.getElementById("imgSqrs1183").src;

    value45Save1183 = "zSqrArtSpecz1183";

    localStorage.setItem(value45Save1183, sQz1183);
};

function square1184(){

    var sQz1184 = document.getElementById("imgSqrs1184").src;

    value45Save1184 = "zSqrArtSpecz1184";

    localStorage.setItem(value45Save1184, sQz1184);
};

function square1185(){

    var sQz1185 = document.getElementById("imgSqrs1185").src;

    value45Save1185 = "zSqrArtSpecz1185";

    localStorage.setItem(value45Save1185, sQz1185);
};

function square1186(){

    var sQz1186 = document.getElementById("imgSqrs1186").src;

    value45Save1186 = "zSqrArtSpecz1186";

    localStorage.setItem(value45Save1186, sQz1186);
};

function square1187(){

    var sQz1187 = document.getElementById("imgSqrs1187").src;

    value45Save1187 = "zSqrArtSpecz1187";

    localStorage.setItem(value45Save1187, sQz1187);
};

function square1188(){

    var sQz1188 = document.getElementById("imgSqrs1188").src;

    value45Save1188 = "zSqrArtSpecz1188";

    localStorage.setItem(value45Save1188, sQz1188);
};

function square1189(){

    var sQz1189 = document.getElementById("imgSqrs1189").src;

    value45Save1189 = "zSqrArtSpecz1189";

    localStorage.setItem(value45Save1189, sQz1189);
};

function square1190(){

    var sQz1190 = document.getElementById("imgSqrs1190").src;

    value45Save1190 = "zSqrArtSpecz1190";

    localStorage.setItem(value45Save1190, sQz1190);
};

function square1191(){

    var sQz1191 = document.getElementById("imgSqrs1191").src;

    value45Save1191 = "zSqrArtSpecz1191";

    localStorage.setItem(value45Save1191, sQz1191);
};

function square1192(){

    var sQz1192 = document.getElementById("imgSqrs1192").src;

    value45Save1192 = "zSqrArtSpecz1192";

    localStorage.setItem(value45Save1192, sQz1192);
};

function square1193(){

    var sQz1193 = document.getElementById("imgSqrs1193").src;

    value45Save1193 = "zSqrArtSpecz1193";

    localStorage.setItem(value45Save1193, sQz1193);
};

function square1194(){

    var sQz1194 = document.getElementById("imgSqrs1194").src;

    value45Save1194 = "zSqrArtSpecz1194";

    localStorage.setItem(value45Save1194, sQz1194);
};

function square1195(){

    var sQz1195 = document.getElementById("imgSqrs1195").src;

    value45Save1195 = "zSqrArtSpecz1195";

    localStorage.setItem(value45Save1195, sQz1195);
};

function square1196(){

    var sQz1196 = document.getElementById("imgSqrs1196").src;

    value45Save1196 = "zSqrArtSpecz1196";

    localStorage.setItem(value45Save1196, sQz1196);
};

function square1197(){

    var sQz1197 = document.getElementById("imgSqrs1197").src;

    value45Save1197 = "zSqrArtSpecz1197";

    localStorage.setItem(value45Save1197, sQz1197);
};

function square1198(){

    var sQz1198 = document.getElementById("imgSqrs1198").src;

    value45Save1198 = "zSqrArtSpecz1198";

    localStorage.setItem(value45Save1198, sQz1198);
};

function square1199(){

    var sQz1199 = document.getElementById("imgSqrs1199").src;

    value45Save1199 = "zSqrArtSpecz1199";

    localStorage.setItem(value45Save1199, sQz1199);
};

function square1200(){

    var sQz1200 = document.getElementById("imgSqrs1200").src;

    value45Save1200 = "zSqrArtSpecz1200";

    localStorage.setItem(value45Save1200, sQz1200);
};

function square1201(){

    var sQz1201 = document.getElementById("imgSqrs1201").src;

    value45Save1201 = "zSqrArtSpecz1201";

    localStorage.setItem(value45Save1201, sQz1201);
};

function square1202(){

    var sQz1202 = document.getElementById("imgSqrs1202").src;

    value45Save1202 = "zSqrArtSpecz1202";

    localStorage.setItem(value45Save1202, sQz1202);
};

function square1203(){

    var sQz1203 = document.getElementById("imgSqrs1203").src;

    value45Save1203 = "zSqrArtSpecz1203";

    localStorage.setItem(value45Save1203, sQz1203);
};

function square1204(){

    var sQz1204 = document.getElementById("imgSqrs1204").src;

    value45Save1204 = "zSqrArtSpecz1204";

    localStorage.setItem(value45Save1204, sQz1204);
};

function square1205(){

    var sQz1205 = document.getElementById("imgSqrs1205").src;

    value45Save1205 = "zSqrArtSpecz1205";

    localStorage.setItem(value45Save1205, sQz1205);
};

function square1206(){

    var sQz1206 = document.getElementById("imgSqrs1206").src;

    value45Save1206 = "zSqrArtSpecz1206";

    localStorage.setItem(value45Save1206, sQz1206);
};

function square1207(){

    var sQz1207 = document.getElementById("imgSqrs1207").src;

    value45Save1207 = "zSqrArtSpecz1207";

    localStorage.setItem(value45Save1207, sQz1207);
};

function square1208(){

    var sQz1208 = document.getElementById("imgSqrs1208").src;

    value45Save1208 = "zSqrArtSpecz1208";

    localStorage.setItem(value45Save1208, sQz1208);
};

function square1209(){

    var sQz1209 = document.getElementById("imgSqrs1209").src;

    value45Save1209 = "zSqrArtSpecz1209";

    localStorage.setItem(value45Save1209, sQz1209);
};

function square1210(){

    var sQz1210 = document.getElementById("imgSqrs1210").src;

    value45Save1210 = "zSqrArtSpecz1210";

    localStorage.setItem(value45Save1210, sQz1210);
};

function square1211(){

    var sQz1211 = document.getElementById("imgSqrs1211").src;

    value45Save1211 = "zSqrArtSpecz1211";

    localStorage.setItem(value45Save1211, sQz1211);
};

function square1212(){

    var sQz1212 = document.getElementById("imgSqrs1212").src;

    value45Save1212 = "zSqrArtSpecz1212";

    localStorage.setItem(value45Save1212, sQz1212);
};

function square1213(){

    var sQz1213 = document.getElementById("imgSqrs1213").src;

    value45Save1213 = "zSqrArtSpecz1213";

    localStorage.setItem(value45Save1213, sQz1213);
};

function square1214(){

    var sQz1214 = document.getElementById("imgSqrs1214").src;

    value45Save1214 = "zSqrArtSpecz1214";

    localStorage.setItem(value45Save1214, sQz1214);
};

function square1215(){

    var sQz1215 = document.getElementById("imgSqrs1215").src;

    value45Save1215 = "zSqrArtSpecz1215";

    localStorage.setItem(value45Save1215, sQz1215);
};

function square1216(){

    var sQz1216 = document.getElementById("imgSqrs1216").src;

    value45Save1216 = "zSqrArtSpecz1216";

    localStorage.setItem(value45Save1216, sQz1216);
};

function square1217(){

    var sQz1217 = document.getElementById("imgSqrs1217").src;

    value45Save1217 = "zSqrArtSpecz1217";

    localStorage.setItem(value45Save1217, sQz1217);
};

function square1218(){

    var sQz1218 = document.getElementById("imgSqrs1218").src;

    value45Save1218 = "zSqrArtSpecz1218";

    localStorage.setItem(value45Save1218, sQz1218);
};

function square1219(){

    var sQz1219 = document.getElementById("imgSqrs1219").src;

    value45Save1219 = "zSqrArtSpecz1219";

    localStorage.setItem(value45Save1219, sQz1219);
};

function square1220(){

    var sQz1220 = document.getElementById("imgSqrs1220").src;

    value45Save1220 = "zSqrArtSpecz1220";

    localStorage.setItem(value45Save1220, sQz1220);
};

function square1221(){

    var sQz1221 = document.getElementById("imgSqrs1221").src;

    value45Save1221 = "zSqrArtSpecz1221";

    localStorage.setItem(value45Save1221, sQz1221);
};

function square1222(){

    var sQz1222 = document.getElementById("imgSqrs1222").src;

    value45Save1222 = "zSqrArtSpecz1222";

    localStorage.setItem(value45Save1222, sQz1222);
};

function square1223(){

    var sQz1223 = document.getElementById("imgSqrs1223").src;

    value45Save1223 = "zSqrArtSpecz1223";

    localStorage.setItem(value45Save1223, sQz1223);
};

function square1224(){

    var sQz1224 = document.getElementById("imgSqrs1224").src;

    value45Save1224 = "zSqrArtSpecz1224";

    localStorage.setItem(value45Save1224, sQz1224);
};

function square1225(){

    var sQz1225 = document.getElementById("imgSqrs1225").src;

    value45Save1225 = "zSqrArtSpecz1225";

    localStorage.setItem(value45Save1225, sQz1225);
};

function square1226(){

    var sQz1226 = document.getElementById("imgSqrs1226").src;

    value45Save1226 = "zSqrArtSpecz1226";

    localStorage.setItem(value45Save1226, sQz1226);
};

function square1227(){

    var sQz1227 = document.getElementById("imgSqrs1227").src;

    value45Save1227 = "zSqrArtSpecz1227";

    localStorage.setItem(value45Save1227, sQz1227);
};

function square1228(){

    var sQz1228 = document.getElementById("imgSqrs1228").src;

    value45Save1228 = "zSqrArtSpecz1228";

    localStorage.setItem(value45Save1228, sQz1228);
};

function square1229(){

    var sQz1229 = document.getElementById("imgSqrs1229").src;

    value45Save1229 = "zSqrArtSpecz1229";

    localStorage.setItem(value45Save1229, sQz1229);
};

function square1230(){

    var sQz1230 = document.getElementById("imgSqrs1230").src;

    value45Save1230 = "zSqrArtSpecz1230";

    localStorage.setItem(value45Save1230, sQz1230);
};

function square1231(){

    var sQz1231 = document.getElementById("imgSqrs1231").src;

    value45Save1231 = "zSqrArtSpecz1231";

    localStorage.setItem(value45Save1231, sQz1231);
};

function square1232(){

    var sQz1232 = document.getElementById("imgSqrs1232").src;

    value45Save1232 = "zSqrArtSpecz1232";

    localStorage.setItem(value45Save1232, sQz1232);
};

function square1233(){

    var sQz1233 = document.getElementById("imgSqrs1233").src;

    value45Save1233 = "zSqrArtSpecz1233";

    localStorage.setItem(value45Save1233, sQz1233);
};

function square1234(){

    var sQz1234 = document.getElementById("imgSqrs1234").src;

    value45Save1234 = "zSqrArtSpecz1234";

    localStorage.setItem(value45Save1234, sQz1234);
};

function square1235(){

    var sQz1235 = document.getElementById("imgSqrs1235").src;

    value45Save1235 = "zSqrArtSpecz1235";

    localStorage.setItem(value45Save1235, sQz1235);
};

function square1236(){

    var sQz1236 = document.getElementById("imgSqrs1236").src;

    value45Save1236 = "zSqrArtSpecz1236";

    localStorage.setItem(value45Save1236, sQz1236);
};

function square1237(){

    var sQz1237 = document.getElementById("imgSqrs1237").src;

    value45Save1237 = "zSqrArtSpecz1237";

    localStorage.setItem(value45Save1237, sQz1237);
};

function square1238(){

    var sQz1238 = document.getElementById("imgSqrs1238").src;

    value45Save1238 = "zSqrArtSpecz1238";

    localStorage.setItem(value45Save1238, sQz1238);
};

function square1239(){

    var sQz1239 = document.getElementById("imgSqrs1239").src;

    value45Save1239 = "zSqrArtSpecz1239";

    localStorage.setItem(value45Save1239, sQz1239);
};

function square1240(){

    var sQz1240 = document.getElementById("imgSqrs1240").src;

    value45Save1240 = "zSqrArtSpecz1240";

    localStorage.setItem(value45Save1240, sQz1240);
};

function square1241(){

    var sQz1241 = document.getElementById("imgSqrs1241").src;

    value45Save1241 = "zSqrArtSpecz1241";

    localStorage.setItem(value45Save1241, sQz1241);
};

function square1242(){

    var sQz1242 = document.getElementById("imgSqrs1242").src;

    value45Save1242 = "zSqrArtSpecz1242";

    localStorage.setItem(value45Save1242, sQz1242);
};

function square1243(){

    var sQz1243 = document.getElementById("imgSqrs1243").src;

    value45Save1243 = "zSqrArtSpecz1243";

    localStorage.setItem(value45Save1243, sQz1243);
};

function square1244(){

    var sQz1244 = document.getElementById("imgSqrs1244").src;

    value45Save1244 = "zSqrArtSpecz1244";

    localStorage.setItem(value45Save1244, sQz1244);
};

function square1245(){

    var sQz1245 = document.getElementById("imgSqrs1245").src;

    value45Save1245 = "zSqrArtSpecz1245";

    localStorage.setItem(value45Save1245, sQz1245);
};

function square1246(){

    var sQz1246 = document.getElementById("imgSqrs1246").src;

    value45Save1246 = "zSqrArtSpecz1246";

    localStorage.setItem(value45Save1246, sQz1246);
};

function square1247(){

    var sQz1247 = document.getElementById("imgSqrs1247").src;

    value45Save1247 = "zSqrArtSpecz1247";

    localStorage.setItem(value45Save1247, sQz1247);
};

function square1248(){

    var sQz1248 = document.getElementById("imgSqrs1248").src;

    value45Save1248 = "zSqrArtSpecz1248";

    localStorage.setItem(value45Save1248, sQz1248);
};

function square1249(){

    var sQz1249 = document.getElementById("imgSqrs1249").src;

    value45Save1249 = "zSqrArtSpecz1249";

    localStorage.setItem(value45Save1249, sQz1249);
};

function square1250(){

    var sQz1250 = document.getElementById("imgSqrs1250").src;

    value45Save1250 = "zSqrArtSpecz1250";

    localStorage.setItem(value45Save1250, sQz1250);
};

function square1251(){

    var sQz1251 = document.getElementById("imgSqrs1251").src;

    value45Save1251 = "zSqrArtSpecz1251";

    localStorage.setItem(value45Save1251, sQz1251);
};

function square1252(){

    var sQz1252 = document.getElementById("imgSqrs1252").src;

    value45Save1252 = "zSqrArtSpecz1252";

    localStorage.setItem(value45Save1252, sQz1252);
};

function square1253(){

    var sQz1253 = document.getElementById("imgSqrs1253").src;

    value45Save1253 = "zSqrArtSpecz1253";

    localStorage.setItem(value45Save1253, sQz1253);
};

function square1254(){

    var sQz1254 = document.getElementById("imgSqrs1254").src;

    value45Save1254 = "zSqrArtSpecz1254";

    localStorage.setItem(value45Save1254, sQz1254);
};

function square1255(){

    var sQz1255 = document.getElementById("imgSqrs1255").src;

    value45Save1255 = "zSqrArtSpecz1255";

    localStorage.setItem(value45Save1255, sQz1255);
};

function square1256(){

    var sQz1256 = document.getElementById("imgSqrs1256").src;

    value45Save1256 = "zSqrArtSpecz1256";

    localStorage.setItem(value45Save1256, sQz1256);
};

function square1257(){

    var sQz1257 = document.getElementById("imgSqrs1257").src;

    value45Save1257 = "zSqrArtSpecz1257";

    localStorage.setItem(value45Save1257, sQz1257);
};

function square1258(){

    var sQz1258 = document.getElementById("imgSqrs1258").src;

    value45Save1258 = "zSqrArtSpecz1258";

    localStorage.setItem(value45Save1258, sQz1258);
};

function square1259(){

    var sQz1259 = document.getElementById("imgSqrs1259").src;

    value45Save1259 = "zSqrArtSpecz1259";

    localStorage.setItem(value45Save1259, sQz1259);
};

function square1260(){

    var sQz1260 = document.getElementById("imgSqrs1260").src;

    value45Save1260 = "zSqrArtSpecz1260";

    localStorage.setItem(value45Save1260, sQz1260);
};

function square1261(){

    var sQz1261 = document.getElementById("imgSqrs1261").src;

    value45Save1261 = "zSqrArtSpecz1261";

    localStorage.setItem(value45Save1261, sQz1261);
};

function square1262(){

    var sQz1262 = document.getElementById("imgSqrs1262").src;

    value45Save1262 = "zSqrArtSpecz1262";

    localStorage.setItem(value45Save1262, sQz1262);
};

function square1263(){

    var sQz1263 = document.getElementById("imgSqrs1263").src;

    value45Save1263 = "zSqrArtSpecz1263";

    localStorage.setItem(value45Save1263, sQz1263);
};

function square1264(){

    var sQz1264 = document.getElementById("imgSqrs1264").src;

    value45Save1264 = "zSqrArtSpecz1264";

    localStorage.setItem(value45Save1264, sQz1264);
};

function square1265(){

    var sQz1265 = document.getElementById("imgSqrs1265").src;

    value45Save1265 = "zSqrArtSpecz1265";

    localStorage.setItem(value45Save1265, sQz1265);
};

function square1266(){

    var sQz1266 = document.getElementById("imgSqrs1266").src;

    value45Save1266 = "zSqrArtSpecz1266";

    localStorage.setItem(value45Save1266, sQz1266);
};

function square1267(){

    var sQz1267 = document.getElementById("imgSqrs1267").src;

    value45Save1267 = "zSqrArtSpecz1267";

    localStorage.setItem(value45Save1267, sQz1267);
};

function square1268(){

    var sQz1268 = document.getElementById("imgSqrs1268").src;

    value45Save1268 = "zSqrArtSpecz1268";

    localStorage.setItem(value45Save1268, sQz1268);
};

function square1269(){

    var sQz1269 = document.getElementById("imgSqrs1269").src;

    value45Save1269 = "zSqrArtSpecz1269";

    localStorage.setItem(value45Save1269, sQz1269);
};

function square1270(){

    var sQz1270 = document.getElementById("imgSqrs1270").src;

    value45Save1270 = "zSqrArtSpecz1270";

    localStorage.setItem(value45Save1270, sQz1270);
};

function square1271(){

    var sQz1271 = document.getElementById("imgSqrs1271").src;

    value45Save1271 = "zSqrArtSpecz1271";

    localStorage.setItem(value45Save1271, sQz1271);
};

function square1272(){

    var sQz1272 = document.getElementById("imgSqrs1272").src;

    value45Save1272 = "zSqrArtSpecz1272";

    localStorage.setItem(value45Save1272, sQz1272);
};

function square1273(){

    var sQz1273 = document.getElementById("imgSqrs1273").src;

    value45Save1273 = "zSqrArtSpecz1273";

    localStorage.setItem(value45Save1273, sQz1273);
};

function square1274(){

    var sQz1274 = document.getElementById("imgSqrs1274").src;

    value45Save1274 = "zSqrArtSpecz1274";

    localStorage.setItem(value45Save1274, sQz1274);
};

function square1275(){

    var sQz1275 = document.getElementById("imgSqrs1275").src;

    value45Save1275 = "zSqrArtSpecz1275";

    localStorage.setItem(value45Save1275, sQz1275);
};

function square1276(){

    var sQz1276 = document.getElementById("imgSqrs1276").src;

    value45Save1276 = "zSqrArtSpecz1276";

    localStorage.setItem(value45Save1276, sQz1276);
};

function square1277(){

    var sQz1277 = document.getElementById("imgSqrs1277").src;

    value45Save1277 = "zSqrArtSpecz1277";

    localStorage.setItem(value45Save1277, sQz1277);
};

function square1278(){

    var sQz1278 = document.getElementById("imgSqrs1278").src;

    value45Save1278 = "zSqrArtSpecz1278";

    localStorage.setItem(value45Save1278, sQz1278);
};

function square1279(){

    var sQz1279 = document.getElementById("imgSqrs1279").src;

    value45Save1279 = "zSqrArtSpecz1279";

    localStorage.setItem(value45Save1279, sQz1279);
};

function square1280(){

    var sQz1280 = document.getElementById("imgSqrs1280").src;

    value45Save1280 = "zSqrArtSpecz1280";

    localStorage.setItem(value45Save1280, sQz1280);
};

function square1281(){

    var sQz1281 = document.getElementById("imgSqrs1281").src;

    value45Save1281 = "zSqrArtSpecz1281";

    localStorage.setItem(value45Save1281, sQz1281);
};

function square1282(){

    var sQz1282 = document.getElementById("imgSqrs1282").src;

    value45Save1282 = "zSqrArtSpecz1282";

    localStorage.setItem(value45Save1282, sQz1282);
};

function square1283(){

    var sQz1283 = document.getElementById("imgSqrs1283").src;

    value45Save1283 = "zSqrArtSpecz1283";

    localStorage.setItem(value45Save1283, sQz1283);
};

function square1284(){

    var sQz1284 = document.getElementById("imgSqrs1284").src;

    value45Save1284 = "zSqrArtSpecz1284";

    localStorage.setItem(value45Save1284, sQz1284);
};

function square1285(){

    var sQz1285 = document.getElementById("imgSqrs1285").src;

    value45Save1285 = "zSqrArtSpecz1285";

    localStorage.setItem(value45Save1285, sQz1285);
};

function square1286(){

    var sQz1286 = document.getElementById("imgSqrs1286").src;

    value45Save1286 = "zSqrArtSpecz1286";

    localStorage.setItem(value45Save1286, sQz1286);
};

function square1287(){

    var sQz1287 = document.getElementById("imgSqrs1287").src;

    value45Save1287 = "zSqrArtSpecz1287";

    localStorage.setItem(value45Save1287, sQz1287);
};

function square1288(){

    var sQz1288 = document.getElementById("imgSqrs1288").src;

    value45Save1288 = "zSqrArtSpecz1288";

    localStorage.setItem(value45Save1288, sQz1288);
};

function square1289(){

    var sQz1289 = document.getElementById("imgSqrs1289").src;

    value45Save1289 = "zSqrArtSpecz1289";

    localStorage.setItem(value45Save1289, sQz1289);
};

function square1290(){

    var sQz1290 = document.getElementById("imgSqrs1290").src;

    value45Save1290 = "zSqrArtSpecz1290";

    localStorage.setItem(value45Save1290, sQz1290);
};

function square1291(){

    var sQz1291 = document.getElementById("imgSqrs1291").src;

    value45Save1291 = "zSqrArtSpecz1291";

    localStorage.setItem(value45Save1291, sQz1291);
};

function square1292(){

    var sQz1292 = document.getElementById("imgSqrs1292").src;

    value45Save1292 = "zSqrArtSpecz1292";

    localStorage.setItem(value45Save1292, sQz1292);
};

function square1293(){

    var sQz1293 = document.getElementById("imgSqrs1293").src;

    value45Save1293 = "zSqrArtSpecz1293";

    localStorage.setItem(value45Save1293, sQz1293);
};

function square1294(){

    var sQz1294 = document.getElementById("imgSqrs1294").src;

    value45Save1294 = "zSqrArtSpecz1294";

    localStorage.setItem(value45Save1294, sQz1294);
};

function square1295(){

    var sQz1295 = document.getElementById("imgSqrs1295").src;

    value45Save1295 = "zSqrArtSpecz1295";

    localStorage.setItem(value45Save1295, sQz1295);
};

function square1296(){

    var sQz1296 = document.getElementById("imgSqrs1296").src;

    value45Save1296 = "zSqrArtSpecz1296";

    localStorage.setItem(value45Save1296, sQz1296);
};

function square1297(){

    var sQz1297 = document.getElementById("imgSqrs1297").src;

    value45Save1297 = "zSqrArtSpecz1297";

    localStorage.setItem(value45Save1297, sQz1297);
};

function square1298(){

    var sQz1298 = document.getElementById("imgSqrs1298").src;

    value45Save1298 = "zSqrArtSpecz1298";

    localStorage.setItem(value45Save1298, sQz1298);
};

function square1299(){

    var sQz1299 = document.getElementById("imgSqrs1299").src;

    value45Save1299 = "zSqrArtSpecz1299";

    localStorage.setItem(value45Save1299, sQz1299);
};

function square1300(){

    var sQz1300 = document.getElementById("imgSqrs1300").src;

    value45Save1300 = "zSqrArtSpecz1300";

    localStorage.setItem(value45Save1300, sQz1300);
};

function square1301(){

    var sQz1301 = document.getElementById("imgSqrs1301").src;

    value45Save1301 = "zSqrArtSpecz1301";

    localStorage.setItem(value45Save1301, sQz1301);
};

function square1302(){

    var sQz1302 = document.getElementById("imgSqrs1302").src;

    value45Save1302 = "zSqrArtSpecz1302";

    localStorage.setItem(value45Save1302, sQz1302);
};

function square1303(){

    var sQz1303 = document.getElementById("imgSqrs1303").src;

    value45Save1303 = "zSqrArtSpecz1303";

    localStorage.setItem(value45Save1303, sQz1303);
};

function square1304(){

    var sQz1304 = document.getElementById("imgSqrs1304").src;

    value45Save1304 = "zSqrArtSpecz1304";

    localStorage.setItem(value45Save1304, sQz1304);
};

function square1305(){

    var sQz1305 = document.getElementById("imgSqrs1305").src;

    value45Save1305 = "zSqrArtSpecz1305";

    localStorage.setItem(value45Save1305, sQz1305);
};

function square1306(){

    var sQz1306 = document.getElementById("imgSqrs1306").src;

    value45Save1306 = "zSqrArtSpecz1306";

    localStorage.setItem(value45Save1306, sQz1306);
};

function square1307(){

    var sQz1307 = document.getElementById("imgSqrs1307").src;

    value45Save1307 = "zSqrArtSpecz1307";

    localStorage.setItem(value45Save1307, sQz1307);
};

function square1308(){

    var sQz1308 = document.getElementById("imgSqrs1308").src;

    value45Save1308 = "zSqrArtSpecz1308";

    localStorage.setItem(value45Save1308, sQz1308);
};

function square1309(){

    var sQz1309 = document.getElementById("imgSqrs1309").src;

    value45Save1309 = "zSqrArtSpecz1309";

    localStorage.setItem(value45Save1309, sQz1309);
};

function square1310(){

    var sQz1310 = document.getElementById("imgSqrs1310").src;

    value45Save1310 = "zSqrArtSpecz1310";

    localStorage.setItem(value45Save1310, sQz1310);
};

function square1311(){

    var sQz1311 = document.getElementById("imgSqrs1311").src;

    value45Save1311 = "zSqrArtSpecz1311";

    localStorage.setItem(value45Save1311, sQz1311);
};

function square1312(){

    var sQz1312 = document.getElementById("imgSqrs1312").src;

    value45Save1312 = "zSqrArtSpecz1312";

    localStorage.setItem(value45Save1312, sQz1312);
};

function square1313(){

    var sQz1313 = document.getElementById("imgSqrs1313").src;

    value45Save1313 = "zSqrArtSpecz1313";

    localStorage.setItem(value45Save1313, sQz1313);
};

function square1314(){

    var sQz1314 = document.getElementById("imgSqrs1314").src;

    value45Save1314 = "zSqrArtSpecz1314";

    localStorage.setItem(value45Save1314, sQz1314);
};

function square1315(){

    var sQz1315 = document.getElementById("imgSqrs1315").src;

    value45Save1315 = "zSqrArtSpecz1315";

    localStorage.setItem(value45Save1315, sQz1315);
};

function square1316(){

    var sQz1316 = document.getElementById("imgSqrs1316").src;

    value45Save1316 = "zSqrArtSpecz1316";

    localStorage.setItem(value45Save1316, sQz1316);
};

function square1317(){

    var sQz1317 = document.getElementById("imgSqrs1317").src;

    value45Save1317 = "zSqrArtSpecz1317";

    localStorage.setItem(value45Save1317, sQz1317);
};

function square1318(){

    var sQz1318 = document.getElementById("imgSqrs1318").src;

    value45Save1318 = "zSqrArtSpecz1318";

    localStorage.setItem(value45Save1318, sQz1318);
};

function square1319(){

    var sQz1319 = document.getElementById("imgSqrs1319").src;

    value45Save1319 = "zSqrArtSpecz1319";

    localStorage.setItem(value45Save1319, sQz1319);
};

function square1320(){

    var sQz1320 = document.getElementById("imgSqrs1320").src;

    value45Save1320 = "zSqrArtSpecz1320";

    localStorage.setItem(value45Save1320, sQz1320);
};

function square1321(){

    var sQz1321 = document.getElementById("imgSqrs1321").src;

    value45Save1321 = "zSqrArtSpecz1321";

    localStorage.setItem(value45Save1321, sQz1321);
};

function square1322(){

    var sQz1322 = document.getElementById("imgSqrs1322").src;

    value45Save1322 = "zSqrArtSpecz1322";

    localStorage.setItem(value45Save1322, sQz1322);
};

function square1323(){

    var sQz1323 = document.getElementById("imgSqrs1323").src;

    value45Save1323 = "zSqrArtSpecz1323";

    localStorage.setItem(value45Save1323, sQz1323);
};

function square1324(){

    var sQz1324 = document.getElementById("imgSqrs1324").src;

    value45Save1324 = "zSqrArtSpecz1324";

    localStorage.setItem(value45Save1324, sQz1324);
};

function square1325(){

    var sQz1325 = document.getElementById("imgSqrs1325").src;

    value45Save1325 = "zSqrArtSpecz1325";

    localStorage.setItem(value45Save1325, sQz1325);
};

function square1326(){

    var sQz1326 = document.getElementById("imgSqrs1326").src;

    value45Save1326 = "zSqrArtSpecz1326";

    localStorage.setItem(value45Save1326, sQz1326);
};

function square1327(){

    var sQz1327 = document.getElementById("imgSqrs1327").src;

    value45Save1327 = "zSqrArtSpecz1327";

    localStorage.setItem(value45Save1327, sQz1327);
};

function square1328(){

    var sQz1328 = document.getElementById("imgSqrs1328").src;

    value45Save1328 = "zSqrArtSpecz1328";

    localStorage.setItem(value45Save1328, sQz1328);
};

function square1329(){

    var sQz1329 = document.getElementById("imgSqrs1329").src;

    value45Save1329 = "zSqrArtSpecz1329";

    localStorage.setItem(value45Save1329, sQz1329);
};

function square1330(){

    var sQz1330 = document.getElementById("imgSqrs1330").src;

    value45Save1330 = "zSqrArtSpecz1330";

    localStorage.setItem(value45Save1330, sQz1330);
};

function square1331(){

    var sQz1331 = document.getElementById("imgSqrs1331").src;

    value45Save1331 = "zSqrArtSpecz1331";

    localStorage.setItem(value45Save1331, sQz1331);
};

function square1332(){

    var sQz1332 = document.getElementById("imgSqrs1332").src;

    value45Save1332 = "zSqrArtSpecz1332";

    localStorage.setItem(value45Save1332, sQz1332);
};

function square1333(){

    var sQz1333 = document.getElementById("imgSqrs1333").src;

    value45Save1333 = "zSqrArtSpecz1333";

    localStorage.setItem(value45Save1333, sQz1333);
};

function square1334(){

    var sQz1334 = document.getElementById("imgSqrs1334").src;

    value45Save1334 = "zSqrArtSpecz1334";

    localStorage.setItem(value45Save1334, sQz1334);
};

function square1335(){

    var sQz1335 = document.getElementById("imgSqrs1335").src;

    value45Save1335 = "zSqrArtSpecz1335";

    localStorage.setItem(value45Save1335, sQz1335);
};

function square1336(){

    var sQz1336 = document.getElementById("imgSqrs1336").src;

    value45Save1336 = "zSqrArtSpecz1336";

    localStorage.setItem(value45Save1336, sQz1336);
};

function square1337(){

    var sQz1337 = document.getElementById("imgSqrs1337").src;

    value45Save1337 = "zSqrArtSpecz1337";

    localStorage.setItem(value45Save1337, sQz1337);
};

function square1338(){

    var sQz1338 = document.getElementById("imgSqrs1338").src;

    value45Save1338 = "zSqrArtSpecz1338";

    localStorage.setItem(value45Save1338, sQz1338);
};

function square1339(){

    var sQz1339 = document.getElementById("imgSqrs1339").src;

    value45Save1339 = "zSqrArtSpecz1339";

    localStorage.setItem(value45Save1339, sQz1339);
};

function square1340(){

    var sQz1340 = document.getElementById("imgSqrs1340").src;

    value45Save1340 = "zSqrArtSpecz1340";

    localStorage.setItem(value45Save1340, sQz1340);
};

function square1341(){

    var sQz1341 = document.getElementById("imgSqrs1341").src;

    value45Save1341 = "zSqrArtSpecz1341";

    localStorage.setItem(value45Save1341, sQz1341);
};

function square1342(){

    var sQz1342 = document.getElementById("imgSqrs1342").src;

    value45Save1342 = "zSqrArtSpecz1342";

    localStorage.setItem(value45Save1342, sQz1342);
};

function square1343(){

    var sQz1343 = document.getElementById("imgSqrs1343").src;

    value45Save1343 = "zSqrArtSpecz1343";

    localStorage.setItem(value45Save1343, sQz1343);
};

function square1344(){

    var sQz1344 = document.getElementById("imgSqrs1344").src;

    value45Save1344 = "zSqrArtSpecz1344";

    localStorage.setItem(value45Save1344, sQz1344);
};

function square1345(){

    var sQz1345 = document.getElementById("imgSqrs1345").src;

    value45Save1345 = "zSqrArtSpecz1345";

    localStorage.setItem(value45Save1345, sQz1345);
};

function square1346(){

    var sQz1346 = document.getElementById("imgSqrs1346").src;

    value45Save1346 = "zSqrArtSpecz1346";

    localStorage.setItem(value45Save1346, sQz1346);
};

function square1347(){

    var sQz1347 = document.getElementById("imgSqrs1347").src;

    value45Save1347 = "zSqrArtSpecz1347";

    localStorage.setItem(value45Save1347, sQz1347);
};

function square1348(){

    var sQz1348 = document.getElementById("imgSqrs1348").src;

    value45Save1348 = "zSqrArtSpecz1348";

    localStorage.setItem(value45Save1348, sQz1348);
};

function square1349(){

    var sQz1349 = document.getElementById("imgSqrs1349").src;

    value45Save1349 = "zSqrArtSpecz1349";

    localStorage.setItem(value45Save1349, sQz1349);
};

function square1350(){

    var sQz1350 = document.getElementById("imgSqrs1350").src;

    value45Save1350 = "zSqrArtSpecz1350";

    localStorage.setItem(value45Save1350, sQz1350);
};

function square1351(){

    var sQz1351 = document.getElementById("imgSqrs1351").src;

    value45Save1351 = "zSqrArtSpecz1351";

    localStorage.setItem(value45Save1351, sQz1351);
};

function square1352(){

    var sQz1352 = document.getElementById("imgSqrs1352").src;

    value45Save1352 = "zSqrArtSpecz1352";

    localStorage.setItem(value45Save1352, sQz1352);
};

function square1353(){

    var sQz1353 = document.getElementById("imgSqrs1353").src;

    value45Save1353 = "zSqrArtSpecz1353";

    localStorage.setItem(value45Save1353, sQz1353);
};

function square1354(){

    var sQz1354 = document.getElementById("imgSqrs1354").src;

    value45Save1354 = "zSqrArtSpecz1354";

    localStorage.setItem(value45Save1354, sQz1354);
};

function square1355(){

    var sQz1355 = document.getElementById("imgSqrs1355").src;

    value45Save1355 = "zSqrArtSpecz1355";

    localStorage.setItem(value45Save1355, sQz1355);
};

function square1356(){

    var sQz1356 = document.getElementById("imgSqrs1356").src;

    value45Save1356 = "zSqrArtSpecz1356";

    localStorage.setItem(value45Save1356, sQz1356);
};

function square1357(){

    var sQz1357 = document.getElementById("imgSqrs1357").src;

    value45Save1357 = "zSqrArtSpecz1357";

    localStorage.setItem(value45Save1357, sQz1357);
};

function square1358(){

    var sQz1358 = document.getElementById("imgSqrs1358").src;

    value45Save1358 = "zSqrArtSpecz1358";

    localStorage.setItem(value45Save1358, sQz1358);
};

function square1359(){

    var sQz1359 = document.getElementById("imgSqrs1359").src;

    value45Save1359 = "zSqrArtSpecz1359";

    localStorage.setItem(value45Save1359, sQz1359);
};

function square1360(){

    var sQz1360 = document.getElementById("imgSqrs1360").src;

    value45Save1360 = "zSqrArtSpecz1360";

    localStorage.setItem(value45Save1360, sQz1360);
};

function square1361(){

    var sQz1361 = document.getElementById("imgSqrs1361").src;

    value45Save1361 = "zSqrArtSpecz1361";

    localStorage.setItem(value45Save1361, sQz1361);
};

function square1362(){

    var sQz1362 = document.getElementById("imgSqrs1362").src;

    value45Save1362 = "zSqrArtSpecz1362";

    localStorage.setItem(value45Save1362, sQz1362);
};

function square1363(){

    var sQz1363 = document.getElementById("imgSqrs1363").src;

    value45Save1363 = "zSqrArtSpecz1363";

    localStorage.setItem(value45Save1363, sQz1363);
};

function square1364(){

    var sQz1364 = document.getElementById("imgSqrs1364").src;

    value45Save1364 = "zSqrArtSpecz1364";

    localStorage.setItem(value45Save1364, sQz1364);
};

function square1365(){

    var sQz1365 = document.getElementById("imgSqrs1365").src;

    value45Save1365 = "zSqrArtSpecz1365";

    localStorage.setItem(value45Save1365, sQz1365);
};

function square1366(){

    var sQz1366 = document.getElementById("imgSqrs1366").src;

    value45Save1366 = "zSqrArtSpecz1366";

    localStorage.setItem(value45Save1366, sQz1366);
};

function square1367(){

    var sQz1367 = document.getElementById("imgSqrs1367").src;

    value45Save1367 = "zSqrArtSpecz1367";

    localStorage.setItem(value45Save1367, sQz1367);
};

function square1368(){

    var sQz1368 = document.getElementById("imgSqrs1368").src;

    value45Save1368 = "zSqrArtSpecz1368";

    localStorage.setItem(value45Save1368, sQz1368);
};

function square1369(){

    var sQz1369 = document.getElementById("imgSqrs1369").src;

    value45Save1369 = "zSqrArtSpecz1369";

    localStorage.setItem(value45Save1369, sQz1369);
};

function square1370(){

    var sQz1370 = document.getElementById("imgSqrs1370").src;

    value45Save1370 = "zSqrArtSpecz1370";

    localStorage.setItem(value45Save1370, sQz1370);
};

function square1371(){

    var sQz1371 = document.getElementById("imgSqrs1371").src;

    value45Save1371 = "zSqrArtSpecz1371";

    localStorage.setItem(value45Save1371, sQz1371);
};

function square1372(){

    var sQz1372 = document.getElementById("imgSqrs1372").src;

    value45Save1372 = "zSqrArtSpecz1372";

    localStorage.setItem(value45Save1372, sQz1372);
};

function square1373(){

    var sQz1373 = document.getElementById("imgSqrs1373").src;

    value45Save1373 = "zSqrArtSpecz1373";

    localStorage.setItem(value45Save1373, sQz1373);
};

function square1374(){

    var sQz1374 = document.getElementById("imgSqrs1374").src;

    value45Save1374 = "zSqrArtSpecz1374";

    localStorage.setItem(value45Save1374, sQz1374);
};

function square1375(){

    var sQz1375 = document.getElementById("imgSqrs1375").src;

    value45Save1375 = "zSqrArtSpecz1375";

    localStorage.setItem(value45Save1375, sQz1375);
};

function square1376(){

    var sQz1376 = document.getElementById("imgSqrs1376").src;

    value45Save1376 = "zSqrArtSpecz1376";

    localStorage.setItem(value45Save1376, sQz1376);
};

function square1377(){

    var sQz1377 = document.getElementById("imgSqrs1377").src;

    value45Save1377 = "zSqrArtSpecz1377";

    localStorage.setItem(value45Save1377, sQz1377);
};

function square1378(){

    var sQz1378 = document.getElementById("imgSqrs1378").src;

    value45Save1378 = "zSqrArtSpecz1378";

    localStorage.setItem(value45Save1378, sQz1378);
};

function square1379(){

    var sQz1379 = document.getElementById("imgSqrs1379").src;

    value45Save1379 = "zSqrArtSpecz1379";

    localStorage.setItem(value45Save1379, sQz1379);
};

function square1380(){

    var sQz1380 = document.getElementById("imgSqrs1380").src;

    value45Save1380 = "zSqrArtSpecz1380";

    localStorage.setItem(value45Save1380, sQz1380);
};

function square1381(){

    var sQz1381 = document.getElementById("imgSqrs1381").src;

    value45Save1381 = "zSqrArtSpecz1381";

    localStorage.setItem(value45Save1381, sQz1381);
};

function square1382(){

    var sQz1382 = document.getElementById("imgSqrs1382").src;

    value45Save1382 = "zSqrArtSpecz1382";

    localStorage.setItem(value45Save1382, sQz1382);
};

function square1383(){

    var sQz1383 = document.getElementById("imgSqrs1383").src;

    value45Save1383 = "zSqrArtSpecz1383";

    localStorage.setItem(value45Save1383, sQz1383);
};

function square1384(){

    var sQz1384 = document.getElementById("imgSqrs1384").src;

    value45Save1384 = "zSqrArtSpecz1384";

    localStorage.setItem(value45Save1384, sQz1384);
};

function square1385(){

    var sQz1385 = document.getElementById("imgSqrs1385").src;

    value45Save1385 = "zSqrArtSpecz1385";

    localStorage.setItem(value45Save1385, sQz1385);
};

function square1386(){

    var sQz1386 = document.getElementById("imgSqrs1386").src;

    value45Save1386 = "zSqrArtSpecz1386";

    localStorage.setItem(value45Save1386, sQz1386);
};

function square1387(){

    var sQz1387 = document.getElementById("imgSqrs1387").src;

    value45Save1387 = "zSqrArtSpecz1387";

    localStorage.setItem(value45Save1387, sQz1387);
};

function square1388(){

    var sQz1388 = document.getElementById("imgSqrs1388").src;

    value45Save1388 = "zSqrArtSpecz1388";

    localStorage.setItem(value45Save1388, sQz1388);
};

function square1389(){

    var sQz1389 = document.getElementById("imgSqrs1389").src;

    value45Save1389 = "zSqrArtSpecz1389";

    localStorage.setItem(value45Save1389, sQz1389);
};

function square1390(){

    var sQz1390 = document.getElementById("imgSqrs1390").src;

    value45Save1390 = "zSqrArtSpecz1390";

    localStorage.setItem(value45Save1390, sQz1390);
};

function square1391(){

    var sQz1391 = document.getElementById("imgSqrs1391").src;

    value45Save1391 = "zSqrArtSpecz1391";

    localStorage.setItem(value45Save1391, sQz1391);
};

function square1392(){

    var sQz1392 = document.getElementById("imgSqrs1392").src;

    value45Save1392 = "zSqrArtSpecz1392";

    localStorage.setItem(value45Save1392, sQz1392);
};

function square1393(){

    var sQz1393 = document.getElementById("imgSqrs1393").src;

    value45Save1393 = "zSqrArtSpecz1393";

    localStorage.setItem(value45Save1393, sQz1393);
};

function square1394(){

    var sQz1394 = document.getElementById("imgSqrs1394").src;

    value45Save1394 = "zSqrArtSpecz1394";

    localStorage.setItem(value45Save1394, sQz1394);
};

function square1395(){

    var sQz1395 = document.getElementById("imgSqrs1395").src;

    value45Save1395 = "zSqrArtSpecz1395";

    localStorage.setItem(value45Save1395, sQz1395);
};

function square1396(){

    var sQz1396 = document.getElementById("imgSqrs1396").src;

    value45Save1396 = "zSqrArtSpecz1396";

    localStorage.setItem(value45Save1396, sQz1396);
};

function square1397(){

    var sQz1397 = document.getElementById("imgSqrs1397").src;

    value45Save1397 = "zSqrArtSpecz1397";

    localStorage.setItem(value45Save1397, sQz1397);
};

function square1398(){

    var sQz1398 = document.getElementById("imgSqrs1398").src;

    value45Save1398 = "zSqrArtSpecz1398";

    localStorage.setItem(value45Save1398, sQz1398);
};

function square1399(){

    var sQz1399 = document.getElementById("imgSqrs1399").src;

    value45Save1399 = "zSqrArtSpecz1399";

    localStorage.setItem(value45Save1399, sQz1399);
};

function square1400(){

    var sQz1400 = document.getElementById("imgSqrs1400").src;

    value45Save1400 = "zSqrArtSpecz1400";

    localStorage.setItem(value45Save1400, sQz1400);
};

function square1401(){

    var sQz1401 = document.getElementById("imgSqrs1401").src;

    value45Save1401 = "zSqrArtSpecz1401";

    localStorage.setItem(value45Save1401, sQz1401);
};

function square1402(){

    var sQz1402 = document.getElementById("imgSqrs1402").src;

    value45Save1402 = "zSqrArtSpecz1402";

    localStorage.setItem(value45Save1402, sQz1402);
};

function square1403(){

    var sQz1403 = document.getElementById("imgSqrs1403").src;

    value45Save1403 = "zSqrArtSpecz1403";

    localStorage.setItem(value45Save1403, sQz1403);
};

function square1404(){

    var sQz1404 = document.getElementById("imgSqrs1404").src;

    value45Save1404 = "zSqrArtSpecz1404";

    localStorage.setItem(value45Save1404, sQz1404);
};

function square1405(){

    var sQz1405 = document.getElementById("imgSqrs1405").src;

    value45Save1405 = "zSqrArtSpecz1405";

    localStorage.setItem(value45Save1405, sQz1405);
};

function square1406(){

    var sQz1406 = document.getElementById("imgSqrs1406").src;

    value45Save1406 = "zSqrArtSpecz1406";

    localStorage.setItem(value45Save1406, sQz1406);
};

function square1407(){

    var sQz1407 = document.getElementById("imgSqrs1407").src;

    value45Save1407 = "zSqrArtSpecz1407";

    localStorage.setItem(value45Save1407, sQz1407);
};

function square1408(){

    var sQz1408 = document.getElementById("imgSqrs1408").src;

    value45Save1408 = "zSqrArtSpecz1408";

    localStorage.setItem(value45Save1408, sQz1408);
};

function square1409(){

    var sQz1409 = document.getElementById("imgSqrs1409").src;

    value45Save1409 = "zSqrArtSpecz1409";

    localStorage.setItem(value45Save1409, sQz1409);
};

function square1410(){

    var sQz1410 = document.getElementById("imgSqrs1410").src;

    value45Save1410 = "zSqrArtSpecz1410";

    localStorage.setItem(value45Save1410, sQz1410);
};

function square1411(){

    var sQz1411 = document.getElementById("imgSqrs1411").src;

    value45Save1411 = "zSqrArtSpecz1411";

    localStorage.setItem(value45Save1411, sQz1411);
};

function square1412(){

    var sQz1412 = document.getElementById("imgSqrs1412").src;

    value45Save1412 = "zSqrArtSpecz1412";

    localStorage.setItem(value45Save1412, sQz1412);
};

function square1413(){

    var sQz1413 = document.getElementById("imgSqrs1413").src;

    value45Save1413 = "zSqrArtSpecz1413";

    localStorage.setItem(value45Save1413, sQz1413);
};

function square1414(){

    var sQz1414 = document.getElementById("imgSqrs1414").src;

    value45Save1414 = "zSqrArtSpecz1414";

    localStorage.setItem(value45Save1414, sQz1414);
};

function square1415(){

    var sQz1415 = document.getElementById("imgSqrs1415").src;

    value45Save1415 = "zSqrArtSpecz1415";

    localStorage.setItem(value45Save1415, sQz1415);
};

function square1416(){

    var sQz1416 = document.getElementById("imgSqrs1416").src;

    value45Save1416 = "zSqrArtSpecz1416";

    localStorage.setItem(value45Save1416, sQz1416);
};

function square1417(){

    var sQz1417 = document.getElementById("imgSqrs1417").src;

    value45Save1417 = "zSqrArtSpecz1417";

    localStorage.setItem(value45Save1417, sQz1417);
};

function square1418(){

    var sQz1418 = document.getElementById("imgSqrs1418").src;

    value45Save1418 = "zSqrArtSpecz1418";

    localStorage.setItem(value45Save1418, sQz1418);
};

function square1419(){

    var sQz1419 = document.getElementById("imgSqrs1419").src;

    value45Save1419 = "zSqrArtSpecz1419";

    localStorage.setItem(value45Save1419, sQz1419);
};

function square1420(){

    var sQz1420 = document.getElementById("imgSqrs1420").src;

    value45Save1420 = "zSqrArtSpecz1420";

    localStorage.setItem(value45Save1420, sQz1420);
};

function square1421(){

    var sQz1421 = document.getElementById("imgSqrs1421").src;

    value45Save1421 = "zSqrArtSpecz1421";

    localStorage.setItem(value45Save1421, sQz1421);
};

function square1422(){

    var sQz1422 = document.getElementById("imgSqrs1422").src;

    value45Save1422 = "zSqrArtSpecz1422";

    localStorage.setItem(value45Save1422, sQz1422);
};

function square1423(){

    var sQz1423 = document.getElementById("imgSqrs1423").src;

    value45Save1423 = "zSqrArtSpecz1423";

    localStorage.setItem(value45Save1423, sQz1423);
};

function square1424(){

    var sQz1424 = document.getElementById("imgSqrs1424").src;

    value45Save1424 = "zSqrArtSpecz1424";

    localStorage.setItem(value45Save1424, sQz1424);
};

function square1425(){

    var sQz1425 = document.getElementById("imgSqrs1425").src;

    value45Save1425 = "zSqrArtSpecz1425";

    localStorage.setItem(value45Save1425, sQz1425);
};

function square1426(){

    var sQz1426 = document.getElementById("imgSqrs1426").src;

    value45Save1426 = "zSqrArtSpecz1426";

    localStorage.setItem(value45Save1426, sQz1426);
};

function square1427(){

    var sQz1427 = document.getElementById("imgSqrs1427").src;

    value45Save1427 = "zSqrArtSpecz1427";

    localStorage.setItem(value45Save1427, sQz1427);
};

function square1428(){

    var sQz1428 = document.getElementById("imgSqrs1428").src;

    value45Save1428 = "zSqrArtSpecz1428";

    localStorage.setItem(value45Save1428, sQz1428);
};

function square1429(){

    var sQz1429 = document.getElementById("imgSqrs1429").src;

    value45Save1429 = "zSqrArtSpecz1429";

    localStorage.setItem(value45Save1429, sQz1429);
};

function square1430(){

    var sQz1430 = document.getElementById("imgSqrs1430").src;

    value45Save1430 = "zSqrArtSpecz1430";

    localStorage.setItem(value45Save1430, sQz1430);
};

function square1431(){

    var sQz1431 = document.getElementById("imgSqrs1431").src;

    value45Save1431 = "zSqrArtSpecz1431";

    localStorage.setItem(value45Save1431, sQz1431);
};

function square1432(){

    var sQz1432 = document.getElementById("imgSqrs1432").src;

    value45Save1432 = "zSqrArtSpecz1432";

    localStorage.setItem(value45Save1432, sQz1432);
};

function square1433(){

    var sQz1433 = document.getElementById("imgSqrs1433").src;

    value45Save1433 = "zSqrArtSpecz1433";

    localStorage.setItem(value45Save1433, sQz1433);
};

function square1434(){

    var sQz1434 = document.getElementById("imgSqrs1434").src;

    value45Save1434 = "zSqrArtSpecz1434";

    localStorage.setItem(value45Save1434, sQz1434);
};

function square1435(){

    var sQz1435 = document.getElementById("imgSqrs1435").src;

    value45Save1435 = "zSqrArtSpecz1435";

    localStorage.setItem(value45Save1435, sQz1435);
};

function square1436(){

    var sQz1436 = document.getElementById("imgSqrs1436").src;

    value45Save1436 = "zSqrArtSpecz1436";

    localStorage.setItem(value45Save1436, sQz1436);
};

function square1437(){

    var sQz1437 = document.getElementById("imgSqrs1437").src;

    value45Save1437 = "zSqrArtSpecz1437";

    localStorage.setItem(value45Save1437, sQz1437);
};

function square1438(){

    var sQz1438 = document.getElementById("imgSqrs1438").src;

    value45Save1438 = "zSqrArtSpecz1438";

    localStorage.setItem(value45Save1438, sQz1438);
};

function square1439(){

    var sQz1439 = document.getElementById("imgSqrs1439").src;

    value45Save1439 = "zSqrArtSpecz1439";

    localStorage.setItem(value45Save1439, sQz1439);
};

function square1440(){

    var sQz1440 = document.getElementById("imgSqrs1440").src;

    value45Save1440 = "zSqrArtSpecz1440";

    localStorage.setItem(value45Save1440, sQz1440);
};

function square1441(){

    var sQz1441 = document.getElementById("imgSqrs1441").src;

    value45Save1441 = "zSqrArtSpecz1441";

    localStorage.setItem(value45Save1441, sQz1441);
};

function square1442(){

    var sQz1442 = document.getElementById("imgSqrs1442").src;

    value45Save1442 = "zSqrArtSpecz1442";

    localStorage.setItem(value45Save1442, sQz1442);
};

function square1443(){

    var sQz1443 = document.getElementById("imgSqrs1443").src;

    value45Save1443 = "zSqrArtSpecz1443";

    localStorage.setItem(value45Save1443, sQz1443);
};

function square1444(){

    var sQz1444 = document.getElementById("imgSqrs1444").src;

    value45Save1444 = "zSqrArtSpecz1444";

    localStorage.setItem(value45Save1444, sQz1444);
};

function square1445(){

    var sQz1445 = document.getElementById("imgSqrs1445").src;

    value45Save1445 = "zSqrArtSpecz1445";

    localStorage.setItem(value45Save1445, sQz1445);
};

function square1446(){

    var sQz1446 = document.getElementById("imgSqrs1446").src;

    value45Save1446 = "zSqrArtSpecz1446";

    localStorage.setItem(value45Save1446, sQz1446);
};

function square1447(){

    var sQz1447 = document.getElementById("imgSqrs1447").src;

    value45Save1447 = "zSqrArtSpecz1447";

    localStorage.setItem(value45Save1447, sQz1447);
};

function square1448(){

    var sQz1448 = document.getElementById("imgSqrs1448").src;

    value45Save1448 = "zSqrArtSpecz1448";

    localStorage.setItem(value45Save1448, sQz1448);
};

function square1449(){

    var sQz1449 = document.getElementById("imgSqrs1449").src;

    value45Save1449 = "zSqrArtSpecz1449";

    localStorage.setItem(value45Save1449, sQz1449);
};

function square1450(){

    var sQz1450 = document.getElementById("imgSqrs1450").src;

    value45Save1450 = "zSqrArtSpecz1450";

    localStorage.setItem(value45Save1450, sQz1450);
};

function square1451(){

    var sQz1451 = document.getElementById("imgSqrs1451").src;

    value45Save1451 = "zSqrArtSpecz1451";

    localStorage.setItem(value45Save1451, sQz1451);
};

function square1452(){

    var sQz1452 = document.getElementById("imgSqrs1452").src;

    value45Save1452 = "zSqrArtSpecz1452";

    localStorage.setItem(value45Save1452, sQz1452);
};

function square1453(){

    var sQz1453 = document.getElementById("imgSqrs1453").src;

    value45Save1453 = "zSqrArtSpecz1453";

    localStorage.setItem(value45Save1453, sQz1453);
};

function square1454(){

    var sQz1454 = document.getElementById("imgSqrs1454").src;

    value45Save1454 = "zSqrArtSpecz1454";

    localStorage.setItem(value45Save1454, sQz1454);
};

function square1455(){

    var sQz1455 = document.getElementById("imgSqrs1455").src;

    value45Save1455 = "zSqrArtSpecz1455";

    localStorage.setItem(value45Save1455, sQz1455);
};

function square1456(){

    var sQz1456 = document.getElementById("imgSqrs1456").src;

    value45Save1456 = "zSqrArtSpecz1456";

    localStorage.setItem(value45Save1456, sQz1456);
};

function square1457(){

    var sQz1457 = document.getElementById("imgSqrs1457").src;

    value45Save1457 = "zSqrArtSpecz1457";

    localStorage.setItem(value45Save1457, sQz1457);
};

function square1458(){

    var sQz1458 = document.getElementById("imgSqrs1458").src;

    value45Save1458 = "zSqrArtSpecz1458";

    localStorage.setItem(value45Save1458, sQz1458);
};

function square1459(){

    var sQz1459 = document.getElementById("imgSqrs1459").src;

    value45Save1459 = "zSqrArtSpecz1459";

    localStorage.setItem(value45Save1459, sQz1459);
};

function square1460(){

    var sQz1460 = document.getElementById("imgSqrs1460").src;

    value45Save1460 = "zSqrArtSpecz1460";

    localStorage.setItem(value45Save1460, sQz1460);
};

function square1461(){

    var sQz1461 = document.getElementById("imgSqrs1461").src;

    value45Save1461 = "zSqrArtSpecz1461";

    localStorage.setItem(value45Save1461, sQz1461);
};

function square1462(){

    var sQz1462 = document.getElementById("imgSqrs1462").src;

    value45Save1462 = "zSqrArtSpecz1462";

    localStorage.setItem(value45Save1462, sQz1462);
};

function square1463(){

    var sQz1463 = document.getElementById("imgSqrs1463").src;

    value45Save1463 = "zSqrArtSpecz1463";

    localStorage.setItem(value45Save1463, sQz1463);
};

function square1464(){

    var sQz1464 = document.getElementById("imgSqrs1464").src;

    value45Save1464 = "zSqrArtSpecz1464";

    localStorage.setItem(value45Save1464, sQz1464);
};

function square1465(){

    var sQz1465 = document.getElementById("imgSqrs1465").src;

    value45Save1465 = "zSqrArtSpecz1465";

    localStorage.setItem(value45Save1465, sQz1465);
};

function square1466(){

    var sQz1466 = document.getElementById("imgSqrs1466").src;

    value45Save1466 = "zSqrArtSpecz1466";

    localStorage.setItem(value45Save1466, sQz1466);
};

function square1467(){

    var sQz1467 = document.getElementById("imgSqrs1467").src;

    value45Save1467 = "zSqrArtSpecz1467";

    localStorage.setItem(value45Save1467, sQz1467);
};

function square1468(){

    var sQz1468 = document.getElementById("imgSqrs1468").src;

    value45Save1468 = "zSqrArtSpecz1468";

    localStorage.setItem(value45Save1468, sQz1468);
};

function square1469(){

    var sQz1469 = document.getElementById("imgSqrs1469").src;

    value45Save1469 = "zSqrArtSpecz1469";

    localStorage.setItem(value45Save1469, sQz1469);
};

function square1470(){

    var sQz1470 = document.getElementById("imgSqrs1470").src;

    value45Save1470 = "zSqrArtSpecz1470";

    localStorage.setItem(value45Save1470, sQz1470);
};

function square1471(){

    var sQz1471 = document.getElementById("imgSqrs1471").src;

    value45Save1471 = "zSqrArtSpecz1471";

    localStorage.setItem(value45Save1471, sQz1471);
};

function square1472(){

    var sQz1472 = document.getElementById("imgSqrs1472").src;

    value45Save1472 = "zSqrArtSpecz1472";

    localStorage.setItem(value45Save1472, sQz1472);
};

function square1473(){

    var sQz1473 = document.getElementById("imgSqrs1473").src;

    value45Save1473 = "zSqrArtSpecz1473";

    localStorage.setItem(value45Save1473, sQz1473);
};

function square1474(){

    var sQz1474 = document.getElementById("imgSqrs1474").src;

    value45Save1474 = "zSqrArtSpecz1474";

    localStorage.setItem(value45Save1474, sQz1474);
};

function square1475(){

    var sQz1475 = document.getElementById("imgSqrs1475").src;

    value45Save1475 = "zSqrArtSpecz1475";

    localStorage.setItem(value45Save1475, sQz1475);
};

function square1476(){

    var sQz1476 = document.getElementById("imgSqrs1476").src;

    value45Save1476 = "zSqrArtSpecz1476";

    localStorage.setItem(value45Save1476, sQz1476);
};

function square1477(){

    var sQz1477 = document.getElementById("imgSqrs1477").src;

    value45Save1477 = "zSqrArtSpecz1477";

    localStorage.setItem(value45Save1477, sQz1477);
};

function square1478(){

    var sQz1478 = document.getElementById("imgSqrs1478").src;

    value45Save1478 = "zSqrArtSpecz1478";

    localStorage.setItem(value45Save1478, sQz1478);
};

function square1479(){

    var sQz1479 = document.getElementById("imgSqrs1479").src;

    value45Save1479 = "zSqrArtSpecz1479";

    localStorage.setItem(value45Save1479, sQz1479);
};

function square1480(){

    var sQz1480 = document.getElementById("imgSqrs1480").src;

    value45Save1480 = "zSqrArtSpecz1480";

    localStorage.setItem(value45Save1480, sQz1480);
};

function square1481(){

    var sQz1481 = document.getElementById("imgSqrs1481").src;

    value45Save1481 = "zSqrArtSpecz1481";

    localStorage.setItem(value45Save1481, sQz1481);
};

function square1482(){

    var sQz1482 = document.getElementById("imgSqrs1482").src;

    value45Save1482 = "zSqrArtSpecz1482";

    localStorage.setItem(value45Save1482, sQz1482);
};

function square1483(){

    var sQz1483 = document.getElementById("imgSqrs1483").src;

    value45Save1483 = "zSqrArtSpecz1483";

    localStorage.setItem(value45Save1483, sQz1483);
};

function square1484(){

    var sQz1484 = document.getElementById("imgSqrs1484").src;

    value45Save1484 = "zSqrArtSpecz1484";

    localStorage.setItem(value45Save1484, sQz1484);
};

function square1485(){

    var sQz1485 = document.getElementById("imgSqrs1485").src;

    value45Save1485 = "zSqrArtSpecz1485";

    localStorage.setItem(value45Save1485, sQz1485);
};

function square1486(){

    var sQz1486 = document.getElementById("imgSqrs1486").src;

    value45Save1486 = "zSqrArtSpecz1486";

    localStorage.setItem(value45Save1486, sQz1486);
};

function square1487(){

    var sQz1487 = document.getElementById("imgSqrs1487").src;

    value45Save1487 = "zSqrArtSpecz1487";

    localStorage.setItem(value45Save1487, sQz1487);
};

function square1488(){

    var sQz1488 = document.getElementById("imgSqrs1488").src;

    value45Save1488 = "zSqrArtSpecz1488";

    localStorage.setItem(value45Save1488, sQz1488);
};

function square1489(){

    var sQz1489 = document.getElementById("imgSqrs1489").src;

    value45Save1489 = "zSqrArtSpecz1489";

    localStorage.setItem(value45Save1489, sQz1489);
};

function square1490(){

    var sQz1490 = document.getElementById("imgSqrs1490").src;

    value45Save1490 = "zSqrArtSpecz1490";

    localStorage.setItem(value45Save1490, sQz1490);
};

function square1491(){

    var sQz1491 = document.getElementById("imgSqrs1491").src;

    value45Save1491 = "zSqrArtSpecz1491";

    localStorage.setItem(value45Save1491, sQz1491);
};

function square1492(){

    var sQz1492 = document.getElementById("imgSqrs1492").src;

    value45Save1492 = "zSqrArtSpecz1492";

    localStorage.setItem(value45Save1492, sQz1492);
};

function square1493(){

    var sQz1493 = document.getElementById("imgSqrs1493").src;

    value45Save1493 = "zSqrArtSpecz1493";

    localStorage.setItem(value45Save1493, sQz1493);
};

function square1494(){

    var sQz1494 = document.getElementById("imgSqrs1494").src;

    value45Save1494 = "zSqrArtSpecz1494";

    localStorage.setItem(value45Save1494, sQz1494);
};

function square1495(){

    var sQz1495 = document.getElementById("imgSqrs1495").src;

    value45Save1495 = "zSqrArtSpecz1495";

    localStorage.setItem(value45Save1495, sQz1495);
};

function square1496(){

    var sQz1496 = document.getElementById("imgSqrs1496").src;

    value45Save1496 = "zSqrArtSpecz1496";

    localStorage.setItem(value45Save1496, sQz1496);
};

function square1497(){

    var sQz1497 = document.getElementById("imgSqrs1497").src;

    value45Save1497 = "zSqrArtSpecz1497";

    localStorage.setItem(value45Save1497, sQz1497);
};

function square1498(){

    var sQz1498 = document.getElementById("imgSqrs1498").src;

    value45Save1498 = "zSqrArtSpecz1498";

    localStorage.setItem(value45Save1498, sQz1498);
};

function square1499(){

    var sQz1499 = document.getElementById("imgSqrs1499").src;

    value45Save1499 = "zSqrArtSpecz1499";

    localStorage.setItem(value45Save1499, sQz1499);
};

function square1500(){

    var sQz1500 = document.getElementById("imgSqrs1500").src;

    value45Save1500 = "zSqrArtSpecz1500";

    localStorage.setItem(value45Save1500, sQz1500);
};

function square1501(){

    var sQz1501 = document.getElementById("imgSqrs1501").src;

    value45Save1501 = "zSqrArtSpecz1501";

    localStorage.setItem(value45Save1501, sQz1501);
};

function square1502(){

    var sQz1502 = document.getElementById("imgSqrs1502").src;

    value45Save1502 = "zSqrArtSpecz1502";

    localStorage.setItem(value45Save1502, sQz1502);
};

function square1503(){

    var sQz1503 = document.getElementById("imgSqrs1503").src;

    value45Save1503 = "zSqrArtSpecz1503";

    localStorage.setItem(value45Save1503, sQz1503);
};

function square1504(){

    var sQz1504 = document.getElementById("imgSqrs1504").src;

    value45Save1504 = "zSqrArtSpecz1504";

    localStorage.setItem(value45Save1504, sQz1504);
};

function square1505(){

    var sQz1505 = document.getElementById("imgSqrs1505").src;

    value45Save1505 = "zSqrArtSpecz1505";

    localStorage.setItem(value45Save1505, sQz1505);
};

function square1506(){

    var sQz1506 = document.getElementById("imgSqrs1506").src;

    value45Save1506 = "zSqrArtSpecz1506";

    localStorage.setItem(value45Save1506, sQz1506);
};

function square1507(){

    var sQz1507 = document.getElementById("imgSqrs1507").src;

    value45Save1507 = "zSqrArtSpecz1507";

    localStorage.setItem(value45Save1507, sQz1507);
};

function square1508(){

    var sQz1508 = document.getElementById("imgSqrs1508").src;

    value45Save1508 = "zSqrArtSpecz1508";

    localStorage.setItem(value45Save1508, sQz1508);
};

function square1509(){

    var sQz1509 = document.getElementById("imgSqrs1509").src;

    value45Save1509 = "zSqrArtSpecz1509";

    localStorage.setItem(value45Save1509, sQz1509);
};

function square1510(){

    var sQz1510 = document.getElementById("imgSqrs1510").src;

    value45Save1510 = "zSqrArtSpecz1510";

    localStorage.setItem(value45Save1510, sQz1510);
};

function square1511(){

    var sQz1511 = document.getElementById("imgSqrs1511").src;

    value45Save1511 = "zSqrArtSpecz1511";

    localStorage.setItem(value45Save1511, sQz1511);
};

function square1512(){

    var sQz1512 = document.getElementById("imgSqrs1512").src;

    value45Save1512 = "zSqrArtSpecz1512";

    localStorage.setItem(value45Save1512, sQz1512);
};

function square1513(){

    var sQz1513 = document.getElementById("imgSqrs1513").src;

    value45Save1513 = "zSqrArtSpecz1513";

    localStorage.setItem(value45Save1513, sQz1513);
};

function square1514(){

    var sQz1514 = document.getElementById("imgSqrs1514").src;

    value45Save1514 = "zSqrArtSpecz1514";

    localStorage.setItem(value45Save1514, sQz1514);
};

function square1515(){

    var sQz1515 = document.getElementById("imgSqrs1515").src;

    value45Save1515 = "zSqrArtSpecz1515";

    localStorage.setItem(value45Save1515, sQz1515);
};

function square1516(){

    var sQz1516 = document.getElementById("imgSqrs1516").src;

    value45Save1516 = "zSqrArtSpecz1516";

    localStorage.setItem(value45Save1516, sQz1516);
};

function square1517(){

    var sQz1517 = document.getElementById("imgSqrs1517").src;

    value45Save1517 = "zSqrArtSpecz1517";

    localStorage.setItem(value45Save1517, sQz1517);
};

function square1518(){

    var sQz1518 = document.getElementById("imgSqrs1518").src;

    value45Save1518 = "zSqrArtSpecz1518";

    localStorage.setItem(value45Save1518, sQz1518);
};

function square1519(){

    var sQz1519 = document.getElementById("imgSqrs1519").src;

    value45Save1519 = "zSqrArtSpecz1519";

    localStorage.setItem(value45Save1519, sQz1519);
};

function square1520(){

    var sQz1520 = document.getElementById("imgSqrs1520").src;

    value45Save1520 = "zSqrArtSpecz1520";

    localStorage.setItem(value45Save1520, sQz1520);
};

function square1521(){

    var sQz1521 = document.getElementById("imgSqrs1521").src;

    value45Save1521 = "zSqrArtSpecz1521";

    localStorage.setItem(value45Save1521, sQz1521);
};

function square1522(){

    var sQz1522 = document.getElementById("imgSqrs1522").src;

    value45Save1522 = "zSqrArtSpecz1522";

    localStorage.setItem(value45Save1522, sQz1522);
};

function square1523(){

    var sQz1523 = document.getElementById("imgSqrs1523").src;

    value45Save1523 = "zSqrArtSpecz1523";

    localStorage.setItem(value45Save1523, sQz1523);
};

function square1524(){

    var sQz1524 = document.getElementById("imgSqrs1524").src;

    value45Save1524 = "zSqrArtSpecz1524";

    localStorage.setItem(value45Save1524, sQz1524);
};

function square1525(){

    var sQz1525 = document.getElementById("imgSqrs1525").src;

    value45Save1525 = "zSqrArtSpecz1525";

    localStorage.setItem(value45Save1525, sQz1525);
};

function square1526(){

    var sQz1526 = document.getElementById("imgSqrs1526").src;

    value45Save1526 = "zSqrArtSpecz1526";

    localStorage.setItem(value45Save1526, sQz1526);
};

function square1527(){

    var sQz1527 = document.getElementById("imgSqrs1527").src;

    value45Save1527 = "zSqrArtSpecz1527";

    localStorage.setItem(value45Save1527, sQz1527);
};

function square1528(){

    var sQz1528 = document.getElementById("imgSqrs1528").src;

    value45Save1528 = "zSqrArtSpecz1528";

    localStorage.setItem(value45Save1528, sQz1528);
};

function square1529(){

    var sQz1529 = document.getElementById("imgSqrs1529").src;

    value45Save1529 = "zSqrArtSpecz1529";

    localStorage.setItem(value45Save1529, sQz1529);
};

function square1530(){

    var sQz1530 = document.getElementById("imgSqrs1530").src;

    value45Save1530 = "zSqrArtSpecz1530";

    localStorage.setItem(value45Save1530, sQz1530);
};

function square1531(){

    var sQz1531 = document.getElementById("imgSqrs1531").src;

    value45Save1531 = "zSqrArtSpecz1531";

    localStorage.setItem(value45Save1531, sQz1531);
};

function square1532(){

    var sQz1532 = document.getElementById("imgSqrs1532").src;

    value45Save1532 = "zSqrArtSpecz1532";

    localStorage.setItem(value45Save1532, sQz1532);
};

function square1533(){

    var sQz1533 = document.getElementById("imgSqrs1533").src;

    value45Save1533 = "zSqrArtSpecz1533";

    localStorage.setItem(value45Save1533, sQz1533);
};

function square1534(){

    var sQz1534 = document.getElementById("imgSqrs1534").src;

    value45Save1534 = "zSqrArtSpecz1534";

    localStorage.setItem(value45Save1534, sQz1534);
};

function square1535(){

    var sQz1535 = document.getElementById("imgSqrs1535").src;

    value45Save1535 = "zSqrArtSpecz1535";

    localStorage.setItem(value45Save1535, sQz1535);
};

function square1536(){

    var sQz1536 = document.getElementById("imgSqrs1536").src;

    value45Save1536 = "zSqrArtSpecz1536";

    localStorage.setItem(value45Save1536, sQz1536);
};

function square1537(){

    var sQz1537 = document.getElementById("imgSqrs1537").src;

    value45Save1537 = "zSqrArtSpecz1537";

    localStorage.setItem(value45Save1537, sQz1537);
};

function square1538(){

    var sQz1538 = document.getElementById("imgSqrs1538").src;

    value45Save1538 = "zSqrArtSpecz1538";

    localStorage.setItem(value45Save1538, sQz1538);
};

function square1539(){

    var sQz1539 = document.getElementById("imgSqrs1539").src;

    value45Save1539 = "zSqrArtSpecz1539";

    localStorage.setItem(value45Save1539, sQz1539);
};

function square1540(){

    var sQz1540 = document.getElementById("imgSqrs1540").src;

    value45Save1540 = "zSqrArtSpecz1540";

    localStorage.setItem(value45Save1540, sQz1540);
};

function square1541(){

    var sQz1541 = document.getElementById("imgSqrs1541").src;

    value45Save1541 = "zSqrArtSpecz1541";

    localStorage.setItem(value45Save1541, sQz1541);
};

function square1542(){

    var sQz1542 = document.getElementById("imgSqrs1542").src;

    value45Save1542 = "zSqrArtSpecz1542";

    localStorage.setItem(value45Save1542, sQz1542);
};

function square1543(){

    var sQz1543 = document.getElementById("imgSqrs1543").src;

    value45Save1543 = "zSqrArtSpecz1543";

    localStorage.setItem(value45Save1543, sQz1543);
};

function square1544(){

    var sQz1544 = document.getElementById("imgSqrs1544").src;

    value45Save1544 = "zSqrArtSpecz1544";

    localStorage.setItem(value45Save1544, sQz1544);
};

function square1545(){

    var sQz1545 = document.getElementById("imgSqrs1545").src;

    value45Save1545 = "zSqrArtSpecz1545";

    localStorage.setItem(value45Save1545, sQz1545);
};

function square1546(){

    var sQz1546 = document.getElementById("imgSqrs1546").src;

    value45Save1546 = "zSqrArtSpecz1546";

    localStorage.setItem(value45Save1546, sQz1546);
};

function square1547(){

    var sQz1547 = document.getElementById("imgSqrs1547").src;

    value45Save1547 = "zSqrArtSpecz1547";

    localStorage.setItem(value45Save1547, sQz1547);
};

function square1548(){

    var sQz1548 = document.getElementById("imgSqrs1548").src;

    value45Save1548 = "zSqrArtSpecz1548";

    localStorage.setItem(value45Save1548, sQz1548);
};

function square1549(){

    var sQz1549 = document.getElementById("imgSqrs1549").src;

    value45Save1549 = "zSqrArtSpecz1549";

    localStorage.setItem(value45Save1549, sQz1549);
};

function square1550(){

    var sQz1550 = document.getElementById("imgSqrs1550").src;

    value45Save1550 = "zSqrArtSpecz1550";

    localStorage.setItem(value45Save1550, sQz1550);
};

function square1551(){

    var sQz1551 = document.getElementById("imgSqrs1551").src;

    value45Save1551 = "zSqrArtSpecz1551";

    localStorage.setItem(value45Save1551, sQz1551);
};

function square1552(){

    var sQz1552 = document.getElementById("imgSqrs1552").src;

    value45Save1552 = "zSqrArtSpecz1552";

    localStorage.setItem(value45Save1552, sQz1552);
};

function square1553(){

    var sQz1553 = document.getElementById("imgSqrs1553").src;

    value45Save1553 = "zSqrArtSpecz1553";

    localStorage.setItem(value45Save1553, sQz1553);
};

function square1554(){

    var sQz1554 = document.getElementById("imgSqrs1554").src;

    value45Save1554 = "zSqrArtSpecz1554";

    localStorage.setItem(value45Save1554, sQz1554);
};

function square1555(){

    var sQz1555 = document.getElementById("imgSqrs1555").src;

    value45Save1555 = "zSqrArtSpecz1555";

    localStorage.setItem(value45Save1555, sQz1555);
};

function square1556(){

    var sQz1556 = document.getElementById("imgSqrs1556").src;

    value45Save1556 = "zSqrArtSpecz1556";

    localStorage.setItem(value45Save1556, sQz1556);
};

function square1557(){

    var sQz1557 = document.getElementById("imgSqrs1557").src;

    value45Save1557 = "zSqrArtSpecz1557";

    localStorage.setItem(value45Save1557, sQz1557);
};

function square1558(){

    var sQz1558 = document.getElementById("imgSqrs1558").src;

    value45Save1558 = "zSqrArtSpecz1558";

    localStorage.setItem(value45Save1558, sQz1558);
};

function square1559(){

    var sQz1559 = document.getElementById("imgSqrs1559").src;

    value45Save1559 = "zSqrArtSpecz1559";

    localStorage.setItem(value45Save1559, sQz1559);
};

function square1560(){

    var sQz1560 = document.getElementById("imgSqrs1560").src;

    value45Save1560 = "zSqrArtSpecz1560";

    localStorage.setItem(value45Save1560, sQz1560);
};

function square1561(){

    var sQz1561 = document.getElementById("imgSqrs1561").src;

    value45Save1561 = "zSqrArtSpecz1561";

    localStorage.setItem(value45Save1561, sQz1561);
};

function square1562(){

    var sQz1562 = document.getElementById("imgSqrs1562").src;

    value45Save1562 = "zSqrArtSpecz1562";

    localStorage.setItem(value45Save1562, sQz1562);
};

function square1563(){

    var sQz1563 = document.getElementById("imgSqrs1563").src;

    value45Save1563 = "zSqrArtSpecz1563";

    localStorage.setItem(value45Save1563, sQz1563);
};

function square1564(){

    var sQz1564 = document.getElementById("imgSqrs1564").src;

    value45Save1564 = "zSqrArtSpecz1564";

    localStorage.setItem(value45Save1564, sQz1564);
};

function square1565(){

    var sQz1565 = document.getElementById("imgSqrs1565").src;

    value45Save1565 = "zSqrArtSpecz1565";

    localStorage.setItem(value45Save1565, sQz1565);
};

function square1566(){

    var sQz1566 = document.getElementById("imgSqrs1566").src;

    value45Save1566 = "zSqrArtSpecz1566";

    localStorage.setItem(value45Save1566, sQz1566);
};

function square1567(){

    var sQz1567 = document.getElementById("imgSqrs1567").src;

    value45Save1567 = "zSqrArtSpecz1567";

    localStorage.setItem(value45Save1567, sQz1567);
};

function square1568(){

    var sQz1568 = document.getElementById("imgSqrs1568").src;

    value45Save1568 = "zSqrArtSpecz1568";

    localStorage.setItem(value45Save1568, sQz1568);
};

function square1569(){

    var sQz1569 = document.getElementById("imgSqrs1569").src;

    value45Save1569 = "zSqrArtSpecz1569";

    localStorage.setItem(value45Save1569, sQz1569);
};

function square1570(){

    var sQz1570 = document.getElementById("imgSqrs1570").src;

    value45Save1570 = "zSqrArtSpecz1570";

    localStorage.setItem(value45Save1570, sQz1570);
};

function square1571(){

    var sQz1571 = document.getElementById("imgSqrs1571").src;

    value45Save1571 = "zSqrArtSpecz1571";

    localStorage.setItem(value45Save1571, sQz1571);
};

function square1572(){

    var sQz1572 = document.getElementById("imgSqrs1572").src;

    value45Save1572 = "zSqrArtSpecz1572";

    localStorage.setItem(value45Save1572, sQz1572);
};

function square1573(){

    var sQz1573 = document.getElementById("imgSqrs1573").src;

    value45Save1573 = "zSqrArtSpecz1573";

    localStorage.setItem(value45Save1573, sQz1573);
};

function square1574(){

    var sQz1574 = document.getElementById("imgSqrs1574").src;

    value45Save1574 = "zSqrArtSpecz1574";

    localStorage.setItem(value45Save1574, sQz1574);
};

function square1575(){

    var sQz1575 = document.getElementById("imgSqrs1575").src;

    value45Save1575 = "zSqrArtSpecz1575";

    localStorage.setItem(value45Save1575, sQz1575);
};

function square1576(){

    var sQz1576 = document.getElementById("imgSqrs1576").src;

    value45Save1576 = "zSqrArtSpecz1576";

    localStorage.setItem(value45Save1576, sQz1576);
};

function square1577(){

    var sQz1577 = document.getElementById("imgSqrs1577").src;

    value45Save1577 = "zSqrArtSpecz1577";

    localStorage.setItem(value45Save1577, sQz1577);
};

function square1578(){

    var sQz1578 = document.getElementById("imgSqrs1578").src;

    value45Save1578 = "zSqrArtSpecz1578";

    localStorage.setItem(value45Save1578, sQz1578);
};

function square1579(){

    var sQz1579 = document.getElementById("imgSqrs1579").src;

    value45Save1579 = "zSqrArtSpecz1579";

    localStorage.setItem(value45Save1579, sQz1579);
};

function square1580(){

    var sQz1580 = document.getElementById("imgSqrs1580").src;

    value45Save1580 = "zSqrArtSpecz1580";

    localStorage.setItem(value45Save1580, sQz1580);
};

function square1581(){

    var sQz1581 = document.getElementById("imgSqrs1581").src;

    value45Save1581 = "zSqrArtSpecz1581";

    localStorage.setItem(value45Save1581, sQz1581);
};

function square1582(){

    var sQz1582 = document.getElementById("imgSqrs1582").src;

    value45Save1582 = "zSqrArtSpecz1582";

    localStorage.setItem(value45Save1582, sQz1582);
};

function square1583(){

    var sQz1583 = document.getElementById("imgSqrs1583").src;

    value45Save1583 = "zSqrArtSpecz1583";

    localStorage.setItem(value45Save1583, sQz1583);
};

function square1584(){

    var sQz1584 = document.getElementById("imgSqrs1584").src;

    value45Save1584 = "zSqrArtSpecz1584";

    localStorage.setItem(value45Save1584, sQz1584);
};

function square1585(){

    var sQz1585 = document.getElementById("imgSqrs1585").src;

    value45Save1585 = "zSqrArtSpecz1585";

    localStorage.setItem(value45Save1585, sQz1585);
};

function square1586(){

    var sQz1586 = document.getElementById("imgSqrs1586").src;

    value45Save1586 = "zSqrArtSpecz1586";

    localStorage.setItem(value45Save1586, sQz1586);
};

function square1587(){

    var sQz1587 = document.getElementById("imgSqrs1587").src;

    value45Save1587 = "zSqrArtSpecz1587";

    localStorage.setItem(value45Save1587, sQz1587);
};

function square1588(){

    var sQz1588 = document.getElementById("imgSqrs1588").src;

    value45Save1588 = "zSqrArtSpecz1588";

    localStorage.setItem(value45Save1588, sQz1588);
};

function square1589(){

    var sQz1589 = document.getElementById("imgSqrs1589").src;

    value45Save1589 = "zSqrArtSpecz1589";

    localStorage.setItem(value45Save1589, sQz1589);
};

function square1590(){

    var sQz1590 = document.getElementById("imgSqrs1590").src;

    value45Save1590 = "zSqrArtSpecz1590";

    localStorage.setItem(value45Save1590, sQz1590);
};

function square1591(){

    var sQz1591 = document.getElementById("imgSqrs1591").src;

    value45Save1591 = "zSqrArtSpecz1591";

    localStorage.setItem(value45Save1591, sQz1591);
};

function square1592(){

    var sQz1592 = document.getElementById("imgSqrs1592").src;

    value45Save1592 = "zSqrArtSpecz1592";

    localStorage.setItem(value45Save1592, sQz1592);
};

function square1593(){

    var sQz1593 = document.getElementById("imgSqrs1593").src;

    value45Save1593 = "zSqrArtSpecz1593";

    localStorage.setItem(value45Save1593, sQz1593);
};

function square1594(){

    var sQz1594 = document.getElementById("imgSqrs1594").src;

    value45Save1594 = "zSqrArtSpecz1594";

    localStorage.setItem(value45Save1594, sQz1594);
};

function square1595(){

    var sQz1595 = document.getElementById("imgSqrs1595").src;

    value45Save1595 = "zSqrArtSpecz1595";

    localStorage.setItem(value45Save1595, sQz1595);
};

function square1596(){

    var sQz1596 = document.getElementById("imgSqrs1596").src;

    value45Save1596 = "zSqrArtSpecz1596";

    localStorage.setItem(value45Save1596, sQz1596);
};

function square1597(){

    var sQz1597 = document.getElementById("imgSqrs1597").src;

    value45Save1597 = "zSqrArtSpecz1597";

    localStorage.setItem(value45Save1597, sQz1597);
};

function square1598(){

    var sQz1598 = document.getElementById("imgSqrs1598").src;

    value45Save1598 = "zSqrArtSpecz1598";

    localStorage.setItem(value45Save1598, sQz1598);
};

function square1599(){

    var sQz1599 = document.getElementById("imgSqrs1599").src;

    value45Save1599 = "zSqrArtSpecz1599";

    localStorage.setItem(value45Save1599, sQz1599);
};

function square1600(){

    var sQz1600 = document.getElementById("imgSqrs1600").src;

    value45Save1600 = "zSqrArtSpecz1600";

    localStorage.setItem(value45Save1600, sQz1600);
};

function square1601(){

    var sQz1601 = document.getElementById("imgSqrs1601").src;

    value45Save1601 = "zSqrArtSpecz1601";

    localStorage.setItem(value45Save1601, sQz1601);
};

function square1602(){

    var sQz1602 = document.getElementById("imgSqrs1602").src;

    value45Save1602 = "zSqrArtSpecz1602";

    localStorage.setItem(value45Save1602, sQz1602);
};

function square1603(){

    var sQz1603 = document.getElementById("imgSqrs1603").src;

    value45Save1603 = "zSqrArtSpecz1603";

    localStorage.setItem(value45Save1603, sQz1603);
};

function square1604(){

    var sQz1604 = document.getElementById("imgSqrs1604").src;

    value45Save1604 = "zSqrArtSpecz1604";

    localStorage.setItem(value45Save1604, sQz1604);
};

function square1605(){

    var sQz1605 = document.getElementById("imgSqrs1605").src;

    value45Save1605 = "zSqrArtSpecz1605";

    localStorage.setItem(value45Save1605, sQz1605);
};

function square1606(){

    var sQz1606 = document.getElementById("imgSqrs1606").src;

    value45Save1606 = "zSqrArtSpecz1606";

    localStorage.setItem(value45Save1606, sQz1606);
};

function square1607(){

    var sQz1607 = document.getElementById("imgSqrs1607").src;

    value45Save1607 = "zSqrArtSpecz1607";

    localStorage.setItem(value45Save1607, sQz1607);
};

function square1608(){

    var sQz1608 = document.getElementById("imgSqrs1608").src;

    value45Save1608 = "zSqrArtSpecz1608";

    localStorage.setItem(value45Save1608, sQz1608);
};

function square1609(){

    var sQz1609 = document.getElementById("imgSqrs1609").src;

    value45Save1609 = "zSqrArtSpecz1609";

    localStorage.setItem(value45Save1609, sQz1609);
};

function square1610(){

    var sQz1610 = document.getElementById("imgSqrs1610").src;

    value45Save1610 = "zSqrArtSpecz1610";

    localStorage.setItem(value45Save1610, sQz1610);
};

function square1611(){

    var sQz1611 = document.getElementById("imgSqrs1611").src;

    value45Save1611 = "zSqrArtSpecz1611";

    localStorage.setItem(value45Save1611, sQz1611);
};

function square1612(){

    var sQz1612 = document.getElementById("imgSqrs1612").src;

    value45Save1612 = "zSqrArtSpecz1612";

    localStorage.setItem(value45Save1612, sQz1612);
};

function square1613(){

    var sQz1613 = document.getElementById("imgSqrs1613").src;

    value45Save1613 = "zSqrArtSpecz1613";

    localStorage.setItem(value45Save1613, sQz1613);
};

function square1614(){

    var sQz1614 = document.getElementById("imgSqrs1614").src;

    value45Save1614 = "zSqrArtSpecz1614";

    localStorage.setItem(value45Save1614, sQz1614);
};

function square1615(){

    var sQz1615 = document.getElementById("imgSqrs1615").src;

    value45Save1615 = "zSqrArtSpecz1615";

    localStorage.setItem(value45Save1615, sQz1615);
};

function square1616(){

    var sQz1616 = document.getElementById("imgSqrs1616").src;

    value45Save1616 = "zSqrArtSpecz1616";

    localStorage.setItem(value45Save1616, sQz1616);
};

function square1617(){

    var sQz1617 = document.getElementById("imgSqrs1617").src;

    value45Save1617 = "zSqrArtSpecz1617";

    localStorage.setItem(value45Save1617, sQz1617);
};

function square1618(){

    var sQz1618 = document.getElementById("imgSqrs1618").src;

    value45Save1618 = "zSqrArtSpecz1618";

    localStorage.setItem(value45Save1618, sQz1618);
};

function square1619(){

    var sQz1619 = document.getElementById("imgSqrs1619").src;

    value45Save1619 = "zSqrArtSpecz1619";

    localStorage.setItem(value45Save1619, sQz1619);
};

function square1620(){

    var sQz1620 = document.getElementById("imgSqrs1620").src;

    value45Save1620 = "zSqrArtSpecz1620";

    localStorage.setItem(value45Save1620, sQz1620);
};

function square1621(){

    var sQz1621 = document.getElementById("imgSqrs1621").src;

    value45Save1621 = "zSqrArtSpecz1621";

    localStorage.setItem(value45Save1621, sQz1621);
};

function square1622(){

    var sQz1622 = document.getElementById("imgSqrs1622").src;

    value45Save1622 = "zSqrArtSpecz1622";

    localStorage.setItem(value45Save1622, sQz1622);
};

function square1623(){

    var sQz1623 = document.getElementById("imgSqrs1623").src;

    value45Save1623 = "zSqrArtSpecz1623";

    localStorage.setItem(value45Save1623, sQz1623);
};

function square1624(){

    var sQz1624 = document.getElementById("imgSqrs1624").src;

    value45Save1624 = "zSqrArtSpecz1624";

    localStorage.setItem(value45Save1624, sQz1624);
};

function square1625(){

    var sQz1625 = document.getElementById("imgSqrs1625").src;

    value45Save1625 = "zSqrArtSpecz1625";

    localStorage.setItem(value45Save1625, sQz1625);
};

function square1626(){

    var sQz1626 = document.getElementById("imgSqrs1626").src;

    value45Save1626 = "zSqrArtSpecz1626";

    localStorage.setItem(value45Save1626, sQz1626);
};

function square1627(){

    var sQz1627 = document.getElementById("imgSqrs1627").src;

    value45Save1627 = "zSqrArtSpecz1627";

    localStorage.setItem(value45Save1627, sQz1627);
};

function square1628(){

    var sQz1628 = document.getElementById("imgSqrs1628").src;

    value45Save1628 = "zSqrArtSpecz1628";

    localStorage.setItem(value45Save1628, sQz1628);
};

function square1629(){

    var sQz1629 = document.getElementById("imgSqrs1629").src;

    value45Save1629 = "zSqrArtSpecz1629";

    localStorage.setItem(value45Save1629, sQz1629);
};

function square1630(){

    var sQz1630 = document.getElementById("imgSqrs1630").src;

    value45Save1630 = "zSqrArtSpecz1630";

    localStorage.setItem(value45Save1630, sQz1630);
};

function square1631(){

    var sQz1631 = document.getElementById("imgSqrs1631").src;

    value45Save1631 = "zSqrArtSpecz1631";

    localStorage.setItem(value45Save1631, sQz1631);
};

function square1632(){

    var sQz1632 = document.getElementById("imgSqrs1632").src;

    value45Save1632 = "zSqrArtSpecz1632";

    localStorage.setItem(value45Save1632, sQz1632);
};

function square1633(){

    var sQz1633 = document.getElementById("imgSqrs1633").src;

    value45Save1633 = "zSqrArtSpecz1633";

    localStorage.setItem(value45Save1633, sQz1633);
};

function square1634(){

    var sQz1634 = document.getElementById("imgSqrs1634").src;

    value45Save1634 = "zSqrArtSpecz1634";

    localStorage.setItem(value45Save1634, sQz1634);
};

function square1635(){

    var sQz1635 = document.getElementById("imgSqrs1635").src;

    value45Save1635 = "zSqrArtSpecz1635";

    localStorage.setItem(value45Save1635, sQz1635);
};

function square1636(){

    var sQz1636 = document.getElementById("imgSqrs1636").src;

    value45Save1636 = "zSqrArtSpecz1636";

    localStorage.setItem(value45Save1636, sQz1636);
};

function square1637(){

    var sQz1637 = document.getElementById("imgSqrs1637").src;

    value45Save1637 = "zSqrArtSpecz1637";

    localStorage.setItem(value45Save1637, sQz1637);
};

function square1638(){

    var sQz1638 = document.getElementById("imgSqrs1638").src;

    value45Save1638 = "zSqrArtSpecz1638";

    localStorage.setItem(value45Save1638, sQz1638);
};

function square1639(){

    var sQz1639 = document.getElementById("imgSqrs1639").src;

    value45Save1639 = "zSqrArtSpecz1639";

    localStorage.setItem(value45Save1639, sQz1639);
};

function square1640(){

    var sQz1640 = document.getElementById("imgSqrs1640").src;

    value45Save1640 = "zSqrArtSpecz1640";

    localStorage.setItem(value45Save1640, sQz1640);
};

function square1641(){

    var sQz1641 = document.getElementById("imgSqrs1641").src;

    value45Save1641 = "zSqrArtSpecz1641";

    localStorage.setItem(value45Save1641, sQz1641);
};

function square1642(){

    var sQz1642 = document.getElementById("imgSqrs1642").src;

    value45Save1642 = "zSqrArtSpecz1642";

    localStorage.setItem(value45Save1642, sQz1642);
};

function square1643(){

    var sQz1643 = document.getElementById("imgSqrs1643").src;

    value45Save1643 = "zSqrArtSpecz1643";

    localStorage.setItem(value45Save1643, sQz1643);
};

function square1644(){

    var sQz1644 = document.getElementById("imgSqrs1644").src;

    value45Save1644 = "zSqrArtSpecz1644";

    localStorage.setItem(value45Save1644, sQz1644);
};

function square1645(){

    var sQz1645 = document.getElementById("imgSqrs1645").src;

    value45Save1645 = "zSqrArtSpecz1645";

    localStorage.setItem(value45Save1645, sQz1645);
};

function square1646(){

    var sQz1646 = document.getElementById("imgSqrs1646").src;

    value45Save1646 = "zSqrArtSpecz1646";

    localStorage.setItem(value45Save1646, sQz1646);
};

function square1647(){

    var sQz1647 = document.getElementById("imgSqrs1647").src;

    value45Save1647 = "zSqrArtSpecz1647";

    localStorage.setItem(value45Save1647, sQz1647);
};

function square1648(){

    var sQz1648 = document.getElementById("imgSqrs1648").src;

    value45Save1648 = "zSqrArtSpecz1648";

    localStorage.setItem(value45Save1648, sQz1648);
};

function square1649(){

    var sQz1649 = document.getElementById("imgSqrs1649").src;

    value45Save1649 = "zSqrArtSpecz1649";

    localStorage.setItem(value45Save1649, sQz1649);
};

function square1650(){

    var sQz1650 = document.getElementById("imgSqrs1650").src;

    value45Save1650 = "zSqrArtSpecz1650";

    localStorage.setItem(value45Save1650, sQz1650);
};

function square1651(){

    var sQz1651 = document.getElementById("imgSqrs1651").src;

    value45Save1651 = "zSqrArtSpecz1651";

    localStorage.setItem(value45Save1651, sQz1651);
};

function square1652(){

    var sQz1652 = document.getElementById("imgSqrs1652").src;

    value45Save1652 = "zSqrArtSpecz1652";

    localStorage.setItem(value45Save1652, sQz1652);
};

function square1653(){

    var sQz1653 = document.getElementById("imgSqrs1653").src;

    value45Save1653 = "zSqrArtSpecz1653";

    localStorage.setItem(value45Save1653, sQz1653);
};

function square1654(){

    var sQz1654 = document.getElementById("imgSqrs1654").src;

    value45Save1654 = "zSqrArtSpecz1654";

    localStorage.setItem(value45Save1654, sQz1654);
};

function square1655(){

    var sQz1655 = document.getElementById("imgSqrs1655").src;

    value45Save1655 = "zSqrArtSpecz1655";

    localStorage.setItem(value45Save1655, sQz1655);
};

function square1656(){

    var sQz1656 = document.getElementById("imgSqrs1656").src;

    value45Save1656 = "zSqrArtSpecz1656";

    localStorage.setItem(value45Save1656, sQz1656);
};

function square1657(){

    var sQz1657 = document.getElementById("imgSqrs1657").src;

    value45Save1657 = "zSqrArtSpecz1657";

    localStorage.setItem(value45Save1657, sQz1657);
};

function square1658(){

    var sQz1658 = document.getElementById("imgSqrs1658").src;

    value45Save1658 = "zSqrArtSpecz1658";

    localStorage.setItem(value45Save1658, sQz1658);
};

function square1659(){

    var sQz1659 = document.getElementById("imgSqrs1659").src;

    value45Save1659 = "zSqrArtSpecz1659";

    localStorage.setItem(value45Save1659, sQz1659);
};

function square1660(){

    var sQz1660 = document.getElementById("imgSqrs1660").src;

    value45Save1660 = "zSqrArtSpecz1660";

    localStorage.setItem(value45Save1660, sQz1660);
};

function square1661(){

    var sQz1661 = document.getElementById("imgSqrs1661").src;

    value45Save1661 = "zSqrArtSpecz1661";

    localStorage.setItem(value45Save1661, sQz1661);
};

function square1662(){

    var sQz1662 = document.getElementById("imgSqrs1662").src;

    value45Save1662 = "zSqrArtSpecz1662";

    localStorage.setItem(value45Save1662, sQz1662);
};

function square1663(){

    var sQz1663 = document.getElementById("imgSqrs1663").src;

    value45Save1663 = "zSqrArtSpecz1663";

    localStorage.setItem(value45Save1663, sQz1663);
};

function square1664(){

    var sQz1664 = document.getElementById("imgSqrs1664").src;

    value45Save1664 = "zSqrArtSpecz1664";

    localStorage.setItem(value45Save1664, sQz1664);
};

function square1665(){

    var sQz1665 = document.getElementById("imgSqrs1665").src;

    value45Save1665 = "zSqrArtSpecz1665";

    localStorage.setItem(value45Save1665, sQz1665);
};

function square1666(){

    var sQz1666 = document.getElementById("imgSqrs1666").src;

    value45Save1666 = "zSqrArtSpecz1666";

    localStorage.setItem(value45Save1666, sQz1666);
};

function square1667(){

    var sQz1667 = document.getElementById("imgSqrs1667").src;

    value45Save1667 = "zSqrArtSpecz1667";

    localStorage.setItem(value45Save1667, sQz1667);
};

function square1668(){

    var sQz1668 = document.getElementById("imgSqrs1668").src;

    value45Save1668 = "zSqrArtSpecz1668";

    localStorage.setItem(value45Save1668, sQz1668);
};

function square1669(){

    var sQz1669 = document.getElementById("imgSqrs1669").src;

    value45Save1669 = "zSqrArtSpecz1669";

    localStorage.setItem(value45Save1669, sQz1669);
};

function square1670(){

    var sQz1670 = document.getElementById("imgSqrs1670").src;

    value45Save1670 = "zSqrArtSpecz1670";

    localStorage.setItem(value45Save1670, sQz1670);
};

function square1671(){

    var sQz1671 = document.getElementById("imgSqrs1671").src;

    value45Save1671 = "zSqrArtSpecz1671";

    localStorage.setItem(value45Save1671, sQz1671);
};

function square1672(){

    var sQz1672 = document.getElementById("imgSqrs1672").src;

    value45Save1672 = "zSqrArtSpecz1672";

    localStorage.setItem(value45Save1672, sQz1672);
};

function square1673(){

    var sQz1673 = document.getElementById("imgSqrs1673").src;

    value45Save1673 = "zSqrArtSpecz1673";

    localStorage.setItem(value45Save1673, sQz1673);
};

function square1674(){

    var sQz1674 = document.getElementById("imgSqrs1674").src;

    value45Save1674 = "zSqrArtSpecz1674";

    localStorage.setItem(value45Save1674, sQz1674);
};

function square1675(){

    var sQz1675 = document.getElementById("imgSqrs1675").src;

    value45Save1675 = "zSqrArtSpecz1675";

    localStorage.setItem(value45Save1675, sQz1675);
};

function square1676(){

    var sQz1676 = document.getElementById("imgSqrs1676").src;

    value45Save1676 = "zSqrArtSpecz1676";

    localStorage.setItem(value45Save1676, sQz1676);
};

function square1677(){

    var sQz1677 = document.getElementById("imgSqrs1677").src;

    value45Save1677 = "zSqrArtSpecz1677";

    localStorage.setItem(value45Save1677, sQz1677);
};

function square1678(){

    var sQz1678 = document.getElementById("imgSqrs1678").src;

    value45Save1678 = "zSqrArtSpecz1678";

    localStorage.setItem(value45Save1678, sQz1678);
};

function square1679(){

    var sQz1679 = document.getElementById("imgSqrs1679").src;

    value45Save1679 = "zSqrArtSpecz1679";

    localStorage.setItem(value45Save1679, sQz1679);
};

function square1680(){

    var sQz1680 = document.getElementById("imgSqrs1680").src;

    value45Save1680 = "zSqrArtSpecz1680";

    localStorage.setItem(value45Save1680, sQz1680);
};

function square1681(){

    var sQz1681 = document.getElementById("imgSqrs1681").src;

    value45Save1681 = "zSqrArtSpecz1681";

    localStorage.setItem(value45Save1681, sQz1681);
};

function square1682(){

    var sQz1682 = document.getElementById("imgSqrs1682").src;

    value45Save1682 = "zSqrArtSpecz1682";

    localStorage.setItem(value45Save1682, sQz1682);
};

function square1683(){

    var sQz1683 = document.getElementById("imgSqrs1683").src;

    value45Save1683 = "zSqrArtSpecz1683";

    localStorage.setItem(value45Save1683, sQz1683);
};

function square1684(){

    var sQz1684 = document.getElementById("imgSqrs1684").src;

    value45Save1684 = "zSqrArtSpecz1684";

    localStorage.setItem(value45Save1684, sQz1684);
};

function square1685(){

    var sQz1685 = document.getElementById("imgSqrs1685").src;

    value45Save1685 = "zSqrArtSpecz1685";

    localStorage.setItem(value45Save1685, sQz1685);
};

function square1686(){

    var sQz1686 = document.getElementById("imgSqrs1686").src;

    value45Save1686 = "zSqrArtSpecz1686";

    localStorage.setItem(value45Save1686, sQz1686);
};

function square1687(){

    var sQz1687 = document.getElementById("imgSqrs1687").src;

    value45Save1687 = "zSqrArtSpecz1687";

    localStorage.setItem(value45Save1687, sQz1687);
};

function square1688(){

    var sQz1688 = document.getElementById("imgSqrs1688").src;

    value45Save1688 = "zSqrArtSpecz1688";

    localStorage.setItem(value45Save1688, sQz1688);
};

function square1689(){

    var sQz1689 = document.getElementById("imgSqrs1689").src;

    value45Save1689 = "zSqrArtSpecz1689";

    localStorage.setItem(value45Save1689, sQz1689);
};

function square1690(){

    var sQz1690 = document.getElementById("imgSqrs1690").src;

    value45Save1690 = "zSqrArtSpecz1690";

    localStorage.setItem(value45Save1690, sQz1690);
};

function square1691(){

    var sQz1691 = document.getElementById("imgSqrs1691").src;

    value45Save1691 = "zSqrArtSpecz1691";

    localStorage.setItem(value45Save1691, sQz1691);
};

function square1692(){

    var sQz1692 = document.getElementById("imgSqrs1692").src;

    value45Save1692 = "zSqrArtSpecz1692";

    localStorage.setItem(value45Save1692, sQz1692);
};

function square1693(){

    var sQz1693 = document.getElementById("imgSqrs1693").src;

    value45Save1693 = "zSqrArtSpecz1693";

    localStorage.setItem(value45Save1693, sQz1693);
};

function square1694(){

    var sQz1694 = document.getElementById("imgSqrs1694").src;

    value45Save1694 = "zSqrArtSpecz1694";

    localStorage.setItem(value45Save1694, sQz1694);
};

function square1695(){

    var sQz1695 = document.getElementById("imgSqrs1695").src;

    value45Save1695 = "zSqrArtSpecz1695";

    localStorage.setItem(value45Save1695, sQz1695);
};

function square1696(){

    var sQz1696 = document.getElementById("imgSqrs1696").src;

    value45Save1696 = "zSqrArtSpecz1696";

    localStorage.setItem(value45Save1696, sQz1696);
};

function square1697(){

    var sQz1697 = document.getElementById("imgSqrs1697").src;

    value45Save1697 = "zSqrArtSpecz1697";

    localStorage.setItem(value45Save1697, sQz1697);
};

function square1698(){

    var sQz1698 = document.getElementById("imgSqrs1698").src;

    value45Save1698 = "zSqrArtSpecz1698";

    localStorage.setItem(value45Save1698, sQz1698);
};

function square1699(){

    var sQz1699 = document.getElementById("imgSqrs1699").src;

    value45Save1699 = "zSqrArtSpecz1699";

    localStorage.setItem(value45Save1699, sQz1699);
};

function square1700(){

    var sQz1700 = document.getElementById("imgSqrs1700").src;

    value45Save1700 = "zSqrArtSpecz1700";

    localStorage.setItem(value45Save1700, sQz1700);
};

function square1701(){

    var sQz1701 = document.getElementById("imgSqrs1701").src;

    value45Save1701 = "zSqrArtSpecz1701";

    localStorage.setItem(value45Save1701, sQz1701);
};

function square1702(){

    var sQz1702 = document.getElementById("imgSqrs1702").src;

    value45Save1702 = "zSqrArtSpecz1702";

    localStorage.setItem(value45Save1702, sQz1702);
};

function square1703(){

    var sQz1703 = document.getElementById("imgSqrs1703").src;

    value45Save1703 = "zSqrArtSpecz1703";

    localStorage.setItem(value45Save1703, sQz1703);
};

function square1704(){

    var sQz1704 = document.getElementById("imgSqrs1704").src;

    value45Save1704 = "zSqrArtSpecz1704";

    localStorage.setItem(value45Save1704, sQz1704);
};

function square1705(){

    var sQz1705 = document.getElementById("imgSqrs1705").src;

    value45Save1705 = "zSqrArtSpecz1705";

    localStorage.setItem(value45Save1705, sQz1705);
};

function square1706(){

    var sQz1706 = document.getElementById("imgSqrs1706").src;

    value45Save1706 = "zSqrArtSpecz1706";

    localStorage.setItem(value45Save1706, sQz1706);
};

function square1707(){

    var sQz1707 = document.getElementById("imgSqrs1707").src;

    value45Save1707 = "zSqrArtSpecz1707";

    localStorage.setItem(value45Save1707, sQz1707);
};

function square1708(){

    var sQz1708 = document.getElementById("imgSqrs1708").src;

    value45Save1708 = "zSqrArtSpecz1708";

    localStorage.setItem(value45Save1708, sQz1708);
};

function square1709(){

    var sQz1709 = document.getElementById("imgSqrs1709").src;

    value45Save1709 = "zSqrArtSpecz1709";

    localStorage.setItem(value45Save1709, sQz1709);
};

function square1710(){

    var sQz1710 = document.getElementById("imgSqrs1710").src;

    value45Save1710 = "zSqrArtSpecz1710";

    localStorage.setItem(value45Save1710, sQz1710);
};

function square1711(){

    var sQz1711 = document.getElementById("imgSqrs1711").src;

    value45Save1711 = "zSqrArtSpecz1711";

    localStorage.setItem(value45Save1711, sQz1711);
};

function square1712(){

    var sQz1712 = document.getElementById("imgSqrs1712").src;

    value45Save1712 = "zSqrArtSpecz1712";

    localStorage.setItem(value45Save1712, sQz1712);
};

function square1713(){

    var sQz1713 = document.getElementById("imgSqrs1713").src;

    value45Save1713 = "zSqrArtSpecz1713";

    localStorage.setItem(value45Save1713, sQz1713);
};

function square1714(){

    var sQz1714 = document.getElementById("imgSqrs1714").src;

    value45Save1714 = "zSqrArtSpecz1714";

    localStorage.setItem(value45Save1714, sQz1714);
};

function square1715(){

    var sQz1715 = document.getElementById("imgSqrs1715").src;

    value45Save1715 = "zSqrArtSpecz1715";

    localStorage.setItem(value45Save1715, sQz1715);
};

function square1716(){

    var sQz1716 = document.getElementById("imgSqrs1716").src;

    value45Save1716 = "zSqrArtSpecz1716";

    localStorage.setItem(value45Save1716, sQz1716);
};

function square1717(){

    var sQz1717 = document.getElementById("imgSqrs1717").src;

    value45Save1717 = "zSqrArtSpecz1717";

    localStorage.setItem(value45Save1717, sQz1717);
};

function square1718(){

    var sQz1718 = document.getElementById("imgSqrs1718").src;

    value45Save1718 = "zSqrArtSpecz1718";

    localStorage.setItem(value45Save1718, sQz1718);
};

function square1719(){

    var sQz1719 = document.getElementById("imgSqrs1719").src;

    value45Save1719 = "zSqrArtSpecz1719";

    localStorage.setItem(value45Save1719, sQz1719);
};

function square1720(){

    var sQz1720 = document.getElementById("imgSqrs1720").src;

    value45Save1720 = "zSqrArtSpecz1720";

    localStorage.setItem(value45Save1720, sQz1720);
};

function square1721(){

    var sQz1721 = document.getElementById("imgSqrs1721").src;

    value45Save1721 = "zSqrArtSpecz1721";

    localStorage.setItem(value45Save1721, sQz1721);
};

function square1722(){

    var sQz1722 = document.getElementById("imgSqrs1722").src;

    value45Save1722 = "zSqrArtSpecz1722";

    localStorage.setItem(value45Save1722, sQz1722);
};

function square1723(){

    var sQz1723 = document.getElementById("imgSqrs1723").src;

    value45Save1723 = "zSqrArtSpecz1723";

    localStorage.setItem(value45Save1723, sQz1723);
};

function square1724(){

    var sQz1724 = document.getElementById("imgSqrs1724").src;

    value45Save1724 = "zSqrArtSpecz1724";

    localStorage.setItem(value45Save1724, sQz1724);
};

function square1725(){

    var sQz1725 = document.getElementById("imgSqrs1725").src;

    value45Save1725 = "zSqrArtSpecz1725";

    localStorage.setItem(value45Save1725, sQz1725);
};

function square1726(){

    var sQz1726 = document.getElementById("imgSqrs1726").src;

    value45Save1726 = "zSqrArtSpecz1726";

    localStorage.setItem(value45Save1726, sQz1726);
};

function square1727(){

    var sQz1727 = document.getElementById("imgSqrs1727").src;

    value45Save1727 = "zSqrArtSpecz1727";

    localStorage.setItem(value45Save1727, sQz1727);
};

function square1728(){

    var sQz1728 = document.getElementById("imgSqrs1728").src;

    value45Save1728 = "zSqrArtSpecz1728";

    localStorage.setItem(value45Save1728, sQz1728);
};

function square1729(){

    var sQz1729 = document.getElementById("imgSqrs1729").src;

    value45Save1729 = "zSqrArtSpecz1729";

    localStorage.setItem(value45Save1729, sQz1729);
};

function square1730(){

    var sQz1730 = document.getElementById("imgSqrs1730").src;

    value45Save1730 = "zSqrArtSpecz1730";

    localStorage.setItem(value45Save1730, sQz1730);
};

function square1731(){

    var sQz1731 = document.getElementById("imgSqrs1731").src;

    value45Save1731 = "zSqrArtSpecz1731";

    localStorage.setItem(value45Save1731, sQz1731);
};

function square1732(){

    var sQz1732 = document.getElementById("imgSqrs1732").src;

    value45Save1732 = "zSqrArtSpecz1732";

    localStorage.setItem(value45Save1732, sQz1732);
};

function square1733(){

    var sQz1733 = document.getElementById("imgSqrs1733").src;

    value45Save1733 = "zSqrArtSpecz1733";

    localStorage.setItem(value45Save1733, sQz1733);
};

function square1734(){

    var sQz1734 = document.getElementById("imgSqrs1734").src;

    value45Save1734 = "zSqrArtSpecz1734";

    localStorage.setItem(value45Save1734, sQz1734);
};

function square1735(){

    var sQz1735 = document.getElementById("imgSqrs1735").src;

    value45Save1735 = "zSqrArtSpecz1735";

    localStorage.setItem(value45Save1735, sQz1735);
};

function square1736(){

    var sQz1736 = document.getElementById("imgSqrs1736").src;

    value45Save1736 = "zSqrArtSpecz1736";

    localStorage.setItem(value45Save1736, sQz1736);
};

function square1737(){

    var sQz1737 = document.getElementById("imgSqrs1737").src;

    value45Save1737 = "zSqrArtSpecz1737";

    localStorage.setItem(value45Save1737, sQz1737);
};

function square1738(){

    var sQz1738 = document.getElementById("imgSqrs1738").src;

    value45Save1738 = "zSqrArtSpecz1738";

    localStorage.setItem(value45Save1738, sQz1738);
};

function square1739(){

    var sQz1739 = document.getElementById("imgSqrs1739").src;

    value45Save1739 = "zSqrArtSpecz1739";

    localStorage.setItem(value45Save1739, sQz1739);
};

function square1740(){

    var sQz1740 = document.getElementById("imgSqrs1740").src;

    value45Save1740 = "zSqrArtSpecz1740";

    localStorage.setItem(value45Save1740, sQz1740);
};

function square1741(){

    var sQz1741 = document.getElementById("imgSqrs1741").src;

    value45Save1741 = "zSqrArtSpecz1741";

    localStorage.setItem(value45Save1741, sQz1741);
};

function square1742(){

    var sQz1742 = document.getElementById("imgSqrs1742").src;

    value45Save1742 = "zSqrArtSpecz1742";

    localStorage.setItem(value45Save1742, sQz1742);
};

function square1743(){

    var sQz1743 = document.getElementById("imgSqrs1743").src;

    value45Save1743 = "zSqrArtSpecz1743";

    localStorage.setItem(value45Save1743, sQz1743);
};

function square1744(){

    var sQz1744 = document.getElementById("imgSqrs1744").src;

    value45Save1744 = "zSqrArtSpecz1744";

    localStorage.setItem(value45Save1744, sQz1744);
};

function square1745(){

    var sQz1745 = document.getElementById("imgSqrs1745").src;

    value45Save1745 = "zSqrArtSpecz1745";

    localStorage.setItem(value45Save1745, sQz1745);
};

function square1746(){

    var sQz1746 = document.getElementById("imgSqrs1746").src;

    value45Save1746 = "zSqrArtSpecz1746";

    localStorage.setItem(value45Save1746, sQz1746);
};

function square1747(){

    var sQz1747 = document.getElementById("imgSqrs1747").src;

    value45Save1747 = "zSqrArtSpecz1747";

    localStorage.setItem(value45Save1747, sQz1747);
};

function square1748(){

    var sQz1748 = document.getElementById("imgSqrs1748").src;

    value45Save1748 = "zSqrArtSpecz1748";

    localStorage.setItem(value45Save1748, sQz1748);
};

function square1749(){

    var sQz1749 = document.getElementById("imgSqrs1749").src;

    value45Save1749 = "zSqrArtSpecz1749";

    localStorage.setItem(value45Save1749, sQz1749);
};

function square1750(){

    var sQz1750 = document.getElementById("imgSqrs1750").src;

    value45Save1750 = "zSqrArtSpecz1750";

    localStorage.setItem(value45Save1750, sQz1750);
};

function square1751(){

    var sQz1751 = document.getElementById("imgSqrs1751").src;

    value45Save1751 = "zSqrArtSpecz1751";

    localStorage.setItem(value45Save1751, sQz1751);
};

function square1752(){

    var sQz1752 = document.getElementById("imgSqrs1752").src;

    value45Save1752 = "zSqrArtSpecz1752";

    localStorage.setItem(value45Save1752, sQz1752);
};

function square1753(){

    var sQz1753 = document.getElementById("imgSqrs1753").src;

    value45Save1753 = "zSqrArtSpecz1753";

    localStorage.setItem(value45Save1753, sQz1753);
};

function square1754(){

    var sQz1754 = document.getElementById("imgSqrs1754").src;

    value45Save1754 = "zSqrArtSpecz1754";

    localStorage.setItem(value45Save1754, sQz1754);
};

function square1755(){

    var sQz1755 = document.getElementById("imgSqrs1755").src;

    value45Save1755 = "zSqrArtSpecz1755";

    localStorage.setItem(value45Save1755, sQz1755);
};

function square1756(){

    var sQz1756 = document.getElementById("imgSqrs1756").src;

    value45Save1756 = "zSqrArtSpecz1756";

    localStorage.setItem(value45Save1756, sQz1756);
};

function square1757(){

    var sQz1757 = document.getElementById("imgSqrs1757").src;

    value45Save1757 = "zSqrArtSpecz1757";

    localStorage.setItem(value45Save1757, sQz1757);
};

function square1758(){

    var sQz1758 = document.getElementById("imgSqrs1758").src;

    value45Save1758 = "zSqrArtSpecz1758";

    localStorage.setItem(value45Save1758, sQz1758);
};

function square1759(){

    var sQz1759 = document.getElementById("imgSqrs1759").src;

    value45Save1759 = "zSqrArtSpecz1759";

    localStorage.setItem(value45Save1759, sQz1759);
};

function square1760(){

    var sQz1760 = document.getElementById("imgSqrs1760").src;

    value45Save1760 = "zSqrArtSpecz1760";

    localStorage.setItem(value45Save1760, sQz1760);
};

function square1761(){

    var sQz1761 = document.getElementById("imgSqrs1761").src;

    value45Save1761 = "zSqrArtSpecz1761";

    localStorage.setItem(value45Save1761, sQz1761);
};

function square1762(){

    var sQz1762 = document.getElementById("imgSqrs1762").src;

    value45Save1762 = "zSqrArtSpecz1762";

    localStorage.setItem(value45Save1762, sQz1762);
};

function square1763(){

    var sQz1763 = document.getElementById("imgSqrs1763").src;

    value45Save1763 = "zSqrArtSpecz1763";

    localStorage.setItem(value45Save1763, sQz1763);
};

function square1764(){

    var sQz1764 = document.getElementById("imgSqrs1764").src;

    value45Save1764 = "zSqrArtSpecz1764";

    localStorage.setItem(value45Save1764, sQz1764);
};

function square1765(){

    var sQz1765 = document.getElementById("imgSqrs1765").src;

    value45Save1765 = "zSqrArtSpecz1765";

    localStorage.setItem(value45Save1765, sQz1765);
};

function square1766(){

    var sQz1766 = document.getElementById("imgSqrs1766").src;

    value45Save1766 = "zSqrArtSpecz1766";

    localStorage.setItem(value45Save1766, sQz1766);
};

function square1767(){

    var sQz1767 = document.getElementById("imgSqrs1767").src;

    value45Save1767 = "zSqrArtSpecz1767";

    localStorage.setItem(value45Save1767, sQz1767);
};

function square1768(){

    var sQz1768 = document.getElementById("imgSqrs1768").src;

    value45Save1768 = "zSqrArtSpecz1768";

    localStorage.setItem(value45Save1768, sQz1768);
};

function square1769(){

    var sQz1769 = document.getElementById("imgSqrs1769").src;

    value45Save1769 = "zSqrArtSpecz1769";

    localStorage.setItem(value45Save1769, sQz1769);
};

function square1770(){

    var sQz1770 = document.getElementById("imgSqrs1770").src;

    value45Save1770 = "zSqrArtSpecz1770";

    localStorage.setItem(value45Save1770, sQz1770);
};

function square1771(){

    var sQz1771 = document.getElementById("imgSqrs1771").src;

    value45Save1771 = "zSqrArtSpecz1771";

    localStorage.setItem(value45Save1771, sQz1771);
};

function square1772(){

    var sQz1772 = document.getElementById("imgSqrs1772").src;

    value45Save1772 = "zSqrArtSpecz1772";

    localStorage.setItem(value45Save1772, sQz1772);
};

function square1773(){

    var sQz1773 = document.getElementById("imgSqrs1773").src;

    value45Save1773 = "zSqrArtSpecz1773";

    localStorage.setItem(value45Save1773, sQz1773);
};

function square1774(){

    var sQz1774 = document.getElementById("imgSqrs1774").src;

    value45Save1774 = "zSqrArtSpecz1774";

    localStorage.setItem(value45Save1774, sQz1774);
};

function square1775(){

    var sQz1775 = document.getElementById("imgSqrs1775").src;

    value45Save1775 = "zSqrArtSpecz1775";

    localStorage.setItem(value45Save1775, sQz1775);
};

function square1776(){

    var sQz1776 = document.getElementById("imgSqrs1776").src;

    value45Save1776 = "zSqrArtSpecz1776";

    localStorage.setItem(value45Save1776, sQz1776);
};

function square1777(){

    var sQz1777 = document.getElementById("imgSqrs1777").src;

    value45Save1777 = "zSqrArtSpecz1777";

    localStorage.setItem(value45Save1777, sQz1777);
};

function square1778(){

    var sQz1778 = document.getElementById("imgSqrs1778").src;

    value45Save1778 = "zSqrArtSpecz1778";

    localStorage.setItem(value45Save1778, sQz1778);
};

function square1779(){

    var sQz1779 = document.getElementById("imgSqrs1779").src;

    value45Save1779 = "zSqrArtSpecz1779";

    localStorage.setItem(value45Save1779, sQz1779);
};

function square1780(){

    var sQz1780 = document.getElementById("imgSqrs1780").src;

    value45Save1780 = "zSqrArtSpecz1780";

    localStorage.setItem(value45Save1780, sQz1780);
};

function square1781(){

    var sQz1781 = document.getElementById("imgSqrs1781").src;

    value45Save1781 = "zSqrArtSpecz1781";

    localStorage.setItem(value45Save1781, sQz1781);
};

function square1782(){

    var sQz1782 = document.getElementById("imgSqrs1782").src;

    value45Save1782 = "zSqrArtSpecz1782";

    localStorage.setItem(value45Save1782, sQz1782);
};

function square1783(){

    var sQz1783 = document.getElementById("imgSqrs1783").src;

    value45Save1783 = "zSqrArtSpecz1783";

    localStorage.setItem(value45Save1783, sQz1783);
};

function square1784(){

    var sQz1784 = document.getElementById("imgSqrs1784").src;

    value45Save1784 = "zSqrArtSpecz1784";

    localStorage.setItem(value45Save1784, sQz1784);
};

function square1785(){

    var sQz1785 = document.getElementById("imgSqrs1785").src;

    value45Save1785 = "zSqrArtSpecz1785";

    localStorage.setItem(value45Save1785, sQz1785);
};

function square1786(){

    var sQz1786 = document.getElementById("imgSqrs1786").src;

    value45Save1786 = "zSqrArtSpecz1786";

    localStorage.setItem(value45Save1786, sQz1786);
};

function square1787(){

    var sQz1787 = document.getElementById("imgSqrs1787").src;

    value45Save1787 = "zSqrArtSpecz1787";

    localStorage.setItem(value45Save1787, sQz1787);
};

function square1788(){

    var sQz1788 = document.getElementById("imgSqrs1788").src;

    value45Save1788 = "zSqrArtSpecz1788";

    localStorage.setItem(value45Save1788, sQz1788);
};

function square1789(){

    var sQz1789 = document.getElementById("imgSqrs1789").src;

    value45Save1789 = "zSqrArtSpecz1789";

    localStorage.setItem(value45Save1789, sQz1789);
};

function square1790(){

    var sQz1790 = document.getElementById("imgSqrs1790").src;

    value45Save1790 = "zSqrArtSpecz1790";

    localStorage.setItem(value45Save1790, sQz1790);
};

function square1791(){

    var sQz1791 = document.getElementById("imgSqrs1791").src;

    value45Save1791 = "zSqrArtSpecz1791";

    localStorage.setItem(value45Save1791, sQz1791);
};

function square1792(){

    var sQz1792 = document.getElementById("imgSqrs1792").src;

    value45Save1792 = "zSqrArtSpecz1792";

    localStorage.setItem(value45Save1792, sQz1792);
};

function square1793(){

    var sQz1793 = document.getElementById("imgSqrs1793").src;

    value45Save1793 = "zSqrArtSpecz1793";

    localStorage.setItem(value45Save1793, sQz1793);
};

function square1794(){

    var sQz1794 = document.getElementById("imgSqrs1794").src;

    value45Save1794 = "zSqrArtSpecz1794";

    localStorage.setItem(value45Save1794, sQz1794);
};

function square1795(){

    var sQz1795 = document.getElementById("imgSqrs1795").src;

    value45Save1795 = "zSqrArtSpecz1795";

    localStorage.setItem(value45Save1795, sQz1795);
};

function square1796(){

    var sQz1796 = document.getElementById("imgSqrs1796").src;

    value45Save1796 = "zSqrArtSpecz1796";

    localStorage.setItem(value45Save1796, sQz1796);
};

function square1797(){

    var sQz1797 = document.getElementById("imgSqrs1797").src;

    value45Save1797 = "zSqrArtSpecz1797";

    localStorage.setItem(value45Save1797, sQz1797);
};

function square1798(){

    var sQz1798 = document.getElementById("imgSqrs1798").src;

    value45Save1798 = "zSqrArtSpecz1798";

    localStorage.setItem(value45Save1798, sQz1798);
};

function square1799(){

    var sQz1799 = document.getElementById("imgSqrs1799").src;

    value45Save1799 = "zSqrArtSpecz1799";

    localStorage.setItem(value45Save1799, sQz1799);
};

function square1800(){

    var sQz1800 = document.getElementById("imgSqrs1800").src;

    value45Save1800 = "zSqrArtSpecz1800";

    localStorage.setItem(value45Save1800, sQz1800);
};

function square1801(){

    var sQz1801 = document.getElementById("imgSqrs1801").src;

    value45Save1801 = "zSqrArtSpecz1801";

    localStorage.setItem(value45Save1801, sQz1801);
};

function square1802(){

    var sQz1802 = document.getElementById("imgSqrs1802").src;

    value45Save1802 = "zSqrArtSpecz1802";

    localStorage.setItem(value45Save1802, sQz1802);
};

function square1803(){

    var sQz1803 = document.getElementById("imgSqrs1803").src;

    value45Save1803 = "zSqrArtSpecz1803";

    localStorage.setItem(value45Save1803, sQz1803);
};

function square1804(){

    var sQz1804 = document.getElementById("imgSqrs1804").src;

    value45Save1804 = "zSqrArtSpecz1804";

    localStorage.setItem(value45Save1804, sQz1804);
};

function square1805(){

    var sQz1805 = document.getElementById("imgSqrs1805").src;

    value45Save1805 = "zSqrArtSpecz1805";

    localStorage.setItem(value45Save1805, sQz1805);
};

function square1806(){

    var sQz1806 = document.getElementById("imgSqrs1806").src;

    value45Save1806 = "zSqrArtSpecz1806";

    localStorage.setItem(value45Save1806, sQz1806);
};

function square1807(){

    var sQz1807 = document.getElementById("imgSqrs1807").src;

    value45Save1807 = "zSqrArtSpecz1807";

    localStorage.setItem(value45Save1807, sQz1807);
};

function square1808(){

    var sQz1808 = document.getElementById("imgSqrs1808").src;

    value45Save1808 = "zSqrArtSpecz1808";

    localStorage.setItem(value45Save1808, sQz1808);
};

function square1809(){

    var sQz1809 = document.getElementById("imgSqrs1809").src;

    value45Save1809 = "zSqrArtSpecz1809";

    localStorage.setItem(value45Save1809, sQz1809);
};

function square1810(){

    var sQz1810 = document.getElementById("imgSqrs1810").src;

    value45Save1810 = "zSqrArtSpecz1810";

    localStorage.setItem(value45Save1810, sQz1810);
};

function square1811(){

    var sQz1811 = document.getElementById("imgSqrs1811").src;

    value45Save1811 = "zSqrArtSpecz1811";

    localStorage.setItem(value45Save1811, sQz1811);
};

function square1812(){

    var sQz1812 = document.getElementById("imgSqrs1812").src;

    value45Save1812 = "zSqrArtSpecz1812";

    localStorage.setItem(value45Save1812, sQz1812);
};

function square1813(){

    var sQz1813 = document.getElementById("imgSqrs1813").src;

    value45Save1813 = "zSqrArtSpecz1813";

    localStorage.setItem(value45Save1813, sQz1813);
};

function square1814(){

    var sQz1814 = document.getElementById("imgSqrs1814").src;

    value45Save1814 = "zSqrArtSpecz1814";

    localStorage.setItem(value45Save1814, sQz1814);
};

function square1815(){

    var sQz1815 = document.getElementById("imgSqrs1815").src;

    value45Save1815 = "zSqrArtSpecz1815";

    localStorage.setItem(value45Save1815, sQz1815);
};

function square1816(){

    var sQz1816 = document.getElementById("imgSqrs1816").src;

    value45Save1816 = "zSqrArtSpecz1816";

    localStorage.setItem(value45Save1816, sQz1816);
};

function square1817(){

    var sQz1817 = document.getElementById("imgSqrs1817").src;

    value45Save1817 = "zSqrArtSpecz1817";

    localStorage.setItem(value45Save1817, sQz1817);
};

function square1818(){

    var sQz1818 = document.getElementById("imgSqrs1818").src;

    value45Save1818 = "zSqrArtSpecz1818";

    localStorage.setItem(value45Save1818, sQz1818);
};

function square1819(){

    var sQz1819 = document.getElementById("imgSqrs1819").src;

    value45Save1819 = "zSqrArtSpecz1819";

    localStorage.setItem(value45Save1819, sQz1819);
};

function square1820(){

    var sQz1820 = document.getElementById("imgSqrs1820").src;

    value45Save1820 = "zSqrArtSpecz1820";

    localStorage.setItem(value45Save1820, sQz1820);
};

function square1821(){

    var sQz1821 = document.getElementById("imgSqrs1821").src;

    value45Save1821 = "zSqrArtSpecz1821";

    localStorage.setItem(value45Save1821, sQz1821);
};

function square1822(){

    var sQz1822 = document.getElementById("imgSqrs1822").src;

    value45Save1822 = "zSqrArtSpecz1822";

    localStorage.setItem(value45Save1822, sQz1822);
};

function square1823(){

    var sQz1823 = document.getElementById("imgSqrs1823").src;

    value45Save1823 = "zSqrArtSpecz1823";

    localStorage.setItem(value45Save1823, sQz1823);
};

function square1824(){

    var sQz1824 = document.getElementById("imgSqrs1824").src;

    value45Save1824 = "zSqrArtSpecz1824";

    localStorage.setItem(value45Save1824, sQz1824);
};

function square1825(){

    var sQz1825 = document.getElementById("imgSqrs1825").src;

    value45Save1825 = "zSqrArtSpecz1825";

    localStorage.setItem(value45Save1825, sQz1825);
};

function square1826(){

    var sQz1826 = document.getElementById("imgSqrs1826").src;

    value45Save1826 = "zSqrArtSpecz1826";

    localStorage.setItem(value45Save1826, sQz1826);
};

function square1827(){

    var sQz1827 = document.getElementById("imgSqrs1827").src;

    value45Save1827 = "zSqrArtSpecz1827";

    localStorage.setItem(value45Save1827, sQz1827);
};

function square1828(){

    var sQz1828 = document.getElementById("imgSqrs1828").src;

    value45Save1828 = "zSqrArtSpecz1828";

    localStorage.setItem(value45Save1828, sQz1828);
};

function square1829(){

    var sQz1829 = document.getElementById("imgSqrs1829").src;

    value45Save1829 = "zSqrArtSpecz1829";

    localStorage.setItem(value45Save1829, sQz1829);
};

function square1830(){

    var sQz1830 = document.getElementById("imgSqrs1830").src;

    value45Save1830 = "zSqrArtSpecz1830";

    localStorage.setItem(value45Save1830, sQz1830);
};

function square1831(){

    var sQz1831 = document.getElementById("imgSqrs1831").src;

    value45Save1831 = "zSqrArtSpecz1831";

    localStorage.setItem(value45Save1831, sQz1831);
};

function square1832(){

    var sQz1832 = document.getElementById("imgSqrs1832").src;

    value45Save1832 = "zSqrArtSpecz1832";

    localStorage.setItem(value45Save1832, sQz1832);
};

function square1833(){

    var sQz1833 = document.getElementById("imgSqrs1833").src;

    value45Save1833 = "zSqrArtSpecz1833";

    localStorage.setItem(value45Save1833, sQz1833);
};

function square1834(){

    var sQz1834 = document.getElementById("imgSqrs1834").src;

    value45Save1834 = "zSqrArtSpecz1834";

    localStorage.setItem(value45Save1834, sQz1834);
};

function square1835(){

    var sQz1835 = document.getElementById("imgSqrs1835").src;

    value45Save1835 = "zSqrArtSpecz1835";

    localStorage.setItem(value45Save1835, sQz1835);
};

function square1836(){

    var sQz1836 = document.getElementById("imgSqrs1836").src;

    value45Save1836 = "zSqrArtSpecz1836";

    localStorage.setItem(value45Save1836, sQz1836);
};

function square1837(){

    var sQz1837 = document.getElementById("imgSqrs1837").src;

    value45Save1837 = "zSqrArtSpecz1837";

    localStorage.setItem(value45Save1837, sQz1837);
};

function square1838(){

    var sQz1838 = document.getElementById("imgSqrs1838").src;

    value45Save1838 = "zSqrArtSpecz1838";

    localStorage.setItem(value45Save1838, sQz1838);
};

function square1839(){

    var sQz1839 = document.getElementById("imgSqrs1839").src;

    value45Save1839 = "zSqrArtSpecz1839";

    localStorage.setItem(value45Save1839, sQz1839);
};

function square1840(){

    var sQz1840 = document.getElementById("imgSqrs1840").src;

    value45Save1840 = "zSqrArtSpecz1840";

    localStorage.setItem(value45Save1840, sQz1840);
};

function square1841(){

    var sQz1841 = document.getElementById("imgSqrs1841").src;

    value45Save1841 = "zSqrArtSpecz1841";

    localStorage.setItem(value45Save1841, sQz1841);
};

function square1842(){

    var sQz1842 = document.getElementById("imgSqrs1842").src;

    value45Save1842 = "zSqrArtSpecz1842";

    localStorage.setItem(value45Save1842, sQz1842);
};

function square1843(){

    var sQz1843 = document.getElementById("imgSqrs1843").src;

    value45Save1843 = "zSqrArtSpecz1843";

    localStorage.setItem(value45Save1843, sQz1843);
};

function square1844(){

    var sQz1844 = document.getElementById("imgSqrs1844").src;

    value45Save1844 = "zSqrArtSpecz1844";

    localStorage.setItem(value45Save1844, sQz1844);
};

function square1845(){

    var sQz1845 = document.getElementById("imgSqrs1845").src;

    value45Save1845 = "zSqrArtSpecz1845";

    localStorage.setItem(value45Save1845, sQz1845);
};

function square1846(){

    var sQz1846 = document.getElementById("imgSqrs1846").src;

    value45Save1846 = "zSqrArtSpecz1846";

    localStorage.setItem(value45Save1846, sQz1846);
};

function square1847(){

    var sQz1847 = document.getElementById("imgSqrs1847").src;

    value45Save1847 = "zSqrArtSpecz1847";

    localStorage.setItem(value45Save1847, sQz1847);
};

function square1848(){

    var sQz1848 = document.getElementById("imgSqrs1848").src;

    value45Save1848 = "zSqrArtSpecz1848";

    localStorage.setItem(value45Save1848, sQz1848);
};

function square1849(){

    var sQz1849 = document.getElementById("imgSqrs1849").src;

    value45Save1849 = "zSqrArtSpecz1849";

    localStorage.setItem(value45Save1849, sQz1849);
};

function square1850(){

    var sQz1850 = document.getElementById("imgSqrs1850").src;

    value45Save1850 = "zSqrArtSpecz1850";

    localStorage.setItem(value45Save1850, sQz1850);
};

function square1851(){

    var sQz1851 = document.getElementById("imgSqrs1851").src;

    value45Save1851 = "zSqrArtSpecz1851";

    localStorage.setItem(value45Save1851, sQz1851);
};

function square1852(){

    var sQz1852 = document.getElementById("imgSqrs1852").src;

    value45Save1852 = "zSqrArtSpecz1852";

    localStorage.setItem(value45Save1852, sQz1852);
};

function square1853(){

    var sQz1853 = document.getElementById("imgSqrs1853").src;

    value45Save1853 = "zSqrArtSpecz1853";

    localStorage.setItem(value45Save1853, sQz1853);
};

function square1854(){

    var sQz1854 = document.getElementById("imgSqrs1854").src;

    value45Save1854 = "zSqrArtSpecz1854";

    localStorage.setItem(value45Save1854, sQz1854);
};

function square1855(){

    var sQz1855 = document.getElementById("imgSqrs1855").src;

    value45Save1855 = "zSqrArtSpecz1855";

    localStorage.setItem(value45Save1855, sQz1855);
};

function square1856(){

    var sQz1856 = document.getElementById("imgSqrs1856").src;

    value45Save1856 = "zSqrArtSpecz1856";

    localStorage.setItem(value45Save1856, sQz1856);
};

function square1857(){

    var sQz1857 = document.getElementById("imgSqrs1857").src;

    value45Save1857 = "zSqrArtSpecz1857";

    localStorage.setItem(value45Save1857, sQz1857);
};

function square1858(){

    var sQz1858 = document.getElementById("imgSqrs1858").src;

    value45Save1858 = "zSqrArtSpecz1858";

    localStorage.setItem(value45Save1858, sQz1858);
};

function square1859(){

    var sQz1859 = document.getElementById("imgSqrs1859").src;

    value45Save1859 = "zSqrArtSpecz1859";

    localStorage.setItem(value45Save1859, sQz1859);
};

function square1860(){

    var sQz1860 = document.getElementById("imgSqrs1860").src;

    value45Save1860 = "zSqrArtSpecz1860";

    localStorage.setItem(value45Save1860, sQz1860);
};

function square1861(){

    var sQz1861 = document.getElementById("imgSqrs1861").src;

    value45Save1861 = "zSqrArtSpecz1861";

    localStorage.setItem(value45Save1861, sQz1861);
};

function square1862(){

    var sQz1862 = document.getElementById("imgSqrs1862").src;

    value45Save1862 = "zSqrArtSpecz1862";

    localStorage.setItem(value45Save1862, sQz1862);
};

function square1863(){

    var sQz1863 = document.getElementById("imgSqrs1863").src;

    value45Save1863 = "zSqrArtSpecz1863";

    localStorage.setItem(value45Save1863, sQz1863);
};

function square1864(){

    var sQz1864 = document.getElementById("imgSqrs1864").src;

    value45Save1864 = "zSqrArtSpecz1864";

    localStorage.setItem(value45Save1864, sQz1864);
};

function square1865(){

    var sQz1865 = document.getElementById("imgSqrs1865").src;

    value45Save1865 = "zSqrArtSpecz1865";

    localStorage.setItem(value45Save1865, sQz1865);
};

function square1866(){

    var sQz1866 = document.getElementById("imgSqrs1866").src;

    value45Save1866 = "zSqrArtSpecz1866";

    localStorage.setItem(value45Save1866, sQz1866);
};

function square1867(){

    var sQz1867 = document.getElementById("imgSqrs1867").src;

    value45Save1867 = "zSqrArtSpecz1867";

    localStorage.setItem(value45Save1867, sQz1867);
};

function square1868(){

    var sQz1868 = document.getElementById("imgSqrs1868").src;

    value45Save1868 = "zSqrArtSpecz1868";

    localStorage.setItem(value45Save1868, sQz1868);
};

function square1869(){

    var sQz1869 = document.getElementById("imgSqrs1869").src;

    value45Save1869 = "zSqrArtSpecz1869";

    localStorage.setItem(value45Save1869, sQz1869);
};

function square1870(){

    var sQz1870 = document.getElementById("imgSqrs1870").src;

    value45Save1870 = "zSqrArtSpecz1870";

    localStorage.setItem(value45Save1870, sQz1870);
};

function square1871(){

    var sQz1871 = document.getElementById("imgSqrs1871").src;

    value45Save1871 = "zSqrArtSpecz1871";

    localStorage.setItem(value45Save1871, sQz1871);
};

function square1872(){

    var sQz1872 = document.getElementById("imgSqrs1872").src;

    value45Save1872 = "zSqrArtSpecz1872";

    localStorage.setItem(value45Save1872, sQz1872);
};

function square1873(){

    var sQz1873 = document.getElementById("imgSqrs1873").src;

    value45Save1873 = "zSqrArtSpecz1873";

    localStorage.setItem(value45Save1873, sQz1873);
};

function square1874(){

    var sQz1874 = document.getElementById("imgSqrs1874").src;

    value45Save1874 = "zSqrArtSpecz1874";

    localStorage.setItem(value45Save1874, sQz1874);
};

function square1875(){

    var sQz1875 = document.getElementById("imgSqrs1875").src;

    value45Save1875 = "zSqrArtSpecz1875";

    localStorage.setItem(value45Save1875, sQz1875);
};

function square1876(){

    var sQz1876 = document.getElementById("imgSqrs1876").src;

    value45Save1876 = "zSqrArtSpecz1876";

    localStorage.setItem(value45Save1876, sQz1876);
};

function square1877(){

    var sQz1877 = document.getElementById("imgSqrs1877").src;

    value45Save1877 = "zSqrArtSpecz1877";

    localStorage.setItem(value45Save1877, sQz1877);
};

function square1878(){

    var sQz1878 = document.getElementById("imgSqrs1878").src;

    value45Save1878 = "zSqrArtSpecz1878";

    localStorage.setItem(value45Save1878, sQz1878);
};

function square1879(){

    var sQz1879 = document.getElementById("imgSqrs1879").src;

    value45Save1879 = "zSqrArtSpecz1879";

    localStorage.setItem(value45Save1879, sQz1879);
};

function square1880(){

    var sQz1880 = document.getElementById("imgSqrs1880").src;

    value45Save1880 = "zSqrArtSpecz1880";

    localStorage.setItem(value45Save1880, sQz1880);
};

function square1881(){

    var sQz1881 = document.getElementById("imgSqrs1881").src;

    value45Save1881 = "zSqrArtSpecz1881";

    localStorage.setItem(value45Save1881, sQz1881);
};

function square1882(){

    var sQz1882 = document.getElementById("imgSqrs1882").src;

    value45Save1882 = "zSqrArtSpecz1882";

    localStorage.setItem(value45Save1882, sQz1882);
};

function square1883(){

    var sQz1883 = document.getElementById("imgSqrs1883").src;

    value45Save1883 = "zSqrArtSpecz1883";

    localStorage.setItem(value45Save1883, sQz1883);
};

function square1884(){

    var sQz1884 = document.getElementById("imgSqrs1884").src;

    value45Save1884 = "zSqrArtSpecz1884";

    localStorage.setItem(value45Save1884, sQz1884);
};

function square1885(){

    var sQz1885 = document.getElementById("imgSqrs1885").src;

    value45Save1885 = "zSqrArtSpecz1885";

    localStorage.setItem(value45Save1885, sQz1885);
};

function square1886(){

    var sQz1886 = document.getElementById("imgSqrs1886").src;

    value45Save1886 = "zSqrArtSpecz1886";

    localStorage.setItem(value45Save1886, sQz1886);
};

function square1887(){

    var sQz1887 = document.getElementById("imgSqrs1887").src;

    value45Save1887 = "zSqrArtSpecz1887";

    localStorage.setItem(value45Save1887, sQz1887);
};

function square1888(){

    var sQz1888 = document.getElementById("imgSqrs1888").src;

    value45Save1888 = "zSqrArtSpecz1888";

    localStorage.setItem(value45Save1888, sQz1888);
};

function square1889(){

    var sQz1889 = document.getElementById("imgSqrs1889").src;

    value45Save1889 = "zSqrArtSpecz1889";

    localStorage.setItem(value45Save1889, sQz1889);
};

function square1890(){

    var sQz1890 = document.getElementById("imgSqrs1890").src;

    value45Save1890 = "zSqrArtSpecz1890";

    localStorage.setItem(value45Save1890, sQz1890);
};

function square1891(){

    var sQz1891 = document.getElementById("imgSqrs1891").src;

    value45Save1891 = "zSqrArtSpecz1891";

    localStorage.setItem(value45Save1891, sQz1891);
};

function square1892(){

    var sQz1892 = document.getElementById("imgSqrs1892").src;

    value45Save1892 = "zSqrArtSpecz1892";

    localStorage.setItem(value45Save1892, sQz1892);
};

function square1893(){

    var sQz1893 = document.getElementById("imgSqrs1893").src;

    value45Save1893 = "zSqrArtSpecz1893";

    localStorage.setItem(value45Save1893, sQz1893);
};

function square1894(){

    var sQz1894 = document.getElementById("imgSqrs1894").src;

    value45Save1894 = "zSqrArtSpecz1894";

    localStorage.setItem(value45Save1894, sQz1894);
};

function square1895(){

    var sQz1895 = document.getElementById("imgSqrs1895").src;

    value45Save1895 = "zSqrArtSpecz1895";

    localStorage.setItem(value45Save1895, sQz1895);
};

function square1896(){

    var sQz1896 = document.getElementById("imgSqrs1896").src;

    value45Save1896 = "zSqrArtSpecz1896";

    localStorage.setItem(value45Save1896, sQz1896);
};

function square1897(){

    var sQz1897 = document.getElementById("imgSqrs1897").src;

    value45Save1897 = "zSqrArtSpecz1897";

    localStorage.setItem(value45Save1897, sQz1897);
};

function square1898(){

    var sQz1898 = document.getElementById("imgSqrs1898").src;

    value45Save1898 = "zSqrArtSpecz1898";

    localStorage.setItem(value45Save1898, sQz1898);
};

function square1899(){

    var sQz1899 = document.getElementById("imgSqrs1899").src;

    value45Save1899 = "zSqrArtSpecz1899";

    localStorage.setItem(value45Save1899, sQz1899);
};

function square1900(){

    var sQz1900 = document.getElementById("imgSqrs1900").src;

    value45Save1900 = "zSqrArtSpecz1900";

    localStorage.setItem(value45Save1900, sQz1900);
};

function square1901(){

    var sQz1901 = document.getElementById("imgSqrs1901").src;

    value45Save1901 = "zSqrArtSpecz1901";

    localStorage.setItem(value45Save1901, sQz1901);
};

function square1902(){

    var sQz1902 = document.getElementById("imgSqrs1902").src;

    value45Save1902 = "zSqrArtSpecz1902";

    localStorage.setItem(value45Save1902, sQz1902);
};

function square1903(){

    var sQz1903 = document.getElementById("imgSqrs1903").src;

    value45Save1903 = "zSqrArtSpecz1903";

    localStorage.setItem(value45Save1903, sQz1903);
};

function square1904(){

    var sQz1904 = document.getElementById("imgSqrs1904").src;

    value45Save1904 = "zSqrArtSpecz1904";

    localStorage.setItem(value45Save1904, sQz1904);
};

function square1905(){

    var sQz1905 = document.getElementById("imgSqrs1905").src;

    value45Save1905 = "zSqrArtSpecz1905";

    localStorage.setItem(value45Save1905, sQz1905);
};

function square1906(){

    var sQz1906 = document.getElementById("imgSqrs1906").src;

    value45Save1906 = "zSqrArtSpecz1906";

    localStorage.setItem(value45Save1906, sQz1906);
};

function square1907(){

    var sQz1907 = document.getElementById("imgSqrs1907").src;

    value45Save1907 = "zSqrArtSpecz1907";

    localStorage.setItem(value45Save1907, sQz1907);
};

function square1908(){

    var sQz1908 = document.getElementById("imgSqrs1908").src;

    value45Save1908 = "zSqrArtSpecz1908";

    localStorage.setItem(value45Save1908, sQz1908);
};

function square1909(){

    var sQz1909 = document.getElementById("imgSqrs1909").src;

    value45Save1909 = "zSqrArtSpecz1909";

    localStorage.setItem(value45Save1909, sQz1909);
};

function square1910(){

    var sQz1910 = document.getElementById("imgSqrs1910").src;

    value45Save1910 = "zSqrArtSpecz1910";

    localStorage.setItem(value45Save1910, sQz1910);
};

function square1911(){

    var sQz1911 = document.getElementById("imgSqrs1911").src;

    value45Save1911 = "zSqrArtSpecz1911";

    localStorage.setItem(value45Save1911, sQz1911);
};

function square1912(){

    var sQz1912 = document.getElementById("imgSqrs1912").src;

    value45Save1912 = "zSqrArtSpecz1912";

    localStorage.setItem(value45Save1912, sQz1912);
};

function square1913(){

    var sQz1913 = document.getElementById("imgSqrs1913").src;

    value45Save1913 = "zSqrArtSpecz1913";

    localStorage.setItem(value45Save1913, sQz1913);
};

function square1914(){

    var sQz1914 = document.getElementById("imgSqrs1914").src;

    value45Save1914 = "zSqrArtSpecz1914";

    localStorage.setItem(value45Save1914, sQz1914);
};

function square1915(){

    var sQz1915 = document.getElementById("imgSqrs1915").src;

    value45Save1915 = "zSqrArtSpecz1915";

    localStorage.setItem(value45Save1915, sQz1915);
};

function square1916(){

    var sQz1916 = document.getElementById("imgSqrs1916").src;

    value45Save1916 = "zSqrArtSpecz1916";

    localStorage.setItem(value45Save1916, sQz1916);
};

function square1917(){

    var sQz1917 = document.getElementById("imgSqrs1917").src;

    value45Save1917 = "zSqrArtSpecz1917";

    localStorage.setItem(value45Save1917, sQz1917);
};

function square1918(){

    var sQz1918 = document.getElementById("imgSqrs1918").src;

    value45Save1918 = "zSqrArtSpecz1918";

    localStorage.setItem(value45Save1918, sQz1918);
};

function square1919(){

    var sQz1919 = document.getElementById("imgSqrs1919").src;

    value45Save1919 = "zSqrArtSpecz1919";

    localStorage.setItem(value45Save1919, sQz1919);
};

function square1920(){

    var sQz1920 = document.getElementById("imgSqrs1920").src;

    value45Save1920 = "zSqrArtSpecz1920";

    localStorage.setItem(value45Save1920, sQz1920);
};

function square1921(){

    var sQz1921 = document.getElementById("imgSqrs1921").src;

    value45Save1921 = "zSqrArtSpecz1921";

    localStorage.setItem(value45Save1921, sQz1921);
};

function square1922(){

    var sQz1922 = document.getElementById("imgSqrs1922").src;

    value45Save1922 = "zSqrArtSpecz1922";

    localStorage.setItem(value45Save1922, sQz1922);
};

function square1923(){

    var sQz1923 = document.getElementById("imgSqrs1923").src;

    value45Save1923 = "zSqrArtSpecz1923";

    localStorage.setItem(value45Save1923, sQz1923);
};

function square1924(){

    var sQz1924 = document.getElementById("imgSqrs1924").src;

    value45Save1924 = "zSqrArtSpecz1924";

    localStorage.setItem(value45Save1924, sQz1924);
};

function square1925(){

    var sQz1925 = document.getElementById("imgSqrs1925").src;

    value45Save1925 = "zSqrArtSpecz1925";

    localStorage.setItem(value45Save1925, sQz1925);
};

function square1926(){

    var sQz1926 = document.getElementById("imgSqrs1926").src;

    value45Save1926 = "zSqrArtSpecz1926";

    localStorage.setItem(value45Save1926, sQz1926);
};

function square1927(){

    var sQz1927 = document.getElementById("imgSqrs1927").src;

    value45Save1927 = "zSqrArtSpecz1927";

    localStorage.setItem(value45Save1927, sQz1927);
};

function square1928(){

    var sQz1928 = document.getElementById("imgSqrs1928").src;

    value45Save1928 = "zSqrArtSpecz1928";

    localStorage.setItem(value45Save1928, sQz1928);
};

function square1929(){

    var sQz1929 = document.getElementById("imgSqrs1929").src;

    value45Save1929 = "zSqrArtSpecz1929";

    localStorage.setItem(value45Save1929, sQz1929);
};

function square1930(){

    var sQz1930 = document.getElementById("imgSqrs1930").src;

    value45Save1930 = "zSqrArtSpecz1930";

    localStorage.setItem(value45Save1930, sQz1930);
};

function square1931(){

    var sQz1931 = document.getElementById("imgSqrs1931").src;

    value45Save1931 = "zSqrArtSpecz1931";

    localStorage.setItem(value45Save1931, sQz1931);
};

function square1932(){

    var sQz1932 = document.getElementById("imgSqrs1932").src;

    value45Save1932 = "zSqrArtSpecz1932";

    localStorage.setItem(value45Save1932, sQz1932);
};

function square1933(){

    var sQz1933 = document.getElementById("imgSqrs1933").src;

    value45Save1933 = "zSqrArtSpecz1933";

    localStorage.setItem(value45Save1933, sQz1933);
};

function square1934(){

    var sQz1934 = document.getElementById("imgSqrs1934").src;

    value45Save1934 = "zSqrArtSpecz1934";

    localStorage.setItem(value45Save1934, sQz1934);
};

function square1935(){

    var sQz1935 = document.getElementById("imgSqrs1935").src;

    value45Save1935 = "zSqrArtSpecz1935";

    localStorage.setItem(value45Save1935, sQz1935);
};

function square1936(){

    var sQz1936 = document.getElementById("imgSqrs1936").src;

    value45Save1936 = "zSqrArtSpecz1936";

    localStorage.setItem(value45Save1936, sQz1936);
};

function square1937(){

    var sQz1937 = document.getElementById("imgSqrs1937").src;

    value45Save1937 = "zSqrArtSpecz1937";

    localStorage.setItem(value45Save1937, sQz1937);
};

function square1938(){

    var sQz1938 = document.getElementById("imgSqrs1938").src;

    value45Save1938 = "zSqrArtSpecz1938";

    localStorage.setItem(value45Save1938, sQz1938);
};

function square1939(){

    var sQz1939 = document.getElementById("imgSqrs1939").src;

    value45Save1939 = "zSqrArtSpecz1939";

    localStorage.setItem(value45Save1939, sQz1939);
};

function square1940(){

    var sQz1940 = document.getElementById("imgSqrs1940").src;

    value45Save1940 = "zSqrArtSpecz1940";

    localStorage.setItem(value45Save1940, sQz1940);
};

function square1941(){

    var sQz1941 = document.getElementById("imgSqrs1941").src;

    value45Save1941 = "zSqrArtSpecz1941";

    localStorage.setItem(value45Save1941, sQz1941);
};

function square1942(){

    var sQz1942 = document.getElementById("imgSqrs1942").src;

    value45Save1942 = "zSqrArtSpecz1942";

    localStorage.setItem(value45Save1942, sQz1942);
};

function square1943(){

    var sQz1943 = document.getElementById("imgSqrs1943").src;

    value45Save1943 = "zSqrArtSpecz1943";

    localStorage.setItem(value45Save1943, sQz1943);
};

function square1944(){

    var sQz1944 = document.getElementById("imgSqrs1944").src;

    value45Save1944 = "zSqrArtSpecz1944";

    localStorage.setItem(value45Save1944, sQz1944);
};

function square1945(){

    var sQz1945 = document.getElementById("imgSqrs1945").src;

    value45Save1945 = "zSqrArtSpecz1945";

    localStorage.setItem(value45Save1945, sQz1945);
};

function square1946(){

    var sQz1946 = document.getElementById("imgSqrs1946").src;

    value45Save1946 = "zSqrArtSpecz1946";

    localStorage.setItem(value45Save1946, sQz1946);
};

function square1947(){

    var sQz1947 = document.getElementById("imgSqrs1947").src;

    value45Save1947 = "zSqrArtSpecz1947";

    localStorage.setItem(value45Save1947, sQz1947);
};

function square1948(){

    var sQz1948 = document.getElementById("imgSqrs1948").src;

    value45Save1948 = "zSqrArtSpecz1948";

    localStorage.setItem(value45Save1948, sQz1948);
};

function square1949(){

    var sQz1949 = document.getElementById("imgSqrs1949").src;

    value45Save1949 = "zSqrArtSpecz1949";

    localStorage.setItem(value45Save1949, sQz1949);
};

function square1950(){

    var sQz1950 = document.getElementById("imgSqrs1950").src;

    value45Save1950 = "zSqrArtSpecz1950";

    localStorage.setItem(value45Save1950, sQz1950);
};

function square1951(){

    var sQz1951 = document.getElementById("imgSqrs1951").src;

    value45Save1951 = "zSqrArtSpecz1951";

    localStorage.setItem(value45Save1951, sQz1951);
};

function square1952(){

    var sQz1952 = document.getElementById("imgSqrs1952").src;

    value45Save1952 = "zSqrArtSpecz1952";

    localStorage.setItem(value45Save1952, sQz1952);
};

function square1953(){

    var sQz1953 = document.getElementById("imgSqrs1953").src;

    value45Save1953 = "zSqrArtSpecz1953";

    localStorage.setItem(value45Save1953, sQz1953);
};

function square1954(){

    var sQz1954 = document.getElementById("imgSqrs1954").src;

    value45Save1954 = "zSqrArtSpecz1954";

    localStorage.setItem(value45Save1954, sQz1954);
};

function square1955(){

    var sQz1955 = document.getElementById("imgSqrs1955").src;

    value45Save1955 = "zSqrArtSpecz1955";

    localStorage.setItem(value45Save1955, sQz1955);
};

function square1956(){

    var sQz1956 = document.getElementById("imgSqrs1956").src;

    value45Save1956 = "zSqrArtSpecz1956";

    localStorage.setItem(value45Save1956, sQz1956);
};

function square1957(){

    var sQz1957 = document.getElementById("imgSqrs1957").src;

    value45Save1957 = "zSqrArtSpecz1957";

    localStorage.setItem(value45Save1957, sQz1957);
};

function square1958(){

    var sQz1958 = document.getElementById("imgSqrs1958").src;

    value45Save1958 = "zSqrArtSpecz1958";

    localStorage.setItem(value45Save1958, sQz1958);
};

function square1959(){

    var sQz1959 = document.getElementById("imgSqrs1959").src;

    value45Save1959 = "zSqrArtSpecz1959";

    localStorage.setItem(value45Save1959, sQz1959);
};

function square1960(){

    var sQz1960 = document.getElementById("imgSqrs1960").src;

    value45Save1960 = "zSqrArtSpecz1960";

    localStorage.setItem(value45Save1960, sQz1960);
};

function square1961(){

    var sQz1961 = document.getElementById("imgSqrs1961").src;

    value45Save1961 = "zSqrArtSpecz1961";

    localStorage.setItem(value45Save1961, sQz1961);
};

function square1962(){

    var sQz1962 = document.getElementById("imgSqrs1962").src;

    value45Save1962 = "zSqrArtSpecz1962";

    localStorage.setItem(value45Save1962, sQz1962);
};

function square1963(){

    var sQz1963 = document.getElementById("imgSqrs1963").src;

    value45Save1963 = "zSqrArtSpecz1963";

    localStorage.setItem(value45Save1963, sQz1963);
};

function square1964(){

    var sQz1964 = document.getElementById("imgSqrs1964").src;

    value45Save1964 = "zSqrArtSpecz1964";

    localStorage.setItem(value45Save1964, sQz1964);
};

function square1965(){

    var sQz1965 = document.getElementById("imgSqrs1965").src;

    value45Save1965 = "zSqrArtSpecz1965";

    localStorage.setItem(value45Save1965, sQz1965);
};

function square1966(){

    var sQz1966 = document.getElementById("imgSqrs1966").src;

    value45Save1966 = "zSqrArtSpecz1966";

    localStorage.setItem(value45Save1966, sQz1966);
};

function square1967(){

    var sQz1967 = document.getElementById("imgSqrs1967").src;

    value45Save1967 = "zSqrArtSpecz1967";

    localStorage.setItem(value45Save1967, sQz1967);
};

function square1968(){

    var sQz1968 = document.getElementById("imgSqrs1968").src;

    value45Save1968 = "zSqrArtSpecz1968";

    localStorage.setItem(value45Save1968, sQz1968);
};

function square1969(){

    var sQz1969 = document.getElementById("imgSqrs1969").src;

    value45Save1969 = "zSqrArtSpecz1969";

    localStorage.setItem(value45Save1969, sQz1969);
};

function square1970(){

    var sQz1970 = document.getElementById("imgSqrs1970").src;

    value45Save1970 = "zSqrArtSpecz1970";

    localStorage.setItem(value45Save1970, sQz1970);
};

function square1971(){

    var sQz1971 = document.getElementById("imgSqrs1971").src;

    value45Save1971 = "zSqrArtSpecz1971";

    localStorage.setItem(value45Save1971, sQz1971);
};

function square1972(){

    var sQz1972 = document.getElementById("imgSqrs1972").src;

    value45Save1972 = "zSqrArtSpecz1972";

    localStorage.setItem(value45Save1972, sQz1972);
};

function square1973(){

    var sQz1973 = document.getElementById("imgSqrs1973").src;

    value45Save1973 = "zSqrArtSpecz1973";

    localStorage.setItem(value45Save1973, sQz1973);
};

function square1974(){

    var sQz1974 = document.getElementById("imgSqrs1974").src;

    value45Save1974 = "zSqrArtSpecz1974";

    localStorage.setItem(value45Save1974, sQz1974);
};

function square1975(){

    var sQz1975 = document.getElementById("imgSqrs1975").src;

    value45Save1975 = "zSqrArtSpecz1975";

    localStorage.setItem(value45Save1975, sQz1975);
};

function square1976(){

    var sQz1976 = document.getElementById("imgSqrs1976").src;

    value45Save1976 = "zSqrArtSpecz1976";

    localStorage.setItem(value45Save1976, sQz1976);
};

function square1977(){

    var sQz1977 = document.getElementById("imgSqrs1977").src;

    value45Save1977 = "zSqrArtSpecz1977";

    localStorage.setItem(value45Save1977, sQz1977);
};

function square1978(){

    var sQz1978 = document.getElementById("imgSqrs1978").src;

    value45Save1978 = "zSqrArtSpecz1978";

    localStorage.setItem(value45Save1978, sQz1978);
};

function square1979(){

    var sQz1979 = document.getElementById("imgSqrs1979").src;

    value45Save1979 = "zSqrArtSpecz1979";

    localStorage.setItem(value45Save1979, sQz1979);
};

function square1980(){

    var sQz1980 = document.getElementById("imgSqrs1980").src;

    value45Save1980 = "zSqrArtSpecz1980";

    localStorage.setItem(value45Save1980, sQz1980);
};

function square1981(){

    var sQz1981 = document.getElementById("imgSqrs1981").src;

    value45Save1981 = "zSqrArtSpecz1981";

    localStorage.setItem(value45Save1981, sQz1981);
};

function square1982(){

    var sQz1982 = document.getElementById("imgSqrs1982").src;

    value45Save1982 = "zSqrArtSpecz1982";

    localStorage.setItem(value45Save1982, sQz1982);
};

function square1983(){

    var sQz1983 = document.getElementById("imgSqrs1983").src;

    value45Save1983 = "zSqrArtSpecz1983";

    localStorage.setItem(value45Save1983, sQz1983);
};

function square1984(){

    var sQz1984 = document.getElementById("imgSqrs1984").src;

    value45Save1984 = "zSqrArtSpecz1984";

    localStorage.setItem(value45Save1984, sQz1984);
};

function square1985(){

    var sQz1985 = document.getElementById("imgSqrs1985").src;

    value45Save1985 = "zSqrArtSpecz1985";

    localStorage.setItem(value45Save1985, sQz1985);
};

function square1986(){

    var sQz1986 = document.getElementById("imgSqrs1986").src;

    value45Save1986 = "zSqrArtSpecz1986";

    localStorage.setItem(value45Save1986, sQz1986);
};

function square1987(){

    var sQz1987 = document.getElementById("imgSqrs1987").src;

    value45Save1987 = "zSqrArtSpecz1987";

    localStorage.setItem(value45Save1987, sQz1987);
};

function square1988(){

    var sQz1988 = document.getElementById("imgSqrs1988").src;

    value45Save1988 = "zSqrArtSpecz1988";

    localStorage.setItem(value45Save1988, sQz1988);
};

function square1989(){

    var sQz1989 = document.getElementById("imgSqrs1989").src;

    value45Save1989 = "zSqrArtSpecz1989";

    localStorage.setItem(value45Save1989, sQz1989);
};

function square1990(){

    var sQz1990 = document.getElementById("imgSqrs1990").src;

    value45Save1990 = "zSqrArtSpecz1990";

    localStorage.setItem(value45Save1990, sQz1990);
};

function square1991(){

    var sQz1991 = document.getElementById("imgSqrs1991").src;

    value45Save1991 = "zSqrArtSpecz1991";

    localStorage.setItem(value45Save1991, sQz1991);
};

function square1992(){

    var sQz1992 = document.getElementById("imgSqrs1992").src;

    value45Save1992 = "zSqrArtSpecz1992";

    localStorage.setItem(value45Save1992, sQz1992);
};

function square1993(){

    var sQz1993 = document.getElementById("imgSqrs1993").src;

    value45Save1993 = "zSqrArtSpecz1993";

    localStorage.setItem(value45Save1993, sQz1993);
};

function square1994(){

    var sQz1994 = document.getElementById("imgSqrs1994").src;

    value45Save1994 = "zSqrArtSpecz1994";

    localStorage.setItem(value45Save1994, sQz1994);
};

function square1995(){

    var sQz1995 = document.getElementById("imgSqrs1995").src;

    value45Save1995 = "zSqrArtSpecz1995";

    localStorage.setItem(value45Save1995, sQz1995);
};

function square1996(){

    var sQz1996 = document.getElementById("imgSqrs1996").src;

    value45Save1996 = "zSqrArtSpecz1996";

    localStorage.setItem(value45Save1996, sQz1996);
};

function square1997(){

    var sQz1997 = document.getElementById("imgSqrs1997").src;

    value45Save1997 = "zSqrArtSpecz1997";

    localStorage.setItem(value45Save1997, sQz1997);
};

function square1998(){

    var sQz1998 = document.getElementById("imgSqrs1998").src;

    value45Save1998 = "zSqrArtSpecz1998";

    localStorage.setItem(value45Save1998, sQz1998);
};

function square1999(){

    var sQz1999 = document.getElementById("imgSqrs1999").src;

    value45Save1999 = "zSqrArtSpecz1999";

    localStorage.setItem(value45Save1999, sQz1999);
};

function square2000(){

    var sQz2000 = document.getElementById("imgSqrs2000").src;

    value45Save2000 = "zSqrArtSpecz2000";

    localStorage.setItem(value45Save2000, sQz2000);
};

function square2001(){

    var sQz2001 = document.getElementById("imgSqrs2001").src;

    value45Save2001 = "zSqrArtSpecz2001";

    localStorage.setItem(value45Save2001, sQz2001);
};

function square2002(){

    var sQz2002 = document.getElementById("imgSqrs2002").src;

    value45Save2002 = "zSqrArtSpecz2002";

    localStorage.setItem(value45Save2002, sQz2002);
};

function square2003(){

    var sQz2003 = document.getElementById("imgSqrs2003").src;

    value45Save2003 = "zSqrArtSpecz2003";

    localStorage.setItem(value45Save2003, sQz2003);
};

function square2004(){

    var sQz2004 = document.getElementById("imgSqrs2004").src;

    value45Save2004 = "zSqrArtSpecz2004";

    localStorage.setItem(value45Save2004, sQz2004);
};

function square2005(){

    var sQz2005 = document.getElementById("imgSqrs2005").src;

    value45Save2005 = "zSqrArtSpecz2005";

    localStorage.setItem(value45Save2005, sQz2005);
};

function square2006(){

    var sQz2006 = document.getElementById("imgSqrs2006").src;

    value45Save2006 = "zSqrArtSpecz2006";

    localStorage.setItem(value45Save2006, sQz2006);
};

function square2007(){

    var sQz2007 = document.getElementById("imgSqrs2007").src;

    value45Save2007 = "zSqrArtSpecz2007";

    localStorage.setItem(value45Save2007, sQz2007);
};

function square2008(){

    var sQz2008 = document.getElementById("imgSqrs2008").src;

    value45Save2008 = "zSqrArtSpecz2008";

    localStorage.setItem(value45Save2008, sQz2008);
};

function square2009(){

    var sQz2009 = document.getElementById("imgSqrs2009").src;

    value45Save2009 = "zSqrArtSpecz2009";

    localStorage.setItem(value45Save2009, sQz2009);
};

function square2010(){

    var sQz2010 = document.getElementById("imgSqrs2010").src;

    value45Save2010 = "zSqrArtSpecz2010";

    localStorage.setItem(value45Save2010, sQz2010);
};

function square2011(){

    var sQz2011 = document.getElementById("imgSqrs2011").src;

    value45Save2011 = "zSqrArtSpecz2011";

    localStorage.setItem(value45Save2011, sQz2011);
};

function square2012(){

    var sQz2012 = document.getElementById("imgSqrs2012").src;

    value45Save2012 = "zSqrArtSpecz2012";

    localStorage.setItem(value45Save2012, sQz2012);
};

function square2013(){

    var sQz2013 = document.getElementById("imgSqrs2013").src;

    value45Save2013 = "zSqrArtSpecz2013";

    localStorage.setItem(value45Save2013, sQz2013);
};

function square2014(){

    var sQz2014 = document.getElementById("imgSqrs2014").src;

    value45Save2014 = "zSqrArtSpecz2014";

    localStorage.setItem(value45Save2014, sQz2014);
};

function square2015(){

    var sQz2015 = document.getElementById("imgSqrs2015").src;

    value45Save2015 = "zSqrArtSpecz2015";

    localStorage.setItem(value45Save2015, sQz2015);
};

function square2016(){

    var sQz2016 = document.getElementById("imgSqrs2016").src;

    value45Save2016 = "zSqrArtSpecz2016";

    localStorage.setItem(value45Save2016, sQz2016);
};

function square2017(){

    var sQz2017 = document.getElementById("imgSqrs2017").src;

    value45Save2017 = "zSqrArtSpecz2017";

    localStorage.setItem(value45Save2017, sQz2017);
};

function square2018(){

    var sQz2018 = document.getElementById("imgSqrs2018").src;

    value45Save2018 = "zSqrArtSpecz2018";

    localStorage.setItem(value45Save2018, sQz2018);
};

function square2019(){

    var sQz2019 = document.getElementById("imgSqrs2019").src;

    value45Save2019 = "zSqrArtSpecz2019";

    localStorage.setItem(value45Save2019, sQz2019);
};

function square2020(){

    var sQz2020 = document.getElementById("imgSqrs2020").src;

    value45Save2020 = "zSqrArtSpecz2020";

    localStorage.setItem(value45Save2020, sQz2020);
};

function square2021(){

    var sQz2021 = document.getElementById("imgSqrs2021").src;

    value45Save2021 = "zSqrArtSpecz2021";

    localStorage.setItem(value45Save2021, sQz2021);
};

function square2022(){

    var sQz2022 = document.getElementById("imgSqrs2022").src;

    value45Save2022 = "zSqrArtSpecz2022";

    localStorage.setItem(value45Save2022, sQz2022);
};

function square2023(){

    var sQz2023 = document.getElementById("imgSqrs2023").src;

    value45Save2023 = "zSqrArtSpecz2023";

    localStorage.setItem(value45Save2023, sQz2023);
};

function square2024(){

    var sQz2024 = document.getElementById("imgSqrs2024").src;

    value45Save2024 = "zSqrArtSpecz2024";

    localStorage.setItem(value45Save2024, sQz2024);
};

function square2025(){

    var sQz2025 = document.getElementById("imgSqrs2025").src;

    value45Save2025 = "zSqrArtSpecz2025";

    localStorage.setItem(value45Save2025, sQz2025);
};

function setAThis(){
    square1()

    square2()

    square3()

    square4()

    square5()

    square6()

    square7()

    square8()

    square9()

    square10()

    square11()

    square12()

    square13()

    square14()

    square15()

    square16()

    square17()

    square18()

    square19()

    square20()

    square21()

    square22()

    square23()

    square24()

    square25()

    square26()

    square27()

    square28()

    square29()

    square30()

    square31()

    square32()

    square33()

    square34()

    square35()

    square36()

    square37()

    square38()

    square39()

    square40()

    square41()

    square42()

    square43()

    square44()

    square45()

    square46()

    square47()

    square48()

    square49()

    square50()

    square51()

    square52()

    square53()

    square54()

    square55()

    square56()

    square57()

    square58()

    square59()

    square60()

    square61()

    square62()

    square63()

    square64()

    square65()

    square66()

    square67()

    square68()

    square69()

    square70()

    square71()

    square72()

    square73()

    square74()

    square75()

    square76()

    square77()

    square78()

    square79()

    square80()

    square81()

    square82()

    square83()

    square84()

    square85()

    square86()

    square87()

    square88()

    square89()

    square90()

    square91()

    square92()

    square93()

    square94()

    square95()

    square96()

    square97()

    square98()

    square99()

    square100()

    square101()

    square102()

    square103()

    square104()

    square105()

    square106()

    square107()

    square108()

    square109()

    square110()

    square111()

    square112()

    square113()

    square114()

    square115()

    square116()

    square117()

    square118()

    square119()

    square120()

    square121()

    square122()

    square123()

    square124()

    square125()

    square126()

    square127()

    square128()

    square129()

    square130()

    square131()

    square132()

    square133()

    square134()

    square135()

    square136()

    square137()

    square138()

    square139()

    square140()

    square141()

    square142()

    square143()

    square144()

    square145()

    square146()

    square147()

    square148()

    square149()

    square150()

    square151()

    square152()

    square153()

    square154()

    square155()

    square156()

    square157()

    square158()

    square159()

    square160()

    square161()

    square162()

    square163()

    square164()

    square165()

    square166()

    square167()

    square168()

    square169()

    square170()

    square171()

    square172()

    square173()

    square174()

    square175()

    square176()

    square177()

    square178()

    square179()

    square180()

    square181()

    square182()

    square183()

    square184()

    square185()

    square186()

    square187()

    square188()

    square189()

    square190()

    square191()

    square192()

    square193()

    square194()

    square195()

    square196()

    square197()

    square198()

    square199()

    square200()

    square201()

    square202()

    square203()

    square204()

    square205()

    square206()

    square207()

    square208()

    square209()

    square210()

    square211()

    square212()

    square213()

    square214()

    square215()

    square216()

    square217()

    square218()

    square219()

    square220()

    square221()

    square222()

    square223()

    square224()

    square225()

    square226()

    square227()

    square228()

    square229()

    square230()

    square231()

    square232()

    square233()

    square234()

    square235()

    square236()

    square237()

    square238()

    square239()

    square240()

    square241()

    square242()

    square243()

    square244()

    square245()

    square246()

    square247()

    square248()

    square249()

    square250()

    square251()

    square252()

    square253()

    square254()

    square255()

    square256()

    square257()

    square258()

    square259()

    square260()

    square261()

    square262()

    square263()

    square264()

    square265()

    square266()

    square267()

    square268()

    square269()

    square270()

    square271()

    square272()

    square273()

    square274()

    square275()

    square276()

    square277()

    square278()

    square279()

    square280()

    square281()

    square282()

    square283()

    square284()

    square285()

    square286()

    square287()

    square288()

    square289()

    square290()

    square291()

    square292()

    square293()

    square294()

    square295()

    square296()

    square297()

    square298()

    square299()

    square300()

    square301()

    square302()

    square303()

    square304()

    square305()

    square306()

    square307()

    square308()

    square309()

    square310()

    square311()

    square312()

    square313()

    square314()

    square315()

    square316()

    square317()

    square318()

    square319()

    square320()

    square321()

    square322()

    square323()

    square324()

    square325()

    square326()

    square327()

    square328()

    square329()

    square330()

    square331()

    square332()

    square333()

    square334()

    square335()

    square336()

    square337()

    square338()

    square339()

    square340()

    square341()

    square342()

    square343()

    square344()

    square345()

    square346()

    square347()

    square348()

    square349()

    square350()

    square351()

    square352()

    square353()

    square354()

    square355()

    square356()

    square357()

    square358()

    square359()

    square360()

    square361()

    square362()

    square363()

    square364()

    square365()

    square366()

    square367()

    square368()

    square369()

    square370()

    square371()

    square372()

    square373()

    square374()

    square375()

    square376()

    square377()

    square378()

    square379()

    square380()

    square381()

    square382()

    square383()

    square384()

    square385()

    square386()

    square387()

    square388()

    square389()

    square390()

    square391()

    square392()

    square393()

    square394()

    square395()

    square396()

    square397()

    square398()

    square399()

    square400()

    square401()

    square402()

    square403()

    square404()

    square405()

    square406()

    square407()

    square408()

    square409()

    square410()

    square411()

    square412()

    square413()

    square414()

    square415()

    square416()

    square417()

    square418()

    square419()

    square420()

    square421()

    square422()

    square423()

    square424()

    square425()

    square426()

    square427()

    square428()

    square429()

    square430()

    square431()

    square432()

    square433()

    square434()

    square435()

    square436()

    square437()

    square438()

    square439()

    square440()

    square441()

    square442()

    square443()

    square444()

    square445()

    square446()

    square447()

    square448()

    square449()

    square450()

    square451()

    square452()

    square453()

    square454()

    square455()

    square456()

    square457()

    square458()

    square459()

    square460()

    square461()

    square462()

    square463()

    square464()

    square465()

    square466()

    square467()

    square468()

    square469()

    square470()

    square471()

    square472()

    square473()

    square474()

    square475()

    square476()

    square477()

    square478()

    square479()

    square480()

    square481()

    square482()

    square483()

    square484()

    square485()

    square486()

    square487()

    square488()

    square489()

    square490()

    square491()

    square492()

    square493()

    square494()

    square495()

    square496()

    square497()

    square498()

    square499()

    square500()

    square501()

    square502()

    square503()

    square504()

    square505()

    square506()

    square507()

    square508()

    square509()

    square510()

    square511()

    square512()

    square513()

    square514()

    square515()

    square516()

    square517()

    square518()

    square519()

    square520()

    square521()

    square522()

    square523()

    square524()

    square525()

    square526()

    square527()

    square528()

    square529()

    square530()

    square531()

    square532()

    square533()

    square534()

    square535()

    square536()

    square537()

    square538()

    square539()

    square540()

    square541()

    square542()

    square543()

    square544()

    square545()

    square546()

    square547()

    square548()

    square549()

    square550()

    square551()

    square552()

    square553()

    square554()

    square555()

    square556()

    square557()

    square558()

    square559()

    square560()

    square561()

    square562()

    square563()

    square564()

    square565()

    square566()

    square567()

    square568()

    square569()

    square570()

    square571()

    square572()

    square573()

    square574()

    square575()

    square576()

    square577()

    square578()

    square579()

    square580()

    square581()

    square582()

    square583()

    square584()

    square585()

    square586()

    square587()

    square588()

    square589()

    square590()

    square591()

    square592()

    square593()

    square594()

    square595()

    square596()

    square597()

    square598()

    square599()

    square600()

    square601()

    square602()

    square603()

    square604()

    square605()

    square606()

    square607()

    square608()

    square609()

    square610()

    square611()

    square612()

    square613()

    square614()

    square615()

    square616()

    square617()

    square618()

    square619()

    square620()

    square621()

    square622()

    square623()

    square624()

    square625()

    square626()

    square627()

    square628()

    square629()

    square630()

    square631()

    square632()

    square633()

    square634()

    square635()

    square636()

    square637()

    square638()

    square639()

    square640()

    square641()

    square642()

    square643()

    square644()

    square645()

    square646()

    square647()

    square648()

    square649()

    square650()

    square651()

    square652()

    square653()

    square654()

    square655()

    square656()

    square657()

    square658()

    square659()

    square660()

    square661()

    square662()

    square663()

    square664()

    square665()

    square666()

    square667()

    square668()

    square669()

    square670()

    square671()

    square672()

    square673()

    square674()

    square675()

    square676()

    square677()

    square678()

    square679()

    square680()

    square681()

    square682()

    square683()

    square684()

    square685()

    square686()

    square687()

    square688()

    square689()

    square690()

    square691()

    square692()

    square693()

    square694()

    square695()

    square696()

    square697()

    square698()

    square699()

    square700()

    square701()

    square702()

    square703()

    square704()

    square705()

    square706()

    square707()

    square708()

    square709()

    square710()

    square711()

    square712()

    square713()

    square714()

    square715()

    square716()

    square717()

    square718()

    square719()

    square720()

    square721()

    square722()

    square723()

    square724()

    square725()

    square726()

    square727()

    square728()

    square729()

    square730()

    square731()

    square732()

    square733()

    square734()

    square735()

    square736()

    square737()

    square738()

    square739()

    square740()

    square741()

    square742()

    square743()

    square744()

    square745()

    square746()

    square747()

    square748()

    square749()

    square750()

    square751()

    square752()

    square753()

    square754()

    square755()

    square756()

    square757()

    square758()

    square759()

    square760()

    square761()

    square762()

    square763()

    square764()

    square765()

    square766()

    square767()

    square768()

    square769()

    square770()

    square771()

    square772()

    square773()

    square774()

    square775()

    square776()

    square777()

    square778()

    square779()

    square780()

    square781()

    square782()

    square783()

    square784()

    square785()

    square786()

    square787()

    square788()

    square789()

    square790()

    square791()

    square792()

    square793()

    square794()

    square795()

    square796()

    square797()

    square798()

    square799()

    square800()

    square801()

    square802()

    square803()

    square804()

    square805()

    square806()

    square807()

    square808()

    square809()

    square810()

    square811()

    square812()

    square813()

    square814()

    square815()

    square816()

    square817()

    square818()

    square819()

    square820()

    square821()

    square822()

    square823()

    square824()

    square825()

    square826()

    square827()

    square828()

    square829()

    square830()

    square831()

    square832()

    square833()

    square834()

    square835()

    square836()

    square837()

    square838()

    square839()

    square840()

    square841()

    square842()

    square843()

    square844()

    square845()

    square846()

    square847()

    square848()

    square849()

    square850()

    square851()

    square852()

    square853()

    square854()

    square855()

    square856()

    square857()

    square858()

    square859()

    square860()

    square861()

    square862()

    square863()

    square864()

    square865()

    square866()

    square867()

    square868()

    square869()

    square870()

    square871()

    square872()

    square873()

    square874()

    square875()

    square876()

    square877()

    square878()

    square879()

    square880()

    square881()

    square882()

    square883()

    square884()

    square885()

    square886()

    square887()

    square888()

    square889()

    square890()

    square891()

    square892()

    square893()

    square894()

    square895()

    square896()

    square897()

    square898()

    square899()

    square900()

    square901()

    square902()

    square903()

    square904()

    square905()

    square906()

    square907()

    square908()

    square909()

    square910()

    square911()

    square912()

    square913()

    square914()

    square915()

    square916()

    square917()

    square918()

    square919()

    square920()

    square921()

    square922()

    square923()

    square924()

    square925()

    square926()

    square927()

    square928()

    square929()

    square930()

    square931()

    square932()

    square933()

    square934()

    square935()

    square936()

    square937()

    square938()

    square939()

    square940()

    square941()

    square942()

    square943()

    square944()

    square945()

    square946()

    square947()

    square948()

    square949()

    square950()

    square951()

    square952()

    square953()

    square954()

    square955()

    square956()

    square957()

    square958()

    square959()

    square960()

    square961()

    square962()

    square963()

    square964()

    square965()

    square966()

    square967()

    square968()

    square969()

    square970()

    square971()

    square972()

    square973()

    square974()

    square975()

    square976()

    square977()

    square978()

    square979()

    square980()

    square981()

    square982()

    square983()

    square984()

    square985()

    square986()

    square987()

    square988()

    square989()

    square990()

    square991()

    square992()

    square993()

    square994()

    square995()

    square996()

    square997()

    square998()

    square999()

    square1000()

    square1001()

    square1002()

    square1003()

    square1004()

    square1005()

    square1006()

    square1007()

    square1008()

    square1009()

    square1010()

    square1011()

    square1012()

    square1013()

    square1014()

    square1015()

    square1016()

    square1017()

    square1018()

    square1019()

    square1020()

    square1021()

    square1022()

    square1023()

    square1024()

    square1025()

    square1026()

    square1027()

    square1028()

    square1029()

    square1030()

    square1031()

    square1032()

    square1033()

    square1034()

    square1035()

    square1036()

    square1037()

    square1038()

    square1039()

    square1040()

    square1041()

    square1042()

    square1043()

    square1044()

    square1045()

    square1046()

    square1047()

    square1048()

    square1049()

    square1050()

    square1051()

    square1052()

    square1053()

    square1054()

    square1055()

    square1056()

    square1057()

    square1058()

    square1059()

    square1060()

    square1061()

    square1062()

    square1063()

    square1064()

    square1065()

    square1066()

    square1067()

    square1068()

    square1069()

    square1070()

    square1071()

    square1072()

    square1073()

    square1074()

    square1075()

    square1076()

    square1077()

    square1078()

    square1079()

    square1080()

    square1081()

    square1082()

    square1083()

    square1084()

    square1085()

    square1086()

    square1087()

    square1088()

    square1089()

    square1090()

    square1091()

    square1092()

    square1093()

    square1094()

    square1095()

    square1096()

    square1097()

    square1098()

    square1099()

    square1100()

    square1101()

    square1102()

    square1103()

    square1104()

    square1105()

    square1106()

    square1107()

    square1108()

    square1109()

    square1110()

    square1111()

    square1112()

    square1113()

    square1114()

    square1115()

    square1116()

    square1117()

    square1118()

    square1119()

    square1120()

    square1121()

    square1122()

    square1123()

    square1124()

    square1125()

    square1126()

    square1127()

    square1128()

    square1129()

    square1130()

    square1131()

    square1132()

    square1133()

    square1134()

    square1135()

    square1136()

    square1137()

    square1138()

    square1139()

    square1140()

    square1141()

    square1142()

    square1143()

    square1144()

    square1145()

    square1146()

    square1147()

    square1148()

    square1149()

    square1150()

    square1151()

    square1152()

    square1153()

    square1154()

    square1155()

    square1156()

    square1157()

    square1158()

    square1159()

    square1160()

    square1161()

    square1162()

    square1163()

    square1164()

    square1165()

    square1166()

    square1167()

    square1168()

    square1169()

    square1170()

    square1171()

    square1172()

    square1173()

    square1174()

    square1175()

    square1176()

    square1177()

    square1178()

    square1179()

    square1180()

    square1181()

    square1182()

    square1183()

    square1184()

    square1185()

    square1186()

    square1187()

    square1188()

    square1189()

    square1190()

    square1191()

    square1192()

    square1193()

    square1194()

    square1195()

    square1196()

    square1197()

    square1198()

    square1199()

    square1200()

    square1201()

    square1202()

    square1203()

    square1204()

    square1205()

    square1206()

    square1207()

    square1208()

    square1209()

    square1210()

    square1211()

    square1212()

    square1213()

    square1214()

    square1215()

    square1216()

    square1217()

    square1218()

    square1219()

    square1220()

    square1221()

    square1222()

    square1223()

    square1224()

    square1225()

    square1226()

    square1227()

    square1228()

    square1229()

    square1230()

    square1231()

    square1232()

    square1233()

    square1234()

    square1235()

    square1236()

    square1237()

    square1238()

    square1239()

    square1240()

    square1241()

    square1242()

    square1243()

    square1244()

    square1245()

    square1246()

    square1247()

    square1248()

    square1249()

    square1250()

    square1251()

    square1252()

    square1253()

    square1254()

    square1255()

    square1256()

    square1257()

    square1258()

    square1259()

    square1260()

    square1261()

    square1262()

    square1263()

    square1264()

    square1265()

    square1266()

    square1267()

    square1268()

    square1269()

    square1270()

    square1271()

    square1272()

    square1273()

    square1274()

    square1275()

    square1276()

    square1277()

    square1278()

    square1279()

    square1280()

    square1281()

    square1282()

    square1283()

    square1284()

    square1285()

    square1286()

    square1287()

    square1288()

    square1289()

    square1290()

    square1291()

    square1292()

    square1293()

    square1294()

    square1295()

    square1296()

    square1297()

    square1298()

    square1299()

    square1300()

    square1301()

    square1302()

    square1303()

    square1304()

    square1305()

    square1306()

    square1307()

    square1308()

    square1309()

    square1310()

    square1311()

    square1312()

    square1313()

    square1314()

    square1315()

    square1316()

    square1317()

    square1318()

    square1319()

    square1320()

    square1321()

    square1322()

    square1323()

    square1324()

    square1325()

    square1326()

    square1327()

    square1328()

    square1329()

    square1330()

    square1331()

    square1332()

    square1333()

    square1334()

    square1335()

    square1336()

    square1337()

    square1338()

    square1339()

    square1340()

    square1341()

    square1342()

    square1343()

    square1344()

    square1345()

    square1346()

    square1347()

    square1348()

    square1349()

    square1350()

    square1351()

    square1352()

    square1353()

    square1354()

    square1355()

    square1356()

    square1357()

    square1358()

    square1359()

    square1360()

    square1361()

    square1362()

    square1363()

    square1364()

    square1365()

    square1366()

    square1367()

    square1368()

    square1369()

    square1370()

    square1371()

    square1372()

    square1373()

    square1374()

    square1375()

    square1376()

    square1377()

    square1378()

    square1379()

    square1380()

    square1381()

    square1382()

    square1383()

    square1384()

    square1385()

    square1386()

    square1387()

    square1388()

    square1389()

    square1390()

    square1391()

    square1392()

    square1393()

    square1394()

    square1395()

    square1396()

    square1397()

    square1398()

    square1399()

    square1400()

    square1401()

    square1402()

    square1403()

    square1404()

    square1405()

    square1406()

    square1407()

    square1408()

    square1409()

    square1410()

    square1411()

    square1412()

    square1413()

    square1414()

    square1415()

    square1416()

    square1417()

    square1418()

    square1419()

    square1420()

    square1421()

    square1422()

    square1423()

    square1424()

    square1425()

    square1426()

    square1427()

    square1428()

    square1429()

    square1430()

    square1431()

    square1432()

    square1433()

    square1434()

    square1435()

    square1436()

    square1437()

    square1438()

    square1439()

    square1440()

    square1441()

    square1442()

    square1443()

    square1444()

    square1445()

    square1446()

    square1447()

    square1448()

    square1449()

    square1450()

    square1451()

    square1452()

    square1453()

    square1454()

    square1455()

    square1456()

    square1457()

    square1458()

    square1459()

    square1460()

    square1461()

    square1462()

    square1463()

    square1464()

    square1465()

    square1466()

    square1467()

    square1468()

    square1469()

    square1470()

    square1471()

    square1472()

    square1473()

    square1474()

    square1475()

    square1476()

    square1477()

    square1478()

    square1479()

    square1480()

    square1481()

    square1482()

    square1483()

    square1484()

    square1485()

    square1486()

    square1487()

    square1488()

    square1489()

    square1490()

    square1491()

    square1492()

    square1493()

    square1494()

    square1495()

    square1496()

    square1497()

    square1498()

    square1499()

    square1500()

    square1501()

    square1502()

    square1503()

    square1504()

    square1505()

    square1506()

    square1507()

    square1508()

    square1509()

    square1510()

    square1511()

    square1512()

    square1513()

    square1514()

    square1515()

    square1516()

    square1517()

    square1518()

    square1519()

    square1520()

    square1521()

    square1522()

    square1523()

    square1524()

    square1525()

    square1526()

    square1527()

    square1528()

    square1529()

    square1530()

    square1531()

    square1532()

    square1533()

    square1534()

    square1535()

    square1536()

    square1537()

    square1538()

    square1539()

    square1540()

    square1541()

    square1542()

    square1543()

    square1544()

    square1545()

    square1546()

    square1547()

    square1548()

    square1549()

    square1550()

    square1551()

    square1552()

    square1553()

    square1554()

    square1555()

    square1556()

    square1557()

    square1558()

    square1559()

    square1560()

    square1561()

    square1562()

    square1563()

    square1564()

    square1565()

    square1566()

    square1567()

    square1568()

    square1569()

    square1570()

    square1571()

    square1572()

    square1573()

    square1574()

    square1575()

    square1576()

    square1577()

    square1578()

    square1579()

    square1580()

    square1581()

    square1582()

    square1583()

    square1584()

    square1585()

    square1586()

    square1587()

    square1588()

    square1589()

    square1590()

    square1591()

    square1592()

    square1593()

    square1594()

    square1595()

    square1596()

    square1597()

    square1598()

    square1599()

    square1600()

    square1601()

    square1602()

    square1603()

    square1604()

    square1605()

    square1606()

    square1607()

    square1608()

    square1609()

    square1610()

    square1611()

    square1612()

    square1613()

    square1614()

    square1615()

    square1616()

    square1617()

    square1618()

    square1619()

    square1620()

    square1621()

    square1622()

    square1623()

    square1624()

    square1625()

    square1626()

    square1627()

    square1628()

    square1629()

    square1630()

    square1631()

    square1632()

    square1633()

    square1634()

    square1635()

    square1636()

    square1637()

    square1638()

    square1639()

    square1640()

    square1641()

    square1642()

    square1643()

    square1644()

    square1645()

    square1646()

    square1647()

    square1648()

    square1649()

    square1650()

    square1651()

    square1652()

    square1653()

    square1654()

    square1655()

    square1656()

    square1657()

    square1658()

    square1659()

    square1660()

    square1661()

    square1662()

    square1663()

    square1664()

    square1665()

    square1666()

    square1667()

    square1668()

    square1669()

    square1670()

    square1671()

    square1672()

    square1673()

    square1674()

    square1675()

    square1676()

    square1677()

    square1678()

    square1679()

    square1680()

    square1681()

    square1682()

    square1683()

    square1684()

    square1685()

    square1686()

    square1687()

    square1688()

    square1689()

    square1690()

    square1691()

    square1692()

    square1693()

    square1694()

    square1695()

    square1696()

    square1697()

    square1698()

    square1699()

    square1700()

    square1701()

    square1702()

    square1703()

    square1704()

    square1705()

    square1706()

    square1707()

    square1708()

    square1709()

    square1710()

    square1711()

    square1712()

    square1713()

    square1714()

    square1715()

    square1716()

    square1717()

    square1718()

    square1719()

    square1720()

    square1721()

    square1722()

    square1723()

    square1724()

    square1725()

    square1726()

    square1727()

    square1728()

    square1729()

    square1730()

    square1731()

    square1732()

    square1733()

    square1734()

    square1735()

    square1736()

    square1737()

    square1738()

    square1739()

    square1740()

    square1741()

    square1742()

    square1743()

    square1744()

    square1745()

    square1746()

    square1747()

    square1748()

    square1749()

    square1750()

    square1751()

    square1752()

    square1753()

    square1754()

    square1755()

    square1756()

    square1757()

    square1758()

    square1759()

    square1760()

    square1761()

    square1762()

    square1763()

    square1764()

    square1765()

    square1766()

    square1767()

    square1768()

    square1769()

    square1770()

    square1771()

    square1772()

    square1773()

    square1774()

    square1775()

    square1776()

    square1777()

    square1778()

    square1779()

    square1780()

    square1781()

    square1782()

    square1783()

    square1784()

    square1785()

    square1786()

    square1787()

    square1788()

    square1789()

    square1790()

    square1791()

    square1792()

    square1793()

    square1794()

    square1795()

    square1796()

    square1797()

    square1798()

    square1799()

    square1800()

    square1801()

    square1802()

    square1803()

    square1804()

    square1805()

    square1806()

    square1807()

    square1808()

    square1809()

    square1810()

    square1811()

    square1812()

    square1813()

    square1814()

    square1815()

    square1816()

    square1817()

    square1818()

    square1819()

    square1820()

    square1821()

    square1822()

    square1823()

    square1824()

    square1825()

    square1826()

    square1827()

    square1828()

    square1829()

    square1830()

    square1831()

    square1832()

    square1833()

    square1834()

    square1835()

    square1836()

    square1837()

    square1838()

    square1839()

    square1840()

    square1841()

    square1842()

    square1843()

    square1844()

    square1845()

    square1846()

    square1847()

    square1848()

    square1849()

    square1850()

    square1851()

    square1852()

    square1853()

    square1854()

    square1855()

    square1856()

    square1857()

    square1858()

    square1859()

    square1860()

    square1861()

    square1862()

    square1863()

    square1864()

    square1865()

    square1866()

    square1867()

    square1868()

    square1869()

    square1870()

    square1871()

    square1872()

    square1873()

    square1874()

    square1875()

    square1876()

    square1877()

    square1878()

    square1879()

    square1880()

    square1881()

    square1882()

    square1883()

    square1884()

    square1885()

    square1886()

    square1887()

    square1888()

    square1889()

    square1890()

    square1891()

    square1892()

    square1893()

    square1894()

    square1895()

    square1896()

    square1897()

    square1898()

    square1899()

    square1900()

    square1901()

    square1902()

    square1903()

    square1904()

    square1905()

    square1906()

    square1907()

    square1908()

    square1909()

    square1910()

    square1911()

    square1912()

    square1913()

    square1914()

    square1915()

    square1916()

    square1917()

    square1918()

    square1919()

    square1920()

    square1921()

    square1922()

    square1923()

    square1924()

    square1925()

    square1926()

    square1927()

    square1928()

    square1929()

    square1930()

    square1931()

    square1932()

    square1933()

    square1934()

    square1935()

    square1936()

    square1937()

    square1938()

    square1939()

    square1940()

    square1941()

    square1942()

    square1943()

    square1944()

    square1945()

    square1946()

    square1947()

    square1948()

    square1949()

    square1950()

    square1951()

    square1952()

    square1953()

    square1954()

    square1955()

    square1956()

    square1957()

    square1958()

    square1959()

    square1960()

    square1961()

    square1962()

    square1963()

    square1964()

    square1965()

    square1966()

    square1967()

    square1968()

    square1969()

    square1970()

    square1971()

    square1972()

    square1973()

    square1974()

    square1975()

    square1976()

    square1977()

    square1978()

    square1979()

    square1980()

    square1981()

    square1982()

    square1983()

    square1984()

    square1985()

    square1986()

    square1987()

    square1988()

    square1989()

    square1990()

    square1991()

    square1992()

    square1993()

    square1994()

    square1995()

    square1996()

    square1997()

    square1998()

    square1999()

    square2000()

    square2001()

    square2002()

    square2003()

    square2004()

    square2005()

    square2006()

    square2007()

    square2008()

    square2009()

    square2010()

    square2011()

    square2012()

    square2013()

    square2014()

    square2015()

    square2016()

    square2017()

    square2018()

    square2019()

    square2020()

    square2021()

    square2022()

    square2023()

    square2024()

    square2025()

    alert("Your art has been saved locally, to your local browser storage.");
};

function squareToSzzZValue1(){
    value45Save = "zSqrArtSpecz1";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1").src = tripleZeroA;
};

function squareToSzzZValue2(){
    value45Save = "zSqrArtSpecz2";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs2").src = tripleZeroA;
};

function squareToSzzZValue3(){
    value45Save = "zSqrArtSpecz3";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs3").src = tripleZeroA;
};

function squareToSzzZValue4(){
    value45Save = "zSqrArtSpecz4";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs4").src = tripleZeroA;
};

function squareToSzzZValue5(){
    value45Save = "zSqrArtSpecz5";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs5").src = tripleZeroA;
};

function squareToSzzZValue6(){
    value45Save = "zSqrArtSpecz6";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs6").src = tripleZeroA;
};

function squareToSzzZValue7(){
    value45Save = "zSqrArtSpecz7";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs7").src = tripleZeroA;
};

function squareToSzzZValue8(){
    value45Save = "zSqrArtSpecz8";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs8").src = tripleZeroA;
};

function squareToSzzZValue9(){
    value45Save = "zSqrArtSpecz9";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs9").src = tripleZeroA;
};

function squareToSzzZValue10(){
    value45Save = "zSqrArtSpecz10";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs10").src = tripleZeroA;
};

function squareToSzzZValue11(){
    value45Save = "zSqrArtSpecz11";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs11").src = tripleZeroA;
};

function squareToSzzZValue12(){
    value45Save = "zSqrArtSpecz12";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs12").src = tripleZeroA;
};

function squareToSzzZValue13(){
    value45Save = "zSqrArtSpecz13";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs13").src = tripleZeroA;
};

function squareToSzzZValue14(){
    value45Save = "zSqrArtSpecz14";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs14").src = tripleZeroA;
};

function squareToSzzZValue15(){
    value45Save = "zSqrArtSpecz15";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs15").src = tripleZeroA;
};

function squareToSzzZValue16(){
    value45Save = "zSqrArtSpecz16";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs16").src = tripleZeroA;
};

function squareToSzzZValue17(){
    value45Save = "zSqrArtSpecz17";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs17").src = tripleZeroA;
};

function squareToSzzZValue18(){
    value45Save = "zSqrArtSpecz18";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs18").src = tripleZeroA;
};

function squareToSzzZValue19(){
    value45Save = "zSqrArtSpecz19";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs19").src = tripleZeroA;
};

function squareToSzzZValue20(){
    value45Save = "zSqrArtSpecz20";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs20").src = tripleZeroA;
};

function squareToSzzZValue21(){
    value45Save = "zSqrArtSpecz21";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs21").src = tripleZeroA;
};

function squareToSzzZValue22(){
    value45Save = "zSqrArtSpecz22";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs22").src = tripleZeroA;
};

function squareToSzzZValue23(){
    value45Save = "zSqrArtSpecz23";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs23").src = tripleZeroA;
};

function squareToSzzZValue24(){
    value45Save = "zSqrArtSpecz24";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs24").src = tripleZeroA;
};

function squareToSzzZValue25(){
    value45Save = "zSqrArtSpecz25";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs25").src = tripleZeroA;
};

function squareToSzzZValue26(){
    value45Save = "zSqrArtSpecz26";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs26").src = tripleZeroA;
};

function squareToSzzZValue27(){
    value45Save = "zSqrArtSpecz27";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs27").src = tripleZeroA;
};

function squareToSzzZValue28(){
    value45Save = "zSqrArtSpecz28";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs28").src = tripleZeroA;
};

function squareToSzzZValue29(){
    value45Save = "zSqrArtSpecz29";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs29").src = tripleZeroA;
};

function squareToSzzZValue30(){
    value45Save = "zSqrArtSpecz30";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs30").src = tripleZeroA;
};

function squareToSzzZValue31(){
    value45Save = "zSqrArtSpecz31";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs31").src = tripleZeroA;
};

function squareToSzzZValue32(){
    value45Save = "zSqrArtSpecz32";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs32").src = tripleZeroA;
};

function squareToSzzZValue33(){
    value45Save = "zSqrArtSpecz33";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs33").src = tripleZeroA;
};

function squareToSzzZValue34(){
    value45Save = "zSqrArtSpecz34";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs34").src = tripleZeroA;
};

function squareToSzzZValue35(){
    value45Save = "zSqrArtSpecz35";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs35").src = tripleZeroA;
};

function squareToSzzZValue36(){
    value45Save = "zSqrArtSpecz36";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs36").src = tripleZeroA;
};

function squareToSzzZValue37(){
    value45Save = "zSqrArtSpecz37";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs37").src = tripleZeroA;
};

function squareToSzzZValue38(){
    value45Save = "zSqrArtSpecz38";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs38").src = tripleZeroA;
};

function squareToSzzZValue39(){
    value45Save = "zSqrArtSpecz39";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs39").src = tripleZeroA;
};

function squareToSzzZValue40(){
    value45Save = "zSqrArtSpecz40";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs40").src = tripleZeroA;
};

function squareToSzzZValue41(){
    value45Save = "zSqrArtSpecz41";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs41").src = tripleZeroA;
};

function squareToSzzZValue42(){
    value45Save = "zSqrArtSpecz42";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs42").src = tripleZeroA;
};

function squareToSzzZValue43(){
    value45Save = "zSqrArtSpecz43";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs43").src = tripleZeroA;
};

function squareToSzzZValue44(){
    value45Save = "zSqrArtSpecz44";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs44").src = tripleZeroA;
};

function squareToSzzZValue45(){
    value45Save = "zSqrArtSpecz45";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs45").src = tripleZeroA;
};

function squareToSzzZValue46(){
    value45Save = "zSqrArtSpecz46";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs46").src = tripleZeroA;
};

function squareToSzzZValue47(){
    value45Save = "zSqrArtSpecz47";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs47").src = tripleZeroA;
};

function squareToSzzZValue48(){
    value45Save = "zSqrArtSpecz48";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs48").src = tripleZeroA;
};

function squareToSzzZValue49(){
    value45Save = "zSqrArtSpecz49";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs49").src = tripleZeroA;
};

function squareToSzzZValue50(){
    value45Save = "zSqrArtSpecz50";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs50").src = tripleZeroA;
};

function squareToSzzZValue51(){
    value45Save = "zSqrArtSpecz51";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs51").src = tripleZeroA;
};

function squareToSzzZValue52(){
    value45Save = "zSqrArtSpecz52";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs52").src = tripleZeroA;
};

function squareToSzzZValue53(){
    value45Save = "zSqrArtSpecz53";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs53").src = tripleZeroA;
};

function squareToSzzZValue54(){
    value45Save = "zSqrArtSpecz54";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs54").src = tripleZeroA;
};

function squareToSzzZValue55(){
    value45Save = "zSqrArtSpecz55";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs55").src = tripleZeroA;
};

function squareToSzzZValue56(){
    value45Save = "zSqrArtSpecz56";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs56").src = tripleZeroA;
};

function squareToSzzZValue57(){
    value45Save = "zSqrArtSpecz57";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs57").src = tripleZeroA;
};

function squareToSzzZValue58(){
    value45Save = "zSqrArtSpecz58";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs58").src = tripleZeroA;
};

function squareToSzzZValue59(){
    value45Save = "zSqrArtSpecz59";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs59").src = tripleZeroA;
};

function squareToSzzZValue60(){
    value45Save = "zSqrArtSpecz60";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs60").src = tripleZeroA;
};

function squareToSzzZValue61(){
    value45Save = "zSqrArtSpecz61";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs61").src = tripleZeroA;
};

function squareToSzzZValue62(){
    value45Save = "zSqrArtSpecz62";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs62").src = tripleZeroA;
};

function squareToSzzZValue63(){
    value45Save = "zSqrArtSpecz63";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs63").src = tripleZeroA;
};

function squareToSzzZValue64(){
    value45Save = "zSqrArtSpecz64";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs64").src = tripleZeroA;
};

function squareToSzzZValue65(){
    value45Save = "zSqrArtSpecz65";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs65").src = tripleZeroA;
};

function squareToSzzZValue66(){
    value45Save = "zSqrArtSpecz66";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs66").src = tripleZeroA;
};

function squareToSzzZValue67(){
    value45Save = "zSqrArtSpecz67";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs67").src = tripleZeroA;
};

function squareToSzzZValue68(){
    value45Save = "zSqrArtSpecz68";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs68").src = tripleZeroA;
};

function squareToSzzZValue69(){
    value45Save = "zSqrArtSpecz69";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs69").src = tripleZeroA;
};

function squareToSzzZValue70(){
    value45Save = "zSqrArtSpecz70";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs70").src = tripleZeroA;
};

function squareToSzzZValue71(){
    value45Save = "zSqrArtSpecz71";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs71").src = tripleZeroA;
};

function squareToSzzZValue72(){
    value45Save = "zSqrArtSpecz72";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs72").src = tripleZeroA;
};

function squareToSzzZValue73(){
    value45Save = "zSqrArtSpecz73";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs73").src = tripleZeroA;
};

function squareToSzzZValue74(){
    value45Save = "zSqrArtSpecz74";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs74").src = tripleZeroA;
};

function squareToSzzZValue75(){
    value45Save = "zSqrArtSpecz75";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs75").src = tripleZeroA;
};

function squareToSzzZValue76(){
    value45Save = "zSqrArtSpecz76";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs76").src = tripleZeroA;
};

function squareToSzzZValue77(){
    value45Save = "zSqrArtSpecz77";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs77").src = tripleZeroA;
};

function squareToSzzZValue78(){
    value45Save = "zSqrArtSpecz78";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs78").src = tripleZeroA;
};

function squareToSzzZValue79(){
    value45Save = "zSqrArtSpecz79";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs79").src = tripleZeroA;
};

function squareToSzzZValue80(){
    value45Save = "zSqrArtSpecz80";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs80").src = tripleZeroA;
};

function squareToSzzZValue81(){
    value45Save = "zSqrArtSpecz81";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs81").src = tripleZeroA;
};

function squareToSzzZValue82(){
    value45Save = "zSqrArtSpecz82";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs82").src = tripleZeroA;
};

function squareToSzzZValue83(){
    value45Save = "zSqrArtSpecz83";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs83").src = tripleZeroA;
};

function squareToSzzZValue84(){
    value45Save = "zSqrArtSpecz84";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs84").src = tripleZeroA;
};

function squareToSzzZValue85(){
    value45Save = "zSqrArtSpecz85";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs85").src = tripleZeroA;
};

function squareToSzzZValue86(){
    value45Save = "zSqrArtSpecz86";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs86").src = tripleZeroA;
};

function squareToSzzZValue87(){
    value45Save = "zSqrArtSpecz87";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs87").src = tripleZeroA;
};

function squareToSzzZValue88(){
    value45Save = "zSqrArtSpecz88";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs88").src = tripleZeroA;
};

function squareToSzzZValue89(){
    value45Save = "zSqrArtSpecz89";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs89").src = tripleZeroA;
};

function squareToSzzZValue90(){
    value45Save = "zSqrArtSpecz90";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs90").src = tripleZeroA;
};

function squareToSzzZValue91(){
    value45Save = "zSqrArtSpecz91";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs91").src = tripleZeroA;
};

function squareToSzzZValue92(){
    value45Save = "zSqrArtSpecz92";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs92").src = tripleZeroA;
};

function squareToSzzZValue93(){
    value45Save = "zSqrArtSpecz93";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs93").src = tripleZeroA;
};

function squareToSzzZValue94(){
    value45Save = "zSqrArtSpecz94";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs94").src = tripleZeroA;
};

function squareToSzzZValue95(){
    value45Save = "zSqrArtSpecz95";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs95").src = tripleZeroA;
};

function squareToSzzZValue96(){
    value45Save = "zSqrArtSpecz96";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs96").src = tripleZeroA;
};

function squareToSzzZValue97(){
    value45Save = "zSqrArtSpecz97";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs97").src = tripleZeroA;
};

function squareToSzzZValue98(){
    value45Save = "zSqrArtSpecz98";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs98").src = tripleZeroA;
};

function squareToSzzZValue99(){
    value45Save = "zSqrArtSpecz99";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs99").src = tripleZeroA;
};

function squareToSzzZValue100(){
    value45Save = "zSqrArtSpecz100";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs100").src = tripleZeroA;
};

function squareToSzzZValue101(){
    value45Save = "zSqrArtSpecz101";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs101").src = tripleZeroA;
};

function squareToSzzZValue102(){
    value45Save = "zSqrArtSpecz102";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs102").src = tripleZeroA;
};

function squareToSzzZValue103(){
    value45Save = "zSqrArtSpecz103";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs103").src = tripleZeroA;
};

function squareToSzzZValue104(){
    value45Save = "zSqrArtSpecz104";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs104").src = tripleZeroA;
};

function squareToSzzZValue105(){
    value45Save = "zSqrArtSpecz105";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs105").src = tripleZeroA;
};

function squareToSzzZValue106(){
    value45Save = "zSqrArtSpecz106";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs106").src = tripleZeroA;
};

function squareToSzzZValue107(){
    value45Save = "zSqrArtSpecz107";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs107").src = tripleZeroA;
};

function squareToSzzZValue108(){
    value45Save = "zSqrArtSpecz108";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs108").src = tripleZeroA;
};

function squareToSzzZValue109(){
    value45Save = "zSqrArtSpecz109";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs109").src = tripleZeroA;
};

function squareToSzzZValue110(){
    value45Save = "zSqrArtSpecz110";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs110").src = tripleZeroA;
};

function squareToSzzZValue111(){
    value45Save = "zSqrArtSpecz111";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs111").src = tripleZeroA;
};

function squareToSzzZValue112(){
    value45Save = "zSqrArtSpecz112";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs112").src = tripleZeroA;
};

function squareToSzzZValue113(){
    value45Save = "zSqrArtSpecz113";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs113").src = tripleZeroA;
};

function squareToSzzZValue114(){
    value45Save = "zSqrArtSpecz114";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs114").src = tripleZeroA;
};

function squareToSzzZValue115(){
    value45Save = "zSqrArtSpecz115";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs115").src = tripleZeroA;
};

function squareToSzzZValue116(){
    value45Save = "zSqrArtSpecz116";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs116").src = tripleZeroA;
};

function squareToSzzZValue117(){
    value45Save = "zSqrArtSpecz117";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs117").src = tripleZeroA;
};

function squareToSzzZValue118(){
    value45Save = "zSqrArtSpecz118";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs118").src = tripleZeroA;
};

function squareToSzzZValue119(){
    value45Save = "zSqrArtSpecz119";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs119").src = tripleZeroA;
};

function squareToSzzZValue120(){
    value45Save = "zSqrArtSpecz120";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs120").src = tripleZeroA;
};

function squareToSzzZValue121(){
    value45Save = "zSqrArtSpecz121";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs121").src = tripleZeroA;
};

function squareToSzzZValue122(){
    value45Save = "zSqrArtSpecz122";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs122").src = tripleZeroA;
};

function squareToSzzZValue123(){
    value45Save = "zSqrArtSpecz123";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs123").src = tripleZeroA;
};

function squareToSzzZValue124(){
    value45Save = "zSqrArtSpecz124";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs124").src = tripleZeroA;
};

function squareToSzzZValue125(){
    value45Save = "zSqrArtSpecz125";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs125").src = tripleZeroA;
};

function squareToSzzZValue126(){
    value45Save = "zSqrArtSpecz126";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs126").src = tripleZeroA;
};

function squareToSzzZValue127(){
    value45Save = "zSqrArtSpecz127";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs127").src = tripleZeroA;
};

function squareToSzzZValue128(){
    value45Save = "zSqrArtSpecz128";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs128").src = tripleZeroA;
};

function squareToSzzZValue129(){
    value45Save = "zSqrArtSpecz129";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs129").src = tripleZeroA;
};

function squareToSzzZValue130(){
    value45Save = "zSqrArtSpecz130";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs130").src = tripleZeroA;
};

function squareToSzzZValue131(){
    value45Save = "zSqrArtSpecz131";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs131").src = tripleZeroA;
};

function squareToSzzZValue132(){
    value45Save = "zSqrArtSpecz132";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs132").src = tripleZeroA;
};

function squareToSzzZValue133(){
    value45Save = "zSqrArtSpecz133";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs133").src = tripleZeroA;
};

function squareToSzzZValue134(){
    value45Save = "zSqrArtSpecz134";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs134").src = tripleZeroA;
};

function squareToSzzZValue135(){
    value45Save = "zSqrArtSpecz135";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs135").src = tripleZeroA;
};

function squareToSzzZValue136(){
    value45Save = "zSqrArtSpecz136";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs136").src = tripleZeroA;
};

function squareToSzzZValue137(){
    value45Save = "zSqrArtSpecz137";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs137").src = tripleZeroA;
};

function squareToSzzZValue138(){
    value45Save = "zSqrArtSpecz138";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs138").src = tripleZeroA;
};

function squareToSzzZValue139(){
    value45Save = "zSqrArtSpecz139";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs139").src = tripleZeroA;
};

function squareToSzzZValue140(){
    value45Save = "zSqrArtSpecz140";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs140").src = tripleZeroA;
};

function squareToSzzZValue141(){
    value45Save = "zSqrArtSpecz141";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs141").src = tripleZeroA;
};

function squareToSzzZValue142(){
    value45Save = "zSqrArtSpecz142";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs142").src = tripleZeroA;
};

function squareToSzzZValue143(){
    value45Save = "zSqrArtSpecz143";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs143").src = tripleZeroA;
};

function squareToSzzZValue144(){
    value45Save = "zSqrArtSpecz144";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs144").src = tripleZeroA;
};

function squareToSzzZValue145(){
    value45Save = "zSqrArtSpecz145";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs145").src = tripleZeroA;
};

function squareToSzzZValue146(){
    value45Save = "zSqrArtSpecz146";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs146").src = tripleZeroA;
};

function squareToSzzZValue147(){
    value45Save = "zSqrArtSpecz147";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs147").src = tripleZeroA;
};

function squareToSzzZValue148(){
    value45Save = "zSqrArtSpecz148";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs148").src = tripleZeroA;
};

function squareToSzzZValue149(){
    value45Save = "zSqrArtSpecz149";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs149").src = tripleZeroA;
};

function squareToSzzZValue150(){
    value45Save = "zSqrArtSpecz150";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs150").src = tripleZeroA;
};

function squareToSzzZValue151(){
    value45Save = "zSqrArtSpecz151";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs151").src = tripleZeroA;
};

function squareToSzzZValue152(){
    value45Save = "zSqrArtSpecz152";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs152").src = tripleZeroA;
};

function squareToSzzZValue153(){
    value45Save = "zSqrArtSpecz153";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs153").src = tripleZeroA;
};

function squareToSzzZValue154(){
    value45Save = "zSqrArtSpecz154";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs154").src = tripleZeroA;
};

function squareToSzzZValue155(){
    value45Save = "zSqrArtSpecz155";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs155").src = tripleZeroA;
};

function squareToSzzZValue156(){
    value45Save = "zSqrArtSpecz156";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs156").src = tripleZeroA;
};

function squareToSzzZValue157(){
    value45Save = "zSqrArtSpecz157";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs157").src = tripleZeroA;
};

function squareToSzzZValue158(){
    value45Save = "zSqrArtSpecz158";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs158").src = tripleZeroA;
};

function squareToSzzZValue159(){
    value45Save = "zSqrArtSpecz159";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs159").src = tripleZeroA;
};

function squareToSzzZValue160(){
    value45Save = "zSqrArtSpecz160";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs160").src = tripleZeroA;
};

function squareToSzzZValue161(){
    value45Save = "zSqrArtSpecz161";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs161").src = tripleZeroA;
};

function squareToSzzZValue162(){
    value45Save = "zSqrArtSpecz162";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs162").src = tripleZeroA;
};

function squareToSzzZValue163(){
    value45Save = "zSqrArtSpecz163";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs163").src = tripleZeroA;
};

function squareToSzzZValue164(){
    value45Save = "zSqrArtSpecz164";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs164").src = tripleZeroA;
};

function squareToSzzZValue165(){
    value45Save = "zSqrArtSpecz165";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs165").src = tripleZeroA;
};

function squareToSzzZValue166(){
    value45Save = "zSqrArtSpecz166";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs166").src = tripleZeroA;
};

function squareToSzzZValue167(){
    value45Save = "zSqrArtSpecz167";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs167").src = tripleZeroA;
};

function squareToSzzZValue168(){
    value45Save = "zSqrArtSpecz168";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs168").src = tripleZeroA;
};

function squareToSzzZValue169(){
    value45Save = "zSqrArtSpecz169";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs169").src = tripleZeroA;
};

function squareToSzzZValue170(){
    value45Save = "zSqrArtSpecz170";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs170").src = tripleZeroA;
};

function squareToSzzZValue171(){
    value45Save = "zSqrArtSpecz171";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs171").src = tripleZeroA;
};

function squareToSzzZValue172(){
    value45Save = "zSqrArtSpecz172";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs172").src = tripleZeroA;
};

function squareToSzzZValue173(){
    value45Save = "zSqrArtSpecz173";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs173").src = tripleZeroA;
};

function squareToSzzZValue174(){
    value45Save = "zSqrArtSpecz174";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs174").src = tripleZeroA;
};

function squareToSzzZValue175(){
    value45Save = "zSqrArtSpecz175";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs175").src = tripleZeroA;
};

function squareToSzzZValue176(){
    value45Save = "zSqrArtSpecz176";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs176").src = tripleZeroA;
};

function squareToSzzZValue177(){
    value45Save = "zSqrArtSpecz177";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs177").src = tripleZeroA;
};

function squareToSzzZValue178(){
    value45Save = "zSqrArtSpecz178";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs178").src = tripleZeroA;
};

function squareToSzzZValue179(){
    value45Save = "zSqrArtSpecz179";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs179").src = tripleZeroA;
};

function squareToSzzZValue180(){
    value45Save = "zSqrArtSpecz180";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs180").src = tripleZeroA;
};

function squareToSzzZValue181(){
    value45Save = "zSqrArtSpecz181";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs181").src = tripleZeroA;
};

function squareToSzzZValue182(){
    value45Save = "zSqrArtSpecz182";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs182").src = tripleZeroA;
};

function squareToSzzZValue183(){
    value45Save = "zSqrArtSpecz183";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs183").src = tripleZeroA;
};

function squareToSzzZValue184(){
    value45Save = "zSqrArtSpecz184";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs184").src = tripleZeroA;
};

function squareToSzzZValue185(){
    value45Save = "zSqrArtSpecz185";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs185").src = tripleZeroA;
};

function squareToSzzZValue186(){
    value45Save = "zSqrArtSpecz186";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs186").src = tripleZeroA;
};

function squareToSzzZValue187(){
    value45Save = "zSqrArtSpecz187";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs187").src = tripleZeroA;
};

function squareToSzzZValue188(){
    value45Save = "zSqrArtSpecz188";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs188").src = tripleZeroA;
};

function squareToSzzZValue189(){
    value45Save = "zSqrArtSpecz189";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs189").src = tripleZeroA;
};

function squareToSzzZValue190(){
    value45Save = "zSqrArtSpecz190";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs190").src = tripleZeroA;
};

function squareToSzzZValue191(){
    value45Save = "zSqrArtSpecz191";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs191").src = tripleZeroA;
};

function squareToSzzZValue192(){
    value45Save = "zSqrArtSpecz192";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs192").src = tripleZeroA;
};

function squareToSzzZValue193(){
    value45Save = "zSqrArtSpecz193";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs193").src = tripleZeroA;
};

function squareToSzzZValue194(){
    value45Save = "zSqrArtSpecz194";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs194").src = tripleZeroA;
};

function squareToSzzZValue195(){
    value45Save = "zSqrArtSpecz195";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs195").src = tripleZeroA;
};

function squareToSzzZValue196(){
    value45Save = "zSqrArtSpecz196";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs196").src = tripleZeroA;
};

function squareToSzzZValue197(){
    value45Save = "zSqrArtSpecz197";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs197").src = tripleZeroA;
};

function squareToSzzZValue198(){
    value45Save = "zSqrArtSpecz198";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs198").src = tripleZeroA;
};

function squareToSzzZValue199(){
    value45Save = "zSqrArtSpecz199";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs199").src = tripleZeroA;
};

function squareToSzzZValue200(){
    value45Save = "zSqrArtSpecz200";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs200").src = tripleZeroA;
};

function squareToSzzZValue201(){
    value45Save = "zSqrArtSpecz201";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs201").src = tripleZeroA;
};

function squareToSzzZValue202(){
    value45Save = "zSqrArtSpecz202";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs202").src = tripleZeroA;
};

function squareToSzzZValue203(){
    value45Save = "zSqrArtSpecz203";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs203").src = tripleZeroA;
};

function squareToSzzZValue204(){
    value45Save = "zSqrArtSpecz204";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs204").src = tripleZeroA;
};

function squareToSzzZValue205(){
    value45Save = "zSqrArtSpecz205";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs205").src = tripleZeroA;
};

function squareToSzzZValue206(){
    value45Save = "zSqrArtSpecz206";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs206").src = tripleZeroA;
};

function squareToSzzZValue207(){
    value45Save = "zSqrArtSpecz207";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs207").src = tripleZeroA;
};

function squareToSzzZValue208(){
    value45Save = "zSqrArtSpecz208";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs208").src = tripleZeroA;
};

function squareToSzzZValue209(){
    value45Save = "zSqrArtSpecz209";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs209").src = tripleZeroA;
};

function squareToSzzZValue210(){
    value45Save = "zSqrArtSpecz210";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs210").src = tripleZeroA;
};

function squareToSzzZValue211(){
    value45Save = "zSqrArtSpecz211";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs211").src = tripleZeroA;
};

function squareToSzzZValue212(){
    value45Save = "zSqrArtSpecz212";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs212").src = tripleZeroA;
};

function squareToSzzZValue213(){
    value45Save = "zSqrArtSpecz213";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs213").src = tripleZeroA;
};

function squareToSzzZValue214(){
    value45Save = "zSqrArtSpecz214";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs214").src = tripleZeroA;
};

function squareToSzzZValue215(){
    value45Save = "zSqrArtSpecz215";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs215").src = tripleZeroA;
};

function squareToSzzZValue216(){
    value45Save = "zSqrArtSpecz216";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs216").src = tripleZeroA;
};

function squareToSzzZValue217(){
    value45Save = "zSqrArtSpecz217";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs217").src = tripleZeroA;
};

function squareToSzzZValue218(){
    value45Save = "zSqrArtSpecz218";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs218").src = tripleZeroA;
};

function squareToSzzZValue219(){
    value45Save = "zSqrArtSpecz219";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs219").src = tripleZeroA;
};

function squareToSzzZValue220(){
    value45Save = "zSqrArtSpecz220";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs220").src = tripleZeroA;
};

function squareToSzzZValue221(){
    value45Save = "zSqrArtSpecz221";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs221").src = tripleZeroA;
};

function squareToSzzZValue222(){
    value45Save = "zSqrArtSpecz222";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs222").src = tripleZeroA;
};

function squareToSzzZValue223(){
    value45Save = "zSqrArtSpecz223";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs223").src = tripleZeroA;
};

function squareToSzzZValue224(){
    value45Save = "zSqrArtSpecz224";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs224").src = tripleZeroA;
};

function squareToSzzZValue225(){
    value45Save = "zSqrArtSpecz225";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs225").src = tripleZeroA;
};

function squareToSzzZValue226(){
    value45Save = "zSqrArtSpecz226";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs226").src = tripleZeroA;
};

function squareToSzzZValue227(){
    value45Save = "zSqrArtSpecz227";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs227").src = tripleZeroA;
};

function squareToSzzZValue228(){
    value45Save = "zSqrArtSpecz228";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs228").src = tripleZeroA;
};

function squareToSzzZValue229(){
    value45Save = "zSqrArtSpecz229";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs229").src = tripleZeroA;
};

function squareToSzzZValue230(){
    value45Save = "zSqrArtSpecz230";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs230").src = tripleZeroA;
};

function squareToSzzZValue231(){
    value45Save = "zSqrArtSpecz231";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs231").src = tripleZeroA;
};

function squareToSzzZValue232(){
    value45Save = "zSqrArtSpecz232";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs232").src = tripleZeroA;
};

function squareToSzzZValue233(){
    value45Save = "zSqrArtSpecz233";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs233").src = tripleZeroA;
};

function squareToSzzZValue234(){
    value45Save = "zSqrArtSpecz234";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs234").src = tripleZeroA;
};

function squareToSzzZValue235(){
    value45Save = "zSqrArtSpecz235";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs235").src = tripleZeroA;
};

function squareToSzzZValue236(){
    value45Save = "zSqrArtSpecz236";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs236").src = tripleZeroA;
};

function squareToSzzZValue237(){
    value45Save = "zSqrArtSpecz237";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs237").src = tripleZeroA;
};

function squareToSzzZValue238(){
    value45Save = "zSqrArtSpecz238";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs238").src = tripleZeroA;
};

function squareToSzzZValue239(){
    value45Save = "zSqrArtSpecz239";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs239").src = tripleZeroA;
};

function squareToSzzZValue240(){
    value45Save = "zSqrArtSpecz240";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs240").src = tripleZeroA;
};

function squareToSzzZValue241(){
    value45Save = "zSqrArtSpecz241";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs241").src = tripleZeroA;
};

function squareToSzzZValue242(){
    value45Save = "zSqrArtSpecz242";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs242").src = tripleZeroA;
};

function squareToSzzZValue243(){
    value45Save = "zSqrArtSpecz243";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs243").src = tripleZeroA;
};

function squareToSzzZValue244(){
    value45Save = "zSqrArtSpecz244";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs244").src = tripleZeroA;
};

function squareToSzzZValue245(){
    value45Save = "zSqrArtSpecz245";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs245").src = tripleZeroA;
};

function squareToSzzZValue246(){
    value45Save = "zSqrArtSpecz246";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs246").src = tripleZeroA;
};

function squareToSzzZValue247(){
    value45Save = "zSqrArtSpecz247";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs247").src = tripleZeroA;
};

function squareToSzzZValue248(){
    value45Save = "zSqrArtSpecz248";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs248").src = tripleZeroA;
};

function squareToSzzZValue249(){
    value45Save = "zSqrArtSpecz249";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs249").src = tripleZeroA;
};

function squareToSzzZValue250(){
    value45Save = "zSqrArtSpecz250";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs250").src = tripleZeroA;
};

function squareToSzzZValue251(){
    value45Save = "zSqrArtSpecz251";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs251").src = tripleZeroA;
};

function squareToSzzZValue252(){
    value45Save = "zSqrArtSpecz252";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs252").src = tripleZeroA;
};

function squareToSzzZValue253(){
    value45Save = "zSqrArtSpecz253";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs253").src = tripleZeroA;
};

function squareToSzzZValue254(){
    value45Save = "zSqrArtSpecz254";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs254").src = tripleZeroA;
};

function squareToSzzZValue255(){
    value45Save = "zSqrArtSpecz255";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs255").src = tripleZeroA;
};

function squareToSzzZValue256(){
    value45Save = "zSqrArtSpecz256";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs256").src = tripleZeroA;
};

function squareToSzzZValue257(){
    value45Save = "zSqrArtSpecz257";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs257").src = tripleZeroA;
};

function squareToSzzZValue258(){
    value45Save = "zSqrArtSpecz258";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs258").src = tripleZeroA;
};

function squareToSzzZValue259(){
    value45Save = "zSqrArtSpecz259";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs259").src = tripleZeroA;
};

function squareToSzzZValue260(){
    value45Save = "zSqrArtSpecz260";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs260").src = tripleZeroA;
};

function squareToSzzZValue261(){
    value45Save = "zSqrArtSpecz261";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs261").src = tripleZeroA;
};

function squareToSzzZValue262(){
    value45Save = "zSqrArtSpecz262";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs262").src = tripleZeroA;
};

function squareToSzzZValue263(){
    value45Save = "zSqrArtSpecz263";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs263").src = tripleZeroA;
};

function squareToSzzZValue264(){
    value45Save = "zSqrArtSpecz264";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs264").src = tripleZeroA;
};

function squareToSzzZValue265(){
    value45Save = "zSqrArtSpecz265";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs265").src = tripleZeroA;
};

function squareToSzzZValue266(){
    value45Save = "zSqrArtSpecz266";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs266").src = tripleZeroA;
};

function squareToSzzZValue267(){
    value45Save = "zSqrArtSpecz267";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs267").src = tripleZeroA;
};

function squareToSzzZValue268(){
    value45Save = "zSqrArtSpecz268";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs268").src = tripleZeroA;
};

function squareToSzzZValue269(){
    value45Save = "zSqrArtSpecz269";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs269").src = tripleZeroA;
};

function squareToSzzZValue270(){
    value45Save = "zSqrArtSpecz270";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs270").src = tripleZeroA;
};

function squareToSzzZValue271(){
    value45Save = "zSqrArtSpecz271";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs271").src = tripleZeroA;
};

function squareToSzzZValue272(){
    value45Save = "zSqrArtSpecz272";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs272").src = tripleZeroA;
};

function squareToSzzZValue273(){
    value45Save = "zSqrArtSpecz273";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs273").src = tripleZeroA;
};

function squareToSzzZValue274(){
    value45Save = "zSqrArtSpecz274";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs274").src = tripleZeroA;
};

function squareToSzzZValue275(){
    value45Save = "zSqrArtSpecz275";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs275").src = tripleZeroA;
};

function squareToSzzZValue276(){
    value45Save = "zSqrArtSpecz276";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs276").src = tripleZeroA;
};

function squareToSzzZValue277(){
    value45Save = "zSqrArtSpecz277";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs277").src = tripleZeroA;
};

function squareToSzzZValue278(){
    value45Save = "zSqrArtSpecz278";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs278").src = tripleZeroA;
};

function squareToSzzZValue279(){
    value45Save = "zSqrArtSpecz279";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs279").src = tripleZeroA;
};

function squareToSzzZValue280(){
    value45Save = "zSqrArtSpecz280";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs280").src = tripleZeroA;
};

function squareToSzzZValue281(){
    value45Save = "zSqrArtSpecz281";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs281").src = tripleZeroA;
};

function squareToSzzZValue282(){
    value45Save = "zSqrArtSpecz282";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs282").src = tripleZeroA;
};

function squareToSzzZValue283(){
    value45Save = "zSqrArtSpecz283";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs283").src = tripleZeroA;
};

function squareToSzzZValue284(){
    value45Save = "zSqrArtSpecz284";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs284").src = tripleZeroA;
};

function squareToSzzZValue285(){
    value45Save = "zSqrArtSpecz285";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs285").src = tripleZeroA;
};

function squareToSzzZValue286(){
    value45Save = "zSqrArtSpecz286";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs286").src = tripleZeroA;
};

function squareToSzzZValue287(){
    value45Save = "zSqrArtSpecz287";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs287").src = tripleZeroA;
};

function squareToSzzZValue288(){
    value45Save = "zSqrArtSpecz288";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs288").src = tripleZeroA;
};

function squareToSzzZValue289(){
    value45Save = "zSqrArtSpecz289";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs289").src = tripleZeroA;
};

function squareToSzzZValue290(){
    value45Save = "zSqrArtSpecz290";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs290").src = tripleZeroA;
};

function squareToSzzZValue291(){
    value45Save = "zSqrArtSpecz291";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs291").src = tripleZeroA;
};

function squareToSzzZValue292(){
    value45Save = "zSqrArtSpecz292";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs292").src = tripleZeroA;
};

function squareToSzzZValue293(){
    value45Save = "zSqrArtSpecz293";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs293").src = tripleZeroA;
};

function squareToSzzZValue294(){
    value45Save = "zSqrArtSpecz294";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs294").src = tripleZeroA;
};

function squareToSzzZValue295(){
    value45Save = "zSqrArtSpecz295";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs295").src = tripleZeroA;
};

function squareToSzzZValue296(){
    value45Save = "zSqrArtSpecz296";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs296").src = tripleZeroA;
};

function squareToSzzZValue297(){
    value45Save = "zSqrArtSpecz297";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs297").src = tripleZeroA;
};

function squareToSzzZValue298(){
    value45Save = "zSqrArtSpecz298";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs298").src = tripleZeroA;
};

function squareToSzzZValue299(){
    value45Save = "zSqrArtSpecz299";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs299").src = tripleZeroA;
};

function squareToSzzZValue300(){
    value45Save = "zSqrArtSpecz300";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs300").src = tripleZeroA;
};

function squareToSzzZValue301(){
    value45Save = "zSqrArtSpecz301";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs301").src = tripleZeroA;
};

function squareToSzzZValue302(){
    value45Save = "zSqrArtSpecz302";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs302").src = tripleZeroA;
};

function squareToSzzZValue303(){
    value45Save = "zSqrArtSpecz303";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs303").src = tripleZeroA;
};

function squareToSzzZValue304(){
    value45Save = "zSqrArtSpecz304";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs304").src = tripleZeroA;
};

function squareToSzzZValue305(){
    value45Save = "zSqrArtSpecz305";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs305").src = tripleZeroA;
};

function squareToSzzZValue306(){
    value45Save = "zSqrArtSpecz306";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs306").src = tripleZeroA;
};

function squareToSzzZValue307(){
    value45Save = "zSqrArtSpecz307";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs307").src = tripleZeroA;
};

function squareToSzzZValue308(){
    value45Save = "zSqrArtSpecz308";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs308").src = tripleZeroA;
};

function squareToSzzZValue309(){
    value45Save = "zSqrArtSpecz309";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs309").src = tripleZeroA;
};

function squareToSzzZValue310(){
    value45Save = "zSqrArtSpecz310";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs310").src = tripleZeroA;
};

function squareToSzzZValue311(){
    value45Save = "zSqrArtSpecz311";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs311").src = tripleZeroA;
};

function squareToSzzZValue312(){
    value45Save = "zSqrArtSpecz312";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs312").src = tripleZeroA;
};

function squareToSzzZValue313(){
    value45Save = "zSqrArtSpecz313";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs313").src = tripleZeroA;
};

function squareToSzzZValue314(){
    value45Save = "zSqrArtSpecz314";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs314").src = tripleZeroA;
};

function squareToSzzZValue315(){
    value45Save = "zSqrArtSpecz315";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs315").src = tripleZeroA;
};

function squareToSzzZValue316(){
    value45Save = "zSqrArtSpecz316";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs316").src = tripleZeroA;
};

function squareToSzzZValue317(){
    value45Save = "zSqrArtSpecz317";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs317").src = tripleZeroA;
};

function squareToSzzZValue318(){
    value45Save = "zSqrArtSpecz318";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs318").src = tripleZeroA;
};

function squareToSzzZValue319(){
    value45Save = "zSqrArtSpecz319";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs319").src = tripleZeroA;
};

function squareToSzzZValue320(){
    value45Save = "zSqrArtSpecz320";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs320").src = tripleZeroA;
};

function squareToSzzZValue321(){
    value45Save = "zSqrArtSpecz321";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs321").src = tripleZeroA;
};

function squareToSzzZValue322(){
    value45Save = "zSqrArtSpecz322";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs322").src = tripleZeroA;
};

function squareToSzzZValue323(){
    value45Save = "zSqrArtSpecz323";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs323").src = tripleZeroA;
};

function squareToSzzZValue324(){
    value45Save = "zSqrArtSpecz324";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs324").src = tripleZeroA;
};

function squareToSzzZValue325(){
    value45Save = "zSqrArtSpecz325";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs325").src = tripleZeroA;
};

function squareToSzzZValue326(){
    value45Save = "zSqrArtSpecz326";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs326").src = tripleZeroA;
};

function squareToSzzZValue327(){
    value45Save = "zSqrArtSpecz327";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs327").src = tripleZeroA;
};

function squareToSzzZValue328(){
    value45Save = "zSqrArtSpecz328";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs328").src = tripleZeroA;
};

function squareToSzzZValue329(){
    value45Save = "zSqrArtSpecz329";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs329").src = tripleZeroA;
};

function squareToSzzZValue330(){
    value45Save = "zSqrArtSpecz330";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs330").src = tripleZeroA;
};

function squareToSzzZValue331(){
    value45Save = "zSqrArtSpecz331";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs331").src = tripleZeroA;
};

function squareToSzzZValue332(){
    value45Save = "zSqrArtSpecz332";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs332").src = tripleZeroA;
};

function squareToSzzZValue333(){
    value45Save = "zSqrArtSpecz333";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs333").src = tripleZeroA;
};

function squareToSzzZValue334(){
    value45Save = "zSqrArtSpecz334";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs334").src = tripleZeroA;
};

function squareToSzzZValue335(){
    value45Save = "zSqrArtSpecz335";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs335").src = tripleZeroA;
};

function squareToSzzZValue336(){
    value45Save = "zSqrArtSpecz336";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs336").src = tripleZeroA;
};

function squareToSzzZValue337(){
    value45Save = "zSqrArtSpecz337";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs337").src = tripleZeroA;
};

function squareToSzzZValue338(){
    value45Save = "zSqrArtSpecz338";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs338").src = tripleZeroA;
};

function squareToSzzZValue339(){
    value45Save = "zSqrArtSpecz339";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs339").src = tripleZeroA;
};

function squareToSzzZValue340(){
    value45Save = "zSqrArtSpecz340";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs340").src = tripleZeroA;
};

function squareToSzzZValue341(){
    value45Save = "zSqrArtSpecz341";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs341").src = tripleZeroA;
};

function squareToSzzZValue342(){
    value45Save = "zSqrArtSpecz342";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs342").src = tripleZeroA;
};

function squareToSzzZValue343(){
    value45Save = "zSqrArtSpecz343";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs343").src = tripleZeroA;
};

function squareToSzzZValue344(){
    value45Save = "zSqrArtSpecz344";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs344").src = tripleZeroA;
};

function squareToSzzZValue345(){
    value45Save = "zSqrArtSpecz345";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs345").src = tripleZeroA;
};

function squareToSzzZValue346(){
    value45Save = "zSqrArtSpecz346";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs346").src = tripleZeroA;
};

function squareToSzzZValue347(){
    value45Save = "zSqrArtSpecz347";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs347").src = tripleZeroA;
};

function squareToSzzZValue348(){
    value45Save = "zSqrArtSpecz348";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs348").src = tripleZeroA;
};

function squareToSzzZValue349(){
    value45Save = "zSqrArtSpecz349";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs349").src = tripleZeroA;
};

function squareToSzzZValue350(){
    value45Save = "zSqrArtSpecz350";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs350").src = tripleZeroA;
};

function squareToSzzZValue351(){
    value45Save = "zSqrArtSpecz351";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs351").src = tripleZeroA;
};

function squareToSzzZValue352(){
    value45Save = "zSqrArtSpecz352";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs352").src = tripleZeroA;
};

function squareToSzzZValue353(){
    value45Save = "zSqrArtSpecz353";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs353").src = tripleZeroA;
};

function squareToSzzZValue354(){
    value45Save = "zSqrArtSpecz354";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs354").src = tripleZeroA;
};

function squareToSzzZValue355(){
    value45Save = "zSqrArtSpecz355";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs355").src = tripleZeroA;
};

function squareToSzzZValue356(){
    value45Save = "zSqrArtSpecz356";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs356").src = tripleZeroA;
};

function squareToSzzZValue357(){
    value45Save = "zSqrArtSpecz357";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs357").src = tripleZeroA;
};

function squareToSzzZValue358(){
    value45Save = "zSqrArtSpecz358";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs358").src = tripleZeroA;
};

function squareToSzzZValue359(){
    value45Save = "zSqrArtSpecz359";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs359").src = tripleZeroA;
};

function squareToSzzZValue360(){
    value45Save = "zSqrArtSpecz360";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs360").src = tripleZeroA;
};

function squareToSzzZValue361(){
    value45Save = "zSqrArtSpecz361";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs361").src = tripleZeroA;
};

function squareToSzzZValue362(){
    value45Save = "zSqrArtSpecz362";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs362").src = tripleZeroA;
};

function squareToSzzZValue363(){
    value45Save = "zSqrArtSpecz363";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs363").src = tripleZeroA;
};

function squareToSzzZValue364(){
    value45Save = "zSqrArtSpecz364";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs364").src = tripleZeroA;
};

function squareToSzzZValue365(){
    value45Save = "zSqrArtSpecz365";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs365").src = tripleZeroA;
};

function squareToSzzZValue366(){
    value45Save = "zSqrArtSpecz366";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs366").src = tripleZeroA;
};

function squareToSzzZValue367(){
    value45Save = "zSqrArtSpecz367";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs367").src = tripleZeroA;
};

function squareToSzzZValue368(){
    value45Save = "zSqrArtSpecz368";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs368").src = tripleZeroA;
};

function squareToSzzZValue369(){
    value45Save = "zSqrArtSpecz369";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs369").src = tripleZeroA;
};

function squareToSzzZValue370(){
    value45Save = "zSqrArtSpecz370";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs370").src = tripleZeroA;
};

function squareToSzzZValue371(){
    value45Save = "zSqrArtSpecz371";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs371").src = tripleZeroA;
};

function squareToSzzZValue372(){
    value45Save = "zSqrArtSpecz372";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs372").src = tripleZeroA;
};

function squareToSzzZValue373(){
    value45Save = "zSqrArtSpecz373";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs373").src = tripleZeroA;
};

function squareToSzzZValue374(){
    value45Save = "zSqrArtSpecz374";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs374").src = tripleZeroA;
};

function squareToSzzZValue375(){
    value45Save = "zSqrArtSpecz375";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs375").src = tripleZeroA;
};

function squareToSzzZValue376(){
    value45Save = "zSqrArtSpecz376";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs376").src = tripleZeroA;
};

function squareToSzzZValue377(){
    value45Save = "zSqrArtSpecz377";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs377").src = tripleZeroA;
};

function squareToSzzZValue378(){
    value45Save = "zSqrArtSpecz378";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs378").src = tripleZeroA;
};

function squareToSzzZValue379(){
    value45Save = "zSqrArtSpecz379";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs379").src = tripleZeroA;
};

function squareToSzzZValue380(){
    value45Save = "zSqrArtSpecz380";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs380").src = tripleZeroA;
};

function squareToSzzZValue381(){
    value45Save = "zSqrArtSpecz381";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs381").src = tripleZeroA;
};

function squareToSzzZValue382(){
    value45Save = "zSqrArtSpecz382";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs382").src = tripleZeroA;
};

function squareToSzzZValue383(){
    value45Save = "zSqrArtSpecz383";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs383").src = tripleZeroA;
};

function squareToSzzZValue384(){
    value45Save = "zSqrArtSpecz384";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs384").src = tripleZeroA;
};

function squareToSzzZValue385(){
    value45Save = "zSqrArtSpecz385";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs385").src = tripleZeroA;
};

function squareToSzzZValue386(){
    value45Save = "zSqrArtSpecz386";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs386").src = tripleZeroA;
};

function squareToSzzZValue387(){
    value45Save = "zSqrArtSpecz387";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs387").src = tripleZeroA;
};

function squareToSzzZValue388(){
    value45Save = "zSqrArtSpecz388";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs388").src = tripleZeroA;
};

function squareToSzzZValue389(){
    value45Save = "zSqrArtSpecz389";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs389").src = tripleZeroA;
};

function squareToSzzZValue390(){
    value45Save = "zSqrArtSpecz390";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs390").src = tripleZeroA;
};

function squareToSzzZValue391(){
    value45Save = "zSqrArtSpecz391";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs391").src = tripleZeroA;
};

function squareToSzzZValue392(){
    value45Save = "zSqrArtSpecz392";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs392").src = tripleZeroA;
};

function squareToSzzZValue393(){
    value45Save = "zSqrArtSpecz393";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs393").src = tripleZeroA;
};

function squareToSzzZValue394(){
    value45Save = "zSqrArtSpecz394";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs394").src = tripleZeroA;
};

function squareToSzzZValue395(){
    value45Save = "zSqrArtSpecz395";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs395").src = tripleZeroA;
};

function squareToSzzZValue396(){
    value45Save = "zSqrArtSpecz396";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs396").src = tripleZeroA;
};

function squareToSzzZValue397(){
    value45Save = "zSqrArtSpecz397";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs397").src = tripleZeroA;
};

function squareToSzzZValue398(){
    value45Save = "zSqrArtSpecz398";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs398").src = tripleZeroA;
};

function squareToSzzZValue399(){
    value45Save = "zSqrArtSpecz399";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs399").src = tripleZeroA;
};

function squareToSzzZValue400(){
    value45Save = "zSqrArtSpecz400";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs400").src = tripleZeroA;
};

function squareToSzzZValue401(){
    value45Save = "zSqrArtSpecz401";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs401").src = tripleZeroA;
};

function squareToSzzZValue402(){
    value45Save = "zSqrArtSpecz402";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs402").src = tripleZeroA;
};

function squareToSzzZValue403(){
    value45Save = "zSqrArtSpecz403";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs403").src = tripleZeroA;
};

function squareToSzzZValue404(){
    value45Save = "zSqrArtSpecz404";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs404").src = tripleZeroA;
};

function squareToSzzZValue405(){
    value45Save = "zSqrArtSpecz405";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs405").src = tripleZeroA;
};

function squareToSzzZValue406(){
    value45Save = "zSqrArtSpecz406";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs406").src = tripleZeroA;
};

function squareToSzzZValue407(){
    value45Save = "zSqrArtSpecz407";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs407").src = tripleZeroA;
};

function squareToSzzZValue408(){
    value45Save = "zSqrArtSpecz408";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs408").src = tripleZeroA;
};

function squareToSzzZValue409(){
    value45Save = "zSqrArtSpecz409";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs409").src = tripleZeroA;
};

function squareToSzzZValue410(){
    value45Save = "zSqrArtSpecz410";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs410").src = tripleZeroA;
};

function squareToSzzZValue411(){
    value45Save = "zSqrArtSpecz411";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs411").src = tripleZeroA;
};

function squareToSzzZValue412(){
    value45Save = "zSqrArtSpecz412";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs412").src = tripleZeroA;
};

function squareToSzzZValue413(){
    value45Save = "zSqrArtSpecz413";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs413").src = tripleZeroA;
};

function squareToSzzZValue414(){
    value45Save = "zSqrArtSpecz414";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs414").src = tripleZeroA;
};

function squareToSzzZValue415(){
    value45Save = "zSqrArtSpecz415";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs415").src = tripleZeroA;
};

function squareToSzzZValue416(){
    value45Save = "zSqrArtSpecz416";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs416").src = tripleZeroA;
};

function squareToSzzZValue417(){
    value45Save = "zSqrArtSpecz417";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs417").src = tripleZeroA;
};

function squareToSzzZValue418(){
    value45Save = "zSqrArtSpecz418";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs418").src = tripleZeroA;
};

function squareToSzzZValue419(){
    value45Save = "zSqrArtSpecz419";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs419").src = tripleZeroA;
};

function squareToSzzZValue420(){
    value45Save = "zSqrArtSpecz420";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs420").src = tripleZeroA;
};

function squareToSzzZValue421(){
    value45Save = "zSqrArtSpecz421";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs421").src = tripleZeroA;
};

function squareToSzzZValue422(){
    value45Save = "zSqrArtSpecz422";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs422").src = tripleZeroA;
};

function squareToSzzZValue423(){
    value45Save = "zSqrArtSpecz423";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs423").src = tripleZeroA;
};

function squareToSzzZValue424(){
    value45Save = "zSqrArtSpecz424";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs424").src = tripleZeroA;
};

function squareToSzzZValue425(){
    value45Save = "zSqrArtSpecz425";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs425").src = tripleZeroA;
};

function squareToSzzZValue426(){
    value45Save = "zSqrArtSpecz426";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs426").src = tripleZeroA;
};

function squareToSzzZValue427(){
    value45Save = "zSqrArtSpecz427";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs427").src = tripleZeroA;
};

function squareToSzzZValue428(){
    value45Save = "zSqrArtSpecz428";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs428").src = tripleZeroA;
};

function squareToSzzZValue429(){
    value45Save = "zSqrArtSpecz429";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs429").src = tripleZeroA;
};

function squareToSzzZValue430(){
    value45Save = "zSqrArtSpecz430";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs430").src = tripleZeroA;
};

function squareToSzzZValue431(){
    value45Save = "zSqrArtSpecz431";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs431").src = tripleZeroA;
};

function squareToSzzZValue432(){
    value45Save = "zSqrArtSpecz432";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs432").src = tripleZeroA;
};

function squareToSzzZValue433(){
    value45Save = "zSqrArtSpecz433";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs433").src = tripleZeroA;
};

function squareToSzzZValue434(){
    value45Save = "zSqrArtSpecz434";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs434").src = tripleZeroA;
};

function squareToSzzZValue435(){
    value45Save = "zSqrArtSpecz435";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs435").src = tripleZeroA;
};

function squareToSzzZValue436(){
    value45Save = "zSqrArtSpecz436";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs436").src = tripleZeroA;
};

function squareToSzzZValue437(){
    value45Save = "zSqrArtSpecz437";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs437").src = tripleZeroA;
};

function squareToSzzZValue438(){
    value45Save = "zSqrArtSpecz438";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs438").src = tripleZeroA;
};

function squareToSzzZValue439(){
    value45Save = "zSqrArtSpecz439";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs439").src = tripleZeroA;
};

function squareToSzzZValue440(){
    value45Save = "zSqrArtSpecz440";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs440").src = tripleZeroA;
};

function squareToSzzZValue441(){
    value45Save = "zSqrArtSpecz441";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs441").src = tripleZeroA;
};

function squareToSzzZValue442(){
    value45Save = "zSqrArtSpecz442";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs442").src = tripleZeroA;
};

function squareToSzzZValue443(){
    value45Save = "zSqrArtSpecz443";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs443").src = tripleZeroA;
};

function squareToSzzZValue444(){
    value45Save = "zSqrArtSpecz444";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs444").src = tripleZeroA;
};

function squareToSzzZValue445(){
    value45Save = "zSqrArtSpecz445";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs445").src = tripleZeroA;
};

function squareToSzzZValue446(){
    value45Save = "zSqrArtSpecz446";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs446").src = tripleZeroA;
};

function squareToSzzZValue447(){
    value45Save = "zSqrArtSpecz447";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs447").src = tripleZeroA;
};

function squareToSzzZValue448(){
    value45Save = "zSqrArtSpecz448";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs448").src = tripleZeroA;
};

function squareToSzzZValue449(){
    value45Save = "zSqrArtSpecz449";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs449").src = tripleZeroA;
};

function squareToSzzZValue450(){
    value45Save = "zSqrArtSpecz450";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs450").src = tripleZeroA;
};

function squareToSzzZValue451(){
    value45Save = "zSqrArtSpecz451";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs451").src = tripleZeroA;
};

function squareToSzzZValue452(){
    value45Save = "zSqrArtSpecz452";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs452").src = tripleZeroA;
};

function squareToSzzZValue453(){
    value45Save = "zSqrArtSpecz453";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs453").src = tripleZeroA;
};

function squareToSzzZValue454(){
    value45Save = "zSqrArtSpecz454";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs454").src = tripleZeroA;
};

function squareToSzzZValue455(){
    value45Save = "zSqrArtSpecz455";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs455").src = tripleZeroA;
};

function squareToSzzZValue456(){
    value45Save = "zSqrArtSpecz456";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs456").src = tripleZeroA;
};

function squareToSzzZValue457(){
    value45Save = "zSqrArtSpecz457";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs457").src = tripleZeroA;
};

function squareToSzzZValue458(){
    value45Save = "zSqrArtSpecz458";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs458").src = tripleZeroA;
};

function squareToSzzZValue459(){
    value45Save = "zSqrArtSpecz459";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs459").src = tripleZeroA;
};

function squareToSzzZValue460(){
    value45Save = "zSqrArtSpecz460";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs460").src = tripleZeroA;
};

function squareToSzzZValue461(){
    value45Save = "zSqrArtSpecz461";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs461").src = tripleZeroA;
};

function squareToSzzZValue462(){
    value45Save = "zSqrArtSpecz462";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs462").src = tripleZeroA;
};

function squareToSzzZValue463(){
    value45Save = "zSqrArtSpecz463";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs463").src = tripleZeroA;
};

function squareToSzzZValue464(){
    value45Save = "zSqrArtSpecz464";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs464").src = tripleZeroA;
};

function squareToSzzZValue465(){
    value45Save = "zSqrArtSpecz465";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs465").src = tripleZeroA;
};

function squareToSzzZValue466(){
    value45Save = "zSqrArtSpecz466";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs466").src = tripleZeroA;
};

function squareToSzzZValue467(){
    value45Save = "zSqrArtSpecz467";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs467").src = tripleZeroA;
};

function squareToSzzZValue468(){
    value45Save = "zSqrArtSpecz468";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs468").src = tripleZeroA;
};

function squareToSzzZValue469(){
    value45Save = "zSqrArtSpecz469";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs469").src = tripleZeroA;
};

function squareToSzzZValue470(){
    value45Save = "zSqrArtSpecz470";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs470").src = tripleZeroA;
};

function squareToSzzZValue471(){
    value45Save = "zSqrArtSpecz471";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs471").src = tripleZeroA;
};

function squareToSzzZValue472(){
    value45Save = "zSqrArtSpecz472";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs472").src = tripleZeroA;
};

function squareToSzzZValue473(){
    value45Save = "zSqrArtSpecz473";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs473").src = tripleZeroA;
};

function squareToSzzZValue474(){
    value45Save = "zSqrArtSpecz474";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs474").src = tripleZeroA;
};

function squareToSzzZValue475(){
    value45Save = "zSqrArtSpecz475";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs475").src = tripleZeroA;
};

function squareToSzzZValue476(){
    value45Save = "zSqrArtSpecz476";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs476").src = tripleZeroA;
};

function squareToSzzZValue477(){
    value45Save = "zSqrArtSpecz477";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs477").src = tripleZeroA;
};

function squareToSzzZValue478(){
    value45Save = "zSqrArtSpecz478";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs478").src = tripleZeroA;
};

function squareToSzzZValue479(){
    value45Save = "zSqrArtSpecz479";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs479").src = tripleZeroA;
};

function squareToSzzZValue480(){
    value45Save = "zSqrArtSpecz480";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs480").src = tripleZeroA;
};

function squareToSzzZValue481(){
    value45Save = "zSqrArtSpecz481";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs481").src = tripleZeroA;
};

function squareToSzzZValue482(){
    value45Save = "zSqrArtSpecz482";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs482").src = tripleZeroA;
};

function squareToSzzZValue483(){
    value45Save = "zSqrArtSpecz483";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs483").src = tripleZeroA;
};

function squareToSzzZValue484(){
    value45Save = "zSqrArtSpecz484";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs484").src = tripleZeroA;
};

function squareToSzzZValue485(){
    value45Save = "zSqrArtSpecz485";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs485").src = tripleZeroA;
};

function squareToSzzZValue486(){
    value45Save = "zSqrArtSpecz486";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs486").src = tripleZeroA;
};

function squareToSzzZValue487(){
    value45Save = "zSqrArtSpecz487";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs487").src = tripleZeroA;
};

function squareToSzzZValue488(){
    value45Save = "zSqrArtSpecz488";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs488").src = tripleZeroA;
};

function squareToSzzZValue489(){
    value45Save = "zSqrArtSpecz489";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs489").src = tripleZeroA;
};

function squareToSzzZValue490(){
    value45Save = "zSqrArtSpecz490";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs490").src = tripleZeroA;
};

function squareToSzzZValue491(){
    value45Save = "zSqrArtSpecz491";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs491").src = tripleZeroA;
};

function squareToSzzZValue492(){
    value45Save = "zSqrArtSpecz492";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs492").src = tripleZeroA;
};

function squareToSzzZValue493(){
    value45Save = "zSqrArtSpecz493";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs493").src = tripleZeroA;
};

function squareToSzzZValue494(){
    value45Save = "zSqrArtSpecz494";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs494").src = tripleZeroA;
};

function squareToSzzZValue495(){
    value45Save = "zSqrArtSpecz495";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs495").src = tripleZeroA;
};

function squareToSzzZValue496(){
    value45Save = "zSqrArtSpecz496";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs496").src = tripleZeroA;
};

function squareToSzzZValue497(){
    value45Save = "zSqrArtSpecz497";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs497").src = tripleZeroA;
};

function squareToSzzZValue498(){
    value45Save = "zSqrArtSpecz498";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs498").src = tripleZeroA;
};

function squareToSzzZValue499(){
    value45Save = "zSqrArtSpecz499";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs499").src = tripleZeroA;
};

function squareToSzzZValue500(){
    value45Save = "zSqrArtSpecz500";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs500").src = tripleZeroA;
};

function squareToSzzZValue501(){
    value45Save = "zSqrArtSpecz501";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs501").src = tripleZeroA;
};

function squareToSzzZValue502(){
    value45Save = "zSqrArtSpecz502";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs502").src = tripleZeroA;
};

function squareToSzzZValue503(){
    value45Save = "zSqrArtSpecz503";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs503").src = tripleZeroA;
};

function squareToSzzZValue504(){
    value45Save = "zSqrArtSpecz504";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs504").src = tripleZeroA;
};

function squareToSzzZValue505(){
    value45Save = "zSqrArtSpecz505";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs505").src = tripleZeroA;
};

function squareToSzzZValue506(){
    value45Save = "zSqrArtSpecz506";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs506").src = tripleZeroA;
};

function squareToSzzZValue507(){
    value45Save = "zSqrArtSpecz507";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs507").src = tripleZeroA;
};

function squareToSzzZValue508(){
    value45Save = "zSqrArtSpecz508";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs508").src = tripleZeroA;
};

function squareToSzzZValue509(){
    value45Save = "zSqrArtSpecz509";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs509").src = tripleZeroA;
};

function squareToSzzZValue510(){
    value45Save = "zSqrArtSpecz510";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs510").src = tripleZeroA;
};

function squareToSzzZValue511(){
    value45Save = "zSqrArtSpecz511";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs511").src = tripleZeroA;
};

function squareToSzzZValue512(){
    value45Save = "zSqrArtSpecz512";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs512").src = tripleZeroA;
};

function squareToSzzZValue513(){
    value45Save = "zSqrArtSpecz513";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs513").src = tripleZeroA;
};

function squareToSzzZValue514(){
    value45Save = "zSqrArtSpecz514";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs514").src = tripleZeroA;
};

function squareToSzzZValue515(){
    value45Save = "zSqrArtSpecz515";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs515").src = tripleZeroA;
};

function squareToSzzZValue516(){
    value45Save = "zSqrArtSpecz516";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs516").src = tripleZeroA;
};

function squareToSzzZValue517(){
    value45Save = "zSqrArtSpecz517";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs517").src = tripleZeroA;
};

function squareToSzzZValue518(){
    value45Save = "zSqrArtSpecz518";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs518").src = tripleZeroA;
};

function squareToSzzZValue519(){
    value45Save = "zSqrArtSpecz519";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs519").src = tripleZeroA;
};

function squareToSzzZValue520(){
    value45Save = "zSqrArtSpecz520";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs520").src = tripleZeroA;
};

function squareToSzzZValue521(){
    value45Save = "zSqrArtSpecz521";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs521").src = tripleZeroA;
};

function squareToSzzZValue522(){
    value45Save = "zSqrArtSpecz522";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs522").src = tripleZeroA;
};

function squareToSzzZValue523(){
    value45Save = "zSqrArtSpecz523";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs523").src = tripleZeroA;
};

function squareToSzzZValue524(){
    value45Save = "zSqrArtSpecz524";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs524").src = tripleZeroA;
};

function squareToSzzZValue525(){
    value45Save = "zSqrArtSpecz525";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs525").src = tripleZeroA;
};

function squareToSzzZValue526(){
    value45Save = "zSqrArtSpecz526";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs526").src = tripleZeroA;
};

function squareToSzzZValue527(){
    value45Save = "zSqrArtSpecz527";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs527").src = tripleZeroA;
};

function squareToSzzZValue528(){
    value45Save = "zSqrArtSpecz528";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs528").src = tripleZeroA;
};

function squareToSzzZValue529(){
    value45Save = "zSqrArtSpecz529";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs529").src = tripleZeroA;
};

function squareToSzzZValue530(){
    value45Save = "zSqrArtSpecz530";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs530").src = tripleZeroA;
};

function squareToSzzZValue531(){
    value45Save = "zSqrArtSpecz531";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs531").src = tripleZeroA;
};

function squareToSzzZValue532(){
    value45Save = "zSqrArtSpecz532";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs532").src = tripleZeroA;
};

function squareToSzzZValue533(){
    value45Save = "zSqrArtSpecz533";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs533").src = tripleZeroA;
};

function squareToSzzZValue534(){
    value45Save = "zSqrArtSpecz534";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs534").src = tripleZeroA;
};

function squareToSzzZValue535(){
    value45Save = "zSqrArtSpecz535";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs535").src = tripleZeroA;
};

function squareToSzzZValue536(){
    value45Save = "zSqrArtSpecz536";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs536").src = tripleZeroA;
};

function squareToSzzZValue537(){
    value45Save = "zSqrArtSpecz537";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs537").src = tripleZeroA;
};

function squareToSzzZValue538(){
    value45Save = "zSqrArtSpecz538";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs538").src = tripleZeroA;
};

function squareToSzzZValue539(){
    value45Save = "zSqrArtSpecz539";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs539").src = tripleZeroA;
};

function squareToSzzZValue540(){
    value45Save = "zSqrArtSpecz540";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs540").src = tripleZeroA;
};

function squareToSzzZValue541(){
    value45Save = "zSqrArtSpecz541";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs541").src = tripleZeroA;
};

function squareToSzzZValue542(){
    value45Save = "zSqrArtSpecz542";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs542").src = tripleZeroA;
};

function squareToSzzZValue543(){
    value45Save = "zSqrArtSpecz543";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs543").src = tripleZeroA;
};

function squareToSzzZValue544(){
    value45Save = "zSqrArtSpecz544";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs544").src = tripleZeroA;
};

function squareToSzzZValue545(){
    value45Save = "zSqrArtSpecz545";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs545").src = tripleZeroA;
};

function squareToSzzZValue546(){
    value45Save = "zSqrArtSpecz546";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs546").src = tripleZeroA;
};

function squareToSzzZValue547(){
    value45Save = "zSqrArtSpecz547";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs547").src = tripleZeroA;
};

function squareToSzzZValue548(){
    value45Save = "zSqrArtSpecz548";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs548").src = tripleZeroA;
};

function squareToSzzZValue549(){
    value45Save = "zSqrArtSpecz549";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs549").src = tripleZeroA;
};

function squareToSzzZValue550(){
    value45Save = "zSqrArtSpecz550";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs550").src = tripleZeroA;
};

function squareToSzzZValue551(){
    value45Save = "zSqrArtSpecz551";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs551").src = tripleZeroA;
};

function squareToSzzZValue552(){
    value45Save = "zSqrArtSpecz552";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs552").src = tripleZeroA;
};

function squareToSzzZValue553(){
    value45Save = "zSqrArtSpecz553";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs553").src = tripleZeroA;
};

function squareToSzzZValue554(){
    value45Save = "zSqrArtSpecz554";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs554").src = tripleZeroA;
};

function squareToSzzZValue555(){
    value45Save = "zSqrArtSpecz555";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs555").src = tripleZeroA;
};

function squareToSzzZValue556(){
    value45Save = "zSqrArtSpecz556";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs556").src = tripleZeroA;
};

function squareToSzzZValue557(){
    value45Save = "zSqrArtSpecz557";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs557").src = tripleZeroA;
};

function squareToSzzZValue558(){
    value45Save = "zSqrArtSpecz558";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs558").src = tripleZeroA;
};

function squareToSzzZValue559(){
    value45Save = "zSqrArtSpecz559";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs559").src = tripleZeroA;
};

function squareToSzzZValue560(){
    value45Save = "zSqrArtSpecz560";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs560").src = tripleZeroA;
};

function squareToSzzZValue561(){
    value45Save = "zSqrArtSpecz561";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs561").src = tripleZeroA;
};

function squareToSzzZValue562(){
    value45Save = "zSqrArtSpecz562";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs562").src = tripleZeroA;
};

function squareToSzzZValue563(){
    value45Save = "zSqrArtSpecz563";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs563").src = tripleZeroA;
};

function squareToSzzZValue564(){
    value45Save = "zSqrArtSpecz564";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs564").src = tripleZeroA;
};

function squareToSzzZValue565(){
    value45Save = "zSqrArtSpecz565";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs565").src = tripleZeroA;
};

function squareToSzzZValue566(){
    value45Save = "zSqrArtSpecz566";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs566").src = tripleZeroA;
};

function squareToSzzZValue567(){
    value45Save = "zSqrArtSpecz567";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs567").src = tripleZeroA;
};

function squareToSzzZValue568(){
    value45Save = "zSqrArtSpecz568";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs568").src = tripleZeroA;
};

function squareToSzzZValue569(){
    value45Save = "zSqrArtSpecz569";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs569").src = tripleZeroA;
};

function squareToSzzZValue570(){
    value45Save = "zSqrArtSpecz570";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs570").src = tripleZeroA;
};

function squareToSzzZValue571(){
    value45Save = "zSqrArtSpecz571";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs571").src = tripleZeroA;
};

function squareToSzzZValue572(){
    value45Save = "zSqrArtSpecz572";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs572").src = tripleZeroA;
};

function squareToSzzZValue573(){
    value45Save = "zSqrArtSpecz573";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs573").src = tripleZeroA;
};

function squareToSzzZValue574(){
    value45Save = "zSqrArtSpecz574";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs574").src = tripleZeroA;
};

function squareToSzzZValue575(){
    value45Save = "zSqrArtSpecz575";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs575").src = tripleZeroA;
};

function squareToSzzZValue576(){
    value45Save = "zSqrArtSpecz576";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs576").src = tripleZeroA;
};

function squareToSzzZValue577(){
    value45Save = "zSqrArtSpecz577";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs577").src = tripleZeroA;
};

function squareToSzzZValue578(){
    value45Save = "zSqrArtSpecz578";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs578").src = tripleZeroA;
};

function squareToSzzZValue579(){
    value45Save = "zSqrArtSpecz579";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs579").src = tripleZeroA;
};

function squareToSzzZValue580(){
    value45Save = "zSqrArtSpecz580";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs580").src = tripleZeroA;
};

function squareToSzzZValue581(){
    value45Save = "zSqrArtSpecz581";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs581").src = tripleZeroA;
};

function squareToSzzZValue582(){
    value45Save = "zSqrArtSpecz582";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs582").src = tripleZeroA;
};

function squareToSzzZValue583(){
    value45Save = "zSqrArtSpecz583";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs583").src = tripleZeroA;
};

function squareToSzzZValue584(){
    value45Save = "zSqrArtSpecz584";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs584").src = tripleZeroA;
};

function squareToSzzZValue585(){
    value45Save = "zSqrArtSpecz585";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs585").src = tripleZeroA;
};

function squareToSzzZValue586(){
    value45Save = "zSqrArtSpecz586";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs586").src = tripleZeroA;
};

function squareToSzzZValue587(){
    value45Save = "zSqrArtSpecz587";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs587").src = tripleZeroA;
};

function squareToSzzZValue588(){
    value45Save = "zSqrArtSpecz588";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs588").src = tripleZeroA;
};

function squareToSzzZValue589(){
    value45Save = "zSqrArtSpecz589";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs589").src = tripleZeroA;
};

function squareToSzzZValue590(){
    value45Save = "zSqrArtSpecz590";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs590").src = tripleZeroA;
};

function squareToSzzZValue591(){
    value45Save = "zSqrArtSpecz591";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs591").src = tripleZeroA;
};

function squareToSzzZValue592(){
    value45Save = "zSqrArtSpecz592";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs592").src = tripleZeroA;
};

function squareToSzzZValue593(){
    value45Save = "zSqrArtSpecz593";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs593").src = tripleZeroA;
};

function squareToSzzZValue594(){
    value45Save = "zSqrArtSpecz594";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs594").src = tripleZeroA;
};

function squareToSzzZValue595(){
    value45Save = "zSqrArtSpecz595";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs595").src = tripleZeroA;
};

function squareToSzzZValue596(){
    value45Save = "zSqrArtSpecz596";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs596").src = tripleZeroA;
};

function squareToSzzZValue597(){
    value45Save = "zSqrArtSpecz597";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs597").src = tripleZeroA;
};

function squareToSzzZValue598(){
    value45Save = "zSqrArtSpecz598";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs598").src = tripleZeroA;
};

function squareToSzzZValue599(){
    value45Save = "zSqrArtSpecz599";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs599").src = tripleZeroA;
};

function squareToSzzZValue600(){
    value45Save = "zSqrArtSpecz600";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs600").src = tripleZeroA;
};

function squareToSzzZValue601(){
    value45Save = "zSqrArtSpecz601";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs601").src = tripleZeroA;
};

function squareToSzzZValue602(){
    value45Save = "zSqrArtSpecz602";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs602").src = tripleZeroA;
};

function squareToSzzZValue603(){
    value45Save = "zSqrArtSpecz603";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs603").src = tripleZeroA;
};

function squareToSzzZValue604(){
    value45Save = "zSqrArtSpecz604";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs604").src = tripleZeroA;
};

function squareToSzzZValue605(){
    value45Save = "zSqrArtSpecz605";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs605").src = tripleZeroA;
};

function squareToSzzZValue606(){
    value45Save = "zSqrArtSpecz606";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs606").src = tripleZeroA;
};

function squareToSzzZValue607(){
    value45Save = "zSqrArtSpecz607";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs607").src = tripleZeroA;
};

function squareToSzzZValue608(){
    value45Save = "zSqrArtSpecz608";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs608").src = tripleZeroA;
};

function squareToSzzZValue609(){
    value45Save = "zSqrArtSpecz609";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs609").src = tripleZeroA;
};

function squareToSzzZValue610(){
    value45Save = "zSqrArtSpecz610";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs610").src = tripleZeroA;
};

function squareToSzzZValue611(){
    value45Save = "zSqrArtSpecz611";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs611").src = tripleZeroA;
};

function squareToSzzZValue612(){
    value45Save = "zSqrArtSpecz612";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs612").src = tripleZeroA;
};

function squareToSzzZValue613(){
    value45Save = "zSqrArtSpecz613";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs613").src = tripleZeroA;
};

function squareToSzzZValue614(){
    value45Save = "zSqrArtSpecz614";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs614").src = tripleZeroA;
};

function squareToSzzZValue615(){
    value45Save = "zSqrArtSpecz615";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs615").src = tripleZeroA;
};

function squareToSzzZValue616(){
    value45Save = "zSqrArtSpecz616";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs616").src = tripleZeroA;
};

function squareToSzzZValue617(){
    value45Save = "zSqrArtSpecz617";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs617").src = tripleZeroA;
};

function squareToSzzZValue618(){
    value45Save = "zSqrArtSpecz618";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs618").src = tripleZeroA;
};

function squareToSzzZValue619(){
    value45Save = "zSqrArtSpecz619";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs619").src = tripleZeroA;
};

function squareToSzzZValue620(){
    value45Save = "zSqrArtSpecz620";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs620").src = tripleZeroA;
};

function squareToSzzZValue621(){
    value45Save = "zSqrArtSpecz621";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs621").src = tripleZeroA;
};

function squareToSzzZValue622(){
    value45Save = "zSqrArtSpecz622";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs622").src = tripleZeroA;
};

function squareToSzzZValue623(){
    value45Save = "zSqrArtSpecz623";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs623").src = tripleZeroA;
};

function squareToSzzZValue624(){
    value45Save = "zSqrArtSpecz624";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs624").src = tripleZeroA;
};

function squareToSzzZValue625(){
    value45Save = "zSqrArtSpecz625";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs625").src = tripleZeroA;
};

function squareToSzzZValue626(){
    value45Save = "zSqrArtSpecz626";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs626").src = tripleZeroA;
};

function squareToSzzZValue627(){
    value45Save = "zSqrArtSpecz627";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs627").src = tripleZeroA;
};

function squareToSzzZValue628(){
    value45Save = "zSqrArtSpecz628";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs628").src = tripleZeroA;
};

function squareToSzzZValue629(){
    value45Save = "zSqrArtSpecz629";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs629").src = tripleZeroA;
};

function squareToSzzZValue630(){
    value45Save = "zSqrArtSpecz630";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs630").src = tripleZeroA;
};

function squareToSzzZValue631(){
    value45Save = "zSqrArtSpecz631";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs631").src = tripleZeroA;
};

function squareToSzzZValue632(){
    value45Save = "zSqrArtSpecz632";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs632").src = tripleZeroA;
};

function squareToSzzZValue633(){
    value45Save = "zSqrArtSpecz633";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs633").src = tripleZeroA;
};

function squareToSzzZValue634(){
    value45Save = "zSqrArtSpecz634";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs634").src = tripleZeroA;
};

function squareToSzzZValue635(){
    value45Save = "zSqrArtSpecz635";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs635").src = tripleZeroA;
};

function squareToSzzZValue636(){
    value45Save = "zSqrArtSpecz636";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs636").src = tripleZeroA;
};

function squareToSzzZValue637(){
    value45Save = "zSqrArtSpecz637";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs637").src = tripleZeroA;
};

function squareToSzzZValue638(){
    value45Save = "zSqrArtSpecz638";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs638").src = tripleZeroA;
};

function squareToSzzZValue639(){
    value45Save = "zSqrArtSpecz639";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs639").src = tripleZeroA;
};

function squareToSzzZValue640(){
    value45Save = "zSqrArtSpecz640";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs640").src = tripleZeroA;
};

function squareToSzzZValue641(){
    value45Save = "zSqrArtSpecz641";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs641").src = tripleZeroA;
};

function squareToSzzZValue642(){
    value45Save = "zSqrArtSpecz642";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs642").src = tripleZeroA;
};

function squareToSzzZValue643(){
    value45Save = "zSqrArtSpecz643";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs643").src = tripleZeroA;
};

function squareToSzzZValue644(){
    value45Save = "zSqrArtSpecz644";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs644").src = tripleZeroA;
};

function squareToSzzZValue645(){
    value45Save = "zSqrArtSpecz645";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs645").src = tripleZeroA;
};

function squareToSzzZValue646(){
    value45Save = "zSqrArtSpecz646";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs646").src = tripleZeroA;
};

function squareToSzzZValue647(){
    value45Save = "zSqrArtSpecz647";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs647").src = tripleZeroA;
};

function squareToSzzZValue648(){
    value45Save = "zSqrArtSpecz648";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs648").src = tripleZeroA;
};

function squareToSzzZValue649(){
    value45Save = "zSqrArtSpecz649";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs649").src = tripleZeroA;
};

function squareToSzzZValue650(){
    value45Save = "zSqrArtSpecz650";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs650").src = tripleZeroA;
};

function squareToSzzZValue651(){
    value45Save = "zSqrArtSpecz651";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs651").src = tripleZeroA;
};

function squareToSzzZValue652(){
    value45Save = "zSqrArtSpecz652";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs652").src = tripleZeroA;
};

function squareToSzzZValue653(){
    value45Save = "zSqrArtSpecz653";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs653").src = tripleZeroA;
};

function squareToSzzZValue654(){
    value45Save = "zSqrArtSpecz654";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs654").src = tripleZeroA;
};

function squareToSzzZValue655(){
    value45Save = "zSqrArtSpecz655";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs655").src = tripleZeroA;
};

function squareToSzzZValue656(){
    value45Save = "zSqrArtSpecz656";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs656").src = tripleZeroA;
};

function squareToSzzZValue657(){
    value45Save = "zSqrArtSpecz657";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs657").src = tripleZeroA;
};

function squareToSzzZValue658(){
    value45Save = "zSqrArtSpecz658";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs658").src = tripleZeroA;
};

function squareToSzzZValue659(){
    value45Save = "zSqrArtSpecz659";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs659").src = tripleZeroA;
};

function squareToSzzZValue660(){
    value45Save = "zSqrArtSpecz660";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs660").src = tripleZeroA;
};

function squareToSzzZValue661(){
    value45Save = "zSqrArtSpecz661";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs661").src = tripleZeroA;
};

function squareToSzzZValue662(){
    value45Save = "zSqrArtSpecz662";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs662").src = tripleZeroA;
};

function squareToSzzZValue663(){
    value45Save = "zSqrArtSpecz663";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs663").src = tripleZeroA;
};

function squareToSzzZValue664(){
    value45Save = "zSqrArtSpecz664";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs664").src = tripleZeroA;
};

function squareToSzzZValue665(){
    value45Save = "zSqrArtSpecz665";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs665").src = tripleZeroA;
};

function squareToSzzZValue666(){
    value45Save = "zSqrArtSpecz666";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs666").src = tripleZeroA;
};

function squareToSzzZValue667(){
    value45Save = "zSqrArtSpecz667";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs667").src = tripleZeroA;
};

function squareToSzzZValue668(){
    value45Save = "zSqrArtSpecz668";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs668").src = tripleZeroA;
};

function squareToSzzZValue669(){
    value45Save = "zSqrArtSpecz669";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs669").src = tripleZeroA;
};

function squareToSzzZValue670(){
    value45Save = "zSqrArtSpecz670";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs670").src = tripleZeroA;
};

function squareToSzzZValue671(){
    value45Save = "zSqrArtSpecz671";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs671").src = tripleZeroA;
};

function squareToSzzZValue672(){
    value45Save = "zSqrArtSpecz672";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs672").src = tripleZeroA;
};

function squareToSzzZValue673(){
    value45Save = "zSqrArtSpecz673";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs673").src = tripleZeroA;
};

function squareToSzzZValue674(){
    value45Save = "zSqrArtSpecz674";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs674").src = tripleZeroA;
};

function squareToSzzZValue675(){
    value45Save = "zSqrArtSpecz675";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs675").src = tripleZeroA;
};

function squareToSzzZValue676(){
    value45Save = "zSqrArtSpecz676";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs676").src = tripleZeroA;
};

function squareToSzzZValue677(){
    value45Save = "zSqrArtSpecz677";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs677").src = tripleZeroA;
};

function squareToSzzZValue678(){
    value45Save = "zSqrArtSpecz678";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs678").src = tripleZeroA;
};

function squareToSzzZValue679(){
    value45Save = "zSqrArtSpecz679";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs679").src = tripleZeroA;
};

function squareToSzzZValue680(){
    value45Save = "zSqrArtSpecz680";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs680").src = tripleZeroA;
};

function squareToSzzZValue681(){
    value45Save = "zSqrArtSpecz681";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs681").src = tripleZeroA;
};

function squareToSzzZValue682(){
    value45Save = "zSqrArtSpecz682";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs682").src = tripleZeroA;
};

function squareToSzzZValue683(){
    value45Save = "zSqrArtSpecz683";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs683").src = tripleZeroA;
};

function squareToSzzZValue684(){
    value45Save = "zSqrArtSpecz684";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs684").src = tripleZeroA;
};

function squareToSzzZValue685(){
    value45Save = "zSqrArtSpecz685";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs685").src = tripleZeroA;
};

function squareToSzzZValue686(){
    value45Save = "zSqrArtSpecz686";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs686").src = tripleZeroA;
};

function squareToSzzZValue687(){
    value45Save = "zSqrArtSpecz687";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs687").src = tripleZeroA;
};

function squareToSzzZValue688(){
    value45Save = "zSqrArtSpecz688";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs688").src = tripleZeroA;
};

function squareToSzzZValue689(){
    value45Save = "zSqrArtSpecz689";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs689").src = tripleZeroA;
};

function squareToSzzZValue690(){
    value45Save = "zSqrArtSpecz690";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs690").src = tripleZeroA;
};

function squareToSzzZValue691(){
    value45Save = "zSqrArtSpecz691";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs691").src = tripleZeroA;
};

function squareToSzzZValue692(){
    value45Save = "zSqrArtSpecz692";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs692").src = tripleZeroA;
};

function squareToSzzZValue693(){
    value45Save = "zSqrArtSpecz693";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs693").src = tripleZeroA;
};

function squareToSzzZValue694(){
    value45Save = "zSqrArtSpecz694";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs694").src = tripleZeroA;
};

function squareToSzzZValue695(){
    value45Save = "zSqrArtSpecz695";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs695").src = tripleZeroA;
};

function squareToSzzZValue696(){
    value45Save = "zSqrArtSpecz696";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs696").src = tripleZeroA;
};

function squareToSzzZValue697(){
    value45Save = "zSqrArtSpecz697";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs697").src = tripleZeroA;
};

function squareToSzzZValue698(){
    value45Save = "zSqrArtSpecz698";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs698").src = tripleZeroA;
};

function squareToSzzZValue699(){
    value45Save = "zSqrArtSpecz699";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs699").src = tripleZeroA;
};

function squareToSzzZValue700(){
    value45Save = "zSqrArtSpecz700";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs700").src = tripleZeroA;
};

function squareToSzzZValue701(){
    value45Save = "zSqrArtSpecz701";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs701").src = tripleZeroA;
};

function squareToSzzZValue702(){
    value45Save = "zSqrArtSpecz702";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs702").src = tripleZeroA;
};

function squareToSzzZValue703(){
    value45Save = "zSqrArtSpecz703";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs703").src = tripleZeroA;
};

function squareToSzzZValue704(){
    value45Save = "zSqrArtSpecz704";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs704").src = tripleZeroA;
};

function squareToSzzZValue705(){
    value45Save = "zSqrArtSpecz705";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs705").src = tripleZeroA;
};

function squareToSzzZValue706(){
    value45Save = "zSqrArtSpecz706";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs706").src = tripleZeroA;
};

function squareToSzzZValue707(){
    value45Save = "zSqrArtSpecz707";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs707").src = tripleZeroA;
};

function squareToSzzZValue708(){
    value45Save = "zSqrArtSpecz708";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs708").src = tripleZeroA;
};

function squareToSzzZValue709(){
    value45Save = "zSqrArtSpecz709";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs709").src = tripleZeroA;
};

function squareToSzzZValue710(){
    value45Save = "zSqrArtSpecz710";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs710").src = tripleZeroA;
};

function squareToSzzZValue711(){
    value45Save = "zSqrArtSpecz711";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs711").src = tripleZeroA;
};

function squareToSzzZValue712(){
    value45Save = "zSqrArtSpecz712";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs712").src = tripleZeroA;
};

function squareToSzzZValue713(){
    value45Save = "zSqrArtSpecz713";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs713").src = tripleZeroA;
};

function squareToSzzZValue714(){
    value45Save = "zSqrArtSpecz714";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs714").src = tripleZeroA;
};

function squareToSzzZValue715(){
    value45Save = "zSqrArtSpecz715";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs715").src = tripleZeroA;
};

function squareToSzzZValue716(){
    value45Save = "zSqrArtSpecz716";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs716").src = tripleZeroA;
};

function squareToSzzZValue717(){
    value45Save = "zSqrArtSpecz717";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs717").src = tripleZeroA;
};

function squareToSzzZValue718(){
    value45Save = "zSqrArtSpecz718";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs718").src = tripleZeroA;
};

function squareToSzzZValue719(){
    value45Save = "zSqrArtSpecz719";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs719").src = tripleZeroA;
};

function squareToSzzZValue720(){
    value45Save = "zSqrArtSpecz720";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs720").src = tripleZeroA;
};

function squareToSzzZValue721(){
    value45Save = "zSqrArtSpecz721";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs721").src = tripleZeroA;
};

function squareToSzzZValue722(){
    value45Save = "zSqrArtSpecz722";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs722").src = tripleZeroA;
};

function squareToSzzZValue723(){
    value45Save = "zSqrArtSpecz723";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs723").src = tripleZeroA;
};

function squareToSzzZValue724(){
    value45Save = "zSqrArtSpecz724";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs724").src = tripleZeroA;
};

function squareToSzzZValue725(){
    value45Save = "zSqrArtSpecz725";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs725").src = tripleZeroA;
};

function squareToSzzZValue726(){
    value45Save = "zSqrArtSpecz726";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs726").src = tripleZeroA;
};

function squareToSzzZValue727(){
    value45Save = "zSqrArtSpecz727";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs727").src = tripleZeroA;
};

function squareToSzzZValue728(){
    value45Save = "zSqrArtSpecz728";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs728").src = tripleZeroA;
};

function squareToSzzZValue729(){
    value45Save = "zSqrArtSpecz729";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs729").src = tripleZeroA;
};

function squareToSzzZValue730(){
    value45Save = "zSqrArtSpecz730";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs730").src = tripleZeroA;
};

function squareToSzzZValue731(){
    value45Save = "zSqrArtSpecz731";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs731").src = tripleZeroA;
};

function squareToSzzZValue732(){
    value45Save = "zSqrArtSpecz732";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs732").src = tripleZeroA;
};

function squareToSzzZValue733(){
    value45Save = "zSqrArtSpecz733";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs733").src = tripleZeroA;
};

function squareToSzzZValue734(){
    value45Save = "zSqrArtSpecz734";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs734").src = tripleZeroA;
};

function squareToSzzZValue735(){
    value45Save = "zSqrArtSpecz735";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs735").src = tripleZeroA;
};

function squareToSzzZValue736(){
    value45Save = "zSqrArtSpecz736";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs736").src = tripleZeroA;
};

function squareToSzzZValue737(){
    value45Save = "zSqrArtSpecz737";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs737").src = tripleZeroA;
};

function squareToSzzZValue738(){
    value45Save = "zSqrArtSpecz738";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs738").src = tripleZeroA;
};

function squareToSzzZValue739(){
    value45Save = "zSqrArtSpecz739";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs739").src = tripleZeroA;
};

function squareToSzzZValue740(){
    value45Save = "zSqrArtSpecz740";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs740").src = tripleZeroA;
};

function squareToSzzZValue741(){
    value45Save = "zSqrArtSpecz741";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs741").src = tripleZeroA;
};

function squareToSzzZValue742(){
    value45Save = "zSqrArtSpecz742";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs742").src = tripleZeroA;
};

function squareToSzzZValue743(){
    value45Save = "zSqrArtSpecz743";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs743").src = tripleZeroA;
};

function squareToSzzZValue744(){
    value45Save = "zSqrArtSpecz744";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs744").src = tripleZeroA;
};

function squareToSzzZValue745(){
    value45Save = "zSqrArtSpecz745";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs745").src = tripleZeroA;
};

function squareToSzzZValue746(){
    value45Save = "zSqrArtSpecz746";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs746").src = tripleZeroA;
};

function squareToSzzZValue747(){
    value45Save = "zSqrArtSpecz747";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs747").src = tripleZeroA;
};

function squareToSzzZValue748(){
    value45Save = "zSqrArtSpecz748";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs748").src = tripleZeroA;
};

function squareToSzzZValue749(){
    value45Save = "zSqrArtSpecz749";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs749").src = tripleZeroA;
};

function squareToSzzZValue750(){
    value45Save = "zSqrArtSpecz750";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs750").src = tripleZeroA;
};

function squareToSzzZValue751(){
    value45Save = "zSqrArtSpecz751";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs751").src = tripleZeroA;
};

function squareToSzzZValue752(){
    value45Save = "zSqrArtSpecz752";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs752").src = tripleZeroA;
};

function squareToSzzZValue753(){
    value45Save = "zSqrArtSpecz753";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs753").src = tripleZeroA;
};

function squareToSzzZValue754(){
    value45Save = "zSqrArtSpecz754";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs754").src = tripleZeroA;
};

function squareToSzzZValue755(){
    value45Save = "zSqrArtSpecz755";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs755").src = tripleZeroA;
};

function squareToSzzZValue756(){
    value45Save = "zSqrArtSpecz756";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs756").src = tripleZeroA;
};

function squareToSzzZValue757(){
    value45Save = "zSqrArtSpecz757";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs757").src = tripleZeroA;
};

function squareToSzzZValue758(){
    value45Save = "zSqrArtSpecz758";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs758").src = tripleZeroA;
};

function squareToSzzZValue759(){
    value45Save = "zSqrArtSpecz759";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs759").src = tripleZeroA;
};

function squareToSzzZValue760(){
    value45Save = "zSqrArtSpecz760";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs760").src = tripleZeroA;
};

function squareToSzzZValue761(){
    value45Save = "zSqrArtSpecz761";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs761").src = tripleZeroA;
};

function squareToSzzZValue762(){
    value45Save = "zSqrArtSpecz762";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs762").src = tripleZeroA;
};

function squareToSzzZValue763(){
    value45Save = "zSqrArtSpecz763";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs763").src = tripleZeroA;
};

function squareToSzzZValue764(){
    value45Save = "zSqrArtSpecz764";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs764").src = tripleZeroA;
};

function squareToSzzZValue765(){
    value45Save = "zSqrArtSpecz765";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs765").src = tripleZeroA;
};

function squareToSzzZValue766(){
    value45Save = "zSqrArtSpecz766";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs766").src = tripleZeroA;
};

function squareToSzzZValue767(){
    value45Save = "zSqrArtSpecz767";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs767").src = tripleZeroA;
};

function squareToSzzZValue768(){
    value45Save = "zSqrArtSpecz768";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs768").src = tripleZeroA;
};

function squareToSzzZValue769(){
    value45Save = "zSqrArtSpecz769";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs769").src = tripleZeroA;
};

function squareToSzzZValue770(){
    value45Save = "zSqrArtSpecz770";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs770").src = tripleZeroA;
};

function squareToSzzZValue771(){
    value45Save = "zSqrArtSpecz771";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs771").src = tripleZeroA;
};

function squareToSzzZValue772(){
    value45Save = "zSqrArtSpecz772";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs772").src = tripleZeroA;
};

function squareToSzzZValue773(){
    value45Save = "zSqrArtSpecz773";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs773").src = tripleZeroA;
};

function squareToSzzZValue774(){
    value45Save = "zSqrArtSpecz774";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs774").src = tripleZeroA;
};

function squareToSzzZValue775(){
    value45Save = "zSqrArtSpecz775";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs775").src = tripleZeroA;
};

function squareToSzzZValue776(){
    value45Save = "zSqrArtSpecz776";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs776").src = tripleZeroA;
};

function squareToSzzZValue777(){
    value45Save = "zSqrArtSpecz777";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs777").src = tripleZeroA;
};

function squareToSzzZValue778(){
    value45Save = "zSqrArtSpecz778";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs778").src = tripleZeroA;
};

function squareToSzzZValue779(){
    value45Save = "zSqrArtSpecz779";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs779").src = tripleZeroA;
};

function squareToSzzZValue780(){
    value45Save = "zSqrArtSpecz780";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs780").src = tripleZeroA;
};

function squareToSzzZValue781(){
    value45Save = "zSqrArtSpecz781";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs781").src = tripleZeroA;
};

function squareToSzzZValue782(){
    value45Save = "zSqrArtSpecz782";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs782").src = tripleZeroA;
};

function squareToSzzZValue783(){
    value45Save = "zSqrArtSpecz783";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs783").src = tripleZeroA;
};

function squareToSzzZValue784(){
    value45Save = "zSqrArtSpecz784";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs784").src = tripleZeroA;
};

function squareToSzzZValue785(){
    value45Save = "zSqrArtSpecz785";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs785").src = tripleZeroA;
};

function squareToSzzZValue786(){
    value45Save = "zSqrArtSpecz786";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs786").src = tripleZeroA;
};

function squareToSzzZValue787(){
    value45Save = "zSqrArtSpecz787";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs787").src = tripleZeroA;
};

function squareToSzzZValue788(){
    value45Save = "zSqrArtSpecz788";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs788").src = tripleZeroA;
};

function squareToSzzZValue789(){
    value45Save = "zSqrArtSpecz789";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs789").src = tripleZeroA;
};

function squareToSzzZValue790(){
    value45Save = "zSqrArtSpecz790";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs790").src = tripleZeroA;
};

function squareToSzzZValue791(){
    value45Save = "zSqrArtSpecz791";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs791").src = tripleZeroA;
};

function squareToSzzZValue792(){
    value45Save = "zSqrArtSpecz792";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs792").src = tripleZeroA;
};

function squareToSzzZValue793(){
    value45Save = "zSqrArtSpecz793";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs793").src = tripleZeroA;
};

function squareToSzzZValue794(){
    value45Save = "zSqrArtSpecz794";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs794").src = tripleZeroA;
};

function squareToSzzZValue795(){
    value45Save = "zSqrArtSpecz795";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs795").src = tripleZeroA;
};

function squareToSzzZValue796(){
    value45Save = "zSqrArtSpecz796";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs796").src = tripleZeroA;
};

function squareToSzzZValue797(){
    value45Save = "zSqrArtSpecz797";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs797").src = tripleZeroA;
};

function squareToSzzZValue798(){
    value45Save = "zSqrArtSpecz798";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs798").src = tripleZeroA;
};

function squareToSzzZValue799(){
    value45Save = "zSqrArtSpecz799";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs799").src = tripleZeroA;
};

function squareToSzzZValue800(){
    value45Save = "zSqrArtSpecz800";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs800").src = tripleZeroA;
};

function squareToSzzZValue801(){
    value45Save = "zSqrArtSpecz801";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs801").src = tripleZeroA;
};

function squareToSzzZValue802(){
    value45Save = "zSqrArtSpecz802";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs802").src = tripleZeroA;
};

function squareToSzzZValue803(){
    value45Save = "zSqrArtSpecz803";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs803").src = tripleZeroA;
};

function squareToSzzZValue804(){
    value45Save = "zSqrArtSpecz804";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs804").src = tripleZeroA;
};

function squareToSzzZValue805(){
    value45Save = "zSqrArtSpecz805";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs805").src = tripleZeroA;
};

function squareToSzzZValue806(){
    value45Save = "zSqrArtSpecz806";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs806").src = tripleZeroA;
};

function squareToSzzZValue807(){
    value45Save = "zSqrArtSpecz807";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs807").src = tripleZeroA;
};

function squareToSzzZValue808(){
    value45Save = "zSqrArtSpecz808";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs808").src = tripleZeroA;
};

function squareToSzzZValue809(){
    value45Save = "zSqrArtSpecz809";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs809").src = tripleZeroA;
};

function squareToSzzZValue810(){
    value45Save = "zSqrArtSpecz810";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs810").src = tripleZeroA;
};

function squareToSzzZValue811(){
    value45Save = "zSqrArtSpecz811";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs811").src = tripleZeroA;
};

function squareToSzzZValue812(){
    value45Save = "zSqrArtSpecz812";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs812").src = tripleZeroA;
};

function squareToSzzZValue813(){
    value45Save = "zSqrArtSpecz813";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs813").src = tripleZeroA;
};

function squareToSzzZValue814(){
    value45Save = "zSqrArtSpecz814";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs814").src = tripleZeroA;
};

function squareToSzzZValue815(){
    value45Save = "zSqrArtSpecz815";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs815").src = tripleZeroA;
};

function squareToSzzZValue816(){
    value45Save = "zSqrArtSpecz816";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs816").src = tripleZeroA;
};

function squareToSzzZValue817(){
    value45Save = "zSqrArtSpecz817";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs817").src = tripleZeroA;
};

function squareToSzzZValue818(){
    value45Save = "zSqrArtSpecz818";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs818").src = tripleZeroA;
};

function squareToSzzZValue819(){
    value45Save = "zSqrArtSpecz819";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs819").src = tripleZeroA;
};

function squareToSzzZValue820(){
    value45Save = "zSqrArtSpecz820";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs820").src = tripleZeroA;
};

function squareToSzzZValue821(){
    value45Save = "zSqrArtSpecz821";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs821").src = tripleZeroA;
};

function squareToSzzZValue822(){
    value45Save = "zSqrArtSpecz822";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs822").src = tripleZeroA;
};

function squareToSzzZValue823(){
    value45Save = "zSqrArtSpecz823";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs823").src = tripleZeroA;
};

function squareToSzzZValue824(){
    value45Save = "zSqrArtSpecz824";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs824").src = tripleZeroA;
};

function squareToSzzZValue825(){
    value45Save = "zSqrArtSpecz825";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs825").src = tripleZeroA;
};

function squareToSzzZValue826(){
    value45Save = "zSqrArtSpecz826";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs826").src = tripleZeroA;
};

function squareToSzzZValue827(){
    value45Save = "zSqrArtSpecz827";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs827").src = tripleZeroA;
};

function squareToSzzZValue828(){
    value45Save = "zSqrArtSpecz828";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs828").src = tripleZeroA;
};

function squareToSzzZValue829(){
    value45Save = "zSqrArtSpecz829";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs829").src = tripleZeroA;
};

function squareToSzzZValue830(){
    value45Save = "zSqrArtSpecz830";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs830").src = tripleZeroA;
};

function squareToSzzZValue831(){
    value45Save = "zSqrArtSpecz831";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs831").src = tripleZeroA;
};

function squareToSzzZValue832(){
    value45Save = "zSqrArtSpecz832";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs832").src = tripleZeroA;
};

function squareToSzzZValue833(){
    value45Save = "zSqrArtSpecz833";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs833").src = tripleZeroA;
};

function squareToSzzZValue834(){
    value45Save = "zSqrArtSpecz834";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs834").src = tripleZeroA;
};

function squareToSzzZValue835(){
    value45Save = "zSqrArtSpecz835";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs835").src = tripleZeroA;
};

function squareToSzzZValue836(){
    value45Save = "zSqrArtSpecz836";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs836").src = tripleZeroA;
};

function squareToSzzZValue837(){
    value45Save = "zSqrArtSpecz837";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs837").src = tripleZeroA;
};

function squareToSzzZValue838(){
    value45Save = "zSqrArtSpecz838";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs838").src = tripleZeroA;
};

function squareToSzzZValue839(){
    value45Save = "zSqrArtSpecz839";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs839").src = tripleZeroA;
};

function squareToSzzZValue840(){
    value45Save = "zSqrArtSpecz840";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs840").src = tripleZeroA;
};

function squareToSzzZValue841(){
    value45Save = "zSqrArtSpecz841";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs841").src = tripleZeroA;
};

function squareToSzzZValue842(){
    value45Save = "zSqrArtSpecz842";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs842").src = tripleZeroA;
};

function squareToSzzZValue843(){
    value45Save = "zSqrArtSpecz843";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs843").src = tripleZeroA;
};

function squareToSzzZValue844(){
    value45Save = "zSqrArtSpecz844";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs844").src = tripleZeroA;
};

function squareToSzzZValue845(){
    value45Save = "zSqrArtSpecz845";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs845").src = tripleZeroA;
};

function squareToSzzZValue846(){
    value45Save = "zSqrArtSpecz846";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs846").src = tripleZeroA;
};

function squareToSzzZValue847(){
    value45Save = "zSqrArtSpecz847";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs847").src = tripleZeroA;
};

function squareToSzzZValue848(){
    value45Save = "zSqrArtSpecz848";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs848").src = tripleZeroA;
};

function squareToSzzZValue849(){
    value45Save = "zSqrArtSpecz849";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs849").src = tripleZeroA;
};

function squareToSzzZValue850(){
    value45Save = "zSqrArtSpecz850";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs850").src = tripleZeroA;
};

function squareToSzzZValue851(){
    value45Save = "zSqrArtSpecz851";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs851").src = tripleZeroA;
};

function squareToSzzZValue852(){
    value45Save = "zSqrArtSpecz852";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs852").src = tripleZeroA;
};

function squareToSzzZValue853(){
    value45Save = "zSqrArtSpecz853";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs853").src = tripleZeroA;
};

function squareToSzzZValue854(){
    value45Save = "zSqrArtSpecz854";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs854").src = tripleZeroA;
};

function squareToSzzZValue855(){
    value45Save = "zSqrArtSpecz855";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs855").src = tripleZeroA;
};

function squareToSzzZValue856(){
    value45Save = "zSqrArtSpecz856";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs856").src = tripleZeroA;
};

function squareToSzzZValue857(){
    value45Save = "zSqrArtSpecz857";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs857").src = tripleZeroA;
};

function squareToSzzZValue858(){
    value45Save = "zSqrArtSpecz858";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs858").src = tripleZeroA;
};

function squareToSzzZValue859(){
    value45Save = "zSqrArtSpecz859";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs859").src = tripleZeroA;
};

function squareToSzzZValue860(){
    value45Save = "zSqrArtSpecz860";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs860").src = tripleZeroA;
};

function squareToSzzZValue861(){
    value45Save = "zSqrArtSpecz861";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs861").src = tripleZeroA;
};

function squareToSzzZValue862(){
    value45Save = "zSqrArtSpecz862";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs862").src = tripleZeroA;
};

function squareToSzzZValue863(){
    value45Save = "zSqrArtSpecz863";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs863").src = tripleZeroA;
};

function squareToSzzZValue864(){
    value45Save = "zSqrArtSpecz864";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs864").src = tripleZeroA;
};

function squareToSzzZValue865(){
    value45Save = "zSqrArtSpecz865";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs865").src = tripleZeroA;
};

function squareToSzzZValue866(){
    value45Save = "zSqrArtSpecz866";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs866").src = tripleZeroA;
};

function squareToSzzZValue867(){
    value45Save = "zSqrArtSpecz867";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs867").src = tripleZeroA;
};

function squareToSzzZValue868(){
    value45Save = "zSqrArtSpecz868";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs868").src = tripleZeroA;
};

function squareToSzzZValue869(){
    value45Save = "zSqrArtSpecz869";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs869").src = tripleZeroA;
};

function squareToSzzZValue870(){
    value45Save = "zSqrArtSpecz870";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs870").src = tripleZeroA;
};

function squareToSzzZValue871(){
    value45Save = "zSqrArtSpecz871";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs871").src = tripleZeroA;
};

function squareToSzzZValue872(){
    value45Save = "zSqrArtSpecz872";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs872").src = tripleZeroA;
};

function squareToSzzZValue873(){
    value45Save = "zSqrArtSpecz873";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs873").src = tripleZeroA;
};

function squareToSzzZValue874(){
    value45Save = "zSqrArtSpecz874";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs874").src = tripleZeroA;
};

function squareToSzzZValue875(){
    value45Save = "zSqrArtSpecz875";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs875").src = tripleZeroA;
};

function squareToSzzZValue876(){
    value45Save = "zSqrArtSpecz876";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs876").src = tripleZeroA;
};

function squareToSzzZValue877(){
    value45Save = "zSqrArtSpecz877";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs877").src = tripleZeroA;
};

function squareToSzzZValue878(){
    value45Save = "zSqrArtSpecz878";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs878").src = tripleZeroA;
};

function squareToSzzZValue879(){
    value45Save = "zSqrArtSpecz879";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs879").src = tripleZeroA;
};

function squareToSzzZValue880(){
    value45Save = "zSqrArtSpecz880";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs880").src = tripleZeroA;
};

function squareToSzzZValue881(){
    value45Save = "zSqrArtSpecz881";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs881").src = tripleZeroA;
};

function squareToSzzZValue882(){
    value45Save = "zSqrArtSpecz882";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs882").src = tripleZeroA;
};

function squareToSzzZValue883(){
    value45Save = "zSqrArtSpecz883";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs883").src = tripleZeroA;
};

function squareToSzzZValue884(){
    value45Save = "zSqrArtSpecz884";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs884").src = tripleZeroA;
};

function squareToSzzZValue885(){
    value45Save = "zSqrArtSpecz885";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs885").src = tripleZeroA;
};

function squareToSzzZValue886(){
    value45Save = "zSqrArtSpecz886";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs886").src = tripleZeroA;
};

function squareToSzzZValue887(){
    value45Save = "zSqrArtSpecz887";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs887").src = tripleZeroA;
};

function squareToSzzZValue888(){
    value45Save = "zSqrArtSpecz888";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs888").src = tripleZeroA;
};

function squareToSzzZValue889(){
    value45Save = "zSqrArtSpecz889";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs889").src = tripleZeroA;
};

function squareToSzzZValue890(){
    value45Save = "zSqrArtSpecz890";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs890").src = tripleZeroA;
};

function squareToSzzZValue891(){
    value45Save = "zSqrArtSpecz891";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs891").src = tripleZeroA;
};

function squareToSzzZValue892(){
    value45Save = "zSqrArtSpecz892";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs892").src = tripleZeroA;
};

function squareToSzzZValue893(){
    value45Save = "zSqrArtSpecz893";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs893").src = tripleZeroA;
};

function squareToSzzZValue894(){
    value45Save = "zSqrArtSpecz894";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs894").src = tripleZeroA;
};

function squareToSzzZValue895(){
    value45Save = "zSqrArtSpecz895";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs895").src = tripleZeroA;
};

function squareToSzzZValue896(){
    value45Save = "zSqrArtSpecz896";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs896").src = tripleZeroA;
};

function squareToSzzZValue897(){
    value45Save = "zSqrArtSpecz897";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs897").src = tripleZeroA;
};

function squareToSzzZValue898(){
    value45Save = "zSqrArtSpecz898";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs898").src = tripleZeroA;
};

function squareToSzzZValue899(){
    value45Save = "zSqrArtSpecz899";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs899").src = tripleZeroA;
};

function squareToSzzZValue900(){
    value45Save = "zSqrArtSpecz900";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs900").src = tripleZeroA;
};

function squareToSzzZValue901(){
    value45Save = "zSqrArtSpecz901";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs901").src = tripleZeroA;
};

function squareToSzzZValue902(){
    value45Save = "zSqrArtSpecz902";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs902").src = tripleZeroA;
};

function squareToSzzZValue903(){
    value45Save = "zSqrArtSpecz903";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs903").src = tripleZeroA;
};

function squareToSzzZValue904(){
    value45Save = "zSqrArtSpecz904";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs904").src = tripleZeroA;
};

function squareToSzzZValue905(){
    value45Save = "zSqrArtSpecz905";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs905").src = tripleZeroA;
};

function squareToSzzZValue906(){
    value45Save = "zSqrArtSpecz906";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs906").src = tripleZeroA;
};

function squareToSzzZValue907(){
    value45Save = "zSqrArtSpecz907";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs907").src = tripleZeroA;
};

function squareToSzzZValue908(){
    value45Save = "zSqrArtSpecz908";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs908").src = tripleZeroA;
};

function squareToSzzZValue909(){
    value45Save = "zSqrArtSpecz909";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs909").src = tripleZeroA;
};

function squareToSzzZValue910(){
    value45Save = "zSqrArtSpecz910";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs910").src = tripleZeroA;
};

function squareToSzzZValue911(){
    value45Save = "zSqrArtSpecz911";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs911").src = tripleZeroA;
};

function squareToSzzZValue912(){
    value45Save = "zSqrArtSpecz912";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs912").src = tripleZeroA;
};

function squareToSzzZValue913(){
    value45Save = "zSqrArtSpecz913";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs913").src = tripleZeroA;
};

function squareToSzzZValue914(){
    value45Save = "zSqrArtSpecz914";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs914").src = tripleZeroA;
};

function squareToSzzZValue915(){
    value45Save = "zSqrArtSpecz915";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs915").src = tripleZeroA;
};

function squareToSzzZValue916(){
    value45Save = "zSqrArtSpecz916";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs916").src = tripleZeroA;
};

function squareToSzzZValue917(){
    value45Save = "zSqrArtSpecz917";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs917").src = tripleZeroA;
};

function squareToSzzZValue918(){
    value45Save = "zSqrArtSpecz918";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs918").src = tripleZeroA;
};

function squareToSzzZValue919(){
    value45Save = "zSqrArtSpecz919";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs919").src = tripleZeroA;
};

function squareToSzzZValue920(){
    value45Save = "zSqrArtSpecz920";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs920").src = tripleZeroA;
};

function squareToSzzZValue921(){
    value45Save = "zSqrArtSpecz921";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs921").src = tripleZeroA;
};

function squareToSzzZValue922(){
    value45Save = "zSqrArtSpecz922";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs922").src = tripleZeroA;
};

function squareToSzzZValue923(){
    value45Save = "zSqrArtSpecz923";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs923").src = tripleZeroA;
};

function squareToSzzZValue924(){
    value45Save = "zSqrArtSpecz924";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs924").src = tripleZeroA;
};

function squareToSzzZValue925(){
    value45Save = "zSqrArtSpecz925";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs925").src = tripleZeroA;
};

function squareToSzzZValue926(){
    value45Save = "zSqrArtSpecz926";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs926").src = tripleZeroA;
};

function squareToSzzZValue927(){
    value45Save = "zSqrArtSpecz927";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs927").src = tripleZeroA;
};

function squareToSzzZValue928(){
    value45Save = "zSqrArtSpecz928";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs928").src = tripleZeroA;
};

function squareToSzzZValue929(){
    value45Save = "zSqrArtSpecz929";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs929").src = tripleZeroA;
};

function squareToSzzZValue930(){
    value45Save = "zSqrArtSpecz930";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs930").src = tripleZeroA;
};

function squareToSzzZValue931(){
    value45Save = "zSqrArtSpecz931";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs931").src = tripleZeroA;
};

function squareToSzzZValue932(){
    value45Save = "zSqrArtSpecz932";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs932").src = tripleZeroA;
};

function squareToSzzZValue933(){
    value45Save = "zSqrArtSpecz933";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs933").src = tripleZeroA;
};

function squareToSzzZValue934(){
    value45Save = "zSqrArtSpecz934";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs934").src = tripleZeroA;
};

function squareToSzzZValue935(){
    value45Save = "zSqrArtSpecz935";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs935").src = tripleZeroA;
};

function squareToSzzZValue936(){
    value45Save = "zSqrArtSpecz936";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs936").src = tripleZeroA;
};

function squareToSzzZValue937(){
    value45Save = "zSqrArtSpecz937";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs937").src = tripleZeroA;
};

function squareToSzzZValue938(){
    value45Save = "zSqrArtSpecz938";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs938").src = tripleZeroA;
};

function squareToSzzZValue939(){
    value45Save = "zSqrArtSpecz939";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs939").src = tripleZeroA;
};

function squareToSzzZValue940(){
    value45Save = "zSqrArtSpecz940";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs940").src = tripleZeroA;
};

function squareToSzzZValue941(){
    value45Save = "zSqrArtSpecz941";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs941").src = tripleZeroA;
};

function squareToSzzZValue942(){
    value45Save = "zSqrArtSpecz942";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs942").src = tripleZeroA;
};

function squareToSzzZValue943(){
    value45Save = "zSqrArtSpecz943";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs943").src = tripleZeroA;
};

function squareToSzzZValue944(){
    value45Save = "zSqrArtSpecz944";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs944").src = tripleZeroA;
};

function squareToSzzZValue945(){
    value45Save = "zSqrArtSpecz945";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs945").src = tripleZeroA;
};

function squareToSzzZValue946(){
    value45Save = "zSqrArtSpecz946";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs946").src = tripleZeroA;
};

function squareToSzzZValue947(){
    value45Save = "zSqrArtSpecz947";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs947").src = tripleZeroA;
};

function squareToSzzZValue948(){
    value45Save = "zSqrArtSpecz948";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs948").src = tripleZeroA;
};

function squareToSzzZValue949(){
    value45Save = "zSqrArtSpecz949";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs949").src = tripleZeroA;
};

function squareToSzzZValue950(){
    value45Save = "zSqrArtSpecz950";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs950").src = tripleZeroA;
};

function squareToSzzZValue951(){
    value45Save = "zSqrArtSpecz951";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs951").src = tripleZeroA;
};

function squareToSzzZValue952(){
    value45Save = "zSqrArtSpecz952";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs952").src = tripleZeroA;
};

function squareToSzzZValue953(){
    value45Save = "zSqrArtSpecz953";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs953").src = tripleZeroA;
};

function squareToSzzZValue954(){
    value45Save = "zSqrArtSpecz954";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs954").src = tripleZeroA;
};

function squareToSzzZValue955(){
    value45Save = "zSqrArtSpecz955";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs955").src = tripleZeroA;
};

function squareToSzzZValue956(){
    value45Save = "zSqrArtSpecz956";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs956").src = tripleZeroA;
};

function squareToSzzZValue957(){
    value45Save = "zSqrArtSpecz957";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs957").src = tripleZeroA;
};

function squareToSzzZValue958(){
    value45Save = "zSqrArtSpecz958";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs958").src = tripleZeroA;
};

function squareToSzzZValue959(){
    value45Save = "zSqrArtSpecz959";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs959").src = tripleZeroA;
};

function squareToSzzZValue960(){
    value45Save = "zSqrArtSpecz960";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs960").src = tripleZeroA;
};

function squareToSzzZValue961(){
    value45Save = "zSqrArtSpecz961";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs961").src = tripleZeroA;
};

function squareToSzzZValue962(){
    value45Save = "zSqrArtSpecz962";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs962").src = tripleZeroA;
};

function squareToSzzZValue963(){
    value45Save = "zSqrArtSpecz963";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs963").src = tripleZeroA;
};

function squareToSzzZValue964(){
    value45Save = "zSqrArtSpecz964";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs964").src = tripleZeroA;
};

function squareToSzzZValue965(){
    value45Save = "zSqrArtSpecz965";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs965").src = tripleZeroA;
};

function squareToSzzZValue966(){
    value45Save = "zSqrArtSpecz966";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs966").src = tripleZeroA;
};

function squareToSzzZValue967(){
    value45Save = "zSqrArtSpecz967";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs967").src = tripleZeroA;
};

function squareToSzzZValue968(){
    value45Save = "zSqrArtSpecz968";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs968").src = tripleZeroA;
};

function squareToSzzZValue969(){
    value45Save = "zSqrArtSpecz969";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs969").src = tripleZeroA;
};

function squareToSzzZValue970(){
    value45Save = "zSqrArtSpecz970";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs970").src = tripleZeroA;
};

function squareToSzzZValue971(){
    value45Save = "zSqrArtSpecz971";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs971").src = tripleZeroA;
};

function squareToSzzZValue972(){
    value45Save = "zSqrArtSpecz972";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs972").src = tripleZeroA;
};

function squareToSzzZValue973(){
    value45Save = "zSqrArtSpecz973";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs973").src = tripleZeroA;
};

function squareToSzzZValue974(){
    value45Save = "zSqrArtSpecz974";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs974").src = tripleZeroA;
};

function squareToSzzZValue975(){
    value45Save = "zSqrArtSpecz975";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs975").src = tripleZeroA;
};

function squareToSzzZValue976(){
    value45Save = "zSqrArtSpecz976";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs976").src = tripleZeroA;
};

function squareToSzzZValue977(){
    value45Save = "zSqrArtSpecz977";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs977").src = tripleZeroA;
};

function squareToSzzZValue978(){
    value45Save = "zSqrArtSpecz978";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs978").src = tripleZeroA;
};

function squareToSzzZValue979(){
    value45Save = "zSqrArtSpecz979";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs979").src = tripleZeroA;
};

function squareToSzzZValue980(){
    value45Save = "zSqrArtSpecz980";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs980").src = tripleZeroA;
};

function squareToSzzZValue981(){
    value45Save = "zSqrArtSpecz981";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs981").src = tripleZeroA;
};

function squareToSzzZValue982(){
    value45Save = "zSqrArtSpecz982";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs982").src = tripleZeroA;
};

function squareToSzzZValue983(){
    value45Save = "zSqrArtSpecz983";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs983").src = tripleZeroA;
};

function squareToSzzZValue984(){
    value45Save = "zSqrArtSpecz984";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs984").src = tripleZeroA;
};

function squareToSzzZValue985(){
    value45Save = "zSqrArtSpecz985";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs985").src = tripleZeroA;
};

function squareToSzzZValue986(){
    value45Save = "zSqrArtSpecz986";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs986").src = tripleZeroA;
};

function squareToSzzZValue987(){
    value45Save = "zSqrArtSpecz987";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs987").src = tripleZeroA;
};

function squareToSzzZValue988(){
    value45Save = "zSqrArtSpecz988";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs988").src = tripleZeroA;
};

function squareToSzzZValue989(){
    value45Save = "zSqrArtSpecz989";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs989").src = tripleZeroA;
};

function squareToSzzZValue990(){
    value45Save = "zSqrArtSpecz990";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs990").src = tripleZeroA;
};

function squareToSzzZValue991(){
    value45Save = "zSqrArtSpecz991";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs991").src = tripleZeroA;
};

function squareToSzzZValue992(){
    value45Save = "zSqrArtSpecz992";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs992").src = tripleZeroA;
};

function squareToSzzZValue993(){
    value45Save = "zSqrArtSpecz993";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs993").src = tripleZeroA;
};

function squareToSzzZValue994(){
    value45Save = "zSqrArtSpecz994";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs994").src = tripleZeroA;
};

function squareToSzzZValue995(){
    value45Save = "zSqrArtSpecz995";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs995").src = tripleZeroA;
};

function squareToSzzZValue996(){
    value45Save = "zSqrArtSpecz996";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs996").src = tripleZeroA;
};

function squareToSzzZValue997(){
    value45Save = "zSqrArtSpecz997";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs997").src = tripleZeroA;
};

function squareToSzzZValue998(){
    value45Save = "zSqrArtSpecz998";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs998").src = tripleZeroA;
};

function squareToSzzZValue999(){
    value45Save = "zSqrArtSpecz999";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs999").src = tripleZeroA;
};

function squareToSzzZValue1000(){
    value45Save = "zSqrArtSpecz1000";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1000").src = tripleZeroA;
};

function squareToSzzZValue1001(){
    value45Save = "zSqrArtSpecz1001";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1001").src = tripleZeroA;
};

function squareToSzzZValue1002(){
    value45Save = "zSqrArtSpecz1002";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1002").src = tripleZeroA;
};

function squareToSzzZValue1003(){
    value45Save = "zSqrArtSpecz1003";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1003").src = tripleZeroA;
};

function squareToSzzZValue1004(){
    value45Save = "zSqrArtSpecz1004";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1004").src = tripleZeroA;
};

function squareToSzzZValue1005(){
    value45Save = "zSqrArtSpecz1005";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1005").src = tripleZeroA;
};

function squareToSzzZValue1006(){
    value45Save = "zSqrArtSpecz1006";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1006").src = tripleZeroA;
};

function squareToSzzZValue1007(){
    value45Save = "zSqrArtSpecz1007";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1007").src = tripleZeroA;
};

function squareToSzzZValue1008(){
    value45Save = "zSqrArtSpecz1008";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1008").src = tripleZeroA;
};

function squareToSzzZValue1009(){
    value45Save = "zSqrArtSpecz1009";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1009").src = tripleZeroA;
};

function squareToSzzZValue1010(){
    value45Save = "zSqrArtSpecz1010";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1010").src = tripleZeroA;
};

function squareToSzzZValue1011(){
    value45Save = "zSqrArtSpecz1011";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1011").src = tripleZeroA;
};

function squareToSzzZValue1012(){
    value45Save = "zSqrArtSpecz1012";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1012").src = tripleZeroA;
};

function squareToSzzZValue1013(){
    value45Save = "zSqrArtSpecz1013";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1013").src = tripleZeroA;
};

function squareToSzzZValue1014(){
    value45Save = "zSqrArtSpecz1014";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1014").src = tripleZeroA;
};

function squareToSzzZValue1015(){
    value45Save = "zSqrArtSpecz1015";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1015").src = tripleZeroA;
};

function squareToSzzZValue1016(){
    value45Save = "zSqrArtSpecz1016";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1016").src = tripleZeroA;
};

function squareToSzzZValue1017(){
    value45Save = "zSqrArtSpecz1017";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1017").src = tripleZeroA;
};

function squareToSzzZValue1018(){
    value45Save = "zSqrArtSpecz1018";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1018").src = tripleZeroA;
};

function squareToSzzZValue1019(){
    value45Save = "zSqrArtSpecz1019";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1019").src = tripleZeroA;
};

function squareToSzzZValue1020(){
    value45Save = "zSqrArtSpecz1020";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1020").src = tripleZeroA;
};

function squareToSzzZValue1021(){
    value45Save = "zSqrArtSpecz1021";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1021").src = tripleZeroA;
};

function squareToSzzZValue1022(){
    value45Save = "zSqrArtSpecz1022";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1022").src = tripleZeroA;
};

function squareToSzzZValue1023(){
    value45Save = "zSqrArtSpecz1023";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1023").src = tripleZeroA;
};

function squareToSzzZValue1024(){
    value45Save = "zSqrArtSpecz1024";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1024").src = tripleZeroA;
};

function squareToSzzZValue1025(){
    value45Save = "zSqrArtSpecz1025";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1025").src = tripleZeroA;
};

function squareToSzzZValue1026(){
    value45Save = "zSqrArtSpecz1026";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1026").src = tripleZeroA;
};

function squareToSzzZValue1027(){
    value45Save = "zSqrArtSpecz1027";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1027").src = tripleZeroA;
};

function squareToSzzZValue1028(){
    value45Save = "zSqrArtSpecz1028";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1028").src = tripleZeroA;
};

function squareToSzzZValue1029(){
    value45Save = "zSqrArtSpecz1029";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1029").src = tripleZeroA;
};

function squareToSzzZValue1030(){
    value45Save = "zSqrArtSpecz1030";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1030").src = tripleZeroA;
};

function squareToSzzZValue1031(){
    value45Save = "zSqrArtSpecz1031";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1031").src = tripleZeroA;
};

function squareToSzzZValue1032(){
    value45Save = "zSqrArtSpecz1032";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1032").src = tripleZeroA;
};

function squareToSzzZValue1033(){
    value45Save = "zSqrArtSpecz1033";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1033").src = tripleZeroA;
};

function squareToSzzZValue1034(){
    value45Save = "zSqrArtSpecz1034";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1034").src = tripleZeroA;
};

function squareToSzzZValue1035(){
    value45Save = "zSqrArtSpecz1035";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1035").src = tripleZeroA;
};

function squareToSzzZValue1036(){
    value45Save = "zSqrArtSpecz1036";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1036").src = tripleZeroA;
};

function squareToSzzZValue1037(){
    value45Save = "zSqrArtSpecz1037";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1037").src = tripleZeroA;
};

function squareToSzzZValue1038(){
    value45Save = "zSqrArtSpecz1038";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1038").src = tripleZeroA;
};

function squareToSzzZValue1039(){
    value45Save = "zSqrArtSpecz1039";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1039").src = tripleZeroA;
};

function squareToSzzZValue1040(){
    value45Save = "zSqrArtSpecz1040";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1040").src = tripleZeroA;
};

function squareToSzzZValue1041(){
    value45Save = "zSqrArtSpecz1041";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1041").src = tripleZeroA;
};

function squareToSzzZValue1042(){
    value45Save = "zSqrArtSpecz1042";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1042").src = tripleZeroA;
};

function squareToSzzZValue1043(){
    value45Save = "zSqrArtSpecz1043";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1043").src = tripleZeroA;
};

function squareToSzzZValue1044(){
    value45Save = "zSqrArtSpecz1044";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1044").src = tripleZeroA;
};

function squareToSzzZValue1045(){
    value45Save = "zSqrArtSpecz1045";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1045").src = tripleZeroA;
};

function squareToSzzZValue1046(){
    value45Save = "zSqrArtSpecz1046";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1046").src = tripleZeroA;
};

function squareToSzzZValue1047(){
    value45Save = "zSqrArtSpecz1047";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1047").src = tripleZeroA;
};

function squareToSzzZValue1048(){
    value45Save = "zSqrArtSpecz1048";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1048").src = tripleZeroA;
};

function squareToSzzZValue1049(){
    value45Save = "zSqrArtSpecz1049";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1049").src = tripleZeroA;
};

function squareToSzzZValue1050(){
    value45Save = "zSqrArtSpecz1050";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1050").src = tripleZeroA;
};

function squareToSzzZValue1051(){
    value45Save = "zSqrArtSpecz1051";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1051").src = tripleZeroA;
};

function squareToSzzZValue1052(){
    value45Save = "zSqrArtSpecz1052";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1052").src = tripleZeroA;
};

function squareToSzzZValue1053(){
    value45Save = "zSqrArtSpecz1053";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1053").src = tripleZeroA;
};

function squareToSzzZValue1054(){
    value45Save = "zSqrArtSpecz1054";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1054").src = tripleZeroA;
};

function squareToSzzZValue1055(){
    value45Save = "zSqrArtSpecz1055";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1055").src = tripleZeroA;
};

function squareToSzzZValue1056(){
    value45Save = "zSqrArtSpecz1056";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1056").src = tripleZeroA;
};

function squareToSzzZValue1057(){
    value45Save = "zSqrArtSpecz1057";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1057").src = tripleZeroA;
};

function squareToSzzZValue1058(){
    value45Save = "zSqrArtSpecz1058";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1058").src = tripleZeroA;
};

function squareToSzzZValue1059(){
    value45Save = "zSqrArtSpecz1059";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1059").src = tripleZeroA;
};

function squareToSzzZValue1060(){
    value45Save = "zSqrArtSpecz1060";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1060").src = tripleZeroA;
};

function squareToSzzZValue1061(){
    value45Save = "zSqrArtSpecz1061";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1061").src = tripleZeroA;
};

function squareToSzzZValue1062(){
    value45Save = "zSqrArtSpecz1062";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1062").src = tripleZeroA;
};

function squareToSzzZValue1063(){
    value45Save = "zSqrArtSpecz1063";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1063").src = tripleZeroA;
};

function squareToSzzZValue1064(){
    value45Save = "zSqrArtSpecz1064";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1064").src = tripleZeroA;
};

function squareToSzzZValue1065(){
    value45Save = "zSqrArtSpecz1065";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1065").src = tripleZeroA;
};

function squareToSzzZValue1066(){
    value45Save = "zSqrArtSpecz1066";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1066").src = tripleZeroA;
};

function squareToSzzZValue1067(){
    value45Save = "zSqrArtSpecz1067";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1067").src = tripleZeroA;
};

function squareToSzzZValue1068(){
    value45Save = "zSqrArtSpecz1068";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1068").src = tripleZeroA;
};

function squareToSzzZValue1069(){
    value45Save = "zSqrArtSpecz1069";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1069").src = tripleZeroA;
};

function squareToSzzZValue1070(){
    value45Save = "zSqrArtSpecz1070";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1070").src = tripleZeroA;
};

function squareToSzzZValue1071(){
    value45Save = "zSqrArtSpecz1071";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1071").src = tripleZeroA;
};

function squareToSzzZValue1072(){
    value45Save = "zSqrArtSpecz1072";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1072").src = tripleZeroA;
};

function squareToSzzZValue1073(){
    value45Save = "zSqrArtSpecz1073";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1073").src = tripleZeroA;
};

function squareToSzzZValue1074(){
    value45Save = "zSqrArtSpecz1074";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1074").src = tripleZeroA;
};

function squareToSzzZValue1075(){
    value45Save = "zSqrArtSpecz1075";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1075").src = tripleZeroA;
};

function squareToSzzZValue1076(){
    value45Save = "zSqrArtSpecz1076";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1076").src = tripleZeroA;
};

function squareToSzzZValue1077(){
    value45Save = "zSqrArtSpecz1077";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1077").src = tripleZeroA;
};

function squareToSzzZValue1078(){
    value45Save = "zSqrArtSpecz1078";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1078").src = tripleZeroA;
};

function squareToSzzZValue1079(){
    value45Save = "zSqrArtSpecz1079";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1079").src = tripleZeroA;
};

function squareToSzzZValue1080(){
    value45Save = "zSqrArtSpecz1080";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1080").src = tripleZeroA;
};

function squareToSzzZValue1081(){
    value45Save = "zSqrArtSpecz1081";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1081").src = tripleZeroA;
};

function squareToSzzZValue1082(){
    value45Save = "zSqrArtSpecz1082";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1082").src = tripleZeroA;
};

function squareToSzzZValue1083(){
    value45Save = "zSqrArtSpecz1083";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1083").src = tripleZeroA;
};

function squareToSzzZValue1084(){
    value45Save = "zSqrArtSpecz1084";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1084").src = tripleZeroA;
};

function squareToSzzZValue1085(){
    value45Save = "zSqrArtSpecz1085";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1085").src = tripleZeroA;
};

function squareToSzzZValue1086(){
    value45Save = "zSqrArtSpecz1086";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1086").src = tripleZeroA;
};

function squareToSzzZValue1087(){
    value45Save = "zSqrArtSpecz1087";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1087").src = tripleZeroA;
};

function squareToSzzZValue1088(){
    value45Save = "zSqrArtSpecz1088";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1088").src = tripleZeroA;
};

function squareToSzzZValue1089(){
    value45Save = "zSqrArtSpecz1089";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1089").src = tripleZeroA;
};

function squareToSzzZValue1090(){
    value45Save = "zSqrArtSpecz1090";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1090").src = tripleZeroA;
};

function squareToSzzZValue1091(){
    value45Save = "zSqrArtSpecz1091";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1091").src = tripleZeroA;
};

function squareToSzzZValue1092(){
    value45Save = "zSqrArtSpecz1092";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1092").src = tripleZeroA;
};

function squareToSzzZValue1093(){
    value45Save = "zSqrArtSpecz1093";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1093").src = tripleZeroA;
};

function squareToSzzZValue1094(){
    value45Save = "zSqrArtSpecz1094";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1094").src = tripleZeroA;
};

function squareToSzzZValue1095(){
    value45Save = "zSqrArtSpecz1095";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1095").src = tripleZeroA;
};

function squareToSzzZValue1096(){
    value45Save = "zSqrArtSpecz1096";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1096").src = tripleZeroA;
};

function squareToSzzZValue1097(){
    value45Save = "zSqrArtSpecz1097";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1097").src = tripleZeroA;
};

function squareToSzzZValue1098(){
    value45Save = "zSqrArtSpecz1098";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1098").src = tripleZeroA;
};

function squareToSzzZValue1099(){
    value45Save = "zSqrArtSpecz1099";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1099").src = tripleZeroA;
};

function squareToSzzZValue1100(){
    value45Save = "zSqrArtSpecz1100";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1100").src = tripleZeroA;
};

function squareToSzzZValue1101(){
    value45Save = "zSqrArtSpecz1101";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1101").src = tripleZeroA;
};

function squareToSzzZValue1102(){
    value45Save = "zSqrArtSpecz1102";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1102").src = tripleZeroA;
};

function squareToSzzZValue1103(){
    value45Save = "zSqrArtSpecz1103";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1103").src = tripleZeroA;
};

function squareToSzzZValue1104(){
    value45Save = "zSqrArtSpecz1104";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1104").src = tripleZeroA;
};

function squareToSzzZValue1105(){
    value45Save = "zSqrArtSpecz1105";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1105").src = tripleZeroA;
};

function squareToSzzZValue1106(){
    value45Save = "zSqrArtSpecz1106";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1106").src = tripleZeroA;
};

function squareToSzzZValue1107(){
    value45Save = "zSqrArtSpecz1107";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1107").src = tripleZeroA;
};

function squareToSzzZValue1108(){
    value45Save = "zSqrArtSpecz1108";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1108").src = tripleZeroA;
};

function squareToSzzZValue1109(){
    value45Save = "zSqrArtSpecz1109";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1109").src = tripleZeroA;
};

function squareToSzzZValue1110(){
    value45Save = "zSqrArtSpecz1110";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1110").src = tripleZeroA;
};

function squareToSzzZValue1111(){
    value45Save = "zSqrArtSpecz1111";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1111").src = tripleZeroA;
};

function squareToSzzZValue1112(){
    value45Save = "zSqrArtSpecz1112";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1112").src = tripleZeroA;
};

function squareToSzzZValue1113(){
    value45Save = "zSqrArtSpecz1113";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1113").src = tripleZeroA;
};

function squareToSzzZValue1114(){
    value45Save = "zSqrArtSpecz1114";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1114").src = tripleZeroA;
};

function squareToSzzZValue1115(){
    value45Save = "zSqrArtSpecz1115";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1115").src = tripleZeroA;
};

function squareToSzzZValue1116(){
    value45Save = "zSqrArtSpecz1116";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1116").src = tripleZeroA;
};

function squareToSzzZValue1117(){
    value45Save = "zSqrArtSpecz1117";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1117").src = tripleZeroA;
};

function squareToSzzZValue1118(){
    value45Save = "zSqrArtSpecz1118";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1118").src = tripleZeroA;
};

function squareToSzzZValue1119(){
    value45Save = "zSqrArtSpecz1119";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1119").src = tripleZeroA;
};

function squareToSzzZValue1120(){
    value45Save = "zSqrArtSpecz1120";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1120").src = tripleZeroA;
};

function squareToSzzZValue1121(){
    value45Save = "zSqrArtSpecz1121";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1121").src = tripleZeroA;
};

function squareToSzzZValue1122(){
    value45Save = "zSqrArtSpecz1122";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1122").src = tripleZeroA;
};

function squareToSzzZValue1123(){
    value45Save = "zSqrArtSpecz1123";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1123").src = tripleZeroA;
};

function squareToSzzZValue1124(){
    value45Save = "zSqrArtSpecz1124";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1124").src = tripleZeroA;
};

function squareToSzzZValue1125(){
    value45Save = "zSqrArtSpecz1125";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1125").src = tripleZeroA;
};

function squareToSzzZValue1126(){
    value45Save = "zSqrArtSpecz1126";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1126").src = tripleZeroA;
};

function squareToSzzZValue1127(){
    value45Save = "zSqrArtSpecz1127";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1127").src = tripleZeroA;
};

function squareToSzzZValue1128(){
    value45Save = "zSqrArtSpecz1128";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1128").src = tripleZeroA;
};

function squareToSzzZValue1129(){
    value45Save = "zSqrArtSpecz1129";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1129").src = tripleZeroA;
};

function squareToSzzZValue1130(){
    value45Save = "zSqrArtSpecz1130";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1130").src = tripleZeroA;
};

function squareToSzzZValue1131(){
    value45Save = "zSqrArtSpecz1131";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1131").src = tripleZeroA;
};

function squareToSzzZValue1132(){
    value45Save = "zSqrArtSpecz1132";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1132").src = tripleZeroA;
};

function squareToSzzZValue1133(){
    value45Save = "zSqrArtSpecz1133";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1133").src = tripleZeroA;
};

function squareToSzzZValue1134(){
    value45Save = "zSqrArtSpecz1134";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1134").src = tripleZeroA;
};

function squareToSzzZValue1135(){
    value45Save = "zSqrArtSpecz1135";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1135").src = tripleZeroA;
};

function squareToSzzZValue1136(){
    value45Save = "zSqrArtSpecz1136";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1136").src = tripleZeroA;
};

function squareToSzzZValue1137(){
    value45Save = "zSqrArtSpecz1137";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1137").src = tripleZeroA;
};

function squareToSzzZValue1138(){
    value45Save = "zSqrArtSpecz1138";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1138").src = tripleZeroA;
};

function squareToSzzZValue1139(){
    value45Save = "zSqrArtSpecz1139";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1139").src = tripleZeroA;
};

function squareToSzzZValue1140(){
    value45Save = "zSqrArtSpecz1140";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1140").src = tripleZeroA;
};

function squareToSzzZValue1141(){
    value45Save = "zSqrArtSpecz1141";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1141").src = tripleZeroA;
};

function squareToSzzZValue1142(){
    value45Save = "zSqrArtSpecz1142";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1142").src = tripleZeroA;
};

function squareToSzzZValue1143(){
    value45Save = "zSqrArtSpecz1143";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1143").src = tripleZeroA;
};

function squareToSzzZValue1144(){
    value45Save = "zSqrArtSpecz1144";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1144").src = tripleZeroA;
};

function squareToSzzZValue1145(){
    value45Save = "zSqrArtSpecz1145";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1145").src = tripleZeroA;
};

function squareToSzzZValue1146(){
    value45Save = "zSqrArtSpecz1146";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1146").src = tripleZeroA;
};

function squareToSzzZValue1147(){
    value45Save = "zSqrArtSpecz1147";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1147").src = tripleZeroA;
};

function squareToSzzZValue1148(){
    value45Save = "zSqrArtSpecz1148";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1148").src = tripleZeroA;
};

function squareToSzzZValue1149(){
    value45Save = "zSqrArtSpecz1149";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1149").src = tripleZeroA;
};

function squareToSzzZValue1150(){
    value45Save = "zSqrArtSpecz1150";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1150").src = tripleZeroA;
};

function squareToSzzZValue1151(){
    value45Save = "zSqrArtSpecz1151";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1151").src = tripleZeroA;
};

function squareToSzzZValue1152(){
    value45Save = "zSqrArtSpecz1152";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1152").src = tripleZeroA;
};

function squareToSzzZValue1153(){
    value45Save = "zSqrArtSpecz1153";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1153").src = tripleZeroA;
};

function squareToSzzZValue1154(){
    value45Save = "zSqrArtSpecz1154";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1154").src = tripleZeroA;
};

function squareToSzzZValue1155(){
    value45Save = "zSqrArtSpecz1155";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1155").src = tripleZeroA;
};

function squareToSzzZValue1156(){
    value45Save = "zSqrArtSpecz1156";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1156").src = tripleZeroA;
};

function squareToSzzZValue1157(){
    value45Save = "zSqrArtSpecz1157";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1157").src = tripleZeroA;
};

function squareToSzzZValue1158(){
    value45Save = "zSqrArtSpecz1158";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1158").src = tripleZeroA;
};

function squareToSzzZValue1159(){
    value45Save = "zSqrArtSpecz1159";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1159").src = tripleZeroA;
};

function squareToSzzZValue1160(){
    value45Save = "zSqrArtSpecz1160";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1160").src = tripleZeroA;
};

function squareToSzzZValue1161(){
    value45Save = "zSqrArtSpecz1161";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1161").src = tripleZeroA;
};

function squareToSzzZValue1162(){
    value45Save = "zSqrArtSpecz1162";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1162").src = tripleZeroA;
};

function squareToSzzZValue1163(){
    value45Save = "zSqrArtSpecz1163";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1163").src = tripleZeroA;
};

function squareToSzzZValue1164(){
    value45Save = "zSqrArtSpecz1164";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1164").src = tripleZeroA;
};

function squareToSzzZValue1165(){
    value45Save = "zSqrArtSpecz1165";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1165").src = tripleZeroA;
};

function squareToSzzZValue1166(){
    value45Save = "zSqrArtSpecz1166";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1166").src = tripleZeroA;
};

function squareToSzzZValue1167(){
    value45Save = "zSqrArtSpecz1167";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1167").src = tripleZeroA;
};

function squareToSzzZValue1168(){
    value45Save = "zSqrArtSpecz1168";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1168").src = tripleZeroA;
};

function squareToSzzZValue1169(){
    value45Save = "zSqrArtSpecz1169";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1169").src = tripleZeroA;
};

function squareToSzzZValue1170(){
    value45Save = "zSqrArtSpecz1170";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1170").src = tripleZeroA;
};

function squareToSzzZValue1171(){
    value45Save = "zSqrArtSpecz1171";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1171").src = tripleZeroA;
};

function squareToSzzZValue1172(){
    value45Save = "zSqrArtSpecz1172";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1172").src = tripleZeroA;
};

function squareToSzzZValue1173(){
    value45Save = "zSqrArtSpecz1173";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1173").src = tripleZeroA;
};

function squareToSzzZValue1174(){
    value45Save = "zSqrArtSpecz1174";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1174").src = tripleZeroA;
};

function squareToSzzZValue1175(){
    value45Save = "zSqrArtSpecz1175";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1175").src = tripleZeroA;
};

function squareToSzzZValue1176(){
    value45Save = "zSqrArtSpecz1176";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1176").src = tripleZeroA;
};

function squareToSzzZValue1177(){
    value45Save = "zSqrArtSpecz1177";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1177").src = tripleZeroA;
};

function squareToSzzZValue1178(){
    value45Save = "zSqrArtSpecz1178";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1178").src = tripleZeroA;
};

function squareToSzzZValue1179(){
    value45Save = "zSqrArtSpecz1179";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1179").src = tripleZeroA;
};

function squareToSzzZValue1180(){
    value45Save = "zSqrArtSpecz1180";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1180").src = tripleZeroA;
};

function squareToSzzZValue1181(){
    value45Save = "zSqrArtSpecz1181";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1181").src = tripleZeroA;
};

function squareToSzzZValue1182(){
    value45Save = "zSqrArtSpecz1182";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1182").src = tripleZeroA;
};

function squareToSzzZValue1183(){
    value45Save = "zSqrArtSpecz1183";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1183").src = tripleZeroA;
};

function squareToSzzZValue1184(){
    value45Save = "zSqrArtSpecz1184";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1184").src = tripleZeroA;
};

function squareToSzzZValue1185(){
    value45Save = "zSqrArtSpecz1185";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1185").src = tripleZeroA;
};

function squareToSzzZValue1186(){
    value45Save = "zSqrArtSpecz1186";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1186").src = tripleZeroA;
};

function squareToSzzZValue1187(){
    value45Save = "zSqrArtSpecz1187";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1187").src = tripleZeroA;
};

function squareToSzzZValue1188(){
    value45Save = "zSqrArtSpecz1188";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1188").src = tripleZeroA;
};

function squareToSzzZValue1189(){
    value45Save = "zSqrArtSpecz1189";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1189").src = tripleZeroA;
};

function squareToSzzZValue1190(){
    value45Save = "zSqrArtSpecz1190";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1190").src = tripleZeroA;
};

function squareToSzzZValue1191(){
    value45Save = "zSqrArtSpecz1191";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1191").src = tripleZeroA;
};

function squareToSzzZValue1192(){
    value45Save = "zSqrArtSpecz1192";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1192").src = tripleZeroA;
};

function squareToSzzZValue1193(){
    value45Save = "zSqrArtSpecz1193";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1193").src = tripleZeroA;
};

function squareToSzzZValue1194(){
    value45Save = "zSqrArtSpecz1194";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1194").src = tripleZeroA;
};

function squareToSzzZValue1195(){
    value45Save = "zSqrArtSpecz1195";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1195").src = tripleZeroA;
};

function squareToSzzZValue1196(){
    value45Save = "zSqrArtSpecz1196";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1196").src = tripleZeroA;
};

function squareToSzzZValue1197(){
    value45Save = "zSqrArtSpecz1197";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1197").src = tripleZeroA;
};

function squareToSzzZValue1198(){
    value45Save = "zSqrArtSpecz1198";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1198").src = tripleZeroA;
};

function squareToSzzZValue1199(){
    value45Save = "zSqrArtSpecz1199";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1199").src = tripleZeroA;
};

function squareToSzzZValue1200(){
    value45Save = "zSqrArtSpecz1200";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1200").src = tripleZeroA;
};

function squareToSzzZValue1201(){
    value45Save = "zSqrArtSpecz1201";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1201").src = tripleZeroA;
};

function squareToSzzZValue1202(){
    value45Save = "zSqrArtSpecz1202";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1202").src = tripleZeroA;
};

function squareToSzzZValue1203(){
    value45Save = "zSqrArtSpecz1203";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1203").src = tripleZeroA;
};

function squareToSzzZValue1204(){
    value45Save = "zSqrArtSpecz1204";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1204").src = tripleZeroA;
};

function squareToSzzZValue1205(){
    value45Save = "zSqrArtSpecz1205";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1205").src = tripleZeroA;
};

function squareToSzzZValue1206(){
    value45Save = "zSqrArtSpecz1206";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1206").src = tripleZeroA;
};

function squareToSzzZValue1207(){
    value45Save = "zSqrArtSpecz1207";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1207").src = tripleZeroA;
};

function squareToSzzZValue1208(){
    value45Save = "zSqrArtSpecz1208";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1208").src = tripleZeroA;
};

function squareToSzzZValue1209(){
    value45Save = "zSqrArtSpecz1209";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1209").src = tripleZeroA;
};

function squareToSzzZValue1210(){
    value45Save = "zSqrArtSpecz1210";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1210").src = tripleZeroA;
};

function squareToSzzZValue1211(){
    value45Save = "zSqrArtSpecz1211";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1211").src = tripleZeroA;
};

function squareToSzzZValue1212(){
    value45Save = "zSqrArtSpecz1212";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1212").src = tripleZeroA;
};

function squareToSzzZValue1213(){
    value45Save = "zSqrArtSpecz1213";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1213").src = tripleZeroA;
};

function squareToSzzZValue1214(){
    value45Save = "zSqrArtSpecz1214";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1214").src = tripleZeroA;
};

function squareToSzzZValue1215(){
    value45Save = "zSqrArtSpecz1215";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1215").src = tripleZeroA;
};

function squareToSzzZValue1216(){
    value45Save = "zSqrArtSpecz1216";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1216").src = tripleZeroA;
};

function squareToSzzZValue1217(){
    value45Save = "zSqrArtSpecz1217";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1217").src = tripleZeroA;
};

function squareToSzzZValue1218(){
    value45Save = "zSqrArtSpecz1218";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1218").src = tripleZeroA;
};

function squareToSzzZValue1219(){
    value45Save = "zSqrArtSpecz1219";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1219").src = tripleZeroA;
};

function squareToSzzZValue1220(){
    value45Save = "zSqrArtSpecz1220";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1220").src = tripleZeroA;
};

function squareToSzzZValue1221(){
    value45Save = "zSqrArtSpecz1221";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1221").src = tripleZeroA;
};

function squareToSzzZValue1222(){
    value45Save = "zSqrArtSpecz1222";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1222").src = tripleZeroA;
};

function squareToSzzZValue1223(){
    value45Save = "zSqrArtSpecz1223";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1223").src = tripleZeroA;
};

function squareToSzzZValue1224(){
    value45Save = "zSqrArtSpecz1224";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1224").src = tripleZeroA;
};

function squareToSzzZValue1225(){
    value45Save = "zSqrArtSpecz1225";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1225").src = tripleZeroA;
};

function squareToSzzZValue1226(){
    value45Save = "zSqrArtSpecz1226";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1226").src = tripleZeroA;
};

function squareToSzzZValue1227(){
    value45Save = "zSqrArtSpecz1227";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1227").src = tripleZeroA;
};

function squareToSzzZValue1228(){
    value45Save = "zSqrArtSpecz1228";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1228").src = tripleZeroA;
};

function squareToSzzZValue1229(){
    value45Save = "zSqrArtSpecz1229";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1229").src = tripleZeroA;
};

function squareToSzzZValue1230(){
    value45Save = "zSqrArtSpecz1230";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1230").src = tripleZeroA;
};

function squareToSzzZValue1231(){
    value45Save = "zSqrArtSpecz1231";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1231").src = tripleZeroA;
};

function squareToSzzZValue1232(){
    value45Save = "zSqrArtSpecz1232";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1232").src = tripleZeroA;
};

function squareToSzzZValue1233(){
    value45Save = "zSqrArtSpecz1233";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1233").src = tripleZeroA;
};

function squareToSzzZValue1234(){
    value45Save = "zSqrArtSpecz1234";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1234").src = tripleZeroA;
};

function squareToSzzZValue1235(){
    value45Save = "zSqrArtSpecz1235";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1235").src = tripleZeroA;
};

function squareToSzzZValue1236(){
    value45Save = "zSqrArtSpecz1236";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1236").src = tripleZeroA;
};

function squareToSzzZValue1237(){
    value45Save = "zSqrArtSpecz1237";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1237").src = tripleZeroA;
};

function squareToSzzZValue1238(){
    value45Save = "zSqrArtSpecz1238";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1238").src = tripleZeroA;
};

function squareToSzzZValue1239(){
    value45Save = "zSqrArtSpecz1239";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1239").src = tripleZeroA;
};

function squareToSzzZValue1240(){
    value45Save = "zSqrArtSpecz1240";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1240").src = tripleZeroA;
};

function squareToSzzZValue1241(){
    value45Save = "zSqrArtSpecz1241";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1241").src = tripleZeroA;
};

function squareToSzzZValue1242(){
    value45Save = "zSqrArtSpecz1242";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1242").src = tripleZeroA;
};

function squareToSzzZValue1243(){
    value45Save = "zSqrArtSpecz1243";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1243").src = tripleZeroA;
};

function squareToSzzZValue1244(){
    value45Save = "zSqrArtSpecz1244";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1244").src = tripleZeroA;
};

function squareToSzzZValue1245(){
    value45Save = "zSqrArtSpecz1245";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1245").src = tripleZeroA;
};

function squareToSzzZValue1246(){
    value45Save = "zSqrArtSpecz1246";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1246").src = tripleZeroA;
};

function squareToSzzZValue1247(){
    value45Save = "zSqrArtSpecz1247";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1247").src = tripleZeroA;
};

function squareToSzzZValue1248(){
    value45Save = "zSqrArtSpecz1248";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1248").src = tripleZeroA;
};

function squareToSzzZValue1249(){
    value45Save = "zSqrArtSpecz1249";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1249").src = tripleZeroA;
};

function squareToSzzZValue1250(){
    value45Save = "zSqrArtSpecz1250";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1250").src = tripleZeroA;
};

function squareToSzzZValue1251(){
    value45Save = "zSqrArtSpecz1251";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1251").src = tripleZeroA;
};

function squareToSzzZValue1252(){
    value45Save = "zSqrArtSpecz1252";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1252").src = tripleZeroA;
};

function squareToSzzZValue1253(){
    value45Save = "zSqrArtSpecz1253";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1253").src = tripleZeroA;
};

function squareToSzzZValue1254(){
    value45Save = "zSqrArtSpecz1254";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1254").src = tripleZeroA;
};

function squareToSzzZValue1255(){
    value45Save = "zSqrArtSpecz1255";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1255").src = tripleZeroA;
};

function squareToSzzZValue1256(){
    value45Save = "zSqrArtSpecz1256";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1256").src = tripleZeroA;
};

function squareToSzzZValue1257(){
    value45Save = "zSqrArtSpecz1257";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1257").src = tripleZeroA;
};

function squareToSzzZValue1258(){
    value45Save = "zSqrArtSpecz1258";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1258").src = tripleZeroA;
};

function squareToSzzZValue1259(){
    value45Save = "zSqrArtSpecz1259";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1259").src = tripleZeroA;
};

function squareToSzzZValue1260(){
    value45Save = "zSqrArtSpecz1260";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1260").src = tripleZeroA;
};

function squareToSzzZValue1261(){
    value45Save = "zSqrArtSpecz1261";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1261").src = tripleZeroA;
};

function squareToSzzZValue1262(){
    value45Save = "zSqrArtSpecz1262";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1262").src = tripleZeroA;
};

function squareToSzzZValue1263(){
    value45Save = "zSqrArtSpecz1263";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1263").src = tripleZeroA;
};

function squareToSzzZValue1264(){
    value45Save = "zSqrArtSpecz1264";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1264").src = tripleZeroA;
};

function squareToSzzZValue1265(){
    value45Save = "zSqrArtSpecz1265";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1265").src = tripleZeroA;
};

function squareToSzzZValue1266(){
    value45Save = "zSqrArtSpecz1266";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1266").src = tripleZeroA;
};

function squareToSzzZValue1267(){
    value45Save = "zSqrArtSpecz1267";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1267").src = tripleZeroA;
};

function squareToSzzZValue1268(){
    value45Save = "zSqrArtSpecz1268";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1268").src = tripleZeroA;
};

function squareToSzzZValue1269(){
    value45Save = "zSqrArtSpecz1269";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1269").src = tripleZeroA;
};

function squareToSzzZValue1270(){
    value45Save = "zSqrArtSpecz1270";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1270").src = tripleZeroA;
};

function squareToSzzZValue1271(){
    value45Save = "zSqrArtSpecz1271";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1271").src = tripleZeroA;
};

function squareToSzzZValue1272(){
    value45Save = "zSqrArtSpecz1272";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1272").src = tripleZeroA;
};

function squareToSzzZValue1273(){
    value45Save = "zSqrArtSpecz1273";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1273").src = tripleZeroA;
};

function squareToSzzZValue1274(){
    value45Save = "zSqrArtSpecz1274";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1274").src = tripleZeroA;
};

function squareToSzzZValue1275(){
    value45Save = "zSqrArtSpecz1275";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1275").src = tripleZeroA;
};

function squareToSzzZValue1276(){
    value45Save = "zSqrArtSpecz1276";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1276").src = tripleZeroA;
};

function squareToSzzZValue1277(){
    value45Save = "zSqrArtSpecz1277";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1277").src = tripleZeroA;
};

function squareToSzzZValue1278(){
    value45Save = "zSqrArtSpecz1278";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1278").src = tripleZeroA;
};

function squareToSzzZValue1279(){
    value45Save = "zSqrArtSpecz1279";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1279").src = tripleZeroA;
};

function squareToSzzZValue1280(){
    value45Save = "zSqrArtSpecz1280";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1280").src = tripleZeroA;
};

function squareToSzzZValue1281(){
    value45Save = "zSqrArtSpecz1281";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1281").src = tripleZeroA;
};

function squareToSzzZValue1282(){
    value45Save = "zSqrArtSpecz1282";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1282").src = tripleZeroA;
};

function squareToSzzZValue1283(){
    value45Save = "zSqrArtSpecz1283";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1283").src = tripleZeroA;
};

function squareToSzzZValue1284(){
    value45Save = "zSqrArtSpecz1284";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1284").src = tripleZeroA;
};

function squareToSzzZValue1285(){
    value45Save = "zSqrArtSpecz1285";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1285").src = tripleZeroA;
};

function squareToSzzZValue1286(){
    value45Save = "zSqrArtSpecz1286";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1286").src = tripleZeroA;
};

function squareToSzzZValue1287(){
    value45Save = "zSqrArtSpecz1287";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1287").src = tripleZeroA;
};

function squareToSzzZValue1288(){
    value45Save = "zSqrArtSpecz1288";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1288").src = tripleZeroA;
};

function squareToSzzZValue1289(){
    value45Save = "zSqrArtSpecz1289";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1289").src = tripleZeroA;
};

function squareToSzzZValue1290(){
    value45Save = "zSqrArtSpecz1290";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1290").src = tripleZeroA;
};

function squareToSzzZValue1291(){
    value45Save = "zSqrArtSpecz1291";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1291").src = tripleZeroA;
};

function squareToSzzZValue1292(){
    value45Save = "zSqrArtSpecz1292";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1292").src = tripleZeroA;
};

function squareToSzzZValue1293(){
    value45Save = "zSqrArtSpecz1293";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1293").src = tripleZeroA;
};

function squareToSzzZValue1294(){
    value45Save = "zSqrArtSpecz1294";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1294").src = tripleZeroA;
};

function squareToSzzZValue1295(){
    value45Save = "zSqrArtSpecz1295";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1295").src = tripleZeroA;
};

function squareToSzzZValue1296(){
    value45Save = "zSqrArtSpecz1296";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1296").src = tripleZeroA;
};

function squareToSzzZValue1297(){
    value45Save = "zSqrArtSpecz1297";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1297").src = tripleZeroA;
};

function squareToSzzZValue1298(){
    value45Save = "zSqrArtSpecz1298";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1298").src = tripleZeroA;
};

function squareToSzzZValue1299(){
    value45Save = "zSqrArtSpecz1299";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1299").src = tripleZeroA;
};

function squareToSzzZValue1300(){
    value45Save = "zSqrArtSpecz1300";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1300").src = tripleZeroA;
};

function squareToSzzZValue1301(){
    value45Save = "zSqrArtSpecz1301";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1301").src = tripleZeroA;
};

function squareToSzzZValue1302(){
    value45Save = "zSqrArtSpecz1302";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1302").src = tripleZeroA;
};

function squareToSzzZValue1303(){
    value45Save = "zSqrArtSpecz1303";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1303").src = tripleZeroA;
};

function squareToSzzZValue1304(){
    value45Save = "zSqrArtSpecz1304";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1304").src = tripleZeroA;
};

function squareToSzzZValue1305(){
    value45Save = "zSqrArtSpecz1305";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1305").src = tripleZeroA;
};

function squareToSzzZValue1306(){
    value45Save = "zSqrArtSpecz1306";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1306").src = tripleZeroA;
};

function squareToSzzZValue1307(){
    value45Save = "zSqrArtSpecz1307";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1307").src = tripleZeroA;
};

function squareToSzzZValue1308(){
    value45Save = "zSqrArtSpecz1308";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1308").src = tripleZeroA;
};

function squareToSzzZValue1309(){
    value45Save = "zSqrArtSpecz1309";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1309").src = tripleZeroA;
};

function squareToSzzZValue1310(){
    value45Save = "zSqrArtSpecz1310";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1310").src = tripleZeroA;
};

function squareToSzzZValue1311(){
    value45Save = "zSqrArtSpecz1311";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1311").src = tripleZeroA;
};

function squareToSzzZValue1312(){
    value45Save = "zSqrArtSpecz1312";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1312").src = tripleZeroA;
};

function squareToSzzZValue1313(){
    value45Save = "zSqrArtSpecz1313";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1313").src = tripleZeroA;
};

function squareToSzzZValue1314(){
    value45Save = "zSqrArtSpecz1314";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1314").src = tripleZeroA;
};

function squareToSzzZValue1315(){
    value45Save = "zSqrArtSpecz1315";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1315").src = tripleZeroA;
};

function squareToSzzZValue1316(){
    value45Save = "zSqrArtSpecz1316";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1316").src = tripleZeroA;
};

function squareToSzzZValue1317(){
    value45Save = "zSqrArtSpecz1317";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1317").src = tripleZeroA;
};

function squareToSzzZValue1318(){
    value45Save = "zSqrArtSpecz1318";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1318").src = tripleZeroA;
};

function squareToSzzZValue1319(){
    value45Save = "zSqrArtSpecz1319";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1319").src = tripleZeroA;
};

function squareToSzzZValue1320(){
    value45Save = "zSqrArtSpecz1320";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1320").src = tripleZeroA;
};

function squareToSzzZValue1321(){
    value45Save = "zSqrArtSpecz1321";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1321").src = tripleZeroA;
};

function squareToSzzZValue1322(){
    value45Save = "zSqrArtSpecz1322";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1322").src = tripleZeroA;
};

function squareToSzzZValue1323(){
    value45Save = "zSqrArtSpecz1323";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1323").src = tripleZeroA;
};

function squareToSzzZValue1324(){
    value45Save = "zSqrArtSpecz1324";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1324").src = tripleZeroA;
};

function squareToSzzZValue1325(){
    value45Save = "zSqrArtSpecz1325";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1325").src = tripleZeroA;
};

function squareToSzzZValue1326(){
    value45Save = "zSqrArtSpecz1326";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1326").src = tripleZeroA;
};

function squareToSzzZValue1327(){
    value45Save = "zSqrArtSpecz1327";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1327").src = tripleZeroA;
};

function squareToSzzZValue1328(){
    value45Save = "zSqrArtSpecz1328";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1328").src = tripleZeroA;
};

function squareToSzzZValue1329(){
    value45Save = "zSqrArtSpecz1329";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1329").src = tripleZeroA;
};

function squareToSzzZValue1330(){
    value45Save = "zSqrArtSpecz1330";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1330").src = tripleZeroA;
};

function squareToSzzZValue1331(){
    value45Save = "zSqrArtSpecz1331";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1331").src = tripleZeroA;
};

function squareToSzzZValue1332(){
    value45Save = "zSqrArtSpecz1332";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1332").src = tripleZeroA;
};

function squareToSzzZValue1333(){
    value45Save = "zSqrArtSpecz1333";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1333").src = tripleZeroA;
};

function squareToSzzZValue1334(){
    value45Save = "zSqrArtSpecz1334";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1334").src = tripleZeroA;
};

function squareToSzzZValue1335(){
    value45Save = "zSqrArtSpecz1335";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1335").src = tripleZeroA;
};

function squareToSzzZValue1336(){
    value45Save = "zSqrArtSpecz1336";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1336").src = tripleZeroA;
};

function squareToSzzZValue1337(){
    value45Save = "zSqrArtSpecz1337";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1337").src = tripleZeroA;
};

function squareToSzzZValue1338(){
    value45Save = "zSqrArtSpecz1338";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1338").src = tripleZeroA;
};

function squareToSzzZValue1339(){
    value45Save = "zSqrArtSpecz1339";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1339").src = tripleZeroA;
};

function squareToSzzZValue1340(){
    value45Save = "zSqrArtSpecz1340";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1340").src = tripleZeroA;
};

function squareToSzzZValue1341(){
    value45Save = "zSqrArtSpecz1341";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1341").src = tripleZeroA;
};

function squareToSzzZValue1342(){
    value45Save = "zSqrArtSpecz1342";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1342").src = tripleZeroA;
};

function squareToSzzZValue1343(){
    value45Save = "zSqrArtSpecz1343";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1343").src = tripleZeroA;
};

function squareToSzzZValue1344(){
    value45Save = "zSqrArtSpecz1344";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1344").src = tripleZeroA;
};

function squareToSzzZValue1345(){
    value45Save = "zSqrArtSpecz1345";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1345").src = tripleZeroA;
};

function squareToSzzZValue1346(){
    value45Save = "zSqrArtSpecz1346";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1346").src = tripleZeroA;
};

function squareToSzzZValue1347(){
    value45Save = "zSqrArtSpecz1347";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1347").src = tripleZeroA;
};

function squareToSzzZValue1348(){
    value45Save = "zSqrArtSpecz1348";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1348").src = tripleZeroA;
};

function squareToSzzZValue1349(){
    value45Save = "zSqrArtSpecz1349";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1349").src = tripleZeroA;
};

function squareToSzzZValue1350(){
    value45Save = "zSqrArtSpecz1350";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1350").src = tripleZeroA;
};

function squareToSzzZValue1351(){
    value45Save = "zSqrArtSpecz1351";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1351").src = tripleZeroA;
};

function squareToSzzZValue1352(){
    value45Save = "zSqrArtSpecz1352";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1352").src = tripleZeroA;
};

function squareToSzzZValue1353(){
    value45Save = "zSqrArtSpecz1353";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1353").src = tripleZeroA;
};

function squareToSzzZValue1354(){
    value45Save = "zSqrArtSpecz1354";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1354").src = tripleZeroA;
};

function squareToSzzZValue1355(){
    value45Save = "zSqrArtSpecz1355";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1355").src = tripleZeroA;
};

function squareToSzzZValue1356(){
    value45Save = "zSqrArtSpecz1356";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1356").src = tripleZeroA;
};

function squareToSzzZValue1357(){
    value45Save = "zSqrArtSpecz1357";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1357").src = tripleZeroA;
};

function squareToSzzZValue1358(){
    value45Save = "zSqrArtSpecz1358";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1358").src = tripleZeroA;
};

function squareToSzzZValue1359(){
    value45Save = "zSqrArtSpecz1359";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1359").src = tripleZeroA;
};

function squareToSzzZValue1360(){
    value45Save = "zSqrArtSpecz1360";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1360").src = tripleZeroA;
};

function squareToSzzZValue1361(){
    value45Save = "zSqrArtSpecz1361";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1361").src = tripleZeroA;
};

function squareToSzzZValue1362(){
    value45Save = "zSqrArtSpecz1362";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1362").src = tripleZeroA;
};

function squareToSzzZValue1363(){
    value45Save = "zSqrArtSpecz1363";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1363").src = tripleZeroA;
};

function squareToSzzZValue1364(){
    value45Save = "zSqrArtSpecz1364";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1364").src = tripleZeroA;
};

function squareToSzzZValue1365(){
    value45Save = "zSqrArtSpecz1365";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1365").src = tripleZeroA;
};

function squareToSzzZValue1366(){
    value45Save = "zSqrArtSpecz1366";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1366").src = tripleZeroA;
};

function squareToSzzZValue1367(){
    value45Save = "zSqrArtSpecz1367";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1367").src = tripleZeroA;
};

function squareToSzzZValue1368(){
    value45Save = "zSqrArtSpecz1368";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1368").src = tripleZeroA;
};

function squareToSzzZValue1369(){
    value45Save = "zSqrArtSpecz1369";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1369").src = tripleZeroA;
};

function squareToSzzZValue1370(){
    value45Save = "zSqrArtSpecz1370";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1370").src = tripleZeroA;
};

function squareToSzzZValue1371(){
    value45Save = "zSqrArtSpecz1371";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1371").src = tripleZeroA;
};

function squareToSzzZValue1372(){
    value45Save = "zSqrArtSpecz1372";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1372").src = tripleZeroA;
};

function squareToSzzZValue1373(){
    value45Save = "zSqrArtSpecz1373";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1373").src = tripleZeroA;
};

function squareToSzzZValue1374(){
    value45Save = "zSqrArtSpecz1374";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1374").src = tripleZeroA;
};

function squareToSzzZValue1375(){
    value45Save = "zSqrArtSpecz1375";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1375").src = tripleZeroA;
};

function squareToSzzZValue1376(){
    value45Save = "zSqrArtSpecz1376";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1376").src = tripleZeroA;
};

function squareToSzzZValue1377(){
    value45Save = "zSqrArtSpecz1377";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1377").src = tripleZeroA;
};

function squareToSzzZValue1378(){
    value45Save = "zSqrArtSpecz1378";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1378").src = tripleZeroA;
};

function squareToSzzZValue1379(){
    value45Save = "zSqrArtSpecz1379";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1379").src = tripleZeroA;
};

function squareToSzzZValue1380(){
    value45Save = "zSqrArtSpecz1380";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1380").src = tripleZeroA;
};

function squareToSzzZValue1381(){
    value45Save = "zSqrArtSpecz1381";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1381").src = tripleZeroA;
};

function squareToSzzZValue1382(){
    value45Save = "zSqrArtSpecz1382";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1382").src = tripleZeroA;
};

function squareToSzzZValue1383(){
    value45Save = "zSqrArtSpecz1383";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1383").src = tripleZeroA;
};

function squareToSzzZValue1384(){
    value45Save = "zSqrArtSpecz1384";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1384").src = tripleZeroA;
};

function squareToSzzZValue1385(){
    value45Save = "zSqrArtSpecz1385";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1385").src = tripleZeroA;
};

function squareToSzzZValue1386(){
    value45Save = "zSqrArtSpecz1386";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1386").src = tripleZeroA;
};

function squareToSzzZValue1387(){
    value45Save = "zSqrArtSpecz1387";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1387").src = tripleZeroA;
};

function squareToSzzZValue1388(){
    value45Save = "zSqrArtSpecz1388";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1388").src = tripleZeroA;
};

function squareToSzzZValue1389(){
    value45Save = "zSqrArtSpecz1389";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1389").src = tripleZeroA;
};

function squareToSzzZValue1390(){
    value45Save = "zSqrArtSpecz1390";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1390").src = tripleZeroA;
};

function squareToSzzZValue1391(){
    value45Save = "zSqrArtSpecz1391";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1391").src = tripleZeroA;
};

function squareToSzzZValue1392(){
    value45Save = "zSqrArtSpecz1392";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1392").src = tripleZeroA;
};

function squareToSzzZValue1393(){
    value45Save = "zSqrArtSpecz1393";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1393").src = tripleZeroA;
};

function squareToSzzZValue1394(){
    value45Save = "zSqrArtSpecz1394";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1394").src = tripleZeroA;
};

function squareToSzzZValue1395(){
    value45Save = "zSqrArtSpecz1395";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1395").src = tripleZeroA;
};

function squareToSzzZValue1396(){
    value45Save = "zSqrArtSpecz1396";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1396").src = tripleZeroA;
};

function squareToSzzZValue1397(){
    value45Save = "zSqrArtSpecz1397";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1397").src = tripleZeroA;
};

function squareToSzzZValue1398(){
    value45Save = "zSqrArtSpecz1398";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1398").src = tripleZeroA;
};

function squareToSzzZValue1399(){
    value45Save = "zSqrArtSpecz1399";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1399").src = tripleZeroA;
};

function squareToSzzZValue1400(){
    value45Save = "zSqrArtSpecz1400";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1400").src = tripleZeroA;
};

function squareToSzzZValue1401(){
    value45Save = "zSqrArtSpecz1401";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1401").src = tripleZeroA;
};

function squareToSzzZValue1402(){
    value45Save = "zSqrArtSpecz1402";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1402").src = tripleZeroA;
};

function squareToSzzZValue1403(){
    value45Save = "zSqrArtSpecz1403";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1403").src = tripleZeroA;
};

function squareToSzzZValue1404(){
    value45Save = "zSqrArtSpecz1404";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1404").src = tripleZeroA;
};

function squareToSzzZValue1405(){
    value45Save = "zSqrArtSpecz1405";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1405").src = tripleZeroA;
};

function squareToSzzZValue1406(){
    value45Save = "zSqrArtSpecz1406";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1406").src = tripleZeroA;
};

function squareToSzzZValue1407(){
    value45Save = "zSqrArtSpecz1407";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1407").src = tripleZeroA;
};

function squareToSzzZValue1408(){
    value45Save = "zSqrArtSpecz1408";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1408").src = tripleZeroA;
};

function squareToSzzZValue1409(){
    value45Save = "zSqrArtSpecz1409";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1409").src = tripleZeroA;
};

function squareToSzzZValue1410(){
    value45Save = "zSqrArtSpecz1410";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1410").src = tripleZeroA;
};

function squareToSzzZValue1411(){
    value45Save = "zSqrArtSpecz1411";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1411").src = tripleZeroA;
};

function squareToSzzZValue1412(){
    value45Save = "zSqrArtSpecz1412";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1412").src = tripleZeroA;
};

function squareToSzzZValue1413(){
    value45Save = "zSqrArtSpecz1413";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1413").src = tripleZeroA;
};

function squareToSzzZValue1414(){
    value45Save = "zSqrArtSpecz1414";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1414").src = tripleZeroA;
};

function squareToSzzZValue1415(){
    value45Save = "zSqrArtSpecz1415";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1415").src = tripleZeroA;
};

function squareToSzzZValue1416(){
    value45Save = "zSqrArtSpecz1416";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1416").src = tripleZeroA;
};

function squareToSzzZValue1417(){
    value45Save = "zSqrArtSpecz1417";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1417").src = tripleZeroA;
};

function squareToSzzZValue1418(){
    value45Save = "zSqrArtSpecz1418";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1418").src = tripleZeroA;
};

function squareToSzzZValue1419(){
    value45Save = "zSqrArtSpecz1419";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1419").src = tripleZeroA;
};

function squareToSzzZValue1420(){
    value45Save = "zSqrArtSpecz1420";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1420").src = tripleZeroA;
};

function squareToSzzZValue1421(){
    value45Save = "zSqrArtSpecz1421";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1421").src = tripleZeroA;
};

function squareToSzzZValue1422(){
    value45Save = "zSqrArtSpecz1422";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1422").src = tripleZeroA;
};

function squareToSzzZValue1423(){
    value45Save = "zSqrArtSpecz1423";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1423").src = tripleZeroA;
};

function squareToSzzZValue1424(){
    value45Save = "zSqrArtSpecz1424";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1424").src = tripleZeroA;
};

function squareToSzzZValue1425(){
    value45Save = "zSqrArtSpecz1425";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1425").src = tripleZeroA;
};

function squareToSzzZValue1426(){
    value45Save = "zSqrArtSpecz1426";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1426").src = tripleZeroA;
};

function squareToSzzZValue1427(){
    value45Save = "zSqrArtSpecz1427";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1427").src = tripleZeroA;
};

function squareToSzzZValue1428(){
    value45Save = "zSqrArtSpecz1428";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1428").src = tripleZeroA;
};

function squareToSzzZValue1429(){
    value45Save = "zSqrArtSpecz1429";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1429").src = tripleZeroA;
};

function squareToSzzZValue1430(){
    value45Save = "zSqrArtSpecz1430";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1430").src = tripleZeroA;
};

function squareToSzzZValue1431(){
    value45Save = "zSqrArtSpecz1431";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1431").src = tripleZeroA;
};

function squareToSzzZValue1432(){
    value45Save = "zSqrArtSpecz1432";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1432").src = tripleZeroA;
};

function squareToSzzZValue1433(){
    value45Save = "zSqrArtSpecz1433";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1433").src = tripleZeroA;
};

function squareToSzzZValue1434(){
    value45Save = "zSqrArtSpecz1434";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1434").src = tripleZeroA;
};

function squareToSzzZValue1435(){
    value45Save = "zSqrArtSpecz1435";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1435").src = tripleZeroA;
};

function squareToSzzZValue1436(){
    value45Save = "zSqrArtSpecz1436";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1436").src = tripleZeroA;
};

function squareToSzzZValue1437(){
    value45Save = "zSqrArtSpecz1437";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1437").src = tripleZeroA;
};

function squareToSzzZValue1438(){
    value45Save = "zSqrArtSpecz1438";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1438").src = tripleZeroA;
};

function squareToSzzZValue1439(){
    value45Save = "zSqrArtSpecz1439";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1439").src = tripleZeroA;
};

function squareToSzzZValue1440(){
    value45Save = "zSqrArtSpecz1440";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1440").src = tripleZeroA;
};

function squareToSzzZValue1441(){
    value45Save = "zSqrArtSpecz1441";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1441").src = tripleZeroA;
};

function squareToSzzZValue1442(){
    value45Save = "zSqrArtSpecz1442";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1442").src = tripleZeroA;
};

function squareToSzzZValue1443(){
    value45Save = "zSqrArtSpecz1443";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1443").src = tripleZeroA;
};

function squareToSzzZValue1444(){
    value45Save = "zSqrArtSpecz1444";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1444").src = tripleZeroA;
};

function squareToSzzZValue1445(){
    value45Save = "zSqrArtSpecz1445";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1445").src = tripleZeroA;
};

function squareToSzzZValue1446(){
    value45Save = "zSqrArtSpecz1446";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1446").src = tripleZeroA;
};

function squareToSzzZValue1447(){
    value45Save = "zSqrArtSpecz1447";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1447").src = tripleZeroA;
};

function squareToSzzZValue1448(){
    value45Save = "zSqrArtSpecz1448";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1448").src = tripleZeroA;
};

function squareToSzzZValue1449(){
    value45Save = "zSqrArtSpecz1449";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1449").src = tripleZeroA;
};

function squareToSzzZValue1450(){
    value45Save = "zSqrArtSpecz1450";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1450").src = tripleZeroA;
};

function squareToSzzZValue1451(){
    value45Save = "zSqrArtSpecz1451";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1451").src = tripleZeroA;
};

function squareToSzzZValue1452(){
    value45Save = "zSqrArtSpecz1452";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1452").src = tripleZeroA;
};

function squareToSzzZValue1453(){
    value45Save = "zSqrArtSpecz1453";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1453").src = tripleZeroA;
};

function squareToSzzZValue1454(){
    value45Save = "zSqrArtSpecz1454";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1454").src = tripleZeroA;
};

function squareToSzzZValue1455(){
    value45Save = "zSqrArtSpecz1455";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1455").src = tripleZeroA;
};

function squareToSzzZValue1456(){
    value45Save = "zSqrArtSpecz1456";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1456").src = tripleZeroA;
};

function squareToSzzZValue1457(){
    value45Save = "zSqrArtSpecz1457";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1457").src = tripleZeroA;
};

function squareToSzzZValue1458(){
    value45Save = "zSqrArtSpecz1458";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1458").src = tripleZeroA;
};

function squareToSzzZValue1459(){
    value45Save = "zSqrArtSpecz1459";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1459").src = tripleZeroA;
};

function squareToSzzZValue1460(){
    value45Save = "zSqrArtSpecz1460";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1460").src = tripleZeroA;
};

function squareToSzzZValue1461(){
    value45Save = "zSqrArtSpecz1461";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1461").src = tripleZeroA;
};

function squareToSzzZValue1462(){
    value45Save = "zSqrArtSpecz1462";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1462").src = tripleZeroA;
};

function squareToSzzZValue1463(){
    value45Save = "zSqrArtSpecz1463";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1463").src = tripleZeroA;
};

function squareToSzzZValue1464(){
    value45Save = "zSqrArtSpecz1464";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1464").src = tripleZeroA;
};

function squareToSzzZValue1465(){
    value45Save = "zSqrArtSpecz1465";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1465").src = tripleZeroA;
};

function squareToSzzZValue1466(){
    value45Save = "zSqrArtSpecz1466";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1466").src = tripleZeroA;
};

function squareToSzzZValue1467(){
    value45Save = "zSqrArtSpecz1467";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1467").src = tripleZeroA;
};

function squareToSzzZValue1468(){
    value45Save = "zSqrArtSpecz1468";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1468").src = tripleZeroA;
};

function squareToSzzZValue1469(){
    value45Save = "zSqrArtSpecz1469";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1469").src = tripleZeroA;
};

function squareToSzzZValue1470(){
    value45Save = "zSqrArtSpecz1470";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1470").src = tripleZeroA;
};

function squareToSzzZValue1471(){
    value45Save = "zSqrArtSpecz1471";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1471").src = tripleZeroA;
};

function squareToSzzZValue1472(){
    value45Save = "zSqrArtSpecz1472";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1472").src = tripleZeroA;
};

function squareToSzzZValue1473(){
    value45Save = "zSqrArtSpecz1473";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1473").src = tripleZeroA;
};

function squareToSzzZValue1474(){
    value45Save = "zSqrArtSpecz1474";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1474").src = tripleZeroA;
};

function squareToSzzZValue1475(){
    value45Save = "zSqrArtSpecz1475";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1475").src = tripleZeroA;
};

function squareToSzzZValue1476(){
    value45Save = "zSqrArtSpecz1476";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1476").src = tripleZeroA;
};

function squareToSzzZValue1477(){
    value45Save = "zSqrArtSpecz1477";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1477").src = tripleZeroA;
};

function squareToSzzZValue1478(){
    value45Save = "zSqrArtSpecz1478";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1478").src = tripleZeroA;
};

function squareToSzzZValue1479(){
    value45Save = "zSqrArtSpecz1479";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1479").src = tripleZeroA;
};

function squareToSzzZValue1480(){
    value45Save = "zSqrArtSpecz1480";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1480").src = tripleZeroA;
};

function squareToSzzZValue1481(){
    value45Save = "zSqrArtSpecz1481";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1481").src = tripleZeroA;
};

function squareToSzzZValue1482(){
    value45Save = "zSqrArtSpecz1482";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1482").src = tripleZeroA;
};

function squareToSzzZValue1483(){
    value45Save = "zSqrArtSpecz1483";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1483").src = tripleZeroA;
};

function squareToSzzZValue1484(){
    value45Save = "zSqrArtSpecz1484";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1484").src = tripleZeroA;
};

function squareToSzzZValue1485(){
    value45Save = "zSqrArtSpecz1485";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1485").src = tripleZeroA;
};

function squareToSzzZValue1486(){
    value45Save = "zSqrArtSpecz1486";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1486").src = tripleZeroA;
};

function squareToSzzZValue1487(){
    value45Save = "zSqrArtSpecz1487";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1487").src = tripleZeroA;
};

function squareToSzzZValue1488(){
    value45Save = "zSqrArtSpecz1488";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1488").src = tripleZeroA;
};

function squareToSzzZValue1489(){
    value45Save = "zSqrArtSpecz1489";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1489").src = tripleZeroA;
};

function squareToSzzZValue1490(){
    value45Save = "zSqrArtSpecz1490";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1490").src = tripleZeroA;
};

function squareToSzzZValue1491(){
    value45Save = "zSqrArtSpecz1491";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1491").src = tripleZeroA;
};

function squareToSzzZValue1492(){
    value45Save = "zSqrArtSpecz1492";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1492").src = tripleZeroA;
};

function squareToSzzZValue1493(){
    value45Save = "zSqrArtSpecz1493";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1493").src = tripleZeroA;
};

function squareToSzzZValue1494(){
    value45Save = "zSqrArtSpecz1494";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1494").src = tripleZeroA;
};

function squareToSzzZValue1495(){
    value45Save = "zSqrArtSpecz1495";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1495").src = tripleZeroA;
};

function squareToSzzZValue1496(){
    value45Save = "zSqrArtSpecz1496";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1496").src = tripleZeroA;
};

function squareToSzzZValue1497(){
    value45Save = "zSqrArtSpecz1497";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1497").src = tripleZeroA;
};

function squareToSzzZValue1498(){
    value45Save = "zSqrArtSpecz1498";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1498").src = tripleZeroA;
};

function squareToSzzZValue1499(){
    value45Save = "zSqrArtSpecz1499";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1499").src = tripleZeroA;
};

function squareToSzzZValue1500(){
    value45Save = "zSqrArtSpecz1500";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1500").src = tripleZeroA;
};

function squareToSzzZValue1501(){
    value45Save = "zSqrArtSpecz1501";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1501").src = tripleZeroA;
};

function squareToSzzZValue1502(){
    value45Save = "zSqrArtSpecz1502";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1502").src = tripleZeroA;
};

function squareToSzzZValue1503(){
    value45Save = "zSqrArtSpecz1503";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1503").src = tripleZeroA;
};

function squareToSzzZValue1504(){
    value45Save = "zSqrArtSpecz1504";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1504").src = tripleZeroA;
};

function squareToSzzZValue1505(){
    value45Save = "zSqrArtSpecz1505";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1505").src = tripleZeroA;
};

function squareToSzzZValue1506(){
    value45Save = "zSqrArtSpecz1506";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1506").src = tripleZeroA;
};

function squareToSzzZValue1507(){
    value45Save = "zSqrArtSpecz1507";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1507").src = tripleZeroA;
};

function squareToSzzZValue1508(){
    value45Save = "zSqrArtSpecz1508";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1508").src = tripleZeroA;
};

function squareToSzzZValue1509(){
    value45Save = "zSqrArtSpecz1509";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1509").src = tripleZeroA;
};

function squareToSzzZValue1510(){
    value45Save = "zSqrArtSpecz1510";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1510").src = tripleZeroA;
};

function squareToSzzZValue1511(){
    value45Save = "zSqrArtSpecz1511";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1511").src = tripleZeroA;
};

function squareToSzzZValue1512(){
    value45Save = "zSqrArtSpecz1512";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1512").src = tripleZeroA;
};

function squareToSzzZValue1513(){
    value45Save = "zSqrArtSpecz1513";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1513").src = tripleZeroA;
};

function squareToSzzZValue1514(){
    value45Save = "zSqrArtSpecz1514";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1514").src = tripleZeroA;
};

function squareToSzzZValue1515(){
    value45Save = "zSqrArtSpecz1515";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1515").src = tripleZeroA;
};

function squareToSzzZValue1516(){
    value45Save = "zSqrArtSpecz1516";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1516").src = tripleZeroA;
};

function squareToSzzZValue1517(){
    value45Save = "zSqrArtSpecz1517";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1517").src = tripleZeroA;
};

function squareToSzzZValue1518(){
    value45Save = "zSqrArtSpecz1518";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1518").src = tripleZeroA;
};

function squareToSzzZValue1519(){
    value45Save = "zSqrArtSpecz1519";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1519").src = tripleZeroA;
};

function squareToSzzZValue1520(){
    value45Save = "zSqrArtSpecz1520";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1520").src = tripleZeroA;
};

function squareToSzzZValue1521(){
    value45Save = "zSqrArtSpecz1521";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1521").src = tripleZeroA;
};

function squareToSzzZValue1522(){
    value45Save = "zSqrArtSpecz1522";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1522").src = tripleZeroA;
};

function squareToSzzZValue1523(){
    value45Save = "zSqrArtSpecz1523";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1523").src = tripleZeroA;
};

function squareToSzzZValue1524(){
    value45Save = "zSqrArtSpecz1524";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1524").src = tripleZeroA;
};

function squareToSzzZValue1525(){
    value45Save = "zSqrArtSpecz1525";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1525").src = tripleZeroA;
};

function squareToSzzZValue1526(){
    value45Save = "zSqrArtSpecz1526";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1526").src = tripleZeroA;
};

function squareToSzzZValue1527(){
    value45Save = "zSqrArtSpecz1527";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1527").src = tripleZeroA;
};

function squareToSzzZValue1528(){
    value45Save = "zSqrArtSpecz1528";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1528").src = tripleZeroA;
};

function squareToSzzZValue1529(){
    value45Save = "zSqrArtSpecz1529";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1529").src = tripleZeroA;
};

function squareToSzzZValue1530(){
    value45Save = "zSqrArtSpecz1530";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1530").src = tripleZeroA;
};

function squareToSzzZValue1531(){
    value45Save = "zSqrArtSpecz1531";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1531").src = tripleZeroA;
};

function squareToSzzZValue1532(){
    value45Save = "zSqrArtSpecz1532";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1532").src = tripleZeroA;
};

function squareToSzzZValue1533(){
    value45Save = "zSqrArtSpecz1533";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1533").src = tripleZeroA;
};

function squareToSzzZValue1534(){
    value45Save = "zSqrArtSpecz1534";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1534").src = tripleZeroA;
};

function squareToSzzZValue1535(){
    value45Save = "zSqrArtSpecz1535";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1535").src = tripleZeroA;
};

function squareToSzzZValue1536(){
    value45Save = "zSqrArtSpecz1536";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1536").src = tripleZeroA;
};

function squareToSzzZValue1537(){
    value45Save = "zSqrArtSpecz1537";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1537").src = tripleZeroA;
};

function squareToSzzZValue1538(){
    value45Save = "zSqrArtSpecz1538";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1538").src = tripleZeroA;
};

function squareToSzzZValue1539(){
    value45Save = "zSqrArtSpecz1539";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1539").src = tripleZeroA;
};

function squareToSzzZValue1540(){
    value45Save = "zSqrArtSpecz1540";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1540").src = tripleZeroA;
};

function squareToSzzZValue1541(){
    value45Save = "zSqrArtSpecz1541";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1541").src = tripleZeroA;
};

function squareToSzzZValue1542(){
    value45Save = "zSqrArtSpecz1542";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1542").src = tripleZeroA;
};

function squareToSzzZValue1543(){
    value45Save = "zSqrArtSpecz1543";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1543").src = tripleZeroA;
};

function squareToSzzZValue1544(){
    value45Save = "zSqrArtSpecz1544";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1544").src = tripleZeroA;
};

function squareToSzzZValue1545(){
    value45Save = "zSqrArtSpecz1545";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1545").src = tripleZeroA;
};

function squareToSzzZValue1546(){
    value45Save = "zSqrArtSpecz1546";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1546").src = tripleZeroA;
};

function squareToSzzZValue1547(){
    value45Save = "zSqrArtSpecz1547";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1547").src = tripleZeroA;
};

function squareToSzzZValue1548(){
    value45Save = "zSqrArtSpecz1548";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1548").src = tripleZeroA;
};

function squareToSzzZValue1549(){
    value45Save = "zSqrArtSpecz1549";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1549").src = tripleZeroA;
};

function squareToSzzZValue1550(){
    value45Save = "zSqrArtSpecz1550";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1550").src = tripleZeroA;
};

function squareToSzzZValue1551(){
    value45Save = "zSqrArtSpecz1551";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1551").src = tripleZeroA;
};

function squareToSzzZValue1552(){
    value45Save = "zSqrArtSpecz1552";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1552").src = tripleZeroA;
};

function squareToSzzZValue1553(){
    value45Save = "zSqrArtSpecz1553";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1553").src = tripleZeroA;
};

function squareToSzzZValue1554(){
    value45Save = "zSqrArtSpecz1554";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1554").src = tripleZeroA;
};

function squareToSzzZValue1555(){
    value45Save = "zSqrArtSpecz1555";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1555").src = tripleZeroA;
};

function squareToSzzZValue1556(){
    value45Save = "zSqrArtSpecz1556";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1556").src = tripleZeroA;
};

function squareToSzzZValue1557(){
    value45Save = "zSqrArtSpecz1557";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1557").src = tripleZeroA;
};

function squareToSzzZValue1558(){
    value45Save = "zSqrArtSpecz1558";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1558").src = tripleZeroA;
};

function squareToSzzZValue1559(){
    value45Save = "zSqrArtSpecz1559";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1559").src = tripleZeroA;
};

function squareToSzzZValue1560(){
    value45Save = "zSqrArtSpecz1560";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1560").src = tripleZeroA;
};

function squareToSzzZValue1561(){
    value45Save = "zSqrArtSpecz1561";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1561").src = tripleZeroA;
};

function squareToSzzZValue1562(){
    value45Save = "zSqrArtSpecz1562";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1562").src = tripleZeroA;
};

function squareToSzzZValue1563(){
    value45Save = "zSqrArtSpecz1563";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1563").src = tripleZeroA;
};

function squareToSzzZValue1564(){
    value45Save = "zSqrArtSpecz1564";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1564").src = tripleZeroA;
};

function squareToSzzZValue1565(){
    value45Save = "zSqrArtSpecz1565";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1565").src = tripleZeroA;
};

function squareToSzzZValue1566(){
    value45Save = "zSqrArtSpecz1566";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1566").src = tripleZeroA;
};

function squareToSzzZValue1567(){
    value45Save = "zSqrArtSpecz1567";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1567").src = tripleZeroA;
};

function squareToSzzZValue1568(){
    value45Save = "zSqrArtSpecz1568";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1568").src = tripleZeroA;
};

function squareToSzzZValue1569(){
    value45Save = "zSqrArtSpecz1569";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1569").src = tripleZeroA;
};

function squareToSzzZValue1570(){
    value45Save = "zSqrArtSpecz1570";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1570").src = tripleZeroA;
};

function squareToSzzZValue1571(){
    value45Save = "zSqrArtSpecz1571";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1571").src = tripleZeroA;
};

function squareToSzzZValue1572(){
    value45Save = "zSqrArtSpecz1572";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1572").src = tripleZeroA;
};

function squareToSzzZValue1573(){
    value45Save = "zSqrArtSpecz1573";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1573").src = tripleZeroA;
};

function squareToSzzZValue1574(){
    value45Save = "zSqrArtSpecz1574";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1574").src = tripleZeroA;
};

function squareToSzzZValue1575(){
    value45Save = "zSqrArtSpecz1575";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1575").src = tripleZeroA;
};

function squareToSzzZValue1576(){
    value45Save = "zSqrArtSpecz1576";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1576").src = tripleZeroA;
};

function squareToSzzZValue1577(){
    value45Save = "zSqrArtSpecz1577";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1577").src = tripleZeroA;
};

function squareToSzzZValue1578(){
    value45Save = "zSqrArtSpecz1578";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1578").src = tripleZeroA;
};

function squareToSzzZValue1579(){
    value45Save = "zSqrArtSpecz1579";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1579").src = tripleZeroA;
};

function squareToSzzZValue1580(){
    value45Save = "zSqrArtSpecz1580";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1580").src = tripleZeroA;
};

function squareToSzzZValue1581(){
    value45Save = "zSqrArtSpecz1581";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1581").src = tripleZeroA;
};

function squareToSzzZValue1582(){
    value45Save = "zSqrArtSpecz1582";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1582").src = tripleZeroA;
};

function squareToSzzZValue1583(){
    value45Save = "zSqrArtSpecz1583";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1583").src = tripleZeroA;
};

function squareToSzzZValue1584(){
    value45Save = "zSqrArtSpecz1584";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1584").src = tripleZeroA;
};

function squareToSzzZValue1585(){
    value45Save = "zSqrArtSpecz1585";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1585").src = tripleZeroA;
};

function squareToSzzZValue1586(){
    value45Save = "zSqrArtSpecz1586";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1586").src = tripleZeroA;
};

function squareToSzzZValue1587(){
    value45Save = "zSqrArtSpecz1587";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1587").src = tripleZeroA;
};

function squareToSzzZValue1588(){
    value45Save = "zSqrArtSpecz1588";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1588").src = tripleZeroA;
};

function squareToSzzZValue1589(){
    value45Save = "zSqrArtSpecz1589";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1589").src = tripleZeroA;
};

function squareToSzzZValue1590(){
    value45Save = "zSqrArtSpecz1590";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1590").src = tripleZeroA;
};

function squareToSzzZValue1591(){
    value45Save = "zSqrArtSpecz1591";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1591").src = tripleZeroA;
};

function squareToSzzZValue1592(){
    value45Save = "zSqrArtSpecz1592";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1592").src = tripleZeroA;
};

function squareToSzzZValue1593(){
    value45Save = "zSqrArtSpecz1593";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1593").src = tripleZeroA;
};

function squareToSzzZValue1594(){
    value45Save = "zSqrArtSpecz1594";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1594").src = tripleZeroA;
};

function squareToSzzZValue1595(){
    value45Save = "zSqrArtSpecz1595";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1595").src = tripleZeroA;
};

function squareToSzzZValue1596(){
    value45Save = "zSqrArtSpecz1596";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1596").src = tripleZeroA;
};

function squareToSzzZValue1597(){
    value45Save = "zSqrArtSpecz1597";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1597").src = tripleZeroA;
};

function squareToSzzZValue1598(){
    value45Save = "zSqrArtSpecz1598";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1598").src = tripleZeroA;
};

function squareToSzzZValue1599(){
    value45Save = "zSqrArtSpecz1599";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1599").src = tripleZeroA;
};

function squareToSzzZValue1600(){
    value45Save = "zSqrArtSpecz1600";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1600").src = tripleZeroA;
};

function squareToSzzZValue1601(){
    value45Save = "zSqrArtSpecz1601";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1601").src = tripleZeroA;
};

function squareToSzzZValue1602(){
    value45Save = "zSqrArtSpecz1602";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1602").src = tripleZeroA;
};

function squareToSzzZValue1603(){
    value45Save = "zSqrArtSpecz1603";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1603").src = tripleZeroA;
};

function squareToSzzZValue1604(){
    value45Save = "zSqrArtSpecz1604";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1604").src = tripleZeroA;
};

function squareToSzzZValue1605(){
    value45Save = "zSqrArtSpecz1605";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1605").src = tripleZeroA;
};

function squareToSzzZValue1606(){
    value45Save = "zSqrArtSpecz1606";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1606").src = tripleZeroA;
};

function squareToSzzZValue1607(){
    value45Save = "zSqrArtSpecz1607";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1607").src = tripleZeroA;
};

function squareToSzzZValue1608(){
    value45Save = "zSqrArtSpecz1608";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1608").src = tripleZeroA;
};

function squareToSzzZValue1609(){
    value45Save = "zSqrArtSpecz1609";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1609").src = tripleZeroA;
};

function squareToSzzZValue1610(){
    value45Save = "zSqrArtSpecz1610";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1610").src = tripleZeroA;
};

function squareToSzzZValue1611(){
    value45Save = "zSqrArtSpecz1611";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1611").src = tripleZeroA;
};

function squareToSzzZValue1612(){
    value45Save = "zSqrArtSpecz1612";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1612").src = tripleZeroA;
};

function squareToSzzZValue1613(){
    value45Save = "zSqrArtSpecz1613";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1613").src = tripleZeroA;
};

function squareToSzzZValue1614(){
    value45Save = "zSqrArtSpecz1614";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1614").src = tripleZeroA;
};

function squareToSzzZValue1615(){
    value45Save = "zSqrArtSpecz1615";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1615").src = tripleZeroA;
};

function squareToSzzZValue1616(){
    value45Save = "zSqrArtSpecz1616";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1616").src = tripleZeroA;
};

function squareToSzzZValue1617(){
    value45Save = "zSqrArtSpecz1617";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1617").src = tripleZeroA;
};

function squareToSzzZValue1618(){
    value45Save = "zSqrArtSpecz1618";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1618").src = tripleZeroA;
};

function squareToSzzZValue1619(){
    value45Save = "zSqrArtSpecz1619";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1619").src = tripleZeroA;
};

function squareToSzzZValue1620(){
    value45Save = "zSqrArtSpecz1620";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1620").src = tripleZeroA;
};

function squareToSzzZValue1621(){
    value45Save = "zSqrArtSpecz1621";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1621").src = tripleZeroA;
};

function squareToSzzZValue1622(){
    value45Save = "zSqrArtSpecz1622";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1622").src = tripleZeroA;
};

function squareToSzzZValue1623(){
    value45Save = "zSqrArtSpecz1623";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1623").src = tripleZeroA;
};

function squareToSzzZValue1624(){
    value45Save = "zSqrArtSpecz1624";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1624").src = tripleZeroA;
};

function squareToSzzZValue1625(){
    value45Save = "zSqrArtSpecz1625";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1625").src = tripleZeroA;
};

function squareToSzzZValue1626(){
    value45Save = "zSqrArtSpecz1626";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1626").src = tripleZeroA;
};

function squareToSzzZValue1627(){
    value45Save = "zSqrArtSpecz1627";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1627").src = tripleZeroA;
};

function squareToSzzZValue1628(){
    value45Save = "zSqrArtSpecz1628";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1628").src = tripleZeroA;
};

function squareToSzzZValue1629(){
    value45Save = "zSqrArtSpecz1629";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1629").src = tripleZeroA;
};

function squareToSzzZValue1630(){
    value45Save = "zSqrArtSpecz1630";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1630").src = tripleZeroA;
};

function squareToSzzZValue1631(){
    value45Save = "zSqrArtSpecz1631";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1631").src = tripleZeroA;
};

function squareToSzzZValue1632(){
    value45Save = "zSqrArtSpecz1632";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1632").src = tripleZeroA;
};

function squareToSzzZValue1633(){
    value45Save = "zSqrArtSpecz1633";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1633").src = tripleZeroA;
};

function squareToSzzZValue1634(){
    value45Save = "zSqrArtSpecz1634";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1634").src = tripleZeroA;
};

function squareToSzzZValue1635(){
    value45Save = "zSqrArtSpecz1635";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1635").src = tripleZeroA;
};

function squareToSzzZValue1636(){
    value45Save = "zSqrArtSpecz1636";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1636").src = tripleZeroA;
};

function squareToSzzZValue1637(){
    value45Save = "zSqrArtSpecz1637";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1637").src = tripleZeroA;
};

function squareToSzzZValue1638(){
    value45Save = "zSqrArtSpecz1638";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1638").src = tripleZeroA;
};

function squareToSzzZValue1639(){
    value45Save = "zSqrArtSpecz1639";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1639").src = tripleZeroA;
};

function squareToSzzZValue1640(){
    value45Save = "zSqrArtSpecz1640";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1640").src = tripleZeroA;
};

function squareToSzzZValue1641(){
    value45Save = "zSqrArtSpecz1641";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1641").src = tripleZeroA;
};

function squareToSzzZValue1642(){
    value45Save = "zSqrArtSpecz1642";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1642").src = tripleZeroA;
};

function squareToSzzZValue1643(){
    value45Save = "zSqrArtSpecz1643";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1643").src = tripleZeroA;
};

function squareToSzzZValue1644(){
    value45Save = "zSqrArtSpecz1644";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1644").src = tripleZeroA;
};

function squareToSzzZValue1645(){
    value45Save = "zSqrArtSpecz1645";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1645").src = tripleZeroA;
};

function squareToSzzZValue1646(){
    value45Save = "zSqrArtSpecz1646";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1646").src = tripleZeroA;
};

function squareToSzzZValue1647(){
    value45Save = "zSqrArtSpecz1647";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1647").src = tripleZeroA;
};

function squareToSzzZValue1648(){
    value45Save = "zSqrArtSpecz1648";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1648").src = tripleZeroA;
};

function squareToSzzZValue1649(){
    value45Save = "zSqrArtSpecz1649";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1649").src = tripleZeroA;
};

function squareToSzzZValue1650(){
    value45Save = "zSqrArtSpecz1650";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1650").src = tripleZeroA;
};

function squareToSzzZValue1651(){
    value45Save = "zSqrArtSpecz1651";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1651").src = tripleZeroA;
};

function squareToSzzZValue1652(){
    value45Save = "zSqrArtSpecz1652";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1652").src = tripleZeroA;
};

function squareToSzzZValue1653(){
    value45Save = "zSqrArtSpecz1653";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1653").src = tripleZeroA;
};

function squareToSzzZValue1654(){
    value45Save = "zSqrArtSpecz1654";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1654").src = tripleZeroA;
};

function squareToSzzZValue1655(){
    value45Save = "zSqrArtSpecz1655";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1655").src = tripleZeroA;
};

function squareToSzzZValue1656(){
    value45Save = "zSqrArtSpecz1656";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1656").src = tripleZeroA;
};

function squareToSzzZValue1657(){
    value45Save = "zSqrArtSpecz1657";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1657").src = tripleZeroA;
};

function squareToSzzZValue1658(){
    value45Save = "zSqrArtSpecz1658";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1658").src = tripleZeroA;
};

function squareToSzzZValue1659(){
    value45Save = "zSqrArtSpecz1659";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1659").src = tripleZeroA;
};

function squareToSzzZValue1660(){
    value45Save = "zSqrArtSpecz1660";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1660").src = tripleZeroA;
};

function squareToSzzZValue1661(){
    value45Save = "zSqrArtSpecz1661";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1661").src = tripleZeroA;
};

function squareToSzzZValue1662(){
    value45Save = "zSqrArtSpecz1662";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1662").src = tripleZeroA;
};

function squareToSzzZValue1663(){
    value45Save = "zSqrArtSpecz1663";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1663").src = tripleZeroA;
};

function squareToSzzZValue1664(){
    value45Save = "zSqrArtSpecz1664";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1664").src = tripleZeroA;
};

function squareToSzzZValue1665(){
    value45Save = "zSqrArtSpecz1665";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1665").src = tripleZeroA;
};

function squareToSzzZValue1666(){
    value45Save = "zSqrArtSpecz1666";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1666").src = tripleZeroA;
};

function squareToSzzZValue1667(){
    value45Save = "zSqrArtSpecz1667";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1667").src = tripleZeroA;
};

function squareToSzzZValue1668(){
    value45Save = "zSqrArtSpecz1668";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1668").src = tripleZeroA;
};

function squareToSzzZValue1669(){
    value45Save = "zSqrArtSpecz1669";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1669").src = tripleZeroA;
};

function squareToSzzZValue1670(){
    value45Save = "zSqrArtSpecz1670";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1670").src = tripleZeroA;
};

function squareToSzzZValue1671(){
    value45Save = "zSqrArtSpecz1671";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1671").src = tripleZeroA;
};

function squareToSzzZValue1672(){
    value45Save = "zSqrArtSpecz1672";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1672").src = tripleZeroA;
};

function squareToSzzZValue1673(){
    value45Save = "zSqrArtSpecz1673";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1673").src = tripleZeroA;
};

function squareToSzzZValue1674(){
    value45Save = "zSqrArtSpecz1674";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1674").src = tripleZeroA;
};

function squareToSzzZValue1675(){
    value45Save = "zSqrArtSpecz1675";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1675").src = tripleZeroA;
};

function squareToSzzZValue1676(){
    value45Save = "zSqrArtSpecz1676";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1676").src = tripleZeroA;
};

function squareToSzzZValue1677(){
    value45Save = "zSqrArtSpecz1677";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1677").src = tripleZeroA;
};

function squareToSzzZValue1678(){
    value45Save = "zSqrArtSpecz1678";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1678").src = tripleZeroA;
};

function squareToSzzZValue1679(){
    value45Save = "zSqrArtSpecz1679";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1679").src = tripleZeroA;
};

function squareToSzzZValue1680(){
    value45Save = "zSqrArtSpecz1680";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1680").src = tripleZeroA;
};

function squareToSzzZValue1681(){
    value45Save = "zSqrArtSpecz1681";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1681").src = tripleZeroA;
};

function squareToSzzZValue1682(){
    value45Save = "zSqrArtSpecz1682";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1682").src = tripleZeroA;
};

function squareToSzzZValue1683(){
    value45Save = "zSqrArtSpecz1683";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1683").src = tripleZeroA;
};

function squareToSzzZValue1684(){
    value45Save = "zSqrArtSpecz1684";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1684").src = tripleZeroA;
};

function squareToSzzZValue1685(){
    value45Save = "zSqrArtSpecz1685";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1685").src = tripleZeroA;
};

function squareToSzzZValue1686(){
    value45Save = "zSqrArtSpecz1686";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1686").src = tripleZeroA;
};

function squareToSzzZValue1687(){
    value45Save = "zSqrArtSpecz1687";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1687").src = tripleZeroA;
};

function squareToSzzZValue1688(){
    value45Save = "zSqrArtSpecz1688";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1688").src = tripleZeroA;
};

function squareToSzzZValue1689(){
    value45Save = "zSqrArtSpecz1689";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1689").src = tripleZeroA;
};

function squareToSzzZValue1690(){
    value45Save = "zSqrArtSpecz1690";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1690").src = tripleZeroA;
};

function squareToSzzZValue1691(){
    value45Save = "zSqrArtSpecz1691";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1691").src = tripleZeroA;
};

function squareToSzzZValue1692(){
    value45Save = "zSqrArtSpecz1692";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1692").src = tripleZeroA;
};

function squareToSzzZValue1693(){
    value45Save = "zSqrArtSpecz1693";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1693").src = tripleZeroA;
};

function squareToSzzZValue1694(){
    value45Save = "zSqrArtSpecz1694";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1694").src = tripleZeroA;
};

function squareToSzzZValue1695(){
    value45Save = "zSqrArtSpecz1695";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1695").src = tripleZeroA;
};

function squareToSzzZValue1696(){
    value45Save = "zSqrArtSpecz1696";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1696").src = tripleZeroA;
};

function squareToSzzZValue1697(){
    value45Save = "zSqrArtSpecz1697";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1697").src = tripleZeroA;
};

function squareToSzzZValue1698(){
    value45Save = "zSqrArtSpecz1698";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1698").src = tripleZeroA;
};

function squareToSzzZValue1699(){
    value45Save = "zSqrArtSpecz1699";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1699").src = tripleZeroA;
};

function squareToSzzZValue1700(){
    value45Save = "zSqrArtSpecz1700";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1700").src = tripleZeroA;
};

function squareToSzzZValue1701(){
    value45Save = "zSqrArtSpecz1701";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1701").src = tripleZeroA;
};

function squareToSzzZValue1702(){
    value45Save = "zSqrArtSpecz1702";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1702").src = tripleZeroA;
};

function squareToSzzZValue1703(){
    value45Save = "zSqrArtSpecz1703";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1703").src = tripleZeroA;
};

function squareToSzzZValue1704(){
    value45Save = "zSqrArtSpecz1704";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1704").src = tripleZeroA;
};

function squareToSzzZValue1705(){
    value45Save = "zSqrArtSpecz1705";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1705").src = tripleZeroA;
};

function squareToSzzZValue1706(){
    value45Save = "zSqrArtSpecz1706";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1706").src = tripleZeroA;
};

function squareToSzzZValue1707(){
    value45Save = "zSqrArtSpecz1707";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1707").src = tripleZeroA;
};

function squareToSzzZValue1708(){
    value45Save = "zSqrArtSpecz1708";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1708").src = tripleZeroA;
};

function squareToSzzZValue1709(){
    value45Save = "zSqrArtSpecz1709";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1709").src = tripleZeroA;
};

function squareToSzzZValue1710(){
    value45Save = "zSqrArtSpecz1710";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1710").src = tripleZeroA;
};

function squareToSzzZValue1711(){
    value45Save = "zSqrArtSpecz1711";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1711").src = tripleZeroA;
};

function squareToSzzZValue1712(){
    value45Save = "zSqrArtSpecz1712";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1712").src = tripleZeroA;
};

function squareToSzzZValue1713(){
    value45Save = "zSqrArtSpecz1713";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1713").src = tripleZeroA;
};

function squareToSzzZValue1714(){
    value45Save = "zSqrArtSpecz1714";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1714").src = tripleZeroA;
};

function squareToSzzZValue1715(){
    value45Save = "zSqrArtSpecz1715";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1715").src = tripleZeroA;
};

function squareToSzzZValue1716(){
    value45Save = "zSqrArtSpecz1716";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1716").src = tripleZeroA;
};

function squareToSzzZValue1717(){
    value45Save = "zSqrArtSpecz1717";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1717").src = tripleZeroA;
};

function squareToSzzZValue1718(){
    value45Save = "zSqrArtSpecz1718";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1718").src = tripleZeroA;
};

function squareToSzzZValue1719(){
    value45Save = "zSqrArtSpecz1719";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1719").src = tripleZeroA;
};

function squareToSzzZValue1720(){
    value45Save = "zSqrArtSpecz1720";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1720").src = tripleZeroA;
};

function squareToSzzZValue1721(){
    value45Save = "zSqrArtSpecz1721";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1721").src = tripleZeroA;
};

function squareToSzzZValue1722(){
    value45Save = "zSqrArtSpecz1722";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1722").src = tripleZeroA;
};

function squareToSzzZValue1723(){
    value45Save = "zSqrArtSpecz1723";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1723").src = tripleZeroA;
};

function squareToSzzZValue1724(){
    value45Save = "zSqrArtSpecz1724";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1724").src = tripleZeroA;
};

function squareToSzzZValue1725(){
    value45Save = "zSqrArtSpecz1725";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1725").src = tripleZeroA;
};

function squareToSzzZValue1726(){
    value45Save = "zSqrArtSpecz1726";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1726").src = tripleZeroA;
};

function squareToSzzZValue1727(){
    value45Save = "zSqrArtSpecz1727";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1727").src = tripleZeroA;
};

function squareToSzzZValue1728(){
    value45Save = "zSqrArtSpecz1728";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1728").src = tripleZeroA;
};

function squareToSzzZValue1729(){
    value45Save = "zSqrArtSpecz1729";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1729").src = tripleZeroA;
};

function squareToSzzZValue1730(){
    value45Save = "zSqrArtSpecz1730";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1730").src = tripleZeroA;
};

function squareToSzzZValue1731(){
    value45Save = "zSqrArtSpecz1731";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1731").src = tripleZeroA;
};

function squareToSzzZValue1732(){
    value45Save = "zSqrArtSpecz1732";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1732").src = tripleZeroA;
};

function squareToSzzZValue1733(){
    value45Save = "zSqrArtSpecz1733";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1733").src = tripleZeroA;
};

function squareToSzzZValue1734(){
    value45Save = "zSqrArtSpecz1734";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1734").src = tripleZeroA;
};

function squareToSzzZValue1735(){
    value45Save = "zSqrArtSpecz1735";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1735").src = tripleZeroA;
};

function squareToSzzZValue1736(){
    value45Save = "zSqrArtSpecz1736";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1736").src = tripleZeroA;
};

function squareToSzzZValue1737(){
    value45Save = "zSqrArtSpecz1737";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1737").src = tripleZeroA;
};

function squareToSzzZValue1738(){
    value45Save = "zSqrArtSpecz1738";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1738").src = tripleZeroA;
};

function squareToSzzZValue1739(){
    value45Save = "zSqrArtSpecz1739";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1739").src = tripleZeroA;
};

function squareToSzzZValue1740(){
    value45Save = "zSqrArtSpecz1740";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1740").src = tripleZeroA;
};

function squareToSzzZValue1741(){
    value45Save = "zSqrArtSpecz1741";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1741").src = tripleZeroA;
};

function squareToSzzZValue1742(){
    value45Save = "zSqrArtSpecz1742";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1742").src = tripleZeroA;
};

function squareToSzzZValue1743(){
    value45Save = "zSqrArtSpecz1743";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1743").src = tripleZeroA;
};

function squareToSzzZValue1744(){
    value45Save = "zSqrArtSpecz1744";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1744").src = tripleZeroA;
};

function squareToSzzZValue1745(){
    value45Save = "zSqrArtSpecz1745";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1745").src = tripleZeroA;
};

function squareToSzzZValue1746(){
    value45Save = "zSqrArtSpecz1746";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1746").src = tripleZeroA;
};

function squareToSzzZValue1747(){
    value45Save = "zSqrArtSpecz1747";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1747").src = tripleZeroA;
};

function squareToSzzZValue1748(){
    value45Save = "zSqrArtSpecz1748";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1748").src = tripleZeroA;
};

function squareToSzzZValue1749(){
    value45Save = "zSqrArtSpecz1749";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1749").src = tripleZeroA;
};

function squareToSzzZValue1750(){
    value45Save = "zSqrArtSpecz1750";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1750").src = tripleZeroA;
};

function squareToSzzZValue1751(){
    value45Save = "zSqrArtSpecz1751";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1751").src = tripleZeroA;
};

function squareToSzzZValue1752(){
    value45Save = "zSqrArtSpecz1752";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1752").src = tripleZeroA;
};

function squareToSzzZValue1753(){
    value45Save = "zSqrArtSpecz1753";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1753").src = tripleZeroA;
};

function squareToSzzZValue1754(){
    value45Save = "zSqrArtSpecz1754";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1754").src = tripleZeroA;
};

function squareToSzzZValue1755(){
    value45Save = "zSqrArtSpecz1755";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1755").src = tripleZeroA;
};

function squareToSzzZValue1756(){
    value45Save = "zSqrArtSpecz1756";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1756").src = tripleZeroA;
};

function squareToSzzZValue1757(){
    value45Save = "zSqrArtSpecz1757";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1757").src = tripleZeroA;
};

function squareToSzzZValue1758(){
    value45Save = "zSqrArtSpecz1758";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1758").src = tripleZeroA;
};

function squareToSzzZValue1759(){
    value45Save = "zSqrArtSpecz1759";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1759").src = tripleZeroA;
};

function squareToSzzZValue1760(){
    value45Save = "zSqrArtSpecz1760";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1760").src = tripleZeroA;
};

function squareToSzzZValue1761(){
    value45Save = "zSqrArtSpecz1761";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1761").src = tripleZeroA;
};

function squareToSzzZValue1762(){
    value45Save = "zSqrArtSpecz1762";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1762").src = tripleZeroA;
};

function squareToSzzZValue1763(){
    value45Save = "zSqrArtSpecz1763";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1763").src = tripleZeroA;
};

function squareToSzzZValue1764(){
    value45Save = "zSqrArtSpecz1764";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1764").src = tripleZeroA;
};

function squareToSzzZValue1765(){
    value45Save = "zSqrArtSpecz1765";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1765").src = tripleZeroA;
};

function squareToSzzZValue1766(){
    value45Save = "zSqrArtSpecz1766";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1766").src = tripleZeroA;
};

function squareToSzzZValue1767(){
    value45Save = "zSqrArtSpecz1767";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1767").src = tripleZeroA;
};

function squareToSzzZValue1768(){
    value45Save = "zSqrArtSpecz1768";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1768").src = tripleZeroA;
};

function squareToSzzZValue1769(){
    value45Save = "zSqrArtSpecz1769";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1769").src = tripleZeroA;
};

function squareToSzzZValue1770(){
    value45Save = "zSqrArtSpecz1770";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1770").src = tripleZeroA;
};

function squareToSzzZValue1771(){
    value45Save = "zSqrArtSpecz1771";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1771").src = tripleZeroA;
};

function squareToSzzZValue1772(){
    value45Save = "zSqrArtSpecz1772";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1772").src = tripleZeroA;
};

function squareToSzzZValue1773(){
    value45Save = "zSqrArtSpecz1773";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1773").src = tripleZeroA;
};

function squareToSzzZValue1774(){
    value45Save = "zSqrArtSpecz1774";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1774").src = tripleZeroA;
};

function squareToSzzZValue1775(){
    value45Save = "zSqrArtSpecz1775";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1775").src = tripleZeroA;
};

function squareToSzzZValue1776(){
    value45Save = "zSqrArtSpecz1776";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1776").src = tripleZeroA;
};

function squareToSzzZValue1777(){
    value45Save = "zSqrArtSpecz1777";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1777").src = tripleZeroA;
};

function squareToSzzZValue1778(){
    value45Save = "zSqrArtSpecz1778";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1778").src = tripleZeroA;
};

function squareToSzzZValue1779(){
    value45Save = "zSqrArtSpecz1779";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1779").src = tripleZeroA;
};

function squareToSzzZValue1780(){
    value45Save = "zSqrArtSpecz1780";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1780").src = tripleZeroA;
};

function squareToSzzZValue1781(){
    value45Save = "zSqrArtSpecz1781";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1781").src = tripleZeroA;
};

function squareToSzzZValue1782(){
    value45Save = "zSqrArtSpecz1782";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1782").src = tripleZeroA;
};

function squareToSzzZValue1783(){
    value45Save = "zSqrArtSpecz1783";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1783").src = tripleZeroA;
};

function squareToSzzZValue1784(){
    value45Save = "zSqrArtSpecz1784";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1784").src = tripleZeroA;
};

function squareToSzzZValue1785(){
    value45Save = "zSqrArtSpecz1785";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1785").src = tripleZeroA;
};

function squareToSzzZValue1786(){
    value45Save = "zSqrArtSpecz1786";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1786").src = tripleZeroA;
};

function squareToSzzZValue1787(){
    value45Save = "zSqrArtSpecz1787";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1787").src = tripleZeroA;
};

function squareToSzzZValue1788(){
    value45Save = "zSqrArtSpecz1788";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1788").src = tripleZeroA;
};

function squareToSzzZValue1789(){
    value45Save = "zSqrArtSpecz1789";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1789").src = tripleZeroA;
};

function squareToSzzZValue1790(){
    value45Save = "zSqrArtSpecz1790";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1790").src = tripleZeroA;
};

function squareToSzzZValue1791(){
    value45Save = "zSqrArtSpecz1791";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1791").src = tripleZeroA;
};

function squareToSzzZValue1792(){
    value45Save = "zSqrArtSpecz1792";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1792").src = tripleZeroA;
};

function squareToSzzZValue1793(){
    value45Save = "zSqrArtSpecz1793";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1793").src = tripleZeroA;
};

function squareToSzzZValue1794(){
    value45Save = "zSqrArtSpecz1794";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1794").src = tripleZeroA;
};

function squareToSzzZValue1795(){
    value45Save = "zSqrArtSpecz1795";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1795").src = tripleZeroA;
};

function squareToSzzZValue1796(){
    value45Save = "zSqrArtSpecz1796";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1796").src = tripleZeroA;
};

function squareToSzzZValue1797(){
    value45Save = "zSqrArtSpecz1797";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1797").src = tripleZeroA;
};

function squareToSzzZValue1798(){
    value45Save = "zSqrArtSpecz1798";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1798").src = tripleZeroA;
};

function squareToSzzZValue1799(){
    value45Save = "zSqrArtSpecz1799";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1799").src = tripleZeroA;
};

function squareToSzzZValue1800(){
    value45Save = "zSqrArtSpecz1800";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1800").src = tripleZeroA;
};

function squareToSzzZValue1801(){
    value45Save = "zSqrArtSpecz1801";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1801").src = tripleZeroA;
};

function squareToSzzZValue1802(){
    value45Save = "zSqrArtSpecz1802";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1802").src = tripleZeroA;
};

function squareToSzzZValue1803(){
    value45Save = "zSqrArtSpecz1803";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1803").src = tripleZeroA;
};

function squareToSzzZValue1804(){
    value45Save = "zSqrArtSpecz1804";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1804").src = tripleZeroA;
};

function squareToSzzZValue1805(){
    value45Save = "zSqrArtSpecz1805";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1805").src = tripleZeroA;
};

function squareToSzzZValue1806(){
    value45Save = "zSqrArtSpecz1806";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1806").src = tripleZeroA;
};

function squareToSzzZValue1807(){
    value45Save = "zSqrArtSpecz1807";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1807").src = tripleZeroA;
};

function squareToSzzZValue1808(){
    value45Save = "zSqrArtSpecz1808";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1808").src = tripleZeroA;
};

function squareToSzzZValue1809(){
    value45Save = "zSqrArtSpecz1809";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1809").src = tripleZeroA;
};

function squareToSzzZValue1810(){
    value45Save = "zSqrArtSpecz1810";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1810").src = tripleZeroA;
};

function squareToSzzZValue1811(){
    value45Save = "zSqrArtSpecz1811";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1811").src = tripleZeroA;
};

function squareToSzzZValue1812(){
    value45Save = "zSqrArtSpecz1812";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1812").src = tripleZeroA;
};

function squareToSzzZValue1813(){
    value45Save = "zSqrArtSpecz1813";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1813").src = tripleZeroA;
};

function squareToSzzZValue1814(){
    value45Save = "zSqrArtSpecz1814";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1814").src = tripleZeroA;
};

function squareToSzzZValue1815(){
    value45Save = "zSqrArtSpecz1815";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1815").src = tripleZeroA;
};

function squareToSzzZValue1816(){
    value45Save = "zSqrArtSpecz1816";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1816").src = tripleZeroA;
};

function squareToSzzZValue1817(){
    value45Save = "zSqrArtSpecz1817";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1817").src = tripleZeroA;
};

function squareToSzzZValue1818(){
    value45Save = "zSqrArtSpecz1818";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1818").src = tripleZeroA;
};

function squareToSzzZValue1819(){
    value45Save = "zSqrArtSpecz1819";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1819").src = tripleZeroA;
};

function squareToSzzZValue1820(){
    value45Save = "zSqrArtSpecz1820";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1820").src = tripleZeroA;
};

function squareToSzzZValue1821(){
    value45Save = "zSqrArtSpecz1821";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1821").src = tripleZeroA;
};

function squareToSzzZValue1822(){
    value45Save = "zSqrArtSpecz1822";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1822").src = tripleZeroA;
};

function squareToSzzZValue1823(){
    value45Save = "zSqrArtSpecz1823";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1823").src = tripleZeroA;
};

function squareToSzzZValue1824(){
    value45Save = "zSqrArtSpecz1824";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1824").src = tripleZeroA;
};

function squareToSzzZValue1825(){
    value45Save = "zSqrArtSpecz1825";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1825").src = tripleZeroA;
};

function squareToSzzZValue1826(){
    value45Save = "zSqrArtSpecz1826";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1826").src = tripleZeroA;
};

function squareToSzzZValue1827(){
    value45Save = "zSqrArtSpecz1827";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1827").src = tripleZeroA;
};

function squareToSzzZValue1828(){
    value45Save = "zSqrArtSpecz1828";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1828").src = tripleZeroA;
};

function squareToSzzZValue1829(){
    value45Save = "zSqrArtSpecz1829";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1829").src = tripleZeroA;
};

function squareToSzzZValue1830(){
    value45Save = "zSqrArtSpecz1830";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1830").src = tripleZeroA;
};

function squareToSzzZValue1831(){
    value45Save = "zSqrArtSpecz1831";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1831").src = tripleZeroA;
};

function squareToSzzZValue1832(){
    value45Save = "zSqrArtSpecz1832";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1832").src = tripleZeroA;
};

function squareToSzzZValue1833(){
    value45Save = "zSqrArtSpecz1833";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1833").src = tripleZeroA;
};

function squareToSzzZValue1834(){
    value45Save = "zSqrArtSpecz1834";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1834").src = tripleZeroA;
};

function squareToSzzZValue1835(){
    value45Save = "zSqrArtSpecz1835";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1835").src = tripleZeroA;
};

function squareToSzzZValue1836(){
    value45Save = "zSqrArtSpecz1836";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1836").src = tripleZeroA;
};

function squareToSzzZValue1837(){
    value45Save = "zSqrArtSpecz1837";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1837").src = tripleZeroA;
};

function squareToSzzZValue1838(){
    value45Save = "zSqrArtSpecz1838";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1838").src = tripleZeroA;
};

function squareToSzzZValue1839(){
    value45Save = "zSqrArtSpecz1839";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1839").src = tripleZeroA;
};

function squareToSzzZValue1840(){
    value45Save = "zSqrArtSpecz1840";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1840").src = tripleZeroA;
};

function squareToSzzZValue1841(){
    value45Save = "zSqrArtSpecz1841";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1841").src = tripleZeroA;
};

function squareToSzzZValue1842(){
    value45Save = "zSqrArtSpecz1842";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1842").src = tripleZeroA;
};

function squareToSzzZValue1843(){
    value45Save = "zSqrArtSpecz1843";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1843").src = tripleZeroA;
};

function squareToSzzZValue1844(){
    value45Save = "zSqrArtSpecz1844";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1844").src = tripleZeroA;
};

function squareToSzzZValue1845(){
    value45Save = "zSqrArtSpecz1845";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1845").src = tripleZeroA;
};

function squareToSzzZValue1846(){
    value45Save = "zSqrArtSpecz1846";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1846").src = tripleZeroA;
};

function squareToSzzZValue1847(){
    value45Save = "zSqrArtSpecz1847";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1847").src = tripleZeroA;
};

function squareToSzzZValue1848(){
    value45Save = "zSqrArtSpecz1848";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1848").src = tripleZeroA;
};

function squareToSzzZValue1849(){
    value45Save = "zSqrArtSpecz1849";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1849").src = tripleZeroA;
};

function squareToSzzZValue1850(){
    value45Save = "zSqrArtSpecz1850";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1850").src = tripleZeroA;
};

function squareToSzzZValue1851(){
    value45Save = "zSqrArtSpecz1851";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1851").src = tripleZeroA;
};

function squareToSzzZValue1852(){
    value45Save = "zSqrArtSpecz1852";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1852").src = tripleZeroA;
};

function squareToSzzZValue1853(){
    value45Save = "zSqrArtSpecz1853";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1853").src = tripleZeroA;
};

function squareToSzzZValue1854(){
    value45Save = "zSqrArtSpecz1854";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1854").src = tripleZeroA;
};

function squareToSzzZValue1855(){
    value45Save = "zSqrArtSpecz1855";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1855").src = tripleZeroA;
};

function squareToSzzZValue1856(){
    value45Save = "zSqrArtSpecz1856";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1856").src = tripleZeroA;
};

function squareToSzzZValue1857(){
    value45Save = "zSqrArtSpecz1857";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1857").src = tripleZeroA;
};

function squareToSzzZValue1858(){
    value45Save = "zSqrArtSpecz1858";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1858").src = tripleZeroA;
};

function squareToSzzZValue1859(){
    value45Save = "zSqrArtSpecz1859";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1859").src = tripleZeroA;
};

function squareToSzzZValue1860(){
    value45Save = "zSqrArtSpecz1860";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1860").src = tripleZeroA;
};

function squareToSzzZValue1861(){
    value45Save = "zSqrArtSpecz1861";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1861").src = tripleZeroA;
};

function squareToSzzZValue1862(){
    value45Save = "zSqrArtSpecz1862";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1862").src = tripleZeroA;
};

function squareToSzzZValue1863(){
    value45Save = "zSqrArtSpecz1863";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1863").src = tripleZeroA;
};

function squareToSzzZValue1864(){
    value45Save = "zSqrArtSpecz1864";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1864").src = tripleZeroA;
};

function squareToSzzZValue1865(){
    value45Save = "zSqrArtSpecz1865";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1865").src = tripleZeroA;
};

function squareToSzzZValue1866(){
    value45Save = "zSqrArtSpecz1866";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1866").src = tripleZeroA;
};

function squareToSzzZValue1867(){
    value45Save = "zSqrArtSpecz1867";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1867").src = tripleZeroA;
};

function squareToSzzZValue1868(){
    value45Save = "zSqrArtSpecz1868";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1868").src = tripleZeroA;
};

function squareToSzzZValue1869(){
    value45Save = "zSqrArtSpecz1869";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1869").src = tripleZeroA;
};

function squareToSzzZValue1870(){
    value45Save = "zSqrArtSpecz1870";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1870").src = tripleZeroA;
};

function squareToSzzZValue1871(){
    value45Save = "zSqrArtSpecz1871";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1871").src = tripleZeroA;
};

function squareToSzzZValue1872(){
    value45Save = "zSqrArtSpecz1872";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1872").src = tripleZeroA;
};

function squareToSzzZValue1873(){
    value45Save = "zSqrArtSpecz1873";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1873").src = tripleZeroA;
};

function squareToSzzZValue1874(){
    value45Save = "zSqrArtSpecz1874";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1874").src = tripleZeroA;
};

function squareToSzzZValue1875(){
    value45Save = "zSqrArtSpecz1875";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1875").src = tripleZeroA;
};

function squareToSzzZValue1876(){
    value45Save = "zSqrArtSpecz1876";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1876").src = tripleZeroA;
};

function squareToSzzZValue1877(){
    value45Save = "zSqrArtSpecz1877";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1877").src = tripleZeroA;
};

function squareToSzzZValue1878(){
    value45Save = "zSqrArtSpecz1878";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1878").src = tripleZeroA;
};

function squareToSzzZValue1879(){
    value45Save = "zSqrArtSpecz1879";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1879").src = tripleZeroA;
};

function squareToSzzZValue1880(){
    value45Save = "zSqrArtSpecz1880";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1880").src = tripleZeroA;
};

function squareToSzzZValue1881(){
    value45Save = "zSqrArtSpecz1881";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1881").src = tripleZeroA;
};

function squareToSzzZValue1882(){
    value45Save = "zSqrArtSpecz1882";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1882").src = tripleZeroA;
};

function squareToSzzZValue1883(){
    value45Save = "zSqrArtSpecz1883";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1883").src = tripleZeroA;
};

function squareToSzzZValue1884(){
    value45Save = "zSqrArtSpecz1884";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1884").src = tripleZeroA;
};

function squareToSzzZValue1885(){
    value45Save = "zSqrArtSpecz1885";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1885").src = tripleZeroA;
};

function squareToSzzZValue1886(){
    value45Save = "zSqrArtSpecz1886";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1886").src = tripleZeroA;
};

function squareToSzzZValue1887(){
    value45Save = "zSqrArtSpecz1887";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1887").src = tripleZeroA;
};

function squareToSzzZValue1888(){
    value45Save = "zSqrArtSpecz1888";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1888").src = tripleZeroA;
};

function squareToSzzZValue1889(){
    value45Save = "zSqrArtSpecz1889";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1889").src = tripleZeroA;
};

function squareToSzzZValue1890(){
    value45Save = "zSqrArtSpecz1890";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1890").src = tripleZeroA;
};

function squareToSzzZValue1891(){
    value45Save = "zSqrArtSpecz1891";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1891").src = tripleZeroA;
};

function squareToSzzZValue1892(){
    value45Save = "zSqrArtSpecz1892";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1892").src = tripleZeroA;
};

function squareToSzzZValue1893(){
    value45Save = "zSqrArtSpecz1893";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1893").src = tripleZeroA;
};

function squareToSzzZValue1894(){
    value45Save = "zSqrArtSpecz1894";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1894").src = tripleZeroA;
};

function squareToSzzZValue1895(){
    value45Save = "zSqrArtSpecz1895";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1895").src = tripleZeroA;
};

function squareToSzzZValue1896(){
    value45Save = "zSqrArtSpecz1896";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1896").src = tripleZeroA;
};

function squareToSzzZValue1897(){
    value45Save = "zSqrArtSpecz1897";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1897").src = tripleZeroA;
};

function squareToSzzZValue1898(){
    value45Save = "zSqrArtSpecz1898";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1898").src = tripleZeroA;
};

function squareToSzzZValue1899(){
    value45Save = "zSqrArtSpecz1899";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1899").src = tripleZeroA;
};

function squareToSzzZValue1900(){
    value45Save = "zSqrArtSpecz1900";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1900").src = tripleZeroA;
};

function squareToSzzZValue1901(){
    value45Save = "zSqrArtSpecz1901";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1901").src = tripleZeroA;
};

function squareToSzzZValue1902(){
    value45Save = "zSqrArtSpecz1902";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1902").src = tripleZeroA;
};

function squareToSzzZValue1903(){
    value45Save = "zSqrArtSpecz1903";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1903").src = tripleZeroA;
};

function squareToSzzZValue1904(){
    value45Save = "zSqrArtSpecz1904";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1904").src = tripleZeroA;
};

function squareToSzzZValue1905(){
    value45Save = "zSqrArtSpecz1905";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1905").src = tripleZeroA;
};

function squareToSzzZValue1906(){
    value45Save = "zSqrArtSpecz1906";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1906").src = tripleZeroA;
};

function squareToSzzZValue1907(){
    value45Save = "zSqrArtSpecz1907";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1907").src = tripleZeroA;
};

function squareToSzzZValue1908(){
    value45Save = "zSqrArtSpecz1908";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1908").src = tripleZeroA;
};

function squareToSzzZValue1909(){
    value45Save = "zSqrArtSpecz1909";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1909").src = tripleZeroA;
};

function squareToSzzZValue1910(){
    value45Save = "zSqrArtSpecz1910";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1910").src = tripleZeroA;
};

function squareToSzzZValue1911(){
    value45Save = "zSqrArtSpecz1911";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1911").src = tripleZeroA;
};

function squareToSzzZValue1912(){
    value45Save = "zSqrArtSpecz1912";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1912").src = tripleZeroA;
};

function squareToSzzZValue1913(){
    value45Save = "zSqrArtSpecz1913";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1913").src = tripleZeroA;
};

function squareToSzzZValue1914(){
    value45Save = "zSqrArtSpecz1914";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1914").src = tripleZeroA;
};

function squareToSzzZValue1915(){
    value45Save = "zSqrArtSpecz1915";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1915").src = tripleZeroA;
};

function squareToSzzZValue1916(){
    value45Save = "zSqrArtSpecz1916";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1916").src = tripleZeroA;
};

function squareToSzzZValue1917(){
    value45Save = "zSqrArtSpecz1917";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1917").src = tripleZeroA;
};

function squareToSzzZValue1918(){
    value45Save = "zSqrArtSpecz1918";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1918").src = tripleZeroA;
};

function squareToSzzZValue1919(){
    value45Save = "zSqrArtSpecz1919";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1919").src = tripleZeroA;
};

function squareToSzzZValue1920(){
    value45Save = "zSqrArtSpecz1920";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1920").src = tripleZeroA;
};

function squareToSzzZValue1921(){
    value45Save = "zSqrArtSpecz1921";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1921").src = tripleZeroA;
};

function squareToSzzZValue1922(){
    value45Save = "zSqrArtSpecz1922";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1922").src = tripleZeroA;
};

function squareToSzzZValue1923(){
    value45Save = "zSqrArtSpecz1923";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1923").src = tripleZeroA;
};

function squareToSzzZValue1924(){
    value45Save = "zSqrArtSpecz1924";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1924").src = tripleZeroA;
};

function squareToSzzZValue1925(){
    value45Save = "zSqrArtSpecz1925";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1925").src = tripleZeroA;
};

function squareToSzzZValue1926(){
    value45Save = "zSqrArtSpecz1926";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1926").src = tripleZeroA;
};

function squareToSzzZValue1927(){
    value45Save = "zSqrArtSpecz1927";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1927").src = tripleZeroA;
};

function squareToSzzZValue1928(){
    value45Save = "zSqrArtSpecz1928";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1928").src = tripleZeroA;
};

function squareToSzzZValue1929(){
    value45Save = "zSqrArtSpecz1929";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1929").src = tripleZeroA;
};

function squareToSzzZValue1930(){
    value45Save = "zSqrArtSpecz1930";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1930").src = tripleZeroA;
};

function squareToSzzZValue1931(){
    value45Save = "zSqrArtSpecz1931";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1931").src = tripleZeroA;
};

function squareToSzzZValue1932(){
    value45Save = "zSqrArtSpecz1932";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1932").src = tripleZeroA;
};

function squareToSzzZValue1933(){
    value45Save = "zSqrArtSpecz1933";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1933").src = tripleZeroA;
};

function squareToSzzZValue1934(){
    value45Save = "zSqrArtSpecz1934";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1934").src = tripleZeroA;
};

function squareToSzzZValue1935(){
    value45Save = "zSqrArtSpecz1935";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1935").src = tripleZeroA;
};

function squareToSzzZValue1936(){
    value45Save = "zSqrArtSpecz1936";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1936").src = tripleZeroA;
};

function squareToSzzZValue1937(){
    value45Save = "zSqrArtSpecz1937";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1937").src = tripleZeroA;
};

function squareToSzzZValue1938(){
    value45Save = "zSqrArtSpecz1938";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1938").src = tripleZeroA;
};

function squareToSzzZValue1939(){
    value45Save = "zSqrArtSpecz1939";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1939").src = tripleZeroA;
};

function squareToSzzZValue1940(){
    value45Save = "zSqrArtSpecz1940";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1940").src = tripleZeroA;
};

function squareToSzzZValue1941(){
    value45Save = "zSqrArtSpecz1941";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1941").src = tripleZeroA;
};

function squareToSzzZValue1942(){
    value45Save = "zSqrArtSpecz1942";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1942").src = tripleZeroA;
};

function squareToSzzZValue1943(){
    value45Save = "zSqrArtSpecz1943";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1943").src = tripleZeroA;
};

function squareToSzzZValue1944(){
    value45Save = "zSqrArtSpecz1944";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1944").src = tripleZeroA;
};

function squareToSzzZValue1945(){
    value45Save = "zSqrArtSpecz1945";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1945").src = tripleZeroA;
};

function squareToSzzZValue1946(){
    value45Save = "zSqrArtSpecz1946";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1946").src = tripleZeroA;
};

function squareToSzzZValue1947(){
    value45Save = "zSqrArtSpecz1947";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1947").src = tripleZeroA;
};

function squareToSzzZValue1948(){
    value45Save = "zSqrArtSpecz1948";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1948").src = tripleZeroA;
};

function squareToSzzZValue1949(){
    value45Save = "zSqrArtSpecz1949";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1949").src = tripleZeroA;
};

function squareToSzzZValue1950(){
    value45Save = "zSqrArtSpecz1950";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1950").src = tripleZeroA;
};

function squareToSzzZValue1951(){
    value45Save = "zSqrArtSpecz1951";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1951").src = tripleZeroA;
};

function squareToSzzZValue1952(){
    value45Save = "zSqrArtSpecz1952";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1952").src = tripleZeroA;
};

function squareToSzzZValue1953(){
    value45Save = "zSqrArtSpecz1953";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1953").src = tripleZeroA;
};

function squareToSzzZValue1954(){
    value45Save = "zSqrArtSpecz1954";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1954").src = tripleZeroA;
};

function squareToSzzZValue1955(){
    value45Save = "zSqrArtSpecz1955";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1955").src = tripleZeroA;
};

function squareToSzzZValue1956(){
    value45Save = "zSqrArtSpecz1956";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1956").src = tripleZeroA;
};

function squareToSzzZValue1957(){
    value45Save = "zSqrArtSpecz1957";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1957").src = tripleZeroA;
};

function squareToSzzZValue1958(){
    value45Save = "zSqrArtSpecz1958";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1958").src = tripleZeroA;
};

function squareToSzzZValue1959(){
    value45Save = "zSqrArtSpecz1959";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1959").src = tripleZeroA;
};

function squareToSzzZValue1960(){
    value45Save = "zSqrArtSpecz1960";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1960").src = tripleZeroA;
};

function squareToSzzZValue1961(){
    value45Save = "zSqrArtSpecz1961";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1961").src = tripleZeroA;
};

function squareToSzzZValue1962(){
    value45Save = "zSqrArtSpecz1962";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1962").src = tripleZeroA;
};

function squareToSzzZValue1963(){
    value45Save = "zSqrArtSpecz1963";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1963").src = tripleZeroA;
};

function squareToSzzZValue1964(){
    value45Save = "zSqrArtSpecz1964";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1964").src = tripleZeroA;
};

function squareToSzzZValue1965(){
    value45Save = "zSqrArtSpecz1965";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1965").src = tripleZeroA;
};

function squareToSzzZValue1966(){
    value45Save = "zSqrArtSpecz1966";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1966").src = tripleZeroA;
};

function squareToSzzZValue1967(){
    value45Save = "zSqrArtSpecz1967";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1967").src = tripleZeroA;
};

function squareToSzzZValue1968(){
    value45Save = "zSqrArtSpecz1968";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1968").src = tripleZeroA;
};

function squareToSzzZValue1969(){
    value45Save = "zSqrArtSpecz1969";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1969").src = tripleZeroA;
};

function squareToSzzZValue1970(){
    value45Save = "zSqrArtSpecz1970";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1970").src = tripleZeroA;
};

function squareToSzzZValue1971(){
    value45Save = "zSqrArtSpecz1971";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1971").src = tripleZeroA;
};

function squareToSzzZValue1972(){
    value45Save = "zSqrArtSpecz1972";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1972").src = tripleZeroA;
};

function squareToSzzZValue1973(){
    value45Save = "zSqrArtSpecz1973";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1973").src = tripleZeroA;
};

function squareToSzzZValue1974(){
    value45Save = "zSqrArtSpecz1974";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1974").src = tripleZeroA;
};

function squareToSzzZValue1975(){
    value45Save = "zSqrArtSpecz1975";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1975").src = tripleZeroA;
};

function squareToSzzZValue1976(){
    value45Save = "zSqrArtSpecz1976";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1976").src = tripleZeroA;
};

function squareToSzzZValue1977(){
    value45Save = "zSqrArtSpecz1977";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1977").src = tripleZeroA;
};

function squareToSzzZValue1978(){
    value45Save = "zSqrArtSpecz1978";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1978").src = tripleZeroA;
};

function squareToSzzZValue1979(){
    value45Save = "zSqrArtSpecz1979";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1979").src = tripleZeroA;
};

function squareToSzzZValue1980(){
    value45Save = "zSqrArtSpecz1980";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1980").src = tripleZeroA;
};

function squareToSzzZValue1981(){
    value45Save = "zSqrArtSpecz1981";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1981").src = tripleZeroA;
};

function squareToSzzZValue1982(){
    value45Save = "zSqrArtSpecz1982";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1982").src = tripleZeroA;
};

function squareToSzzZValue1983(){
    value45Save = "zSqrArtSpecz1983";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1983").src = tripleZeroA;
};

function squareToSzzZValue1984(){
    value45Save = "zSqrArtSpecz1984";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1984").src = tripleZeroA;
};

function squareToSzzZValue1985(){
    value45Save = "zSqrArtSpecz1985";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1985").src = tripleZeroA;
};

function squareToSzzZValue1986(){
    value45Save = "zSqrArtSpecz1986";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1986").src = tripleZeroA;
};

function squareToSzzZValue1987(){
    value45Save = "zSqrArtSpecz1987";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1987").src = tripleZeroA;
};

function squareToSzzZValue1988(){
    value45Save = "zSqrArtSpecz1988";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1988").src = tripleZeroA;
};

function squareToSzzZValue1989(){
    value45Save = "zSqrArtSpecz1989";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1989").src = tripleZeroA;
};

function squareToSzzZValue1990(){
    value45Save = "zSqrArtSpecz1990";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1990").src = tripleZeroA;
};

function squareToSzzZValue1991(){
    value45Save = "zSqrArtSpecz1991";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1991").src = tripleZeroA;
};

function squareToSzzZValue1992(){
    value45Save = "zSqrArtSpecz1992";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1992").src = tripleZeroA;
};

function squareToSzzZValue1993(){
    value45Save = "zSqrArtSpecz1993";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1993").src = tripleZeroA;
};

function squareToSzzZValue1994(){
    value45Save = "zSqrArtSpecz1994";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1994").src = tripleZeroA;
};

function squareToSzzZValue1995(){
    value45Save = "zSqrArtSpecz1995";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1995").src = tripleZeroA;
};

function squareToSzzZValue1996(){
    value45Save = "zSqrArtSpecz1996";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1996").src = tripleZeroA;
};

function squareToSzzZValue1997(){
    value45Save = "zSqrArtSpecz1997";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1997").src = tripleZeroA;
};

function squareToSzzZValue1998(){
    value45Save = "zSqrArtSpecz1998";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1998").src = tripleZeroA;
};

function squareToSzzZValue1999(){
    value45Save = "zSqrArtSpecz1999";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs1999").src = tripleZeroA;
};

function squareToSzzZValue2000(){
    value45Save = "zSqrArtSpecz2000";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs2000").src = tripleZeroA;
};

function squareToSzzZValue2001(){
    value45Save = "zSqrArtSpecz2001";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs2001").src = tripleZeroA;
};

function squareToSzzZValue2002(){
    value45Save = "zSqrArtSpecz2002";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs2002").src = tripleZeroA;
};

function squareToSzzZValue2003(){
    value45Save = "zSqrArtSpecz2003";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs2003").src = tripleZeroA;
};

function squareToSzzZValue2004(){
    value45Save = "zSqrArtSpecz2004";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs2004").src = tripleZeroA;
};

function squareToSzzZValue2005(){
    value45Save = "zSqrArtSpecz2005";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs2005").src = tripleZeroA;
};

function squareToSzzZValue2006(){
    value45Save = "zSqrArtSpecz2006";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs2006").src = tripleZeroA;
};

function squareToSzzZValue2007(){
    value45Save = "zSqrArtSpecz2007";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs2007").src = tripleZeroA;
};

function squareToSzzZValue2008(){
    value45Save = "zSqrArtSpecz2008";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs2008").src = tripleZeroA;
};

function squareToSzzZValue2009(){
    value45Save = "zSqrArtSpecz2009";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs2009").src = tripleZeroA;
};

function squareToSzzZValue2010(){
    value45Save = "zSqrArtSpecz2010";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs2010").src = tripleZeroA;
};

function squareToSzzZValue2011(){
    value45Save = "zSqrArtSpecz2011";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs2011").src = tripleZeroA;
};

function squareToSzzZValue2012(){
    value45Save = "zSqrArtSpecz2012";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs2012").src = tripleZeroA;
};

function squareToSzzZValue2013(){
    value45Save = "zSqrArtSpecz2013";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs2013").src = tripleZeroA;
};

function squareToSzzZValue2014(){
    value45Save = "zSqrArtSpecz2014";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs2014").src = tripleZeroA;
};

function squareToSzzZValue2015(){
    value45Save = "zSqrArtSpecz2015";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs2015").src = tripleZeroA;
};

function squareToSzzZValue2016(){
    value45Save = "zSqrArtSpecz2016";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs2016").src = tripleZeroA;
};

function squareToSzzZValue2017(){
    value45Save = "zSqrArtSpecz2017";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs2017").src = tripleZeroA;
};

function squareToSzzZValue2018(){
    value45Save = "zSqrArtSpecz2018";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs2018").src = tripleZeroA;
};

function squareToSzzZValue2019(){
    value45Save = "zSqrArtSpecz2019";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs2019").src = tripleZeroA;
};

function squareToSzzZValue2020(){
    value45Save = "zSqrArtSpecz2020";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs2020").src = tripleZeroA;
};

function squareToSzzZValue2021(){
    value45Save = "zSqrArtSpecz2021";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs2021").src = tripleZeroA;
};

function squareToSzzZValue2022(){
    value45Save = "zSqrArtSpecz2022";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs2022").src = tripleZeroA;
};

function squareToSzzZValue2023(){
    value45Save = "zSqrArtSpecz2023";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs2023").src = tripleZeroA;
};

function squareToSzzZValue2024(){
    value45Save = "zSqrArtSpecz2024";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs2024").src = tripleZeroA;
};

function squareToSzzZValue2025(){
    value45Save = "zSqrArtSpecz2025";
    var tripleZeroA = localStorage.getItem(value45Save);
    document.getElementById("imgSqrs2025").src = tripleZeroA;
};

function getBThis(){
    squareToSzzZValue1()

    squareToSzzZValue2()

    squareToSzzZValue3()

    squareToSzzZValue4()

    squareToSzzZValue5()

    squareToSzzZValue6()

    squareToSzzZValue7()

    squareToSzzZValue8()

    squareToSzzZValue9()

    squareToSzzZValue10()

    squareToSzzZValue11()

    squareToSzzZValue12()

    squareToSzzZValue13()

    squareToSzzZValue14()

    squareToSzzZValue15()

    squareToSzzZValue16()

    squareToSzzZValue17()

    squareToSzzZValue18()

    squareToSzzZValue19()

    squareToSzzZValue20()

    squareToSzzZValue21()

    squareToSzzZValue22()

    squareToSzzZValue23()

    squareToSzzZValue24()

    squareToSzzZValue25()

    squareToSzzZValue26()

    squareToSzzZValue27()

    squareToSzzZValue28()

    squareToSzzZValue29()

    squareToSzzZValue30()

    squareToSzzZValue31()

    squareToSzzZValue32()

    squareToSzzZValue33()

    squareToSzzZValue34()

    squareToSzzZValue35()

    squareToSzzZValue36()

    squareToSzzZValue37()

    squareToSzzZValue38()

    squareToSzzZValue39()

    squareToSzzZValue40()

    squareToSzzZValue41()

    squareToSzzZValue42()

    squareToSzzZValue43()

    squareToSzzZValue44()

    squareToSzzZValue45()

    squareToSzzZValue46()

    squareToSzzZValue47()

    squareToSzzZValue48()

    squareToSzzZValue49()

    squareToSzzZValue50()

    squareToSzzZValue51()

    squareToSzzZValue52()

    squareToSzzZValue53()

    squareToSzzZValue54()

    squareToSzzZValue55()

    squareToSzzZValue56()

    squareToSzzZValue57()

    squareToSzzZValue58()

    squareToSzzZValue59()

    squareToSzzZValue60()

    squareToSzzZValue61()

    squareToSzzZValue62()

    squareToSzzZValue63()

    squareToSzzZValue64()

    squareToSzzZValue65()

    squareToSzzZValue66()

    squareToSzzZValue67()

    squareToSzzZValue68()

    squareToSzzZValue69()

    squareToSzzZValue70()

    squareToSzzZValue71()

    squareToSzzZValue72()

    squareToSzzZValue73()

    squareToSzzZValue74()

    squareToSzzZValue75()

    squareToSzzZValue76()

    squareToSzzZValue77()

    squareToSzzZValue78()

    squareToSzzZValue79()

    squareToSzzZValue80()

    squareToSzzZValue81()

    squareToSzzZValue82()

    squareToSzzZValue83()

    squareToSzzZValue84()

    squareToSzzZValue85()

    squareToSzzZValue86()

    squareToSzzZValue87()

    squareToSzzZValue88()

    squareToSzzZValue89()

    squareToSzzZValue90()

    squareToSzzZValue91()

    squareToSzzZValue92()

    squareToSzzZValue93()

    squareToSzzZValue94()

    squareToSzzZValue95()

    squareToSzzZValue96()

    squareToSzzZValue97()

    squareToSzzZValue98()

    squareToSzzZValue99()

    squareToSzzZValue100()

    squareToSzzZValue101()

    squareToSzzZValue102()

    squareToSzzZValue103()

    squareToSzzZValue104()

    squareToSzzZValue105()

    squareToSzzZValue106()

    squareToSzzZValue107()

    squareToSzzZValue108()

    squareToSzzZValue109()

    squareToSzzZValue110()

    squareToSzzZValue111()

    squareToSzzZValue112()

    squareToSzzZValue113()

    squareToSzzZValue114()

    squareToSzzZValue115()

    squareToSzzZValue116()

    squareToSzzZValue117()

    squareToSzzZValue118()

    squareToSzzZValue119()

    squareToSzzZValue120()

    squareToSzzZValue121()

    squareToSzzZValue122()

    squareToSzzZValue123()

    squareToSzzZValue124()

    squareToSzzZValue125()

    squareToSzzZValue126()

    squareToSzzZValue127()

    squareToSzzZValue128()

    squareToSzzZValue129()

    squareToSzzZValue130()

    squareToSzzZValue131()

    squareToSzzZValue132()

    squareToSzzZValue133()

    squareToSzzZValue134()

    squareToSzzZValue135()

    squareToSzzZValue136()

    squareToSzzZValue137()

    squareToSzzZValue138()

    squareToSzzZValue139()

    squareToSzzZValue140()

    squareToSzzZValue141()

    squareToSzzZValue142()

    squareToSzzZValue143()

    squareToSzzZValue144()

    squareToSzzZValue145()

    squareToSzzZValue146()

    squareToSzzZValue147()

    squareToSzzZValue148()

    squareToSzzZValue149()

    squareToSzzZValue150()

    squareToSzzZValue151()

    squareToSzzZValue152()

    squareToSzzZValue153()

    squareToSzzZValue154()

    squareToSzzZValue155()

    squareToSzzZValue156()

    squareToSzzZValue157()

    squareToSzzZValue158()

    squareToSzzZValue159()

    squareToSzzZValue160()

    squareToSzzZValue161()

    squareToSzzZValue162()

    squareToSzzZValue163()

    squareToSzzZValue164()

    squareToSzzZValue165()

    squareToSzzZValue166()

    squareToSzzZValue167()

    squareToSzzZValue168()

    squareToSzzZValue169()

    squareToSzzZValue170()

    squareToSzzZValue171()

    squareToSzzZValue172()

    squareToSzzZValue173()

    squareToSzzZValue174()

    squareToSzzZValue175()

    squareToSzzZValue176()

    squareToSzzZValue177()

    squareToSzzZValue178()

    squareToSzzZValue179()

    squareToSzzZValue180()

    squareToSzzZValue181()

    squareToSzzZValue182()

    squareToSzzZValue183()

    squareToSzzZValue184()

    squareToSzzZValue185()

    squareToSzzZValue186()

    squareToSzzZValue187()

    squareToSzzZValue188()

    squareToSzzZValue189()

    squareToSzzZValue190()

    squareToSzzZValue191()

    squareToSzzZValue192()

    squareToSzzZValue193()

    squareToSzzZValue194()

    squareToSzzZValue195()

    squareToSzzZValue196()

    squareToSzzZValue197()

    squareToSzzZValue198()

    squareToSzzZValue199()

    squareToSzzZValue200()

    squareToSzzZValue201()

    squareToSzzZValue202()

    squareToSzzZValue203()

    squareToSzzZValue204()

    squareToSzzZValue205()

    squareToSzzZValue206()

    squareToSzzZValue207()

    squareToSzzZValue208()

    squareToSzzZValue209()

    squareToSzzZValue210()

    squareToSzzZValue211()

    squareToSzzZValue212()

    squareToSzzZValue213()

    squareToSzzZValue214()

    squareToSzzZValue215()

    squareToSzzZValue216()

    squareToSzzZValue217()

    squareToSzzZValue218()

    squareToSzzZValue219()

    squareToSzzZValue220()

    squareToSzzZValue221()

    squareToSzzZValue222()

    squareToSzzZValue223()

    squareToSzzZValue224()

    squareToSzzZValue225()

    squareToSzzZValue226()

    squareToSzzZValue227()

    squareToSzzZValue228()

    squareToSzzZValue229()

    squareToSzzZValue230()

    squareToSzzZValue231()

    squareToSzzZValue232()

    squareToSzzZValue233()

    squareToSzzZValue234()

    squareToSzzZValue235()

    squareToSzzZValue236()

    squareToSzzZValue237()

    squareToSzzZValue238()

    squareToSzzZValue239()

    squareToSzzZValue240()

    squareToSzzZValue241()

    squareToSzzZValue242()

    squareToSzzZValue243()

    squareToSzzZValue244()

    squareToSzzZValue245()

    squareToSzzZValue246()

    squareToSzzZValue247()

    squareToSzzZValue248()

    squareToSzzZValue249()

    squareToSzzZValue250()

    squareToSzzZValue251()

    squareToSzzZValue252()

    squareToSzzZValue253()

    squareToSzzZValue254()

    squareToSzzZValue255()

    squareToSzzZValue256()

    squareToSzzZValue257()

    squareToSzzZValue258()

    squareToSzzZValue259()

    squareToSzzZValue260()

    squareToSzzZValue261()

    squareToSzzZValue262()

    squareToSzzZValue263()

    squareToSzzZValue264()

    squareToSzzZValue265()

    squareToSzzZValue266()

    squareToSzzZValue267()

    squareToSzzZValue268()

    squareToSzzZValue269()

    squareToSzzZValue270()

    squareToSzzZValue271()

    squareToSzzZValue272()

    squareToSzzZValue273()

    squareToSzzZValue274()

    squareToSzzZValue275()

    squareToSzzZValue276()

    squareToSzzZValue277()

    squareToSzzZValue278()

    squareToSzzZValue279()

    squareToSzzZValue280()

    squareToSzzZValue281()

    squareToSzzZValue282()

    squareToSzzZValue283()

    squareToSzzZValue284()

    squareToSzzZValue285()

    squareToSzzZValue286()

    squareToSzzZValue287()

    squareToSzzZValue288()

    squareToSzzZValue289()

    squareToSzzZValue290()

    squareToSzzZValue291()

    squareToSzzZValue292()

    squareToSzzZValue293()

    squareToSzzZValue294()

    squareToSzzZValue295()

    squareToSzzZValue296()

    squareToSzzZValue297()

    squareToSzzZValue298()

    squareToSzzZValue299()

    squareToSzzZValue300()

    squareToSzzZValue301()

    squareToSzzZValue302()

    squareToSzzZValue303()

    squareToSzzZValue304()

    squareToSzzZValue305()

    squareToSzzZValue306()

    squareToSzzZValue307()

    squareToSzzZValue308()

    squareToSzzZValue309()

    squareToSzzZValue310()

    squareToSzzZValue311()

    squareToSzzZValue312()

    squareToSzzZValue313()

    squareToSzzZValue314()

    squareToSzzZValue315()

    squareToSzzZValue316()

    squareToSzzZValue317()

    squareToSzzZValue318()

    squareToSzzZValue319()

    squareToSzzZValue320()

    squareToSzzZValue321()

    squareToSzzZValue322()

    squareToSzzZValue323()

    squareToSzzZValue324()

    squareToSzzZValue325()

    squareToSzzZValue326()

    squareToSzzZValue327()

    squareToSzzZValue328()

    squareToSzzZValue329()

    squareToSzzZValue330()

    squareToSzzZValue331()

    squareToSzzZValue332()

    squareToSzzZValue333()

    squareToSzzZValue334()

    squareToSzzZValue335()

    squareToSzzZValue336()

    squareToSzzZValue337()

    squareToSzzZValue338()

    squareToSzzZValue339()

    squareToSzzZValue340()

    squareToSzzZValue341()

    squareToSzzZValue342()

    squareToSzzZValue343()

    squareToSzzZValue344()

    squareToSzzZValue345()

    squareToSzzZValue346()

    squareToSzzZValue347()

    squareToSzzZValue348()

    squareToSzzZValue349()

    squareToSzzZValue350()

    squareToSzzZValue351()

    squareToSzzZValue352()

    squareToSzzZValue353()

    squareToSzzZValue354()

    squareToSzzZValue355()

    squareToSzzZValue356()

    squareToSzzZValue357()

    squareToSzzZValue358()

    squareToSzzZValue359()

    squareToSzzZValue360()

    squareToSzzZValue361()

    squareToSzzZValue362()

    squareToSzzZValue363()

    squareToSzzZValue364()

    squareToSzzZValue365()

    squareToSzzZValue366()

    squareToSzzZValue367()

    squareToSzzZValue368()

    squareToSzzZValue369()

    squareToSzzZValue370()

    squareToSzzZValue371()

    squareToSzzZValue372()

    squareToSzzZValue373()

    squareToSzzZValue374()

    squareToSzzZValue375()

    squareToSzzZValue376()

    squareToSzzZValue377()

    squareToSzzZValue378()

    squareToSzzZValue379()

    squareToSzzZValue380()

    squareToSzzZValue381()

    squareToSzzZValue382()

    squareToSzzZValue383()

    squareToSzzZValue384()

    squareToSzzZValue385()

    squareToSzzZValue386()

    squareToSzzZValue387()

    squareToSzzZValue388()

    squareToSzzZValue389()

    squareToSzzZValue390()

    squareToSzzZValue391()

    squareToSzzZValue392()

    squareToSzzZValue393()

    squareToSzzZValue394()

    squareToSzzZValue395()

    squareToSzzZValue396()

    squareToSzzZValue397()

    squareToSzzZValue398()

    squareToSzzZValue399()

    squareToSzzZValue400()

    squareToSzzZValue401()

    squareToSzzZValue402()

    squareToSzzZValue403()

    squareToSzzZValue404()

    squareToSzzZValue405()

    squareToSzzZValue406()

    squareToSzzZValue407()

    squareToSzzZValue408()

    squareToSzzZValue409()

    squareToSzzZValue410()

    squareToSzzZValue411()

    squareToSzzZValue412()

    squareToSzzZValue413()

    squareToSzzZValue414()

    squareToSzzZValue415()

    squareToSzzZValue416()

    squareToSzzZValue417()

    squareToSzzZValue418()

    squareToSzzZValue419()

    squareToSzzZValue420()

    squareToSzzZValue421()

    squareToSzzZValue422()

    squareToSzzZValue423()

    squareToSzzZValue424()

    squareToSzzZValue425()

    squareToSzzZValue426()

    squareToSzzZValue427()

    squareToSzzZValue428()

    squareToSzzZValue429()

    squareToSzzZValue430()

    squareToSzzZValue431()

    squareToSzzZValue432()

    squareToSzzZValue433()

    squareToSzzZValue434()

    squareToSzzZValue435()

    squareToSzzZValue436()

    squareToSzzZValue437()

    squareToSzzZValue438()

    squareToSzzZValue439()

    squareToSzzZValue440()

    squareToSzzZValue441()

    squareToSzzZValue442()

    squareToSzzZValue443()

    squareToSzzZValue444()

    squareToSzzZValue445()

    squareToSzzZValue446()

    squareToSzzZValue447()

    squareToSzzZValue448()

    squareToSzzZValue449()

    squareToSzzZValue450()

    squareToSzzZValue451()

    squareToSzzZValue452()

    squareToSzzZValue453()

    squareToSzzZValue454()

    squareToSzzZValue455()

    squareToSzzZValue456()

    squareToSzzZValue457()

    squareToSzzZValue458()

    squareToSzzZValue459()

    squareToSzzZValue460()

    squareToSzzZValue461()

    squareToSzzZValue462()

    squareToSzzZValue463()

    squareToSzzZValue464()

    squareToSzzZValue465()

    squareToSzzZValue466()

    squareToSzzZValue467()

    squareToSzzZValue468()

    squareToSzzZValue469()

    squareToSzzZValue470()

    squareToSzzZValue471()

    squareToSzzZValue472()

    squareToSzzZValue473()

    squareToSzzZValue474()

    squareToSzzZValue475()

    squareToSzzZValue476()

    squareToSzzZValue477()

    squareToSzzZValue478()

    squareToSzzZValue479()

    squareToSzzZValue480()

    squareToSzzZValue481()

    squareToSzzZValue482()

    squareToSzzZValue483()

    squareToSzzZValue484()

    squareToSzzZValue485()

    squareToSzzZValue486()

    squareToSzzZValue487()

    squareToSzzZValue488()

    squareToSzzZValue489()

    squareToSzzZValue490()

    squareToSzzZValue491()

    squareToSzzZValue492()

    squareToSzzZValue493()

    squareToSzzZValue494()

    squareToSzzZValue495()

    squareToSzzZValue496()

    squareToSzzZValue497()

    squareToSzzZValue498()

    squareToSzzZValue499()

    squareToSzzZValue500()

    squareToSzzZValue501()

    squareToSzzZValue502()

    squareToSzzZValue503()

    squareToSzzZValue504()

    squareToSzzZValue505()

    squareToSzzZValue506()

    squareToSzzZValue507()

    squareToSzzZValue508()

    squareToSzzZValue509()

    squareToSzzZValue510()

    squareToSzzZValue511()

    squareToSzzZValue512()

    squareToSzzZValue513()

    squareToSzzZValue514()

    squareToSzzZValue515()

    squareToSzzZValue516()

    squareToSzzZValue517()

    squareToSzzZValue518()

    squareToSzzZValue519()

    squareToSzzZValue520()

    squareToSzzZValue521()

    squareToSzzZValue522()

    squareToSzzZValue523()

    squareToSzzZValue524()

    squareToSzzZValue525()

    squareToSzzZValue526()

    squareToSzzZValue527()

    squareToSzzZValue528()

    squareToSzzZValue529()

    squareToSzzZValue530()

    squareToSzzZValue531()

    squareToSzzZValue532()

    squareToSzzZValue533()

    squareToSzzZValue534()

    squareToSzzZValue535()

    squareToSzzZValue536()

    squareToSzzZValue537()

    squareToSzzZValue538()

    squareToSzzZValue539()

    squareToSzzZValue540()

    squareToSzzZValue541()

    squareToSzzZValue542()

    squareToSzzZValue543()

    squareToSzzZValue544()

    squareToSzzZValue545()

    squareToSzzZValue546()

    squareToSzzZValue547()

    squareToSzzZValue548()

    squareToSzzZValue549()

    squareToSzzZValue550()

    squareToSzzZValue551()

    squareToSzzZValue552()

    squareToSzzZValue553()

    squareToSzzZValue554()

    squareToSzzZValue555()

    squareToSzzZValue556()

    squareToSzzZValue557()

    squareToSzzZValue558()

    squareToSzzZValue559()

    squareToSzzZValue560()

    squareToSzzZValue561()

    squareToSzzZValue562()

    squareToSzzZValue563()

    squareToSzzZValue564()

    squareToSzzZValue565()

    squareToSzzZValue566()

    squareToSzzZValue567()

    squareToSzzZValue568()

    squareToSzzZValue569()

    squareToSzzZValue570()

    squareToSzzZValue571()

    squareToSzzZValue572()

    squareToSzzZValue573()

    squareToSzzZValue574()

    squareToSzzZValue575()

    squareToSzzZValue576()

    squareToSzzZValue577()

    squareToSzzZValue578()

    squareToSzzZValue579()

    squareToSzzZValue580()

    squareToSzzZValue581()

    squareToSzzZValue582()

    squareToSzzZValue583()

    squareToSzzZValue584()

    squareToSzzZValue585()

    squareToSzzZValue586()

    squareToSzzZValue587()

    squareToSzzZValue588()

    squareToSzzZValue589()

    squareToSzzZValue590()

    squareToSzzZValue591()

    squareToSzzZValue592()

    squareToSzzZValue593()

    squareToSzzZValue594()

    squareToSzzZValue595()

    squareToSzzZValue596()

    squareToSzzZValue597()

    squareToSzzZValue598()

    squareToSzzZValue599()

    squareToSzzZValue600()

    squareToSzzZValue601()

    squareToSzzZValue602()

    squareToSzzZValue603()

    squareToSzzZValue604()

    squareToSzzZValue605()

    squareToSzzZValue606()

    squareToSzzZValue607()

    squareToSzzZValue608()

    squareToSzzZValue609()

    squareToSzzZValue610()

    squareToSzzZValue611()

    squareToSzzZValue612()

    squareToSzzZValue613()

    squareToSzzZValue614()

    squareToSzzZValue615()

    squareToSzzZValue616()

    squareToSzzZValue617()

    squareToSzzZValue618()

    squareToSzzZValue619()

    squareToSzzZValue620()

    squareToSzzZValue621()

    squareToSzzZValue622()

    squareToSzzZValue623()

    squareToSzzZValue624()

    squareToSzzZValue625()

    squareToSzzZValue626()

    squareToSzzZValue627()

    squareToSzzZValue628()

    squareToSzzZValue629()

    squareToSzzZValue630()

    squareToSzzZValue631()

    squareToSzzZValue632()

    squareToSzzZValue633()

    squareToSzzZValue634()

    squareToSzzZValue635()

    squareToSzzZValue636()

    squareToSzzZValue637()

    squareToSzzZValue638()

    squareToSzzZValue639()

    squareToSzzZValue640()

    squareToSzzZValue641()

    squareToSzzZValue642()

    squareToSzzZValue643()

    squareToSzzZValue644()

    squareToSzzZValue645()

    squareToSzzZValue646()

    squareToSzzZValue647()

    squareToSzzZValue648()

    squareToSzzZValue649()

    squareToSzzZValue650()

    squareToSzzZValue651()

    squareToSzzZValue652()

    squareToSzzZValue653()

    squareToSzzZValue654()

    squareToSzzZValue655()

    squareToSzzZValue656()

    squareToSzzZValue657()

    squareToSzzZValue658()

    squareToSzzZValue659()

    squareToSzzZValue660()

    squareToSzzZValue661()

    squareToSzzZValue662()

    squareToSzzZValue663()

    squareToSzzZValue664()

    squareToSzzZValue665()

    squareToSzzZValue666()

    squareToSzzZValue667()

    squareToSzzZValue668()

    squareToSzzZValue669()

    squareToSzzZValue670()

    squareToSzzZValue671()

    squareToSzzZValue672()

    squareToSzzZValue673()

    squareToSzzZValue674()

    squareToSzzZValue675()

    squareToSzzZValue676()

    squareToSzzZValue677()

    squareToSzzZValue678()

    squareToSzzZValue679()

    squareToSzzZValue680()

    squareToSzzZValue681()

    squareToSzzZValue682()

    squareToSzzZValue683()

    squareToSzzZValue684()

    squareToSzzZValue685()

    squareToSzzZValue686()

    squareToSzzZValue687()

    squareToSzzZValue688()

    squareToSzzZValue689()

    squareToSzzZValue690()

    squareToSzzZValue691()

    squareToSzzZValue692()

    squareToSzzZValue693()

    squareToSzzZValue694()

    squareToSzzZValue695()

    squareToSzzZValue696()

    squareToSzzZValue697()

    squareToSzzZValue698()

    squareToSzzZValue699()

    squareToSzzZValue700()

    squareToSzzZValue701()

    squareToSzzZValue702()

    squareToSzzZValue703()

    squareToSzzZValue704()

    squareToSzzZValue705()

    squareToSzzZValue706()

    squareToSzzZValue707()

    squareToSzzZValue708()

    squareToSzzZValue709()

    squareToSzzZValue710()

    squareToSzzZValue711()

    squareToSzzZValue712()

    squareToSzzZValue713()

    squareToSzzZValue714()

    squareToSzzZValue715()

    squareToSzzZValue716()

    squareToSzzZValue717()

    squareToSzzZValue718()

    squareToSzzZValue719()

    squareToSzzZValue720()

    squareToSzzZValue721()

    squareToSzzZValue722()

    squareToSzzZValue723()

    squareToSzzZValue724()

    squareToSzzZValue725()

    squareToSzzZValue726()

    squareToSzzZValue727()

    squareToSzzZValue728()

    squareToSzzZValue729()

    squareToSzzZValue730()

    squareToSzzZValue731()

    squareToSzzZValue732()

    squareToSzzZValue733()

    squareToSzzZValue734()

    squareToSzzZValue735()

    squareToSzzZValue736()

    squareToSzzZValue737()

    squareToSzzZValue738()

    squareToSzzZValue739()

    squareToSzzZValue740()

    squareToSzzZValue741()

    squareToSzzZValue742()

    squareToSzzZValue743()

    squareToSzzZValue744()

    squareToSzzZValue745()

    squareToSzzZValue746()

    squareToSzzZValue747()

    squareToSzzZValue748()

    squareToSzzZValue749()

    squareToSzzZValue750()

    squareToSzzZValue751()

    squareToSzzZValue752()

    squareToSzzZValue753()

    squareToSzzZValue754()

    squareToSzzZValue755()

    squareToSzzZValue756()

    squareToSzzZValue757()

    squareToSzzZValue758()

    squareToSzzZValue759()

    squareToSzzZValue760()

    squareToSzzZValue761()

    squareToSzzZValue762()

    squareToSzzZValue763()

    squareToSzzZValue764()

    squareToSzzZValue765()

    squareToSzzZValue766()

    squareToSzzZValue767()

    squareToSzzZValue768()

    squareToSzzZValue769()

    squareToSzzZValue770()

    squareToSzzZValue771()

    squareToSzzZValue772()

    squareToSzzZValue773()

    squareToSzzZValue774()

    squareToSzzZValue775()

    squareToSzzZValue776()

    squareToSzzZValue777()

    squareToSzzZValue778()

    squareToSzzZValue779()

    squareToSzzZValue780()

    squareToSzzZValue781()

    squareToSzzZValue782()

    squareToSzzZValue783()

    squareToSzzZValue784()

    squareToSzzZValue785()

    squareToSzzZValue786()

    squareToSzzZValue787()

    squareToSzzZValue788()

    squareToSzzZValue789()

    squareToSzzZValue790()

    squareToSzzZValue791()

    squareToSzzZValue792()

    squareToSzzZValue793()

    squareToSzzZValue794()

    squareToSzzZValue795()

    squareToSzzZValue796()

    squareToSzzZValue797()

    squareToSzzZValue798()

    squareToSzzZValue799()

    squareToSzzZValue800()

    squareToSzzZValue801()

    squareToSzzZValue802()

    squareToSzzZValue803()

    squareToSzzZValue804()

    squareToSzzZValue805()

    squareToSzzZValue806()

    squareToSzzZValue807()

    squareToSzzZValue808()

    squareToSzzZValue809()

    squareToSzzZValue810()

    squareToSzzZValue811()

    squareToSzzZValue812()

    squareToSzzZValue813()

    squareToSzzZValue814()

    squareToSzzZValue815()

    squareToSzzZValue816()

    squareToSzzZValue817()

    squareToSzzZValue818()

    squareToSzzZValue819()

    squareToSzzZValue820()

    squareToSzzZValue821()

    squareToSzzZValue822()

    squareToSzzZValue823()

    squareToSzzZValue824()

    squareToSzzZValue825()

    squareToSzzZValue826()

    squareToSzzZValue827()

    squareToSzzZValue828()

    squareToSzzZValue829()

    squareToSzzZValue830()

    squareToSzzZValue831()

    squareToSzzZValue832()

    squareToSzzZValue833()

    squareToSzzZValue834()

    squareToSzzZValue835()

    squareToSzzZValue836()

    squareToSzzZValue837()

    squareToSzzZValue838()

    squareToSzzZValue839()

    squareToSzzZValue840()

    squareToSzzZValue841()

    squareToSzzZValue842()

    squareToSzzZValue843()

    squareToSzzZValue844()

    squareToSzzZValue845()

    squareToSzzZValue846()

    squareToSzzZValue847()

    squareToSzzZValue848()

    squareToSzzZValue849()

    squareToSzzZValue850()

    squareToSzzZValue851()

    squareToSzzZValue852()

    squareToSzzZValue853()

    squareToSzzZValue854()

    squareToSzzZValue855()

    squareToSzzZValue856()

    squareToSzzZValue857()

    squareToSzzZValue858()

    squareToSzzZValue859()

    squareToSzzZValue860()

    squareToSzzZValue861()

    squareToSzzZValue862()

    squareToSzzZValue863()

    squareToSzzZValue864()

    squareToSzzZValue865()

    squareToSzzZValue866()

    squareToSzzZValue867()

    squareToSzzZValue868()

    squareToSzzZValue869()

    squareToSzzZValue870()

    squareToSzzZValue871()

    squareToSzzZValue872()

    squareToSzzZValue873()

    squareToSzzZValue874()

    squareToSzzZValue875()

    squareToSzzZValue876()

    squareToSzzZValue877()

    squareToSzzZValue878()

    squareToSzzZValue879()

    squareToSzzZValue880()

    squareToSzzZValue881()

    squareToSzzZValue882()

    squareToSzzZValue883()

    squareToSzzZValue884()

    squareToSzzZValue885()

    squareToSzzZValue886()

    squareToSzzZValue887()

    squareToSzzZValue888()

    squareToSzzZValue889()

    squareToSzzZValue890()

    squareToSzzZValue891()

    squareToSzzZValue892()

    squareToSzzZValue893()

    squareToSzzZValue894()

    squareToSzzZValue895()

    squareToSzzZValue896()

    squareToSzzZValue897()

    squareToSzzZValue898()

    squareToSzzZValue899()

    squareToSzzZValue900()

    squareToSzzZValue901()

    squareToSzzZValue902()

    squareToSzzZValue903()

    squareToSzzZValue904()

    squareToSzzZValue905()

    squareToSzzZValue906()

    squareToSzzZValue907()

    squareToSzzZValue908()

    squareToSzzZValue909()

    squareToSzzZValue910()

    squareToSzzZValue911()

    squareToSzzZValue912()

    squareToSzzZValue913()

    squareToSzzZValue914()

    squareToSzzZValue915()

    squareToSzzZValue916()

    squareToSzzZValue917()

    squareToSzzZValue918()

    squareToSzzZValue919()

    squareToSzzZValue920()

    squareToSzzZValue921()

    squareToSzzZValue922()

    squareToSzzZValue923()

    squareToSzzZValue924()

    squareToSzzZValue925()

    squareToSzzZValue926()

    squareToSzzZValue927()

    squareToSzzZValue928()

    squareToSzzZValue929()

    squareToSzzZValue930()

    squareToSzzZValue931()

    squareToSzzZValue932()

    squareToSzzZValue933()

    squareToSzzZValue934()

    squareToSzzZValue935()

    squareToSzzZValue936()

    squareToSzzZValue937()

    squareToSzzZValue938()

    squareToSzzZValue939()

    squareToSzzZValue940()

    squareToSzzZValue941()

    squareToSzzZValue942()

    squareToSzzZValue943()

    squareToSzzZValue944()

    squareToSzzZValue945()

    squareToSzzZValue946()

    squareToSzzZValue947()

    squareToSzzZValue948()

    squareToSzzZValue949()

    squareToSzzZValue950()

    squareToSzzZValue951()

    squareToSzzZValue952()

    squareToSzzZValue953()

    squareToSzzZValue954()

    squareToSzzZValue955()

    squareToSzzZValue956()

    squareToSzzZValue957()

    squareToSzzZValue958()

    squareToSzzZValue959()

    squareToSzzZValue960()

    squareToSzzZValue961()

    squareToSzzZValue962()

    squareToSzzZValue963()

    squareToSzzZValue964()

    squareToSzzZValue965()

    squareToSzzZValue966()

    squareToSzzZValue967()

    squareToSzzZValue968()

    squareToSzzZValue969()

    squareToSzzZValue970()

    squareToSzzZValue971()

    squareToSzzZValue972()

    squareToSzzZValue973()

    squareToSzzZValue974()

    squareToSzzZValue975()

    squareToSzzZValue976()

    squareToSzzZValue977()

    squareToSzzZValue978()

    squareToSzzZValue979()

    squareToSzzZValue980()

    squareToSzzZValue981()

    squareToSzzZValue982()

    squareToSzzZValue983()

    squareToSzzZValue984()

    squareToSzzZValue985()

    squareToSzzZValue986()

    squareToSzzZValue987()

    squareToSzzZValue988()

    squareToSzzZValue989()

    squareToSzzZValue990()

    squareToSzzZValue991()

    squareToSzzZValue992()

    squareToSzzZValue993()

    squareToSzzZValue994()

    squareToSzzZValue995()

    squareToSzzZValue996()

    squareToSzzZValue997()

    squareToSzzZValue998()

    squareToSzzZValue999()

    squareToSzzZValue1000()

    squareToSzzZValue1001()

    squareToSzzZValue1002()

    squareToSzzZValue1003()

    squareToSzzZValue1004()

    squareToSzzZValue1005()

    squareToSzzZValue1006()

    squareToSzzZValue1007()

    squareToSzzZValue1008()

    squareToSzzZValue1009()

    squareToSzzZValue1010()

    squareToSzzZValue1011()

    squareToSzzZValue1012()

    squareToSzzZValue1013()

    squareToSzzZValue1014()

    squareToSzzZValue1015()

    squareToSzzZValue1016()

    squareToSzzZValue1017()

    squareToSzzZValue1018()

    squareToSzzZValue1019()

    squareToSzzZValue1020()

    squareToSzzZValue1021()

    squareToSzzZValue1022()

    squareToSzzZValue1023()

    squareToSzzZValue1024()

    squareToSzzZValue1025()

    squareToSzzZValue1026()

    squareToSzzZValue1027()

    squareToSzzZValue1028()

    squareToSzzZValue1029()

    squareToSzzZValue1030()

    squareToSzzZValue1031()

    squareToSzzZValue1032()

    squareToSzzZValue1033()

    squareToSzzZValue1034()

    squareToSzzZValue1035()

    squareToSzzZValue1036()

    squareToSzzZValue1037()

    squareToSzzZValue1038()

    squareToSzzZValue1039()

    squareToSzzZValue1040()

    squareToSzzZValue1041()

    squareToSzzZValue1042()

    squareToSzzZValue1043()

    squareToSzzZValue1044()

    squareToSzzZValue1045()

    squareToSzzZValue1046()

    squareToSzzZValue1047()

    squareToSzzZValue1048()

    squareToSzzZValue1049()

    squareToSzzZValue1050()

    squareToSzzZValue1051()

    squareToSzzZValue1052()

    squareToSzzZValue1053()

    squareToSzzZValue1054()

    squareToSzzZValue1055()

    squareToSzzZValue1056()

    squareToSzzZValue1057()

    squareToSzzZValue1058()

    squareToSzzZValue1059()

    squareToSzzZValue1060()

    squareToSzzZValue1061()

    squareToSzzZValue1062()

    squareToSzzZValue1063()

    squareToSzzZValue1064()

    squareToSzzZValue1065()

    squareToSzzZValue1066()

    squareToSzzZValue1067()

    squareToSzzZValue1068()

    squareToSzzZValue1069()

    squareToSzzZValue1070()

    squareToSzzZValue1071()

    squareToSzzZValue1072()

    squareToSzzZValue1073()

    squareToSzzZValue1074()

    squareToSzzZValue1075()

    squareToSzzZValue1076()

    squareToSzzZValue1077()

    squareToSzzZValue1078()

    squareToSzzZValue1079()

    squareToSzzZValue1080()

    squareToSzzZValue1081()

    squareToSzzZValue1082()

    squareToSzzZValue1083()

    squareToSzzZValue1084()

    squareToSzzZValue1085()

    squareToSzzZValue1086()

    squareToSzzZValue1087()

    squareToSzzZValue1088()

    squareToSzzZValue1089()

    squareToSzzZValue1090()

    squareToSzzZValue1091()

    squareToSzzZValue1092()

    squareToSzzZValue1093()

    squareToSzzZValue1094()

    squareToSzzZValue1095()

    squareToSzzZValue1096()

    squareToSzzZValue1097()

    squareToSzzZValue1098()

    squareToSzzZValue1099()

    squareToSzzZValue1100()

    squareToSzzZValue1101()

    squareToSzzZValue1102()

    squareToSzzZValue1103()

    squareToSzzZValue1104()

    squareToSzzZValue1105()

    squareToSzzZValue1106()

    squareToSzzZValue1107()

    squareToSzzZValue1108()

    squareToSzzZValue1109()

    squareToSzzZValue1110()

    squareToSzzZValue1111()

    squareToSzzZValue1112()

    squareToSzzZValue1113()

    squareToSzzZValue1114()

    squareToSzzZValue1115()

    squareToSzzZValue1116()

    squareToSzzZValue1117()

    squareToSzzZValue1118()

    squareToSzzZValue1119()

    squareToSzzZValue1120()

    squareToSzzZValue1121()

    squareToSzzZValue1122()

    squareToSzzZValue1123()

    squareToSzzZValue1124()

    squareToSzzZValue1125()

    squareToSzzZValue1126()

    squareToSzzZValue1127()

    squareToSzzZValue1128()

    squareToSzzZValue1129()

    squareToSzzZValue1130()

    squareToSzzZValue1131()

    squareToSzzZValue1132()

    squareToSzzZValue1133()

    squareToSzzZValue1134()

    squareToSzzZValue1135()

    squareToSzzZValue1136()

    squareToSzzZValue1137()

    squareToSzzZValue1138()

    squareToSzzZValue1139()

    squareToSzzZValue1140()

    squareToSzzZValue1141()

    squareToSzzZValue1142()

    squareToSzzZValue1143()

    squareToSzzZValue1144()

    squareToSzzZValue1145()

    squareToSzzZValue1146()

    squareToSzzZValue1147()

    squareToSzzZValue1148()

    squareToSzzZValue1149()

    squareToSzzZValue1150()

    squareToSzzZValue1151()

    squareToSzzZValue1152()

    squareToSzzZValue1153()

    squareToSzzZValue1154()

    squareToSzzZValue1155()

    squareToSzzZValue1156()

    squareToSzzZValue1157()

    squareToSzzZValue1158()

    squareToSzzZValue1159()

    squareToSzzZValue1160()

    squareToSzzZValue1161()

    squareToSzzZValue1162()

    squareToSzzZValue1163()

    squareToSzzZValue1164()

    squareToSzzZValue1165()

    squareToSzzZValue1166()

    squareToSzzZValue1167()

    squareToSzzZValue1168()

    squareToSzzZValue1169()

    squareToSzzZValue1170()

    squareToSzzZValue1171()

    squareToSzzZValue1172()

    squareToSzzZValue1173()

    squareToSzzZValue1174()

    squareToSzzZValue1175()

    squareToSzzZValue1176()

    squareToSzzZValue1177()

    squareToSzzZValue1178()

    squareToSzzZValue1179()

    squareToSzzZValue1180()

    squareToSzzZValue1181()

    squareToSzzZValue1182()

    squareToSzzZValue1183()

    squareToSzzZValue1184()

    squareToSzzZValue1185()

    squareToSzzZValue1186()

    squareToSzzZValue1187()

    squareToSzzZValue1188()

    squareToSzzZValue1189()

    squareToSzzZValue1190()

    squareToSzzZValue1191()

    squareToSzzZValue1192()

    squareToSzzZValue1193()

    squareToSzzZValue1194()

    squareToSzzZValue1195()

    squareToSzzZValue1196()

    squareToSzzZValue1197()

    squareToSzzZValue1198()

    squareToSzzZValue1199()

    squareToSzzZValue1200()

    squareToSzzZValue1201()

    squareToSzzZValue1202()

    squareToSzzZValue1203()

    squareToSzzZValue1204()

    squareToSzzZValue1205()

    squareToSzzZValue1206()

    squareToSzzZValue1207()

    squareToSzzZValue1208()

    squareToSzzZValue1209()

    squareToSzzZValue1210()

    squareToSzzZValue1211()

    squareToSzzZValue1212()

    squareToSzzZValue1213()

    squareToSzzZValue1214()

    squareToSzzZValue1215()

    squareToSzzZValue1216()

    squareToSzzZValue1217()

    squareToSzzZValue1218()

    squareToSzzZValue1219()

    squareToSzzZValue1220()

    squareToSzzZValue1221()

    squareToSzzZValue1222()

    squareToSzzZValue1223()

    squareToSzzZValue1224()

    squareToSzzZValue1225()

    squareToSzzZValue1226()

    squareToSzzZValue1227()

    squareToSzzZValue1228()

    squareToSzzZValue1229()

    squareToSzzZValue1230()

    squareToSzzZValue1231()

    squareToSzzZValue1232()

    squareToSzzZValue1233()

    squareToSzzZValue1234()

    squareToSzzZValue1235()

    squareToSzzZValue1236()

    squareToSzzZValue1237()

    squareToSzzZValue1238()

    squareToSzzZValue1239()

    squareToSzzZValue1240()

    squareToSzzZValue1241()

    squareToSzzZValue1242()

    squareToSzzZValue1243()

    squareToSzzZValue1244()

    squareToSzzZValue1245()

    squareToSzzZValue1246()

    squareToSzzZValue1247()

    squareToSzzZValue1248()

    squareToSzzZValue1249()

    squareToSzzZValue1250()

    squareToSzzZValue1251()

    squareToSzzZValue1252()

    squareToSzzZValue1253()

    squareToSzzZValue1254()

    squareToSzzZValue1255()

    squareToSzzZValue1256()

    squareToSzzZValue1257()

    squareToSzzZValue1258()

    squareToSzzZValue1259()

    squareToSzzZValue1260()

    squareToSzzZValue1261()

    squareToSzzZValue1262()

    squareToSzzZValue1263()

    squareToSzzZValue1264()

    squareToSzzZValue1265()

    squareToSzzZValue1266()

    squareToSzzZValue1267()

    squareToSzzZValue1268()

    squareToSzzZValue1269()

    squareToSzzZValue1270()

    squareToSzzZValue1271()

    squareToSzzZValue1272()

    squareToSzzZValue1273()

    squareToSzzZValue1274()

    squareToSzzZValue1275()

    squareToSzzZValue1276()

    squareToSzzZValue1277()

    squareToSzzZValue1278()

    squareToSzzZValue1279()

    squareToSzzZValue1280()

    squareToSzzZValue1281()

    squareToSzzZValue1282()

    squareToSzzZValue1283()

    squareToSzzZValue1284()

    squareToSzzZValue1285()

    squareToSzzZValue1286()

    squareToSzzZValue1287()

    squareToSzzZValue1288()

    squareToSzzZValue1289()

    squareToSzzZValue1290()

    squareToSzzZValue1291()

    squareToSzzZValue1292()

    squareToSzzZValue1293()

    squareToSzzZValue1294()

    squareToSzzZValue1295()

    squareToSzzZValue1296()

    squareToSzzZValue1297()

    squareToSzzZValue1298()

    squareToSzzZValue1299()

    squareToSzzZValue1300()

    squareToSzzZValue1301()

    squareToSzzZValue1302()

    squareToSzzZValue1303()

    squareToSzzZValue1304()

    squareToSzzZValue1305()

    squareToSzzZValue1306()

    squareToSzzZValue1307()

    squareToSzzZValue1308()

    squareToSzzZValue1309()

    squareToSzzZValue1310()

    squareToSzzZValue1311()

    squareToSzzZValue1312()

    squareToSzzZValue1313()

    squareToSzzZValue1314()

    squareToSzzZValue1315()

    squareToSzzZValue1316()

    squareToSzzZValue1317()

    squareToSzzZValue1318()

    squareToSzzZValue1319()

    squareToSzzZValue1320()

    squareToSzzZValue1321()

    squareToSzzZValue1322()

    squareToSzzZValue1323()

    squareToSzzZValue1324()

    squareToSzzZValue1325()

    squareToSzzZValue1326()

    squareToSzzZValue1327()

    squareToSzzZValue1328()

    squareToSzzZValue1329()

    squareToSzzZValue1330()

    squareToSzzZValue1331()

    squareToSzzZValue1332()

    squareToSzzZValue1333()

    squareToSzzZValue1334()

    squareToSzzZValue1335()

    squareToSzzZValue1336()

    squareToSzzZValue1337()

    squareToSzzZValue1338()

    squareToSzzZValue1339()

    squareToSzzZValue1340()

    squareToSzzZValue1341()

    squareToSzzZValue1342()

    squareToSzzZValue1343()

    squareToSzzZValue1344()

    squareToSzzZValue1345()

    squareToSzzZValue1346()

    squareToSzzZValue1347()

    squareToSzzZValue1348()

    squareToSzzZValue1349()

    squareToSzzZValue1350()

    squareToSzzZValue1351()

    squareToSzzZValue1352()

    squareToSzzZValue1353()

    squareToSzzZValue1354()

    squareToSzzZValue1355()

    squareToSzzZValue1356()

    squareToSzzZValue1357()

    squareToSzzZValue1358()

    squareToSzzZValue1359()

    squareToSzzZValue1360()

    squareToSzzZValue1361()

    squareToSzzZValue1362()

    squareToSzzZValue1363()

    squareToSzzZValue1364()

    squareToSzzZValue1365()

    squareToSzzZValue1366()

    squareToSzzZValue1367()

    squareToSzzZValue1368()

    squareToSzzZValue1369()

    squareToSzzZValue1370()

    squareToSzzZValue1371()

    squareToSzzZValue1372()

    squareToSzzZValue1373()

    squareToSzzZValue1374()

    squareToSzzZValue1375()

    squareToSzzZValue1376()

    squareToSzzZValue1377()

    squareToSzzZValue1378()

    squareToSzzZValue1379()

    squareToSzzZValue1380()

    squareToSzzZValue1381()

    squareToSzzZValue1382()

    squareToSzzZValue1383()

    squareToSzzZValue1384()

    squareToSzzZValue1385()

    squareToSzzZValue1386()

    squareToSzzZValue1387()

    squareToSzzZValue1388()

    squareToSzzZValue1389()

    squareToSzzZValue1390()

    squareToSzzZValue1391()

    squareToSzzZValue1392()

    squareToSzzZValue1393()

    squareToSzzZValue1394()

    squareToSzzZValue1395()

    squareToSzzZValue1396()

    squareToSzzZValue1397()

    squareToSzzZValue1398()

    squareToSzzZValue1399()

    squareToSzzZValue1400()

    squareToSzzZValue1401()

    squareToSzzZValue1402()

    squareToSzzZValue1403()

    squareToSzzZValue1404()

    squareToSzzZValue1405()

    squareToSzzZValue1406()

    squareToSzzZValue1407()

    squareToSzzZValue1408()

    squareToSzzZValue1409()

    squareToSzzZValue1410()

    squareToSzzZValue1411()

    squareToSzzZValue1412()

    squareToSzzZValue1413()

    squareToSzzZValue1414()

    squareToSzzZValue1415()

    squareToSzzZValue1416()

    squareToSzzZValue1417()

    squareToSzzZValue1418()

    squareToSzzZValue1419()

    squareToSzzZValue1420()

    squareToSzzZValue1421()

    squareToSzzZValue1422()

    squareToSzzZValue1423()

    squareToSzzZValue1424()

    squareToSzzZValue1425()

    squareToSzzZValue1426()

    squareToSzzZValue1427()

    squareToSzzZValue1428()

    squareToSzzZValue1429()

    squareToSzzZValue1430()

    squareToSzzZValue1431()

    squareToSzzZValue1432()

    squareToSzzZValue1433()

    squareToSzzZValue1434()

    squareToSzzZValue1435()

    squareToSzzZValue1436()

    squareToSzzZValue1437()

    squareToSzzZValue1438()

    squareToSzzZValue1439()

    squareToSzzZValue1440()

    squareToSzzZValue1441()

    squareToSzzZValue1442()

    squareToSzzZValue1443()

    squareToSzzZValue1444()

    squareToSzzZValue1445()

    squareToSzzZValue1446()

    squareToSzzZValue1447()

    squareToSzzZValue1448()

    squareToSzzZValue1449()

    squareToSzzZValue1450()

    squareToSzzZValue1451()

    squareToSzzZValue1452()

    squareToSzzZValue1453()

    squareToSzzZValue1454()

    squareToSzzZValue1455()

    squareToSzzZValue1456()

    squareToSzzZValue1457()

    squareToSzzZValue1458()

    squareToSzzZValue1459()

    squareToSzzZValue1460()

    squareToSzzZValue1461()

    squareToSzzZValue1462()

    squareToSzzZValue1463()

    squareToSzzZValue1464()

    squareToSzzZValue1465()

    squareToSzzZValue1466()

    squareToSzzZValue1467()

    squareToSzzZValue1468()

    squareToSzzZValue1469()

    squareToSzzZValue1470()

    squareToSzzZValue1471()

    squareToSzzZValue1472()

    squareToSzzZValue1473()

    squareToSzzZValue1474()

    squareToSzzZValue1475()

    squareToSzzZValue1476()

    squareToSzzZValue1477()

    squareToSzzZValue1478()

    squareToSzzZValue1479()

    squareToSzzZValue1480()

    squareToSzzZValue1481()

    squareToSzzZValue1482()

    squareToSzzZValue1483()

    squareToSzzZValue1484()

    squareToSzzZValue1485()

    squareToSzzZValue1486()

    squareToSzzZValue1487()

    squareToSzzZValue1488()

    squareToSzzZValue1489()

    squareToSzzZValue1490()

    squareToSzzZValue1491()

    squareToSzzZValue1492()

    squareToSzzZValue1493()

    squareToSzzZValue1494()

    squareToSzzZValue1495()

    squareToSzzZValue1496()

    squareToSzzZValue1497()

    squareToSzzZValue1498()

    squareToSzzZValue1499()

    squareToSzzZValue1500()

    squareToSzzZValue1501()

    squareToSzzZValue1502()

    squareToSzzZValue1503()

    squareToSzzZValue1504()

    squareToSzzZValue1505()

    squareToSzzZValue1506()

    squareToSzzZValue1507()

    squareToSzzZValue1508()

    squareToSzzZValue1509()

    squareToSzzZValue1510()

    squareToSzzZValue1511()

    squareToSzzZValue1512()

    squareToSzzZValue1513()

    squareToSzzZValue1514()

    squareToSzzZValue1515()

    squareToSzzZValue1516()

    squareToSzzZValue1517()

    squareToSzzZValue1518()

    squareToSzzZValue1519()

    squareToSzzZValue1520()

    squareToSzzZValue1521()

    squareToSzzZValue1522()

    squareToSzzZValue1523()

    squareToSzzZValue1524()

    squareToSzzZValue1525()

    squareToSzzZValue1526()

    squareToSzzZValue1527()

    squareToSzzZValue1528()

    squareToSzzZValue1529()

    squareToSzzZValue1530()

    squareToSzzZValue1531()

    squareToSzzZValue1532()

    squareToSzzZValue1533()

    squareToSzzZValue1534()

    squareToSzzZValue1535()

    squareToSzzZValue1536()

    squareToSzzZValue1537()

    squareToSzzZValue1538()

    squareToSzzZValue1539()

    squareToSzzZValue1540()

    squareToSzzZValue1541()

    squareToSzzZValue1542()

    squareToSzzZValue1543()

    squareToSzzZValue1544()

    squareToSzzZValue1545()

    squareToSzzZValue1546()

    squareToSzzZValue1547()

    squareToSzzZValue1548()

    squareToSzzZValue1549()

    squareToSzzZValue1550()

    squareToSzzZValue1551()

    squareToSzzZValue1552()

    squareToSzzZValue1553()

    squareToSzzZValue1554()

    squareToSzzZValue1555()

    squareToSzzZValue1556()

    squareToSzzZValue1557()

    squareToSzzZValue1558()

    squareToSzzZValue1559()

    squareToSzzZValue1560()

    squareToSzzZValue1561()

    squareToSzzZValue1562()

    squareToSzzZValue1563()

    squareToSzzZValue1564()

    squareToSzzZValue1565()

    squareToSzzZValue1566()

    squareToSzzZValue1567()

    squareToSzzZValue1568()

    squareToSzzZValue1569()

    squareToSzzZValue1570()

    squareToSzzZValue1571()

    squareToSzzZValue1572()

    squareToSzzZValue1573()

    squareToSzzZValue1574()

    squareToSzzZValue1575()

    squareToSzzZValue1576()

    squareToSzzZValue1577()

    squareToSzzZValue1578()

    squareToSzzZValue1579()

    squareToSzzZValue1580()

    squareToSzzZValue1581()

    squareToSzzZValue1582()

    squareToSzzZValue1583()

    squareToSzzZValue1584()

    squareToSzzZValue1585()

    squareToSzzZValue1586()

    squareToSzzZValue1587()

    squareToSzzZValue1588()

    squareToSzzZValue1589()

    squareToSzzZValue1590()

    squareToSzzZValue1591()

    squareToSzzZValue1592()

    squareToSzzZValue1593()

    squareToSzzZValue1594()

    squareToSzzZValue1595()

    squareToSzzZValue1596()

    squareToSzzZValue1597()

    squareToSzzZValue1598()

    squareToSzzZValue1599()

    squareToSzzZValue1600()

    squareToSzzZValue1601()

    squareToSzzZValue1602()

    squareToSzzZValue1603()

    squareToSzzZValue1604()

    squareToSzzZValue1605()

    squareToSzzZValue1606()

    squareToSzzZValue1607()

    squareToSzzZValue1608()

    squareToSzzZValue1609()

    squareToSzzZValue1610()

    squareToSzzZValue1611()

    squareToSzzZValue1612()

    squareToSzzZValue1613()

    squareToSzzZValue1614()

    squareToSzzZValue1615()

    squareToSzzZValue1616()

    squareToSzzZValue1617()

    squareToSzzZValue1618()

    squareToSzzZValue1619()

    squareToSzzZValue1620()

    squareToSzzZValue1621()

    squareToSzzZValue1622()

    squareToSzzZValue1623()

    squareToSzzZValue1624()

    squareToSzzZValue1625()

    squareToSzzZValue1626()

    squareToSzzZValue1627()

    squareToSzzZValue1628()

    squareToSzzZValue1629()

    squareToSzzZValue1630()

    squareToSzzZValue1631()

    squareToSzzZValue1632()

    squareToSzzZValue1633()

    squareToSzzZValue1634()

    squareToSzzZValue1635()

    squareToSzzZValue1636()

    squareToSzzZValue1637()

    squareToSzzZValue1638()

    squareToSzzZValue1639()

    squareToSzzZValue1640()

    squareToSzzZValue1641()

    squareToSzzZValue1642()

    squareToSzzZValue1643()

    squareToSzzZValue1644()

    squareToSzzZValue1645()

    squareToSzzZValue1646()

    squareToSzzZValue1647()

    squareToSzzZValue1648()

    squareToSzzZValue1649()

    squareToSzzZValue1650()

    squareToSzzZValue1651()

    squareToSzzZValue1652()

    squareToSzzZValue1653()

    squareToSzzZValue1654()

    squareToSzzZValue1655()

    squareToSzzZValue1656()

    squareToSzzZValue1657()

    squareToSzzZValue1658()

    squareToSzzZValue1659()

    squareToSzzZValue1660()

    squareToSzzZValue1661()

    squareToSzzZValue1662()

    squareToSzzZValue1663()

    squareToSzzZValue1664()

    squareToSzzZValue1665()

    squareToSzzZValue1666()

    squareToSzzZValue1667()

    squareToSzzZValue1668()

    squareToSzzZValue1669()

    squareToSzzZValue1670()

    squareToSzzZValue1671()

    squareToSzzZValue1672()

    squareToSzzZValue1673()

    squareToSzzZValue1674()

    squareToSzzZValue1675()

    squareToSzzZValue1676()

    squareToSzzZValue1677()

    squareToSzzZValue1678()

    squareToSzzZValue1679()

    squareToSzzZValue1680()

    squareToSzzZValue1681()

    squareToSzzZValue1682()

    squareToSzzZValue1683()

    squareToSzzZValue1684()

    squareToSzzZValue1685()

    squareToSzzZValue1686()

    squareToSzzZValue1687()

    squareToSzzZValue1688()

    squareToSzzZValue1689()

    squareToSzzZValue1690()

    squareToSzzZValue1691()

    squareToSzzZValue1692()

    squareToSzzZValue1693()

    squareToSzzZValue1694()

    squareToSzzZValue1695()

    squareToSzzZValue1696()

    squareToSzzZValue1697()

    squareToSzzZValue1698()

    squareToSzzZValue1699()

    squareToSzzZValue1700()

    squareToSzzZValue1701()

    squareToSzzZValue1702()

    squareToSzzZValue1703()

    squareToSzzZValue1704()

    squareToSzzZValue1705()

    squareToSzzZValue1706()

    squareToSzzZValue1707()

    squareToSzzZValue1708()

    squareToSzzZValue1709()

    squareToSzzZValue1710()

    squareToSzzZValue1711()

    squareToSzzZValue1712()

    squareToSzzZValue1713()

    squareToSzzZValue1714()

    squareToSzzZValue1715()

    squareToSzzZValue1716()

    squareToSzzZValue1717()

    squareToSzzZValue1718()

    squareToSzzZValue1719()

    squareToSzzZValue1720()

    squareToSzzZValue1721()

    squareToSzzZValue1722()

    squareToSzzZValue1723()

    squareToSzzZValue1724()

    squareToSzzZValue1725()

    squareToSzzZValue1726()

    squareToSzzZValue1727()

    squareToSzzZValue1728()

    squareToSzzZValue1729()

    squareToSzzZValue1730()

    squareToSzzZValue1731()

    squareToSzzZValue1732()

    squareToSzzZValue1733()

    squareToSzzZValue1734()

    squareToSzzZValue1735()

    squareToSzzZValue1736()

    squareToSzzZValue1737()

    squareToSzzZValue1738()

    squareToSzzZValue1739()

    squareToSzzZValue1740()

    squareToSzzZValue1741()

    squareToSzzZValue1742()

    squareToSzzZValue1743()

    squareToSzzZValue1744()

    squareToSzzZValue1745()

    squareToSzzZValue1746()

    squareToSzzZValue1747()

    squareToSzzZValue1748()

    squareToSzzZValue1749()

    squareToSzzZValue1750()

    squareToSzzZValue1751()

    squareToSzzZValue1752()

    squareToSzzZValue1753()

    squareToSzzZValue1754()

    squareToSzzZValue1755()

    squareToSzzZValue1756()

    squareToSzzZValue1757()

    squareToSzzZValue1758()

    squareToSzzZValue1759()

    squareToSzzZValue1760()

    squareToSzzZValue1761()

    squareToSzzZValue1762()

    squareToSzzZValue1763()

    squareToSzzZValue1764()

    squareToSzzZValue1765()

    squareToSzzZValue1766()

    squareToSzzZValue1767()

    squareToSzzZValue1768()

    squareToSzzZValue1769()

    squareToSzzZValue1770()

    squareToSzzZValue1771()

    squareToSzzZValue1772()

    squareToSzzZValue1773()

    squareToSzzZValue1774()

    squareToSzzZValue1775()

    squareToSzzZValue1776()

    squareToSzzZValue1777()

    squareToSzzZValue1778()

    squareToSzzZValue1779()

    squareToSzzZValue1780()

    squareToSzzZValue1781()

    squareToSzzZValue1782()

    squareToSzzZValue1783()

    squareToSzzZValue1784()

    squareToSzzZValue1785()

    squareToSzzZValue1786()

    squareToSzzZValue1787()

    squareToSzzZValue1788()

    squareToSzzZValue1789()

    squareToSzzZValue1790()

    squareToSzzZValue1791()

    squareToSzzZValue1792()

    squareToSzzZValue1793()

    squareToSzzZValue1794()

    squareToSzzZValue1795()

    squareToSzzZValue1796()

    squareToSzzZValue1797()

    squareToSzzZValue1798()

    squareToSzzZValue1799()

    squareToSzzZValue1800()

    squareToSzzZValue1801()

    squareToSzzZValue1802()

    squareToSzzZValue1803()

    squareToSzzZValue1804()

    squareToSzzZValue1805()

    squareToSzzZValue1806()

    squareToSzzZValue1807()

    squareToSzzZValue1808()

    squareToSzzZValue1809()

    squareToSzzZValue1810()

    squareToSzzZValue1811()

    squareToSzzZValue1812()

    squareToSzzZValue1813()

    squareToSzzZValue1814()

    squareToSzzZValue1815()

    squareToSzzZValue1816()

    squareToSzzZValue1817()

    squareToSzzZValue1818()

    squareToSzzZValue1819()

    squareToSzzZValue1820()

    squareToSzzZValue1821()

    squareToSzzZValue1822()

    squareToSzzZValue1823()

    squareToSzzZValue1824()

    squareToSzzZValue1825()

    squareToSzzZValue1826()

    squareToSzzZValue1827()

    squareToSzzZValue1828()

    squareToSzzZValue1829()

    squareToSzzZValue1830()

    squareToSzzZValue1831()

    squareToSzzZValue1832()

    squareToSzzZValue1833()

    squareToSzzZValue1834()

    squareToSzzZValue1835()

    squareToSzzZValue1836()

    squareToSzzZValue1837()

    squareToSzzZValue1838()

    squareToSzzZValue1839()

    squareToSzzZValue1840()

    squareToSzzZValue1841()

    squareToSzzZValue1842()

    squareToSzzZValue1843()

    squareToSzzZValue1844()

    squareToSzzZValue1845()

    squareToSzzZValue1846()

    squareToSzzZValue1847()

    squareToSzzZValue1848()

    squareToSzzZValue1849()

    squareToSzzZValue1850()

    squareToSzzZValue1851()

    squareToSzzZValue1852()

    squareToSzzZValue1853()

    squareToSzzZValue1854()

    squareToSzzZValue1855()

    squareToSzzZValue1856()

    squareToSzzZValue1857()

    squareToSzzZValue1858()

    squareToSzzZValue1859()

    squareToSzzZValue1860()

    squareToSzzZValue1861()

    squareToSzzZValue1862()

    squareToSzzZValue1863()

    squareToSzzZValue1864()

    squareToSzzZValue1865()

    squareToSzzZValue1866()

    squareToSzzZValue1867()

    squareToSzzZValue1868()

    squareToSzzZValue1869()

    squareToSzzZValue1870()

    squareToSzzZValue1871()

    squareToSzzZValue1872()

    squareToSzzZValue1873()

    squareToSzzZValue1874()

    squareToSzzZValue1875()

    squareToSzzZValue1876()

    squareToSzzZValue1877()

    squareToSzzZValue1878()

    squareToSzzZValue1879()

    squareToSzzZValue1880()

    squareToSzzZValue1881()

    squareToSzzZValue1882()

    squareToSzzZValue1883()

    squareToSzzZValue1884()

    squareToSzzZValue1885()

    squareToSzzZValue1886()

    squareToSzzZValue1887()

    squareToSzzZValue1888()

    squareToSzzZValue1889()

    squareToSzzZValue1890()

    squareToSzzZValue1891()

    squareToSzzZValue1892()

    squareToSzzZValue1893()

    squareToSzzZValue1894()

    squareToSzzZValue1895()

    squareToSzzZValue1896()

    squareToSzzZValue1897()

    squareToSzzZValue1898()

    squareToSzzZValue1899()

    squareToSzzZValue1900()

    squareToSzzZValue1901()

    squareToSzzZValue1902()

    squareToSzzZValue1903()

    squareToSzzZValue1904()

    squareToSzzZValue1905()

    squareToSzzZValue1906()

    squareToSzzZValue1907()

    squareToSzzZValue1908()

    squareToSzzZValue1909()

    squareToSzzZValue1910()

    squareToSzzZValue1911()

    squareToSzzZValue1912()

    squareToSzzZValue1913()

    squareToSzzZValue1914()

    squareToSzzZValue1915()

    squareToSzzZValue1916()

    squareToSzzZValue1917()

    squareToSzzZValue1918()

    squareToSzzZValue1919()

    squareToSzzZValue1920()

    squareToSzzZValue1921()

    squareToSzzZValue1922()

    squareToSzzZValue1923()

    squareToSzzZValue1924()

    squareToSzzZValue1925()

    squareToSzzZValue1926()

    squareToSzzZValue1927()

    squareToSzzZValue1928()

    squareToSzzZValue1929()

    squareToSzzZValue1930()

    squareToSzzZValue1931()

    squareToSzzZValue1932()

    squareToSzzZValue1933()

    squareToSzzZValue1934()

    squareToSzzZValue1935()

    squareToSzzZValue1936()

    squareToSzzZValue1937()

    squareToSzzZValue1938()

    squareToSzzZValue1939()

    squareToSzzZValue1940()

    squareToSzzZValue1941()

    squareToSzzZValue1942()

    squareToSzzZValue1943()

    squareToSzzZValue1944()

    squareToSzzZValue1945()

    squareToSzzZValue1946()

    squareToSzzZValue1947()

    squareToSzzZValue1948()

    squareToSzzZValue1949()

    squareToSzzZValue1950()

    squareToSzzZValue1951()

    squareToSzzZValue1952()

    squareToSzzZValue1953()

    squareToSzzZValue1954()

    squareToSzzZValue1955()

    squareToSzzZValue1956()

    squareToSzzZValue1957()

    squareToSzzZValue1958()

    squareToSzzZValue1959()

    squareToSzzZValue1960()

    squareToSzzZValue1961()

    squareToSzzZValue1962()

    squareToSzzZValue1963()

    squareToSzzZValue1964()

    squareToSzzZValue1965()

    squareToSzzZValue1966()

    squareToSzzZValue1967()

    squareToSzzZValue1968()

    squareToSzzZValue1969()

    squareToSzzZValue1970()

    squareToSzzZValue1971()

    squareToSzzZValue1972()

    squareToSzzZValue1973()

    squareToSzzZValue1974()

    squareToSzzZValue1975()

    squareToSzzZValue1976()

    squareToSzzZValue1977()

    squareToSzzZValue1978()

    squareToSzzZValue1979()

    squareToSzzZValue1980()

    squareToSzzZValue1981()

    squareToSzzZValue1982()

    squareToSzzZValue1983()

    squareToSzzZValue1984()

    squareToSzzZValue1985()

    squareToSzzZValue1986()

    squareToSzzZValue1987()

    squareToSzzZValue1988()

    squareToSzzZValue1989()

    squareToSzzZValue1990()

    squareToSzzZValue1991()

    squareToSzzZValue1992()

    squareToSzzZValue1993()

    squareToSzzZValue1994()

    squareToSzzZValue1995()

    squareToSzzZValue1996()

    squareToSzzZValue1997()

    squareToSzzZValue1998()

    squareToSzzZValue1999()

    squareToSzzZValue2000()

    squareToSzzZValue2001()

    squareToSzzZValue2002()

    squareToSzzZValue2003()

    squareToSzzZValue2004()

    squareToSzzZValue2005()

    squareToSzzZValue2006()

    squareToSzzZValue2007()

    squareToSzzZValue2008()

    squareToSzzZValue2009()

    squareToSzzZValue2010()

    squareToSzzZValue2011()

    squareToSzzZValue2012()

    squareToSzzZValue2013()

    squareToSzzZValue2014()

    squareToSzzZValue2015()

    squareToSzzZValue2016()

    squareToSzzZValue2017()

    squareToSzzZValue2018()

    squareToSzzZValue2019()

    squareToSzzZValue2020()

    squareToSzzZValue2021()

    squareToSzzZValue2022()

    squareToSzzZValue2023()

    squareToSzzZValue2024()

    squareToSzzZValue2025()
    
    alert("Your art has been loaded successfully from your browser's local browser storage.");

};

function squareNull(){
    valueSave = 'zSqrArtSpecz0';
    var tripleZeroA = localStorage.getItem(valueSave);
    if(tripleZeroA == null){
        setAThis();
    }else{
        getBThis();
    };
};