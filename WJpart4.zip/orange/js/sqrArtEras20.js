function aZsqrsA1() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs1").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs1").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA2() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs2").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs2").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA3() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs3").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs3").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA4() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs4").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs4").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA5() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs5").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs5").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA6() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs6").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs6").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA7() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs7").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs7").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA8() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs8").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs8").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA9() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs9").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs9").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA10() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs10").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs10").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA11() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs11").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs11").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA12() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs12").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs12").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA13() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs13").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs13").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA14() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs14").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs14").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA15() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs15").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs15").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA16() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs16").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs16").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA17() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs17").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs17").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA18() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs18").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs18").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA19() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs19").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs19").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA20() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs20").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs20").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA21() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs21").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs21").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA22() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs22").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs22").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA23() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs23").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs23").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA24() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs24").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs24").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA25() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs25").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs25").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA26() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs26").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs26").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA27() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs27").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs27").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA28() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs28").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs28").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA29() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs29").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs29").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA30() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs30").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs30").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA31() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs31").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs31").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA32() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs32").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs32").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA33() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs33").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs33").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA34() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs34").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs34").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA35() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs35").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs35").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA36() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs36").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs36").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA37() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs37").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs37").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA38() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs38").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs38").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA39() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs39").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs39").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA40() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs40").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs40").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA41() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs41").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs41").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA42() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs42").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs42").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA43() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs43").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs43").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA44() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs44").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs44").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA45() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs45").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs45").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA46() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs46").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs46").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA47() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs47").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs47").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA48() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs48").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs48").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA49() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs49").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs49").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsA50() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs50").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs50").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB51() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs51").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs51").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB52() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs52").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs52").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB53() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs53").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs53").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB54() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs54").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs54").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB55() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs55").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs55").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB56() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs56").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs56").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB57() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs57").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs57").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB58() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs58").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs58").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB59() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs59").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs59").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB60() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs60").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs60").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB61() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs61").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs61").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB62() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs62").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs62").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB63() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs63").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs63").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB64() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs64").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs64").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB65() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs65").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs65").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB66() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs66").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs66").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB67() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs67").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs67").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB68() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs68").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs68").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB69() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs69").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs69").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB70() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs70").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs70").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB71() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs71").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs71").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB72() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs72").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs72").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB73() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs73").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs73").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB74() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs74").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs74").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB75() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs75").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs75").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB76() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs76").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs76").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB77() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs77").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs77").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB78() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs78").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs78").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB79() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs79").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs79").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB80() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs80").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs80").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB81() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs81").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs81").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB82() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs82").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs82").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB83() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs83").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs83").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB84() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs84").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs84").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB85() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs85").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs85").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB86() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs86").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs86").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB87() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs87").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs87").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB88() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs88").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs88").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB89() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs89").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs89").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB90() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs90").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs90").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB91() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs91").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs91").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB92() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs92").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs92").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB93() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs93").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs93").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB94() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs94").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs94").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB95() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs95").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs95").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB96() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs96").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs96").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB97() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs97").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs97").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB98() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs98").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs98").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB99() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs99").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs99").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsB100() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs100").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs100").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC101() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs101").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs101").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC102() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs102").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs102").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC103() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs103").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs103").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC104() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs104").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs104").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC105() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs105").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs105").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC106() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs106").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs106").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC107() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs107").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs107").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC108() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs108").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs108").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC109() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs109").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs109").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC110() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs110").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs110").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC111() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs111").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs111").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC112() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs112").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs112").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC113() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs113").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs113").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC114() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs114").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs114").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC115() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs115").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs115").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC116() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs116").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs116").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC117() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs117").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs117").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC118() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs118").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs118").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC119() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs119").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs119").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC120() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs120").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs120").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC121() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs121").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs121").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC122() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs122").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs122").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC123() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs123").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs123").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC124() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs124").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs124").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC125() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs125").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs125").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC126() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs126").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs126").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC127() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs127").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs127").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC128() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs128").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs128").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC129() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs129").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs129").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC130() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs130").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs130").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC131() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs131").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs131").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC132() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs132").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs132").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC133() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs133").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs133").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC134() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs134").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs134").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC135() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs135").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs135").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC136() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs136").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs136").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC137() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs137").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs137").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC138() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs138").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs138").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC139() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs139").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs139").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC140() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs140").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs140").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC141() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs141").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs141").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC142() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs142").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs142").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC143() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs143").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs143").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC144() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs144").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs144").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC145() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs145").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs145").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC146() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs146").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs146").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC147() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs147").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs147").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC148() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs148").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs148").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC149() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs149").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs149").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsC150() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs150").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs150").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD151() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs151").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs151").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD152() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs152").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs152").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD153() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs153").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs153").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD154() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs154").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs154").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD155() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs155").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs155").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD156() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs156").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs156").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD157() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs157").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs157").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD158() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs158").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs158").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD159() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs159").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs159").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD160() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs160").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs160").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD161() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs161").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs161").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD162() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs162").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs162").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD163() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs163").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs163").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD164() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs164").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs164").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD165() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs165").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs165").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD166() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs166").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs166").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD167() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs167").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs167").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD168() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs168").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs168").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD169() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs169").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs169").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD170() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs170").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs170").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD171() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs171").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs171").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD172() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs172").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs172").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD173() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs173").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs173").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD174() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs174").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs174").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD175() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs175").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs175").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD176() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs176").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs176").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD177() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs177").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs177").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD178() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs178").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs178").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD179() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs179").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs179").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD180() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs180").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs180").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD181() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs181").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs181").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD182() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs182").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs182").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD183() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs183").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs183").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD184() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs184").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs184").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD185() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs185").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs185").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD186() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs186").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs186").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD187() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs187").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs187").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD188() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs188").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs188").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD189() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs189").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs189").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD190() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs190").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs190").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD191() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs191").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs191").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD192() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs192").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs192").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD193() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs193").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs193").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD194() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs194").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs194").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD195() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs195").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs195").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD196() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs196").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs196").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD197() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs197").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs197").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD198() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs198").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs198").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD199() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs199").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs199").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsD200() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs200").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs200").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE201() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs201").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs201").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE202() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs202").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs202").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE203() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs203").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs203").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE204() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs204").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs204").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE205() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs205").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs205").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE206() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs206").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs206").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE207() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs207").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs207").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE208() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs208").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs208").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE209() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs209").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs209").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE210() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs210").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs210").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE211() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs211").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs211").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE212() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs212").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs212").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE213() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs213").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs213").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE214() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs214").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs214").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE215() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs215").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs215").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE216() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs216").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs216").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE217() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs217").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs217").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE218() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs218").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs218").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE219() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs219").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs219").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE220() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs220").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs220").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE221() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs221").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs221").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE222() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs222").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs222").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE223() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs223").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs223").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE224() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs224").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs224").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE225() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs225").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs225").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE226() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs226").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs226").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE227() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs227").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs227").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE228() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs228").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs228").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE229() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs229").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs229").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE230() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs230").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs230").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE231() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs231").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs231").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE232() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs232").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs232").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE233() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs233").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs233").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE234() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs234").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs234").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE235() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs235").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs235").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE236() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs236").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs236").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE237() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs237").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs237").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE238() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs238").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs238").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE239() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs239").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs239").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE240() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs240").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs240").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE241() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs241").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs241").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE242() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs242").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs242").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE243() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs243").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs243").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE244() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs244").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs244").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE245() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs245").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs245").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE246() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs246").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs246").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE247() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs247").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs247").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE248() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs248").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs248").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE249() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs249").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs249").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsE250() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs250").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs250").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF251() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs251").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs251").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF252() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs252").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs252").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF253() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs253").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs253").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF254() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs254").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs254").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF255() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs255").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs255").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF256() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs256").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs256").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF257() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs257").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs257").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF258() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs258").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs258").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF259() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs259").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs259").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF260() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs260").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs260").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF261() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs261").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs261").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF262() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs262").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs262").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF263() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs263").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs263").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF264() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs264").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs264").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF265() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs265").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs265").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF266() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs266").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs266").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF267() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs267").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs267").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF268() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs268").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs268").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF269() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs269").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs269").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF270() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs270").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs270").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF271() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs271").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs271").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF272() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs272").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs272").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF273() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs273").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs273").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF274() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs274").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs274").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF275() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs275").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs275").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF276() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs276").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs276").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF277() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs277").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs277").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF278() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs278").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs278").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF279() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs279").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs279").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF280() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs280").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs280").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF281() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs281").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs281").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF282() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs282").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs282").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF283() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs283").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs283").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF284() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs284").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs284").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF285() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs285").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs285").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF286() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs286").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs286").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF287() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs287").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs287").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF288() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs288").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs288").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF289() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs289").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs289").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF290() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs290").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs290").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF291() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs291").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs291").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF292() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs292").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs292").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF293() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs293").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs293").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF294() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs294").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs294").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF295() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs295").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs295").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF296() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs296").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs296").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF297() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs297").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs297").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF298() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs298").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs298").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF299() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs299").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs299").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsF300() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs300").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs300").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG301() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs301").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs301").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG302() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs302").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs302").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG303() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs303").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs303").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG304() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs304").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs304").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG305() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs305").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs305").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG306() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs306").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs306").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG307() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs307").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs307").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG308() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs308").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs308").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG309() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs309").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs309").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG310() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs310").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs310").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG311() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs311").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs311").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG312() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs312").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs312").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG313() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs313").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs313").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG314() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs314").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs314").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG315() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs315").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs315").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG316() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs316").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs316").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG317() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs317").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs317").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG318() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs318").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs318").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG319() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs319").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs319").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG320() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs320").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs320").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG321() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs321").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs321").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG322() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs322").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs322").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG323() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs323").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs323").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG324() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs324").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs324").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG325() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs325").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs325").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG326() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs326").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs326").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG327() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs327").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs327").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG328() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs328").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs328").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG329() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs329").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs329").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG330() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs330").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs330").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG331() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs331").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs331").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG332() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs332").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs332").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG333() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs333").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs333").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG334() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs334").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs334").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG335() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs335").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs335").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG336() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs336").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs336").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG337() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs337").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs337").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG338() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs338").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs338").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG339() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs339").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs339").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG340() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs340").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs340").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG341() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs341").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs341").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG342() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs342").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs342").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG343() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs343").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs343").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG344() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs344").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs344").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG345() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs345").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs345").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG346() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs346").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs346").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG347() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs347").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs347").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG348() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs348").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs348").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG349() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs349").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs349").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsG350() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs350").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs350").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH351() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs351").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs351").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH352() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs352").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs352").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH353() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs353").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs353").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH354() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs354").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs354").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH355() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs355").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs355").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH356() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs356").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs356").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH357() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs357").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs357").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH358() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs358").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs358").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH359() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs359").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs359").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH360() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs360").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs360").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH361() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs361").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs361").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH362() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs362").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs362").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH363() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs363").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs363").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH364() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs364").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs364").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH365() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs365").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs365").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH366() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs366").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs366").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH367() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs367").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs367").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH368() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs368").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs368").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH369() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs369").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs369").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH370() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs370").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs370").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH371() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs371").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs371").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH372() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs372").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs372").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH373() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs373").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs373").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH374() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs374").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs374").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH375() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs375").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs375").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH376() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs376").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs376").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH377() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs377").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs377").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH378() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs378").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs378").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH379() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs379").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs379").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH380() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs380").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs380").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH381() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs381").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs381").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH382() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs382").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs382").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH383() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs383").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs383").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH384() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs384").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs384").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH385() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs385").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs385").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH386() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs386").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs386").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH387() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs387").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs387").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH388() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs388").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs388").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH389() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs389").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs389").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH390() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs390").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs390").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH391() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs391").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs391").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH392() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs392").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs392").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH393() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs393").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs393").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH394() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs394").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs394").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH395() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs395").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs395").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH396() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs396").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs396").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH397() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs397").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs397").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH398() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs398").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs398").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH399() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs399").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs399").src = "img/sqrs/wSqr.png"
};};};

function aZsqrsH400() {
 if(document.getElementById("check4").checked == true) {
    if(document.getElementById("imgSqrs400").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqrs400").src = "img/sqrs/wSqr.png"
};};};