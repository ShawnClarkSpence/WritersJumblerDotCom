function square1(){

    var sQz1 = document.getElementById("imgSqrs1").src;

    value20Save1 = "zSqrArtSpecz1";

    localStorage.setItem(value20Save1, sQz1);
};

function square2(){

    var sQz2 = document.getElementById("imgSqrs2").src;

    value20Save2 = "zSqrArtSpecz2";

    localStorage.setItem(value20Save2, sQz2);
};

function square3(){

    var sQz3 = document.getElementById("imgSqrs3").src;

    value20Save3 = "zSqrArtSpecz3";

    localStorage.setItem(value20Save3, sQz3);
};

function square4(){

    var sQz4 = document.getElementById("imgSqrs4").src;

    value20Save4 = "zSqrArtSpecz4";

    localStorage.setItem(value20Save4, sQz4);
};

function square5(){

    var sQz5 = document.getElementById("imgSqrs5").src;

    value20Save5 = "zSqrArtSpecz5";

    localStorage.setItem(value20Save5, sQz5);
};

function square6(){

    var sQz6 = document.getElementById("imgSqrs6").src;

    value20Save6 = "zSqrArtSpecz6";

    localStorage.setItem(value20Save6, sQz6);
};

function square7(){

    var sQz7 = document.getElementById("imgSqrs7").src;

    value20Save7 = "zSqrArtSpecz7";

    localStorage.setItem(value20Save7, sQz7);
};

function square8(){

    var sQz8 = document.getElementById("imgSqrs8").src;

    value20Save8 = "zSqrArtSpecz8";

    localStorage.setItem(value20Save8, sQz8);
};

function square9(){

    var sQz9 = document.getElementById("imgSqrs9").src;

    value20Save9 = "zSqrArtSpecz9";

    localStorage.setItem(value20Save9, sQz9);
};

function square10(){

    var sQz10 = document.getElementById("imgSqrs10").src;

    value20Save10 = "zSqrArtSpecz10";

    localStorage.setItem(value20Save10, sQz10);
};

function square11(){

    var sQz11 = document.getElementById("imgSqrs11").src;

    value20Save11 = "zSqrArtSpecz11";

    localStorage.setItem(value20Save11, sQz11);
};

function square12(){

    var sQz12 = document.getElementById("imgSqrs12").src;

    value20Save12 = "zSqrArtSpecz12";

    localStorage.setItem(value20Save12, sQz12);
};

function square13(){

    var sQz13 = document.getElementById("imgSqrs13").src;

    value20Save13 = "zSqrArtSpecz13";

    localStorage.setItem(value20Save13, sQz13);
};

function square14(){

    var sQz14 = document.getElementById("imgSqrs14").src;

    value20Save14 = "zSqrArtSpecz14";

    localStorage.setItem(value20Save14, sQz14);
};

function square15(){

    var sQz15 = document.getElementById("imgSqrs15").src;

    value20Save15 = "zSqrArtSpecz15";

    localStorage.setItem(value20Save15, sQz15);
};

function square16(){

    var sQz16 = document.getElementById("imgSqrs16").src;

    value20Save16 = "zSqrArtSpecz16";

    localStorage.setItem(value20Save16, sQz16);
};

function square17(){

    var sQz17 = document.getElementById("imgSqrs17").src;

    value20Save17 = "zSqrArtSpecz17";

    localStorage.setItem(value20Save17, sQz17);
};

function square18(){

    var sQz18 = document.getElementById("imgSqrs18").src;

    value20Save18 = "zSqrArtSpecz18";

    localStorage.setItem(value20Save18, sQz18);
};

function square19(){

    var sQz19 = document.getElementById("imgSqrs19").src;

    value20Save19 = "zSqrArtSpecz19";

    localStorage.setItem(value20Save19, sQz19);
};

function square20(){

    var sQz20 = document.getElementById("imgSqrs20").src;

    value20Save20 = "zSqrArtSpecz20";

    localStorage.setItem(value20Save20, sQz20);
};

function square21(){

    var sQz21 = document.getElementById("imgSqrs21").src;

    value20Save21 = "zSqrArtSpecz21";

    localStorage.setItem(value20Save21, sQz21);
};

function square22(){

    var sQz22 = document.getElementById("imgSqrs22").src;

    value20Save22 = "zSqrArtSpecz22";

    localStorage.setItem(value20Save22, sQz22);
};

function square23(){

    var sQz23 = document.getElementById("imgSqrs23").src;

    value20Save23 = "zSqrArtSpecz23";

    localStorage.setItem(value20Save23, sQz23);
};

function square24(){

    var sQz24 = document.getElementById("imgSqrs24").src;

    value20Save24 = "zSqrArtSpecz24";

    localStorage.setItem(value20Save24, sQz24);
};

function square25(){

    var sQz25 = document.getElementById("imgSqrs25").src;

    value20Save25 = "zSqrArtSpecz25";

    localStorage.setItem(value20Save25, sQz25);
};

function square26(){

    var sQz26 = document.getElementById("imgSqrs26").src;

    value20Save26 = "zSqrArtSpecz26";

    localStorage.setItem(value20Save26, sQz26);
};

function square27(){

    var sQz27 = document.getElementById("imgSqrs27").src;

    value20Save27 = "zSqrArtSpecz27";

    localStorage.setItem(value20Save27, sQz27);
};

function square28(){

    var sQz28 = document.getElementById("imgSqrs28").src;

    value20Save28 = "zSqrArtSpecz28";

    localStorage.setItem(value20Save28, sQz28);
};

function square29(){

    var sQz29 = document.getElementById("imgSqrs29").src;

    value20Save29 = "zSqrArtSpecz29";

    localStorage.setItem(value20Save29, sQz29);
};

function square30(){

    var sQz30 = document.getElementById("imgSqrs30").src;

    value20Save30 = "zSqrArtSpecz30";

    localStorage.setItem(value20Save30, sQz30);
};

function square31(){

    var sQz31 = document.getElementById("imgSqrs31").src;

    value20Save31 = "zSqrArtSpecz31";

    localStorage.setItem(value20Save31, sQz31);
};

function square32(){

    var sQz32 = document.getElementById("imgSqrs32").src;

    value20Save32 = "zSqrArtSpecz32";

    localStorage.setItem(value20Save32, sQz32);
};

function square33(){

    var sQz33 = document.getElementById("imgSqrs33").src;

    value20Save33 = "zSqrArtSpecz33";

    localStorage.setItem(value20Save33, sQz33);
};

function square34(){

    var sQz34 = document.getElementById("imgSqrs34").src;

    value20Save34 = "zSqrArtSpecz34";

    localStorage.setItem(value20Save34, sQz34);
};

function square35(){

    var sQz35 = document.getElementById("imgSqrs35").src;

    value20Save35 = "zSqrArtSpecz35";

    localStorage.setItem(value20Save35, sQz35);
};

function square36(){

    var sQz36 = document.getElementById("imgSqrs36").src;

    value20Save36 = "zSqrArtSpecz36";

    localStorage.setItem(value20Save36, sQz36);
};

function square37(){

    var sQz37 = document.getElementById("imgSqrs37").src;

    value20Save37 = "zSqrArtSpecz37";

    localStorage.setItem(value20Save37, sQz37);
};

function square38(){

    var sQz38 = document.getElementById("imgSqrs38").src;

    value20Save38 = "zSqrArtSpecz38";

    localStorage.setItem(value20Save38, sQz38);
};

function square39(){

    var sQz39 = document.getElementById("imgSqrs39").src;

    value20Save39 = "zSqrArtSpecz39";

    localStorage.setItem(value20Save39, sQz39);
};

function square40(){

    var sQz40 = document.getElementById("imgSqrs40").src;

    value20Save40 = "zSqrArtSpecz40";

    localStorage.setItem(value20Save40, sQz40);
};

function square41(){

    var sQz41 = document.getElementById("imgSqrs41").src;

    value20Save41 = "zSqrArtSpecz41";

    localStorage.setItem(value20Save41, sQz41);
};

function square42(){

    var sQz42 = document.getElementById("imgSqrs42").src;

    value20Save42 = "zSqrArtSpecz42";

    localStorage.setItem(value20Save42, sQz42);
};

function square43(){

    var sQz43 = document.getElementById("imgSqrs43").src;

    value20Save43 = "zSqrArtSpecz43";

    localStorage.setItem(value20Save43, sQz43);
};

function square44(){

    var sQz44 = document.getElementById("imgSqrs44").src;

    value20Save44 = "zSqrArtSpecz44";

    localStorage.setItem(value20Save44, sQz44);
};

function square45(){

    var sQz45 = document.getElementById("imgSqrs45").src;

    value20Save45 = "zSqrArtSpecz45";

    localStorage.setItem(value20Save45, sQz45);
};

function square46(){

    var sQz46 = document.getElementById("imgSqrs46").src;

    value20Save46 = "zSqrArtSpecz46";

    localStorage.setItem(value20Save46, sQz46);
};

function square47(){

    var sQz47 = document.getElementById("imgSqrs47").src;

    value20Save47 = "zSqrArtSpecz47";

    localStorage.setItem(value20Save47, sQz47);
};

function square48(){

    var sQz48 = document.getElementById("imgSqrs48").src;

    value20Save48 = "zSqrArtSpecz48";

    localStorage.setItem(value20Save48, sQz48);
};

function square49(){

    var sQz49 = document.getElementById("imgSqrs49").src;

    value20Save49 = "zSqrArtSpecz49";

    localStorage.setItem(value20Save49, sQz49);
};

function square50(){

    var sQz50 = document.getElementById("imgSqrs50").src;

    value20Save50 = "zSqrArtSpecz50";

    localStorage.setItem(value20Save50, sQz50);
};

function square51(){

    var sQz51 = document.getElementById("imgSqrs51").src;

    value20Save51 = "zSqrArtSpecz51";

    localStorage.setItem(value20Save51, sQz51);
};

function square52(){

    var sQz52 = document.getElementById("imgSqrs52").src;

    value20Save52 = "zSqrArtSpecz52";

    localStorage.setItem(value20Save52, sQz52);
};

function square53(){

    var sQz53 = document.getElementById("imgSqrs53").src;

    value20Save53 = "zSqrArtSpecz53";

    localStorage.setItem(value20Save53, sQz53);
};

function square54(){

    var sQz54 = document.getElementById("imgSqrs54").src;

    value20Save54 = "zSqrArtSpecz54";

    localStorage.setItem(value20Save54, sQz54);
};

function square55(){

    var sQz55 = document.getElementById("imgSqrs55").src;

    value20Save55 = "zSqrArtSpecz55";

    localStorage.setItem(value20Save55, sQz55);
};

function square56(){

    var sQz56 = document.getElementById("imgSqrs56").src;

    value20Save56 = "zSqrArtSpecz56";

    localStorage.setItem(value20Save56, sQz56);
};

function square57(){

    var sQz57 = document.getElementById("imgSqrs57").src;

    value20Save57 = "zSqrArtSpecz57";

    localStorage.setItem(value20Save57, sQz57);
};

function square58(){

    var sQz58 = document.getElementById("imgSqrs58").src;

    value20Save58 = "zSqrArtSpecz58";

    localStorage.setItem(value20Save58, sQz58);
};

function square59(){

    var sQz59 = document.getElementById("imgSqrs59").src;

    value20Save59 = "zSqrArtSpecz59";

    localStorage.setItem(value20Save59, sQz59);
};

function square60(){

    var sQz60 = document.getElementById("imgSqrs60").src;

    value20Save60 = "zSqrArtSpecz60";

    localStorage.setItem(value20Save60, sQz60);
};

function square61(){

    var sQz61 = document.getElementById("imgSqrs61").src;

    value20Save61 = "zSqrArtSpecz61";

    localStorage.setItem(value20Save61, sQz61);
};

function square62(){

    var sQz62 = document.getElementById("imgSqrs62").src;

    value20Save62 = "zSqrArtSpecz62";

    localStorage.setItem(value20Save62, sQz62);
};

function square63(){

    var sQz63 = document.getElementById("imgSqrs63").src;

    value20Save63 = "zSqrArtSpecz63";

    localStorage.setItem(value20Save63, sQz63);
};

function square64(){

    var sQz64 = document.getElementById("imgSqrs64").src;

    value20Save64 = "zSqrArtSpecz64";

    localStorage.setItem(value20Save64, sQz64);
};

function square65(){

    var sQz65 = document.getElementById("imgSqrs65").src;

    value20Save65 = "zSqrArtSpecz65";

    localStorage.setItem(value20Save65, sQz65);
};

function square66(){

    var sQz66 = document.getElementById("imgSqrs66").src;

    value20Save66 = "zSqrArtSpecz66";

    localStorage.setItem(value20Save66, sQz66);
};

function square67(){

    var sQz67 = document.getElementById("imgSqrs67").src;

    value20Save67 = "zSqrArtSpecz67";

    localStorage.setItem(value20Save67, sQz67);
};

function square68(){

    var sQz68 = document.getElementById("imgSqrs68").src;

    value20Save68 = "zSqrArtSpecz68";

    localStorage.setItem(value20Save68, sQz68);
};

function square69(){

    var sQz69 = document.getElementById("imgSqrs69").src;

    value20Save69 = "zSqrArtSpecz69";

    localStorage.setItem(value20Save69, sQz69);
};

function square70(){

    var sQz70 = document.getElementById("imgSqrs70").src;

    value20Save70 = "zSqrArtSpecz70";

    localStorage.setItem(value20Save70, sQz70);
};

function square71(){

    var sQz71 = document.getElementById("imgSqrs71").src;

    value20Save71 = "zSqrArtSpecz71";

    localStorage.setItem(value20Save71, sQz71);
};

function square72(){

    var sQz72 = document.getElementById("imgSqrs72").src;

    value20Save72 = "zSqrArtSpecz72";

    localStorage.setItem(value20Save72, sQz72);
};

function square73(){

    var sQz73 = document.getElementById("imgSqrs73").src;

    value20Save73 = "zSqrArtSpecz73";

    localStorage.setItem(value20Save73, sQz73);
};

function square74(){

    var sQz74 = document.getElementById("imgSqrs74").src;

    value20Save74 = "zSqrArtSpecz74";

    localStorage.setItem(value20Save74, sQz74);
};

function square75(){

    var sQz75 = document.getElementById("imgSqrs75").src;

    value20Save75 = "zSqrArtSpecz75";

    localStorage.setItem(value20Save75, sQz75);
};

function square76(){

    var sQz76 = document.getElementById("imgSqrs76").src;

    value20Save76 = "zSqrArtSpecz76";

    localStorage.setItem(value20Save76, sQz76);
};

function square77(){

    var sQz77 = document.getElementById("imgSqrs77").src;

    value20Save77 = "zSqrArtSpecz77";

    localStorage.setItem(value20Save77, sQz77);
};

function square78(){

    var sQz78 = document.getElementById("imgSqrs78").src;

    value20Save78 = "zSqrArtSpecz78";

    localStorage.setItem(value20Save78, sQz78);
};

function square79(){

    var sQz79 = document.getElementById("imgSqrs79").src;

    value20Save79 = "zSqrArtSpecz79";

    localStorage.setItem(value20Save79, sQz79);
};

function square80(){

    var sQz80 = document.getElementById("imgSqrs80").src;

    value20Save80 = "zSqrArtSpecz80";

    localStorage.setItem(value20Save80, sQz80);
};

function square81(){

    var sQz81 = document.getElementById("imgSqrs81").src;

    value20Save81 = "zSqrArtSpecz81";

    localStorage.setItem(value20Save81, sQz81);
};

function square82(){

    var sQz82 = document.getElementById("imgSqrs82").src;

    value20Save82 = "zSqrArtSpecz82";

    localStorage.setItem(value20Save82, sQz82);
};

function square83(){

    var sQz83 = document.getElementById("imgSqrs83").src;

    value20Save83 = "zSqrArtSpecz83";

    localStorage.setItem(value20Save83, sQz83);
};

function square84(){

    var sQz84 = document.getElementById("imgSqrs84").src;

    value20Save84 = "zSqrArtSpecz84";

    localStorage.setItem(value20Save84, sQz84);
};

function square85(){

    var sQz85 = document.getElementById("imgSqrs85").src;

    value20Save85 = "zSqrArtSpecz85";

    localStorage.setItem(value20Save85, sQz85);
};

function square86(){

    var sQz86 = document.getElementById("imgSqrs86").src;

    value20Save86 = "zSqrArtSpecz86";

    localStorage.setItem(value20Save86, sQz86);
};

function square87(){

    var sQz87 = document.getElementById("imgSqrs87").src;

    value20Save87 = "zSqrArtSpecz87";

    localStorage.setItem(value20Save87, sQz87);
};

function square88(){

    var sQz88 = document.getElementById("imgSqrs88").src;

    value20Save88 = "zSqrArtSpecz88";

    localStorage.setItem(value20Save88, sQz88);
};

function square89(){

    var sQz89 = document.getElementById("imgSqrs89").src;

    value20Save89 = "zSqrArtSpecz89";

    localStorage.setItem(value20Save89, sQz89);
};

function square90(){

    var sQz90 = document.getElementById("imgSqrs90").src;

    value20Save90 = "zSqrArtSpecz90";

    localStorage.setItem(value20Save90, sQz90);
};

function square91(){

    var sQz91 = document.getElementById("imgSqrs91").src;

    value20Save91 = "zSqrArtSpecz91";

    localStorage.setItem(value20Save91, sQz91);
};

function square92(){

    var sQz92 = document.getElementById("imgSqrs92").src;

    value20Save92 = "zSqrArtSpecz92";

    localStorage.setItem(value20Save92, sQz92);
};

function square93(){

    var sQz93 = document.getElementById("imgSqrs93").src;

    value20Save93 = "zSqrArtSpecz93";

    localStorage.setItem(value20Save93, sQz93);
};

function square94(){

    var sQz94 = document.getElementById("imgSqrs94").src;

    value20Save94 = "zSqrArtSpecz94";

    localStorage.setItem(value20Save94, sQz94);
};

function square95(){

    var sQz95 = document.getElementById("imgSqrs95").src;

    value20Save95 = "zSqrArtSpecz95";

    localStorage.setItem(value20Save95, sQz95);
};

function square96(){

    var sQz96 = document.getElementById("imgSqrs96").src;

    value20Save96 = "zSqrArtSpecz96";

    localStorage.setItem(value20Save96, sQz96);
};

function square97(){

    var sQz97 = document.getElementById("imgSqrs97").src;

    value20Save97 = "zSqrArtSpecz97";

    localStorage.setItem(value20Save97, sQz97);
};

function square98(){

    var sQz98 = document.getElementById("imgSqrs98").src;

    value20Save98 = "zSqrArtSpecz98";

    localStorage.setItem(value20Save98, sQz98);
};

function square99(){

    var sQz99 = document.getElementById("imgSqrs99").src;

    value20Save99 = "zSqrArtSpecz99";

    localStorage.setItem(value20Save99, sQz99);
};

function square100(){

    var sQz100 = document.getElementById("imgSqrs100").src;

    value20Save100 = "zSqrArtSpecz100";

    localStorage.setItem(value20Save100, sQz100);
};

function square101(){

    var sQz101 = document.getElementById("imgSqrs101").src;

    value20Save101 = "zSqrArtSpecz101";

    localStorage.setItem(value20Save101, sQz101);
};

function square102(){

    var sQz102 = document.getElementById("imgSqrs102").src;

    value20Save102 = "zSqrArtSpecz102";

    localStorage.setItem(value20Save102, sQz102);
};

function square103(){

    var sQz103 = document.getElementById("imgSqrs103").src;

    value20Save103 = "zSqrArtSpecz103";

    localStorage.setItem(value20Save103, sQz103);
};

function square104(){

    var sQz104 = document.getElementById("imgSqrs104").src;

    value20Save104 = "zSqrArtSpecz104";

    localStorage.setItem(value20Save104, sQz104);
};

function square105(){

    var sQz105 = document.getElementById("imgSqrs105").src;

    value20Save105 = "zSqrArtSpecz105";

    localStorage.setItem(value20Save105, sQz105);
};

function square106(){

    var sQz106 = document.getElementById("imgSqrs106").src;

    value20Save106 = "zSqrArtSpecz106";

    localStorage.setItem(value20Save106, sQz106);
};

function square107(){

    var sQz107 = document.getElementById("imgSqrs107").src;

    value20Save107 = "zSqrArtSpecz107";

    localStorage.setItem(value20Save107, sQz107);
};

function square108(){

    var sQz108 = document.getElementById("imgSqrs108").src;

    value20Save108 = "zSqrArtSpecz108";

    localStorage.setItem(value20Save108, sQz108);
};

function square109(){

    var sQz109 = document.getElementById("imgSqrs109").src;

    value20Save109 = "zSqrArtSpecz109";

    localStorage.setItem(value20Save109, sQz109);
};

function square110(){

    var sQz110 = document.getElementById("imgSqrs110").src;

    value20Save110 = "zSqrArtSpecz110";

    localStorage.setItem(value20Save110, sQz110);
};

function square111(){

    var sQz111 = document.getElementById("imgSqrs111").src;

    value20Save111 = "zSqrArtSpecz111";

    localStorage.setItem(value20Save111, sQz111);
};

function square112(){

    var sQz112 = document.getElementById("imgSqrs112").src;

    value20Save112 = "zSqrArtSpecz112";

    localStorage.setItem(value20Save112, sQz112);
};

function square113(){

    var sQz113 = document.getElementById("imgSqrs113").src;

    value20Save113 = "zSqrArtSpecz113";

    localStorage.setItem(value20Save113, sQz113);
};

function square114(){

    var sQz114 = document.getElementById("imgSqrs114").src;

    value20Save114 = "zSqrArtSpecz114";

    localStorage.setItem(value20Save114, sQz114);
};

function square115(){

    var sQz115 = document.getElementById("imgSqrs115").src;

    value20Save115 = "zSqrArtSpecz115";

    localStorage.setItem(value20Save115, sQz115);
};

function square116(){

    var sQz116 = document.getElementById("imgSqrs116").src;

    value20Save116 = "zSqrArtSpecz116";

    localStorage.setItem(value20Save116, sQz116);
};

function square117(){

    var sQz117 = document.getElementById("imgSqrs117").src;

    value20Save117 = "zSqrArtSpecz117";

    localStorage.setItem(value20Save117, sQz117);
};

function square118(){

    var sQz118 = document.getElementById("imgSqrs118").src;

    value20Save118 = "zSqrArtSpecz118";

    localStorage.setItem(value20Save118, sQz118);
};

function square119(){

    var sQz119 = document.getElementById("imgSqrs119").src;

    value20Save119 = "zSqrArtSpecz119";

    localStorage.setItem(value20Save119, sQz119);
};

function square120(){

    var sQz120 = document.getElementById("imgSqrs120").src;

    value20Save120 = "zSqrArtSpecz120";

    localStorage.setItem(value20Save120, sQz120);
};

function square121(){

    var sQz121 = document.getElementById("imgSqrs121").src;

    value20Save121 = "zSqrArtSpecz121";

    localStorage.setItem(value20Save121, sQz121);
};

function square122(){

    var sQz122 = document.getElementById("imgSqrs122").src;

    value20Save122 = "zSqrArtSpecz122";

    localStorage.setItem(value20Save122, sQz122);
};

function square123(){

    var sQz123 = document.getElementById("imgSqrs123").src;

    value20Save123 = "zSqrArtSpecz123";

    localStorage.setItem(value20Save123, sQz123);
};

function square124(){

    var sQz124 = document.getElementById("imgSqrs124").src;

    value20Save124 = "zSqrArtSpecz124";

    localStorage.setItem(value20Save124, sQz124);
};

function square125(){

    var sQz125 = document.getElementById("imgSqrs125").src;

    value20Save125 = "zSqrArtSpecz125";

    localStorage.setItem(value20Save125, sQz125);
};

function square126(){

    var sQz126 = document.getElementById("imgSqrs126").src;

    value20Save126 = "zSqrArtSpecz126";

    localStorage.setItem(value20Save126, sQz126);
};

function square127(){

    var sQz127 = document.getElementById("imgSqrs127").src;

    value20Save127 = "zSqrArtSpecz127";

    localStorage.setItem(value20Save127, sQz127);
};

function square128(){

    var sQz128 = document.getElementById("imgSqrs128").src;

    value20Save128 = "zSqrArtSpecz128";

    localStorage.setItem(value20Save128, sQz128);
};

function square129(){

    var sQz129 = document.getElementById("imgSqrs129").src;

    value20Save129 = "zSqrArtSpecz129";

    localStorage.setItem(value20Save129, sQz129);
};

function square130(){

    var sQz130 = document.getElementById("imgSqrs130").src;

    value20Save130 = "zSqrArtSpecz130";

    localStorage.setItem(value20Save130, sQz130);
};

function square131(){

    var sQz131 = document.getElementById("imgSqrs131").src;

    value20Save131 = "zSqrArtSpecz131";

    localStorage.setItem(value20Save131, sQz131);
};

function square132(){

    var sQz132 = document.getElementById("imgSqrs132").src;

    value20Save132 = "zSqrArtSpecz132";

    localStorage.setItem(value20Save132, sQz132);
};

function square133(){

    var sQz133 = document.getElementById("imgSqrs133").src;

    value20Save133 = "zSqrArtSpecz133";

    localStorage.setItem(value20Save133, sQz133);
};

function square134(){

    var sQz134 = document.getElementById("imgSqrs134").src;

    value20Save134 = "zSqrArtSpecz134";

    localStorage.setItem(value20Save134, sQz134);
};

function square135(){

    var sQz135 = document.getElementById("imgSqrs135").src;

    value20Save135 = "zSqrArtSpecz135";

    localStorage.setItem(value20Save135, sQz135);
};

function square136(){

    var sQz136 = document.getElementById("imgSqrs136").src;

    value20Save136 = "zSqrArtSpecz136";

    localStorage.setItem(value20Save136, sQz136);
};

function square137(){

    var sQz137 = document.getElementById("imgSqrs137").src;

    value20Save137 = "zSqrArtSpecz137";

    localStorage.setItem(value20Save137, sQz137);
};

function square138(){

    var sQz138 = document.getElementById("imgSqrs138").src;

    value20Save138 = "zSqrArtSpecz138";

    localStorage.setItem(value20Save138, sQz138);
};

function square139(){

    var sQz139 = document.getElementById("imgSqrs139").src;

    value20Save139 = "zSqrArtSpecz139";

    localStorage.setItem(value20Save139, sQz139);
};

function square140(){

    var sQz140 = document.getElementById("imgSqrs140").src;

    value20Save140 = "zSqrArtSpecz140";

    localStorage.setItem(value20Save140, sQz140);
};

function square141(){

    var sQz141 = document.getElementById("imgSqrs141").src;

    value20Save141 = "zSqrArtSpecz141";

    localStorage.setItem(value20Save141, sQz141);
};

function square142(){

    var sQz142 = document.getElementById("imgSqrs142").src;

    value20Save142 = "zSqrArtSpecz142";

    localStorage.setItem(value20Save142, sQz142);
};

function square143(){

    var sQz143 = document.getElementById("imgSqrs143").src;

    value20Save143 = "zSqrArtSpecz143";

    localStorage.setItem(value20Save143, sQz143);
};

function square144(){

    var sQz144 = document.getElementById("imgSqrs144").src;

    value20Save144 = "zSqrArtSpecz144";

    localStorage.setItem(value20Save144, sQz144);
};

function square145(){

    var sQz145 = document.getElementById("imgSqrs145").src;

    value20Save145 = "zSqrArtSpecz145";

    localStorage.setItem(value20Save145, sQz145);
};

function square146(){

    var sQz146 = document.getElementById("imgSqrs146").src;

    value20Save146 = "zSqrArtSpecz146";

    localStorage.setItem(value20Save146, sQz146);
};

function square147(){

    var sQz147 = document.getElementById("imgSqrs147").src;

    value20Save147 = "zSqrArtSpecz147";

    localStorage.setItem(value20Save147, sQz147);
};

function square148(){

    var sQz148 = document.getElementById("imgSqrs148").src;

    value20Save148 = "zSqrArtSpecz148";

    localStorage.setItem(value20Save148, sQz148);
};

function square149(){

    var sQz149 = document.getElementById("imgSqrs149").src;

    value20Save149 = "zSqrArtSpecz149";

    localStorage.setItem(value20Save149, sQz149);
};

function square150(){

    var sQz150 = document.getElementById("imgSqrs150").src;

    value20Save150 = "zSqrArtSpecz150";

    localStorage.setItem(value20Save150, sQz150);
};

function square151(){

    var sQz151 = document.getElementById("imgSqrs151").src;

    value20Save151 = "zSqrArtSpecz151";

    localStorage.setItem(value20Save151, sQz151);
};

function square152(){

    var sQz152 = document.getElementById("imgSqrs152").src;

    value20Save152 = "zSqrArtSpecz152";

    localStorage.setItem(value20Save152, sQz152);
};

function square153(){

    var sQz153 = document.getElementById("imgSqrs153").src;

    value20Save153 = "zSqrArtSpecz153";

    localStorage.setItem(value20Save153, sQz153);
};

function square154(){

    var sQz154 = document.getElementById("imgSqrs154").src;

    value20Save154 = "zSqrArtSpecz154";

    localStorage.setItem(value20Save154, sQz154);
};

function square155(){

    var sQz155 = document.getElementById("imgSqrs155").src;

    value20Save155 = "zSqrArtSpecz155";

    localStorage.setItem(value20Save155, sQz155);
};

function square156(){

    var sQz156 = document.getElementById("imgSqrs156").src;

    value20Save156 = "zSqrArtSpecz156";

    localStorage.setItem(value20Save156, sQz156);
};

function square157(){

    var sQz157 = document.getElementById("imgSqrs157").src;

    value20Save157 = "zSqrArtSpecz157";

    localStorage.setItem(value20Save157, sQz157);
};

function square158(){

    var sQz158 = document.getElementById("imgSqrs158").src;

    value20Save158 = "zSqrArtSpecz158";

    localStorage.setItem(value20Save158, sQz158);
};

function square159(){

    var sQz159 = document.getElementById("imgSqrs159").src;

    value20Save159 = "zSqrArtSpecz159";

    localStorage.setItem(value20Save159, sQz159);
};

function square160(){

    var sQz160 = document.getElementById("imgSqrs160").src;

    value20Save160 = "zSqrArtSpecz160";

    localStorage.setItem(value20Save160, sQz160);
};

function square161(){

    var sQz161 = document.getElementById("imgSqrs161").src;

    value20Save161 = "zSqrArtSpecz161";

    localStorage.setItem(value20Save161, sQz161);
};

function square162(){

    var sQz162 = document.getElementById("imgSqrs162").src;

    value20Save162 = "zSqrArtSpecz162";

    localStorage.setItem(value20Save162, sQz162);
};

function square163(){

    var sQz163 = document.getElementById("imgSqrs163").src;

    value20Save163 = "zSqrArtSpecz163";

    localStorage.setItem(value20Save163, sQz163);
};

function square164(){

    var sQz164 = document.getElementById("imgSqrs164").src;

    value20Save164 = "zSqrArtSpecz164";

    localStorage.setItem(value20Save164, sQz164);
};

function square165(){

    var sQz165 = document.getElementById("imgSqrs165").src;

    value20Save165 = "zSqrArtSpecz165";

    localStorage.setItem(value20Save165, sQz165);
};

function square166(){

    var sQz166 = document.getElementById("imgSqrs166").src;

    value20Save166 = "zSqrArtSpecz166";

    localStorage.setItem(value20Save166, sQz166);
};

function square167(){

    var sQz167 = document.getElementById("imgSqrs167").src;

    value20Save167 = "zSqrArtSpecz167";

    localStorage.setItem(value20Save167, sQz167);
};

function square168(){

    var sQz168 = document.getElementById("imgSqrs168").src;

    value20Save168 = "zSqrArtSpecz168";

    localStorage.setItem(value20Save168, sQz168);
};

function square169(){

    var sQz169 = document.getElementById("imgSqrs169").src;

    value20Save169 = "zSqrArtSpecz169";

    localStorage.setItem(value20Save169, sQz169);
};

function square170(){

    var sQz170 = document.getElementById("imgSqrs170").src;

    value20Save170 = "zSqrArtSpecz170";

    localStorage.setItem(value20Save170, sQz170);
};

function square171(){

    var sQz171 = document.getElementById("imgSqrs171").src;

    value20Save171 = "zSqrArtSpecz171";

    localStorage.setItem(value20Save171, sQz171);
};

function square172(){

    var sQz172 = document.getElementById("imgSqrs172").src;

    value20Save172 = "zSqrArtSpecz172";

    localStorage.setItem(value20Save172, sQz172);
};

function square173(){

    var sQz173 = document.getElementById("imgSqrs173").src;

    value20Save173 = "zSqrArtSpecz173";

    localStorage.setItem(value20Save173, sQz173);
};

function square174(){

    var sQz174 = document.getElementById("imgSqrs174").src;

    value20Save174 = "zSqrArtSpecz174";

    localStorage.setItem(value20Save174, sQz174);
};

function square175(){

    var sQz175 = document.getElementById("imgSqrs175").src;

    value20Save175 = "zSqrArtSpecz175";

    localStorage.setItem(value20Save175, sQz175);
};

function square176(){

    var sQz176 = document.getElementById("imgSqrs176").src;

    value20Save176 = "zSqrArtSpecz176";

    localStorage.setItem(value20Save176, sQz176);
};

function square177(){

    var sQz177 = document.getElementById("imgSqrs177").src;

    value20Save177 = "zSqrArtSpecz177";

    localStorage.setItem(value20Save177, sQz177);
};

function square178(){

    var sQz178 = document.getElementById("imgSqrs178").src;

    value20Save178 = "zSqrArtSpecz178";

    localStorage.setItem(value20Save178, sQz178);
};

function square179(){

    var sQz179 = document.getElementById("imgSqrs179").src;

    value20Save179 = "zSqrArtSpecz179";

    localStorage.setItem(value20Save179, sQz179);
};

function square180(){

    var sQz180 = document.getElementById("imgSqrs180").src;

    value20Save180 = "zSqrArtSpecz180";

    localStorage.setItem(value20Save180, sQz180);
};

function square181(){

    var sQz181 = document.getElementById("imgSqrs181").src;

    value20Save181 = "zSqrArtSpecz181";

    localStorage.setItem(value20Save181, sQz181);
};

function square182(){

    var sQz182 = document.getElementById("imgSqrs182").src;

    value20Save182 = "zSqrArtSpecz182";

    localStorage.setItem(value20Save182, sQz182);
};

function square183(){

    var sQz183 = document.getElementById("imgSqrs183").src;

    value20Save183 = "zSqrArtSpecz183";

    localStorage.setItem(value20Save183, sQz183);
};

function square184(){

    var sQz184 = document.getElementById("imgSqrs184").src;

    value20Save184 = "zSqrArtSpecz184";

    localStorage.setItem(value20Save184, sQz184);
};

function square185(){

    var sQz185 = document.getElementById("imgSqrs185").src;

    value20Save185 = "zSqrArtSpecz185";

    localStorage.setItem(value20Save185, sQz185);
};

function square186(){

    var sQz186 = document.getElementById("imgSqrs186").src;

    value20Save186 = "zSqrArtSpecz186";

    localStorage.setItem(value20Save186, sQz186);
};

function square187(){

    var sQz187 = document.getElementById("imgSqrs187").src;

    value20Save187 = "zSqrArtSpecz187";

    localStorage.setItem(value20Save187, sQz187);
};

function square188(){

    var sQz188 = document.getElementById("imgSqrs188").src;

    value20Save188 = "zSqrArtSpecz188";

    localStorage.setItem(value20Save188, sQz188);
};

function square189(){

    var sQz189 = document.getElementById("imgSqrs189").src;

    value20Save189 = "zSqrArtSpecz189";

    localStorage.setItem(value20Save189, sQz189);
};

function square190(){

    var sQz190 = document.getElementById("imgSqrs190").src;

    value20Save190 = "zSqrArtSpecz190";

    localStorage.setItem(value20Save190, sQz190);
};

function square191(){

    var sQz191 = document.getElementById("imgSqrs191").src;

    value20Save191 = "zSqrArtSpecz191";

    localStorage.setItem(value20Save191, sQz191);
};

function square192(){

    var sQz192 = document.getElementById("imgSqrs192").src;

    value20Save192 = "zSqrArtSpecz192";

    localStorage.setItem(value20Save192, sQz192);
};

function square193(){

    var sQz193 = document.getElementById("imgSqrs193").src;

    value20Save193 = "zSqrArtSpecz193";

    localStorage.setItem(value20Save193, sQz193);
};

function square194(){

    var sQz194 = document.getElementById("imgSqrs194").src;

    value20Save194 = "zSqrArtSpecz194";

    localStorage.setItem(value20Save194, sQz194);
};

function square195(){

    var sQz195 = document.getElementById("imgSqrs195").src;

    value20Save195 = "zSqrArtSpecz195";

    localStorage.setItem(value20Save195, sQz195);
};

function square196(){

    var sQz196 = document.getElementById("imgSqrs196").src;

    value20Save196 = "zSqrArtSpecz196";

    localStorage.setItem(value20Save196, sQz196);
};

function square197(){

    var sQz197 = document.getElementById("imgSqrs197").src;

    value20Save197 = "zSqrArtSpecz197";

    localStorage.setItem(value20Save197, sQz197);
};

function square198(){

    var sQz198 = document.getElementById("imgSqrs198").src;

    value20Save198 = "zSqrArtSpecz198";

    localStorage.setItem(value20Save198, sQz198);
};

function square199(){

    var sQz199 = document.getElementById("imgSqrs199").src;

    value20Save199 = "zSqrArtSpecz199";

    localStorage.setItem(value20Save199, sQz199);
};

function square200(){

    var sQz200 = document.getElementById("imgSqrs200").src;

    value20Save200 = "zSqrArtSpecz200";

    localStorage.setItem(value20Save200, sQz200);
};

function square201(){

    var sQz201 = document.getElementById("imgSqrs201").src;

    value20Save201 = "zSqrArtSpecz201";

    localStorage.setItem(value20Save201, sQz201);
};

function square202(){

    var sQz202 = document.getElementById("imgSqrs202").src;

    value20Save202 = "zSqrArtSpecz202";

    localStorage.setItem(value20Save202, sQz202);
};

function square203(){

    var sQz203 = document.getElementById("imgSqrs203").src;

    value20Save203 = "zSqrArtSpecz203";

    localStorage.setItem(value20Save203, sQz203);
};

function square204(){

    var sQz204 = document.getElementById("imgSqrs204").src;

    value20Save204 = "zSqrArtSpecz204";

    localStorage.setItem(value20Save204, sQz204);
};

function square205(){

    var sQz205 = document.getElementById("imgSqrs205").src;

    value20Save205 = "zSqrArtSpecz205";

    localStorage.setItem(value20Save205, sQz205);
};

function square206(){

    var sQz206 = document.getElementById("imgSqrs206").src;

    value20Save206 = "zSqrArtSpecz206";

    localStorage.setItem(value20Save206, sQz206);
};

function square207(){

    var sQz207 = document.getElementById("imgSqrs207").src;

    value20Save207 = "zSqrArtSpecz207";

    localStorage.setItem(value20Save207, sQz207);
};

function square208(){

    var sQz208 = document.getElementById("imgSqrs208").src;

    value20Save208 = "zSqrArtSpecz208";

    localStorage.setItem(value20Save208, sQz208);
};

function square209(){

    var sQz209 = document.getElementById("imgSqrs209").src;

    value20Save209 = "zSqrArtSpecz209";

    localStorage.setItem(value20Save209, sQz209);
};

function square210(){

    var sQz210 = document.getElementById("imgSqrs210").src;

    value20Save210 = "zSqrArtSpecz210";

    localStorage.setItem(value20Save210, sQz210);
};

function square211(){

    var sQz211 = document.getElementById("imgSqrs211").src;

    value20Save211 = "zSqrArtSpecz211";

    localStorage.setItem(value20Save211, sQz211);
};

function square212(){

    var sQz212 = document.getElementById("imgSqrs212").src;

    value20Save212 = "zSqrArtSpecz212";

    localStorage.setItem(value20Save212, sQz212);
};

function square213(){

    var sQz213 = document.getElementById("imgSqrs213").src;

    value20Save213 = "zSqrArtSpecz213";

    localStorage.setItem(value20Save213, sQz213);
};

function square214(){

    var sQz214 = document.getElementById("imgSqrs214").src;

    value20Save214 = "zSqrArtSpecz214";

    localStorage.setItem(value20Save214, sQz214);
};

function square215(){

    var sQz215 = document.getElementById("imgSqrs215").src;

    value20Save215 = "zSqrArtSpecz215";

    localStorage.setItem(value20Save215, sQz215);
};

function square216(){

    var sQz216 = document.getElementById("imgSqrs216").src;

    value20Save216 = "zSqrArtSpecz216";

    localStorage.setItem(value20Save216, sQz216);
};

function square217(){

    var sQz217 = document.getElementById("imgSqrs217").src;

    value20Save217 = "zSqrArtSpecz217";

    localStorage.setItem(value20Save217, sQz217);
};

function square218(){

    var sQz218 = document.getElementById("imgSqrs218").src;

    value20Save218 = "zSqrArtSpecz218";

    localStorage.setItem(value20Save218, sQz218);
};

function square219(){

    var sQz219 = document.getElementById("imgSqrs219").src;

    value20Save219 = "zSqrArtSpecz219";

    localStorage.setItem(value20Save219, sQz219);
};

function square220(){

    var sQz220 = document.getElementById("imgSqrs220").src;

    value20Save220 = "zSqrArtSpecz220";

    localStorage.setItem(value20Save220, sQz220);
};

function square221(){

    var sQz221 = document.getElementById("imgSqrs221").src;

    value20Save221 = "zSqrArtSpecz221";

    localStorage.setItem(value20Save221, sQz221);
};

function square222(){

    var sQz222 = document.getElementById("imgSqrs222").src;

    value20Save222 = "zSqrArtSpecz222";

    localStorage.setItem(value20Save222, sQz222);
};

function square223(){

    var sQz223 = document.getElementById("imgSqrs223").src;

    value20Save223 = "zSqrArtSpecz223";

    localStorage.setItem(value20Save223, sQz223);
};

function square224(){

    var sQz224 = document.getElementById("imgSqrs224").src;

    value20Save224 = "zSqrArtSpecz224";

    localStorage.setItem(value20Save224, sQz224);
};

function square225(){

    var sQz225 = document.getElementById("imgSqrs225").src;

    value20Save225 = "zSqrArtSpecz225";

    localStorage.setItem(value20Save225, sQz225);
};

function square226(){

    var sQz226 = document.getElementById("imgSqrs226").src;

    value20Save226 = "zSqrArtSpecz226";

    localStorage.setItem(value20Save226, sQz226);
};

function square227(){

    var sQz227 = document.getElementById("imgSqrs227").src;

    value20Save227 = "zSqrArtSpecz227";

    localStorage.setItem(value20Save227, sQz227);
};

function square228(){

    var sQz228 = document.getElementById("imgSqrs228").src;

    value20Save228 = "zSqrArtSpecz228";

    localStorage.setItem(value20Save228, sQz228);
};

function square229(){

    var sQz229 = document.getElementById("imgSqrs229").src;

    value20Save229 = "zSqrArtSpecz229";

    localStorage.setItem(value20Save229, sQz229);
};

function square230(){

    var sQz230 = document.getElementById("imgSqrs230").src;

    value20Save230 = "zSqrArtSpecz230";

    localStorage.setItem(value20Save230, sQz230);
};

function square231(){

    var sQz231 = document.getElementById("imgSqrs231").src;

    value20Save231 = "zSqrArtSpecz231";

    localStorage.setItem(value20Save231, sQz231);
};

function square232(){

    var sQz232 = document.getElementById("imgSqrs232").src;

    value20Save232 = "zSqrArtSpecz232";

    localStorage.setItem(value20Save232, sQz232);
};

function square233(){

    var sQz233 = document.getElementById("imgSqrs233").src;

    value20Save233 = "zSqrArtSpecz233";

    localStorage.setItem(value20Save233, sQz233);
};

function square234(){

    var sQz234 = document.getElementById("imgSqrs234").src;

    value20Save234 = "zSqrArtSpecz234";

    localStorage.setItem(value20Save234, sQz234);
};

function square235(){

    var sQz235 = document.getElementById("imgSqrs235").src;

    value20Save235 = "zSqrArtSpecz235";

    localStorage.setItem(value20Save235, sQz235);
};

function square236(){

    var sQz236 = document.getElementById("imgSqrs236").src;

    value20Save236 = "zSqrArtSpecz236";

    localStorage.setItem(value20Save236, sQz236);
};

function square237(){

    var sQz237 = document.getElementById("imgSqrs237").src;

    value20Save237 = "zSqrArtSpecz237";

    localStorage.setItem(value20Save237, sQz237);
};

function square238(){

    var sQz238 = document.getElementById("imgSqrs238").src;

    value20Save238 = "zSqrArtSpecz238";

    localStorage.setItem(value20Save238, sQz238);
};

function square239(){

    var sQz239 = document.getElementById("imgSqrs239").src;

    value20Save239 = "zSqrArtSpecz239";

    localStorage.setItem(value20Save239, sQz239);
};

function square240(){

    var sQz240 = document.getElementById("imgSqrs240").src;

    value20Save240 = "zSqrArtSpecz240";

    localStorage.setItem(value20Save240, sQz240);
};

function square241(){

    var sQz241 = document.getElementById("imgSqrs241").src;

    value20Save241 = "zSqrArtSpecz241";

    localStorage.setItem(value20Save241, sQz241);
};

function square242(){

    var sQz242 = document.getElementById("imgSqrs242").src;

    value20Save242 = "zSqrArtSpecz242";

    localStorage.setItem(value20Save242, sQz242);
};

function square243(){

    var sQz243 = document.getElementById("imgSqrs243").src;

    value20Save243 = "zSqrArtSpecz243";

    localStorage.setItem(value20Save243, sQz243);
};

function square244(){

    var sQz244 = document.getElementById("imgSqrs244").src;

    value20Save244 = "zSqrArtSpecz244";

    localStorage.setItem(value20Save244, sQz244);
};

function square245(){

    var sQz245 = document.getElementById("imgSqrs245").src;

    value20Save245 = "zSqrArtSpecz245";

    localStorage.setItem(value20Save245, sQz245);
};

function square246(){

    var sQz246 = document.getElementById("imgSqrs246").src;

    value20Save246 = "zSqrArtSpecz246";

    localStorage.setItem(value20Save246, sQz246);
};

function square247(){

    var sQz247 = document.getElementById("imgSqrs247").src;

    value20Save247 = "zSqrArtSpecz247";

    localStorage.setItem(value20Save247, sQz247);
};

function square248(){

    var sQz248 = document.getElementById("imgSqrs248").src;

    value20Save248 = "zSqrArtSpecz248";

    localStorage.setItem(value20Save248, sQz248);
};

function square249(){

    var sQz249 = document.getElementById("imgSqrs249").src;

    value20Save249 = "zSqrArtSpecz249";

    localStorage.setItem(value20Save249, sQz249);
};

function square250(){

    var sQz250 = document.getElementById("imgSqrs250").src;

    value20Save250 = "zSqrArtSpecz250";

    localStorage.setItem(value20Save250, sQz250);
};

function square251(){

    var sQz251 = document.getElementById("imgSqrs251").src;

    value20Save251 = "zSqrArtSpecz251";

    localStorage.setItem(value20Save251, sQz251);
};

function square252(){

    var sQz252 = document.getElementById("imgSqrs252").src;

    value20Save252 = "zSqrArtSpecz252";

    localStorage.setItem(value20Save252, sQz252);
};

function square253(){

    var sQz253 = document.getElementById("imgSqrs253").src;

    value20Save253 = "zSqrArtSpecz253";

    localStorage.setItem(value20Save253, sQz253);
};

function square254(){

    var sQz254 = document.getElementById("imgSqrs254").src;

    value20Save254 = "zSqrArtSpecz254";

    localStorage.setItem(value20Save254, sQz254);
};

function square255(){

    var sQz255 = document.getElementById("imgSqrs255").src;

    value20Save255 = "zSqrArtSpecz255";

    localStorage.setItem(value20Save255, sQz255);
};

function square256(){

    var sQz256 = document.getElementById("imgSqrs256").src;

    value20Save256 = "zSqrArtSpecz256";

    localStorage.setItem(value20Save256, sQz256);
};

function square257(){

    var sQz257 = document.getElementById("imgSqrs257").src;

    value20Save257 = "zSqrArtSpecz257";

    localStorage.setItem(value20Save257, sQz257);
};

function square258(){

    var sQz258 = document.getElementById("imgSqrs258").src;

    value20Save258 = "zSqrArtSpecz258";

    localStorage.setItem(value20Save258, sQz258);
};

function square259(){

    var sQz259 = document.getElementById("imgSqrs259").src;

    value20Save259 = "zSqrArtSpecz259";

    localStorage.setItem(value20Save259, sQz259);
};

function square260(){

    var sQz260 = document.getElementById("imgSqrs260").src;

    value20Save260 = "zSqrArtSpecz260";

    localStorage.setItem(value20Save260, sQz260);
};

function square261(){

    var sQz261 = document.getElementById("imgSqrs261").src;

    value20Save261 = "zSqrArtSpecz261";

    localStorage.setItem(value20Save261, sQz261);
};

function square262(){

    var sQz262 = document.getElementById("imgSqrs262").src;

    value20Save262 = "zSqrArtSpecz262";

    localStorage.setItem(value20Save262, sQz262);
};

function square263(){

    var sQz263 = document.getElementById("imgSqrs263").src;

    value20Save263 = "zSqrArtSpecz263";

    localStorage.setItem(value20Save263, sQz263);
};

function square264(){

    var sQz264 = document.getElementById("imgSqrs264").src;

    value20Save264 = "zSqrArtSpecz264";

    localStorage.setItem(value20Save264, sQz264);
};

function square265(){

    var sQz265 = document.getElementById("imgSqrs265").src;

    value20Save265 = "zSqrArtSpecz265";

    localStorage.setItem(value20Save265, sQz265);
};

function square266(){

    var sQz266 = document.getElementById("imgSqrs266").src;

    value20Save266 = "zSqrArtSpecz266";

    localStorage.setItem(value20Save266, sQz266);
};

function square267(){

    var sQz267 = document.getElementById("imgSqrs267").src;

    value20Save267 = "zSqrArtSpecz267";

    localStorage.setItem(value20Save267, sQz267);
};

function square268(){

    var sQz268 = document.getElementById("imgSqrs268").src;

    value20Save268 = "zSqrArtSpecz268";

    localStorage.setItem(value20Save268, sQz268);
};

function square269(){

    var sQz269 = document.getElementById("imgSqrs269").src;

    value20Save269 = "zSqrArtSpecz269";

    localStorage.setItem(value20Save269, sQz269);
};

function square270(){

    var sQz270 = document.getElementById("imgSqrs270").src;

    value20Save270 = "zSqrArtSpecz270";

    localStorage.setItem(value20Save270, sQz270);
};

function square271(){

    var sQz271 = document.getElementById("imgSqrs271").src;

    value20Save271 = "zSqrArtSpecz271";

    localStorage.setItem(value20Save271, sQz271);
};

function square272(){

    var sQz272 = document.getElementById("imgSqrs272").src;

    value20Save272 = "zSqrArtSpecz272";

    localStorage.setItem(value20Save272, sQz272);
};

function square273(){

    var sQz273 = document.getElementById("imgSqrs273").src;

    value20Save273 = "zSqrArtSpecz273";

    localStorage.setItem(value20Save273, sQz273);
};

function square274(){

    var sQz274 = document.getElementById("imgSqrs274").src;

    value20Save274 = "zSqrArtSpecz274";

    localStorage.setItem(value20Save274, sQz274);
};

function square275(){

    var sQz275 = document.getElementById("imgSqrs275").src;

    value20Save275 = "zSqrArtSpecz275";

    localStorage.setItem(value20Save275, sQz275);
};

function square276(){

    var sQz276 = document.getElementById("imgSqrs276").src;

    value20Save276 = "zSqrArtSpecz276";

    localStorage.setItem(value20Save276, sQz276);
};

function square277(){

    var sQz277 = document.getElementById("imgSqrs277").src;

    value20Save277 = "zSqrArtSpecz277";

    localStorage.setItem(value20Save277, sQz277);
};

function square278(){

    var sQz278 = document.getElementById("imgSqrs278").src;

    value20Save278 = "zSqrArtSpecz278";

    localStorage.setItem(value20Save278, sQz278);
};

function square279(){

    var sQz279 = document.getElementById("imgSqrs279").src;

    value20Save279 = "zSqrArtSpecz279";

    localStorage.setItem(value20Save279, sQz279);
};

function square280(){

    var sQz280 = document.getElementById("imgSqrs280").src;

    value20Save280 = "zSqrArtSpecz280";

    localStorage.setItem(value20Save280, sQz280);
};

function square281(){

    var sQz281 = document.getElementById("imgSqrs281").src;

    value20Save281 = "zSqrArtSpecz281";

    localStorage.setItem(value20Save281, sQz281);
};

function square282(){

    var sQz282 = document.getElementById("imgSqrs282").src;

    value20Save282 = "zSqrArtSpecz282";

    localStorage.setItem(value20Save282, sQz282);
};

function square283(){

    var sQz283 = document.getElementById("imgSqrs283").src;

    value20Save283 = "zSqrArtSpecz283";

    localStorage.setItem(value20Save283, sQz283);
};

function square284(){

    var sQz284 = document.getElementById("imgSqrs284").src;

    value20Save284 = "zSqrArtSpecz284";

    localStorage.setItem(value20Save284, sQz284);
};

function square285(){

    var sQz285 = document.getElementById("imgSqrs285").src;

    value20Save285 = "zSqrArtSpecz285";

    localStorage.setItem(value20Save285, sQz285);
};

function square286(){

    var sQz286 = document.getElementById("imgSqrs286").src;

    value20Save286 = "zSqrArtSpecz286";

    localStorage.setItem(value20Save286, sQz286);
};

function square287(){

    var sQz287 = document.getElementById("imgSqrs287").src;

    value20Save287 = "zSqrArtSpecz287";

    localStorage.setItem(value20Save287, sQz287);
};

function square288(){

    var sQz288 = document.getElementById("imgSqrs288").src;

    value20Save288 = "zSqrArtSpecz288";

    localStorage.setItem(value20Save288, sQz288);
};

function square289(){

    var sQz289 = document.getElementById("imgSqrs289").src;

    value20Save289 = "zSqrArtSpecz289";

    localStorage.setItem(value20Save289, sQz289);
};

function square290(){

    var sQz290 = document.getElementById("imgSqrs290").src;

    value20Save290 = "zSqrArtSpecz290";

    localStorage.setItem(value20Save290, sQz290);
};

function square291(){

    var sQz291 = document.getElementById("imgSqrs291").src;

    value20Save291 = "zSqrArtSpecz291";

    localStorage.setItem(value20Save291, sQz291);
};

function square292(){

    var sQz292 = document.getElementById("imgSqrs292").src;

    value20Save292 = "zSqrArtSpecz292";

    localStorage.setItem(value20Save292, sQz292);
};

function square293(){

    var sQz293 = document.getElementById("imgSqrs293").src;

    value20Save293 = "zSqrArtSpecz293";

    localStorage.setItem(value20Save293, sQz293);
};

function square294(){

    var sQz294 = document.getElementById("imgSqrs294").src;

    value20Save294 = "zSqrArtSpecz294";

    localStorage.setItem(value20Save294, sQz294);
};

function square295(){

    var sQz295 = document.getElementById("imgSqrs295").src;

    value20Save295 = "zSqrArtSpecz295";

    localStorage.setItem(value20Save295, sQz295);
};

function square296(){

    var sQz296 = document.getElementById("imgSqrs296").src;

    value20Save296 = "zSqrArtSpecz296";

    localStorage.setItem(value20Save296, sQz296);
};

function square297(){

    var sQz297 = document.getElementById("imgSqrs297").src;

    value20Save297 = "zSqrArtSpecz297";

    localStorage.setItem(value20Save297, sQz297);
};

function square298(){

    var sQz298 = document.getElementById("imgSqrs298").src;

    value20Save298 = "zSqrArtSpecz298";

    localStorage.setItem(value20Save298, sQz298);
};

function square299(){

    var sQz299 = document.getElementById("imgSqrs299").src;

    value20Save299 = "zSqrArtSpecz299";

    localStorage.setItem(value20Save299, sQz299);
};

function square300(){

    var sQz300 = document.getElementById("imgSqrs300").src;

    value20Save300 = "zSqrArtSpecz300";

    localStorage.setItem(value20Save300, sQz300);
};

function square301(){

    var sQz301 = document.getElementById("imgSqrs301").src;

    value20Save301 = "zSqrArtSpecz301";

    localStorage.setItem(value20Save301, sQz301);
};

function square302(){

    var sQz302 = document.getElementById("imgSqrs302").src;

    value20Save302 = "zSqrArtSpecz302";

    localStorage.setItem(value20Save302, sQz302);
};

function square303(){

    var sQz303 = document.getElementById("imgSqrs303").src;

    value20Save303 = "zSqrArtSpecz303";

    localStorage.setItem(value20Save303, sQz303);
};

function square304(){

    var sQz304 = document.getElementById("imgSqrs304").src;

    value20Save304 = "zSqrArtSpecz304";

    localStorage.setItem(value20Save304, sQz304);
};

function square305(){

    var sQz305 = document.getElementById("imgSqrs305").src;

    value20Save305 = "zSqrArtSpecz305";

    localStorage.setItem(value20Save305, sQz305);
};

function square306(){

    var sQz306 = document.getElementById("imgSqrs306").src;

    value20Save306 = "zSqrArtSpecz306";

    localStorage.setItem(value20Save306, sQz306);
};

function square307(){

    var sQz307 = document.getElementById("imgSqrs307").src;

    value20Save307 = "zSqrArtSpecz307";

    localStorage.setItem(value20Save307, sQz307);
};

function square308(){

    var sQz308 = document.getElementById("imgSqrs308").src;

    value20Save308 = "zSqrArtSpecz308";

    localStorage.setItem(value20Save308, sQz308);
};

function square309(){

    var sQz309 = document.getElementById("imgSqrs309").src;

    value20Save309 = "zSqrArtSpecz309";

    localStorage.setItem(value20Save309, sQz309);
};

function square310(){

    var sQz310 = document.getElementById("imgSqrs310").src;

    value20Save310 = "zSqrArtSpecz310";

    localStorage.setItem(value20Save310, sQz310);
};

function square311(){

    var sQz311 = document.getElementById("imgSqrs311").src;

    value20Save311 = "zSqrArtSpecz311";

    localStorage.setItem(value20Save311, sQz311);
};

function square312(){

    var sQz312 = document.getElementById("imgSqrs312").src;

    value20Save312 = "zSqrArtSpecz312";

    localStorage.setItem(value20Save312, sQz312);
};

function square313(){

    var sQz313 = document.getElementById("imgSqrs313").src;

    value20Save313 = "zSqrArtSpecz313";

    localStorage.setItem(value20Save313, sQz313);
};

function square314(){

    var sQz314 = document.getElementById("imgSqrs314").src;

    value20Save314 = "zSqrArtSpecz314";

    localStorage.setItem(value20Save314, sQz314);
};

function square315(){

    var sQz315 = document.getElementById("imgSqrs315").src;

    value20Save315 = "zSqrArtSpecz315";

    localStorage.setItem(value20Save315, sQz315);
};

function square316(){

    var sQz316 = document.getElementById("imgSqrs316").src;

    value20Save316 = "zSqrArtSpecz316";

    localStorage.setItem(value20Save316, sQz316);
};

function square317(){

    var sQz317 = document.getElementById("imgSqrs317").src;

    value20Save317 = "zSqrArtSpecz317";

    localStorage.setItem(value20Save317, sQz317);
};

function square318(){

    var sQz318 = document.getElementById("imgSqrs318").src;

    value20Save318 = "zSqrArtSpecz318";

    localStorage.setItem(value20Save318, sQz318);
};

function square319(){

    var sQz319 = document.getElementById("imgSqrs319").src;

    value20Save319 = "zSqrArtSpecz319";

    localStorage.setItem(value20Save319, sQz319);
};

function square320(){

    var sQz320 = document.getElementById("imgSqrs320").src;

    value20Save320 = "zSqrArtSpecz320";

    localStorage.setItem(value20Save320, sQz320);
};

function square321(){

    var sQz321 = document.getElementById("imgSqrs321").src;

    value20Save321 = "zSqrArtSpecz321";

    localStorage.setItem(value20Save321, sQz321);
};

function square322(){

    var sQz322 = document.getElementById("imgSqrs322").src;

    value20Save322 = "zSqrArtSpecz322";

    localStorage.setItem(value20Save322, sQz322);
};

function square323(){

    var sQz323 = document.getElementById("imgSqrs323").src;

    value20Save323 = "zSqrArtSpecz323";

    localStorage.setItem(value20Save323, sQz323);
};

function square324(){

    var sQz324 = document.getElementById("imgSqrs324").src;

    value20Save324 = "zSqrArtSpecz324";

    localStorage.setItem(value20Save324, sQz324);
};

function square325(){

    var sQz325 = document.getElementById("imgSqrs325").src;

    value20Save325 = "zSqrArtSpecz325";

    localStorage.setItem(value20Save325, sQz325);
};

function square326(){

    var sQz326 = document.getElementById("imgSqrs326").src;

    value20Save326 = "zSqrArtSpecz326";

    localStorage.setItem(value20Save326, sQz326);
};

function square327(){

    var sQz327 = document.getElementById("imgSqrs327").src;

    value20Save327 = "zSqrArtSpecz327";

    localStorage.setItem(value20Save327, sQz327);
};

function square328(){

    var sQz328 = document.getElementById("imgSqrs328").src;

    value20Save328 = "zSqrArtSpecz328";

    localStorage.setItem(value20Save328, sQz328);
};

function square329(){

    var sQz329 = document.getElementById("imgSqrs329").src;

    value20Save329 = "zSqrArtSpecz329";

    localStorage.setItem(value20Save329, sQz329);
};

function square330(){

    var sQz330 = document.getElementById("imgSqrs330").src;

    value20Save330 = "zSqrArtSpecz330";

    localStorage.setItem(value20Save330, sQz330);
};

function square331(){

    var sQz331 = document.getElementById("imgSqrs331").src;

    value20Save331 = "zSqrArtSpecz331";

    localStorage.setItem(value20Save331, sQz331);
};

function square332(){

    var sQz332 = document.getElementById("imgSqrs332").src;

    value20Save332 = "zSqrArtSpecz332";

    localStorage.setItem(value20Save332, sQz332);
};

function square333(){

    var sQz333 = document.getElementById("imgSqrs333").src;

    value20Save333 = "zSqrArtSpecz333";

    localStorage.setItem(value20Save333, sQz333);
};

function square334(){

    var sQz334 = document.getElementById("imgSqrs334").src;

    value20Save334 = "zSqrArtSpecz334";

    localStorage.setItem(value20Save334, sQz334);
};

function square335(){

    var sQz335 = document.getElementById("imgSqrs335").src;

    value20Save335 = "zSqrArtSpecz335";

    localStorage.setItem(value20Save335, sQz335);
};

function square336(){

    var sQz336 = document.getElementById("imgSqrs336").src;

    value20Save336 = "zSqrArtSpecz336";

    localStorage.setItem(value20Save336, sQz336);
};

function square337(){

    var sQz337 = document.getElementById("imgSqrs337").src;

    value20Save337 = "zSqrArtSpecz337";

    localStorage.setItem(value20Save337, sQz337);
};

function square338(){

    var sQz338 = document.getElementById("imgSqrs338").src;

    value20Save338 = "zSqrArtSpecz338";

    localStorage.setItem(value20Save338, sQz338);
};

function square339(){

    var sQz339 = document.getElementById("imgSqrs339").src;

    value20Save339 = "zSqrArtSpecz339";

    localStorage.setItem(value20Save339, sQz339);
};

function square340(){

    var sQz340 = document.getElementById("imgSqrs340").src;

    value20Save340 = "zSqrArtSpecz340";

    localStorage.setItem(value20Save340, sQz340);
};

function square341(){

    var sQz341 = document.getElementById("imgSqrs341").src;

    value20Save341 = "zSqrArtSpecz341";

    localStorage.setItem(value20Save341, sQz341);
};

function square342(){

    var sQz342 = document.getElementById("imgSqrs342").src;

    value20Save342 = "zSqrArtSpecz342";

    localStorage.setItem(value20Save342, sQz342);
};

function square343(){

    var sQz343 = document.getElementById("imgSqrs343").src;

    value20Save343 = "zSqrArtSpecz343";

    localStorage.setItem(value20Save343, sQz343);
};

function square344(){

    var sQz344 = document.getElementById("imgSqrs344").src;

    value20Save344 = "zSqrArtSpecz344";

    localStorage.setItem(value20Save344, sQz344);
};

function square345(){

    var sQz345 = document.getElementById("imgSqrs345").src;

    value20Save345 = "zSqrArtSpecz345";

    localStorage.setItem(value20Save345, sQz345);
};

function square346(){

    var sQz346 = document.getElementById("imgSqrs346").src;

    value20Save346 = "zSqrArtSpecz346";

    localStorage.setItem(value20Save346, sQz346);
};

function square347(){

    var sQz347 = document.getElementById("imgSqrs347").src;

    value20Save347 = "zSqrArtSpecz347";

    localStorage.setItem(value20Save347, sQz347);
};

function square348(){

    var sQz348 = document.getElementById("imgSqrs348").src;

    value20Save348 = "zSqrArtSpecz348";

    localStorage.setItem(value20Save348, sQz348);
};

function square349(){

    var sQz349 = document.getElementById("imgSqrs349").src;

    value20Save349 = "zSqrArtSpecz349";

    localStorage.setItem(value20Save349, sQz349);
};

function square350(){

    var sQz350 = document.getElementById("imgSqrs350").src;

    value20Save350 = "zSqrArtSpecz350";

    localStorage.setItem(value20Save350, sQz350);
};

function square351(){

    var sQz351 = document.getElementById("imgSqrs351").src;

    value20Save351 = "zSqrArtSpecz351";

    localStorage.setItem(value20Save351, sQz351);
};

function square352(){

    var sQz352 = document.getElementById("imgSqrs352").src;

    value20Save352 = "zSqrArtSpecz352";

    localStorage.setItem(value20Save352, sQz352);
};

function square353(){

    var sQz353 = document.getElementById("imgSqrs353").src;

    value20Save353 = "zSqrArtSpecz353";

    localStorage.setItem(value20Save353, sQz353);
};

function square354(){

    var sQz354 = document.getElementById("imgSqrs354").src;

    value20Save354 = "zSqrArtSpecz354";

    localStorage.setItem(value20Save354, sQz354);
};

function square355(){

    var sQz355 = document.getElementById("imgSqrs355").src;

    value20Save355 = "zSqrArtSpecz355";

    localStorage.setItem(value20Save355, sQz355);
};

function square356(){

    var sQz356 = document.getElementById("imgSqrs356").src;

    value20Save356 = "zSqrArtSpecz356";

    localStorage.setItem(value20Save356, sQz356);
};

function square357(){

    var sQz357 = document.getElementById("imgSqrs357").src;

    value20Save357 = "zSqrArtSpecz357";

    localStorage.setItem(value20Save357, sQz357);
};

function square358(){

    var sQz358 = document.getElementById("imgSqrs358").src;

    value20Save358 = "zSqrArtSpecz358";

    localStorage.setItem(value20Save358, sQz358);
};

function square359(){

    var sQz359 = document.getElementById("imgSqrs359").src;

    value20Save359 = "zSqrArtSpecz359";

    localStorage.setItem(value20Save359, sQz359);
};

function square360(){

    var sQz360 = document.getElementById("imgSqrs360").src;

    value20Save360 = "zSqrArtSpecz360";

    localStorage.setItem(value20Save360, sQz360);
};

function square361(){

    var sQz361 = document.getElementById("imgSqrs361").src;

    value20Save361 = "zSqrArtSpecz361";

    localStorage.setItem(value20Save361, sQz361);
};

function square362(){

    var sQz362 = document.getElementById("imgSqrs362").src;

    value20Save362 = "zSqrArtSpecz362";

    localStorage.setItem(value20Save362, sQz362);
};

function square363(){

    var sQz363 = document.getElementById("imgSqrs363").src;

    value20Save363 = "zSqrArtSpecz363";

    localStorage.setItem(value20Save363, sQz363);
};

function square364(){

    var sQz364 = document.getElementById("imgSqrs364").src;

    value20Save364 = "zSqrArtSpecz364";

    localStorage.setItem(value20Save364, sQz364);
};

function square365(){

    var sQz365 = document.getElementById("imgSqrs365").src;

    value20Save365 = "zSqrArtSpecz365";

    localStorage.setItem(value20Save365, sQz365);
};

function square366(){

    var sQz366 = document.getElementById("imgSqrs366").src;

    value20Save366 = "zSqrArtSpecz366";

    localStorage.setItem(value20Save366, sQz366);
};

function square367(){

    var sQz367 = document.getElementById("imgSqrs367").src;

    value20Save367 = "zSqrArtSpecz367";

    localStorage.setItem(value20Save367, sQz367);
};

function square368(){

    var sQz368 = document.getElementById("imgSqrs368").src;

    value20Save368 = "zSqrArtSpecz368";

    localStorage.setItem(value20Save368, sQz368);
};

function square369(){

    var sQz369 = document.getElementById("imgSqrs369").src;

    value20Save369 = "zSqrArtSpecz369";

    localStorage.setItem(value20Save369, sQz369);
};

function square370(){

    var sQz370 = document.getElementById("imgSqrs370").src;

    value20Save370 = "zSqrArtSpecz370";

    localStorage.setItem(value20Save370, sQz370);
};

function square371(){

    var sQz371 = document.getElementById("imgSqrs371").src;

    value20Save371 = "zSqrArtSpecz371";

    localStorage.setItem(value20Save371, sQz371);
};

function square372(){

    var sQz372 = document.getElementById("imgSqrs372").src;

    value20Save372 = "zSqrArtSpecz372";

    localStorage.setItem(value20Save372, sQz372);
};

function square373(){

    var sQz373 = document.getElementById("imgSqrs373").src;

    value20Save373 = "zSqrArtSpecz373";

    localStorage.setItem(value20Save373, sQz373);
};

function square374(){

    var sQz374 = document.getElementById("imgSqrs374").src;

    value20Save374 = "zSqrArtSpecz374";

    localStorage.setItem(value20Save374, sQz374);
};

function square375(){

    var sQz375 = document.getElementById("imgSqrs375").src;

    value20Save375 = "zSqrArtSpecz375";

    localStorage.setItem(value20Save375, sQz375);
};

function square376(){

    var sQz376 = document.getElementById("imgSqrs376").src;

    value20Save376 = "zSqrArtSpecz376";

    localStorage.setItem(value20Save376, sQz376);
};

function square377(){

    var sQz377 = document.getElementById("imgSqrs377").src;

    value20Save377 = "zSqrArtSpecz377";

    localStorage.setItem(value20Save377, sQz377);
};

function square378(){

    var sQz378 = document.getElementById("imgSqrs378").src;

    value20Save378 = "zSqrArtSpecz378";

    localStorage.setItem(value20Save378, sQz378);
};

function square379(){

    var sQz379 = document.getElementById("imgSqrs379").src;

    value20Save379 = "zSqrArtSpecz379";

    localStorage.setItem(value20Save379, sQz379);
};

function square380(){

    var sQz380 = document.getElementById("imgSqrs380").src;

    value20Save380 = "zSqrArtSpecz380";

    localStorage.setItem(value20Save380, sQz380);
};

function square381(){

    var sQz381 = document.getElementById("imgSqrs381").src;

    value20Save381 = "zSqrArtSpecz381";

    localStorage.setItem(value20Save381, sQz381);
};

function square382(){

    var sQz382 = document.getElementById("imgSqrs382").src;

    value20Save382 = "zSqrArtSpecz382";

    localStorage.setItem(value20Save382, sQz382);
};

function square383(){

    var sQz383 = document.getElementById("imgSqrs383").src;

    value20Save383 = "zSqrArtSpecz383";

    localStorage.setItem(value20Save383, sQz383);
};

function square384(){

    var sQz384 = document.getElementById("imgSqrs384").src;

    value20Save384 = "zSqrArtSpecz384";

    localStorage.setItem(value20Save384, sQz384);
};

function square385(){

    var sQz385 = document.getElementById("imgSqrs385").src;

    value20Save385 = "zSqrArtSpecz385";

    localStorage.setItem(value20Save385, sQz385);
};

function square386(){

    var sQz386 = document.getElementById("imgSqrs386").src;

    value20Save386 = "zSqrArtSpecz386";

    localStorage.setItem(value20Save386, sQz386);
};

function square387(){

    var sQz387 = document.getElementById("imgSqrs387").src;

    value20Save387 = "zSqrArtSpecz387";

    localStorage.setItem(value20Save387, sQz387);
};

function square388(){

    var sQz388 = document.getElementById("imgSqrs388").src;

    value20Save388 = "zSqrArtSpecz388";

    localStorage.setItem(value20Save388, sQz388);
};

function square389(){

    var sQz389 = document.getElementById("imgSqrs389").src;

    value20Save389 = "zSqrArtSpecz389";

    localStorage.setItem(value20Save389, sQz389);
};

function square390(){

    var sQz390 = document.getElementById("imgSqrs390").src;

    value20Save390 = "zSqrArtSpecz390";

    localStorage.setItem(value20Save390, sQz390);
};

function square391(){

    var sQz391 = document.getElementById("imgSqrs391").src;

    value20Save391 = "zSqrArtSpecz391";

    localStorage.setItem(value20Save391, sQz391);
};

function square392(){

    var sQz392 = document.getElementById("imgSqrs392").src;

    value20Save392 = "zSqrArtSpecz392";

    localStorage.setItem(value20Save392, sQz392);
};

function square393(){

    var sQz393 = document.getElementById("imgSqrs393").src;

    value20Save393 = "zSqrArtSpecz393";

    localStorage.setItem(value20Save393, sQz393);
};

function square394(){

    var sQz394 = document.getElementById("imgSqrs394").src;

    value20Save394 = "zSqrArtSpecz394";

    localStorage.setItem(value20Save394, sQz394);
};

function square395(){

    var sQz395 = document.getElementById("imgSqrs395").src;

    value20Save395 = "zSqrArtSpecz395";

    localStorage.setItem(value20Save395, sQz395);
};

function square396(){

    var sQz396 = document.getElementById("imgSqrs396").src;

    value20Save396 = "zSqrArtSpecz396";

    localStorage.setItem(value20Save396, sQz396);
};

function square397(){

    var sQz397 = document.getElementById("imgSqrs397").src;

    value20Save397 = "zSqrArtSpecz397";

    localStorage.setItem(value20Save397, sQz397);
};

function square398(){

    var sQz398 = document.getElementById("imgSqrs398").src;

    value20Save398 = "zSqrArtSpecz398";

    localStorage.setItem(value20Save398, sQz398);
};

function square399(){

    var sQz399 = document.getElementById("imgSqrs399").src;

    value20Save399 = "zSqrArtSpecz399";

    localStorage.setItem(value20Save399, sQz399);
};

function square400(){

    var sQz400 = document.getElementById("imgSqrs400").src;

    value20Save400 = "zSqrArtSpecz400";

    localStorage.setItem(value20Save400, sQz400);
};


function setAThis(){
    square1()

    square2()

    square3()

    square4()

    square5()

    square6()

    square7()

    square8()

    square9()

    square10()

    square11()

    square12()

    square13()

    square14()

    square15()

    square16()

    square17()

    square18()

    square19()

    square20()

    square21()

    square22()

    square23()

    square24()

    square25()

    square26()

    square27()

    square28()

    square29()

    square30()

    square31()

    square32()

    square33()

    square34()

    square35()

    square36()

    square37()

    square38()

    square39()

    square40()

    square41()

    square42()

    square43()

    square44()

    square45()

    square46()

    square47()

    square48()

    square49()

    square50()

    square51()

    square52()

    square53()

    square54()

    square55()

    square56()

    square57()

    square58()

    square59()

    square60()

    square61()

    square62()

    square63()

    square64()

    square65()

    square66()

    square67()

    square68()

    square69()

    square70()

    square71()

    square72()

    square73()

    square74()

    square75()

    square76()

    square77()

    square78()

    square79()

    square80()

    square81()

    square82()

    square83()

    square84()

    square85()

    square86()

    square87()

    square88()

    square89()

    square90()

    square91()

    square92()

    square93()

    square94()

    square95()

    square96()

    square97()

    square98()

    square99()

    square100()

    square101()

    square102()

    square103()

    square104()

    square105()

    square106()

    square107()

    square108()

    square109()

    square110()

    square111()

    square112()

    square113()

    square114()

    square115()

    square116()

    square117()

    square118()

    square119()

    square120()

    square121()

    square122()

    square123()

    square124()

    square125()

    square126()

    square127()

    square128()

    square129()

    square130()

    square131()

    square132()

    square133()

    square134()

    square135()

    square136()

    square137()

    square138()

    square139()

    square140()

    square141()

    square142()

    square143()

    square144()

    square145()

    square146()

    square147()

    square148()

    square149()

    square150()

    square151()

    square152()

    square153()

    square154()

    square155()

    square156()

    square157()

    square158()

    square159()

    square160()

    square161()

    square162()

    square163()

    square164()

    square165()

    square166()

    square167()

    square168()

    square169()

    square170()

    square171()

    square172()

    square173()

    square174()

    square175()

    square176()

    square177()

    square178()

    square179()

    square180()

    square181()

    square182()

    square183()

    square184()

    square185()

    square186()

    square187()

    square188()

    square189()

    square190()

    square191()

    square192()

    square193()

    square194()

    square195()

    square196()

    square197()

    square198()

    square199()

    square200()

    square201()

    square202()

    square203()

    square204()

    square205()

    square206()

    square207()

    square208()

    square209()

    square210()

    square211()

    square212()

    square213()

    square214()

    square215()

    square216()

    square217()

    square218()

    square219()

    square220()

    square221()

    square222()

    square223()

    square224()

    square225()

    square226()

    square227()

    square228()

    square229()

    square230()

    square231()

    square232()

    square233()

    square234()

    square235()

    square236()

    square237()

    square238()

    square239()

    square240()

    square241()

    square242()

    square243()

    square244()

    square245()

    square246()

    square247()

    square248()

    square249()

    square250()

    square251()

    square252()

    square253()

    square254()

    square255()

    square256()

    square257()

    square258()

    square259()

    square260()

    square261()

    square262()

    square263()

    square264()

    square265()

    square266()

    square267()

    square268()

    square269()

    square270()

    square271()

    square272()

    square273()

    square274()

    square275()

    square276()

    square277()

    square278()

    square279()

    square280()

    square281()

    square282()

    square283()

    square284()

    square285()

    square286()

    square287()

    square288()

    square289()

    square290()

    square291()

    square292()

    square293()

    square294()

    square295()

    square296()

    square297()

    square298()

    square299()

    square300()

    square301()

    square302()

    square303()

    square304()

    square305()

    square306()

    square307()

    square308()

    square309()

    square310()

    square311()

    square312()

    square313()

    square314()

    square315()

    square316()

    square317()

    square318()

    square319()

    square320()

    square321()

    square322()

    square323()

    square324()

    square325()

    square326()

    square327()

    square328()

    square329()

    square330()

    square331()

    square332()

    square333()

    square334()

    square335()

    square336()

    square337()

    square338()

    square339()

    square340()

    square341()

    square342()

    square343()

    square344()

    square345()

    square346()

    square347()

    square348()

    square349()

    square350()

    square351()

    square352()

    square353()

    square354()

    square355()

    square356()

    square357()

    square358()

    square359()

    square360()

    square361()

    square362()

    square363()

    square364()

    square365()

    square366()

    square367()

    square368()

    square369()

    square370()

    square371()

    square372()

    square373()

    square374()

    square375()

    square376()

    square377()

    square378()

    square379()

    square380()

    square381()

    square382()

    square383()

    square384()

    square385()

    square386()

    square387()

    square388()

    square389()

    square390()

    square391()

    square392()

    square393()

    square394()

    square395()

    square396()

    square397()

    square398()

    square399()

    square400()

    alert("Your art has been saved locally, to your local browser storage.");
};

function squareToSzzZValue1(){
    value20Save = "zSqrArtSpecz1";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs1").src = tripleZeroA;
};

function squareToSzzZValue2(){
    value20Save = "zSqrArtSpecz2";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs2").src = tripleZeroA;
};

function squareToSzzZValue3(){
    value20Save = "zSqrArtSpecz3";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs3").src = tripleZeroA;
};

function squareToSzzZValue4(){
    value20Save = "zSqrArtSpecz4";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs4").src = tripleZeroA;
};

function squareToSzzZValue5(){
    value20Save = "zSqrArtSpecz5";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs5").src = tripleZeroA;
};

function squareToSzzZValue6(){
    value20Save = "zSqrArtSpecz6";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs6").src = tripleZeroA;
};

function squareToSzzZValue7(){
    value20Save = "zSqrArtSpecz7";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs7").src = tripleZeroA;
};

function squareToSzzZValue8(){
    value20Save = "zSqrArtSpecz8";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs8").src = tripleZeroA;
};

function squareToSzzZValue9(){
    value20Save = "zSqrArtSpecz9";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs9").src = tripleZeroA;
};

function squareToSzzZValue10(){
    value20Save = "zSqrArtSpecz10";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs10").src = tripleZeroA;
};

function squareToSzzZValue11(){
    value20Save = "zSqrArtSpecz11";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs11").src = tripleZeroA;
};

function squareToSzzZValue12(){
    value20Save = "zSqrArtSpecz12";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs12").src = tripleZeroA;
};

function squareToSzzZValue13(){
    value20Save = "zSqrArtSpecz13";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs13").src = tripleZeroA;
};

function squareToSzzZValue14(){
    value20Save = "zSqrArtSpecz14";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs14").src = tripleZeroA;
};

function squareToSzzZValue15(){
    value20Save = "zSqrArtSpecz15";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs15").src = tripleZeroA;
};

function squareToSzzZValue16(){
    value20Save = "zSqrArtSpecz16";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs16").src = tripleZeroA;
};

function squareToSzzZValue17(){
    value20Save = "zSqrArtSpecz17";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs17").src = tripleZeroA;
};

function squareToSzzZValue18(){
    value20Save = "zSqrArtSpecz18";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs18").src = tripleZeroA;
};

function squareToSzzZValue19(){
    value20Save = "zSqrArtSpecz19";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs19").src = tripleZeroA;
};

function squareToSzzZValue20(){
    value20Save = "zSqrArtSpecz20";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs20").src = tripleZeroA;
};

function squareToSzzZValue21(){
    value20Save = "zSqrArtSpecz21";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs21").src = tripleZeroA;
};

function squareToSzzZValue22(){
    value20Save = "zSqrArtSpecz22";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs22").src = tripleZeroA;
};

function squareToSzzZValue23(){
    value20Save = "zSqrArtSpecz23";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs23").src = tripleZeroA;
};

function squareToSzzZValue24(){
    value20Save = "zSqrArtSpecz24";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs24").src = tripleZeroA;
};

function squareToSzzZValue25(){
    value20Save = "zSqrArtSpecz25";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs25").src = tripleZeroA;
};

function squareToSzzZValue26(){
    value20Save = "zSqrArtSpecz26";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs26").src = tripleZeroA;
};

function squareToSzzZValue27(){
    value20Save = "zSqrArtSpecz27";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs27").src = tripleZeroA;
};

function squareToSzzZValue28(){
    value20Save = "zSqrArtSpecz28";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs28").src = tripleZeroA;
};

function squareToSzzZValue29(){
    value20Save = "zSqrArtSpecz29";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs29").src = tripleZeroA;
};

function squareToSzzZValue30(){
    value20Save = "zSqrArtSpecz30";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs30").src = tripleZeroA;
};

function squareToSzzZValue31(){
    value20Save = "zSqrArtSpecz31";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs31").src = tripleZeroA;
};

function squareToSzzZValue32(){
    value20Save = "zSqrArtSpecz32";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs32").src = tripleZeroA;
};

function squareToSzzZValue33(){
    value20Save = "zSqrArtSpecz33";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs33").src = tripleZeroA;
};

function squareToSzzZValue34(){
    value20Save = "zSqrArtSpecz34";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs34").src = tripleZeroA;
};

function squareToSzzZValue35(){
    value20Save = "zSqrArtSpecz35";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs35").src = tripleZeroA;
};

function squareToSzzZValue36(){
    value20Save = "zSqrArtSpecz36";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs36").src = tripleZeroA;
};

function squareToSzzZValue37(){
    value20Save = "zSqrArtSpecz37";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs37").src = tripleZeroA;
};

function squareToSzzZValue38(){
    value20Save = "zSqrArtSpecz38";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs38").src = tripleZeroA;
};

function squareToSzzZValue39(){
    value20Save = "zSqrArtSpecz39";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs39").src = tripleZeroA;
};

function squareToSzzZValue40(){
    value20Save = "zSqrArtSpecz40";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs40").src = tripleZeroA;
};

function squareToSzzZValue41(){
    value20Save = "zSqrArtSpecz41";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs41").src = tripleZeroA;
};

function squareToSzzZValue42(){
    value20Save = "zSqrArtSpecz42";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs42").src = tripleZeroA;
};

function squareToSzzZValue43(){
    value20Save = "zSqrArtSpecz43";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs43").src = tripleZeroA;
};

function squareToSzzZValue44(){
    value20Save = "zSqrArtSpecz44";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs44").src = tripleZeroA;
};

function squareToSzzZValue45(){
    value20Save = "zSqrArtSpecz45";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs45").src = tripleZeroA;
};

function squareToSzzZValue46(){
    value20Save = "zSqrArtSpecz46";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs46").src = tripleZeroA;
};

function squareToSzzZValue47(){
    value20Save = "zSqrArtSpecz47";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs47").src = tripleZeroA;
};

function squareToSzzZValue48(){
    value20Save = "zSqrArtSpecz48";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs48").src = tripleZeroA;
};

function squareToSzzZValue49(){
    value20Save = "zSqrArtSpecz49";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs49").src = tripleZeroA;
};

function squareToSzzZValue50(){
    value20Save = "zSqrArtSpecz50";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs50").src = tripleZeroA;
};

function squareToSzzZValue51(){
    value20Save = "zSqrArtSpecz51";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs51").src = tripleZeroA;
};

function squareToSzzZValue52(){
    value20Save = "zSqrArtSpecz52";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs52").src = tripleZeroA;
};

function squareToSzzZValue53(){
    value20Save = "zSqrArtSpecz53";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs53").src = tripleZeroA;
};

function squareToSzzZValue54(){
    value20Save = "zSqrArtSpecz54";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs54").src = tripleZeroA;
};

function squareToSzzZValue55(){
    value20Save = "zSqrArtSpecz55";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs55").src = tripleZeroA;
};

function squareToSzzZValue56(){
    value20Save = "zSqrArtSpecz56";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs56").src = tripleZeroA;
};

function squareToSzzZValue57(){
    value20Save = "zSqrArtSpecz57";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs57").src = tripleZeroA;
};

function squareToSzzZValue58(){
    value20Save = "zSqrArtSpecz58";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs58").src = tripleZeroA;
};

function squareToSzzZValue59(){
    value20Save = "zSqrArtSpecz59";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs59").src = tripleZeroA;
};

function squareToSzzZValue60(){
    value20Save = "zSqrArtSpecz60";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs60").src = tripleZeroA;
};

function squareToSzzZValue61(){
    value20Save = "zSqrArtSpecz61";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs61").src = tripleZeroA;
};

function squareToSzzZValue62(){
    value20Save = "zSqrArtSpecz62";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs62").src = tripleZeroA;
};

function squareToSzzZValue63(){
    value20Save = "zSqrArtSpecz63";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs63").src = tripleZeroA;
};

function squareToSzzZValue64(){
    value20Save = "zSqrArtSpecz64";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs64").src = tripleZeroA;
};

function squareToSzzZValue65(){
    value20Save = "zSqrArtSpecz65";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs65").src = tripleZeroA;
};

function squareToSzzZValue66(){
    value20Save = "zSqrArtSpecz66";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs66").src = tripleZeroA;
};

function squareToSzzZValue67(){
    value20Save = "zSqrArtSpecz67";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs67").src = tripleZeroA;
};

function squareToSzzZValue68(){
    value20Save = "zSqrArtSpecz68";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs68").src = tripleZeroA;
};

function squareToSzzZValue69(){
    value20Save = "zSqrArtSpecz69";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs69").src = tripleZeroA;
};

function squareToSzzZValue70(){
    value20Save = "zSqrArtSpecz70";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs70").src = tripleZeroA;
};

function squareToSzzZValue71(){
    value20Save = "zSqrArtSpecz71";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs71").src = tripleZeroA;
};

function squareToSzzZValue72(){
    value20Save = "zSqrArtSpecz72";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs72").src = tripleZeroA;
};

function squareToSzzZValue73(){
    value20Save = "zSqrArtSpecz73";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs73").src = tripleZeroA;
};

function squareToSzzZValue74(){
    value20Save = "zSqrArtSpecz74";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs74").src = tripleZeroA;
};

function squareToSzzZValue75(){
    value20Save = "zSqrArtSpecz75";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs75").src = tripleZeroA;
};

function squareToSzzZValue76(){
    value20Save = "zSqrArtSpecz76";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs76").src = tripleZeroA;
};

function squareToSzzZValue77(){
    value20Save = "zSqrArtSpecz77";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs77").src = tripleZeroA;
};

function squareToSzzZValue78(){
    value20Save = "zSqrArtSpecz78";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs78").src = tripleZeroA;
};

function squareToSzzZValue79(){
    value20Save = "zSqrArtSpecz79";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs79").src = tripleZeroA;
};

function squareToSzzZValue80(){
    value20Save = "zSqrArtSpecz80";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs80").src = tripleZeroA;
};

function squareToSzzZValue81(){
    value20Save = "zSqrArtSpecz81";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs81").src = tripleZeroA;
};

function squareToSzzZValue82(){
    value20Save = "zSqrArtSpecz82";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs82").src = tripleZeroA;
};

function squareToSzzZValue83(){
    value20Save = "zSqrArtSpecz83";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs83").src = tripleZeroA;
};

function squareToSzzZValue84(){
    value20Save = "zSqrArtSpecz84";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs84").src = tripleZeroA;
};

function squareToSzzZValue85(){
    value20Save = "zSqrArtSpecz85";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs85").src = tripleZeroA;
};

function squareToSzzZValue86(){
    value20Save = "zSqrArtSpecz86";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs86").src = tripleZeroA;
};

function squareToSzzZValue87(){
    value20Save = "zSqrArtSpecz87";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs87").src = tripleZeroA;
};

function squareToSzzZValue88(){
    value20Save = "zSqrArtSpecz88";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs88").src = tripleZeroA;
};

function squareToSzzZValue89(){
    value20Save = "zSqrArtSpecz89";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs89").src = tripleZeroA;
};

function squareToSzzZValue90(){
    value20Save = "zSqrArtSpecz90";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs90").src = tripleZeroA;
};

function squareToSzzZValue91(){
    value20Save = "zSqrArtSpecz91";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs91").src = tripleZeroA;
};

function squareToSzzZValue92(){
    value20Save = "zSqrArtSpecz92";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs92").src = tripleZeroA;
};

function squareToSzzZValue93(){
    value20Save = "zSqrArtSpecz93";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs93").src = tripleZeroA;
};

function squareToSzzZValue94(){
    value20Save = "zSqrArtSpecz94";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs94").src = tripleZeroA;
};

function squareToSzzZValue95(){
    value20Save = "zSqrArtSpecz95";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs95").src = tripleZeroA;
};

function squareToSzzZValue96(){
    value20Save = "zSqrArtSpecz96";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs96").src = tripleZeroA;
};

function squareToSzzZValue97(){
    value20Save = "zSqrArtSpecz97";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs97").src = tripleZeroA;
};

function squareToSzzZValue98(){
    value20Save = "zSqrArtSpecz98";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs98").src = tripleZeroA;
};

function squareToSzzZValue99(){
    value20Save = "zSqrArtSpecz99";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs99").src = tripleZeroA;
};

function squareToSzzZValue100(){
    value20Save = "zSqrArtSpecz100";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs100").src = tripleZeroA;
};

function squareToSzzZValue101(){
    value20Save = "zSqrArtSpecz101";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs101").src = tripleZeroA;
};

function squareToSzzZValue102(){
    value20Save = "zSqrArtSpecz102";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs102").src = tripleZeroA;
};

function squareToSzzZValue103(){
    value20Save = "zSqrArtSpecz103";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs103").src = tripleZeroA;
};

function squareToSzzZValue104(){
    value20Save = "zSqrArtSpecz104";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs104").src = tripleZeroA;
};

function squareToSzzZValue105(){
    value20Save = "zSqrArtSpecz105";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs105").src = tripleZeroA;
};

function squareToSzzZValue106(){
    value20Save = "zSqrArtSpecz106";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs106").src = tripleZeroA;
};

function squareToSzzZValue107(){
    value20Save = "zSqrArtSpecz107";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs107").src = tripleZeroA;
};

function squareToSzzZValue108(){
    value20Save = "zSqrArtSpecz108";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs108").src = tripleZeroA;
};

function squareToSzzZValue109(){
    value20Save = "zSqrArtSpecz109";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs109").src = tripleZeroA;
};

function squareToSzzZValue110(){
    value20Save = "zSqrArtSpecz110";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs110").src = tripleZeroA;
};

function squareToSzzZValue111(){
    value20Save = "zSqrArtSpecz111";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs111").src = tripleZeroA;
};

function squareToSzzZValue112(){
    value20Save = "zSqrArtSpecz112";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs112").src = tripleZeroA;
};

function squareToSzzZValue113(){
    value20Save = "zSqrArtSpecz113";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs113").src = tripleZeroA;
};

function squareToSzzZValue114(){
    value20Save = "zSqrArtSpecz114";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs114").src = tripleZeroA;
};

function squareToSzzZValue115(){
    value20Save = "zSqrArtSpecz115";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs115").src = tripleZeroA;
};

function squareToSzzZValue116(){
    value20Save = "zSqrArtSpecz116";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs116").src = tripleZeroA;
};

function squareToSzzZValue117(){
    value20Save = "zSqrArtSpecz117";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs117").src = tripleZeroA;
};

function squareToSzzZValue118(){
    value20Save = "zSqrArtSpecz118";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs118").src = tripleZeroA;
};

function squareToSzzZValue119(){
    value20Save = "zSqrArtSpecz119";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs119").src = tripleZeroA;
};

function squareToSzzZValue120(){
    value20Save = "zSqrArtSpecz120";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs120").src = tripleZeroA;
};

function squareToSzzZValue121(){
    value20Save = "zSqrArtSpecz121";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs121").src = tripleZeroA;
};

function squareToSzzZValue122(){
    value20Save = "zSqrArtSpecz122";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs122").src = tripleZeroA;
};

function squareToSzzZValue123(){
    value20Save = "zSqrArtSpecz123";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs123").src = tripleZeroA;
};

function squareToSzzZValue124(){
    value20Save = "zSqrArtSpecz124";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs124").src = tripleZeroA;
};

function squareToSzzZValue125(){
    value20Save = "zSqrArtSpecz125";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs125").src = tripleZeroA;
};

function squareToSzzZValue126(){
    value20Save = "zSqrArtSpecz126";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs126").src = tripleZeroA;
};

function squareToSzzZValue127(){
    value20Save = "zSqrArtSpecz127";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs127").src = tripleZeroA;
};

function squareToSzzZValue128(){
    value20Save = "zSqrArtSpecz128";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs128").src = tripleZeroA;
};

function squareToSzzZValue129(){
    value20Save = "zSqrArtSpecz129";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs129").src = tripleZeroA;
};

function squareToSzzZValue130(){
    value20Save = "zSqrArtSpecz130";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs130").src = tripleZeroA;
};

function squareToSzzZValue131(){
    value20Save = "zSqrArtSpecz131";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs131").src = tripleZeroA;
};

function squareToSzzZValue132(){
    value20Save = "zSqrArtSpecz132";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs132").src = tripleZeroA;
};

function squareToSzzZValue133(){
    value20Save = "zSqrArtSpecz133";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs133").src = tripleZeroA;
};

function squareToSzzZValue134(){
    value20Save = "zSqrArtSpecz134";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs134").src = tripleZeroA;
};

function squareToSzzZValue135(){
    value20Save = "zSqrArtSpecz135";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs135").src = tripleZeroA;
};

function squareToSzzZValue136(){
    value20Save = "zSqrArtSpecz136";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs136").src = tripleZeroA;
};

function squareToSzzZValue137(){
    value20Save = "zSqrArtSpecz137";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs137").src = tripleZeroA;
};

function squareToSzzZValue138(){
    value20Save = "zSqrArtSpecz138";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs138").src = tripleZeroA;
};

function squareToSzzZValue139(){
    value20Save = "zSqrArtSpecz139";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs139").src = tripleZeroA;
};

function squareToSzzZValue140(){
    value20Save = "zSqrArtSpecz140";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs140").src = tripleZeroA;
};

function squareToSzzZValue141(){
    value20Save = "zSqrArtSpecz141";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs141").src = tripleZeroA;
};

function squareToSzzZValue142(){
    value20Save = "zSqrArtSpecz142";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs142").src = tripleZeroA;
};

function squareToSzzZValue143(){
    value20Save = "zSqrArtSpecz143";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs143").src = tripleZeroA;
};

function squareToSzzZValue144(){
    value20Save = "zSqrArtSpecz144";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs144").src = tripleZeroA;
};

function squareToSzzZValue145(){
    value20Save = "zSqrArtSpecz145";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs145").src = tripleZeroA;
};

function squareToSzzZValue146(){
    value20Save = "zSqrArtSpecz146";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs146").src = tripleZeroA;
};

function squareToSzzZValue147(){
    value20Save = "zSqrArtSpecz147";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs147").src = tripleZeroA;
};

function squareToSzzZValue148(){
    value20Save = "zSqrArtSpecz148";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs148").src = tripleZeroA;
};

function squareToSzzZValue149(){
    value20Save = "zSqrArtSpecz149";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs149").src = tripleZeroA;
};

function squareToSzzZValue150(){
    value20Save = "zSqrArtSpecz150";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs150").src = tripleZeroA;
};

function squareToSzzZValue151(){
    value20Save = "zSqrArtSpecz151";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs151").src = tripleZeroA;
};

function squareToSzzZValue152(){
    value20Save = "zSqrArtSpecz152";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs152").src = tripleZeroA;
};

function squareToSzzZValue153(){
    value20Save = "zSqrArtSpecz153";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs153").src = tripleZeroA;
};

function squareToSzzZValue154(){
    value20Save = "zSqrArtSpecz154";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs154").src = tripleZeroA;
};

function squareToSzzZValue155(){
    value20Save = "zSqrArtSpecz155";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs155").src = tripleZeroA;
};

function squareToSzzZValue156(){
    value20Save = "zSqrArtSpecz156";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs156").src = tripleZeroA;
};

function squareToSzzZValue157(){
    value20Save = "zSqrArtSpecz157";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs157").src = tripleZeroA;
};

function squareToSzzZValue158(){
    value20Save = "zSqrArtSpecz158";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs158").src = tripleZeroA;
};

function squareToSzzZValue159(){
    value20Save = "zSqrArtSpecz159";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs159").src = tripleZeroA;
};

function squareToSzzZValue160(){
    value20Save = "zSqrArtSpecz160";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs160").src = tripleZeroA;
};

function squareToSzzZValue161(){
    value20Save = "zSqrArtSpecz161";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs161").src = tripleZeroA;
};

function squareToSzzZValue162(){
    value20Save = "zSqrArtSpecz162";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs162").src = tripleZeroA;
};

function squareToSzzZValue163(){
    value20Save = "zSqrArtSpecz163";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs163").src = tripleZeroA;
};

function squareToSzzZValue164(){
    value20Save = "zSqrArtSpecz164";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs164").src = tripleZeroA;
};

function squareToSzzZValue165(){
    value20Save = "zSqrArtSpecz165";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs165").src = tripleZeroA;
};

function squareToSzzZValue166(){
    value20Save = "zSqrArtSpecz166";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs166").src = tripleZeroA;
};

function squareToSzzZValue167(){
    value20Save = "zSqrArtSpecz167";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs167").src = tripleZeroA;
};

function squareToSzzZValue168(){
    value20Save = "zSqrArtSpecz168";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs168").src = tripleZeroA;
};

function squareToSzzZValue169(){
    value20Save = "zSqrArtSpecz169";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs169").src = tripleZeroA;
};

function squareToSzzZValue170(){
    value20Save = "zSqrArtSpecz170";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs170").src = tripleZeroA;
};

function squareToSzzZValue171(){
    value20Save = "zSqrArtSpecz171";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs171").src = tripleZeroA;
};

function squareToSzzZValue172(){
    value20Save = "zSqrArtSpecz172";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs172").src = tripleZeroA;
};

function squareToSzzZValue173(){
    value20Save = "zSqrArtSpecz173";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs173").src = tripleZeroA;
};

function squareToSzzZValue174(){
    value20Save = "zSqrArtSpecz174";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs174").src = tripleZeroA;
};

function squareToSzzZValue175(){
    value20Save = "zSqrArtSpecz175";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs175").src = tripleZeroA;
};

function squareToSzzZValue176(){
    value20Save = "zSqrArtSpecz176";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs176").src = tripleZeroA;
};

function squareToSzzZValue177(){
    value20Save = "zSqrArtSpecz177";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs177").src = tripleZeroA;
};

function squareToSzzZValue178(){
    value20Save = "zSqrArtSpecz178";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs178").src = tripleZeroA;
};

function squareToSzzZValue179(){
    value20Save = "zSqrArtSpecz179";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs179").src = tripleZeroA;
};

function squareToSzzZValue180(){
    value20Save = "zSqrArtSpecz180";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs180").src = tripleZeroA;
};

function squareToSzzZValue181(){
    value20Save = "zSqrArtSpecz181";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs181").src = tripleZeroA;
};

function squareToSzzZValue182(){
    value20Save = "zSqrArtSpecz182";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs182").src = tripleZeroA;
};

function squareToSzzZValue183(){
    value20Save = "zSqrArtSpecz183";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs183").src = tripleZeroA;
};

function squareToSzzZValue184(){
    value20Save = "zSqrArtSpecz184";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs184").src = tripleZeroA;
};

function squareToSzzZValue185(){
    value20Save = "zSqrArtSpecz185";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs185").src = tripleZeroA;
};

function squareToSzzZValue186(){
    value20Save = "zSqrArtSpecz186";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs186").src = tripleZeroA;
};

function squareToSzzZValue187(){
    value20Save = "zSqrArtSpecz187";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs187").src = tripleZeroA;
};

function squareToSzzZValue188(){
    value20Save = "zSqrArtSpecz188";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs188").src = tripleZeroA;
};

function squareToSzzZValue189(){
    value20Save = "zSqrArtSpecz189";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs189").src = tripleZeroA;
};

function squareToSzzZValue190(){
    value20Save = "zSqrArtSpecz190";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs190").src = tripleZeroA;
};

function squareToSzzZValue191(){
    value20Save = "zSqrArtSpecz191";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs191").src = tripleZeroA;
};

function squareToSzzZValue192(){
    value20Save = "zSqrArtSpecz192";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs192").src = tripleZeroA;
};

function squareToSzzZValue193(){
    value20Save = "zSqrArtSpecz193";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs193").src = tripleZeroA;
};

function squareToSzzZValue194(){
    value20Save = "zSqrArtSpecz194";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs194").src = tripleZeroA;
};

function squareToSzzZValue195(){
    value20Save = "zSqrArtSpecz195";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs195").src = tripleZeroA;
};

function squareToSzzZValue196(){
    value20Save = "zSqrArtSpecz196";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs196").src = tripleZeroA;
};

function squareToSzzZValue197(){
    value20Save = "zSqrArtSpecz197";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs197").src = tripleZeroA;
};

function squareToSzzZValue198(){
    value20Save = "zSqrArtSpecz198";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs198").src = tripleZeroA;
};

function squareToSzzZValue199(){
    value20Save = "zSqrArtSpecz199";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs199").src = tripleZeroA;
};

function squareToSzzZValue200(){
    value20Save = "zSqrArtSpecz200";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs200").src = tripleZeroA;
};

function squareToSzzZValue201(){
    value20Save = "zSqrArtSpecz201";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs201").src = tripleZeroA;
};

function squareToSzzZValue202(){
    value20Save = "zSqrArtSpecz202";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs202").src = tripleZeroA;
};

function squareToSzzZValue203(){
    value20Save = "zSqrArtSpecz203";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs203").src = tripleZeroA;
};

function squareToSzzZValue204(){
    value20Save = "zSqrArtSpecz204";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs204").src = tripleZeroA;
};

function squareToSzzZValue205(){
    value20Save = "zSqrArtSpecz205";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs205").src = tripleZeroA;
};

function squareToSzzZValue206(){
    value20Save = "zSqrArtSpecz206";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs206").src = tripleZeroA;
};

function squareToSzzZValue207(){
    value20Save = "zSqrArtSpecz207";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs207").src = tripleZeroA;
};

function squareToSzzZValue208(){
    value20Save = "zSqrArtSpecz208";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs208").src = tripleZeroA;
};

function squareToSzzZValue209(){
    value20Save = "zSqrArtSpecz209";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs209").src = tripleZeroA;
};

function squareToSzzZValue210(){
    value20Save = "zSqrArtSpecz210";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs210").src = tripleZeroA;
};

function squareToSzzZValue211(){
    value20Save = "zSqrArtSpecz211";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs211").src = tripleZeroA;
};

function squareToSzzZValue212(){
    value20Save = "zSqrArtSpecz212";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs212").src = tripleZeroA;
};

function squareToSzzZValue213(){
    value20Save = "zSqrArtSpecz213";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs213").src = tripleZeroA;
};

function squareToSzzZValue214(){
    value20Save = "zSqrArtSpecz214";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs214").src = tripleZeroA;
};

function squareToSzzZValue215(){
    value20Save = "zSqrArtSpecz215";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs215").src = tripleZeroA;
};

function squareToSzzZValue216(){
    value20Save = "zSqrArtSpecz216";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs216").src = tripleZeroA;
};

function squareToSzzZValue217(){
    value20Save = "zSqrArtSpecz217";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs217").src = tripleZeroA;
};

function squareToSzzZValue218(){
    value20Save = "zSqrArtSpecz218";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs218").src = tripleZeroA;
};

function squareToSzzZValue219(){
    value20Save = "zSqrArtSpecz219";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs219").src = tripleZeroA;
};

function squareToSzzZValue220(){
    value20Save = "zSqrArtSpecz220";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs220").src = tripleZeroA;
};

function squareToSzzZValue221(){
    value20Save = "zSqrArtSpecz221";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs221").src = tripleZeroA;
};

function squareToSzzZValue222(){
    value20Save = "zSqrArtSpecz222";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs222").src = tripleZeroA;
};

function squareToSzzZValue223(){
    value20Save = "zSqrArtSpecz223";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs223").src = tripleZeroA;
};

function squareToSzzZValue224(){
    value20Save = "zSqrArtSpecz224";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs224").src = tripleZeroA;
};

function squareToSzzZValue225(){
    value20Save = "zSqrArtSpecz225";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs225").src = tripleZeroA;
};

function squareToSzzZValue226(){
    value20Save = "zSqrArtSpecz226";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs226").src = tripleZeroA;
};

function squareToSzzZValue227(){
    value20Save = "zSqrArtSpecz227";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs227").src = tripleZeroA;
};

function squareToSzzZValue228(){
    value20Save = "zSqrArtSpecz228";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs228").src = tripleZeroA;
};

function squareToSzzZValue229(){
    value20Save = "zSqrArtSpecz229";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs229").src = tripleZeroA;
};

function squareToSzzZValue230(){
    value20Save = "zSqrArtSpecz230";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs230").src = tripleZeroA;
};

function squareToSzzZValue231(){
    value20Save = "zSqrArtSpecz231";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs231").src = tripleZeroA;
};

function squareToSzzZValue232(){
    value20Save = "zSqrArtSpecz232";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs232").src = tripleZeroA;
};

function squareToSzzZValue233(){
    value20Save = "zSqrArtSpecz233";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs233").src = tripleZeroA;
};

function squareToSzzZValue234(){
    value20Save = "zSqrArtSpecz234";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs234").src = tripleZeroA;
};

function squareToSzzZValue235(){
    value20Save = "zSqrArtSpecz235";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs235").src = tripleZeroA;
};

function squareToSzzZValue236(){
    value20Save = "zSqrArtSpecz236";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs236").src = tripleZeroA;
};

function squareToSzzZValue237(){
    value20Save = "zSqrArtSpecz237";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs237").src = tripleZeroA;
};

function squareToSzzZValue238(){
    value20Save = "zSqrArtSpecz238";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs238").src = tripleZeroA;
};

function squareToSzzZValue239(){
    value20Save = "zSqrArtSpecz239";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs239").src = tripleZeroA;
};

function squareToSzzZValue240(){
    value20Save = "zSqrArtSpecz240";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs240").src = tripleZeroA;
};

function squareToSzzZValue241(){
    value20Save = "zSqrArtSpecz241";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs241").src = tripleZeroA;
};

function squareToSzzZValue242(){
    value20Save = "zSqrArtSpecz242";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs242").src = tripleZeroA;
};

function squareToSzzZValue243(){
    value20Save = "zSqrArtSpecz243";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs243").src = tripleZeroA;
};

function squareToSzzZValue244(){
    value20Save = "zSqrArtSpecz244";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs244").src = tripleZeroA;
};

function squareToSzzZValue245(){
    value20Save = "zSqrArtSpecz245";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs245").src = tripleZeroA;
};

function squareToSzzZValue246(){
    value20Save = "zSqrArtSpecz246";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs246").src = tripleZeroA;
};

function squareToSzzZValue247(){
    value20Save = "zSqrArtSpecz247";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs247").src = tripleZeroA;
};

function squareToSzzZValue248(){
    value20Save = "zSqrArtSpecz248";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs248").src = tripleZeroA;
};

function squareToSzzZValue249(){
    value20Save = "zSqrArtSpecz249";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs249").src = tripleZeroA;
};

function squareToSzzZValue250(){
    value20Save = "zSqrArtSpecz250";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs250").src = tripleZeroA;
};

function squareToSzzZValue251(){
    value20Save = "zSqrArtSpecz251";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs251").src = tripleZeroA;
};

function squareToSzzZValue252(){
    value20Save = "zSqrArtSpecz252";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs252").src = tripleZeroA;
};

function squareToSzzZValue253(){
    value20Save = "zSqrArtSpecz253";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs253").src = tripleZeroA;
};

function squareToSzzZValue254(){
    value20Save = "zSqrArtSpecz254";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs254").src = tripleZeroA;
};

function squareToSzzZValue255(){
    value20Save = "zSqrArtSpecz255";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs255").src = tripleZeroA;
};

function squareToSzzZValue256(){
    value20Save = "zSqrArtSpecz256";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs256").src = tripleZeroA;
};

function squareToSzzZValue257(){
    value20Save = "zSqrArtSpecz257";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs257").src = tripleZeroA;
};

function squareToSzzZValue258(){
    value20Save = "zSqrArtSpecz258";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs258").src = tripleZeroA;
};

function squareToSzzZValue259(){
    value20Save = "zSqrArtSpecz259";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs259").src = tripleZeroA;
};

function squareToSzzZValue260(){
    value20Save = "zSqrArtSpecz260";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs260").src = tripleZeroA;
};

function squareToSzzZValue261(){
    value20Save = "zSqrArtSpecz261";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs261").src = tripleZeroA;
};

function squareToSzzZValue262(){
    value20Save = "zSqrArtSpecz262";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs262").src = tripleZeroA;
};

function squareToSzzZValue263(){
    value20Save = "zSqrArtSpecz263";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs263").src = tripleZeroA;
};

function squareToSzzZValue264(){
    value20Save = "zSqrArtSpecz264";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs264").src = tripleZeroA;
};

function squareToSzzZValue265(){
    value20Save = "zSqrArtSpecz265";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs265").src = tripleZeroA;
};

function squareToSzzZValue266(){
    value20Save = "zSqrArtSpecz266";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs266").src = tripleZeroA;
};

function squareToSzzZValue267(){
    value20Save = "zSqrArtSpecz267";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs267").src = tripleZeroA;
};

function squareToSzzZValue268(){
    value20Save = "zSqrArtSpecz268";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs268").src = tripleZeroA;
};

function squareToSzzZValue269(){
    value20Save = "zSqrArtSpecz269";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs269").src = tripleZeroA;
};

function squareToSzzZValue270(){
    value20Save = "zSqrArtSpecz270";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs270").src = tripleZeroA;
};

function squareToSzzZValue271(){
    value20Save = "zSqrArtSpecz271";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs271").src = tripleZeroA;
};

function squareToSzzZValue272(){
    value20Save = "zSqrArtSpecz272";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs272").src = tripleZeroA;
};

function squareToSzzZValue273(){
    value20Save = "zSqrArtSpecz273";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs273").src = tripleZeroA;
};

function squareToSzzZValue274(){
    value20Save = "zSqrArtSpecz274";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs274").src = tripleZeroA;
};

function squareToSzzZValue275(){
    value20Save = "zSqrArtSpecz275";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs275").src = tripleZeroA;
};

function squareToSzzZValue276(){
    value20Save = "zSqrArtSpecz276";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs276").src = tripleZeroA;
};

function squareToSzzZValue277(){
    value20Save = "zSqrArtSpecz277";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs277").src = tripleZeroA;
};

function squareToSzzZValue278(){
    value20Save = "zSqrArtSpecz278";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs278").src = tripleZeroA;
};

function squareToSzzZValue279(){
    value20Save = "zSqrArtSpecz279";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs279").src = tripleZeroA;
};

function squareToSzzZValue280(){
    value20Save = "zSqrArtSpecz280";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs280").src = tripleZeroA;
};

function squareToSzzZValue281(){
    value20Save = "zSqrArtSpecz281";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs281").src = tripleZeroA;
};

function squareToSzzZValue282(){
    value20Save = "zSqrArtSpecz282";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs282").src = tripleZeroA;
};

function squareToSzzZValue283(){
    value20Save = "zSqrArtSpecz283";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs283").src = tripleZeroA;
};

function squareToSzzZValue284(){
    value20Save = "zSqrArtSpecz284";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs284").src = tripleZeroA;
};

function squareToSzzZValue285(){
    value20Save = "zSqrArtSpecz285";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs285").src = tripleZeroA;
};

function squareToSzzZValue286(){
    value20Save = "zSqrArtSpecz286";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs286").src = tripleZeroA;
};

function squareToSzzZValue287(){
    value20Save = "zSqrArtSpecz287";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs287").src = tripleZeroA;
};

function squareToSzzZValue288(){
    value20Save = "zSqrArtSpecz288";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs288").src = tripleZeroA;
};

function squareToSzzZValue289(){
    value20Save = "zSqrArtSpecz289";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs289").src = tripleZeroA;
};

function squareToSzzZValue290(){
    value20Save = "zSqrArtSpecz290";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs290").src = tripleZeroA;
};

function squareToSzzZValue291(){
    value20Save = "zSqrArtSpecz291";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs291").src = tripleZeroA;
};

function squareToSzzZValue292(){
    value20Save = "zSqrArtSpecz292";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs292").src = tripleZeroA;
};

function squareToSzzZValue293(){
    value20Save = "zSqrArtSpecz293";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs293").src = tripleZeroA;
};

function squareToSzzZValue294(){
    value20Save = "zSqrArtSpecz294";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs294").src = tripleZeroA;
};

function squareToSzzZValue295(){
    value20Save = "zSqrArtSpecz295";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs295").src = tripleZeroA;
};

function squareToSzzZValue296(){
    value20Save = "zSqrArtSpecz296";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs296").src = tripleZeroA;
};

function squareToSzzZValue297(){
    value20Save = "zSqrArtSpecz297";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs297").src = tripleZeroA;
};

function squareToSzzZValue298(){
    value20Save = "zSqrArtSpecz298";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs298").src = tripleZeroA;
};

function squareToSzzZValue299(){
    value20Save = "zSqrArtSpecz299";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs299").src = tripleZeroA;
};

function squareToSzzZValue300(){
    value20Save = "zSqrArtSpecz300";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs300").src = tripleZeroA;
};

function squareToSzzZValue301(){
    value20Save = "zSqrArtSpecz301";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs301").src = tripleZeroA;
};

function squareToSzzZValue302(){
    value20Save = "zSqrArtSpecz302";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs302").src = tripleZeroA;
};

function squareToSzzZValue303(){
    value20Save = "zSqrArtSpecz303";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs303").src = tripleZeroA;
};

function squareToSzzZValue304(){
    value20Save = "zSqrArtSpecz304";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs304").src = tripleZeroA;
};

function squareToSzzZValue305(){
    value20Save = "zSqrArtSpecz305";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs305").src = tripleZeroA;
};

function squareToSzzZValue306(){
    value20Save = "zSqrArtSpecz306";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs306").src = tripleZeroA;
};

function squareToSzzZValue307(){
    value20Save = "zSqrArtSpecz307";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs307").src = tripleZeroA;
};

function squareToSzzZValue308(){
    value20Save = "zSqrArtSpecz308";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs308").src = tripleZeroA;
};

function squareToSzzZValue309(){
    value20Save = "zSqrArtSpecz309";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs309").src = tripleZeroA;
};

function squareToSzzZValue310(){
    value20Save = "zSqrArtSpecz310";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs310").src = tripleZeroA;
};

function squareToSzzZValue311(){
    value20Save = "zSqrArtSpecz311";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs311").src = tripleZeroA;
};

function squareToSzzZValue312(){
    value20Save = "zSqrArtSpecz312";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs312").src = tripleZeroA;
};

function squareToSzzZValue313(){
    value20Save = "zSqrArtSpecz313";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs313").src = tripleZeroA;
};

function squareToSzzZValue314(){
    value20Save = "zSqrArtSpecz314";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs314").src = tripleZeroA;
};

function squareToSzzZValue315(){
    value20Save = "zSqrArtSpecz315";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs315").src = tripleZeroA;
};

function squareToSzzZValue316(){
    value20Save = "zSqrArtSpecz316";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs316").src = tripleZeroA;
};

function squareToSzzZValue317(){
    value20Save = "zSqrArtSpecz317";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs317").src = tripleZeroA;
};

function squareToSzzZValue318(){
    value20Save = "zSqrArtSpecz318";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs318").src = tripleZeroA;
};

function squareToSzzZValue319(){
    value20Save = "zSqrArtSpecz319";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs319").src = tripleZeroA;
};

function squareToSzzZValue320(){
    value20Save = "zSqrArtSpecz320";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs320").src = tripleZeroA;
};

function squareToSzzZValue321(){
    value20Save = "zSqrArtSpecz321";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs321").src = tripleZeroA;
};

function squareToSzzZValue322(){
    value20Save = "zSqrArtSpecz322";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs322").src = tripleZeroA;
};

function squareToSzzZValue323(){
    value20Save = "zSqrArtSpecz323";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs323").src = tripleZeroA;
};

function squareToSzzZValue324(){
    value20Save = "zSqrArtSpecz324";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs324").src = tripleZeroA;
};

function squareToSzzZValue325(){
    value20Save = "zSqrArtSpecz325";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs325").src = tripleZeroA;
};

function squareToSzzZValue326(){
    value20Save = "zSqrArtSpecz326";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs326").src = tripleZeroA;
};

function squareToSzzZValue327(){
    value20Save = "zSqrArtSpecz327";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs327").src = tripleZeroA;
};

function squareToSzzZValue328(){
    value20Save = "zSqrArtSpecz328";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs328").src = tripleZeroA;
};

function squareToSzzZValue329(){
    value20Save = "zSqrArtSpecz329";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs329").src = tripleZeroA;
};

function squareToSzzZValue330(){
    value20Save = "zSqrArtSpecz330";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs330").src = tripleZeroA;
};

function squareToSzzZValue331(){
    value20Save = "zSqrArtSpecz331";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs331").src = tripleZeroA;
};

function squareToSzzZValue332(){
    value20Save = "zSqrArtSpecz332";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs332").src = tripleZeroA;
};

function squareToSzzZValue333(){
    value20Save = "zSqrArtSpecz333";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs333").src = tripleZeroA;
};

function squareToSzzZValue334(){
    value20Save = "zSqrArtSpecz334";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs334").src = tripleZeroA;
};

function squareToSzzZValue335(){
    value20Save = "zSqrArtSpecz335";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs335").src = tripleZeroA;
};

function squareToSzzZValue336(){
    value20Save = "zSqrArtSpecz336";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs336").src = tripleZeroA;
};

function squareToSzzZValue337(){
    value20Save = "zSqrArtSpecz337";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs337").src = tripleZeroA;
};

function squareToSzzZValue338(){
    value20Save = "zSqrArtSpecz338";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs338").src = tripleZeroA;
};

function squareToSzzZValue339(){
    value20Save = "zSqrArtSpecz339";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs339").src = tripleZeroA;
};

function squareToSzzZValue340(){
    value20Save = "zSqrArtSpecz340";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs340").src = tripleZeroA;
};

function squareToSzzZValue341(){
    value20Save = "zSqrArtSpecz341";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs341").src = tripleZeroA;
};

function squareToSzzZValue342(){
    value20Save = "zSqrArtSpecz342";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs342").src = tripleZeroA;
};

function squareToSzzZValue343(){
    value20Save = "zSqrArtSpecz343";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs343").src = tripleZeroA;
};

function squareToSzzZValue344(){
    value20Save = "zSqrArtSpecz344";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs344").src = tripleZeroA;
};

function squareToSzzZValue345(){
    value20Save = "zSqrArtSpecz345";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs345").src = tripleZeroA;
};

function squareToSzzZValue346(){
    value20Save = "zSqrArtSpecz346";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs346").src = tripleZeroA;
};

function squareToSzzZValue347(){
    value20Save = "zSqrArtSpecz347";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs347").src = tripleZeroA;
};

function squareToSzzZValue348(){
    value20Save = "zSqrArtSpecz348";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs348").src = tripleZeroA;
};

function squareToSzzZValue349(){
    value20Save = "zSqrArtSpecz349";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs349").src = tripleZeroA;
};

function squareToSzzZValue350(){
    value20Save = "zSqrArtSpecz350";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs350").src = tripleZeroA;
};

function squareToSzzZValue351(){
    value20Save = "zSqrArtSpecz351";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs351").src = tripleZeroA;
};

function squareToSzzZValue352(){
    value20Save = "zSqrArtSpecz352";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs352").src = tripleZeroA;
};

function squareToSzzZValue353(){
    value20Save = "zSqrArtSpecz353";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs353").src = tripleZeroA;
};

function squareToSzzZValue354(){
    value20Save = "zSqrArtSpecz354";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs354").src = tripleZeroA;
};

function squareToSzzZValue355(){
    value20Save = "zSqrArtSpecz355";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs355").src = tripleZeroA;
};

function squareToSzzZValue356(){
    value20Save = "zSqrArtSpecz356";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs356").src = tripleZeroA;
};

function squareToSzzZValue357(){
    value20Save = "zSqrArtSpecz357";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs357").src = tripleZeroA;
};

function squareToSzzZValue358(){
    value20Save = "zSqrArtSpecz358";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs358").src = tripleZeroA;
};

function squareToSzzZValue359(){
    value20Save = "zSqrArtSpecz359";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs359").src = tripleZeroA;
};

function squareToSzzZValue360(){
    value20Save = "zSqrArtSpecz360";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs360").src = tripleZeroA;
};

function squareToSzzZValue361(){
    value20Save = "zSqrArtSpecz361";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs361").src = tripleZeroA;
};

function squareToSzzZValue362(){
    value20Save = "zSqrArtSpecz362";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs362").src = tripleZeroA;
};

function squareToSzzZValue363(){
    value20Save = "zSqrArtSpecz363";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs363").src = tripleZeroA;
};

function squareToSzzZValue364(){
    value20Save = "zSqrArtSpecz364";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs364").src = tripleZeroA;
};

function squareToSzzZValue365(){
    value20Save = "zSqrArtSpecz365";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs365").src = tripleZeroA;
};

function squareToSzzZValue366(){
    value20Save = "zSqrArtSpecz366";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs366").src = tripleZeroA;
};

function squareToSzzZValue367(){
    value20Save = "zSqrArtSpecz367";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs367").src = tripleZeroA;
};

function squareToSzzZValue368(){
    value20Save = "zSqrArtSpecz368";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs368").src = tripleZeroA;
};

function squareToSzzZValue369(){
    value20Save = "zSqrArtSpecz369";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs369").src = tripleZeroA;
};

function squareToSzzZValue370(){
    value20Save = "zSqrArtSpecz370";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs370").src = tripleZeroA;
};

function squareToSzzZValue371(){
    value20Save = "zSqrArtSpecz371";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs371").src = tripleZeroA;
};

function squareToSzzZValue372(){
    value20Save = "zSqrArtSpecz372";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs372").src = tripleZeroA;
};

function squareToSzzZValue373(){
    value20Save = "zSqrArtSpecz373";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs373").src = tripleZeroA;
};

function squareToSzzZValue374(){
    value20Save = "zSqrArtSpecz374";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs374").src = tripleZeroA;
};

function squareToSzzZValue375(){
    value20Save = "zSqrArtSpecz375";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs375").src = tripleZeroA;
};

function squareToSzzZValue376(){
    value20Save = "zSqrArtSpecz376";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs376").src = tripleZeroA;
};

function squareToSzzZValue377(){
    value20Save = "zSqrArtSpecz377";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs377").src = tripleZeroA;
};

function squareToSzzZValue378(){
    value20Save = "zSqrArtSpecz378";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs378").src = tripleZeroA;
};

function squareToSzzZValue379(){
    value20Save = "zSqrArtSpecz379";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs379").src = tripleZeroA;
};

function squareToSzzZValue380(){
    value20Save = "zSqrArtSpecz380";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs380").src = tripleZeroA;
};

function squareToSzzZValue381(){
    value20Save = "zSqrArtSpecz381";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs381").src = tripleZeroA;
};

function squareToSzzZValue382(){
    value20Save = "zSqrArtSpecz382";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs382").src = tripleZeroA;
};

function squareToSzzZValue383(){
    value20Save = "zSqrArtSpecz383";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs383").src = tripleZeroA;
};

function squareToSzzZValue384(){
    value20Save = "zSqrArtSpecz384";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs384").src = tripleZeroA;
};

function squareToSzzZValue385(){
    value20Save = "zSqrArtSpecz385";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs385").src = tripleZeroA;
};

function squareToSzzZValue386(){
    value20Save = "zSqrArtSpecz386";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs386").src = tripleZeroA;
};

function squareToSzzZValue387(){
    value20Save = "zSqrArtSpecz387";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs387").src = tripleZeroA;
};

function squareToSzzZValue388(){
    value20Save = "zSqrArtSpecz388";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs388").src = tripleZeroA;
};

function squareToSzzZValue389(){
    value20Save = "zSqrArtSpecz389";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs389").src = tripleZeroA;
};

function squareToSzzZValue390(){
    value20Save = "zSqrArtSpecz390";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs390").src = tripleZeroA;
};

function squareToSzzZValue391(){
    value20Save = "zSqrArtSpecz391";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs391").src = tripleZeroA;
};

function squareToSzzZValue392(){
    value20Save = "zSqrArtSpecz392";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs392").src = tripleZeroA;
};

function squareToSzzZValue393(){
    value20Save = "zSqrArtSpecz393";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs393").src = tripleZeroA;
};

function squareToSzzZValue394(){
    value20Save = "zSqrArtSpecz394";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs394").src = tripleZeroA;
};

function squareToSzzZValue395(){
    value20Save = "zSqrArtSpecz395";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs395").src = tripleZeroA;
};

function squareToSzzZValue396(){
    value20Save = "zSqrArtSpecz396";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs396").src = tripleZeroA;
};

function squareToSzzZValue397(){
    value20Save = "zSqrArtSpecz397";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs397").src = tripleZeroA;
};

function squareToSzzZValue398(){
    value20Save = "zSqrArtSpecz398";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs398").src = tripleZeroA;
};

function squareToSzzZValue399(){
    value20Save = "zSqrArtSpecz399";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs399").src = tripleZeroA;
};

function squareToSzzZValue400(){
    value20Save = "zSqrArtSpecz400";
    var tripleZeroA = localStorage.getItem(value20Save);
    document.getElementById("imgSqrs400").src = tripleZeroA;
};

function getBThis(){
    squareToSzzZValue1()

    squareToSzzZValue2()

    squareToSzzZValue3()

    squareToSzzZValue4()

    squareToSzzZValue5()

    squareToSzzZValue6()

    squareToSzzZValue7()

    squareToSzzZValue8()

    squareToSzzZValue9()

    squareToSzzZValue10()

    squareToSzzZValue11()

    squareToSzzZValue12()

    squareToSzzZValue13()

    squareToSzzZValue14()

    squareToSzzZValue15()

    squareToSzzZValue16()

    squareToSzzZValue17()

    squareToSzzZValue18()

    squareToSzzZValue19()

    squareToSzzZValue20()

    squareToSzzZValue21()

    squareToSzzZValue22()

    squareToSzzZValue23()

    squareToSzzZValue24()

    squareToSzzZValue25()

    squareToSzzZValue26()

    squareToSzzZValue27()

    squareToSzzZValue28()

    squareToSzzZValue29()

    squareToSzzZValue30()

    squareToSzzZValue31()

    squareToSzzZValue32()

    squareToSzzZValue33()

    squareToSzzZValue34()

    squareToSzzZValue35()

    squareToSzzZValue36()

    squareToSzzZValue37()

    squareToSzzZValue38()

    squareToSzzZValue39()

    squareToSzzZValue40()

    squareToSzzZValue41()

    squareToSzzZValue42()

    squareToSzzZValue43()

    squareToSzzZValue44()

    squareToSzzZValue45()

    squareToSzzZValue46()

    squareToSzzZValue47()

    squareToSzzZValue48()

    squareToSzzZValue49()

    squareToSzzZValue50()

    squareToSzzZValue51()

    squareToSzzZValue52()

    squareToSzzZValue53()

    squareToSzzZValue54()

    squareToSzzZValue55()

    squareToSzzZValue56()

    squareToSzzZValue57()

    squareToSzzZValue58()

    squareToSzzZValue59()

    squareToSzzZValue60()

    squareToSzzZValue61()

    squareToSzzZValue62()

    squareToSzzZValue63()

    squareToSzzZValue64()

    squareToSzzZValue65()

    squareToSzzZValue66()

    squareToSzzZValue67()

    squareToSzzZValue68()

    squareToSzzZValue69()

    squareToSzzZValue70()

    squareToSzzZValue71()

    squareToSzzZValue72()

    squareToSzzZValue73()

    squareToSzzZValue74()

    squareToSzzZValue75()

    squareToSzzZValue76()

    squareToSzzZValue77()

    squareToSzzZValue78()

    squareToSzzZValue79()

    squareToSzzZValue80()

    squareToSzzZValue81()

    squareToSzzZValue82()

    squareToSzzZValue83()

    squareToSzzZValue84()

    squareToSzzZValue85()

    squareToSzzZValue86()

    squareToSzzZValue87()

    squareToSzzZValue88()

    squareToSzzZValue89()

    squareToSzzZValue90()

    squareToSzzZValue91()

    squareToSzzZValue92()

    squareToSzzZValue93()

    squareToSzzZValue94()

    squareToSzzZValue95()

    squareToSzzZValue96()

    squareToSzzZValue97()

    squareToSzzZValue98()

    squareToSzzZValue99()

    squareToSzzZValue100()

    squareToSzzZValue101()

    squareToSzzZValue102()

    squareToSzzZValue103()

    squareToSzzZValue104()

    squareToSzzZValue105()

    squareToSzzZValue106()

    squareToSzzZValue107()

    squareToSzzZValue108()

    squareToSzzZValue109()

    squareToSzzZValue110()

    squareToSzzZValue111()

    squareToSzzZValue112()

    squareToSzzZValue113()

    squareToSzzZValue114()

    squareToSzzZValue115()

    squareToSzzZValue116()

    squareToSzzZValue117()

    squareToSzzZValue118()

    squareToSzzZValue119()

    squareToSzzZValue120()

    squareToSzzZValue121()

    squareToSzzZValue122()

    squareToSzzZValue123()

    squareToSzzZValue124()

    squareToSzzZValue125()

    squareToSzzZValue126()

    squareToSzzZValue127()

    squareToSzzZValue128()

    squareToSzzZValue129()

    squareToSzzZValue130()

    squareToSzzZValue131()

    squareToSzzZValue132()

    squareToSzzZValue133()

    squareToSzzZValue134()

    squareToSzzZValue135()

    squareToSzzZValue136()

    squareToSzzZValue137()

    squareToSzzZValue138()

    squareToSzzZValue139()

    squareToSzzZValue140()

    squareToSzzZValue141()

    squareToSzzZValue142()

    squareToSzzZValue143()

    squareToSzzZValue144()

    squareToSzzZValue145()

    squareToSzzZValue146()

    squareToSzzZValue147()

    squareToSzzZValue148()

    squareToSzzZValue149()

    squareToSzzZValue150()

    squareToSzzZValue151()

    squareToSzzZValue152()

    squareToSzzZValue153()

    squareToSzzZValue154()

    squareToSzzZValue155()

    squareToSzzZValue156()

    squareToSzzZValue157()

    squareToSzzZValue158()

    squareToSzzZValue159()

    squareToSzzZValue160()

    squareToSzzZValue161()

    squareToSzzZValue162()

    squareToSzzZValue163()

    squareToSzzZValue164()

    squareToSzzZValue165()

    squareToSzzZValue166()

    squareToSzzZValue167()

    squareToSzzZValue168()

    squareToSzzZValue169()

    squareToSzzZValue170()

    squareToSzzZValue171()

    squareToSzzZValue172()

    squareToSzzZValue173()

    squareToSzzZValue174()

    squareToSzzZValue175()

    squareToSzzZValue176()

    squareToSzzZValue177()

    squareToSzzZValue178()

    squareToSzzZValue179()

    squareToSzzZValue180()

    squareToSzzZValue181()

    squareToSzzZValue182()

    squareToSzzZValue183()

    squareToSzzZValue184()

    squareToSzzZValue185()

    squareToSzzZValue186()

    squareToSzzZValue187()

    squareToSzzZValue188()

    squareToSzzZValue189()

    squareToSzzZValue190()

    squareToSzzZValue191()

    squareToSzzZValue192()

    squareToSzzZValue193()

    squareToSzzZValue194()

    squareToSzzZValue195()

    squareToSzzZValue196()

    squareToSzzZValue197()

    squareToSzzZValue198()

    squareToSzzZValue199()

    squareToSzzZValue200()

    squareToSzzZValue201()

    squareToSzzZValue202()

    squareToSzzZValue203()

    squareToSzzZValue204()

    squareToSzzZValue205()

    squareToSzzZValue206()

    squareToSzzZValue207()

    squareToSzzZValue208()

    squareToSzzZValue209()

    squareToSzzZValue210()

    squareToSzzZValue211()

    squareToSzzZValue212()

    squareToSzzZValue213()

    squareToSzzZValue214()

    squareToSzzZValue215()

    squareToSzzZValue216()

    squareToSzzZValue217()

    squareToSzzZValue218()

    squareToSzzZValue219()

    squareToSzzZValue220()

    squareToSzzZValue221()

    squareToSzzZValue222()

    squareToSzzZValue223()

    squareToSzzZValue224()

    squareToSzzZValue225()

    squareToSzzZValue226()

    squareToSzzZValue227()

    squareToSzzZValue228()

    squareToSzzZValue229()

    squareToSzzZValue230()

    squareToSzzZValue231()

    squareToSzzZValue232()

    squareToSzzZValue233()

    squareToSzzZValue234()

    squareToSzzZValue235()

    squareToSzzZValue236()

    squareToSzzZValue237()

    squareToSzzZValue238()

    squareToSzzZValue239()

    squareToSzzZValue240()

    squareToSzzZValue241()

    squareToSzzZValue242()

    squareToSzzZValue243()

    squareToSzzZValue244()

    squareToSzzZValue245()

    squareToSzzZValue246()

    squareToSzzZValue247()

    squareToSzzZValue248()

    squareToSzzZValue249()

    squareToSzzZValue250()

    squareToSzzZValue251()

    squareToSzzZValue252()

    squareToSzzZValue253()

    squareToSzzZValue254()

    squareToSzzZValue255()

    squareToSzzZValue256()

    squareToSzzZValue257()

    squareToSzzZValue258()

    squareToSzzZValue259()

    squareToSzzZValue260()

    squareToSzzZValue261()

    squareToSzzZValue262()

    squareToSzzZValue263()

    squareToSzzZValue264()

    squareToSzzZValue265()

    squareToSzzZValue266()

    squareToSzzZValue267()

    squareToSzzZValue268()

    squareToSzzZValue269()

    squareToSzzZValue270()

    squareToSzzZValue271()

    squareToSzzZValue272()

    squareToSzzZValue273()

    squareToSzzZValue274()

    squareToSzzZValue275()

    squareToSzzZValue276()

    squareToSzzZValue277()

    squareToSzzZValue278()

    squareToSzzZValue279()

    squareToSzzZValue280()

    squareToSzzZValue281()

    squareToSzzZValue282()

    squareToSzzZValue283()

    squareToSzzZValue284()

    squareToSzzZValue285()

    squareToSzzZValue286()

    squareToSzzZValue287()

    squareToSzzZValue288()

    squareToSzzZValue289()

    squareToSzzZValue290()

    squareToSzzZValue291()

    squareToSzzZValue292()

    squareToSzzZValue293()

    squareToSzzZValue294()

    squareToSzzZValue295()

    squareToSzzZValue296()

    squareToSzzZValue297()

    squareToSzzZValue298()

    squareToSzzZValue299()

    squareToSzzZValue300()

    squareToSzzZValue301()

    squareToSzzZValue302()

    squareToSzzZValue303()

    squareToSzzZValue304()

    squareToSzzZValue305()

    squareToSzzZValue306()

    squareToSzzZValue307()

    squareToSzzZValue308()

    squareToSzzZValue309()

    squareToSzzZValue310()

    squareToSzzZValue311()

    squareToSzzZValue312()

    squareToSzzZValue313()

    squareToSzzZValue314()

    squareToSzzZValue315()

    squareToSzzZValue316()

    squareToSzzZValue317()

    squareToSzzZValue318()

    squareToSzzZValue319()

    squareToSzzZValue320()

    squareToSzzZValue321()

    squareToSzzZValue322()

    squareToSzzZValue323()

    squareToSzzZValue324()

    squareToSzzZValue325()

    squareToSzzZValue326()

    squareToSzzZValue327()

    squareToSzzZValue328()

    squareToSzzZValue329()

    squareToSzzZValue330()

    squareToSzzZValue331()

    squareToSzzZValue332()

    squareToSzzZValue333()

    squareToSzzZValue334()

    squareToSzzZValue335()

    squareToSzzZValue336()

    squareToSzzZValue337()

    squareToSzzZValue338()

    squareToSzzZValue339()

    squareToSzzZValue340()

    squareToSzzZValue341()

    squareToSzzZValue342()

    squareToSzzZValue343()

    squareToSzzZValue344()

    squareToSzzZValue345()

    squareToSzzZValue346()

    squareToSzzZValue347()

    squareToSzzZValue348()

    squareToSzzZValue349()

    squareToSzzZValue350()

    squareToSzzZValue351()

    squareToSzzZValue352()

    squareToSzzZValue353()

    squareToSzzZValue354()

    squareToSzzZValue355()

    squareToSzzZValue356()

    squareToSzzZValue357()

    squareToSzzZValue358()

    squareToSzzZValue359()

    squareToSzzZValue360()

    squareToSzzZValue361()

    squareToSzzZValue362()

    squareToSzzZValue363()

    squareToSzzZValue364()

    squareToSzzZValue365()

    squareToSzzZValue366()

    squareToSzzZValue367()

    squareToSzzZValue368()

    squareToSzzZValue369()

    squareToSzzZValue370()

    squareToSzzZValue371()

    squareToSzzZValue372()

    squareToSzzZValue373()

    squareToSzzZValue374()

    squareToSzzZValue375()

    squareToSzzZValue376()

    squareToSzzZValue377()

    squareToSzzZValue378()

    squareToSzzZValue379()

    squareToSzzZValue380()

    squareToSzzZValue381()

    squareToSzzZValue382()

    squareToSzzZValue383()

    squareToSzzZValue384()

    squareToSzzZValue385()

    squareToSzzZValue386()

    squareToSzzZValue387()

    squareToSzzZValue388()

    squareToSzzZValue389()

    squareToSzzZValue390()

    squareToSzzZValue391()

    squareToSzzZValue392()

    squareToSzzZValue393()

    squareToSzzZValue394()

    squareToSzzZValue395()

    squareToSzzZValue396()

    squareToSzzZValue397()

    squareToSzzZValue398()

    squareToSzzZValue399()

    squareToSzzZValue400()
    
    alert("Your art has been loaded successfully from your browser's local browser storage.");

};

function squareNull(){
    valueSave = 'zSqrArtSpecz0';
    var tripleZeroA = localStorage.getItem(valueSave);
    if(tripleZeroA == null){
        setAThis();
    }else{
        getBThis();
    };
};