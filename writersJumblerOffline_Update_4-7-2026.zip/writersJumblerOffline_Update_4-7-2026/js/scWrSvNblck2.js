function artsquare0(){
    var sBQz0 = document.getElementById("aImgSqr1").src;
    valueBSave0 = 'zSqrArtSpecz0';
    localStorage.setItem(valueBSave0, sBQz0);
};
function squareBToSzzZValue0(){
    valueBSave0 = 'zSqrArtSpecz0';
    var tripleBZeroA = localStorage.getItem(valueBSave0);
    document.getElementById("imgSqr1").src = tripleBZeroA;};

function artsquare1(){
    var sBQz1 = document.getElementById("aImgSqr2").src;
    valueBSave1 = 'zSqrArtSpecz1';
    localStorage.setItem(valueBSave1, sBQz1);
};
function squareBToSzzZValue1(){
    valueBSave1 = 'zSqrArtSpecz1';
    var tripleBZeroA = localStorage.getItem(valueBSave1);
    document.getElementById("imgSqr2").src = tripleBZeroA;};

function artsquare2(){
    var sBQz2 = document.getElementById("aImgSqr3").src;
    valueBSave2 = 'zSqrArtSpecz2';
    localStorage.setItem(valueBSave2, sBQz2);
};
function squareBToSzzZValue2(){
    valueBSave2 = 'zSqrArtSpecz2';
    var tripleBZeroA = localStorage.getItem(valueBSave2);
    document.getElementById("imgSqr3").src = tripleBZeroA;};

function artsquare3(){
    var sBQz3 = document.getElementById("aImgSqr4").src;
    valueBSave3 = 'zSqrArtSpecz3';
    localStorage.setItem(valueBSave3, sBQz3);
};
function squareBToSzzZValue3(){
    valueBSave3 = 'zSqrArtSpecz3';
    var tripleBZeroA = localStorage.getItem(valueBSave3);
    document.getElementById("imgSqr4").src = tripleBZeroA;};

function artsquare4(){
    var sBQz4 = document.getElementById("aImgSqr5").src;
    valueBSave4 = 'zSqrArtSpecz4';
    localStorage.setItem(valueBSave4, sBQz4);
};
function squareBToSzzZValue4(){
    valueBSave4 = 'zSqrArtSpecz4';
    var tripleBZeroA = localStorage.getItem(valueBSave4);
    document.getElementById("imgSqr5").src = tripleBZeroA;};

function artsquare5(){
    var sBQz5 = document.getElementById("aImgSqr6").src;
    valueBSave5 = 'zSqrArtSpecz5';
    localStorage.setItem(valueBSave5, sBQz5);
};
function squareBToSzzZValue5(){
    valueBSave5 = 'zSqrArtSpecz5';
    var tripleBZeroA = localStorage.getItem(valueBSave5);
    document.getElementById("imgSqr6").src = tripleBZeroA;};

function artsquare6(){
    var sBQz6 = document.getElementById("aImgSqr7").src;
    valueBSave6 = 'zSqrArtSpecz6';
    localStorage.setItem(valueBSave6, sBQz6);
};
function squareBToSzzZValue6(){
    valueBSave6 = 'zSqrArtSpecz6';
    var tripleBZeroA = localStorage.getItem(valueBSave6);
    document.getElementById("imgSqr7").src = tripleBZeroA;};

function artsquare7(){
    var sBQz7 = document.getElementById("aImgSqr8").src;
    valueBSave7 = 'zSqrArtSpecz7';
    localStorage.setItem(valueBSave7, sBQz7);
};
function squareBToSzzZValue7(){
    valueBSave7 = 'zSqrArtSpecz7';
    var tripleBZeroA = localStorage.getItem(valueBSave7);
    document.getElementById("imgSqr8").src = tripleBZeroA;};

function artsquare8(){
    var sBQz8 = document.getElementById("aImgSqr9").src;
    valueBSave8 = 'zSqrArtSpecz8';
    localStorage.setItem(valueBSave8, sBQz8);
};
function squareBToSzzZValue8(){
    valueBSave8 = 'zSqrArtSpecz8';
    var tripleBZeroA = localStorage.getItem(valueBSave8);
    document.getElementById("imgSqr9").src = tripleBZeroA;};

function artsquare9(){
    var sBQz9 = document.getElementById("aImgSqr10").src;
    valueBSave9 = 'zSqrArtSpecz9';
    localStorage.setItem(valueBSave9, sBQz9);
};
function squareBToSzzZValue9(){
    valueBSave9 = 'zSqrArtSpecz9';
    var tripleBZeroA = localStorage.getItem(valueBSave9);
    document.getElementById("imgSqr10").src = tripleBZeroA;};

function artsquare10(){
    var sBQz10 = document.getElementById("aImgSqr11").src;
    valueBSave10 = 'zSqrArtSpecz10';
    localStorage.setItem(valueBSave10, sBQz10);
};
function squareBToSzzZValue10(){
    valueBSave10 = 'zSqrArtSpecz10';
    var tripleBZeroA = localStorage.getItem(valueBSave10);
    document.getElementById("imgSqr11").src = tripleBZeroA;};

function artsquare11(){
    var sBQz11 = document.getElementById("aImgSqr12").src;
    valueBSave11 = 'zSqrArtSpecz11';
    localStorage.setItem(valueBSave11, sBQz11);
};
function squareBToSzzZValue11(){
    valueBSave11 = 'zSqrArtSpecz11';
    var tripleBZeroA = localStorage.getItem(valueBSave11);
    document.getElementById("imgSqr12").src = tripleBZeroA;};

function artsquare12(){
    var sBQz12 = document.getElementById("aImgSqr13").src;
    valueBSave12 = 'zSqrArtSpecz12';
    localStorage.setItem(valueBSave12, sBQz12);
};
function squareBToSzzZValue12(){
    valueBSave12 = 'zSqrArtSpecz12';
    var tripleBZeroA = localStorage.getItem(valueBSave12);
    document.getElementById("imgSqr13").src = tripleBZeroA;};

function artsquare13(){
    var sBQz13 = document.getElementById("aImgSqr14").src;
    valueBSave13 = 'zSqrArtSpecz13';
    localStorage.setItem(valueBSave13, sBQz13);
};
function squareBToSzzZValue13(){
    valueBSave13 = 'zSqrArtSpecz13';
    var tripleBZeroA = localStorage.getItem(valueBSave13);
    document.getElementById("imgSqr14").src = tripleBZeroA;};

function artsquare14(){
    var sBQz14 = document.getElementById("aImgSqr15").src;
    valueBSave14 = 'zSqrArtSpecz14';
    localStorage.setItem(valueBSave14, sBQz14);
};
function squareBToSzzZValue14(){
    valueBSave14 = 'zSqrArtSpecz14';
    var tripleBZeroA = localStorage.getItem(valueBSave14);
    document.getElementById("imgSqr15").src = tripleBZeroA;};

function artsquare15(){
    var sBQz15 = document.getElementById("aImgSqr16").src;
    valueBSave15 = 'zSqrArtSpecz15';
    localStorage.setItem(valueBSave15, sBQz15);
};
function squareBToSzzZValue15(){
    valueBSave15 = 'zSqrArtSpecz15';
    var tripleBZeroA = localStorage.getItem(valueBSave15);
    document.getElementById("imgSqr16").src = tripleBZeroA;};

function artsquare16(){
    var sBQz16 = document.getElementById("aImgSqr17").src;
    valueBSave16 = 'zSqrArtSpecz16';
    localStorage.setItem(valueBSave16, sBQz16);
};
function squareBToSzzZValue16(){
    valueBSave16 = 'zSqrArtSpecz16';
    var tripleBZeroA = localStorage.getItem(valueBSave16);
    document.getElementById("imgSqr17").src = tripleBZeroA;};

function artsquare17(){
    var sBQz17 = document.getElementById("aImgSqr18").src;
    valueBSave17 = 'zSqrArtSpecz17';
    localStorage.setItem(valueBSave17, sBQz17);
};
function squareBToSzzZValue17(){
    valueBSave17 = 'zSqrArtSpecz17';
    var tripleBZeroA = localStorage.getItem(valueBSave17);
    document.getElementById("imgSqr18").src = tripleBZeroA;};

function artsquare18(){
    var sBQz18 = document.getElementById("aImgSqr19").src;
    valueBSave18 = 'zSqrArtSpecz18';
    localStorage.setItem(valueBSave18, sBQz18);
};
function squareBToSzzZValue18(){
    valueBSave18 = 'zSqrArtSpecz18';
    var tripleBZeroA = localStorage.getItem(valueBSave18);
    document.getElementById("imgSqr19").src = tripleBZeroA;};

function artsquare19(){
    var sBQz19 = document.getElementById("aImgSqr20").src;
    valueBSave19 = 'zSqrArtSpecz19';
    localStorage.setItem(valueBSave19, sBQz19);
};
function squareBToSzzZValue19(){
    valueBSave19 = 'zSqrArtSpecz19';
    var tripleBZeroA = localStorage.getItem(valueBSave19);
    document.getElementById("imgSqr20").src = tripleBZeroA;};

function artsquare20(){
    var sBQz20 = document.getElementById("aImgSqr21").src;
    valueBSave20 = 'zSqrArtSpecz20';
    localStorage.setItem(valueBSave20, sBQz20);
};
function squareBToSzzZValue20(){
    valueBSave20 = 'zSqrArtSpecz20';
    var tripleBZeroA = localStorage.getItem(valueBSave20);
    document.getElementById("imgSqr21").src = tripleBZeroA;};

function artsquare21(){
    var sBQz21 = document.getElementById("aImgSqr22").src;
    valueBSave21 = 'zSqrArtSpecz21';
    localStorage.setItem(valueBSave21, sBQz21);
};
function squareBToSzzZValue21(){
    valueBSave21 = 'zSqrArtSpecz21';
    var tripleBZeroA = localStorage.getItem(valueBSave21);
    document.getElementById("imgSqr22").src = tripleBZeroA;};

function artsquare22(){
    var sBQz22 = document.getElementById("aImgSqr23").src;
    valueBSave22 = 'zSqrArtSpecz22';
    localStorage.setItem(valueBSave22, sBQz22);
};
function squareBToSzzZValue22(){
    valueBSave22 = 'zSqrArtSpecz22';
    var tripleBZeroA = localStorage.getItem(valueBSave22);
    document.getElementById("imgSqr23").src = tripleBZeroA;};

function artsquare23(){
    var sBQz23 = document.getElementById("aImgSqr24").src;
    valueBSave23 = 'zSqrArtSpecz23';
    localStorage.setItem(valueBSave23, sBQz23);
};
function squareBToSzzZValue23(){
    valueBSave23 = 'zSqrArtSpecz23';
    var tripleBZeroA = localStorage.getItem(valueBSave23);
    document.getElementById("imgSqr24").src = tripleBZeroA;};

function artsquare24(){
    var sBQz24 = document.getElementById("aImgSqr25").src;
    valueBSave24 = 'zSqrArtSpecz24';
    localStorage.setItem(valueBSave24, sBQz24);
};
function squareBToSzzZValue24(){
    valueBSave24 = 'zSqrArtSpecz24';
    var tripleBZeroA = localStorage.getItem(valueBSave24);
    document.getElementById("imgSqr25").src = tripleBZeroA;};

function artsquare25(){
    var sBQz25 = document.getElementById("aImgSqr26").src;
    valueBSave25 = 'zSqrArtSpecz25';
    localStorage.setItem(valueBSave25, sBQz25);
};
function squareBToSzzZValue25(){
    valueBSave25 = 'zSqrArtSpecz25';
    var tripleBZeroA = localStorage.getItem(valueBSave25);
    document.getElementById("imgSqr26").src = tripleBZeroA;};

function artsquare26(){
    var sBQz26 = document.getElementById("aImgSqr27").src;
    valueBSave26 = 'zSqrArtSpecz26';
    localStorage.setItem(valueBSave26, sBQz26);
};
function squareBToSzzZValue26(){
    valueBSave26 = 'zSqrArtSpecz26';
    var tripleBZeroA = localStorage.getItem(valueBSave26);
    document.getElementById("imgSqr27").src = tripleBZeroA;};

function artsquare27(){
    var sBQz27 = document.getElementById("aImgSqr28").src;
    valueBSave27 = 'zSqrArtSpecz27';
    localStorage.setItem(valueBSave27, sBQz27);
};
function squareBToSzzZValue27(){
    valueBSave27 = 'zSqrArtSpecz27';
    var tripleBZeroA = localStorage.getItem(valueBSave27);
    document.getElementById("imgSqr28").src = tripleBZeroA;};

function artsquare28(){
    var sBQz28 = document.getElementById("aImgSqr29").src;
    valueBSave28 = 'zSqrArtSpecz28';
    localStorage.setItem(valueBSave28, sBQz28);
};
function squareBToSzzZValue28(){
    valueBSave28 = 'zSqrArtSpecz28';
    var tripleBZeroA = localStorage.getItem(valueBSave28);
    document.getElementById("imgSqr29").src = tripleBZeroA;};

function artsquare29(){
    var sBQz29 = document.getElementById("aImgSqr30").src;
    valueBSave29 = 'zSqrArtSpecz29';
    localStorage.setItem(valueBSave29, sBQz29);
};
function squareBToSzzZValue29(){
    valueBSave29 = 'zSqrArtSpecz29';
    var tripleBZeroA = localStorage.getItem(valueBSave29);
    document.getElementById("imgSqr30").src = tripleBZeroA;};

function artsquare30(){
    var sBQz30 = document.getElementById("aImgSqr31").src;
    valueBSave30 = 'zSqrArtSpecz30';
    localStorage.setItem(valueBSave30, sBQz30);
};
function squareBToSzzZValue30(){
    valueBSave30 = 'zSqrArtSpecz30';
    var tripleBZeroA = localStorage.getItem(valueBSave30);
    document.getElementById("imgSqr31").src = tripleBZeroA;};

function artsquare31(){
    var sBQz31 = document.getElementById("aImgSqr32").src;
    valueBSave31 = 'zSqrArtSpecz31';
    localStorage.setItem(valueBSave31, sBQz31);
};
function squareBToSzzZValue31(){
    valueBSave31 = 'zSqrArtSpecz31';
    var tripleBZeroA = localStorage.getItem(valueBSave31);
    document.getElementById("imgSqr32").src = tripleBZeroA;};

function artsquare32(){
    var sBQz32 = document.getElementById("aImgSqr33").src;
    valueBSave32 = 'zSqrArtSpecz32';
    localStorage.setItem(valueBSave32, sBQz32);
};
function squareBToSzzZValue32(){
    valueBSave32 = 'zSqrArtSpecz32';
    var tripleBZeroA = localStorage.getItem(valueBSave32);
    document.getElementById("imgSqr33").src = tripleBZeroA;};

function artsquare33(){
    var sBQz33 = document.getElementById("aImgSqr34").src;
    valueBSave33 = 'zSqrArtSpecz33';
    localStorage.setItem(valueBSave33, sBQz33);
};
function squareBToSzzZValue33(){
    valueBSave33 = 'zSqrArtSpecz33';
    var tripleBZeroA = localStorage.getItem(valueBSave33);
    document.getElementById("imgSqr34").src = tripleBZeroA;};

function artsquare34(){
    var sBQz34 = document.getElementById("aImgSqr35").src;
    valueBSave34 = 'zSqrArtSpecz34';
    localStorage.setItem(valueBSave34, sBQz34);
};
function squareBToSzzZValue34(){
    valueBSave34 = 'zSqrArtSpecz34';
    var tripleBZeroA = localStorage.getItem(valueBSave34);
    document.getElementById("imgSqr35").src = tripleBZeroA;};

function artsquare35(){
    var sBQz35 = document.getElementById("aImgSqr36").src;
    valueBSave35 = 'zSqrArtSpecz35';
    localStorage.setItem(valueBSave35, sBQz35);
};
function squareBToSzzZValue35(){
    valueBSave35 = 'zSqrArtSpecz35';
    var tripleBZeroA = localStorage.getItem(valueBSave35);
    document.getElementById("imgSqr36").src = tripleBZeroA;};

function artsquare36(){
    var sBQz36 = document.getElementById("aImgSqr37").src;
    valueBSave36 = 'zSqrArtSpecz36';
    localStorage.setItem(valueBSave36, sBQz36);
};
function squareBToSzzZValue36(){
    valueBSave36 = 'zSqrArtSpecz36';
    var tripleBZeroA = localStorage.getItem(valueBSave36);
    document.getElementById("imgSqr37").src = tripleBZeroA;};

function artsquare37(){
    var sBQz37 = document.getElementById("aImgSqr38").src;
    valueBSave37 = 'zSqrArtSpecz37';
    localStorage.setItem(valueBSave37, sBQz37);
};
function squareBToSzzZValue37(){
    valueBSave37 = 'zSqrArtSpecz37';
    var tripleBZeroA = localStorage.getItem(valueBSave37);
    document.getElementById("imgSqr38").src = tripleBZeroA;};

function artsquare38(){
    var sBQz38 = document.getElementById("aImgSqr39").src;
    valueBSave38 = 'zSqrArtSpecz38';
    localStorage.setItem(valueBSave38, sBQz38);
};
function squareBToSzzZValue38(){
    valueBSave38 = 'zSqrArtSpecz38';
    var tripleBZeroA = localStorage.getItem(valueBSave38);
    document.getElementById("imgSqr39").src = tripleBZeroA;};

function artsquare39(){
    var sBQz39 = document.getElementById("aImgSqr40").src;
    valueBSave39 = 'zSqrArtSpecz39';
    localStorage.setItem(valueBSave39, sBQz39);
};
function squareBToSzzZValue39(){
    valueBSave39 = 'zSqrArtSpecz39';
    var tripleBZeroA = localStorage.getItem(valueBSave39);
    document.getElementById("imgSqr40").src = tripleBZeroA;};

function artsquare40(){
    var sBQz40 = document.getElementById("aImgSqr41").src;
    valueBSave40 = 'zSqrArtSpecz40';
    localStorage.setItem(valueBSave40, sBQz40);
};
function squareBToSzzZValue40(){
    valueBSave40 = 'zSqrArtSpecz40';
    var tripleBZeroA = localStorage.getItem(valueBSave40);
    document.getElementById("imgSqr41").src = tripleBZeroA;};

function artsquare41(){
    var sBQz41 = document.getElementById("aImgSqr42").src;
    valueBSave41 = 'zSqrArtSpecz41';
    localStorage.setItem(valueBSave41, sBQz41);
};
function squareBToSzzZValue41(){
    valueBSave41 = 'zSqrArtSpecz41';
    var tripleBZeroA = localStorage.getItem(valueBSave41);
    document.getElementById("imgSqr42").src = tripleBZeroA;};

function artsquare42(){
    var sBQz42 = document.getElementById("aImgSqr43").src;
    valueBSave42 = 'zSqrArtSpecz42';
    localStorage.setItem(valueBSave42, sBQz42);
};
function squareBToSzzZValue42(){
    valueBSave42 = 'zSqrArtSpecz42';
    var tripleBZeroA = localStorage.getItem(valueBSave42);
    document.getElementById("imgSqr43").src = tripleBZeroA;};

function artsquare43(){
    var sBQz43 = document.getElementById("aImgSqr44").src;
    valueBSave43 = 'zSqrArtSpecz43';
    localStorage.setItem(valueBSave43, sBQz43);
};
function squareBToSzzZValue43(){
    valueBSave43 = 'zSqrArtSpecz43';
    var tripleBZeroA = localStorage.getItem(valueBSave43);
    document.getElementById("imgSqr44").src = tripleBZeroA;};

function artsquare44(){
    var sBQz44 = document.getElementById("aImgSqr45").src;
    valueBSave44 = 'zSqrArtSpecz44';
    localStorage.setItem(valueBSave44, sBQz44);
};
function squareBToSzzZValue44(){
    valueBSave44 = 'zSqrArtSpecz44';
    var tripleBZeroA = localStorage.getItem(valueBSave44);
    document.getElementById("imgSqr45").src = tripleBZeroA;};

function artsquare45(){
    var sBQz45 = document.getElementById("aImgSqr46").src;
    valueBSave45 = 'zSqrArtSpecz45';
    localStorage.setItem(valueBSave45, sBQz45);
};
function squareBToSzzZValue45(){
    valueBSave45 = 'zSqrArtSpecz45';
    var tripleBZeroA = localStorage.getItem(valueBSave45);
    document.getElementById("imgSqr46").src = tripleBZeroA;};

function artsquare46(){
    var sBQz46 = document.getElementById("aImgSqr47").src;
    valueBSave46 = 'zSqrArtSpecz46';
    localStorage.setItem(valueBSave46, sBQz46);
};
function squareBToSzzZValue46(){
    valueBSave46 = 'zSqrArtSpecz46';
    var tripleBZeroA = localStorage.getItem(valueBSave46);
    document.getElementById("imgSqr47").src = tripleBZeroA;};

function artsquare47(){
    var sBQz47 = document.getElementById("aImgSqr48").src;
    valueBSave47 = 'zSqrArtSpecz47';
    localStorage.setItem(valueBSave47, sBQz47);
};
function squareBToSzzZValue47(){
    valueBSave47 = 'zSqrArtSpecz47';
    var tripleBZeroA = localStorage.getItem(valueBSave47);
    document.getElementById("imgSqr48").src = tripleBZeroA;};

function artsquare48(){
    var sBQz48 = document.getElementById("aImgSqr49").src;
    valueBSave48 = 'zSqrArtSpecz48';
    localStorage.setItem(valueBSave48, sBQz48);
};
function squareBToSzzZValue48(){
    valueBSave48 = 'zSqrArtSpecz48';
    var tripleBZeroA = localStorage.getItem(valueBSave48);
    document.getElementById("imgSqr49").src = tripleBZeroA;};

function artsquare49(){
    var sBQz49 = document.getElementById("aImgSqr50").src;
    valueBSave49 = 'zSqrArtSpecz49';
    localStorage.setItem(valueBSave49, sBQz49);
};
function squareBToSzzZValue49(){
    valueBSave49 = 'zSqrArtSpecz49';
    var tripleBZeroA = localStorage.getItem(valueBSave49);
    document.getElementById("imgSqr50").src = tripleBZeroA;};

function artsquare50(){
    var sBQz50 = document.getElementById("aImgSqr51").src;
    valueBSave50 = 'zSqrArtSpecz50';
    localStorage.setItem(valueBSave50, sBQz50);
};
function squareBToSzzZValue50(){
    valueBSave50 = 'zSqrArtSpecz50';
    var tripleBZeroA = localStorage.getItem(valueBSave50);
    document.getElementById("imgSqr51").src = tripleBZeroA;};

function artsquare51(){
    var sBQz51 = document.getElementById("aImgSqr52").src;
    valueBSave51 = 'zSqrArtSpecz51';
    localStorage.setItem(valueBSave51, sBQz51);
};
function squareBToSzzZValue51(){
    valueBSave51 = 'zSqrArtSpecz51';
    var tripleBZeroA = localStorage.getItem(valueBSave51);
    document.getElementById("imgSqr52").src = tripleBZeroA;};

function artsquare52(){
    var sBQz52 = document.getElementById("aImgSqr53").src;
    valueBSave52 = 'zSqrArtSpecz52';
    localStorage.setItem(valueBSave52, sBQz52);
};
function squareBToSzzZValue52(){
    valueBSave52 = 'zSqrArtSpecz52';
    var tripleBZeroA = localStorage.getItem(valueBSave52);
    document.getElementById("imgSqr53").src = tripleBZeroA;};

function artsquare53(){
    var sBQz53 = document.getElementById("aImgSqr54").src;
    valueBSave53 = 'zSqrArtSpecz53';
    localStorage.setItem(valueBSave53, sBQz53);
};
function squareBToSzzZValue53(){
    valueBSave53 = 'zSqrArtSpecz53';
    var tripleBZeroA = localStorage.getItem(valueBSave53);
    document.getElementById("imgSqr54").src = tripleBZeroA;};

function artsquare54(){
    var sBQz54 = document.getElementById("aImgSqr55").src;
    valueBSave54 = 'zSqrArtSpecz54';
    localStorage.setItem(valueBSave54, sBQz54);
};
function squareBToSzzZValue54(){
    valueBSave54 = 'zSqrArtSpecz54';
    var tripleBZeroA = localStorage.getItem(valueBSave54);
    document.getElementById("imgSqr55").src = tripleBZeroA;};

function artsquare55(){
    var sBQz55 = document.getElementById("aImgSqr56").src;
    valueBSave55 = 'zSqrArtSpecz55';
    localStorage.setItem(valueBSave55, sBQz55);
};
function squareBToSzzZValue55(){
    valueBSave55 = 'zSqrArtSpecz55';
    var tripleBZeroA = localStorage.getItem(valueBSave55);
    document.getElementById("imgSqr56").src = tripleBZeroA;};

function artsquare56(){
    var sBQz56 = document.getElementById("aImgSqr57").src;
    valueBSave56 = 'zSqrArtSpecz56';
    localStorage.setItem(valueBSave56, sBQz56);
};
function squareBToSzzZValue56(){
    valueBSave56 = 'zSqrArtSpecz56';
    var tripleBZeroA = localStorage.getItem(valueBSave56);
    document.getElementById("imgSqr57").src = tripleBZeroA;};

function artsquare57(){
    var sBQz57 = document.getElementById("aImgSqr58").src;
    valueBSave57 = 'zSqrArtSpecz57';
    localStorage.setItem(valueBSave57, sBQz57);
};
function squareBToSzzZValue57(){
    valueBSave57 = 'zSqrArtSpecz57';
    var tripleBZeroA = localStorage.getItem(valueBSave57);
    document.getElementById("imgSqr58").src = tripleBZeroA;};

function artsquare58(){
    var sBQz58 = document.getElementById("aImgSqr59").src;
    valueBSave58 = 'zSqrArtSpecz58';
    localStorage.setItem(valueBSave58, sBQz58);
};
function squareBToSzzZValue58(){
    valueBSave58 = 'zSqrArtSpecz58';
    var tripleBZeroA = localStorage.getItem(valueBSave58);
    document.getElementById("imgSqr59").src = tripleBZeroA;};

function artsquare59(){
    var sBQz59 = document.getElementById("aImgSqr60").src;
    valueBSave59 = 'zSqrArtSpecz59';
    localStorage.setItem(valueBSave59, sBQz59);
};
function squareBToSzzZValue59(){
    valueBSave59 = 'zSqrArtSpecz59';
    var tripleBZeroA = localStorage.getItem(valueBSave59);
    document.getElementById("imgSqr60").src = tripleBZeroA;};

function artsquare60(){
    var sBQz60 = document.getElementById("aImgSqr61").src;
    valueBSave60 = 'zSqrArtSpecz60';
    localStorage.setItem(valueBSave60, sBQz60);
};
function squareBToSzzZValue60(){
    valueBSave60 = 'zSqrArtSpecz60';
    var tripleBZeroA = localStorage.getItem(valueBSave60);
    document.getElementById("imgSqr61").src = tripleBZeroA;};

function artsquare61(){
    var sBQz61 = document.getElementById("aImgSqr62").src;
    valueBSave61 = 'zSqrArtSpecz61';
    localStorage.setItem(valueBSave61, sBQz61);
};
function squareBToSzzZValue61(){
    valueBSave61 = 'zSqrArtSpecz61';
    var tripleBZeroA = localStorage.getItem(valueBSave61);
    document.getElementById("imgSqr62").src = tripleBZeroA;};

function artsquare62(){
    var sBQz62 = document.getElementById("aImgSqr63").src;
    valueBSave62 = 'zSqrArtSpecz62';
    localStorage.setItem(valueBSave62, sBQz62);
};
function squareBToSzzZValue62(){
    valueBSave62 = 'zSqrArtSpecz62';
    var tripleBZeroA = localStorage.getItem(valueBSave62);
    document.getElementById("imgSqr63").src = tripleBZeroA;};

function artsquare63(){
    var sBQz63 = document.getElementById("aImgSqr64").src;
    valueBSave63 = 'zSqrArtSpecz63';
    localStorage.setItem(valueBSave63, sBQz63);
};
function squareBToSzzZValue63(){
    valueBSave63 = 'zSqrArtSpecz63';
    var tripleBZeroA = localStorage.getItem(valueBSave63);
    document.getElementById("imgSqr64").src = tripleBZeroA;};

function artsquare64(){
    var sBQz64 = document.getElementById("aImgSqr65").src;
    valueBSave64 = 'zSqrArtSpecz64';
    localStorage.setItem(valueBSave64, sBQz64);
};
function squareBToSzzZValue64(){
    valueBSave64 = 'zSqrArtSpecz64';
    var tripleBZeroA = localStorage.getItem(valueBSave64);
    document.getElementById("imgSqr65").src = tripleBZeroA;};

function artsquare65(){
    var sBQz65 = document.getElementById("aImgSqr66").src;
    valueBSave65 = 'zSqrArtSpecz65';
    localStorage.setItem(valueBSave65, sBQz65);
};
function squareBToSzzZValue65(){
    valueBSave65 = 'zSqrArtSpecz65';
    var tripleBZeroA = localStorage.getItem(valueBSave65);
    document.getElementById("imgSqr66").src = tripleBZeroA;};

function artsquare66(){
    var sBQz66 = document.getElementById("aImgSqr67").src;
    valueBSave66 = 'zSqrArtSpecz66';
    localStorage.setItem(valueBSave66, sBQz66);
};
function squareBToSzzZValue66(){
    valueBSave66 = 'zSqrArtSpecz66';
    var tripleBZeroA = localStorage.getItem(valueBSave66);
    document.getElementById("imgSqr67").src = tripleBZeroA;};

function artsquare67(){
    var sBQz67 = document.getElementById("aImgSqr68").src;
    valueBSave67 = 'zSqrArtSpecz67';
    localStorage.setItem(valueBSave67, sBQz67);
};
function squareBToSzzZValue67(){
    valueBSave67 = 'zSqrArtSpecz67';
    var tripleBZeroA = localStorage.getItem(valueBSave67);
    document.getElementById("imgSqr68").src = tripleBZeroA;};

function artsquare68(){
    var sBQz68 = document.getElementById("aImgSqr69").src;
    valueBSave68 = 'zSqrArtSpecz68';
    localStorage.setItem(valueBSave68, sBQz68);
};
function squareBToSzzZValue68(){
    valueBSave68 = 'zSqrArtSpecz68';
    var tripleBZeroA = localStorage.getItem(valueBSave68);
    document.getElementById("imgSqr69").src = tripleBZeroA;};

function artsquare69(){
    var sBQz69 = document.getElementById("aImgSqr70").src;
    valueBSave69 = 'zSqrArtSpecz69';
    localStorage.setItem(valueBSave69, sBQz69);
};
function squareBToSzzZValue69(){
    valueBSave69 = 'zSqrArtSpecz69';
    var tripleBZeroA = localStorage.getItem(valueBSave69);
    document.getElementById("imgSqr70").src = tripleBZeroA;};

function artsquare70(){
    var sBQz70 = document.getElementById("aImgSqr71").src;
    valueBSave70 = 'zSqrArtSpecz70';
    localStorage.setItem(valueBSave70, sBQz70);
};
function squareBToSzzZValue70(){
    valueBSave70 = 'zSqrArtSpecz70';
    var tripleBZeroA = localStorage.getItem(valueBSave70);
    document.getElementById("imgSqr71").src = tripleBZeroA;};

function artsquare71(){
    var sBQz71 = document.getElementById("aImgSqr72").src;
    valueBSave71 = 'zSqrArtSpecz71';
    localStorage.setItem(valueBSave71, sBQz71);
};
function squareBToSzzZValue71(){
    valueBSave71 = 'zSqrArtSpecz71';
    var tripleBZeroA = localStorage.getItem(valueBSave71);
    document.getElementById("imgSqr72").src = tripleBZeroA;};

function artsquare72(){
    var sBQz72 = document.getElementById("aImgSqr73").src;
    valueBSave72 = 'zSqrArtSpecz72';
    localStorage.setItem(valueBSave72, sBQz72);
};
function squareBToSzzZValue72(){
    valueBSave72 = 'zSqrArtSpecz72';
    var tripleBZeroA = localStorage.getItem(valueBSave72);
    document.getElementById("imgSqr73").src = tripleBZeroA;};

function artsquare73(){
    var sBQz73 = document.getElementById("aImgSqr74").src;
    valueBSave73 = 'zSqrArtSpecz73';
    localStorage.setItem(valueBSave73, sBQz73);
};
function squareBToSzzZValue73(){
    valueBSave73 = 'zSqrArtSpecz73';
    var tripleBZeroA = localStorage.getItem(valueBSave73);
    document.getElementById("imgSqr74").src = tripleBZeroA;};

function artsquare74(){
    var sBQz74 = document.getElementById("aImgSqr75").src;
    valueBSave74 = 'zSqrArtSpecz74';
    localStorage.setItem(valueBSave74, sBQz74);
};
function squareBToSzzZValue74(){
    valueBSave74 = 'zSqrArtSpecz74';
    var tripleBZeroA = localStorage.getItem(valueBSave74);
    document.getElementById("imgSqr75").src = tripleBZeroA;};

function artsquare75(){
    var sBQz75 = document.getElementById("aImgSqr76").src;
    valueBSave75 = 'zSqrArtSpecz75';
    localStorage.setItem(valueBSave75, sBQz75);
};
function squareBToSzzZValue75(){
    valueBSave75 = 'zSqrArtSpecz75';
    var tripleBZeroA = localStorage.getItem(valueBSave75);
    document.getElementById("imgSqr76").src = tripleBZeroA;};

function artsquare76(){
    var sBQz76 = document.getElementById("aImgSqr77").src;
    valueBSave76 = 'zSqrArtSpecz76';
    localStorage.setItem(valueBSave76, sBQz76);
};
function squareBToSzzZValue76(){
    valueBSave76 = 'zSqrArtSpecz76';
    var tripleBZeroA = localStorage.getItem(valueBSave76);
    document.getElementById("imgSqr77").src = tripleBZeroA;};

function artsquare77(){
    var sBQz77 = document.getElementById("aImgSqr78").src;
    valueBSave77 = 'zSqrArtSpecz77';
    localStorage.setItem(valueBSave77, sBQz77);
};
function squareBToSzzZValue77(){
    valueBSave77 = 'zSqrArtSpecz77';
    var tripleBZeroA = localStorage.getItem(valueBSave77);
    document.getElementById("imgSqr78").src = tripleBZeroA;};

function artsquare78(){
    var sBQz78 = document.getElementById("aImgSqr79").src;
    valueBSave78 = 'zSqrArtSpecz78';
    localStorage.setItem(valueBSave78, sBQz78);
};
function squareBToSzzZValue78(){
    valueBSave78 = 'zSqrArtSpecz78';
    var tripleBZeroA = localStorage.getItem(valueBSave78);
    document.getElementById("imgSqr79").src = tripleBZeroA;};

function artsquare79(){
    var sBQz79 = document.getElementById("aImgSqr80").src;
    valueBSave79 = 'zSqrArtSpecz79';
    localStorage.setItem(valueBSave79, sBQz79);
};
function squareBToSzzZValue79(){
    valueBSave79 = 'zSqrArtSpecz79';
    var tripleBZeroA = localStorage.getItem(valueBSave79);
    document.getElementById("imgSqr80").src = tripleBZeroA;};

function artsquare80(){
    var sBQz80 = document.getElementById("aImgSqr81").src;
    valueBSave80 = 'zSqrArtSpecz80';
    localStorage.setItem(valueBSave80, sBQz80);
};
function squareBToSzzZValue80(){
    valueBSave80 = 'zSqrArtSpecz80';
    var tripleBZeroA = localStorage.getItem(valueBSave80);
    document.getElementById("imgSqr81").src = tripleBZeroA;};

function artsquare81(){
    var sBQz81 = document.getElementById("aImgSqr82").src;
    valueBSave81 = 'zSqrArtSpecz81';
    localStorage.setItem(valueBSave81, sBQz81);
};
function squareBToSzzZValue81(){
    valueBSave81 = 'zSqrArtSpecz81';
    var tripleBZeroA = localStorage.getItem(valueBSave81);
    document.getElementById("imgSqr82").src = tripleBZeroA;};

function artsquare82(){
    var sBQz82 = document.getElementById("aImgSqr83").src;
    valueBSave82 = 'zSqrArtSpecz82';
    localStorage.setItem(valueBSave82, sBQz82);
};
function squareBToSzzZValue82(){
    valueBSave82 = 'zSqrArtSpecz82';
    var tripleBZeroA = localStorage.getItem(valueBSave82);
    document.getElementById("imgSqr83").src = tripleBZeroA;};

function artsquare83(){
    var sBQz83 = document.getElementById("aImgSqr84").src;
    valueBSave83 = 'zSqrArtSpecz83';
    localStorage.setItem(valueBSave83, sBQz83);
};
function squareBToSzzZValue83(){
    valueBSave83 = 'zSqrArtSpecz83';
    var tripleBZeroA = localStorage.getItem(valueBSave83);
    document.getElementById("imgSqr84").src = tripleBZeroA;};

function artsquare84(){
    var sBQz84 = document.getElementById("aImgSqr85").src;
    valueBSave84 = 'zSqrArtSpecz84';
    localStorage.setItem(valueBSave84, sBQz84);
};
function squareBToSzzZValue84(){
    valueBSave84 = 'zSqrArtSpecz84';
    var tripleBZeroA = localStorage.getItem(valueBSave84);
    document.getElementById("imgSqr85").src = tripleBZeroA;};

function artsquare85(){
    var sBQz85 = document.getElementById("aImgSqr86").src;
    valueBSave85 = 'zSqrArtSpecz85';
    localStorage.setItem(valueBSave85, sBQz85);
};
function squareBToSzzZValue85(){
    valueBSave85 = 'zSqrArtSpecz85';
    var tripleBZeroA = localStorage.getItem(valueBSave85);
    document.getElementById("imgSqr86").src = tripleBZeroA;};

function artsquare86(){
    var sBQz86 = document.getElementById("aImgSqr87").src;
    valueBSave86 = 'zSqrArtSpecz86';
    localStorage.setItem(valueBSave86, sBQz86);
};
function squareBToSzzZValue86(){
    valueBSave86 = 'zSqrArtSpecz86';
    var tripleBZeroA = localStorage.getItem(valueBSave86);
    document.getElementById("imgSqr87").src = tripleBZeroA;};

function artsquare87(){
    var sBQz87 = document.getElementById("aImgSqr88").src;
    valueBSave87 = 'zSqrArtSpecz87';
    localStorage.setItem(valueBSave87, sBQz87);
};
function squareBToSzzZValue87(){
    valueBSave87 = 'zSqrArtSpecz87';
    var tripleBZeroA = localStorage.getItem(valueBSave87);
    document.getElementById("imgSqr88").src = tripleBZeroA;};

function artsquare88(){
    var sBQz88 = document.getElementById("aImgSqr89").src;
    valueBSave88 = 'zSqrArtSpecz88';
    localStorage.setItem(valueBSave88, sBQz88);
};
function squareBToSzzZValue88(){
    valueBSave88 = 'zSqrArtSpecz88';
    var tripleBZeroA = localStorage.getItem(valueBSave88);
    document.getElementById("imgSqr89").src = tripleBZeroA;};

function artsquare89(){
    var sBQz89 = document.getElementById("aImgSqr90").src;
    valueBSave89 = 'zSqrArtSpecz89';
    localStorage.setItem(valueBSave89, sBQz89);
};
function squareBToSzzZValue89(){
    valueBSave89 = 'zSqrArtSpecz89';
    var tripleBZeroA = localStorage.getItem(valueBSave89);
    document.getElementById("imgSqr90").src = tripleBZeroA;};

function artsquare90(){
    var sBQz90 = document.getElementById("aImgSqr91").src;
    valueBSave90 = 'zSqrArtSpecz90';
    localStorage.setItem(valueBSave90, sBQz90);
};
function squareBToSzzZValue90(){
    valueBSave90 = 'zSqrArtSpecz90';
    var tripleBZeroA = localStorage.getItem(valueBSave90);
    document.getElementById("imgSqr91").src = tripleBZeroA;};

function artsquare91(){
    var sBQz91 = document.getElementById("aImgSqr92").src;
    valueBSave91 = 'zSqrArtSpecz91';
    localStorage.setItem(valueBSave91, sBQz91);
};
function squareBToSzzZValue91(){
    valueBSave91 = 'zSqrArtSpecz91';
    var tripleBZeroA = localStorage.getItem(valueBSave91);
    document.getElementById("imgSqr92").src = tripleBZeroA;};

function artsquare92(){
    var sBQz92 = document.getElementById("aImgSqr93").src;
    valueBSave92 = 'zSqrArtSpecz92';
    localStorage.setItem(valueBSave92, sBQz92);
};
function squareBToSzzZValue92(){
    valueBSave92 = 'zSqrArtSpecz92';
    var tripleBZeroA = localStorage.getItem(valueBSave92);
    document.getElementById("imgSqr93").src = tripleBZeroA;};

function artsquare93(){
    var sBQz93 = document.getElementById("aImgSqr94").src;
    valueBSave93 = 'zSqrArtSpecz93';
    localStorage.setItem(valueBSave93, sBQz93);
};
function squareBToSzzZValue93(){
    valueBSave93 = 'zSqrArtSpecz93';
    var tripleBZeroA = localStorage.getItem(valueBSave93);
    document.getElementById("imgSqr94").src = tripleBZeroA;};

function artsquare94(){
    var sBQz94 = document.getElementById("aImgSqr95").src;
    valueBSave94 = 'zSqrArtSpecz94';
    localStorage.setItem(valueBSave94, sBQz94);
};
function squareBToSzzZValue94(){
    valueBSave94 = 'zSqrArtSpecz94';
    var tripleBZeroA = localStorage.getItem(valueBSave94);
    document.getElementById("imgSqr95").src = tripleBZeroA;};

function artsquare95(){
    var sBQz95 = document.getElementById("aImgSqr96").src;
    valueBSave95 = 'zSqrArtSpecz95';
    localStorage.setItem(valueBSave95, sBQz95);
};
function squareBToSzzZValue95(){
    valueBSave95 = 'zSqrArtSpecz95';
    var tripleBZeroA = localStorage.getItem(valueBSave95);
    document.getElementById("imgSqr96").src = tripleBZeroA;};

function artsquare96(){
    var sBQz96 = document.getElementById("aImgSqr97").src;
    valueBSave96 = 'zSqrArtSpecz96';
    localStorage.setItem(valueBSave96, sBQz96);
};
function squareBToSzzZValue96(){
    valueBSave96 = 'zSqrArtSpecz96';
    var tripleBZeroA = localStorage.getItem(valueBSave96);
    document.getElementById("imgSqr97").src = tripleBZeroA;};

function artsquare97(){
    var sBQz97 = document.getElementById("aImgSqr98").src;
    valueBSave97 = 'zSqrArtSpecz97';
    localStorage.setItem(valueBSave97, sBQz97);
};
function squareBToSzzZValue97(){
    valueBSave97 = 'zSqrArtSpecz97';
    var tripleBZeroA = localStorage.getItem(valueBSave97);
    document.getElementById("imgSqr98").src = tripleBZeroA;};

function artsquare98(){
    var sBQz98 = document.getElementById("aImgSqr99").src;
    valueBSave98 = 'zSqrArtSpecz98';
    localStorage.setItem(valueBSave98, sBQz98);
};
function squareBToSzzZValue98(){
    valueBSave98 = 'zSqrArtSpecz98';
    var tripleBZeroA = localStorage.getItem(valueBSave98);
    document.getElementById("imgSqr99").src = tripleBZeroA;};

function artsquare99(){
    var sBQz99 = document.getElementById("aImgSqr100").src;
    valueBSave99 = 'zSqrArtSpecz99';
    localStorage.setItem(valueBSave99, sBQz99);
};
function squareBToSzzZValue99(){
    valueBSave99 = 'zSqrArtSpecz99';
    var tripleBZeroA = localStorage.getItem(valueBSave99);
    document.getElementById("imgSqr100").src = tripleBZeroA;};

function artsquare100(){
    var sBQz100 = document.getElementById("aImgSqr101").src;
    valueBSave100 = 'zSqrArtSpecz100';
    localStorage.setItem(valueBSave100, sBQz100);
};
function squareBToSzzZValue100(){
    valueBSave100 = 'zSqrArtSpecz100';
    var tripleBZeroA = localStorage.getItem(valueBSave100);
    document.getElementById("imgSqr101").src = tripleBZeroA;};

function artsquare101(){
    var sBQz101 = document.getElementById("aImgSqr102").src;
    valueBSave101 = 'zSqrArtSpecz101';
    localStorage.setItem(valueBSave101, sBQz101);
};
function squareBToSzzZValue101(){
    valueBSave101 = 'zSqrArtSpecz101';
    var tripleBZeroA = localStorage.getItem(valueBSave101);
    document.getElementById("imgSqr102").src = tripleBZeroA;};

function artsquare102(){
    var sBQz102 = document.getElementById("aImgSqr103").src;
    valueBSave102 = 'zSqrArtSpecz102';
    localStorage.setItem(valueBSave102, sBQz102);
};
function squareBToSzzZValue102(){
    valueBSave102 = 'zSqrArtSpecz102';
    var tripleBZeroA = localStorage.getItem(valueBSave102);
    document.getElementById("imgSqr103").src = tripleBZeroA;};

function artsquare103(){
    var sBQz103 = document.getElementById("aImgSqr104").src;
    valueBSave103 = 'zSqrArtSpecz103';
    localStorage.setItem(valueBSave103, sBQz103);
};
function squareBToSzzZValue103(){
    valueBSave103 = 'zSqrArtSpecz103';
    var tripleBZeroA = localStorage.getItem(valueBSave103);
    document.getElementById("imgSqr104").src = tripleBZeroA;};

function artsquare104(){
    var sBQz104 = document.getElementById("aImgSqr105").src;
    valueBSave104 = 'zSqrArtSpecz104';
    localStorage.setItem(valueBSave104, sBQz104);
};
function squareBToSzzZValue104(){
    valueBSave104 = 'zSqrArtSpecz104';
    var tripleBZeroA = localStorage.getItem(valueBSave104);
    document.getElementById("imgSqr105").src = tripleBZeroA;};

function artsquare105(){
    var sBQz105 = document.getElementById("aImgSqr106").src;
    valueBSave105 = 'zSqrArtSpecz105';
    localStorage.setItem(valueBSave105, sBQz105);
};
function squareBToSzzZValue105(){
    valueBSave105 = 'zSqrArtSpecz105';
    var tripleBZeroA = localStorage.getItem(valueBSave105);
    document.getElementById("imgSqr106").src = tripleBZeroA;};

function artsquare106(){
    var sBQz106 = document.getElementById("aImgSqr107").src;
    valueBSave106 = 'zSqrArtSpecz106';
    localStorage.setItem(valueBSave106, sBQz106);
};
function squareBToSzzZValue106(){
    valueBSave106 = 'zSqrArtSpecz106';
    var tripleBZeroA = localStorage.getItem(valueBSave106);
    document.getElementById("imgSqr107").src = tripleBZeroA;};

function artsquare107(){
    var sBQz107 = document.getElementById("aImgSqr108").src;
    valueBSave107 = 'zSqrArtSpecz107';
    localStorage.setItem(valueBSave107, sBQz107);
};
function squareBToSzzZValue107(){
    valueBSave107 = 'zSqrArtSpecz107';
    var tripleBZeroA = localStorage.getItem(valueBSave107);
    document.getElementById("imgSqr108").src = tripleBZeroA;};

function artsquare108(){
    var sBQz108 = document.getElementById("aImgSqr109").src;
    valueBSave108 = 'zSqrArtSpecz108';
    localStorage.setItem(valueBSave108, sBQz108);
};
function squareBToSzzZValue108(){
    valueBSave108 = 'zSqrArtSpecz108';
    var tripleBZeroA = localStorage.getItem(valueBSave108);
    document.getElementById("imgSqr109").src = tripleBZeroA;};

function artsquare109(){
    var sBQz109 = document.getElementById("aImgSqr110").src;
    valueBSave109 = 'zSqrArtSpecz109';
    localStorage.setItem(valueBSave109, sBQz109);
};
function squareBToSzzZValue109(){
    valueBSave109 = 'zSqrArtSpecz109';
    var tripleBZeroA = localStorage.getItem(valueBSave109);
    document.getElementById("imgSqr110").src = tripleBZeroA;};

function artsquare110(){
    var sBQz110 = document.getElementById("aImgSqr111").src;
    valueBSave110 = 'zSqrArtSpecz110';
    localStorage.setItem(valueBSave110, sBQz110);
};
function squareBToSzzZValue110(){
    valueBSave110 = 'zSqrArtSpecz110';
    var tripleBZeroA = localStorage.getItem(valueBSave110);
    document.getElementById("imgSqr111").src = tripleBZeroA;};

function artsquare111(){
    var sBQz111 = document.getElementById("aImgSqr112").src;
    valueBSave111 = 'zSqrArtSpecz111';
    localStorage.setItem(valueBSave111, sBQz111);
};
function squareBToSzzZValue111(){
    valueBSave111 = 'zSqrArtSpecz111';
    var tripleBZeroA = localStorage.getItem(valueBSave111);
    document.getElementById("imgSqr112").src = tripleBZeroA;};

function artsquare112(){
    var sBQz112 = document.getElementById("aImgSqr113").src;
    valueBSave112 = 'zSqrArtSpecz112';
    localStorage.setItem(valueBSave112, sBQz112);
};
function squareBToSzzZValue112(){
    valueBSave112 = 'zSqrArtSpecz112';
    var tripleBZeroA = localStorage.getItem(valueBSave112);
    document.getElementById("imgSqr113").src = tripleBZeroA;};

function artsquare113(){
    var sBQz113 = document.getElementById("aImgSqr114").src;
    valueBSave113 = 'zSqrArtSpecz113';
    localStorage.setItem(valueBSave113, sBQz113);
};
function squareBToSzzZValue113(){
    valueBSave113 = 'zSqrArtSpecz113';
    var tripleBZeroA = localStorage.getItem(valueBSave113);
    document.getElementById("imgSqr114").src = tripleBZeroA;};

function artsquare114(){
    var sBQz114 = document.getElementById("aImgSqr115").src;
    valueBSave114 = 'zSqrArtSpecz114';
    localStorage.setItem(valueBSave114, sBQz114);
};
function squareBToSzzZValue114(){
    valueBSave114 = 'zSqrArtSpecz114';
    var tripleBZeroA = localStorage.getItem(valueBSave114);
    document.getElementById("imgSqr115").src = tripleBZeroA;};

function artsquare115(){
    var sBQz115 = document.getElementById("aImgSqr116").src;
    valueBSave115 = 'zSqrArtSpecz115';
    localStorage.setItem(valueBSave115, sBQz115);
};
function squareBToSzzZValue115(){
    valueBSave115 = 'zSqrArtSpecz115';
    var tripleBZeroA = localStorage.getItem(valueBSave115);
    document.getElementById("imgSqr116").src = tripleBZeroA;};

function artsquare116(){
    var sBQz116 = document.getElementById("aImgSqr117").src;
    valueBSave116 = 'zSqrArtSpecz116';
    localStorage.setItem(valueBSave116, sBQz116);
};
function squareBToSzzZValue116(){
    valueBSave116 = 'zSqrArtSpecz116';
    var tripleBZeroA = localStorage.getItem(valueBSave116);
    document.getElementById("imgSqr117").src = tripleBZeroA;};

function artsquare117(){
    var sBQz117 = document.getElementById("aImgSqr118").src;
    valueBSave117 = 'zSqrArtSpecz117';
    localStorage.setItem(valueBSave117, sBQz117);
};
function squareBToSzzZValue117(){
    valueBSave117 = 'zSqrArtSpecz117';
    var tripleBZeroA = localStorage.getItem(valueBSave117);
    document.getElementById("imgSqr118").src = tripleBZeroA;};

function artsquare118(){
    var sBQz118 = document.getElementById("aImgSqr119").src;
    valueBSave118 = 'zSqrArtSpecz118';
    localStorage.setItem(valueBSave118, sBQz118);
};
function squareBToSzzZValue118(){
    valueBSave118 = 'zSqrArtSpecz118';
    var tripleBZeroA = localStorage.getItem(valueBSave118);
    document.getElementById("imgSqr119").src = tripleBZeroA;};

function artsquare119(){
    var sBQz119 = document.getElementById("aImgSqr120").src;
    valueBSave119 = 'zSqrArtSpecz119';
    localStorage.setItem(valueBSave119, sBQz119);
};
function squareBToSzzZValue119(){
    valueBSave119 = 'zSqrArtSpecz119';
    var tripleBZeroA = localStorage.getItem(valueBSave119);
    document.getElementById("imgSqr120").src = tripleBZeroA;};

function artsquare120(){
    var sBQz120 = document.getElementById("aImgSqr121").src;
    valueBSave120 = 'zSqrArtSpecz120';
    localStorage.setItem(valueBSave120, sBQz120);
};
function squareBToSzzZValue120(){
    valueBSave120 = 'zSqrArtSpecz120';
    var tripleBZeroA = localStorage.getItem(valueBSave120);
    document.getElementById("imgSqr121").src = tripleBZeroA;};

function artsquare121(){
    var sBQz121 = document.getElementById("aImgSqr122").src;
    valueBSave121 = 'zSqrArtSpecz121';
    localStorage.setItem(valueBSave121, sBQz121);
};
function squareBToSzzZValue121(){
    valueBSave121 = 'zSqrArtSpecz121';
    var tripleBZeroA = localStorage.getItem(valueBSave121);
    document.getElementById("imgSqr122").src = tripleBZeroA;};

function artsquare122(){
    var sBQz122 = document.getElementById("aImgSqr123").src;
    valueBSave122 = 'zSqrArtSpecz122';
    localStorage.setItem(valueBSave122, sBQz122);
};
function squareBToSzzZValue122(){
    valueBSave122 = 'zSqrArtSpecz122';
    var tripleBZeroA = localStorage.getItem(valueBSave122);
    document.getElementById("imgSqr123").src = tripleBZeroA;};

function artsquare123(){
    var sBQz123 = document.getElementById("aImgSqr124").src;
    valueBSave123 = 'zSqrArtSpecz123';
    localStorage.setItem(valueBSave123, sBQz123);
};
function squareBToSzzZValue123(){
    valueBSave123 = 'zSqrArtSpecz123';
    var tripleBZeroA = localStorage.getItem(valueBSave123);
    document.getElementById("imgSqr124").src = tripleBZeroA;};

function artsquare124(){
    var sBQz124 = document.getElementById("aImgSqr125").src;
    valueBSave124 = 'zSqrArtSpecz124';
    localStorage.setItem(valueBSave124, sBQz124);
};
function squareBToSzzZValue124(){
    valueBSave124 = 'zSqrArtSpecz124';
    var tripleBZeroA = localStorage.getItem(valueBSave124);
    document.getElementById("imgSqr125").src = tripleBZeroA;};

function artsquare125(){
    var sBQz125 = document.getElementById("aImgSqr126").src;
    valueBSave125 = 'zSqrArtSpecz125';
    localStorage.setItem(valueBSave125, sBQz125);
};
function squareBToSzzZValue125(){
    valueBSave125 = 'zSqrArtSpecz125';
    var tripleBZeroA = localStorage.getItem(valueBSave125);
    document.getElementById("imgSqr126").src = tripleBZeroA;};

function artsquare126(){
    var sBQz126 = document.getElementById("aImgSqr127").src;
    valueBSave126 = 'zSqrArtSpecz126';
    localStorage.setItem(valueBSave126, sBQz126);
};
function squareBToSzzZValue126(){
    valueBSave126 = 'zSqrArtSpecz126';
    var tripleBZeroA = localStorage.getItem(valueBSave126);
    document.getElementById("imgSqr127").src = tripleBZeroA;};

function artsquare127(){
    var sBQz127 = document.getElementById("aImgSqr128").src;
    valueBSave127 = 'zSqrArtSpecz127';
    localStorage.setItem(valueBSave127, sBQz127);
};
function squareBToSzzZValue127(){
    valueBSave127 = 'zSqrArtSpecz127';
    var tripleBZeroA = localStorage.getItem(valueBSave127);
    document.getElementById("imgSqr128").src = tripleBZeroA;};

function artsquare128(){
    var sBQz128 = document.getElementById("aImgSqr129").src;
    valueBSave128 = 'zSqrArtSpecz128';
    localStorage.setItem(valueBSave128, sBQz128);
};
function squareBToSzzZValue128(){
    valueBSave128 = 'zSqrArtSpecz128';
    var tripleBZeroA = localStorage.getItem(valueBSave128);
    document.getElementById("imgSqr129").src = tripleBZeroA;};

function artsquare129(){
    var sBQz129 = document.getElementById("aImgSqr130").src;
    valueBSave129 = 'zSqrArtSpecz129';
    localStorage.setItem(valueBSave129, sBQz129);
};
function squareBToSzzZValue129(){
    valueBSave129 = 'zSqrArtSpecz129';
    var tripleBZeroA = localStorage.getItem(valueBSave129);
    document.getElementById("imgSqr130").src = tripleBZeroA;};

function artsquare130(){
    var sBQz130 = document.getElementById("aImgSqr131").src;
    valueBSave130 = 'zSqrArtSpecz130';
    localStorage.setItem(valueBSave130, sBQz130);
};
function squareBToSzzZValue130(){
    valueBSave130 = 'zSqrArtSpecz130';
    var tripleBZeroA = localStorage.getItem(valueBSave130);
    document.getElementById("imgSqr131").src = tripleBZeroA;};

function artsquare131(){
    var sBQz131 = document.getElementById("aImgSqr132").src;
    valueBSave131 = 'zSqrArtSpecz131';
    localStorage.setItem(valueBSave131, sBQz131);
};
function squareBToSzzZValue131(){
    valueBSave131 = 'zSqrArtSpecz131';
    var tripleBZeroA = localStorage.getItem(valueBSave131);
    document.getElementById("imgSqr132").src = tripleBZeroA;};

function artsquare132(){
    var sBQz132 = document.getElementById("aImgSqr133").src;
    valueBSave132 = 'zSqrArtSpecz132';
    localStorage.setItem(valueBSave132, sBQz132);
};
function squareBToSzzZValue132(){
    valueBSave132 = 'zSqrArtSpecz132';
    var tripleBZeroA = localStorage.getItem(valueBSave132);
    document.getElementById("imgSqr133").src = tripleBZeroA;};

function artsquare133(){
    var sBQz133 = document.getElementById("aImgSqr134").src;
    valueBSave133 = 'zSqrArtSpecz133';
    localStorage.setItem(valueBSave133, sBQz133);
};
function squareBToSzzZValue133(){
    valueBSave133 = 'zSqrArtSpecz133';
    var tripleBZeroA = localStorage.getItem(valueBSave133);
    document.getElementById("imgSqr134").src = tripleBZeroA;};

function artsquare134(){
    var sBQz134 = document.getElementById("aImgSqr135").src;
    valueBSave134 = 'zSqrArtSpecz134';
    localStorage.setItem(valueBSave134, sBQz134);
};
function squareBToSzzZValue134(){
    valueBSave134 = 'zSqrArtSpecz134';
    var tripleBZeroA = localStorage.getItem(valueBSave134);
    document.getElementById("imgSqr135").src = tripleBZeroA;};

function artsquare135(){
    var sBQz135 = document.getElementById("aImgSqr136").src;
    valueBSave135 = 'zSqrArtSpecz135';
    localStorage.setItem(valueBSave135, sBQz135);
};
function squareBToSzzZValue135(){
    valueBSave135 = 'zSqrArtSpecz135';
    var tripleBZeroA = localStorage.getItem(valueBSave135);
    document.getElementById("imgSqr136").src = tripleBZeroA;};

function artsquare136(){
    var sBQz136 = document.getElementById("aImgSqr137").src;
    valueBSave136 = 'zSqrArtSpecz136';
    localStorage.setItem(valueBSave136, sBQz136);
};
function squareBToSzzZValue136(){
    valueBSave136 = 'zSqrArtSpecz136';
    var tripleBZeroA = localStorage.getItem(valueBSave136);
    document.getElementById("imgSqr137").src = tripleBZeroA;};

function artsquare137(){
    var sBQz137 = document.getElementById("aImgSqr138").src;
    valueBSave137 = 'zSqrArtSpecz137';
    localStorage.setItem(valueBSave137, sBQz137);
};
function squareBToSzzZValue137(){
    valueBSave137 = 'zSqrArtSpecz137';
    var tripleBZeroA = localStorage.getItem(valueBSave137);
    document.getElementById("imgSqr138").src = tripleBZeroA;};

function artsquare138(){
    var sBQz138 = document.getElementById("aImgSqr139").src;
    valueBSave138 = 'zSqrArtSpecz138';
    localStorage.setItem(valueBSave138, sBQz138);
};
function squareBToSzzZValue138(){
    valueBSave138 = 'zSqrArtSpecz138';
    var tripleBZeroA = localStorage.getItem(valueBSave138);
    document.getElementById("imgSqr139").src = tripleBZeroA;};

function artsquare139(){
    var sBQz139 = document.getElementById("aImgSqr140").src;
    valueBSave139 = 'zSqrArtSpecz139';
    localStorage.setItem(valueBSave139, sBQz139);
};
function squareBToSzzZValue139(){
    valueBSave139 = 'zSqrArtSpecz139';
    var tripleBZeroA = localStorage.getItem(valueBSave139);
    document.getElementById("imgSqr140").src = tripleBZeroA;};

function artsquare140(){
    var sBQz140 = document.getElementById("aImgSqr141").src;
    valueBSave140 = 'zSqrArtSpecz140';
    localStorage.setItem(valueBSave140, sBQz140);
};
function squareBToSzzZValue140(){
    valueBSave140 = 'zSqrArtSpecz140';
    var tripleBZeroA = localStorage.getItem(valueBSave140);
    document.getElementById("imgSqr141").src = tripleBZeroA;};

function artsquare141(){
    var sBQz141 = document.getElementById("aImgSqr142").src;
    valueBSave141 = 'zSqrArtSpecz141';
    localStorage.setItem(valueBSave141, sBQz141);
};
function squareBToSzzZValue141(){
    valueBSave141 = 'zSqrArtSpecz141';
    var tripleBZeroA = localStorage.getItem(valueBSave141);
    document.getElementById("imgSqr142").src = tripleBZeroA;};

function artsquare142(){
    var sBQz142 = document.getElementById("aImgSqr143").src;
    valueBSave142 = 'zSqrArtSpecz142';
    localStorage.setItem(valueBSave142, sBQz142);
};
function squareBToSzzZValue142(){
    valueBSave142 = 'zSqrArtSpecz142';
    var tripleBZeroA = localStorage.getItem(valueBSave142);
    document.getElementById("imgSqr143").src = tripleBZeroA;};

function artsquare143(){
    var sBQz143 = document.getElementById("aImgSqr144").src;
    valueBSave143 = 'zSqrArtSpecz143';
    localStorage.setItem(valueBSave143, sBQz143);
};
function squareBToSzzZValue143(){
    valueBSave143 = 'zSqrArtSpecz143';
    var tripleBZeroA = localStorage.getItem(valueBSave143);
    document.getElementById("imgSqr144").src = tripleBZeroA;};

function artsquare144(){
    var sBQz144 = document.getElementById("aImgSqr145").src;
    valueBSave144 = 'zSqrArtSpecz144';
    localStorage.setItem(valueBSave144, sBQz144);
};
function squareBToSzzZValue144(){
    valueBSave144 = 'zSqrArtSpecz144';
    var tripleBZeroA = localStorage.getItem(valueBSave144);
    document.getElementById("imgSqr145").src = tripleBZeroA;};

function artsquare145(){
    var sBQz145 = document.getElementById("aImgSqr146").src;
    valueBSave145 = 'zSqrArtSpecz145';
    localStorage.setItem(valueBSave145, sBQz145);
};
function squareBToSzzZValue145(){
    valueBSave145 = 'zSqrArtSpecz145';
    var tripleBZeroA = localStorage.getItem(valueBSave145);
    document.getElementById("imgSqr146").src = tripleBZeroA;};

function artsquare146(){
    var sBQz146 = document.getElementById("aImgSqr147").src;
    valueBSave146 = 'zSqrArtSpecz146';
    localStorage.setItem(valueBSave146, sBQz146);
};
function squareBToSzzZValue146(){
    valueBSave146 = 'zSqrArtSpecz146';
    var tripleBZeroA = localStorage.getItem(valueBSave146);
    document.getElementById("imgSqr147").src = tripleBZeroA;};

function artsquare147(){
    var sBQz147 = document.getElementById("aImgSqr148").src;
    valueBSave147 = 'zSqrArtSpecz147';
    localStorage.setItem(valueBSave147, sBQz147);
};
function squareBToSzzZValue147(){
    valueBSave147 = 'zSqrArtSpecz147';
    var tripleBZeroA = localStorage.getItem(valueBSave147);
    document.getElementById("imgSqr148").src = tripleBZeroA;};

function artsquare148(){
    var sBQz148 = document.getElementById("aImgSqr149").src;
    valueBSave148 = 'zSqrArtSpecz148';
    localStorage.setItem(valueBSave148, sBQz148);
};
function squareBToSzzZValue148(){
    valueBSave148 = 'zSqrArtSpecz148';
    var tripleBZeroA = localStorage.getItem(valueBSave148);
    document.getElementById("imgSqr149").src = tripleBZeroA;};

function artsquare149(){
    var sBQz149 = document.getElementById("aImgSqr150").src;
    valueBSave149 = 'zSqrArtSpecz149';
    localStorage.setItem(valueBSave149, sBQz149);
};
function squareBToSzzZValue149(){
    valueBSave149 = 'zSqrArtSpecz149';
    var tripleBZeroA = localStorage.getItem(valueBSave149);
    document.getElementById("imgSqr150").src = tripleBZeroA;};

function artsquare150(){
    var sBQz150 = document.getElementById("aImgSqr151").src;
    valueBSave150 = 'zSqrArtSpecz150';
    localStorage.setItem(valueBSave150, sBQz150);
};
function squareBToSzzZValue150(){
    valueBSave150 = 'zSqrArtSpecz150';
    var tripleBZeroA = localStorage.getItem(valueBSave150);
    document.getElementById("imgSqr151").src = tripleBZeroA;};

function artsquare151(){
    var sBQz151 = document.getElementById("aImgSqr152").src;
    valueBSave151 = 'zSqrArtSpecz151';
    localStorage.setItem(valueBSave151, sBQz151);
};
function squareBToSzzZValue151(){
    valueBSave151 = 'zSqrArtSpecz151';
    var tripleBZeroA = localStorage.getItem(valueBSave151);
    document.getElementById("imgSqr152").src = tripleBZeroA;};

function artsquare152(){
    var sBQz152 = document.getElementById("aImgSqr153").src;
    valueBSave152 = 'zSqrArtSpecz152';
    localStorage.setItem(valueBSave152, sBQz152);
};
function squareBToSzzZValue152(){
    valueBSave152 = 'zSqrArtSpecz152';
    var tripleBZeroA = localStorage.getItem(valueBSave152);
    document.getElementById("imgSqr153").src = tripleBZeroA;};

function artsquare153(){
    var sBQz153 = document.getElementById("aImgSqr154").src;
    valueBSave153 = 'zSqrArtSpecz153';
    localStorage.setItem(valueBSave153, sBQz153);
};
function squareBToSzzZValue153(){
    valueBSave153 = 'zSqrArtSpecz153';
    var tripleBZeroA = localStorage.getItem(valueBSave153);
    document.getElementById("imgSqr154").src = tripleBZeroA;};

function artsquare154(){
    var sBQz154 = document.getElementById("aImgSqr155").src;
    valueBSave154 = 'zSqrArtSpecz154';
    localStorage.setItem(valueBSave154, sBQz154);
};
function squareBToSzzZValue154(){
    valueBSave154 = 'zSqrArtSpecz154';
    var tripleBZeroA = localStorage.getItem(valueBSave154);
    document.getElementById("imgSqr155").src = tripleBZeroA;};

function artsquare155(){
    var sBQz155 = document.getElementById("aImgSqr156").src;
    valueBSave155 = 'zSqrArtSpecz155';
    localStorage.setItem(valueBSave155, sBQz155);
};
function squareBToSzzZValue155(){
    valueBSave155 = 'zSqrArtSpecz155';
    var tripleBZeroA = localStorage.getItem(valueBSave155);
    document.getElementById("imgSqr156").src = tripleBZeroA;};

function artsquare156(){
    var sBQz156 = document.getElementById("aImgSqr157").src;
    valueBSave156 = 'zSqrArtSpecz156';
    localStorage.setItem(valueBSave156, sBQz156);
};
function squareBToSzzZValue156(){
    valueBSave156 = 'zSqrArtSpecz156';
    var tripleBZeroA = localStorage.getItem(valueBSave156);
    document.getElementById("imgSqr157").src = tripleBZeroA;};

function artsquare157(){
    var sBQz157 = document.getElementById("aImgSqr158").src;
    valueBSave157 = 'zSqrArtSpecz157';
    localStorage.setItem(valueBSave157, sBQz157);
};
function squareBToSzzZValue157(){
    valueBSave157 = 'zSqrArtSpecz157';
    var tripleBZeroA = localStorage.getItem(valueBSave157);
    document.getElementById("imgSqr158").src = tripleBZeroA;};

function artsquare158(){
    var sBQz158 = document.getElementById("aImgSqr159").src;
    valueBSave158 = 'zSqrArtSpecz158';
    localStorage.setItem(valueBSave158, sBQz158);
};
function squareBToSzzZValue158(){
    valueBSave158 = 'zSqrArtSpecz158';
    var tripleBZeroA = localStorage.getItem(valueBSave158);
    document.getElementById("imgSqr159").src = tripleBZeroA;};

function artsquare159(){
    var sBQz159 = document.getElementById("aImgSqr160").src;
    valueBSave159 = 'zSqrArtSpecz159';
    localStorage.setItem(valueBSave159, sBQz159);
};
function squareBToSzzZValue159(){
    valueBSave159 = 'zSqrArtSpecz159';
    var tripleBZeroA = localStorage.getItem(valueBSave159);
    document.getElementById("imgSqr160").src = tripleBZeroA;};

function artsquare160(){
    var sBQz160 = document.getElementById("aImgSqr161").src;
    valueBSave160 = 'zSqrArtSpecz160';
    localStorage.setItem(valueBSave160, sBQz160);
};
function squareBToSzzZValue160(){
    valueBSave160 = 'zSqrArtSpecz160';
    var tripleBZeroA = localStorage.getItem(valueBSave160);
    document.getElementById("imgSqr161").src = tripleBZeroA;};

function artsquare161(){
    var sBQz161 = document.getElementById("aImgSqr162").src;
    valueBSave161 = 'zSqrArtSpecz161';
    localStorage.setItem(valueBSave161, sBQz161);
};
function squareBToSzzZValue161(){
    valueBSave161 = 'zSqrArtSpecz161';
    var tripleBZeroA = localStorage.getItem(valueBSave161);
    document.getElementById("imgSqr162").src = tripleBZeroA;};

function artsquare162(){
    var sBQz162 = document.getElementById("aImgSqr163").src;
    valueBSave162 = 'zSqrArtSpecz162';
    localStorage.setItem(valueBSave162, sBQz162);
};
function squareBToSzzZValue162(){
    valueBSave162 = 'zSqrArtSpecz162';
    var tripleBZeroA = localStorage.getItem(valueBSave162);
    document.getElementById("imgSqr163").src = tripleBZeroA;};

function artsquare163(){
    var sBQz163 = document.getElementById("aImgSqr164").src;
    valueBSave163 = 'zSqrArtSpecz163';
    localStorage.setItem(valueBSave163, sBQz163);
};
function squareBToSzzZValue163(){
    valueBSave163 = 'zSqrArtSpecz163';
    var tripleBZeroA = localStorage.getItem(valueBSave163);
    document.getElementById("imgSqr164").src = tripleBZeroA;};

function artsquare164(){
    var sBQz164 = document.getElementById("aImgSqr165").src;
    valueBSave164 = 'zSqrArtSpecz164';
    localStorage.setItem(valueBSave164, sBQz164);
};
function squareBToSzzZValue164(){
    valueBSave164 = 'zSqrArtSpecz164';
    var tripleBZeroA = localStorage.getItem(valueBSave164);
    document.getElementById("imgSqr165").src = tripleBZeroA;};

function artsquare165(){
    var sBQz165 = document.getElementById("aImgSqr166").src;
    valueBSave165 = 'zSqrArtSpecz165';
    localStorage.setItem(valueBSave165, sBQz165);
};
function squareBToSzzZValue165(){
    valueBSave165 = 'zSqrArtSpecz165';
    var tripleBZeroA = localStorage.getItem(valueBSave165);
    document.getElementById("imgSqr166").src = tripleBZeroA;};

function artsquare166(){
    var sBQz166 = document.getElementById("aImgSqr167").src;
    valueBSave166 = 'zSqrArtSpecz166';
    localStorage.setItem(valueBSave166, sBQz166);
};
function squareBToSzzZValue166(){
    valueBSave166 = 'zSqrArtSpecz166';
    var tripleBZeroA = localStorage.getItem(valueBSave166);
    document.getElementById("imgSqr167").src = tripleBZeroA;};

function artsquare167(){
    var sBQz167 = document.getElementById("aImgSqr168").src;
    valueBSave167 = 'zSqrArtSpecz167';
    localStorage.setItem(valueBSave167, sBQz167);
};
function squareBToSzzZValue167(){
    valueBSave167 = 'zSqrArtSpecz167';
    var tripleBZeroA = localStorage.getItem(valueBSave167);
    document.getElementById("imgSqr168").src = tripleBZeroA;};

function artsquare168(){
    var sBQz168 = document.getElementById("aImgSqr169").src;
    valueBSave168 = 'zSqrArtSpecz168';
    localStorage.setItem(valueBSave168, sBQz168);
};
function squareBToSzzZValue168(){
    valueBSave168 = 'zSqrArtSpecz168';
    var tripleBZeroA = localStorage.getItem(valueBSave168);
    document.getElementById("imgSqr169").src = tripleBZeroA;};

function artsquare169(){
    var sBQz169 = document.getElementById("aImgSqr170").src;
    valueBSave169 = 'zSqrArtSpecz169';
    localStorage.setItem(valueBSave169, sBQz169);
};
function squareBToSzzZValue169(){
    valueBSave169 = 'zSqrArtSpecz169';
    var tripleBZeroA = localStorage.getItem(valueBSave169);
    document.getElementById("imgSqr170").src = tripleBZeroA;};

function artsquare170(){
    var sBQz170 = document.getElementById("aImgSqr171").src;
    valueBSave170 = 'zSqrArtSpecz170';
    localStorage.setItem(valueBSave170, sBQz170);
};
function squareBToSzzZValue170(){
    valueBSave170 = 'zSqrArtSpecz170';
    var tripleBZeroA = localStorage.getItem(valueBSave170);
    document.getElementById("imgSqr171").src = tripleBZeroA;};

function artsquare171(){
    var sBQz171 = document.getElementById("aImgSqr172").src;
    valueBSave171 = 'zSqrArtSpecz171';
    localStorage.setItem(valueBSave171, sBQz171);
};
function squareBToSzzZValue171(){
    valueBSave171 = 'zSqrArtSpecz171';
    var tripleBZeroA = localStorage.getItem(valueBSave171);
    document.getElementById("imgSqr172").src = tripleBZeroA;};

function artsquare172(){
    var sBQz172 = document.getElementById("aImgSqr173").src;
    valueBSave172 = 'zSqrArtSpecz172';
    localStorage.setItem(valueBSave172, sBQz172);
};
function squareBToSzzZValue172(){
    valueBSave172 = 'zSqrArtSpecz172';
    var tripleBZeroA = localStorage.getItem(valueBSave172);
    document.getElementById("imgSqr173").src = tripleBZeroA;};

function artsquare173(){
    var sBQz173 = document.getElementById("aImgSqr174").src;
    valueBSave173 = 'zSqrArtSpecz173';
    localStorage.setItem(valueBSave173, sBQz173);
};
function squareBToSzzZValue173(){
    valueBSave173 = 'zSqrArtSpecz173';
    var tripleBZeroA = localStorage.getItem(valueBSave173);
    document.getElementById("imgSqr174").src = tripleBZeroA;};

function artsquare174(){
    var sBQz174 = document.getElementById("aImgSqr175").src;
    valueBSave174 = 'zSqrArtSpecz174';
    localStorage.setItem(valueBSave174, sBQz174);
};
function squareBToSzzZValue174(){
    valueBSave174 = 'zSqrArtSpecz174';
    var tripleBZeroA = localStorage.getItem(valueBSave174);
    document.getElementById("imgSqr175").src = tripleBZeroA;};

function artsquare175(){
    var sBQz175 = document.getElementById("aImgSqr176").src;
    valueBSave175 = 'zSqrArtSpecz175';
    localStorage.setItem(valueBSave175, sBQz175);
};
function squareBToSzzZValue175(){
    valueBSave175 = 'zSqrArtSpecz175';
    var tripleBZeroA = localStorage.getItem(valueBSave175);
    document.getElementById("imgSqr176").src = tripleBZeroA;};

function artsquare176(){
    var sBQz176 = document.getElementById("aImgSqr177").src;
    valueBSave176 = 'zSqrArtSpecz176';
    localStorage.setItem(valueBSave176, sBQz176);
};
function squareBToSzzZValue176(){
    valueBSave176 = 'zSqrArtSpecz176';
    var tripleBZeroA = localStorage.getItem(valueBSave176);
    document.getElementById("imgSqr177").src = tripleBZeroA;};

function artsquare177(){
    var sBQz177 = document.getElementById("aImgSqr178").src;
    valueBSave177 = 'zSqrArtSpecz177';
    localStorage.setItem(valueBSave177, sBQz177);
};
function squareBToSzzZValue177(){
    valueBSave177 = 'zSqrArtSpecz177';
    var tripleBZeroA = localStorage.getItem(valueBSave177);
    document.getElementById("imgSqr178").src = tripleBZeroA;};

function artsquare178(){
    var sBQz178 = document.getElementById("aImgSqr179").src;
    valueBSave178 = 'zSqrArtSpecz178';
    localStorage.setItem(valueBSave178, sBQz178);
};
function squareBToSzzZValue178(){
    valueBSave178 = 'zSqrArtSpecz178';
    var tripleBZeroA = localStorage.getItem(valueBSave178);
    document.getElementById("imgSqr179").src = tripleBZeroA;};

function artsquare179(){
    var sBQz179 = document.getElementById("aImgSqr180").src;
    valueBSave179 = 'zSqrArtSpecz179';
    localStorage.setItem(valueBSave179, sBQz179);
};
function squareBToSzzZValue179(){
    valueBSave179 = 'zSqrArtSpecz179';
    var tripleBZeroA = localStorage.getItem(valueBSave179);
    document.getElementById("imgSqr180").src = tripleBZeroA;};

function artsquare180(){
    var sBQz180 = document.getElementById("aImgSqr181").src;
    valueBSave180 = 'zSqrArtSpecz180';
    localStorage.setItem(valueBSave180, sBQz180);
};
function squareBToSzzZValue180(){
    valueBSave180 = 'zSqrArtSpecz180';
    var tripleBZeroA = localStorage.getItem(valueBSave180);
    document.getElementById("imgSqr181").src = tripleBZeroA;};

function artsquare181(){
    var sBQz181 = document.getElementById("aImgSqr182").src;
    valueBSave181 = 'zSqrArtSpecz181';
    localStorage.setItem(valueBSave181, sBQz181);
};
function squareBToSzzZValue181(){
    valueBSave181 = 'zSqrArtSpecz181';
    var tripleBZeroA = localStorage.getItem(valueBSave181);
    document.getElementById("imgSqr182").src = tripleBZeroA;};

function artsquare182(){
    var sBQz182 = document.getElementById("aImgSqr183").src;
    valueBSave182 = 'zSqrArtSpecz182';
    localStorage.setItem(valueBSave182, sBQz182);
};
function squareBToSzzZValue182(){
    valueBSave182 = 'zSqrArtSpecz182';
    var tripleBZeroA = localStorage.getItem(valueBSave182);
    document.getElementById("imgSqr183").src = tripleBZeroA;};

function artsquare183(){
    var sBQz183 = document.getElementById("aImgSqr184").src;
    valueBSave183 = 'zSqrArtSpecz183';
    localStorage.setItem(valueBSave183, sBQz183);
};
function squareBToSzzZValue183(){
    valueBSave183 = 'zSqrArtSpecz183';
    var tripleBZeroA = localStorage.getItem(valueBSave183);
    document.getElementById("imgSqr184").src = tripleBZeroA;};

function artsquare184(){
    var sBQz184 = document.getElementById("aImgSqr185").src;
    valueBSave184 = 'zSqrArtSpecz184';
    localStorage.setItem(valueBSave184, sBQz184);
};
function squareBToSzzZValue184(){
    valueBSave184 = 'zSqrArtSpecz184';
    var tripleBZeroA = localStorage.getItem(valueBSave184);
    document.getElementById("imgSqr185").src = tripleBZeroA;};

function artsquare185(){
    var sBQz185 = document.getElementById("aImgSqr186").src;
    valueBSave185 = 'zSqrArtSpecz185';
    localStorage.setItem(valueBSave185, sBQz185);
};
function squareBToSzzZValue185(){
    valueBSave185 = 'zSqrArtSpecz185';
    var tripleBZeroA = localStorage.getItem(valueBSave185);
    document.getElementById("imgSqr186").src = tripleBZeroA;};

function artsquare186(){
    var sBQz186 = document.getElementById("aImgSqr187").src;
    valueBSave186 = 'zSqrArtSpecz186';
    localStorage.setItem(valueBSave186, sBQz186);
};
function squareBToSzzZValue186(){
    valueBSave186 = 'zSqrArtSpecz186';
    var tripleBZeroA = localStorage.getItem(valueBSave186);
    document.getElementById("imgSqr187").src = tripleBZeroA;};

function artsquare187(){
    var sBQz187 = document.getElementById("aImgSqr188").src;
    valueBSave187 = 'zSqrArtSpecz187';
    localStorage.setItem(valueBSave187, sBQz187);
};
function squareBToSzzZValue187(){
    valueBSave187 = 'zSqrArtSpecz187';
    var tripleBZeroA = localStorage.getItem(valueBSave187);
    document.getElementById("imgSqr188").src = tripleBZeroA;};

function artsquare188(){
    var sBQz188 = document.getElementById("aImgSqr189").src;
    valueBSave188 = 'zSqrArtSpecz188';
    localStorage.setItem(valueBSave188, sBQz188);
};
function squareBToSzzZValue188(){
    valueBSave188 = 'zSqrArtSpecz188';
    var tripleBZeroA = localStorage.getItem(valueBSave188);
    document.getElementById("imgSqr189").src = tripleBZeroA;};

function artsquare189(){
    var sBQz189 = document.getElementById("aImgSqr190").src;
    valueBSave189 = 'zSqrArtSpecz189';
    localStorage.setItem(valueBSave189, sBQz189);
};
function squareBToSzzZValue189(){
    valueBSave189 = 'zSqrArtSpecz189';
    var tripleBZeroA = localStorage.getItem(valueBSave189);
    document.getElementById("imgSqr190").src = tripleBZeroA;};

function artsquare190(){
    var sBQz190 = document.getElementById("aImgSqr191").src;
    valueBSave190 = 'zSqrArtSpecz190';
    localStorage.setItem(valueBSave190, sBQz190);
};
function squareBToSzzZValue190(){
    valueBSave190 = 'zSqrArtSpecz190';
    var tripleBZeroA = localStorage.getItem(valueBSave190);
    document.getElementById("imgSqr191").src = tripleBZeroA;};

function artsquare191(){
    var sBQz191 = document.getElementById("aImgSqr192").src;
    valueBSave191 = 'zSqrArtSpecz191';
    localStorage.setItem(valueBSave191, sBQz191);
};
function squareBToSzzZValue191(){
    valueBSave191 = 'zSqrArtSpecz191';
    var tripleBZeroA = localStorage.getItem(valueBSave191);
    document.getElementById("imgSqr192").src = tripleBZeroA;};

function artsquare192(){
    var sBQz192 = document.getElementById("aImgSqr193").src;
    valueBSave192 = 'zSqrArtSpecz192';
    localStorage.setItem(valueBSave192, sBQz192);
};
function squareBToSzzZValue192(){
    valueBSave192 = 'zSqrArtSpecz192';
    var tripleBZeroA = localStorage.getItem(valueBSave192);
    document.getElementById("imgSqr193").src = tripleBZeroA;};

function artsquare193(){
    var sBQz193 = document.getElementById("aImgSqr194").src;
    valueBSave193 = 'zSqrArtSpecz193';
    localStorage.setItem(valueBSave193, sBQz193);
};
function squareBToSzzZValue193(){
    valueBSave193 = 'zSqrArtSpecz193';
    var tripleBZeroA = localStorage.getItem(valueBSave193);
    document.getElementById("imgSqr194").src = tripleBZeroA;};

function artsquare194(){
    var sBQz194 = document.getElementById("aImgSqr195").src;
    valueBSave194 = 'zSqrArtSpecz194';
    localStorage.setItem(valueBSave194, sBQz194);
};
function squareBToSzzZValue194(){
    valueBSave194 = 'zSqrArtSpecz194';
    var tripleBZeroA = localStorage.getItem(valueBSave194);
    document.getElementById("imgSqr195").src = tripleBZeroA;};

function artsquare195(){
    var sBQz195 = document.getElementById("aImgSqr196").src;
    valueBSave195 = 'zSqrArtSpecz195';
    localStorage.setItem(valueBSave195, sBQz195);
};
function squareBToSzzZValue195(){
    valueBSave195 = 'zSqrArtSpecz195';
    var tripleBZeroA = localStorage.getItem(valueBSave195);
    document.getElementById("imgSqr196").src = tripleBZeroA;};

function artsquare196(){
    var sBQz196 = document.getElementById("aImgSqr197").src;
    valueBSave196 = 'zSqrArtSpecz196';
    localStorage.setItem(valueBSave196, sBQz196);
};
function squareBToSzzZValue196(){
    valueBSave196 = 'zSqrArtSpecz196';
    var tripleBZeroA = localStorage.getItem(valueBSave196);
    document.getElementById("imgSqr197").src = tripleBZeroA;};

function artsquare197(){
    var sBQz197 = document.getElementById("aImgSqr198").src;
    valueBSave197 = 'zSqrArtSpecz197';
    localStorage.setItem(valueBSave197, sBQz197);
};
function squareBToSzzZValue197(){
    valueBSave197 = 'zSqrArtSpecz197';
    var tripleBZeroA = localStorage.getItem(valueBSave197);
    document.getElementById("imgSqr198").src = tripleBZeroA;};

function artsquare198(){
    var sBQz198 = document.getElementById("aImgSqr199").src;
    valueBSave198 = 'zSqrArtSpecz198';
    localStorage.setItem(valueBSave198, sBQz198);
};
function squareBToSzzZValue198(){
    valueBSave198 = 'zSqrArtSpecz198';
    var tripleBZeroA = localStorage.getItem(valueBSave198);
    document.getElementById("imgSqr199").src = tripleBZeroA;};

function artsquare199(){
    var sBQz199 = document.getElementById("aImgSqr200").src;
    valueBSave199 = 'zSqrArtSpecz199';
    localStorage.setItem(valueBSave199, sBQz199);
};
function squareBToSzzZValue199(){
    valueBSave199 = 'zSqrArtSpecz199';
    var tripleBZeroA = localStorage.getItem(valueBSave199);
    document.getElementById("imgSqr200").src = tripleBZeroA;};

function artsquare200(){
    var sBQz200 = document.getElementById("aImgSqr201").src;
    valueBSave200 = 'zSqrArtSpecz200';
    localStorage.setItem(valueBSave200, sBQz200);
};
function squareBToSzzZValue200(){
    valueBSave200 = 'zSqrArtSpecz200';
    var tripleBZeroA = localStorage.getItem(valueBSave200);
    document.getElementById("imgSqr201").src = tripleBZeroA;};

function artsquare201(){
    var sBQz201 = document.getElementById("aImgSqr202").src;
    valueBSave201 = 'zSqrArtSpecz201';
    localStorage.setItem(valueBSave201, sBQz201);
};
function squareBToSzzZValue201(){
    valueBSave201 = 'zSqrArtSpecz201';
    var tripleBZeroA = localStorage.getItem(valueBSave201);
    document.getElementById("imgSqr202").src = tripleBZeroA;};

function artsquare202(){
    var sBQz202 = document.getElementById("aImgSqr203").src;
    valueBSave202 = 'zSqrArtSpecz202';
    localStorage.setItem(valueBSave202, sBQz202);
};
function squareBToSzzZValue202(){
    valueBSave202 = 'zSqrArtSpecz202';
    var tripleBZeroA = localStorage.getItem(valueBSave202);
    document.getElementById("imgSqr203").src = tripleBZeroA;};

function artsquare203(){
    var sBQz203 = document.getElementById("aImgSqr204").src;
    valueBSave203 = 'zSqrArtSpecz203';
    localStorage.setItem(valueBSave203, sBQz203);
};
function squareBToSzzZValue203(){
    valueBSave203 = 'zSqrArtSpecz203';
    var tripleBZeroA = localStorage.getItem(valueBSave203);
    document.getElementById("imgSqr204").src = tripleBZeroA;};

function artsquare204(){
    var sBQz204 = document.getElementById("aImgSqr205").src;
    valueBSave204 = 'zSqrArtSpecz204';
    localStorage.setItem(valueBSave204, sBQz204);
};
function squareBToSzzZValue204(){
    valueBSave204 = 'zSqrArtSpecz204';
    var tripleBZeroA = localStorage.getItem(valueBSave204);
    document.getElementById("imgSqr205").src = tripleBZeroA;};

function artsquare205(){
    var sBQz205 = document.getElementById("aImgSqr206").src;
    valueBSave205 = 'zSqrArtSpecz205';
    localStorage.setItem(valueBSave205, sBQz205);
};
function squareBToSzzZValue205(){
    valueBSave205 = 'zSqrArtSpecz205';
    var tripleBZeroA = localStorage.getItem(valueBSave205);
    document.getElementById("imgSqr206").src = tripleBZeroA;};

function artsquare206(){
    var sBQz206 = document.getElementById("aImgSqr207").src;
    valueBSave206 = 'zSqrArtSpecz206';
    localStorage.setItem(valueBSave206, sBQz206);
};
function squareBToSzzZValue206(){
    valueBSave206 = 'zSqrArtSpecz206';
    var tripleBZeroA = localStorage.getItem(valueBSave206);
    document.getElementById("imgSqr207").src = tripleBZeroA;};

function artsquare207(){
    var sBQz207 = document.getElementById("aImgSqr208").src;
    valueBSave207 = 'zSqrArtSpecz207';
    localStorage.setItem(valueBSave207, sBQz207);
};
function squareBToSzzZValue207(){
    valueBSave207 = 'zSqrArtSpecz207';
    var tripleBZeroA = localStorage.getItem(valueBSave207);
    document.getElementById("imgSqr208").src = tripleBZeroA;};

function artsquare208(){
    var sBQz208 = document.getElementById("aImgSqr209").src;
    valueBSave208 = 'zSqrArtSpecz208';
    localStorage.setItem(valueBSave208, sBQz208);
};
function squareBToSzzZValue208(){
    valueBSave208 = 'zSqrArtSpecz208';
    var tripleBZeroA = localStorage.getItem(valueBSave208);
    document.getElementById("imgSqr209").src = tripleBZeroA;};

function artsquare209(){
    var sBQz209 = document.getElementById("aImgSqr210").src;
    valueBSave209 = 'zSqrArtSpecz209';
    localStorage.setItem(valueBSave209, sBQz209);
};
function squareBToSzzZValue209(){
    valueBSave209 = 'zSqrArtSpecz209';
    var tripleBZeroA = localStorage.getItem(valueBSave209);
    document.getElementById("imgSqr210").src = tripleBZeroA;};

function artsquare210(){
    var sBQz210 = document.getElementById("aImgSqr211").src;
    valueBSave210 = 'zSqrArtSpecz210';
    localStorage.setItem(valueBSave210, sBQz210);
};
function squareBToSzzZValue210(){
    valueBSave210 = 'zSqrArtSpecz210';
    var tripleBZeroA = localStorage.getItem(valueBSave210);
    document.getElementById("imgSqr211").src = tripleBZeroA;};

function artsquare211(){
    var sBQz211 = document.getElementById("aImgSqr212").src;
    valueBSave211 = 'zSqrArtSpecz211';
    localStorage.setItem(valueBSave211, sBQz211);
};
function squareBToSzzZValue211(){
    valueBSave211 = 'zSqrArtSpecz211';
    var tripleBZeroA = localStorage.getItem(valueBSave211);
    document.getElementById("imgSqr212").src = tripleBZeroA;};

function artsquare212(){
    var sBQz212 = document.getElementById("aImgSqr213").src;
    valueBSave212 = 'zSqrArtSpecz212';
    localStorage.setItem(valueBSave212, sBQz212);
};
function squareBToSzzZValue212(){
    valueBSave212 = 'zSqrArtSpecz212';
    var tripleBZeroA = localStorage.getItem(valueBSave212);
    document.getElementById("imgSqr213").src = tripleBZeroA;};

function artsquare213(){
    var sBQz213 = document.getElementById("aImgSqr214").src;
    valueBSave213 = 'zSqrArtSpecz213';
    localStorage.setItem(valueBSave213, sBQz213);
};
function squareBToSzzZValue213(){
    valueBSave213 = 'zSqrArtSpecz213';
    var tripleBZeroA = localStorage.getItem(valueBSave213);
    document.getElementById("imgSqr214").src = tripleBZeroA;};

function artsquare214(){
    var sBQz214 = document.getElementById("aImgSqr215").src;
    valueBSave214 = 'zSqrArtSpecz214';
    localStorage.setItem(valueBSave214, sBQz214);
};
function squareBToSzzZValue214(){
    valueBSave214 = 'zSqrArtSpecz214';
    var tripleBZeroA = localStorage.getItem(valueBSave214);
    document.getElementById("imgSqr215").src = tripleBZeroA;};

function artsquare215(){
    var sBQz215 = document.getElementById("aImgSqr216").src;
    valueBSave215 = 'zSqrArtSpecz215';
    localStorage.setItem(valueBSave215, sBQz215);
};
function squareBToSzzZValue215(){
    valueBSave215 = 'zSqrArtSpecz215';
    var tripleBZeroA = localStorage.getItem(valueBSave215);
    document.getElementById("imgSqr216").src = tripleBZeroA;};

function artsquare216(){
    var sBQz216 = document.getElementById("aImgSqr217").src;
    valueBSave216 = 'zSqrArtSpecz216';
    localStorage.setItem(valueBSave216, sBQz216);
};
function squareBToSzzZValue216(){
    valueBSave216 = 'zSqrArtSpecz216';
    var tripleBZeroA = localStorage.getItem(valueBSave216);
    document.getElementById("imgSqr217").src = tripleBZeroA;};

function artsquare217(){
    var sBQz217 = document.getElementById("aImgSqr218").src;
    valueBSave217 = 'zSqrArtSpecz217';
    localStorage.setItem(valueBSave217, sBQz217);
};
function squareBToSzzZValue217(){
    valueBSave217 = 'zSqrArtSpecz217';
    var tripleBZeroA = localStorage.getItem(valueBSave217);
    document.getElementById("imgSqr218").src = tripleBZeroA;};

function artsquare218(){
    var sBQz218 = document.getElementById("aImgSqr219").src;
    valueBSave218 = 'zSqrArtSpecz218';
    localStorage.setItem(valueBSave218, sBQz218);
};
function squareBToSzzZValue218(){
    valueBSave218 = 'zSqrArtSpecz218';
    var tripleBZeroA = localStorage.getItem(valueBSave218);
    document.getElementById("imgSqr219").src = tripleBZeroA;};

function artsquare219(){
    var sBQz219 = document.getElementById("aImgSqr220").src;
    valueBSave219 = 'zSqrArtSpecz219';
    localStorage.setItem(valueBSave219, sBQz219);
};
function squareBToSzzZValue219(){
    valueBSave219 = 'zSqrArtSpecz219';
    var tripleBZeroA = localStorage.getItem(valueBSave219);
    document.getElementById("imgSqr220").src = tripleBZeroA;};

function artsquare220(){
    var sBQz220 = document.getElementById("aImgSqr221").src;
    valueBSave220 = 'zSqrArtSpecz220';
    localStorage.setItem(valueBSave220, sBQz220);
};
function squareBToSzzZValue220(){
    valueBSave220 = 'zSqrArtSpecz220';
    var tripleBZeroA = localStorage.getItem(valueBSave220);
    document.getElementById("imgSqr221").src = tripleBZeroA;};

function artsquare221(){
    var sBQz221 = document.getElementById("aImgSqr222").src;
    valueBSave221 = 'zSqrArtSpecz221';
    localStorage.setItem(valueBSave221, sBQz221);
};
function squareBToSzzZValue221(){
    valueBSave221 = 'zSqrArtSpecz221';
    var tripleBZeroA = localStorage.getItem(valueBSave221);
    document.getElementById("imgSqr222").src = tripleBZeroA;};

function artsquare222(){
    var sBQz222 = document.getElementById("aImgSqr223").src;
    valueBSave222 = 'zSqrArtSpecz222';
    localStorage.setItem(valueBSave222, sBQz222);
};
function squareBToSzzZValue222(){
    valueBSave222 = 'zSqrArtSpecz222';
    var tripleBZeroA = localStorage.getItem(valueBSave222);
    document.getElementById("imgSqr223").src = tripleBZeroA;};

function artsquare223(){
    var sBQz223 = document.getElementById("aImgSqr224").src;
    valueBSave223 = 'zSqrArtSpecz223';
    localStorage.setItem(valueBSave223, sBQz223);
};
function squareBToSzzZValue223(){
    valueBSave223 = 'zSqrArtSpecz223';
    var tripleBZeroA = localStorage.getItem(valueBSave223);
    document.getElementById("imgSqr224").src = tripleBZeroA;};

function artsquare224(){
    var sBQz224 = document.getElementById("aImgSqr225").src;
    valueBSave224 = 'zSqrArtSpecz224';
    localStorage.setItem(valueBSave224, sBQz224);
};
function squareBToSzzZValue224(){
    valueBSave224 = 'zSqrArtSpecz224';
    var tripleBZeroA = localStorage.getItem(valueBSave224);
    document.getElementById("imgSqr225").src = tripleBZeroA;};

function artsquare225(){
    var sBQz225 = document.getElementById("aImgSqr226").src;
    valueBSave225 = 'zSqrArtSpecz225';
    localStorage.setItem(valueBSave225, sBQz225);
};
function squareBToSzzZValue225(){
    valueBSave225 = 'zSqrArtSpecz225';
    var tripleBZeroA = localStorage.getItem(valueBSave225);
    document.getElementById("imgSqr226").src = tripleBZeroA;};

function artsquare226(){
    var sBQz226 = document.getElementById("aImgSqr227").src;
    valueBSave226 = 'zSqrArtSpecz226';
    localStorage.setItem(valueBSave226, sBQz226);
};
function squareBToSzzZValue226(){
    valueBSave226 = 'zSqrArtSpecz226';
    var tripleBZeroA = localStorage.getItem(valueBSave226);
    document.getElementById("imgSqr227").src = tripleBZeroA;};

function artsquare227(){
    var sBQz227 = document.getElementById("aImgSqr228").src;
    valueBSave227 = 'zSqrArtSpecz227';
    localStorage.setItem(valueBSave227, sBQz227);
};
function squareBToSzzZValue227(){
    valueBSave227 = 'zSqrArtSpecz227';
    var tripleBZeroA = localStorage.getItem(valueBSave227);
    document.getElementById("imgSqr228").src = tripleBZeroA;};

function artsquare228(){
    var sBQz228 = document.getElementById("aImgSqr229").src;
    valueBSave228 = 'zSqrArtSpecz228';
    localStorage.setItem(valueBSave228, sBQz228);
};
function squareBToSzzZValue228(){
    valueBSave228 = 'zSqrArtSpecz228';
    var tripleBZeroA = localStorage.getItem(valueBSave228);
    document.getElementById("imgSqr229").src = tripleBZeroA;};

function artsquare229(){
    var sBQz229 = document.getElementById("aImgSqr230").src;
    valueBSave229 = 'zSqrArtSpecz229';
    localStorage.setItem(valueBSave229, sBQz229);
};
function squareBToSzzZValue229(){
    valueBSave229 = 'zSqrArtSpecz229';
    var tripleBZeroA = localStorage.getItem(valueBSave229);
    document.getElementById("imgSqr230").src = tripleBZeroA;};

function artsquare230(){
    var sBQz230 = document.getElementById("aImgSqr231").src;
    valueBSave230 = 'zSqrArtSpecz230';
    localStorage.setItem(valueBSave230, sBQz230);
};
function squareBToSzzZValue230(){
    valueBSave230 = 'zSqrArtSpecz230';
    var tripleBZeroA = localStorage.getItem(valueBSave230);
    document.getElementById("imgSqr231").src = tripleBZeroA;};

function artsquare231(){
    var sBQz231 = document.getElementById("aImgSqr232").src;
    valueBSave231 = 'zSqrArtSpecz231';
    localStorage.setItem(valueBSave231, sBQz231);
};
function squareBToSzzZValue231(){
    valueBSave231 = 'zSqrArtSpecz231';
    var tripleBZeroA = localStorage.getItem(valueBSave231);
    document.getElementById("imgSqr232").src = tripleBZeroA;};

function artsquare232(){
    var sBQz232 = document.getElementById("aImgSqr233").src;
    valueBSave232 = 'zSqrArtSpecz232';
    localStorage.setItem(valueBSave232, sBQz232);
};
function squareBToSzzZValue232(){
    valueBSave232 = 'zSqrArtSpecz232';
    var tripleBZeroA = localStorage.getItem(valueBSave232);
    document.getElementById("imgSqr233").src = tripleBZeroA;};

function artsquare233(){
    var sBQz233 = document.getElementById("aImgSqr234").src;
    valueBSave233 = 'zSqrArtSpecz233';
    localStorage.setItem(valueBSave233, sBQz233);
};
function squareBToSzzZValue233(){
    valueBSave233 = 'zSqrArtSpecz233';
    var tripleBZeroA = localStorage.getItem(valueBSave233);
    document.getElementById("imgSqr234").src = tripleBZeroA;};

function artsquare234(){
    var sBQz234 = document.getElementById("aImgSqr235").src;
    valueBSave234 = 'zSqrArtSpecz234';
    localStorage.setItem(valueBSave234, sBQz234);
};
function squareBToSzzZValue234(){
    valueBSave234 = 'zSqrArtSpecz234';
    var tripleBZeroA = localStorage.getItem(valueBSave234);
    document.getElementById("imgSqr235").src = tripleBZeroA;};

function artsquare235(){
    var sBQz235 = document.getElementById("aImgSqr236").src;
    valueBSave235 = 'zSqrArtSpecz235';
    localStorage.setItem(valueBSave235, sBQz235);
};
function squareBToSzzZValue235(){
    valueBSave235 = 'zSqrArtSpecz235';
    var tripleBZeroA = localStorage.getItem(valueBSave235);
    document.getElementById("imgSqr236").src = tripleBZeroA;};

function artsquare236(){
    var sBQz236 = document.getElementById("aImgSqr237").src;
    valueBSave236 = 'zSqrArtSpecz236';
    localStorage.setItem(valueBSave236, sBQz236);
};
function squareBToSzzZValue236(){
    valueBSave236 = 'zSqrArtSpecz236';
    var tripleBZeroA = localStorage.getItem(valueBSave236);
    document.getElementById("imgSqr237").src = tripleBZeroA;};

function artsquare237(){
    var sBQz237 = document.getElementById("aImgSqr238").src;
    valueBSave237 = 'zSqrArtSpecz237';
    localStorage.setItem(valueBSave237, sBQz237);
};
function squareBToSzzZValue237(){
    valueBSave237 = 'zSqrArtSpecz237';
    var tripleBZeroA = localStorage.getItem(valueBSave237);
    document.getElementById("imgSqr238").src = tripleBZeroA;};

function artsquare238(){
    var sBQz238 = document.getElementById("aImgSqr239").src;
    valueBSave238 = 'zSqrArtSpecz238';
    localStorage.setItem(valueBSave238, sBQz238);
};
function squareBToSzzZValue238(){
    valueBSave238 = 'zSqrArtSpecz238';
    var tripleBZeroA = localStorage.getItem(valueBSave238);
    document.getElementById("imgSqr239").src = tripleBZeroA;};

function artsquare239(){
    var sBQz239 = document.getElementById("aImgSqr240").src;
    valueBSave239 = 'zSqrArtSpecz239';
    localStorage.setItem(valueBSave239, sBQz239);
};
function squareBToSzzZValue239(){
    valueBSave239 = 'zSqrArtSpecz239';
    var tripleBZeroA = localStorage.getItem(valueBSave239);
    document.getElementById("imgSqr240").src = tripleBZeroA;};

function artsquare240(){
    var sBQz240 = document.getElementById("aImgSqr241").src;
    valueBSave240 = 'zSqrArtSpecz240';
    localStorage.setItem(valueBSave240, sBQz240);
};
function squareBToSzzZValue240(){
    valueBSave240 = 'zSqrArtSpecz240';
    var tripleBZeroA = localStorage.getItem(valueBSave240);
    document.getElementById("imgSqr241").src = tripleBZeroA;};

function artsquare241(){
    var sBQz241 = document.getElementById("aImgSqr242").src;
    valueBSave241 = 'zSqrArtSpecz241';
    localStorage.setItem(valueBSave241, sBQz241);
};
function squareBToSzzZValue241(){
    valueBSave241 = 'zSqrArtSpecz241';
    var tripleBZeroA = localStorage.getItem(valueBSave241);
    document.getElementById("imgSqr242").src = tripleBZeroA;};

function artsquare242(){
    var sBQz242 = document.getElementById("aImgSqr243").src;
    valueBSave242 = 'zSqrArtSpecz242';
    localStorage.setItem(valueBSave242, sBQz242);
};
function squareBToSzzZValue242(){
    valueBSave242 = 'zSqrArtSpecz242';
    var tripleBZeroA = localStorage.getItem(valueBSave242);
    document.getElementById("imgSqr243").src = tripleBZeroA;};

function artsquare243(){
    var sBQz243 = document.getElementById("aImgSqr244").src;
    valueBSave243 = 'zSqrArtSpecz243';
    localStorage.setItem(valueBSave243, sBQz243);
};
function squareBToSzzZValue243(){
    valueBSave243 = 'zSqrArtSpecz243';
    var tripleBZeroA = localStorage.getItem(valueBSave243);
    document.getElementById("imgSqr244").src = tripleBZeroA;};

function artsquare244(){
    var sBQz244 = document.getElementById("aImgSqr245").src;
    valueBSave244 = 'zSqrArtSpecz244';
    localStorage.setItem(valueBSave244, sBQz244);
};
function squareBToSzzZValue244(){
    valueBSave244 = 'zSqrArtSpecz244';
    var tripleBZeroA = localStorage.getItem(valueBSave244);
    document.getElementById("imgSqr245").src = tripleBZeroA;};

function artsquare245(){
    var sBQz245 = document.getElementById("aImgSqr246").src;
    valueBSave245 = 'zSqrArtSpecz245';
    localStorage.setItem(valueBSave245, sBQz245);
};
function squareBToSzzZValue245(){
    valueBSave245 = 'zSqrArtSpecz245';
    var tripleBZeroA = localStorage.getItem(valueBSave245);
    document.getElementById("imgSqr246").src = tripleBZeroA;};

function artsquare246(){
    var sBQz246 = document.getElementById("aImgSqr247").src;
    valueBSave246 = 'zSqrArtSpecz246';
    localStorage.setItem(valueBSave246, sBQz246);
};
function squareBToSzzZValue246(){
    valueBSave246 = 'zSqrArtSpecz246';
    var tripleBZeroA = localStorage.getItem(valueBSave246);
    document.getElementById("imgSqr247").src = tripleBZeroA;};

function artsquare247(){
    var sBQz247 = document.getElementById("aImgSqr248").src;
    valueBSave247 = 'zSqrArtSpecz247';
    localStorage.setItem(valueBSave247, sBQz247);
};
function squareBToSzzZValue247(){
    valueBSave247 = 'zSqrArtSpecz247';
    var tripleBZeroA = localStorage.getItem(valueBSave247);
    document.getElementById("imgSqr248").src = tripleBZeroA;};

function artsquare248(){
    var sBQz248 = document.getElementById("aImgSqr249").src;
    valueBSave248 = 'zSqrArtSpecz248';
    localStorage.setItem(valueBSave248, sBQz248);
};
function squareBToSzzZValue248(){
    valueBSave248 = 'zSqrArtSpecz248';
    var tripleBZeroA = localStorage.getItem(valueBSave248);
    document.getElementById("imgSqr249").src = tripleBZeroA;};

function artsquare249(){
    var sBQz249 = document.getElementById("aImgSqr250").src;
    valueBSave249 = 'zSqrArtSpecz249';
    localStorage.setItem(valueBSave249, sBQz249);
};
function squareBToSzzZValue249(){
    valueBSave249 = 'zSqrArtSpecz249';
    var tripleBZeroA = localStorage.getItem(valueBSave249);
    document.getElementById("imgSqr250").src = tripleBZeroA;};

function artsquare250(){
    var sBQz250 = document.getElementById("aImgSqr251").src;
    valueBSave250 = 'zSqrArtSpecz250';
    localStorage.setItem(valueBSave250, sBQz250);
};
function squareBToSzzZValue250(){
    valueBSave250 = 'zSqrArtSpecz250';
    var tripleBZeroA = localStorage.getItem(valueBSave250);
    document.getElementById("imgSqr251").src = tripleBZeroA;};

function artsquare251(){
    var sBQz251 = document.getElementById("aImgSqr252").src;
    valueBSave251 = 'zSqrArtSpecz251';
    localStorage.setItem(valueBSave251, sBQz251);
};
function squareBToSzzZValue251(){
    valueBSave251 = 'zSqrArtSpecz251';
    var tripleBZeroA = localStorage.getItem(valueBSave251);
    document.getElementById("imgSqr252").src = tripleBZeroA;};

function artsquare252(){
    var sBQz252 = document.getElementById("aImgSqr253").src;
    valueBSave252 = 'zSqrArtSpecz252';
    localStorage.setItem(valueBSave252, sBQz252);
};
function squareBToSzzZValue252(){
    valueBSave252 = 'zSqrArtSpecz252';
    var tripleBZeroA = localStorage.getItem(valueBSave252);
    document.getElementById("imgSqr253").src = tripleBZeroA;};

function artsquare253(){
    var sBQz253 = document.getElementById("aImgSqr254").src;
    valueBSave253 = 'zSqrArtSpecz253';
    localStorage.setItem(valueBSave253, sBQz253);
};
function squareBToSzzZValue253(){
    valueBSave253 = 'zSqrArtSpecz253';
    var tripleBZeroA = localStorage.getItem(valueBSave253);
    document.getElementById("imgSqr254").src = tripleBZeroA;};

function artsquare254(){
    var sBQz254 = document.getElementById("aImgSqr255").src;
    valueBSave254 = 'zSqrArtSpecz254';
    localStorage.setItem(valueBSave254, sBQz254);
};
function squareBToSzzZValue254(){
    valueBSave254 = 'zSqrArtSpecz254';
    var tripleBZeroA = localStorage.getItem(valueBSave254);
    document.getElementById("imgSqr255").src = tripleBZeroA;};

function artsquare255(){
    var sBQz255 = document.getElementById("aImgSqr256").src;
    valueBSave255 = 'zSqrArtSpecz255';
    localStorage.setItem(valueBSave255, sBQz255);
};
function squareBToSzzZValue255(){
    valueBSave255 = 'zSqrArtSpecz255';
    var tripleBZeroA = localStorage.getItem(valueBSave255);
    document.getElementById("imgSqr256").src = tripleBZeroA;};

function artsquare256(){
    var sBQz256 = document.getElementById("aImgSqr257").src;
    valueBSave256 = 'zSqrArtSpecz256';
    localStorage.setItem(valueBSave256, sBQz256);
};
function squareBToSzzZValue256(){
    valueBSave256 = 'zSqrArtSpecz256';
    var tripleBZeroA = localStorage.getItem(valueBSave256);
    document.getElementById("imgSqr257").src = tripleBZeroA;};

function artsquare257(){
    var sBQz257 = document.getElementById("aImgSqr258").src;
    valueBSave257 = 'zSqrArtSpecz257';
    localStorage.setItem(valueBSave257, sBQz257);
};
function squareBToSzzZValue257(){
    valueBSave257 = 'zSqrArtSpecz257';
    var tripleBZeroA = localStorage.getItem(valueBSave257);
    document.getElementById("imgSqr258").src = tripleBZeroA;};

function artsquare258(){
    var sBQz258 = document.getElementById("aImgSqr259").src;
    valueBSave258 = 'zSqrArtSpecz258';
    localStorage.setItem(valueBSave258, sBQz258);
};
function squareBToSzzZValue258(){
    valueBSave258 = 'zSqrArtSpecz258';
    var tripleBZeroA = localStorage.getItem(valueBSave258);
    document.getElementById("imgSqr259").src = tripleBZeroA;};

function artsquare259(){
    var sBQz259 = document.getElementById("aImgSqr260").src;
    valueBSave259 = 'zSqrArtSpecz259';
    localStorage.setItem(valueBSave259, sBQz259);
};
function squareBToSzzZValue259(){
    valueBSave259 = 'zSqrArtSpecz259';
    var tripleBZeroA = localStorage.getItem(valueBSave259);
    document.getElementById("imgSqr260").src = tripleBZeroA;};

function artsquare260(){
    var sBQz260 = document.getElementById("aImgSqr261").src;
    valueBSave260 = 'zSqrArtSpecz260';
    localStorage.setItem(valueBSave260, sBQz260);
};
function squareBToSzzZValue260(){
    valueBSave260 = 'zSqrArtSpecz260';
    var tripleBZeroA = localStorage.getItem(valueBSave260);
    document.getElementById("imgSqr261").src = tripleBZeroA;};

function artsquare261(){
    var sBQz261 = document.getElementById("aImgSqr262").src;
    valueBSave261 = 'zSqrArtSpecz261';
    localStorage.setItem(valueBSave261, sBQz261);
};
function squareBToSzzZValue261(){
    valueBSave261 = 'zSqrArtSpecz261';
    var tripleBZeroA = localStorage.getItem(valueBSave261);
    document.getElementById("imgSqr262").src = tripleBZeroA;};

function artsquare262(){
    var sBQz262 = document.getElementById("aImgSqr263").src;
    valueBSave262 = 'zSqrArtSpecz262';
    localStorage.setItem(valueBSave262, sBQz262);
};
function squareBToSzzZValue262(){
    valueBSave262 = 'zSqrArtSpecz262';
    var tripleBZeroA = localStorage.getItem(valueBSave262);
    document.getElementById("imgSqr263").src = tripleBZeroA;};

function artsquare263(){
    var sBQz263 = document.getElementById("aImgSqr264").src;
    valueBSave263 = 'zSqrArtSpecz263';
    localStorage.setItem(valueBSave263, sBQz263);
};
function squareBToSzzZValue263(){
    valueBSave263 = 'zSqrArtSpecz263';
    var tripleBZeroA = localStorage.getItem(valueBSave263);
    document.getElementById("imgSqr264").src = tripleBZeroA;};

function artsquare264(){
    var sBQz264 = document.getElementById("aImgSqr265").src;
    valueBSave264 = 'zSqrArtSpecz264';
    localStorage.setItem(valueBSave264, sBQz264);
};
function squareBToSzzZValue264(){
    valueBSave264 = 'zSqrArtSpecz264';
    var tripleBZeroA = localStorage.getItem(valueBSave264);
    document.getElementById("imgSqr265").src = tripleBZeroA;};

function artsquare265(){
    var sBQz265 = document.getElementById("aImgSqr266").src;
    valueBSave265 = 'zSqrArtSpecz265';
    localStorage.setItem(valueBSave265, sBQz265);
};
function squareBToSzzZValue265(){
    valueBSave265 = 'zSqrArtSpecz265';
    var tripleBZeroA = localStorage.getItem(valueBSave265);
    document.getElementById("imgSqr266").src = tripleBZeroA;};

function artsquare266(){
    var sBQz266 = document.getElementById("aImgSqr267").src;
    valueBSave266 = 'zSqrArtSpecz266';
    localStorage.setItem(valueBSave266, sBQz266);
};
function squareBToSzzZValue266(){
    valueBSave266 = 'zSqrArtSpecz266';
    var tripleBZeroA = localStorage.getItem(valueBSave266);
    document.getElementById("imgSqr267").src = tripleBZeroA;};

function artsquare267(){
    var sBQz267 = document.getElementById("aImgSqr268").src;
    valueBSave267 = 'zSqrArtSpecz267';
    localStorage.setItem(valueBSave267, sBQz267);
};
function squareBToSzzZValue267(){
    valueBSave267 = 'zSqrArtSpecz267';
    var tripleBZeroA = localStorage.getItem(valueBSave267);
    document.getElementById("imgSqr268").src = tripleBZeroA;};

function artsquare268(){
    var sBQz268 = document.getElementById("aImgSqr269").src;
    valueBSave268 = 'zSqrArtSpecz268';
    localStorage.setItem(valueBSave268, sBQz268);
};
function squareBToSzzZValue268(){
    valueBSave268 = 'zSqrArtSpecz268';
    var tripleBZeroA = localStorage.getItem(valueBSave268);
    document.getElementById("imgSqr269").src = tripleBZeroA;};

function artsquare269(){
    var sBQz269 = document.getElementById("aImgSqr270").src;
    valueBSave269 = 'zSqrArtSpecz269';
    localStorage.setItem(valueBSave269, sBQz269);
};
function squareBToSzzZValue269(){
    valueBSave269 = 'zSqrArtSpecz269';
    var tripleBZeroA = localStorage.getItem(valueBSave269);
    document.getElementById("imgSqr270").src = tripleBZeroA;};

function artsquare270(){
    var sBQz270 = document.getElementById("aImgSqr271").src;
    valueBSave270 = 'zSqrArtSpecz270';
    localStorage.setItem(valueBSave270, sBQz270);
};
function squareBToSzzZValue270(){
    valueBSave270 = 'zSqrArtSpecz270';
    var tripleBZeroA = localStorage.getItem(valueBSave270);
    document.getElementById("imgSqr271").src = tripleBZeroA;};

function artsquare271(){
    var sBQz271 = document.getElementById("aImgSqr272").src;
    valueBSave271 = 'zSqrArtSpecz271';
    localStorage.setItem(valueBSave271, sBQz271);
};
function squareBToSzzZValue271(){
    valueBSave271 = 'zSqrArtSpecz271';
    var tripleBZeroA = localStorage.getItem(valueBSave271);
    document.getElementById("imgSqr272").src = tripleBZeroA;};

function artsquare272(){
    var sBQz272 = document.getElementById("aImgSqr273").src;
    valueBSave272 = 'zSqrArtSpecz272';
    localStorage.setItem(valueBSave272, sBQz272);
};
function squareBToSzzZValue272(){
    valueBSave272 = 'zSqrArtSpecz272';
    var tripleBZeroA = localStorage.getItem(valueBSave272);
    document.getElementById("imgSqr273").src = tripleBZeroA;};

function artsquare273(){
    var sBQz273 = document.getElementById("aImgSqr274").src;
    valueBSave273 = 'zSqrArtSpecz273';
    localStorage.setItem(valueBSave273, sBQz273);
};
function squareBToSzzZValue273(){
    valueBSave273 = 'zSqrArtSpecz273';
    var tripleBZeroA = localStorage.getItem(valueBSave273);
    document.getElementById("imgSqr274").src = tripleBZeroA;};

function artsquare274(){
    var sBQz274 = document.getElementById("aImgSqr275").src;
    valueBSave274 = 'zSqrArtSpecz274';
    localStorage.setItem(valueBSave274, sBQz274);
};
function squareBToSzzZValue274(){
    valueBSave274 = 'zSqrArtSpecz274';
    var tripleBZeroA = localStorage.getItem(valueBSave274);
    document.getElementById("imgSqr275").src = tripleBZeroA;};

function artsquare275(){
    var sBQz275 = document.getElementById("aImgSqr276").src;
    valueBSave275 = 'zSqrArtSpecz275';
    localStorage.setItem(valueBSave275, sBQz275);
};
function squareBToSzzZValue275(){
    valueBSave275 = 'zSqrArtSpecz275';
    var tripleBZeroA = localStorage.getItem(valueBSave275);
    document.getElementById("imgSqr276").src = tripleBZeroA;};

function artsquare276(){
    var sBQz276 = document.getElementById("aImgSqr277").src;
    valueBSave276 = 'zSqrArtSpecz276';
    localStorage.setItem(valueBSave276, sBQz276);
};
function squareBToSzzZValue276(){
    valueBSave276 = 'zSqrArtSpecz276';
    var tripleBZeroA = localStorage.getItem(valueBSave276);
    document.getElementById("imgSqr277").src = tripleBZeroA;};

function artsquare277(){
    var sBQz277 = document.getElementById("aImgSqr278").src;
    valueBSave277 = 'zSqrArtSpecz277';
    localStorage.setItem(valueBSave277, sBQz277);
};
function squareBToSzzZValue277(){
    valueBSave277 = 'zSqrArtSpecz277';
    var tripleBZeroA = localStorage.getItem(valueBSave277);
    document.getElementById("imgSqr278").src = tripleBZeroA;};

function artsquare278(){
    var sBQz278 = document.getElementById("aImgSqr279").src;
    valueBSave278 = 'zSqrArtSpecz278';
    localStorage.setItem(valueBSave278, sBQz278);
};
function squareBToSzzZValue278(){
    valueBSave278 = 'zSqrArtSpecz278';
    var tripleBZeroA = localStorage.getItem(valueBSave278);
    document.getElementById("imgSqr279").src = tripleBZeroA;};

function artsquare279(){
    var sBQz279 = document.getElementById("aImgSqr280").src;
    valueBSave279 = 'zSqrArtSpecz279';
    localStorage.setItem(valueBSave279, sBQz279);
};
function squareBToSzzZValue279(){
    valueBSave279 = 'zSqrArtSpecz279';
    var tripleBZeroA = localStorage.getItem(valueBSave279);
    document.getElementById("imgSqr280").src = tripleBZeroA;};

function artsquare280(){
    var sBQz280 = document.getElementById("aImgSqr281").src;
    valueBSave280 = 'zSqrArtSpecz280';
    localStorage.setItem(valueBSave280, sBQz280);
};
function squareBToSzzZValue280(){
    valueBSave280 = 'zSqrArtSpecz280';
    var tripleBZeroA = localStorage.getItem(valueBSave280);
    document.getElementById("imgSqr281").src = tripleBZeroA;};

function artsquare281(){
    var sBQz281 = document.getElementById("aImgSqr282").src;
    valueBSave281 = 'zSqrArtSpecz281';
    localStorage.setItem(valueBSave281, sBQz281);
};
function squareBToSzzZValue281(){
    valueBSave281 = 'zSqrArtSpecz281';
    var tripleBZeroA = localStorage.getItem(valueBSave281);
    document.getElementById("imgSqr282").src = tripleBZeroA;};

function artsquare282(){
    var sBQz282 = document.getElementById("aImgSqr283").src;
    valueBSave282 = 'zSqrArtSpecz282';
    localStorage.setItem(valueBSave282, sBQz282);
};
function squareBToSzzZValue282(){
    valueBSave282 = 'zSqrArtSpecz282';
    var tripleBZeroA = localStorage.getItem(valueBSave282);
    document.getElementById("imgSqr283").src = tripleBZeroA;};

function artsquare283(){
    var sBQz283 = document.getElementById("aImgSqr284").src;
    valueBSave283 = 'zSqrArtSpecz283';
    localStorage.setItem(valueBSave283, sBQz283);
};
function squareBToSzzZValue283(){
    valueBSave283 = 'zSqrArtSpecz283';
    var tripleBZeroA = localStorage.getItem(valueBSave283);
    document.getElementById("imgSqr284").src = tripleBZeroA;};

function artsquare284(){
    var sBQz284 = document.getElementById("aImgSqr285").src;
    valueBSave284 = 'zSqrArtSpecz284';
    localStorage.setItem(valueBSave284, sBQz284);
};
function squareBToSzzZValue284(){
    valueBSave284 = 'zSqrArtSpecz284';
    var tripleBZeroA = localStorage.getItem(valueBSave284);
    document.getElementById("imgSqr285").src = tripleBZeroA;};

function artsquare285(){
    var sBQz285 = document.getElementById("aImgSqr286").src;
    valueBSave285 = 'zSqrArtSpecz285';
    localStorage.setItem(valueBSave285, sBQz285);
};
function squareBToSzzZValue285(){
    valueBSave285 = 'zSqrArtSpecz285';
    var tripleBZeroA = localStorage.getItem(valueBSave285);
    document.getElementById("imgSqr286").src = tripleBZeroA;};

function artsquare286(){
    var sBQz286 = document.getElementById("aImgSqr287").src;
    valueBSave286 = 'zSqrArtSpecz286';
    localStorage.setItem(valueBSave286, sBQz286);
};
function squareBToSzzZValue286(){
    valueBSave286 = 'zSqrArtSpecz286';
    var tripleBZeroA = localStorage.getItem(valueBSave286);
    document.getElementById("imgSqr287").src = tripleBZeroA;};

function artsquare287(){
    var sBQz287 = document.getElementById("aImgSqr288").src;
    valueBSave287 = 'zSqrArtSpecz287';
    localStorage.setItem(valueBSave287, sBQz287);
};
function squareBToSzzZValue287(){
    valueBSave287 = 'zSqrArtSpecz287';
    var tripleBZeroA = localStorage.getItem(valueBSave287);
    document.getElementById("imgSqr288").src = tripleBZeroA;};

function artsquare288(){
    var sBQz288 = document.getElementById("aImgSqr289").src;
    valueBSave288 = 'zSqrArtSpecz288';
    localStorage.setItem(valueBSave288, sBQz288);
};
function squareBToSzzZValue288(){
    valueBSave288 = 'zSqrArtSpecz288';
    var tripleBZeroA = localStorage.getItem(valueBSave288);
    document.getElementById("imgSqr289").src = tripleBZeroA;};

function artsquare289(){
    var sBQz289 = document.getElementById("aImgSqr290").src;
    valueBSave289 = 'zSqrArtSpecz289';
    localStorage.setItem(valueBSave289, sBQz289);
};
function squareBToSzzZValue289(){
    valueBSave289 = 'zSqrArtSpecz289';
    var tripleBZeroA = localStorage.getItem(valueBSave289);
    document.getElementById("imgSqr290").src = tripleBZeroA;};

function artsquare290(){
    var sBQz290 = document.getElementById("aImgSqr291").src;
    valueBSave290 = 'zSqrArtSpecz290';
    localStorage.setItem(valueBSave290, sBQz290);
};
function squareBToSzzZValue290(){
    valueBSave290 = 'zSqrArtSpecz290';
    var tripleBZeroA = localStorage.getItem(valueBSave290);
    document.getElementById("imgSqr291").src = tripleBZeroA;};

function artsquare291(){
    var sBQz291 = document.getElementById("aImgSqr292").src;
    valueBSave291 = 'zSqrArtSpecz291';
    localStorage.setItem(valueBSave291, sBQz291);
};
function squareBToSzzZValue291(){
    valueBSave291 = 'zSqrArtSpecz291';
    var tripleBZeroA = localStorage.getItem(valueBSave291);
    document.getElementById("imgSqr292").src = tripleBZeroA;};

function artsquare292(){
    var sBQz292 = document.getElementById("aImgSqr293").src;
    valueBSave292 = 'zSqrArtSpecz292';
    localStorage.setItem(valueBSave292, sBQz292);
};
function squareBToSzzZValue292(){
    valueBSave292 = 'zSqrArtSpecz292';
    var tripleBZeroA = localStorage.getItem(valueBSave292);
    document.getElementById("imgSqr293").src = tripleBZeroA;};

function artsquare293(){
    var sBQz293 = document.getElementById("aImgSqr294").src;
    valueBSave293 = 'zSqrArtSpecz293';
    localStorage.setItem(valueBSave293, sBQz293);
};
function squareBToSzzZValue293(){
    valueBSave293 = 'zSqrArtSpecz293';
    var tripleBZeroA = localStorage.getItem(valueBSave293);
    document.getElementById("imgSqr294").src = tripleBZeroA;};

function artsquare294(){
    var sBQz294 = document.getElementById("aImgSqr295").src;
    valueBSave294 = 'zSqrArtSpecz294';
    localStorage.setItem(valueBSave294, sBQz294);
};
function squareBToSzzZValue294(){
    valueBSave294 = 'zSqrArtSpecz294';
    var tripleBZeroA = localStorage.getItem(valueBSave294);
    document.getElementById("imgSqr295").src = tripleBZeroA;};

function artsquare295(){
    var sBQz295 = document.getElementById("aImgSqr296").src;
    valueBSave295 = 'zSqrArtSpecz295';
    localStorage.setItem(valueBSave295, sBQz295);
};
function squareBToSzzZValue295(){
    valueBSave295 = 'zSqrArtSpecz295';
    var tripleBZeroA = localStorage.getItem(valueBSave295);
    document.getElementById("imgSqr296").src = tripleBZeroA;};

function artsquare296(){
    var sBQz296 = document.getElementById("aImgSqr297").src;
    valueBSave296 = 'zSqrArtSpecz296';
    localStorage.setItem(valueBSave296, sBQz296);
};
function squareBToSzzZValue296(){
    valueBSave296 = 'zSqrArtSpecz296';
    var tripleBZeroA = localStorage.getItem(valueBSave296);
    document.getElementById("imgSqr297").src = tripleBZeroA;};

function artsquare297(){
    var sBQz297 = document.getElementById("aImgSqr298").src;
    valueBSave297 = 'zSqrArtSpecz297';
    localStorage.setItem(valueBSave297, sBQz297);
};
function squareBToSzzZValue297(){
    valueBSave297 = 'zSqrArtSpecz297';
    var tripleBZeroA = localStorage.getItem(valueBSave297);
    document.getElementById("imgSqr298").src = tripleBZeroA;};

function artsquare298(){
    var sBQz298 = document.getElementById("aImgSqr299").src;
    valueBSave298 = 'zSqrArtSpecz298';
    localStorage.setItem(valueBSave298, sBQz298);
};
function squareBToSzzZValue298(){
    valueBSave298 = 'zSqrArtSpecz298';
    var tripleBZeroA = localStorage.getItem(valueBSave298);
    document.getElementById("imgSqr299").src = tripleBZeroA;};

function artsquare299(){
    var sBQz299 = document.getElementById("aImgSqr300").src;
    valueBSave299 = 'zSqrArtSpecz299';
    localStorage.setItem(valueBSave299, sBQz299);
};
function squareBToSzzZValue299(){
    valueBSave299 = 'zSqrArtSpecz299';
    var tripleBZeroA = localStorage.getItem(valueBSave299);
    document.getElementById("imgSqr300").src = tripleBZeroA;};

function artsquare300(){
    var sBQz300 = document.getElementById("aImgSqr301").src;
    valueBSave300 = 'zSqrArtSpecz300';
    localStorage.setItem(valueBSave300, sBQz300);
};
function squareBToSzzZValue300(){
    valueBSave300 = 'zSqrArtSpecz300';
    var tripleBZeroA = localStorage.getItem(valueBSave300);
    document.getElementById("imgSqr301").src = tripleBZeroA;};

function artsquare301(){
    var sBQz301 = document.getElementById("aImgSqr302").src;
    valueBSave301 = 'zSqrArtSpecz301';
    localStorage.setItem(valueBSave301, sBQz301);
};
function squareBToSzzZValue301(){
    valueBSave301 = 'zSqrArtSpecz301';
    var tripleBZeroA = localStorage.getItem(valueBSave301);
    document.getElementById("imgSqr302").src = tripleBZeroA;};

function artsquare302(){
    var sBQz302 = document.getElementById("aImgSqr303").src;
    valueBSave302 = 'zSqrArtSpecz302';
    localStorage.setItem(valueBSave302, sBQz302);
};
function squareBToSzzZValue302(){
    valueBSave302 = 'zSqrArtSpecz302';
    var tripleBZeroA = localStorage.getItem(valueBSave302);
    document.getElementById("imgSqr303").src = tripleBZeroA;};

function artsquare303(){
    var sBQz303 = document.getElementById("aImgSqr304").src;
    valueBSave303 = 'zSqrArtSpecz303';
    localStorage.setItem(valueBSave303, sBQz303);
};
function squareBToSzzZValue303(){
    valueBSave303 = 'zSqrArtSpecz303';
    var tripleBZeroA = localStorage.getItem(valueBSave303);
    document.getElementById("imgSqr304").src = tripleBZeroA;};

function artsquare304(){
    var sBQz304 = document.getElementById("aImgSqr305").src;
    valueBSave304 = 'zSqrArtSpecz304';
    localStorage.setItem(valueBSave304, sBQz304);
};
function squareBToSzzZValue304(){
    valueBSave304 = 'zSqrArtSpecz304';
    var tripleBZeroA = localStorage.getItem(valueBSave304);
    document.getElementById("imgSqr305").src = tripleBZeroA;};

function artsquare305(){
    var sBQz305 = document.getElementById("aImgSqr306").src;
    valueBSave305 = 'zSqrArtSpecz305';
    localStorage.setItem(valueBSave305, sBQz305);
};
function squareBToSzzZValue305(){
    valueBSave305 = 'zSqrArtSpecz305';
    var tripleBZeroA = localStorage.getItem(valueBSave305);
    document.getElementById("imgSqr306").src = tripleBZeroA;};

function artsquare306(){
    var sBQz306 = document.getElementById("aImgSqr307").src;
    valueBSave306 = 'zSqrArtSpecz306';
    localStorage.setItem(valueBSave306, sBQz306);
};
function squareBToSzzZValue306(){
    valueBSave306 = 'zSqrArtSpecz306';
    var tripleBZeroA = localStorage.getItem(valueBSave306);
    document.getElementById("imgSqr307").src = tripleBZeroA;};

function artsquare307(){
    var sBQz307 = document.getElementById("aImgSqr308").src;
    valueBSave307 = 'zSqrArtSpecz307';
    localStorage.setItem(valueBSave307, sBQz307);
};
function squareBToSzzZValue307(){
    valueBSave307 = 'zSqrArtSpecz307';
    var tripleBZeroA = localStorage.getItem(valueBSave307);
    document.getElementById("imgSqr308").src = tripleBZeroA;};

function artsquare308(){
    var sBQz308 = document.getElementById("aImgSqr309").src;
    valueBSave308 = 'zSqrArtSpecz308';
    localStorage.setItem(valueBSave308, sBQz308);
};
function squareBToSzzZValue308(){
    valueBSave308 = 'zSqrArtSpecz308';
    var tripleBZeroA = localStorage.getItem(valueBSave308);
    document.getElementById("imgSqr309").src = tripleBZeroA;};

function artsquare309(){
    var sBQz309 = document.getElementById("aImgSqr310").src;
    valueBSave309 = 'zSqrArtSpecz309';
    localStorage.setItem(valueBSave309, sBQz309);
};
function squareBToSzzZValue309(){
    valueBSave309 = 'zSqrArtSpecz309';
    var tripleBZeroA = localStorage.getItem(valueBSave309);
    document.getElementById("imgSqr310").src = tripleBZeroA;};

function artsquare310(){
    var sBQz310 = document.getElementById("aImgSqr311").src;
    valueBSave310 = 'zSqrArtSpecz310';
    localStorage.setItem(valueBSave310, sBQz310);
};
function squareBToSzzZValue310(){
    valueBSave310 = 'zSqrArtSpecz310';
    var tripleBZeroA = localStorage.getItem(valueBSave310);
    document.getElementById("imgSqr311").src = tripleBZeroA;};

function artsquare311(){
    var sBQz311 = document.getElementById("aImgSqr312").src;
    valueBSave311 = 'zSqrArtSpecz311';
    localStorage.setItem(valueBSave311, sBQz311);
};
function squareBToSzzZValue311(){
    valueBSave311 = 'zSqrArtSpecz311';
    var tripleBZeroA = localStorage.getItem(valueBSave311);
    document.getElementById("imgSqr312").src = tripleBZeroA;};

function artsquare312(){
    var sBQz312 = document.getElementById("aImgSqr313").src;
    valueBSave312 = 'zSqrArtSpecz312';
    localStorage.setItem(valueBSave312, sBQz312);
};
function squareBToSzzZValue312(){
    valueBSave312 = 'zSqrArtSpecz312';
    var tripleBZeroA = localStorage.getItem(valueBSave312);
    document.getElementById("imgSqr313").src = tripleBZeroA;};

function artsquare313(){
    var sBQz313 = document.getElementById("aImgSqr314").src;
    valueBSave313 = 'zSqrArtSpecz313';
    localStorage.setItem(valueBSave313, sBQz313);
};
function squareBToSzzZValue313(){
    valueBSave313 = 'zSqrArtSpecz313';
    var tripleBZeroA = localStorage.getItem(valueBSave313);
    document.getElementById("imgSqr314").src = tripleBZeroA;};

function artsquare314(){
    var sBQz314 = document.getElementById("aImgSqr315").src;
    valueBSave314 = 'zSqrArtSpecz314';
    localStorage.setItem(valueBSave314, sBQz314);
};
function squareBToSzzZValue314(){
    valueBSave314 = 'zSqrArtSpecz314';
    var tripleBZeroA = localStorage.getItem(valueBSave314);
    document.getElementById("imgSqr315").src = tripleBZeroA;};

function artsquare315(){
    var sBQz315 = document.getElementById("aImgSqr316").src;
    valueBSave315 = 'zSqrArtSpecz315';
    localStorage.setItem(valueBSave315, sBQz315);
};
function squareBToSzzZValue315(){
    valueBSave315 = 'zSqrArtSpecz315';
    var tripleBZeroA = localStorage.getItem(valueBSave315);
    document.getElementById("imgSqr316").src = tripleBZeroA;};

function artsquare316(){
    var sBQz316 = document.getElementById("aImgSqr317").src;
    valueBSave316 = 'zSqrArtSpecz316';
    localStorage.setItem(valueBSave316, sBQz316);
};
function squareBToSzzZValue316(){
    valueBSave316 = 'zSqrArtSpecz316';
    var tripleBZeroA = localStorage.getItem(valueBSave316);
    document.getElementById("imgSqr317").src = tripleBZeroA;};

function artsquare317(){
    var sBQz317 = document.getElementById("aImgSqr318").src;
    valueBSave317 = 'zSqrArtSpecz317';
    localStorage.setItem(valueBSave317, sBQz317);
};
function squareBToSzzZValue317(){
    valueBSave317 = 'zSqrArtSpecz317';
    var tripleBZeroA = localStorage.getItem(valueBSave317);
    document.getElementById("imgSqr318").src = tripleBZeroA;};

function artsquare318(){
    var sBQz318 = document.getElementById("aImgSqr319").src;
    valueBSave318 = 'zSqrArtSpecz318';
    localStorage.setItem(valueBSave318, sBQz318);
};
function squareBToSzzZValue318(){
    valueBSave318 = 'zSqrArtSpecz318';
    var tripleBZeroA = localStorage.getItem(valueBSave318);
    document.getElementById("imgSqr319").src = tripleBZeroA;};

function artsquare319(){
    var sBQz319 = document.getElementById("aImgSqr320").src;
    valueBSave319 = 'zSqrArtSpecz319';
    localStorage.setItem(valueBSave319, sBQz319);
};
function squareBToSzzZValue319(){
    valueBSave319 = 'zSqrArtSpecz319';
    var tripleBZeroA = localStorage.getItem(valueBSave319);
    document.getElementById("imgSqr320").src = tripleBZeroA;};

function artsquare320(){
    var sBQz320 = document.getElementById("aImgSqr321").src;
    valueBSave320 = 'zSqrArtSpecz320';
    localStorage.setItem(valueBSave320, sBQz320);
};
function squareBToSzzZValue320(){
    valueBSave320 = 'zSqrArtSpecz320';
    var tripleBZeroA = localStorage.getItem(valueBSave320);
    document.getElementById("imgSqr321").src = tripleBZeroA;};

function artsquare321(){
    var sBQz321 = document.getElementById("aImgSqr322").src;
    valueBSave321 = 'zSqrArtSpecz321';
    localStorage.setItem(valueBSave321, sBQz321);
};
function squareBToSzzZValue321(){
    valueBSave321 = 'zSqrArtSpecz321';
    var tripleBZeroA = localStorage.getItem(valueBSave321);
    document.getElementById("imgSqr322").src = tripleBZeroA;};

function artsquare322(){
    var sBQz322 = document.getElementById("aImgSqr323").src;
    valueBSave322 = 'zSqrArtSpecz322';
    localStorage.setItem(valueBSave322, sBQz322);
};
function squareBToSzzZValue322(){
    valueBSave322 = 'zSqrArtSpecz322';
    var tripleBZeroA = localStorage.getItem(valueBSave322);
    document.getElementById("imgSqr323").src = tripleBZeroA;};

function artsquare323(){
    var sBQz323 = document.getElementById("aImgSqr324").src;
    valueBSave323 = 'zSqrArtSpecz323';
    localStorage.setItem(valueBSave323, sBQz323);
};
function squareBToSzzZValue323(){
    valueBSave323 = 'zSqrArtSpecz323';
    var tripleBZeroA = localStorage.getItem(valueBSave323);
    document.getElementById("imgSqr324").src = tripleBZeroA;};

function artsquare324(){
    var sBQz324 = document.getElementById("aImgSqr325").src;
    valueBSave324 = 'zSqrArtSpecz324';
    localStorage.setItem(valueBSave324, sBQz324);
};
function squareBToSzzZValue324(){
    valueBSave324 = 'zSqrArtSpecz324';
    var tripleBZeroA = localStorage.getItem(valueBSave324);
    document.getElementById("imgSqr325").src = tripleBZeroA;};

function artsquare325(){
    var sBQz325 = document.getElementById("aImgSqr326").src;
    valueBSave325 = 'zSqrArtSpecz325';
    localStorage.setItem(valueBSave325, sBQz325);
};
function squareBToSzzZValue325(){
    valueBSave325 = 'zSqrArtSpecz325';
    var tripleBZeroA = localStorage.getItem(valueBSave325);
    document.getElementById("imgSqr326").src = tripleBZeroA;};

function artsquare326(){
    var sBQz326 = document.getElementById("aImgSqr327").src;
    valueBSave326 = 'zSqrArtSpecz326';
    localStorage.setItem(valueBSave326, sBQz326);
};
function squareBToSzzZValue326(){
    valueBSave326 = 'zSqrArtSpecz326';
    var tripleBZeroA = localStorage.getItem(valueBSave326);
    document.getElementById("imgSqr327").src = tripleBZeroA;};

function artsquare327(){
    var sBQz327 = document.getElementById("aImgSqr328").src;
    valueBSave327 = 'zSqrArtSpecz327';
    localStorage.setItem(valueBSave327, sBQz327);
};
function squareBToSzzZValue327(){
    valueBSave327 = 'zSqrArtSpecz327';
    var tripleBZeroA = localStorage.getItem(valueBSave327);
    document.getElementById("imgSqr328").src = tripleBZeroA;};

function artsquare328(){
    var sBQz328 = document.getElementById("aImgSqr329").src;
    valueBSave328 = 'zSqrArtSpecz328';
    localStorage.setItem(valueBSave328, sBQz328);
};
function squareBToSzzZValue328(){
    valueBSave328 = 'zSqrArtSpecz328';
    var tripleBZeroA = localStorage.getItem(valueBSave328);
    document.getElementById("imgSqr329").src = tripleBZeroA;};

function artsquare329(){
    var sBQz329 = document.getElementById("aImgSqr330").src;
    valueBSave329 = 'zSqrArtSpecz329';
    localStorage.setItem(valueBSave329, sBQz329);
};
function squareBToSzzZValue329(){
    valueBSave329 = 'zSqrArtSpecz329';
    var tripleBZeroA = localStorage.getItem(valueBSave329);
    document.getElementById("imgSqr330").src = tripleBZeroA;};

function artsquare330(){
    var sBQz330 = document.getElementById("aImgSqr331").src;
    valueBSave330 = 'zSqrArtSpecz330';
    localStorage.setItem(valueBSave330, sBQz330);
};
function squareBToSzzZValue330(){
    valueBSave330 = 'zSqrArtSpecz330';
    var tripleBZeroA = localStorage.getItem(valueBSave330);
    document.getElementById("imgSqr331").src = tripleBZeroA;};

function artsquare331(){
    var sBQz331 = document.getElementById("aImgSqr332").src;
    valueBSave331 = 'zSqrArtSpecz331';
    localStorage.setItem(valueBSave331, sBQz331);
};
function squareBToSzzZValue331(){
    valueBSave331 = 'zSqrArtSpecz331';
    var tripleBZeroA = localStorage.getItem(valueBSave331);
    document.getElementById("imgSqr332").src = tripleBZeroA;};

function artsquare332(){
    var sBQz332 = document.getElementById("aImgSqr333").src;
    valueBSave332 = 'zSqrArtSpecz332';
    localStorage.setItem(valueBSave332, sBQz332);
};
function squareBToSzzZValue332(){
    valueBSave332 = 'zSqrArtSpecz332';
    var tripleBZeroA = localStorage.getItem(valueBSave332);
    document.getElementById("imgSqr333").src = tripleBZeroA;};

function artsquare333(){
    var sBQz333 = document.getElementById("aImgSqr334").src;
    valueBSave333 = 'zSqrArtSpecz333';
    localStorage.setItem(valueBSave333, sBQz333);
};
function squareBToSzzZValue333(){
    valueBSave333 = 'zSqrArtSpecz333';
    var tripleBZeroA = localStorage.getItem(valueBSave333);
    document.getElementById("imgSqr334").src = tripleBZeroA;};

function artsquare334(){
    var sBQz334 = document.getElementById("aImgSqr335").src;
    valueBSave334 = 'zSqrArtSpecz334';
    localStorage.setItem(valueBSave334, sBQz334);
};
function squareBToSzzZValue334(){
    valueBSave334 = 'zSqrArtSpecz334';
    var tripleBZeroA = localStorage.getItem(valueBSave334);
    document.getElementById("imgSqr335").src = tripleBZeroA;};

function artsquare335(){
    var sBQz335 = document.getElementById("aImgSqr336").src;
    valueBSave335 = 'zSqrArtSpecz335';
    localStorage.setItem(valueBSave335, sBQz335);
};
function squareBToSzzZValue335(){
    valueBSave335 = 'zSqrArtSpecz335';
    var tripleBZeroA = localStorage.getItem(valueBSave335);
    document.getElementById("imgSqr336").src = tripleBZeroA;};

function artsquare336(){
    var sBQz336 = document.getElementById("aImgSqr337").src;
    valueBSave336 = 'zSqrArtSpecz336';
    localStorage.setItem(valueBSave336, sBQz336);
};
function squareBToSzzZValue336(){
    valueBSave336 = 'zSqrArtSpecz336';
    var tripleBZeroA = localStorage.getItem(valueBSave336);
    document.getElementById("imgSqr337").src = tripleBZeroA;};

function artsquare337(){
    var sBQz337 = document.getElementById("aImgSqr338").src;
    valueBSave337 = 'zSqrArtSpecz337';
    localStorage.setItem(valueBSave337, sBQz337);
};
function squareBToSzzZValue337(){
    valueBSave337 = 'zSqrArtSpecz337';
    var tripleBZeroA = localStorage.getItem(valueBSave337);
    document.getElementById("imgSqr338").src = tripleBZeroA;};

function artsquare338(){
    var sBQz338 = document.getElementById("aImgSqr339").src;
    valueBSave338 = 'zSqrArtSpecz338';
    localStorage.setItem(valueBSave338, sBQz338);
};
function squareBToSzzZValue338(){
    valueBSave338 = 'zSqrArtSpecz338';
    var tripleBZeroA = localStorage.getItem(valueBSave338);
    document.getElementById("imgSqr339").src = tripleBZeroA;};

function artsquare339(){
    var sBQz339 = document.getElementById("aImgSqr340").src;
    valueBSave339 = 'zSqrArtSpecz339';
    localStorage.setItem(valueBSave339, sBQz339);
};
function squareBToSzzZValue339(){
    valueBSave339 = 'zSqrArtSpecz339';
    var tripleBZeroA = localStorage.getItem(valueBSave339);
    document.getElementById("imgSqr340").src = tripleBZeroA;};

function artsquare340(){
    var sBQz340 = document.getElementById("aImgSqr341").src;
    valueBSave340 = 'zSqrArtSpecz340';
    localStorage.setItem(valueBSave340, sBQz340);
};
function squareBToSzzZValue340(){
    valueBSave340 = 'zSqrArtSpecz340';
    var tripleBZeroA = localStorage.getItem(valueBSave340);
    document.getElementById("imgSqr341").src = tripleBZeroA;};

function artsquare341(){
    var sBQz341 = document.getElementById("aImgSqr342").src;
    valueBSave341 = 'zSqrArtSpecz341';
    localStorage.setItem(valueBSave341, sBQz341);
};
function squareBToSzzZValue341(){
    valueBSave341 = 'zSqrArtSpecz341';
    var tripleBZeroA = localStorage.getItem(valueBSave341);
    document.getElementById("imgSqr342").src = tripleBZeroA;};

function artsquare342(){
    var sBQz342 = document.getElementById("aImgSqr343").src;
    valueBSave342 = 'zSqrArtSpecz342';
    localStorage.setItem(valueBSave342, sBQz342);
};
function squareBToSzzZValue342(){
    valueBSave342 = 'zSqrArtSpecz342';
    var tripleBZeroA = localStorage.getItem(valueBSave342);
    document.getElementById("imgSqr343").src = tripleBZeroA;};

function artsquare343(){
    var sBQz343 = document.getElementById("aImgSqr344").src;
    valueBSave343 = 'zSqrArtSpecz343';
    localStorage.setItem(valueBSave343, sBQz343);
};
function squareBToSzzZValue343(){
    valueBSave343 = 'zSqrArtSpecz343';
    var tripleBZeroA = localStorage.getItem(valueBSave343);
    document.getElementById("imgSqr344").src = tripleBZeroA;};

function artsquare344(){
    var sBQz344 = document.getElementById("aImgSqr345").src;
    valueBSave344 = 'zSqrArtSpecz344';
    localStorage.setItem(valueBSave344, sBQz344);
};
function squareBToSzzZValue344(){
    valueBSave344 = 'zSqrArtSpecz344';
    var tripleBZeroA = localStorage.getItem(valueBSave344);
    document.getElementById("imgSqr345").src = tripleBZeroA;};

function artsquare345(){
    var sBQz345 = document.getElementById("aImgSqr346").src;
    valueBSave345 = 'zSqrArtSpecz345';
    localStorage.setItem(valueBSave345, sBQz345);
};
function squareBToSzzZValue345(){
    valueBSave345 = 'zSqrArtSpecz345';
    var tripleBZeroA = localStorage.getItem(valueBSave345);
    document.getElementById("imgSqr346").src = tripleBZeroA;};

function artsquare346(){
    var sBQz346 = document.getElementById("aImgSqr347").src;
    valueBSave346 = 'zSqrArtSpecz346';
    localStorage.setItem(valueBSave346, sBQz346);
};
function squareBToSzzZValue346(){
    valueBSave346 = 'zSqrArtSpecz346';
    var tripleBZeroA = localStorage.getItem(valueBSave346);
    document.getElementById("imgSqr347").src = tripleBZeroA;};

function artsquare347(){
    var sBQz347 = document.getElementById("aImgSqr348").src;
    valueBSave347 = 'zSqrArtSpecz347';
    localStorage.setItem(valueBSave347, sBQz347);
};
function squareBToSzzZValue347(){
    valueBSave347 = 'zSqrArtSpecz347';
    var tripleBZeroA = localStorage.getItem(valueBSave347);
    document.getElementById("imgSqr348").src = tripleBZeroA;};

function artsquare348(){
    var sBQz348 = document.getElementById("aImgSqr349").src;
    valueBSave348 = 'zSqrArtSpecz348';
    localStorage.setItem(valueBSave348, sBQz348);
};
function squareBToSzzZValue348(){
    valueBSave348 = 'zSqrArtSpecz348';
    var tripleBZeroA = localStorage.getItem(valueBSave348);
    document.getElementById("imgSqr349").src = tripleBZeroA;};

function artsquare349(){
    var sBQz349 = document.getElementById("aImgSqr350").src;
    valueBSave349 = 'zSqrArtSpecz349';
    localStorage.setItem(valueBSave349, sBQz349);
};
function squareBToSzzZValue349(){
    valueBSave349 = 'zSqrArtSpecz349';
    var tripleBZeroA = localStorage.getItem(valueBSave349);
    document.getElementById("imgSqr350").src = tripleBZeroA;};

function artsquare350(){
    var sBQz350 = document.getElementById("aImgSqr351").src;
    valueBSave350 = 'zSqrArtSpecz350';
    localStorage.setItem(valueBSave350, sBQz350);
};
function squareBToSzzZValue350(){
    valueBSave350 = 'zSqrArtSpecz350';
    var tripleBZeroA = localStorage.getItem(valueBSave350);
    document.getElementById("imgSqr351").src = tripleBZeroA;};

function artsquare351(){
    var sBQz351 = document.getElementById("aImgSqr352").src;
    valueBSave351 = 'zSqrArtSpecz351';
    localStorage.setItem(valueBSave351, sBQz351);
};
function squareBToSzzZValue351(){
    valueBSave351 = 'zSqrArtSpecz351';
    var tripleBZeroA = localStorage.getItem(valueBSave351);
    document.getElementById("imgSqr352").src = tripleBZeroA;};

function artsquare352(){
    var sBQz352 = document.getElementById("aImgSqr353").src;
    valueBSave352 = 'zSqrArtSpecz352';
    localStorage.setItem(valueBSave352, sBQz352);
};
function squareBToSzzZValue352(){
    valueBSave352 = 'zSqrArtSpecz352';
    var tripleBZeroA = localStorage.getItem(valueBSave352);
    document.getElementById("imgSqr353").src = tripleBZeroA;};

function artsquare353(){
    var sBQz353 = document.getElementById("aImgSqr354").src;
    valueBSave353 = 'zSqrArtSpecz353';
    localStorage.setItem(valueBSave353, sBQz353);
};
function squareBToSzzZValue353(){
    valueBSave353 = 'zSqrArtSpecz353';
    var tripleBZeroA = localStorage.getItem(valueBSave353);
    document.getElementById("imgSqr354").src = tripleBZeroA;};

function artsquare354(){
    var sBQz354 = document.getElementById("aImgSqr355").src;
    valueBSave354 = 'zSqrArtSpecz354';
    localStorage.setItem(valueBSave354, sBQz354);
};
function squareBToSzzZValue354(){
    valueBSave354 = 'zSqrArtSpecz354';
    var tripleBZeroA = localStorage.getItem(valueBSave354);
    document.getElementById("imgSqr355").src = tripleBZeroA;};

function artsquare355(){
    var sBQz355 = document.getElementById("aImgSqr356").src;
    valueBSave355 = 'zSqrArtSpecz355';
    localStorage.setItem(valueBSave355, sBQz355);
};
function squareBToSzzZValue355(){
    valueBSave355 = 'zSqrArtSpecz355';
    var tripleBZeroA = localStorage.getItem(valueBSave355);
    document.getElementById("imgSqr356").src = tripleBZeroA;};

function artsquare356(){
    var sBQz356 = document.getElementById("aImgSqr357").src;
    valueBSave356 = 'zSqrArtSpecz356';
    localStorage.setItem(valueBSave356, sBQz356);
};
function squareBToSzzZValue356(){
    valueBSave356 = 'zSqrArtSpecz356';
    var tripleBZeroA = localStorage.getItem(valueBSave356);
    document.getElementById("imgSqr357").src = tripleBZeroA;};

function artsquare357(){
    var sBQz357 = document.getElementById("aImgSqr358").src;
    valueBSave357 = 'zSqrArtSpecz357';
    localStorage.setItem(valueBSave357, sBQz357);
};
function squareBToSzzZValue357(){
    valueBSave357 = 'zSqrArtSpecz357';
    var tripleBZeroA = localStorage.getItem(valueBSave357);
    document.getElementById("imgSqr358").src = tripleBZeroA;};

function artsquare358(){
    var sBQz358 = document.getElementById("aImgSqr359").src;
    valueBSave358 = 'zSqrArtSpecz358';
    localStorage.setItem(valueBSave358, sBQz358);
};
function squareBToSzzZValue358(){
    valueBSave358 = 'zSqrArtSpecz358';
    var tripleBZeroA = localStorage.getItem(valueBSave358);
    document.getElementById("imgSqr359").src = tripleBZeroA;};

function artsquare359(){
    var sBQz359 = document.getElementById("aImgSqr360").src;
    valueBSave359 = 'zSqrArtSpecz359';
    localStorage.setItem(valueBSave359, sBQz359);
};
function squareBToSzzZValue359(){
    valueBSave359 = 'zSqrArtSpecz359';
    var tripleBZeroA = localStorage.getItem(valueBSave359);
    document.getElementById("imgSqr360").src = tripleBZeroA;};

function artsquare360(){
    var sBQz360 = document.getElementById("aImgSqr361").src;
    valueBSave360 = 'zSqrArtSpecz360';
    localStorage.setItem(valueBSave360, sBQz360);
};
function squareBToSzzZValue360(){
    valueBSave360 = 'zSqrArtSpecz360';
    var tripleBZeroA = localStorage.getItem(valueBSave360);
    document.getElementById("imgSqr361").src = tripleBZeroA;};

function artsquare361(){
    var sBQz361 = document.getElementById("aImgSqr362").src;
    valueBSave361 = 'zSqrArtSpecz361';
    localStorage.setItem(valueBSave361, sBQz361);
};
function squareBToSzzZValue361(){
    valueBSave361 = 'zSqrArtSpecz361';
    var tripleBZeroA = localStorage.getItem(valueBSave361);
    document.getElementById("imgSqr362").src = tripleBZeroA;};

function artsquare362(){
    var sBQz362 = document.getElementById("aImgSqr363").src;
    valueBSave362 = 'zSqrArtSpecz362';
    localStorage.setItem(valueBSave362, sBQz362);
};
function squareBToSzzZValue362(){
    valueBSave362 = 'zSqrArtSpecz362';
    var tripleBZeroA = localStorage.getItem(valueBSave362);
    document.getElementById("imgSqr363").src = tripleBZeroA;};

function artsquare363(){
    var sBQz363 = document.getElementById("aImgSqr364").src;
    valueBSave363 = 'zSqrArtSpecz363';
    localStorage.setItem(valueBSave363, sBQz363);
};
function squareBToSzzZValue363(){
    valueBSave363 = 'zSqrArtSpecz363';
    var tripleBZeroA = localStorage.getItem(valueBSave363);
    document.getElementById("imgSqr364").src = tripleBZeroA;};

function artsquare364(){
    var sBQz364 = document.getElementById("aImgSqr365").src;
    valueBSave364 = 'zSqrArtSpecz364';
    localStorage.setItem(valueBSave364, sBQz364);
};
function squareBToSzzZValue364(){
    valueBSave364 = 'zSqrArtSpecz364';
    var tripleBZeroA = localStorage.getItem(valueBSave364);
    document.getElementById("imgSqr365").src = tripleBZeroA;};

function artsquare365(){
    var sBQz365 = document.getElementById("aImgSqr366").src;
    valueBSave365 = 'zSqrArtSpecz365';
    localStorage.setItem(valueBSave365, sBQz365);
};
function squareBToSzzZValue365(){
    valueBSave365 = 'zSqrArtSpecz365';
    var tripleBZeroA = localStorage.getItem(valueBSave365);
    document.getElementById("imgSqr366").src = tripleBZeroA;};

function artsquare366(){
    var sBQz366 = document.getElementById("aImgSqr367").src;
    valueBSave366 = 'zSqrArtSpecz366';
    localStorage.setItem(valueBSave366, sBQz366);
};
function squareBToSzzZValue366(){
    valueBSave366 = 'zSqrArtSpecz366';
    var tripleBZeroA = localStorage.getItem(valueBSave366);
    document.getElementById("imgSqr367").src = tripleBZeroA;};

function artsquare367(){
    var sBQz367 = document.getElementById("aImgSqr368").src;
    valueBSave367 = 'zSqrArtSpecz367';
    localStorage.setItem(valueBSave367, sBQz367);
};
function squareBToSzzZValue367(){
    valueBSave367 = 'zSqrArtSpecz367';
    var tripleBZeroA = localStorage.getItem(valueBSave367);
    document.getElementById("imgSqr368").src = tripleBZeroA;};

function artsquare368(){
    var sBQz368 = document.getElementById("aImgSqr369").src;
    valueBSave368 = 'zSqrArtSpecz368';
    localStorage.setItem(valueBSave368, sBQz368);
};
function squareBToSzzZValue368(){
    valueBSave368 = 'zSqrArtSpecz368';
    var tripleBZeroA = localStorage.getItem(valueBSave368);
    document.getElementById("imgSqr369").src = tripleBZeroA;};

function artsquare369(){
    var sBQz369 = document.getElementById("aImgSqr370").src;
    valueBSave369 = 'zSqrArtSpecz369';
    localStorage.setItem(valueBSave369, sBQz369);
};
function squareBToSzzZValue369(){
    valueBSave369 = 'zSqrArtSpecz369';
    var tripleBZeroA = localStorage.getItem(valueBSave369);
    document.getElementById("imgSqr370").src = tripleBZeroA;};

function artsquare370(){
    var sBQz370 = document.getElementById("aImgSqr371").src;
    valueBSave370 = 'zSqrArtSpecz370';
    localStorage.setItem(valueBSave370, sBQz370);
};
function squareBToSzzZValue370(){
    valueBSave370 = 'zSqrArtSpecz370';
    var tripleBZeroA = localStorage.getItem(valueBSave370);
    document.getElementById("imgSqr371").src = tripleBZeroA;};

function artsquare371(){
    var sBQz371 = document.getElementById("aImgSqr372").src;
    valueBSave371 = 'zSqrArtSpecz371';
    localStorage.setItem(valueBSave371, sBQz371);
};
function squareBToSzzZValue371(){
    valueBSave371 = 'zSqrArtSpecz371';
    var tripleBZeroA = localStorage.getItem(valueBSave371);
    document.getElementById("imgSqr372").src = tripleBZeroA;};

function artsquare372(){
    var sBQz372 = document.getElementById("aImgSqr373").src;
    valueBSave372 = 'zSqrArtSpecz372';
    localStorage.setItem(valueBSave372, sBQz372);
};
function squareBToSzzZValue372(){
    valueBSave372 = 'zSqrArtSpecz372';
    var tripleBZeroA = localStorage.getItem(valueBSave372);
    document.getElementById("imgSqr373").src = tripleBZeroA;};

function artsquare373(){
    var sBQz373 = document.getElementById("aImgSqr374").src;
    valueBSave373 = 'zSqrArtSpecz373';
    localStorage.setItem(valueBSave373, sBQz373);
};
function squareBToSzzZValue373(){
    valueBSave373 = 'zSqrArtSpecz373';
    var tripleBZeroA = localStorage.getItem(valueBSave373);
    document.getElementById("imgSqr374").src = tripleBZeroA;};

function artsquare374(){
    var sBQz374 = document.getElementById("aImgSqr375").src;
    valueBSave374 = 'zSqrArtSpecz374';
    localStorage.setItem(valueBSave374, sBQz374);
};
function squareBToSzzZValue374(){
    valueBSave374 = 'zSqrArtSpecz374';
    var tripleBZeroA = localStorage.getItem(valueBSave374);
    document.getElementById("imgSqr375").src = tripleBZeroA;};

function artsquare375(){
    var sBQz375 = document.getElementById("aImgSqr376").src;
    valueBSave375 = 'zSqrArtSpecz375';
    localStorage.setItem(valueBSave375, sBQz375);
};
function squareBToSzzZValue375(){
    valueBSave375 = 'zSqrArtSpecz375';
    var tripleBZeroA = localStorage.getItem(valueBSave375);
    document.getElementById("imgSqr376").src = tripleBZeroA;};

function artsquare376(){
    var sBQz376 = document.getElementById("aImgSqr377").src;
    valueBSave376 = 'zSqrArtSpecz376';
    localStorage.setItem(valueBSave376, sBQz376);
};
function squareBToSzzZValue376(){
    valueBSave376 = 'zSqrArtSpecz376';
    var tripleBZeroA = localStorage.getItem(valueBSave376);
    document.getElementById("imgSqr377").src = tripleBZeroA;};

function artsquare377(){
    var sBQz377 = document.getElementById("aImgSqr378").src;
    valueBSave377 = 'zSqrArtSpecz377';
    localStorage.setItem(valueBSave377, sBQz377);
};
function squareBToSzzZValue377(){
    valueBSave377 = 'zSqrArtSpecz377';
    var tripleBZeroA = localStorage.getItem(valueBSave377);
    document.getElementById("imgSqr378").src = tripleBZeroA;};

function artsquare378(){
    var sBQz378 = document.getElementById("aImgSqr379").src;
    valueBSave378 = 'zSqrArtSpecz378';
    localStorage.setItem(valueBSave378, sBQz378);
};
function squareBToSzzZValue378(){
    valueBSave378 = 'zSqrArtSpecz378';
    var tripleBZeroA = localStorage.getItem(valueBSave378);
    document.getElementById("imgSqr379").src = tripleBZeroA;};

function artsquare379(){
    var sBQz379 = document.getElementById("aImgSqr380").src;
    valueBSave379 = 'zSqrArtSpecz379';
    localStorage.setItem(valueBSave379, sBQz379);
};
function squareBToSzzZValue379(){
    valueBSave379 = 'zSqrArtSpecz379';
    var tripleBZeroA = localStorage.getItem(valueBSave379);
    document.getElementById("imgSqr380").src = tripleBZeroA;};

function artsquare380(){
    var sBQz380 = document.getElementById("aImgSqr381").src;
    valueBSave380 = 'zSqrArtSpecz380';
    localStorage.setItem(valueBSave380, sBQz380);
};
function squareBToSzzZValue380(){
    valueBSave380 = 'zSqrArtSpecz380';
    var tripleBZeroA = localStorage.getItem(valueBSave380);
    document.getElementById("imgSqr381").src = tripleBZeroA;};

function artsquare381(){
    var sBQz381 = document.getElementById("aImgSqr382").src;
    valueBSave381 = 'zSqrArtSpecz381';
    localStorage.setItem(valueBSave381, sBQz381);
};
function squareBToSzzZValue381(){
    valueBSave381 = 'zSqrArtSpecz381';
    var tripleBZeroA = localStorage.getItem(valueBSave381);
    document.getElementById("imgSqr382").src = tripleBZeroA;};

function artsquare382(){
    var sBQz382 = document.getElementById("aImgSqr383").src;
    valueBSave382 = 'zSqrArtSpecz382';
    localStorage.setItem(valueBSave382, sBQz382);
};
function squareBToSzzZValue382(){
    valueBSave382 = 'zSqrArtSpecz382';
    var tripleBZeroA = localStorage.getItem(valueBSave382);
    document.getElementById("imgSqr383").src = tripleBZeroA;};

function artsquare383(){
    var sBQz383 = document.getElementById("aImgSqr384").src;
    valueBSave383 = 'zSqrArtSpecz383';
    localStorage.setItem(valueBSave383, sBQz383);
};
function squareBToSzzZValue383(){
    valueBSave383 = 'zSqrArtSpecz383';
    var tripleBZeroA = localStorage.getItem(valueBSave383);
    document.getElementById("imgSqr384").src = tripleBZeroA;};

function artsquare384(){
    var sBQz384 = document.getElementById("aImgSqr385").src;
    valueBSave384 = 'zSqrArtSpecz384';
    localStorage.setItem(valueBSave384, sBQz384);
};
function squareBToSzzZValue384(){
    valueBSave384 = 'zSqrArtSpecz384';
    var tripleBZeroA = localStorage.getItem(valueBSave384);
    document.getElementById("imgSqr385").src = tripleBZeroA;};

function artsquare385(){
    var sBQz385 = document.getElementById("aImgSqr386").src;
    valueBSave385 = 'zSqrArtSpecz385';
    localStorage.setItem(valueBSave385, sBQz385);
};
function squareBToSzzZValue385(){
    valueBSave385 = 'zSqrArtSpecz385';
    var tripleBZeroA = localStorage.getItem(valueBSave385);
    document.getElementById("imgSqr386").src = tripleBZeroA;};

function artsquare386(){
    var sBQz386 = document.getElementById("aImgSqr387").src;
    valueBSave386 = 'zSqrArtSpecz386';
    localStorage.setItem(valueBSave386, sBQz386);
};
function squareBToSzzZValue386(){
    valueBSave386 = 'zSqrArtSpecz386';
    var tripleBZeroA = localStorage.getItem(valueBSave386);
    document.getElementById("imgSqr387").src = tripleBZeroA;};

function artsquare387(){
    var sBQz387 = document.getElementById("aImgSqr388").src;
    valueBSave387 = 'zSqrArtSpecz387';
    localStorage.setItem(valueBSave387, sBQz387);
};
function squareBToSzzZValue387(){
    valueBSave387 = 'zSqrArtSpecz387';
    var tripleBZeroA = localStorage.getItem(valueBSave387);
    document.getElementById("imgSqr388").src = tripleBZeroA;};

function artsquare388(){
    var sBQz388 = document.getElementById("aImgSqr389").src;
    valueBSave388 = 'zSqrArtSpecz388';
    localStorage.setItem(valueBSave388, sBQz388);
};
function squareBToSzzZValue388(){
    valueBSave388 = 'zSqrArtSpecz388';
    var tripleBZeroA = localStorage.getItem(valueBSave388);
    document.getElementById("imgSqr389").src = tripleBZeroA;};

function artsquare389(){
    var sBQz389 = document.getElementById("aImgSqr390").src;
    valueBSave389 = 'zSqrArtSpecz389';
    localStorage.setItem(valueBSave389, sBQz389);
};
function squareBToSzzZValue389(){
    valueBSave389 = 'zSqrArtSpecz389';
    var tripleBZeroA = localStorage.getItem(valueBSave389);
    document.getElementById("imgSqr390").src = tripleBZeroA;};

function artsquare390(){
    var sBQz390 = document.getElementById("aImgSqr391").src;
    valueBSave390 = 'zSqrArtSpecz390';
    localStorage.setItem(valueBSave390, sBQz390);
};
function squareBToSzzZValue390(){
    valueBSave390 = 'zSqrArtSpecz390';
    var tripleBZeroA = localStorage.getItem(valueBSave390);
    document.getElementById("imgSqr391").src = tripleBZeroA;};

function artsquare391(){
    var sBQz391 = document.getElementById("aImgSqr392").src;
    valueBSave391 = 'zSqrArtSpecz391';
    localStorage.setItem(valueBSave391, sBQz391);
};
function squareBToSzzZValue391(){
    valueBSave391 = 'zSqrArtSpecz391';
    var tripleBZeroA = localStorage.getItem(valueBSave391);
    document.getElementById("imgSqr392").src = tripleBZeroA;};

function artsquare392(){
    var sBQz392 = document.getElementById("aImgSqr393").src;
    valueBSave392 = 'zSqrArtSpecz392';
    localStorage.setItem(valueBSave392, sBQz392);
};
function squareBToSzzZValue392(){
    valueBSave392 = 'zSqrArtSpecz392';
    var tripleBZeroA = localStorage.getItem(valueBSave392);
    document.getElementById("imgSqr393").src = tripleBZeroA;};

function artsquare393(){
    var sBQz393 = document.getElementById("aImgSqr394").src;
    valueBSave393 = 'zSqrArtSpecz393';
    localStorage.setItem(valueBSave393, sBQz393);
};
function squareBToSzzZValue393(){
    valueBSave393 = 'zSqrArtSpecz393';
    var tripleBZeroA = localStorage.getItem(valueBSave393);
    document.getElementById("imgSqr394").src = tripleBZeroA;};

function artsquare394(){
    var sBQz394 = document.getElementById("aImgSqr395").src;
    valueBSave394 = 'zSqrArtSpecz394';
    localStorage.setItem(valueBSave394, sBQz394);
};
function squareBToSzzZValue394(){
    valueBSave394 = 'zSqrArtSpecz394';
    var tripleBZeroA = localStorage.getItem(valueBSave394);
    document.getElementById("imgSqr395").src = tripleBZeroA;};

function artsquare395(){
    var sBQz395 = document.getElementById("aImgSqr396").src;
    valueBSave395 = 'zSqrArtSpecz395';
    localStorage.setItem(valueBSave395, sBQz395);
};
function squareBToSzzZValue395(){
    valueBSave395 = 'zSqrArtSpecz395';
    var tripleBZeroA = localStorage.getItem(valueBSave395);
    document.getElementById("imgSqr396").src = tripleBZeroA;};

function artsquare396(){
    var sBQz396 = document.getElementById("aImgSqr397").src;
    valueBSave396 = 'zSqrArtSpecz396';
    localStorage.setItem(valueBSave396, sBQz396);
};
function squareBToSzzZValue396(){
    valueBSave396 = 'zSqrArtSpecz396';
    var tripleBZeroA = localStorage.getItem(valueBSave396);
    document.getElementById("imgSqr397").src = tripleBZeroA;};

function artsquare397(){
    var sBQz397 = document.getElementById("aImgSqr398").src;
    valueBSave397 = 'zSqrArtSpecz397';
    localStorage.setItem(valueBSave397, sBQz397);
};
function squareBToSzzZValue397(){
    valueBSave397 = 'zSqrArtSpecz397';
    var tripleBZeroA = localStorage.getItem(valueBSave397);
    document.getElementById("imgSqr398").src = tripleBZeroA;};

function artsquare398(){
    var sBQz398 = document.getElementById("aImgSqr399").src;
    valueBSave398 = 'zSqrArtSpecz398';
    localStorage.setItem(valueBSave398, sBQz398);
};
function squareBToSzzZValue398(){
    valueBSave398 = 'zSqrArtSpecz398';
    var tripleBZeroA = localStorage.getItem(valueBSave398);
    document.getElementById("imgSqr399").src = tripleBZeroA;};

function artsquare399(){
    var sBQz399 = document.getElementById("aImgSqr400").src;
    valueBSave399 = 'zSqrArtSpecz399';
    localStorage.setItem(valueBSave399, sBQz399);
};
function squareBToSzzZValue399(){
    valueBSave399 = 'zSqrArtSpecz399';
    var tripleBZeroA = localStorage.getItem(valueBSave399);
    document.getElementById("imgSqr400").src = tripleBZeroA;};

function artsquare400(){
    var sBQz400 = document.getElementById("aImgSqr401").src;
    valueBSave400 = 'zSqrArtSpecz400';
    localStorage.setItem(valueBSave400, sBQz400);
};
function squareBToSzzZValue400(){
    valueBSave400 = 'zSqrArtSpecz400';
    var tripleBZeroA = localStorage.getItem(valueBSave400);
    document.getElementById("imgSqr401").src = tripleBZeroA;};

function artsquare401(){
    var sBQz401 = document.getElementById("aImgSqr402").src;
    valueBSave401 = 'zSqrArtSpecz401';
    localStorage.setItem(valueBSave401, sBQz401);
};
function squareBToSzzZValue401(){
    valueBSave401 = 'zSqrArtSpecz401';
    var tripleBZeroA = localStorage.getItem(valueBSave401);
    document.getElementById("imgSqr402").src = tripleBZeroA;};

function artsquare402(){
    var sBQz402 = document.getElementById("aImgSqr403").src;
    valueBSave402 = 'zSqrArtSpecz402';
    localStorage.setItem(valueBSave402, sBQz402);
};
function squareBToSzzZValue402(){
    valueBSave402 = 'zSqrArtSpecz402';
    var tripleBZeroA = localStorage.getItem(valueBSave402);
    document.getElementById("imgSqr403").src = tripleBZeroA;};

function artsquare403(){
    var sBQz403 = document.getElementById("aImgSqr404").src;
    valueBSave403 = 'zSqrArtSpecz403';
    localStorage.setItem(valueBSave403, sBQz403);
};
function squareBToSzzZValue403(){
    valueBSave403 = 'zSqrArtSpecz403';
    var tripleBZeroA = localStorage.getItem(valueBSave403);
    document.getElementById("imgSqr404").src = tripleBZeroA;};

function artsquare404(){
    var sBQz404 = document.getElementById("aImgSqr405").src;
    valueBSave404 = 'zSqrArtSpecz404';
    localStorage.setItem(valueBSave404, sBQz404);
};
function squareBToSzzZValue404(){
    valueBSave404 = 'zSqrArtSpecz404';
    var tripleBZeroA = localStorage.getItem(valueBSave404);
    document.getElementById("imgSqr405").src = tripleBZeroA;};

function artsquare405(){
    var sBQz405 = document.getElementById("aImgSqr406").src;
    valueBSave405 = 'zSqrArtSpecz405';
    localStorage.setItem(valueBSave405, sBQz405);
};
function squareBToSzzZValue405(){
    valueBSave405 = 'zSqrArtSpecz405';
    var tripleBZeroA = localStorage.getItem(valueBSave405);
    document.getElementById("imgSqr406").src = tripleBZeroA;};

function artsquare406(){
    var sBQz406 = document.getElementById("aImgSqr407").src;
    valueBSave406 = 'zSqrArtSpecz406';
    localStorage.setItem(valueBSave406, sBQz406);
};
function squareBToSzzZValue406(){
    valueBSave406 = 'zSqrArtSpecz406';
    var tripleBZeroA = localStorage.getItem(valueBSave406);
    document.getElementById("imgSqr407").src = tripleBZeroA;};

function artsquare407(){
    var sBQz407 = document.getElementById("aImgSqr408").src;
    valueBSave407 = 'zSqrArtSpecz407';
    localStorage.setItem(valueBSave407, sBQz407);
};
function squareBToSzzZValue407(){
    valueBSave407 = 'zSqrArtSpecz407';
    var tripleBZeroA = localStorage.getItem(valueBSave407);
    document.getElementById("imgSqr408").src = tripleBZeroA;};

function artsquare408(){
    var sBQz408 = document.getElementById("aImgSqr409").src;
    valueBSave408 = 'zSqrArtSpecz408';
    localStorage.setItem(valueBSave408, sBQz408);
};
function squareBToSzzZValue408(){
    valueBSave408 = 'zSqrArtSpecz408';
    var tripleBZeroA = localStorage.getItem(valueBSave408);
    document.getElementById("imgSqr409").src = tripleBZeroA;};

function artsquare409(){
    var sBQz409 = document.getElementById("aImgSqr410").src;
    valueBSave409 = 'zSqrArtSpecz409';
    localStorage.setItem(valueBSave409, sBQz409);
};
function squareBToSzzZValue409(){
    valueBSave409 = 'zSqrArtSpecz409';
    var tripleBZeroA = localStorage.getItem(valueBSave409);
    document.getElementById("imgSqr410").src = tripleBZeroA;};

function artsquare410(){
    var sBQz410 = document.getElementById("aImgSqr411").src;
    valueBSave410 = 'zSqrArtSpecz410';
    localStorage.setItem(valueBSave410, sBQz410);
};
function squareBToSzzZValue410(){
    valueBSave410 = 'zSqrArtSpecz410';
    var tripleBZeroA = localStorage.getItem(valueBSave410);
    document.getElementById("imgSqr411").src = tripleBZeroA;};

function artsquare411(){
    var sBQz411 = document.getElementById("aImgSqr412").src;
    valueBSave411 = 'zSqrArtSpecz411';
    localStorage.setItem(valueBSave411, sBQz411);
};
function squareBToSzzZValue411(){
    valueBSave411 = 'zSqrArtSpecz411';
    var tripleBZeroA = localStorage.getItem(valueBSave411);
    document.getElementById("imgSqr412").src = tripleBZeroA;};

function artsquare412(){
    var sBQz412 = document.getElementById("aImgSqr413").src;
    valueBSave412 = 'zSqrArtSpecz412';
    localStorage.setItem(valueBSave412, sBQz412);
};
function squareBToSzzZValue412(){
    valueBSave412 = 'zSqrArtSpecz412';
    var tripleBZeroA = localStorage.getItem(valueBSave412);
    document.getElementById("imgSqr413").src = tripleBZeroA;};

function artsquare413(){
    var sBQz413 = document.getElementById("aImgSqr414").src;
    valueBSave413 = 'zSqrArtSpecz413';
    localStorage.setItem(valueBSave413, sBQz413);
};
function squareBToSzzZValue413(){
    valueBSave413 = 'zSqrArtSpecz413';
    var tripleBZeroA = localStorage.getItem(valueBSave413);
    document.getElementById("imgSqr414").src = tripleBZeroA;};

function artsquare414(){
    var sBQz414 = document.getElementById("aImgSqr415").src;
    valueBSave414 = 'zSqrArtSpecz414';
    localStorage.setItem(valueBSave414, sBQz414);
};
function squareBToSzzZValue414(){
    valueBSave414 = 'zSqrArtSpecz414';
    var tripleBZeroA = localStorage.getItem(valueBSave414);
    document.getElementById("imgSqr415").src = tripleBZeroA;};

function artsquare415(){
    var sBQz415 = document.getElementById("aImgSqr416").src;
    valueBSave415 = 'zSqrArtSpecz415';
    localStorage.setItem(valueBSave415, sBQz415);
};
function squareBToSzzZValue415(){
    valueBSave415 = 'zSqrArtSpecz415';
    var tripleBZeroA = localStorage.getItem(valueBSave415);
    document.getElementById("imgSqr416").src = tripleBZeroA;};

function artsquare416(){
    var sBQz416 = document.getElementById("aImgSqr417").src;
    valueBSave416 = 'zSqrArtSpecz416';
    localStorage.setItem(valueBSave416, sBQz416);
};
function squareBToSzzZValue416(){
    valueBSave416 = 'zSqrArtSpecz416';
    var tripleBZeroA = localStorage.getItem(valueBSave416);
    document.getElementById("imgSqr417").src = tripleBZeroA;};

function artsquare417(){
    var sBQz417 = document.getElementById("aImgSqr418").src;
    valueBSave417 = 'zSqrArtSpecz417';
    localStorage.setItem(valueBSave417, sBQz417);
};
function squareBToSzzZValue417(){
    valueBSave417 = 'zSqrArtSpecz417';
    var tripleBZeroA = localStorage.getItem(valueBSave417);
    document.getElementById("imgSqr418").src = tripleBZeroA;};

function artsquare418(){
    var sBQz418 = document.getElementById("aImgSqr419").src;
    valueBSave418 = 'zSqrArtSpecz418';
    localStorage.setItem(valueBSave418, sBQz418);
};
function squareBToSzzZValue418(){
    valueBSave418 = 'zSqrArtSpecz418';
    var tripleBZeroA = localStorage.getItem(valueBSave418);
    document.getElementById("imgSqr419").src = tripleBZeroA;};

function artsquare419(){
    var sBQz419 = document.getElementById("aImgSqr420").src;
    valueBSave419 = 'zSqrArtSpecz419';
    localStorage.setItem(valueBSave419, sBQz419);
};
function squareBToSzzZValue419(){
    valueBSave419 = 'zSqrArtSpecz419';
    var tripleBZeroA = localStorage.getItem(valueBSave419);
    document.getElementById("imgSqr420").src = tripleBZeroA;};

function artsquare420(){
    var sBQz420 = document.getElementById("aImgSqr421").src;
    valueBSave420 = 'zSqrArtSpecz420';
    localStorage.setItem(valueBSave420, sBQz420);
};
function squareBToSzzZValue420(){
    valueBSave420 = 'zSqrArtSpecz420';
    var tripleBZeroA = localStorage.getItem(valueBSave420);
    document.getElementById("imgSqr421").src = tripleBZeroA;};

function artsquare421(){
    var sBQz421 = document.getElementById("aImgSqr422").src;
    valueBSave421 = 'zSqrArtSpecz421';
    localStorage.setItem(valueBSave421, sBQz421);
};
function squareBToSzzZValue421(){
    valueBSave421 = 'zSqrArtSpecz421';
    var tripleBZeroA = localStorage.getItem(valueBSave421);
    document.getElementById("imgSqr422").src = tripleBZeroA;};

function artsquare422(){
    var sBQz422 = document.getElementById("aImgSqr423").src;
    valueBSave422 = 'zSqrArtSpecz422';
    localStorage.setItem(valueBSave422, sBQz422);
};
function squareBToSzzZValue422(){
    valueBSave422 = 'zSqrArtSpecz422';
    var tripleBZeroA = localStorage.getItem(valueBSave422);
    document.getElementById("imgSqr423").src = tripleBZeroA;};

function artsquare423(){
    var sBQz423 = document.getElementById("aImgSqr424").src;
    valueBSave423 = 'zSqrArtSpecz423';
    localStorage.setItem(valueBSave423, sBQz423);
};
function squareBToSzzZValue423(){
    valueBSave423 = 'zSqrArtSpecz423';
    var tripleBZeroA = localStorage.getItem(valueBSave423);
    document.getElementById("imgSqr424").src = tripleBZeroA;};

function artsquare424(){
    var sBQz424 = document.getElementById("aImgSqr425").src;
    valueBSave424 = 'zSqrArtSpecz424';
    localStorage.setItem(valueBSave424, sBQz424);
};
function squareBToSzzZValue424(){
    valueBSave424 = 'zSqrArtSpecz424';
    var tripleBZeroA = localStorage.getItem(valueBSave424);
    document.getElementById("imgSqr425").src = tripleBZeroA;};

function artsquare425(){
    var sBQz425 = document.getElementById("aImgSqr426").src;
    valueBSave425 = 'zSqrArtSpecz425';
    localStorage.setItem(valueBSave425, sBQz425);
};
function squareBToSzzZValue425(){
    valueBSave425 = 'zSqrArtSpecz425';
    var tripleBZeroA = localStorage.getItem(valueBSave425);
    document.getElementById("imgSqr426").src = tripleBZeroA;};

function artsquare426(){
    var sBQz426 = document.getElementById("aImgSqr427").src;
    valueBSave426 = 'zSqrArtSpecz426';
    localStorage.setItem(valueBSave426, sBQz426);
};
function squareBToSzzZValue426(){
    valueBSave426 = 'zSqrArtSpecz426';
    var tripleBZeroA = localStorage.getItem(valueBSave426);
    document.getElementById("imgSqr427").src = tripleBZeroA;};

function artsquare427(){
    var sBQz427 = document.getElementById("aImgSqr428").src;
    valueBSave427 = 'zSqrArtSpecz427';
    localStorage.setItem(valueBSave427, sBQz427);
};
function squareBToSzzZValue427(){
    valueBSave427 = 'zSqrArtSpecz427';
    var tripleBZeroA = localStorage.getItem(valueBSave427);
    document.getElementById("imgSqr428").src = tripleBZeroA;};

function artsquare428(){
    var sBQz428 = document.getElementById("aImgSqr429").src;
    valueBSave428 = 'zSqrArtSpecz428';
    localStorage.setItem(valueBSave428, sBQz428);
};
function squareBToSzzZValue428(){
    valueBSave428 = 'zSqrArtSpecz428';
    var tripleBZeroA = localStorage.getItem(valueBSave428);
    document.getElementById("imgSqr429").src = tripleBZeroA;};

function artsquare429(){
    var sBQz429 = document.getElementById("aImgSqr430").src;
    valueBSave429 = 'zSqrArtSpecz429';
    localStorage.setItem(valueBSave429, sBQz429);
};
function squareBToSzzZValue429(){
    valueBSave429 = 'zSqrArtSpecz429';
    var tripleBZeroA = localStorage.getItem(valueBSave429);
    document.getElementById("imgSqr430").src = tripleBZeroA;};

function artsquare430(){
    var sBQz430 = document.getElementById("aImgSqr431").src;
    valueBSave430 = 'zSqrArtSpecz430';
    localStorage.setItem(valueBSave430, sBQz430);
};
function squareBToSzzZValue430(){
    valueBSave430 = 'zSqrArtSpecz430';
    var tripleBZeroA = localStorage.getItem(valueBSave430);
    document.getElementById("imgSqr431").src = tripleBZeroA;};

function artsquare431(){
    var sBQz431 = document.getElementById("aImgSqr432").src;
    valueBSave431 = 'zSqrArtSpecz431';
    localStorage.setItem(valueBSave431, sBQz431);
};
function squareBToSzzZValue431(){
    valueBSave431 = 'zSqrArtSpecz431';
    var tripleBZeroA = localStorage.getItem(valueBSave431);
    document.getElementById("imgSqr432").src = tripleBZeroA;};

function artsquare432(){
    var sBQz432 = document.getElementById("aImgSqr433").src;
    valueBSave432 = 'zSqrArtSpecz432';
    localStorage.setItem(valueBSave432, sBQz432);
};
function squareBToSzzZValue432(){
    valueBSave432 = 'zSqrArtSpecz432';
    var tripleBZeroA = localStorage.getItem(valueBSave432);
    document.getElementById("imgSqr433").src = tripleBZeroA;};

function artsquare433(){
    var sBQz433 = document.getElementById("aImgSqr434").src;
    valueBSave433 = 'zSqrArtSpecz433';
    localStorage.setItem(valueBSave433, sBQz433);
};
function squareBToSzzZValue433(){
    valueBSave433 = 'zSqrArtSpecz433';
    var tripleBZeroA = localStorage.getItem(valueBSave433);
    document.getElementById("imgSqr434").src = tripleBZeroA;};

function artsquare434(){
    var sBQz434 = document.getElementById("aImgSqr435").src;
    valueBSave434 = 'zSqrArtSpecz434';
    localStorage.setItem(valueBSave434, sBQz434);
};
function squareBToSzzZValue434(){
    valueBSave434 = 'zSqrArtSpecz434';
    var tripleBZeroA = localStorage.getItem(valueBSave434);
    document.getElementById("imgSqr435").src = tripleBZeroA;};

function artsquare435(){
    var sBQz435 = document.getElementById("aImgSqr436").src;
    valueBSave435 = 'zSqrArtSpecz435';
    localStorage.setItem(valueBSave435, sBQz435);
};
function squareBToSzzZValue435(){
    valueBSave435 = 'zSqrArtSpecz435';
    var tripleBZeroA = localStorage.getItem(valueBSave435);
    document.getElementById("imgSqr436").src = tripleBZeroA;};

function artsquare436(){
    var sBQz436 = document.getElementById("aImgSqr437").src;
    valueBSave436 = 'zSqrArtSpecz436';
    localStorage.setItem(valueBSave436, sBQz436);
};
function squareBToSzzZValue436(){
    valueBSave436 = 'zSqrArtSpecz436';
    var tripleBZeroA = localStorage.getItem(valueBSave436);
    document.getElementById("imgSqr437").src = tripleBZeroA;};

function artsquare437(){
    var sBQz437 = document.getElementById("aImgSqr438").src;
    valueBSave437 = 'zSqrArtSpecz437';
    localStorage.setItem(valueBSave437, sBQz437);
};
function squareBToSzzZValue437(){
    valueBSave437 = 'zSqrArtSpecz437';
    var tripleBZeroA = localStorage.getItem(valueBSave437);
    document.getElementById("imgSqr438").src = tripleBZeroA;};

function artsquare438(){
    var sBQz438 = document.getElementById("aImgSqr439").src;
    valueBSave438 = 'zSqrArtSpecz438';
    localStorage.setItem(valueBSave438, sBQz438);
};
function squareBToSzzZValue438(){
    valueBSave438 = 'zSqrArtSpecz438';
    var tripleBZeroA = localStorage.getItem(valueBSave438);
    document.getElementById("imgSqr439").src = tripleBZeroA;};

function artsquare439(){
    var sBQz439 = document.getElementById("aImgSqr440").src;
    valueBSave439 = 'zSqrArtSpecz439';
    localStorage.setItem(valueBSave439, sBQz439);
};
function squareBToSzzZValue439(){
    valueBSave439 = 'zSqrArtSpecz439';
    var tripleBZeroA = localStorage.getItem(valueBSave439);
    document.getElementById("imgSqr440").src = tripleBZeroA;};

function artsquare440(){
    var sBQz440 = document.getElementById("aImgSqr441").src;
    valueBSave440 = 'zSqrArtSpecz440';
    localStorage.setItem(valueBSave440, sBQz440);
};
function squareBToSzzZValue440(){
    valueBSave440 = 'zSqrArtSpecz440';
    var tripleBZeroA = localStorage.getItem(valueBSave440);
    document.getElementById("imgSqr441").src = tripleBZeroA;};

function artsquare441(){
    var sBQz441 = document.getElementById("aImgSqr442").src;
    valueBSave441 = 'zSqrArtSpecz441';
    localStorage.setItem(valueBSave441, sBQz441);
};
function squareBToSzzZValue441(){
    valueBSave441 = 'zSqrArtSpecz441';
    var tripleBZeroA = localStorage.getItem(valueBSave441);
    document.getElementById("imgSqr442").src = tripleBZeroA;};

function artsquare442(){
    var sBQz442 = document.getElementById("aImgSqr443").src;
    valueBSave442 = 'zSqrArtSpecz442';
    localStorage.setItem(valueBSave442, sBQz442);
};
function squareBToSzzZValue442(){
    valueBSave442 = 'zSqrArtSpecz442';
    var tripleBZeroA = localStorage.getItem(valueBSave442);
    document.getElementById("imgSqr443").src = tripleBZeroA;};

function artsquare443(){
    var sBQz443 = document.getElementById("aImgSqr444").src;
    valueBSave443 = 'zSqrArtSpecz443';
    localStorage.setItem(valueBSave443, sBQz443);
};
function squareBToSzzZValue443(){
    valueBSave443 = 'zSqrArtSpecz443';
    var tripleBZeroA = localStorage.getItem(valueBSave443);
    document.getElementById("imgSqr444").src = tripleBZeroA;};

function artsquare444(){
    var sBQz444 = document.getElementById("aImgSqr445").src;
    valueBSave444 = 'zSqrArtSpecz444';
    localStorage.setItem(valueBSave444, sBQz444);
};
function squareBToSzzZValue444(){
    valueBSave444 = 'zSqrArtSpecz444';
    var tripleBZeroA = localStorage.getItem(valueBSave444);
    document.getElementById("imgSqr445").src = tripleBZeroA;};

function artsquare445(){
    var sBQz445 = document.getElementById("aImgSqr446").src;
    valueBSave445 = 'zSqrArtSpecz445';
    localStorage.setItem(valueBSave445, sBQz445);
};
function squareBToSzzZValue445(){
    valueBSave445 = 'zSqrArtSpecz445';
    var tripleBZeroA = localStorage.getItem(valueBSave445);
    document.getElementById("imgSqr446").src = tripleBZeroA;};

function artsquare446(){
    var sBQz446 = document.getElementById("aImgSqr447").src;
    valueBSave446 = 'zSqrArtSpecz446';
    localStorage.setItem(valueBSave446, sBQz446);
};
function squareBToSzzZValue446(){
    valueBSave446 = 'zSqrArtSpecz446';
    var tripleBZeroA = localStorage.getItem(valueBSave446);
    document.getElementById("imgSqr447").src = tripleBZeroA;};

function artsquare447(){
    var sBQz447 = document.getElementById("aImgSqr448").src;
    valueBSave447 = 'zSqrArtSpecz447';
    localStorage.setItem(valueBSave447, sBQz447);
};
function squareBToSzzZValue447(){
    valueBSave447 = 'zSqrArtSpecz447';
    var tripleBZeroA = localStorage.getItem(valueBSave447);
    document.getElementById("imgSqr448").src = tripleBZeroA;};

function artsquare448(){
    var sBQz448 = document.getElementById("aImgSqr449").src;
    valueBSave448 = 'zSqrArtSpecz448';
    localStorage.setItem(valueBSave448, sBQz448);
};
function squareBToSzzZValue448(){
    valueBSave448 = 'zSqrArtSpecz448';
    var tripleBZeroA = localStorage.getItem(valueBSave448);
    document.getElementById("imgSqr449").src = tripleBZeroA;};

function artsquare449(){
    var sBQz449 = document.getElementById("aImgSqr450").src;
    valueBSave449 = 'zSqrArtSpecz449';
    localStorage.setItem(valueBSave449, sBQz449);
};
function squareBToSzzZValue449(){
    valueBSave449 = 'zSqrArtSpecz449';
    var tripleBZeroA = localStorage.getItem(valueBSave449);
    document.getElementById("imgSqr450").src = tripleBZeroA;};

function artsquare450(){
    var sBQz450 = document.getElementById("aImgSqr451").src;
    valueBSave450 = 'zSqrArtSpecz450';
    localStorage.setItem(valueBSave450, sBQz450);
};
function squareBToSzzZValue450(){
    valueBSave450 = 'zSqrArtSpecz450';
    var tripleBZeroA = localStorage.getItem(valueBSave450);
    document.getElementById("imgSqr451").src = tripleBZeroA;};

function artsquare451(){
    var sBQz451 = document.getElementById("aImgSqr452").src;
    valueBSave451 = 'zSqrArtSpecz451';
    localStorage.setItem(valueBSave451, sBQz451);
};
function squareBToSzzZValue451(){
    valueBSave451 = 'zSqrArtSpecz451';
    var tripleBZeroA = localStorage.getItem(valueBSave451);
    document.getElementById("imgSqr452").src = tripleBZeroA;};

function artsquare452(){
    var sBQz452 = document.getElementById("aImgSqr453").src;
    valueBSave452 = 'zSqrArtSpecz452';
    localStorage.setItem(valueBSave452, sBQz452);
};
function squareBToSzzZValue452(){
    valueBSave452 = 'zSqrArtSpecz452';
    var tripleBZeroA = localStorage.getItem(valueBSave452);
    document.getElementById("imgSqr453").src = tripleBZeroA;};

function artsquare453(){
    var sBQz453 = document.getElementById("aImgSqr454").src;
    valueBSave453 = 'zSqrArtSpecz453';
    localStorage.setItem(valueBSave453, sBQz453);
};
function squareBToSzzZValue453(){
    valueBSave453 = 'zSqrArtSpecz453';
    var tripleBZeroA = localStorage.getItem(valueBSave453);
    document.getElementById("imgSqr454").src = tripleBZeroA;};

function artsquare454(){
    var sBQz454 = document.getElementById("aImgSqr455").src;
    valueBSave454 = 'zSqrArtSpecz454';
    localStorage.setItem(valueBSave454, sBQz454);
};
function squareBToSzzZValue454(){
    valueBSave454 = 'zSqrArtSpecz454';
    var tripleBZeroA = localStorage.getItem(valueBSave454);
    document.getElementById("imgSqr455").src = tripleBZeroA;};

function artsquare455(){
    var sBQz455 = document.getElementById("aImgSqr456").src;
    valueBSave455 = 'zSqrArtSpecz455';
    localStorage.setItem(valueBSave455, sBQz455);
};
function squareBToSzzZValue455(){
    valueBSave455 = 'zSqrArtSpecz455';
    var tripleBZeroA = localStorage.getItem(valueBSave455);
    document.getElementById("imgSqr456").src = tripleBZeroA;};

function artsquare456(){
    var sBQz456 = document.getElementById("aImgSqr457").src;
    valueBSave456 = 'zSqrArtSpecz456';
    localStorage.setItem(valueBSave456, sBQz456);
};
function squareBToSzzZValue456(){
    valueBSave456 = 'zSqrArtSpecz456';
    var tripleBZeroA = localStorage.getItem(valueBSave456);
    document.getElementById("imgSqr457").src = tripleBZeroA;};

function artsquare457(){
    var sBQz457 = document.getElementById("aImgSqr458").src;
    valueBSave457 = 'zSqrArtSpecz457';
    localStorage.setItem(valueBSave457, sBQz457);
};
function squareBToSzzZValue457(){
    valueBSave457 = 'zSqrArtSpecz457';
    var tripleBZeroA = localStorage.getItem(valueBSave457);
    document.getElementById("imgSqr458").src = tripleBZeroA;};

function artsquare458(){
    var sBQz458 = document.getElementById("aImgSqr459").src;
    valueBSave458 = 'zSqrArtSpecz458';
    localStorage.setItem(valueBSave458, sBQz458);
};
function squareBToSzzZValue458(){
    valueBSave458 = 'zSqrArtSpecz458';
    var tripleBZeroA = localStorage.getItem(valueBSave458);
    document.getElementById("imgSqr459").src = tripleBZeroA;};

function artsquare459(){
    var sBQz459 = document.getElementById("aImgSqr460").src;
    valueBSave459 = 'zSqrArtSpecz459';
    localStorage.setItem(valueBSave459, sBQz459);
};
function squareBToSzzZValue459(){
    valueBSave459 = 'zSqrArtSpecz459';
    var tripleBZeroA = localStorage.getItem(valueBSave459);
    document.getElementById("imgSqr460").src = tripleBZeroA;};

function artsquare460(){
    var sBQz460 = document.getElementById("aImgSqr461").src;
    valueBSave460 = 'zSqrArtSpecz460';
    localStorage.setItem(valueBSave460, sBQz460);
};
function squareBToSzzZValue460(){
    valueBSave460 = 'zSqrArtSpecz460';
    var tripleBZeroA = localStorage.getItem(valueBSave460);
    document.getElementById("imgSqr461").src = tripleBZeroA;};

function artsquare461(){
    var sBQz461 = document.getElementById("aImgSqr462").src;
    valueBSave461 = 'zSqrArtSpecz461';
    localStorage.setItem(valueBSave461, sBQz461);
};
function squareBToSzzZValue461(){
    valueBSave461 = 'zSqrArtSpecz461';
    var tripleBZeroA = localStorage.getItem(valueBSave461);
    document.getElementById("imgSqr462").src = tripleBZeroA;};

function artsquare462(){
    var sBQz462 = document.getElementById("aImgSqr463").src;
    valueBSave462 = 'zSqrArtSpecz462';
    localStorage.setItem(valueBSave462, sBQz462);
};
function squareBToSzzZValue462(){
    valueBSave462 = 'zSqrArtSpecz462';
    var tripleBZeroA = localStorage.getItem(valueBSave462);
    document.getElementById("imgSqr463").src = tripleBZeroA;};

function artsquare463(){
    var sBQz463 = document.getElementById("aImgSqr464").src;
    valueBSave463 = 'zSqrArtSpecz463';
    localStorage.setItem(valueBSave463, sBQz463);
};
function squareBToSzzZValue463(){
    valueBSave463 = 'zSqrArtSpecz463';
    var tripleBZeroA = localStorage.getItem(valueBSave463);
    document.getElementById("imgSqr464").src = tripleBZeroA;};

function artsquare464(){
    var sBQz464 = document.getElementById("aImgSqr465").src;
    valueBSave464 = 'zSqrArtSpecz464';
    localStorage.setItem(valueBSave464, sBQz464);
};
function squareBToSzzZValue464(){
    valueBSave464 = 'zSqrArtSpecz464';
    var tripleBZeroA = localStorage.getItem(valueBSave464);
    document.getElementById("imgSqr465").src = tripleBZeroA;};

function artsquare465(){
    var sBQz465 = document.getElementById("aImgSqr466").src;
    valueBSave465 = 'zSqrArtSpecz465';
    localStorage.setItem(valueBSave465, sBQz465);
};
function squareBToSzzZValue465(){
    valueBSave465 = 'zSqrArtSpecz465';
    var tripleBZeroA = localStorage.getItem(valueBSave465);
    document.getElementById("imgSqr466").src = tripleBZeroA;};

function artsquare466(){
    var sBQz466 = document.getElementById("aImgSqr467").src;
    valueBSave466 = 'zSqrArtSpecz466';
    localStorage.setItem(valueBSave466, sBQz466);
};
function squareBToSzzZValue466(){
    valueBSave466 = 'zSqrArtSpecz466';
    var tripleBZeroA = localStorage.getItem(valueBSave466);
    document.getElementById("imgSqr467").src = tripleBZeroA;};

function artsquare467(){
    var sBQz467 = document.getElementById("aImgSqr468").src;
    valueBSave467 = 'zSqrArtSpecz467';
    localStorage.setItem(valueBSave467, sBQz467);
};
function squareBToSzzZValue467(){
    valueBSave467 = 'zSqrArtSpecz467';
    var tripleBZeroA = localStorage.getItem(valueBSave467);
    document.getElementById("imgSqr468").src = tripleBZeroA;};

function artsquare468(){
    var sBQz468 = document.getElementById("aImgSqr469").src;
    valueBSave468 = 'zSqrArtSpecz468';
    localStorage.setItem(valueBSave468, sBQz468);
};
function squareBToSzzZValue468(){
    valueBSave468 = 'zSqrArtSpecz468';
    var tripleBZeroA = localStorage.getItem(valueBSave468);
    document.getElementById("imgSqr469").src = tripleBZeroA;};

function artsquare469(){
    var sBQz469 = document.getElementById("aImgSqr470").src;
    valueBSave469 = 'zSqrArtSpecz469';
    localStorage.setItem(valueBSave469, sBQz469);
};
function squareBToSzzZValue469(){
    valueBSave469 = 'zSqrArtSpecz469';
    var tripleBZeroA = localStorage.getItem(valueBSave469);
    document.getElementById("imgSqr470").src = tripleBZeroA;};

function artsquare470(){
    var sBQz470 = document.getElementById("aImgSqr471").src;
    valueBSave470 = 'zSqrArtSpecz470';
    localStorage.setItem(valueBSave470, sBQz470);
};
function squareBToSzzZValue470(){
    valueBSave470 = 'zSqrArtSpecz470';
    var tripleBZeroA = localStorage.getItem(valueBSave470);
    document.getElementById("imgSqr471").src = tripleBZeroA;};

function artsquare471(){
    var sBQz471 = document.getElementById("aImgSqr472").src;
    valueBSave471 = 'zSqrArtSpecz471';
    localStorage.setItem(valueBSave471, sBQz471);
};
function squareBToSzzZValue471(){
    valueBSave471 = 'zSqrArtSpecz471';
    var tripleBZeroA = localStorage.getItem(valueBSave471);
    document.getElementById("imgSqr472").src = tripleBZeroA;};

function artsquare472(){
    var sBQz472 = document.getElementById("aImgSqr473").src;
    valueBSave472 = 'zSqrArtSpecz472';
    localStorage.setItem(valueBSave472, sBQz472);
};
function squareBToSzzZValue472(){
    valueBSave472 = 'zSqrArtSpecz472';
    var tripleBZeroA = localStorage.getItem(valueBSave472);
    document.getElementById("imgSqr473").src = tripleBZeroA;};

function artsquare473(){
    var sBQz473 = document.getElementById("aImgSqr474").src;
    valueBSave473 = 'zSqrArtSpecz473';
    localStorage.setItem(valueBSave473, sBQz473);
};
function squareBToSzzZValue473(){
    valueBSave473 = 'zSqrArtSpecz473';
    var tripleBZeroA = localStorage.getItem(valueBSave473);
    document.getElementById("imgSqr474").src = tripleBZeroA;};

function artsquare474(){
    var sBQz474 = document.getElementById("aImgSqr475").src;
    valueBSave474 = 'zSqrArtSpecz474';
    localStorage.setItem(valueBSave474, sBQz474);
};
function squareBToSzzZValue474(){
    valueBSave474 = 'zSqrArtSpecz474';
    var tripleBZeroA = localStorage.getItem(valueBSave474);
    document.getElementById("imgSqr475").src = tripleBZeroA;};

function artsquare475(){
    var sBQz475 = document.getElementById("aImgSqr476").src;
    valueBSave475 = 'zSqrArtSpecz475';
    localStorage.setItem(valueBSave475, sBQz475);
};
function squareBToSzzZValue475(){
    valueBSave475 = 'zSqrArtSpecz475';
    var tripleBZeroA = localStorage.getItem(valueBSave475);
    document.getElementById("imgSqr476").src = tripleBZeroA;};

function artsquare476(){
    var sBQz476 = document.getElementById("aImgSqr477").src;
    valueBSave476 = 'zSqrArtSpecz476';
    localStorage.setItem(valueBSave476, sBQz476);
};
function squareBToSzzZValue476(){
    valueBSave476 = 'zSqrArtSpecz476';
    var tripleBZeroA = localStorage.getItem(valueBSave476);
    document.getElementById("imgSqr477").src = tripleBZeroA;};

function artsquare477(){
    var sBQz477 = document.getElementById("aImgSqr478").src;
    valueBSave477 = 'zSqrArtSpecz477';
    localStorage.setItem(valueBSave477, sBQz477);
};
function squareBToSzzZValue477(){
    valueBSave477 = 'zSqrArtSpecz477';
    var tripleBZeroA = localStorage.getItem(valueBSave477);
    document.getElementById("imgSqr478").src = tripleBZeroA;};

function artsquare478(){
    var sBQz478 = document.getElementById("aImgSqr479").src;
    valueBSave478 = 'zSqrArtSpecz478';
    localStorage.setItem(valueBSave478, sBQz478);
};
function squareBToSzzZValue478(){
    valueBSave478 = 'zSqrArtSpecz478';
    var tripleBZeroA = localStorage.getItem(valueBSave478);
    document.getElementById("imgSqr479").src = tripleBZeroA;};

function artsquare479(){
    var sBQz479 = document.getElementById("aImgSqr480").src;
    valueBSave479 = 'zSqrArtSpecz479';
    localStorage.setItem(valueBSave479, sBQz479);
};
function squareBToSzzZValue479(){
    valueBSave479 = 'zSqrArtSpecz479';
    var tripleBZeroA = localStorage.getItem(valueBSave479);
    document.getElementById("imgSqr480").src = tripleBZeroA;};

function artsquare480(){
    var sBQz480 = document.getElementById("aImgSqr481").src;
    valueBSave480 = 'zSqrArtSpecz480';
    localStorage.setItem(valueBSave480, sBQz480);
};
function squareBToSzzZValue480(){
    valueBSave480 = 'zSqrArtSpecz480';
    var tripleBZeroA = localStorage.getItem(valueBSave480);
    document.getElementById("imgSqr481").src = tripleBZeroA;};

function artsquare481(){
    var sBQz481 = document.getElementById("aImgSqr482").src;
    valueBSave481 = 'zSqrArtSpecz481';
    localStorage.setItem(valueBSave481, sBQz481);
};
function squareBToSzzZValue481(){
    valueBSave481 = 'zSqrArtSpecz481';
    var tripleBZeroA = localStorage.getItem(valueBSave481);
    document.getElementById("imgSqr482").src = tripleBZeroA;};

function artsquare482(){
    var sBQz482 = document.getElementById("aImgSqr483").src;
    valueBSave482 = 'zSqrArtSpecz482';
    localStorage.setItem(valueBSave482, sBQz482);
};
function squareBToSzzZValue482(){
    valueBSave482 = 'zSqrArtSpecz482';
    var tripleBZeroA = localStorage.getItem(valueBSave482);
    document.getElementById("imgSqr483").src = tripleBZeroA;};

function artsquare483(){
    var sBQz483 = document.getElementById("aImgSqr484").src;
    valueBSave483 = 'zSqrArtSpecz483';
    localStorage.setItem(valueBSave483, sBQz483);
};
function squareBToSzzZValue483(){
    valueBSave483 = 'zSqrArtSpecz483';
    var tripleBZeroA = localStorage.getItem(valueBSave483);
    document.getElementById("imgSqr484").src = tripleBZeroA;};

function artsquare484(){
    var sBQz484 = document.getElementById("aImgSqr485").src;
    valueBSave484 = 'zSqrArtSpecz484';
    localStorage.setItem(valueBSave484, sBQz484);
};
function squareBToSzzZValue484(){
    valueBSave484 = 'zSqrArtSpecz484';
    var tripleBZeroA = localStorage.getItem(valueBSave484);
    document.getElementById("imgSqr485").src = tripleBZeroA;};

function artsquare485(){
    var sBQz485 = document.getElementById("aImgSqr486").src;
    valueBSave485 = 'zSqrArtSpecz485';
    localStorage.setItem(valueBSave485, sBQz485);
};
function squareBToSzzZValue485(){
    valueBSave485 = 'zSqrArtSpecz485';
    var tripleBZeroA = localStorage.getItem(valueBSave485);
    document.getElementById("imgSqr486").src = tripleBZeroA;};

function artsquare486(){
    var sBQz486 = document.getElementById("aImgSqr487").src;
    valueBSave486 = 'zSqrArtSpecz486';
    localStorage.setItem(valueBSave486, sBQz486);
};
function squareBToSzzZValue486(){
    valueBSave486 = 'zSqrArtSpecz486';
    var tripleBZeroA = localStorage.getItem(valueBSave486);
    document.getElementById("imgSqr487").src = tripleBZeroA;};

function artsquare487(){
    var sBQz487 = document.getElementById("aImgSqr488").src;
    valueBSave487 = 'zSqrArtSpecz487';
    localStorage.setItem(valueBSave487, sBQz487);
};
function squareBToSzzZValue487(){
    valueBSave487 = 'zSqrArtSpecz487';
    var tripleBZeroA = localStorage.getItem(valueBSave487);
    document.getElementById("imgSqr488").src = tripleBZeroA;};

function artsquare488(){
    var sBQz488 = document.getElementById("aImgSqr489").src;
    valueBSave488 = 'zSqrArtSpecz488';
    localStorage.setItem(valueBSave488, sBQz488);
};
function squareBToSzzZValue488(){
    valueBSave488 = 'zSqrArtSpecz488';
    var tripleBZeroA = localStorage.getItem(valueBSave488);
    document.getElementById("imgSqr489").src = tripleBZeroA;};

function artsquare489(){
    var sBQz489 = document.getElementById("aImgSqr490").src;
    valueBSave489 = 'zSqrArtSpecz489';
    localStorage.setItem(valueBSave489, sBQz489);
};
function squareBToSzzZValue489(){
    valueBSave489 = 'zSqrArtSpecz489';
    var tripleBZeroA = localStorage.getItem(valueBSave489);
    document.getElementById("imgSqr490").src = tripleBZeroA;};

function artsquare490(){
    var sBQz490 = document.getElementById("aImgSqr491").src;
    valueBSave490 = 'zSqrArtSpecz490';
    localStorage.setItem(valueBSave490, sBQz490);
};
function squareBToSzzZValue490(){
    valueBSave490 = 'zSqrArtSpecz490';
    var tripleBZeroA = localStorage.getItem(valueBSave490);
    document.getElementById("imgSqr491").src = tripleBZeroA;};

function artsquare491(){
    var sBQz491 = document.getElementById("aImgSqr492").src;
    valueBSave491 = 'zSqrArtSpecz491';
    localStorage.setItem(valueBSave491, sBQz491);
};
function squareBToSzzZValue491(){
    valueBSave491 = 'zSqrArtSpecz491';
    var tripleBZeroA = localStorage.getItem(valueBSave491);
    document.getElementById("imgSqr492").src = tripleBZeroA;};

function artsquare492(){
    var sBQz492 = document.getElementById("aImgSqr493").src;
    valueBSave492 = 'zSqrArtSpecz492';
    localStorage.setItem(valueBSave492, sBQz492);
};
function squareBToSzzZValue492(){
    valueBSave492 = 'zSqrArtSpecz492';
    var tripleBZeroA = localStorage.getItem(valueBSave492);
    document.getElementById("imgSqr493").src = tripleBZeroA;};

function artsquare493(){
    var sBQz493 = document.getElementById("aImgSqr494").src;
    valueBSave493 = 'zSqrArtSpecz493';
    localStorage.setItem(valueBSave493, sBQz493);
};
function squareBToSzzZValue493(){
    valueBSave493 = 'zSqrArtSpecz493';
    var tripleBZeroA = localStorage.getItem(valueBSave493);
    document.getElementById("imgSqr494").src = tripleBZeroA;};

function artsquare494(){
    var sBQz494 = document.getElementById("aImgSqr495").src;
    valueBSave494 = 'zSqrArtSpecz494';
    localStorage.setItem(valueBSave494, sBQz494);
};
function squareBToSzzZValue494(){
    valueBSave494 = 'zSqrArtSpecz494';
    var tripleBZeroA = localStorage.getItem(valueBSave494);
    document.getElementById("imgSqr495").src = tripleBZeroA;};

function artsquare495(){
    var sBQz495 = document.getElementById("aImgSqr496").src;
    valueBSave495 = 'zSqrArtSpecz495';
    localStorage.setItem(valueBSave495, sBQz495);
};
function squareBToSzzZValue495(){
    valueBSave495 = 'zSqrArtSpecz495';
    var tripleBZeroA = localStorage.getItem(valueBSave495);
    document.getElementById("imgSqr496").src = tripleBZeroA;};

function artsquare496(){
    var sBQz496 = document.getElementById("aImgSqr497").src;
    valueBSave496 = 'zSqrArtSpecz496';
    localStorage.setItem(valueBSave496, sBQz496);
};
function squareBToSzzZValue496(){
    valueBSave496 = 'zSqrArtSpecz496';
    var tripleBZeroA = localStorage.getItem(valueBSave496);
    document.getElementById("imgSqr497").src = tripleBZeroA;};

function artsquare497(){
    var sBQz497 = document.getElementById("aImgSqr498").src;
    valueBSave497 = 'zSqrArtSpecz497';
    localStorage.setItem(valueBSave497, sBQz497);
};
function squareBToSzzZValue497(){
    valueBSave497 = 'zSqrArtSpecz497';
    var tripleBZeroA = localStorage.getItem(valueBSave497);
    document.getElementById("imgSqr498").src = tripleBZeroA;};

function artsquare498(){
    var sBQz498 = document.getElementById("aImgSqr499").src;
    valueBSave498 = 'zSqrArtSpecz498';
    localStorage.setItem(valueBSave498, sBQz498);
};
function squareBToSzzZValue498(){
    valueBSave498 = 'zSqrArtSpecz498';
    var tripleBZeroA = localStorage.getItem(valueBSave498);
    document.getElementById("imgSqr499").src = tripleBZeroA;};

function artsquare499(){
    var sBQz499 = document.getElementById("aImgSqr500").src;
    valueBSave499 = 'zSqrArtSpecz499';
    localStorage.setItem(valueBSave499, sBQz499);
};
function squareBToSzzZValue499(){
    valueBSave499 = 'zSqrArtSpecz499';
    var tripleBZeroA = localStorage.getItem(valueBSave499);
    document.getElementById("imgSqr500").src = tripleBZeroA;};

function artsquare500(){
    var sBQz500 = document.getElementById("aImgSqr501").src;
    valueBSave500 = 'zSqrArtSpecz500';
    localStorage.setItem(valueBSave500, sBQz500);
};
function squareBToSzzZValue500(){
    valueBSave500 = 'zSqrArtSpecz500';
    var tripleBZeroA = localStorage.getItem(valueBSave500);
    document.getElementById("imgSqr501").src = tripleBZeroA;};

function artsquare501(){
    var sBQz501 = document.getElementById("aImgSqr502").src;
    valueBSave501 = 'zSqrArtSpecz501';
    localStorage.setItem(valueBSave501, sBQz501);
};
function squareBToSzzZValue501(){
    valueBSave501 = 'zSqrArtSpecz501';
    var tripleBZeroA = localStorage.getItem(valueBSave501);
    document.getElementById("imgSqr502").src = tripleBZeroA;};

function artsquare502(){
    var sBQz502 = document.getElementById("aImgSqr503").src;
    valueBSave502 = 'zSqrArtSpecz502';
    localStorage.setItem(valueBSave502, sBQz502);
};
function squareBToSzzZValue502(){
    valueBSave502 = 'zSqrArtSpecz502';
    var tripleBZeroA = localStorage.getItem(valueBSave502);
    document.getElementById("imgSqr503").src = tripleBZeroA;};

function artsquare503(){
    var sBQz503 = document.getElementById("aImgSqr504").src;
    valueBSave503 = 'zSqrArtSpecz503';
    localStorage.setItem(valueBSave503, sBQz503);
};
function squareBToSzzZValue503(){
    valueBSave503 = 'zSqrArtSpecz503';
    var tripleBZeroA = localStorage.getItem(valueBSave503);
    document.getElementById("imgSqr504").src = tripleBZeroA;};

function artsquare504(){
    var sBQz504 = document.getElementById("aImgSqr505").src;
    valueBSave504 = 'zSqrArtSpecz504';
    localStorage.setItem(valueBSave504, sBQz504);
};
function squareBToSzzZValue504(){
    valueBSave504 = 'zSqrArtSpecz504';
    var tripleBZeroA = localStorage.getItem(valueBSave504);
    document.getElementById("imgSqr505").src = tripleBZeroA;};

function artsquare505(){
    var sBQz505 = document.getElementById("aImgSqr506").src;
    valueBSave505 = 'zSqrArtSpecz505';
    localStorage.setItem(valueBSave505, sBQz505);
};
function squareBToSzzZValue505(){
    valueBSave505 = 'zSqrArtSpecz505';
    var tripleBZeroA = localStorage.getItem(valueBSave505);
    document.getElementById("imgSqr506").src = tripleBZeroA;};

function artsquare506(){
    var sBQz506 = document.getElementById("aImgSqr507").src;
    valueBSave506 = 'zSqrArtSpecz506';
    localStorage.setItem(valueBSave506, sBQz506);
};
function squareBToSzzZValue506(){
    valueBSave506 = 'zSqrArtSpecz506';
    var tripleBZeroA = localStorage.getItem(valueBSave506);
    document.getElementById("imgSqr507").src = tripleBZeroA;};

function artsquare507(){
    var sBQz507 = document.getElementById("aImgSqr508").src;
    valueBSave507 = 'zSqrArtSpecz507';
    localStorage.setItem(valueBSave507, sBQz507);
};
function squareBToSzzZValue507(){
    valueBSave507 = 'zSqrArtSpecz507';
    var tripleBZeroA = localStorage.getItem(valueBSave507);
    document.getElementById("imgSqr508").src = tripleBZeroA;};

function artsquare508(){
    var sBQz508 = document.getElementById("aImgSqr509").src;
    valueBSave508 = 'zSqrArtSpecz508';
    localStorage.setItem(valueBSave508, sBQz508);
};
function squareBToSzzZValue508(){
    valueBSave508 = 'zSqrArtSpecz508';
    var tripleBZeroA = localStorage.getItem(valueBSave508);
    document.getElementById("imgSqr509").src = tripleBZeroA;};

function artsquare509(){
    var sBQz509 = document.getElementById("aImgSqr510").src;
    valueBSave509 = 'zSqrArtSpecz509';
    localStorage.setItem(valueBSave509, sBQz509);
};
function squareBToSzzZValue509(){
    valueBSave509 = 'zSqrArtSpecz509';
    var tripleBZeroA = localStorage.getItem(valueBSave509);
    document.getElementById("imgSqr510").src = tripleBZeroA;};

function artsquare510(){
    var sBQz510 = document.getElementById("aImgSqr511").src;
    valueBSave510 = 'zSqrArtSpecz510';
    localStorage.setItem(valueBSave510, sBQz510);
};
function squareBToSzzZValue510(){
    valueBSave510 = 'zSqrArtSpecz510';
    var tripleBZeroA = localStorage.getItem(valueBSave510);
    document.getElementById("imgSqr511").src = tripleBZeroA;};

function artsquare511(){
    var sBQz511 = document.getElementById("aImgSqr512").src;
    valueBSave511 = 'zSqrArtSpecz511';
    localStorage.setItem(valueBSave511, sBQz511);
};
function squareBToSzzZValue511(){
    valueBSave511 = 'zSqrArtSpecz511';
    var tripleBZeroA = localStorage.getItem(valueBSave511);
    document.getElementById("imgSqr512").src = tripleBZeroA;};

function artsquare512(){
    var sBQz512 = document.getElementById("aImgSqr513").src;
    valueBSave512 = 'zSqrArtSpecz512';
    localStorage.setItem(valueBSave512, sBQz512);
};
function squareBToSzzZValue512(){
    valueBSave512 = 'zSqrArtSpecz512';
    var tripleBZeroA = localStorage.getItem(valueBSave512);
    document.getElementById("imgSqr513").src = tripleBZeroA;};

function artsquare513(){
    var sBQz513 = document.getElementById("aImgSqr514").src;
    valueBSave513 = 'zSqrArtSpecz513';
    localStorage.setItem(valueBSave513, sBQz513);
};
function squareBToSzzZValue513(){
    valueBSave513 = 'zSqrArtSpecz513';
    var tripleBZeroA = localStorage.getItem(valueBSave513);
    document.getElementById("imgSqr514").src = tripleBZeroA;};

function artsquare514(){
    var sBQz514 = document.getElementById("aImgSqr515").src;
    valueBSave514 = 'zSqrArtSpecz514';
    localStorage.setItem(valueBSave514, sBQz514);
};
function squareBToSzzZValue514(){
    valueBSave514 = 'zSqrArtSpecz514';
    var tripleBZeroA = localStorage.getItem(valueBSave514);
    document.getElementById("imgSqr515").src = tripleBZeroA;};

function artsquare515(){
    var sBQz515 = document.getElementById("aImgSqr516").src;
    valueBSave515 = 'zSqrArtSpecz515';
    localStorage.setItem(valueBSave515, sBQz515);
};
function squareBToSzzZValue515(){
    valueBSave515 = 'zSqrArtSpecz515';
    var tripleBZeroA = localStorage.getItem(valueBSave515);
    document.getElementById("imgSqr516").src = tripleBZeroA;};

function artsquare516(){
    var sBQz516 = document.getElementById("aImgSqr517").src;
    valueBSave516 = 'zSqrArtSpecz516';
    localStorage.setItem(valueBSave516, sBQz516);
};
function squareBToSzzZValue516(){
    valueBSave516 = 'zSqrArtSpecz516';
    var tripleBZeroA = localStorage.getItem(valueBSave516);
    document.getElementById("imgSqr517").src = tripleBZeroA;};

function artsquare517(){
    var sBQz517 = document.getElementById("aImgSqr518").src;
    valueBSave517 = 'zSqrArtSpecz517';
    localStorage.setItem(valueBSave517, sBQz517);
};
function squareBToSzzZValue517(){
    valueBSave517 = 'zSqrArtSpecz517';
    var tripleBZeroA = localStorage.getItem(valueBSave517);
    document.getElementById("imgSqr518").src = tripleBZeroA;};

function artsquare518(){
    var sBQz518 = document.getElementById("aImgSqr519").src;
    valueBSave518 = 'zSqrArtSpecz518';
    localStorage.setItem(valueBSave518, sBQz518);
};
function squareBToSzzZValue518(){
    valueBSave518 = 'zSqrArtSpecz518';
    var tripleBZeroA = localStorage.getItem(valueBSave518);
    document.getElementById("imgSqr519").src = tripleBZeroA;};

function artsquare519(){
    var sBQz519 = document.getElementById("aImgSqr520").src;
    valueBSave519 = 'zSqrArtSpecz519';
    localStorage.setItem(valueBSave519, sBQz519);
};
function squareBToSzzZValue519(){
    valueBSave519 = 'zSqrArtSpecz519';
    var tripleBZeroA = localStorage.getItem(valueBSave519);
    document.getElementById("imgSqr520").src = tripleBZeroA;};

function artsquare520(){
    var sBQz520 = document.getElementById("aImgSqr521").src;
    valueBSave520 = 'zSqrArtSpecz520';
    localStorage.setItem(valueBSave520, sBQz520);
};
function squareBToSzzZValue520(){
    valueBSave520 = 'zSqrArtSpecz520';
    var tripleBZeroA = localStorage.getItem(valueBSave520);
    document.getElementById("imgSqr521").src = tripleBZeroA;};

function artsquare521(){
    var sBQz521 = document.getElementById("aImgSqr522").src;
    valueBSave521 = 'zSqrArtSpecz521';
    localStorage.setItem(valueBSave521, sBQz521);
};
function squareBToSzzZValue521(){
    valueBSave521 = 'zSqrArtSpecz521';
    var tripleBZeroA = localStorage.getItem(valueBSave521);
    document.getElementById("imgSqr522").src = tripleBZeroA;};

function artsquare522(){
    var sBQz522 = document.getElementById("aImgSqr523").src;
    valueBSave522 = 'zSqrArtSpecz522';
    localStorage.setItem(valueBSave522, sBQz522);
};
function squareBToSzzZValue522(){
    valueBSave522 = 'zSqrArtSpecz522';
    var tripleBZeroA = localStorage.getItem(valueBSave522);
    document.getElementById("imgSqr523").src = tripleBZeroA;};

function artsquare523(){
    var sBQz523 = document.getElementById("aImgSqr524").src;
    valueBSave523 = 'zSqrArtSpecz523';
    localStorage.setItem(valueBSave523, sBQz523);
};
function squareBToSzzZValue523(){
    valueBSave523 = 'zSqrArtSpecz523';
    var tripleBZeroA = localStorage.getItem(valueBSave523);
    document.getElementById("imgSqr524").src = tripleBZeroA;};

function artsquare524(){
    var sBQz524 = document.getElementById("aImgSqr525").src;
    valueBSave524 = 'zSqrArtSpecz524';
    localStorage.setItem(valueBSave524, sBQz524);
};
function squareBToSzzZValue524(){
    valueBSave524 = 'zSqrArtSpecz524';
    var tripleBZeroA = localStorage.getItem(valueBSave524);
    document.getElementById("imgSqr525").src = tripleBZeroA;};

function artsquare525(){
    var sBQz525 = document.getElementById("aImgSqr526").src;
    valueBSave525 = 'zSqrArtSpecz525';
    localStorage.setItem(valueBSave525, sBQz525);
};
function squareBToSzzZValue525(){
    valueBSave525 = 'zSqrArtSpecz525';
    var tripleBZeroA = localStorage.getItem(valueBSave525);
    document.getElementById("imgSqr526").src = tripleBZeroA;};

function artsquare526(){
    var sBQz526 = document.getElementById("aImgSqr527").src;
    valueBSave526 = 'zSqrArtSpecz526';
    localStorage.setItem(valueBSave526, sBQz526);
};
function squareBToSzzZValue526(){
    valueBSave526 = 'zSqrArtSpecz526';
    var tripleBZeroA = localStorage.getItem(valueBSave526);
    document.getElementById("imgSqr527").src = tripleBZeroA;};

function artsquare527(){
    var sBQz527 = document.getElementById("aImgSqr528").src;
    valueBSave527 = 'zSqrArtSpecz527';
    localStorage.setItem(valueBSave527, sBQz527);
};
function squareBToSzzZValue527(){
    valueBSave527 = 'zSqrArtSpecz527';
    var tripleBZeroA = localStorage.getItem(valueBSave527);
    document.getElementById("imgSqr528").src = tripleBZeroA;};

function artsquare528(){
    var sBQz528 = document.getElementById("aImgSqr529").src;
    valueBSave528 = 'zSqrArtSpecz528';
    localStorage.setItem(valueBSave528, sBQz528);
};
function squareBToSzzZValue528(){
    valueBSave528 = 'zSqrArtSpecz528';
    var tripleBZeroA = localStorage.getItem(valueBSave528);
    document.getElementById("imgSqr529").src = tripleBZeroA;};

function artsquare529(){
    var sBQz529 = document.getElementById("aImgSqr530").src;
    valueBSave529 = 'zSqrArtSpecz529';
    localStorage.setItem(valueBSave529, sBQz529);
};
function squareBToSzzZValue529(){
    valueBSave529 = 'zSqrArtSpecz529';
    var tripleBZeroA = localStorage.getItem(valueBSave529);
    document.getElementById("imgSqr530").src = tripleBZeroA;};

function artsquare530(){
    var sBQz530 = document.getElementById("aImgSqr531").src;
    valueBSave530 = 'zSqrArtSpecz530';
    localStorage.setItem(valueBSave530, sBQz530);
};
function squareBToSzzZValue530(){
    valueBSave530 = 'zSqrArtSpecz530';
    var tripleBZeroA = localStorage.getItem(valueBSave530);
    document.getElementById("imgSqr531").src = tripleBZeroA;};

function artsquare531(){
    var sBQz531 = document.getElementById("aImgSqr532").src;
    valueBSave531 = 'zSqrArtSpecz531';
    localStorage.setItem(valueBSave531, sBQz531);
};
function squareBToSzzZValue531(){
    valueBSave531 = 'zSqrArtSpecz531';
    var tripleBZeroA = localStorage.getItem(valueBSave531);
    document.getElementById("imgSqr532").src = tripleBZeroA;};

function artsquare532(){
    var sBQz532 = document.getElementById("aImgSqr533").src;
    valueBSave532 = 'zSqrArtSpecz532';
    localStorage.setItem(valueBSave532, sBQz532);
};
function squareBToSzzZValue532(){
    valueBSave532 = 'zSqrArtSpecz532';
    var tripleBZeroA = localStorage.getItem(valueBSave532);
    document.getElementById("imgSqr533").src = tripleBZeroA;};

function artsquare533(){
    var sBQz533 = document.getElementById("aImgSqr534").src;
    valueBSave533 = 'zSqrArtSpecz533';
    localStorage.setItem(valueBSave533, sBQz533);
};
function squareBToSzzZValue533(){
    valueBSave533 = 'zSqrArtSpecz533';
    var tripleBZeroA = localStorage.getItem(valueBSave533);
    document.getElementById("imgSqr534").src = tripleBZeroA;};

function artsquare534(){
    var sBQz534 = document.getElementById("aImgSqr535").src;
    valueBSave534 = 'zSqrArtSpecz534';
    localStorage.setItem(valueBSave534, sBQz534);
};
function squareBToSzzZValue534(){
    valueBSave534 = 'zSqrArtSpecz534';
    var tripleBZeroA = localStorage.getItem(valueBSave534);
    document.getElementById("imgSqr535").src = tripleBZeroA;};

function artsquare535(){
    var sBQz535 = document.getElementById("aImgSqr536").src;
    valueBSave535 = 'zSqrArtSpecz535';
    localStorage.setItem(valueBSave535, sBQz535);
};
function squareBToSzzZValue535(){
    valueBSave535 = 'zSqrArtSpecz535';
    var tripleBZeroA = localStorage.getItem(valueBSave535);
    document.getElementById("imgSqr536").src = tripleBZeroA;};

function artsquare536(){
    var sBQz536 = document.getElementById("aImgSqr537").src;
    valueBSave536 = 'zSqrArtSpecz536';
    localStorage.setItem(valueBSave536, sBQz536);
};
function squareBToSzzZValue536(){
    valueBSave536 = 'zSqrArtSpecz536';
    var tripleBZeroA = localStorage.getItem(valueBSave536);
    document.getElementById("imgSqr537").src = tripleBZeroA;};

function artsquare537(){
    var sBQz537 = document.getElementById("aImgSqr538").src;
    valueBSave537 = 'zSqrArtSpecz537';
    localStorage.setItem(valueBSave537, sBQz537);
};
function squareBToSzzZValue537(){
    valueBSave537 = 'zSqrArtSpecz537';
    var tripleBZeroA = localStorage.getItem(valueBSave537);
    document.getElementById("imgSqr538").src = tripleBZeroA;};

function artsquare538(){
    var sBQz538 = document.getElementById("aImgSqr539").src;
    valueBSave538 = 'zSqrArtSpecz538';
    localStorage.setItem(valueBSave538, sBQz538);
};
function squareBToSzzZValue538(){
    valueBSave538 = 'zSqrArtSpecz538';
    var tripleBZeroA = localStorage.getItem(valueBSave538);
    document.getElementById("imgSqr539").src = tripleBZeroA;};

function artsquare539(){
    var sBQz539 = document.getElementById("aImgSqr540").src;
    valueBSave539 = 'zSqrArtSpecz539';
    localStorage.setItem(valueBSave539, sBQz539);
};
function squareBToSzzZValue539(){
    valueBSave539 = 'zSqrArtSpecz539';
    var tripleBZeroA = localStorage.getItem(valueBSave539);
    document.getElementById("imgSqr540").src = tripleBZeroA;};

function artsquare540(){
    var sBQz540 = document.getElementById("aImgSqr541").src;
    valueBSave540 = 'zSqrArtSpecz540';
    localStorage.setItem(valueBSave540, sBQz540);
};
function squareBToSzzZValue540(){
    valueBSave540 = 'zSqrArtSpecz540';
    var tripleBZeroA = localStorage.getItem(valueBSave540);
    document.getElementById("imgSqr541").src = tripleBZeroA;};

function artsquare541(){
    var sBQz541 = document.getElementById("aImgSqr542").src;
    valueBSave541 = 'zSqrArtSpecz541';
    localStorage.setItem(valueBSave541, sBQz541);
};
function squareBToSzzZValue541(){
    valueBSave541 = 'zSqrArtSpecz541';
    var tripleBZeroA = localStorage.getItem(valueBSave541);
    document.getElementById("imgSqr542").src = tripleBZeroA;};

function artsquare542(){
    var sBQz542 = document.getElementById("aImgSqr543").src;
    valueBSave542 = 'zSqrArtSpecz542';
    localStorage.setItem(valueBSave542, sBQz542);
};
function squareBToSzzZValue542(){
    valueBSave542 = 'zSqrArtSpecz542';
    var tripleBZeroA = localStorage.getItem(valueBSave542);
    document.getElementById("imgSqr543").src = tripleBZeroA;};

function artsquare543(){
    var sBQz543 = document.getElementById("aImgSqr544").src;
    valueBSave543 = 'zSqrArtSpecz543';
    localStorage.setItem(valueBSave543, sBQz543);
};
function squareBToSzzZValue543(){
    valueBSave543 = 'zSqrArtSpecz543';
    var tripleBZeroA = localStorage.getItem(valueBSave543);
    document.getElementById("imgSqr544").src = tripleBZeroA;};

function artsquare544(){
    var sBQz544 = document.getElementById("aImgSqr545").src;
    valueBSave544 = 'zSqrArtSpecz544';
    localStorage.setItem(valueBSave544, sBQz544);
};
function squareBToSzzZValue544(){
    valueBSave544 = 'zSqrArtSpecz544';
    var tripleBZeroA = localStorage.getItem(valueBSave544);
    document.getElementById("imgSqr545").src = tripleBZeroA;};

function artsquare545(){
    var sBQz545 = document.getElementById("aImgSqr546").src;
    valueBSave545 = 'zSqrArtSpecz545';
    localStorage.setItem(valueBSave545, sBQz545);
};
function squareBToSzzZValue545(){
    valueBSave545 = 'zSqrArtSpecz545';
    var tripleBZeroA = localStorage.getItem(valueBSave545);
    document.getElementById("imgSqr546").src = tripleBZeroA;};

function artsquare546(){
    var sBQz546 = document.getElementById("aImgSqr547").src;
    valueBSave546 = 'zSqrArtSpecz546';
    localStorage.setItem(valueBSave546, sBQz546);
};
function squareBToSzzZValue546(){
    valueBSave546 = 'zSqrArtSpecz546';
    var tripleBZeroA = localStorage.getItem(valueBSave546);
    document.getElementById("imgSqr547").src = tripleBZeroA;};

function artsquare547(){
    var sBQz547 = document.getElementById("aImgSqr548").src;
    valueBSave547 = 'zSqrArtSpecz547';
    localStorage.setItem(valueBSave547, sBQz547);
};
function squareBToSzzZValue547(){
    valueBSave547 = 'zSqrArtSpecz547';
    var tripleBZeroA = localStorage.getItem(valueBSave547);
    document.getElementById("imgSqr548").src = tripleBZeroA;};

function artsquare548(){
    var sBQz548 = document.getElementById("aImgSqr549").src;
    valueBSave548 = 'zSqrArtSpecz548';
    localStorage.setItem(valueBSave548, sBQz548);
};
function squareBToSzzZValue548(){
    valueBSave548 = 'zSqrArtSpecz548';
    var tripleBZeroA = localStorage.getItem(valueBSave548);
    document.getElementById("imgSqr549").src = tripleBZeroA;};

function artsquare549(){
    var sBQz549 = document.getElementById("aImgSqr550").src;
    valueBSave549 = 'zSqrArtSpecz549';
    localStorage.setItem(valueBSave549, sBQz549);
};
function squareBToSzzZValue549(){
    valueBSave549 = 'zSqrArtSpecz549';
    var tripleBZeroA = localStorage.getItem(valueBSave549);
    document.getElementById("imgSqr550").src = tripleBZeroA;};

function artsquare550(){
    var sBQz550 = document.getElementById("aImgSqr551").src;
    valueBSave550 = 'zSqrArtSpecz550';
    localStorage.setItem(valueBSave550, sBQz550);
};
function squareBToSzzZValue550(){
    valueBSave550 = 'zSqrArtSpecz550';
    var tripleBZeroA = localStorage.getItem(valueBSave550);
    document.getElementById("imgSqr551").src = tripleBZeroA;};

function artsquare551(){
    var sBQz551 = document.getElementById("aImgSqr552").src;
    valueBSave551 = 'zSqrArtSpecz551';
    localStorage.setItem(valueBSave551, sBQz551);
};
function squareBToSzzZValue551(){
    valueBSave551 = 'zSqrArtSpecz551';
    var tripleBZeroA = localStorage.getItem(valueBSave551);
    document.getElementById("imgSqr552").src = tripleBZeroA;};

function artsquare552(){
    var sBQz552 = document.getElementById("aImgSqr553").src;
    valueBSave552 = 'zSqrArtSpecz552';
    localStorage.setItem(valueBSave552, sBQz552);
};
function squareBToSzzZValue552(){
    valueBSave552 = 'zSqrArtSpecz552';
    var tripleBZeroA = localStorage.getItem(valueBSave552);
    document.getElementById("imgSqr553").src = tripleBZeroA;};

function artsquare553(){
    var sBQz553 = document.getElementById("aImgSqr554").src;
    valueBSave553 = 'zSqrArtSpecz553';
    localStorage.setItem(valueBSave553, sBQz553);
};
function squareBToSzzZValue553(){
    valueBSave553 = 'zSqrArtSpecz553';
    var tripleBZeroA = localStorage.getItem(valueBSave553);
    document.getElementById("imgSqr554").src = tripleBZeroA;};

function artsquare554(){
    var sBQz554 = document.getElementById("aImgSqr555").src;
    valueBSave554 = 'zSqrArtSpecz554';
    localStorage.setItem(valueBSave554, sBQz554);
};
function squareBToSzzZValue554(){
    valueBSave554 = 'zSqrArtSpecz554';
    var tripleBZeroA = localStorage.getItem(valueBSave554);
    document.getElementById("imgSqr555").src = tripleBZeroA;};

function artsquare555(){
    var sBQz555 = document.getElementById("aImgSqr556").src;
    valueBSave555 = 'zSqrArtSpecz555';
    localStorage.setItem(valueBSave555, sBQz555);
};
function squareBToSzzZValue555(){
    valueBSave555 = 'zSqrArtSpecz555';
    var tripleBZeroA = localStorage.getItem(valueBSave555);
    document.getElementById("imgSqr556").src = tripleBZeroA;};

function artsquare556(){
    var sBQz556 = document.getElementById("aImgSqr557").src;
    valueBSave556 = 'zSqrArtSpecz556';
    localStorage.setItem(valueBSave556, sBQz556);
};
function squareBToSzzZValue556(){
    valueBSave556 = 'zSqrArtSpecz556';
    var tripleBZeroA = localStorage.getItem(valueBSave556);
    document.getElementById("imgSqr557").src = tripleBZeroA;};

function artsquare557(){
    var sBQz557 = document.getElementById("aImgSqr558").src;
    valueBSave557 = 'zSqrArtSpecz557';
    localStorage.setItem(valueBSave557, sBQz557);
};
function squareBToSzzZValue557(){
    valueBSave557 = 'zSqrArtSpecz557';
    var tripleBZeroA = localStorage.getItem(valueBSave557);
    document.getElementById("imgSqr558").src = tripleBZeroA;};

function artsquare558(){
    var sBQz558 = document.getElementById("aImgSqr559").src;
    valueBSave558 = 'zSqrArtSpecz558';
    localStorage.setItem(valueBSave558, sBQz558);
};
function squareBToSzzZValue558(){
    valueBSave558 = 'zSqrArtSpecz558';
    var tripleBZeroA = localStorage.getItem(valueBSave558);
    document.getElementById("imgSqr559").src = tripleBZeroA;};

function artsquare559(){
    var sBQz559 = document.getElementById("aImgSqr560").src;
    valueBSave559 = 'zSqrArtSpecz559';
    localStorage.setItem(valueBSave559, sBQz559);
};
function squareBToSzzZValue559(){
    valueBSave559 = 'zSqrArtSpecz559';
    var tripleBZeroA = localStorage.getItem(valueBSave559);
    document.getElementById("imgSqr560").src = tripleBZeroA;};

function artsquare560(){
    var sBQz560 = document.getElementById("aImgSqr561").src;
    valueBSave560 = 'zSqrArtSpecz560';
    localStorage.setItem(valueBSave560, sBQz560);
};
function squareBToSzzZValue560(){
    valueBSave560 = 'zSqrArtSpecz560';
    var tripleBZeroA = localStorage.getItem(valueBSave560);
    document.getElementById("imgSqr561").src = tripleBZeroA;};

function artsquare561(){
    var sBQz561 = document.getElementById("aImgSqr562").src;
    valueBSave561 = 'zSqrArtSpecz561';
    localStorage.setItem(valueBSave561, sBQz561);
};
function squareBToSzzZValue561(){
    valueBSave561 = 'zSqrArtSpecz561';
    var tripleBZeroA = localStorage.getItem(valueBSave561);
    document.getElementById("imgSqr562").src = tripleBZeroA;};

function artsquare562(){
    var sBQz562 = document.getElementById("aImgSqr563").src;
    valueBSave562 = 'zSqrArtSpecz562';
    localStorage.setItem(valueBSave562, sBQz562);
};
function squareBToSzzZValue562(){
    valueBSave562 = 'zSqrArtSpecz562';
    var tripleBZeroA = localStorage.getItem(valueBSave562);
    document.getElementById("imgSqr563").src = tripleBZeroA;};

function artsquare563(){
    var sBQz563 = document.getElementById("aImgSqr564").src;
    valueBSave563 = 'zSqrArtSpecz563';
    localStorage.setItem(valueBSave563, sBQz563);
};
function squareBToSzzZValue563(){
    valueBSave563 = 'zSqrArtSpecz563';
    var tripleBZeroA = localStorage.getItem(valueBSave563);
    document.getElementById("imgSqr564").src = tripleBZeroA;};

function artsquare564(){
    var sBQz564 = document.getElementById("aImgSqr565").src;
    valueBSave564 = 'zSqrArtSpecz564';
    localStorage.setItem(valueBSave564, sBQz564);
};
function squareBToSzzZValue564(){
    valueBSave564 = 'zSqrArtSpecz564';
    var tripleBZeroA = localStorage.getItem(valueBSave564);
    document.getElementById("imgSqr565").src = tripleBZeroA;};

function artsquare565(){
    var sBQz565 = document.getElementById("aImgSqr566").src;
    valueBSave565 = 'zSqrArtSpecz565';
    localStorage.setItem(valueBSave565, sBQz565);
};
function squareBToSzzZValue565(){
    valueBSave565 = 'zSqrArtSpecz565';
    var tripleBZeroA = localStorage.getItem(valueBSave565);
    document.getElementById("imgSqr566").src = tripleBZeroA;};

function artsquare566(){
    var sBQz566 = document.getElementById("aImgSqr567").src;
    valueBSave566 = 'zSqrArtSpecz566';
    localStorage.setItem(valueBSave566, sBQz566);
};
function squareBToSzzZValue566(){
    valueBSave566 = 'zSqrArtSpecz566';
    var tripleBZeroA = localStorage.getItem(valueBSave566);
    document.getElementById("imgSqr567").src = tripleBZeroA;};

function artsquare567(){
    var sBQz567 = document.getElementById("aImgSqr568").src;
    valueBSave567 = 'zSqrArtSpecz567';
    localStorage.setItem(valueBSave567, sBQz567);
};
function squareBToSzzZValue567(){
    valueBSave567 = 'zSqrArtSpecz567';
    var tripleBZeroA = localStorage.getItem(valueBSave567);
    document.getElementById("imgSqr568").src = tripleBZeroA;};

function artsquare568(){
    var sBQz568 = document.getElementById("aImgSqr569").src;
    valueBSave568 = 'zSqrArtSpecz568';
    localStorage.setItem(valueBSave568, sBQz568);
};
function squareBToSzzZValue568(){
    valueBSave568 = 'zSqrArtSpecz568';
    var tripleBZeroA = localStorage.getItem(valueBSave568);
    document.getElementById("imgSqr569").src = tripleBZeroA;};

function artsquare569(){
    var sBQz569 = document.getElementById("aImgSqr570").src;
    valueBSave569 = 'zSqrArtSpecz569';
    localStorage.setItem(valueBSave569, sBQz569);
};
function squareBToSzzZValue569(){
    valueBSave569 = 'zSqrArtSpecz569';
    var tripleBZeroA = localStorage.getItem(valueBSave569);
    document.getElementById("imgSqr570").src = tripleBZeroA;};

function artsquare570(){
    var sBQz570 = document.getElementById("aImgSqr571").src;
    valueBSave570 = 'zSqrArtSpecz570';
    localStorage.setItem(valueBSave570, sBQz570);
};
function squareBToSzzZValue570(){
    valueBSave570 = 'zSqrArtSpecz570';
    var tripleBZeroA = localStorage.getItem(valueBSave570);
    document.getElementById("imgSqr571").src = tripleBZeroA;};

function artsquare571(){
    var sBQz571 = document.getElementById("aImgSqr572").src;
    valueBSave571 = 'zSqrArtSpecz571';
    localStorage.setItem(valueBSave571, sBQz571);
};
function squareBToSzzZValue571(){
    valueBSave571 = 'zSqrArtSpecz571';
    var tripleBZeroA = localStorage.getItem(valueBSave571);
    document.getElementById("imgSqr572").src = tripleBZeroA;};

function artsquare572(){
    var sBQz572 = document.getElementById("aImgSqr573").src;
    valueBSave572 = 'zSqrArtSpecz572';
    localStorage.setItem(valueBSave572, sBQz572);
};
function squareBToSzzZValue572(){
    valueBSave572 = 'zSqrArtSpecz572';
    var tripleBZeroA = localStorage.getItem(valueBSave572);
    document.getElementById("imgSqr573").src = tripleBZeroA;};

function artsquare573(){
    var sBQz573 = document.getElementById("aImgSqr574").src;
    valueBSave573 = 'zSqrArtSpecz573';
    localStorage.setItem(valueBSave573, sBQz573);
};
function squareBToSzzZValue573(){
    valueBSave573 = 'zSqrArtSpecz573';
    var tripleBZeroA = localStorage.getItem(valueBSave573);
    document.getElementById("imgSqr574").src = tripleBZeroA;};

function artsquare574(){
    var sBQz574 = document.getElementById("aImgSqr575").src;
    valueBSave574 = 'zSqrArtSpecz574';
    localStorage.setItem(valueBSave574, sBQz574);
};
function squareBToSzzZValue574(){
    valueBSave574 = 'zSqrArtSpecz574';
    var tripleBZeroA = localStorage.getItem(valueBSave574);
    document.getElementById("imgSqr575").src = tripleBZeroA;};

function artsquare575(){
    var sBQz575 = document.getElementById("aImgSqr576").src;
    valueBSave575 = 'zSqrArtSpecz575';
    localStorage.setItem(valueBSave575, sBQz575);
};
function squareBToSzzZValue575(){
    valueBSave575 = 'zSqrArtSpecz575';
    var tripleBZeroA = localStorage.getItem(valueBSave575);
    document.getElementById("imgSqr576").src = tripleBZeroA;};

function artsquare576(){
    var sBQz576 = document.getElementById("aImgSqr577").src;
    valueBSave576 = 'zSqrArtSpecz576';
    localStorage.setItem(valueBSave576, sBQz576);
};
function squareBToSzzZValue576(){
    valueBSave576 = 'zSqrArtSpecz576';
    var tripleBZeroA = localStorage.getItem(valueBSave576);
    document.getElementById("imgSqr577").src = tripleBZeroA;};

function artsquare577(){
    var sBQz577 = document.getElementById("aImgSqr578").src;
    valueBSave577 = 'zSqrArtSpecz577';
    localStorage.setItem(valueBSave577, sBQz577);
};
function squareBToSzzZValue577(){
    valueBSave577 = 'zSqrArtSpecz577';
    var tripleBZeroA = localStorage.getItem(valueBSave577);
    document.getElementById("imgSqr578").src = tripleBZeroA;};

function artsquare578(){
    var sBQz578 = document.getElementById("aImgSqr579").src;
    valueBSave578 = 'zSqrArtSpecz578';
    localStorage.setItem(valueBSave578, sBQz578);
};
function squareBToSzzZValue578(){
    valueBSave578 = 'zSqrArtSpecz578';
    var tripleBZeroA = localStorage.getItem(valueBSave578);
    document.getElementById("imgSqr579").src = tripleBZeroA;};

function artsquare579(){
    var sBQz579 = document.getElementById("aImgSqr580").src;
    valueBSave579 = 'zSqrArtSpecz579';
    localStorage.setItem(valueBSave579, sBQz579);
};
function squareBToSzzZValue579(){
    valueBSave579 = 'zSqrArtSpecz579';
    var tripleBZeroA = localStorage.getItem(valueBSave579);
    document.getElementById("imgSqr580").src = tripleBZeroA;};

function artsquare580(){
    var sBQz580 = document.getElementById("aImgSqr581").src;
    valueBSave580 = 'zSqrArtSpecz580';
    localStorage.setItem(valueBSave580, sBQz580);
};
function squareBToSzzZValue580(){
    valueBSave580 = 'zSqrArtSpecz580';
    var tripleBZeroA = localStorage.getItem(valueBSave580);
    document.getElementById("imgSqr581").src = tripleBZeroA;};

function artsquare581(){
    var sBQz581 = document.getElementById("aImgSqr582").src;
    valueBSave581 = 'zSqrArtSpecz581';
    localStorage.setItem(valueBSave581, sBQz581);
};
function squareBToSzzZValue581(){
    valueBSave581 = 'zSqrArtSpecz581';
    var tripleBZeroA = localStorage.getItem(valueBSave581);
    document.getElementById("imgSqr582").src = tripleBZeroA;};

function artsquare582(){
    var sBQz582 = document.getElementById("aImgSqr583").src;
    valueBSave582 = 'zSqrArtSpecz582';
    localStorage.setItem(valueBSave582, sBQz582);
};
function squareBToSzzZValue582(){
    valueBSave582 = 'zSqrArtSpecz582';
    var tripleBZeroA = localStorage.getItem(valueBSave582);
    document.getElementById("imgSqr583").src = tripleBZeroA;};

function artsquare583(){
    var sBQz583 = document.getElementById("aImgSqr584").src;
    valueBSave583 = 'zSqrArtSpecz583';
    localStorage.setItem(valueBSave583, sBQz583);
};
function squareBToSzzZValue583(){
    valueBSave583 = 'zSqrArtSpecz583';
    var tripleBZeroA = localStorage.getItem(valueBSave583);
    document.getElementById("imgSqr584").src = tripleBZeroA;};

function artsquare584(){
    var sBQz584 = document.getElementById("aImgSqr585").src;
    valueBSave584 = 'zSqrArtSpecz584';
    localStorage.setItem(valueBSave584, sBQz584);
};
function squareBToSzzZValue584(){
    valueBSave584 = 'zSqrArtSpecz584';
    var tripleBZeroA = localStorage.getItem(valueBSave584);
    document.getElementById("imgSqr585").src = tripleBZeroA;};

function artsquare585(){
    var sBQz585 = document.getElementById("aImgSqr586").src;
    valueBSave585 = 'zSqrArtSpecz585';
    localStorage.setItem(valueBSave585, sBQz585);
};
function squareBToSzzZValue585(){
    valueBSave585 = 'zSqrArtSpecz585';
    var tripleBZeroA = localStorage.getItem(valueBSave585);
    document.getElementById("imgSqr586").src = tripleBZeroA;};

function artsquare586(){
    var sBQz586 = document.getElementById("aImgSqr587").src;
    valueBSave586 = 'zSqrArtSpecz586';
    localStorage.setItem(valueBSave586, sBQz586);
};
function squareBToSzzZValue586(){
    valueBSave586 = 'zSqrArtSpecz586';
    var tripleBZeroA = localStorage.getItem(valueBSave586);
    document.getElementById("imgSqr587").src = tripleBZeroA;};

function artsquare587(){
    var sBQz587 = document.getElementById("aImgSqr588").src;
    valueBSave587 = 'zSqrArtSpecz587';
    localStorage.setItem(valueBSave587, sBQz587);
};
function squareBToSzzZValue587(){
    valueBSave587 = 'zSqrArtSpecz587';
    var tripleBZeroA = localStorage.getItem(valueBSave587);
    document.getElementById("imgSqr588").src = tripleBZeroA;};

function artsquare588(){
    var sBQz588 = document.getElementById("aImgSqr589").src;
    valueBSave588 = 'zSqrArtSpecz588';
    localStorage.setItem(valueBSave588, sBQz588);
};
function squareBToSzzZValue588(){
    valueBSave588 = 'zSqrArtSpecz588';
    var tripleBZeroA = localStorage.getItem(valueBSave588);
    document.getElementById("imgSqr589").src = tripleBZeroA;};

function artsquare589(){
    var sBQz589 = document.getElementById("aImgSqr590").src;
    valueBSave589 = 'zSqrArtSpecz589';
    localStorage.setItem(valueBSave589, sBQz589);
};
function squareBToSzzZValue589(){
    valueBSave589 = 'zSqrArtSpecz589';
    var tripleBZeroA = localStorage.getItem(valueBSave589);
    document.getElementById("imgSqr590").src = tripleBZeroA;};

function artsquare590(){
    var sBQz590 = document.getElementById("aImgSqr591").src;
    valueBSave590 = 'zSqrArtSpecz590';
    localStorage.setItem(valueBSave590, sBQz590);
};
function squareBToSzzZValue590(){
    valueBSave590 = 'zSqrArtSpecz590';
    var tripleBZeroA = localStorage.getItem(valueBSave590);
    document.getElementById("imgSqr591").src = tripleBZeroA;};

function artsquare591(){
    var sBQz591 = document.getElementById("aImgSqr592").src;
    valueBSave591 = 'zSqrArtSpecz591';
    localStorage.setItem(valueBSave591, sBQz591);
};
function squareBToSzzZValue591(){
    valueBSave591 = 'zSqrArtSpecz591';
    var tripleBZeroA = localStorage.getItem(valueBSave591);
    document.getElementById("imgSqr592").src = tripleBZeroA;};

function artsquare592(){
    var sBQz592 = document.getElementById("aImgSqr593").src;
    valueBSave592 = 'zSqrArtSpecz592';
    localStorage.setItem(valueBSave592, sBQz592);
};
function squareBToSzzZValue592(){
    valueBSave592 = 'zSqrArtSpecz592';
    var tripleBZeroA = localStorage.getItem(valueBSave592);
    document.getElementById("imgSqr593").src = tripleBZeroA;};

function artsquare593(){
    var sBQz593 = document.getElementById("aImgSqr594").src;
    valueBSave593 = 'zSqrArtSpecz593';
    localStorage.setItem(valueBSave593, sBQz593);
};
function squareBToSzzZValue593(){
    valueBSave593 = 'zSqrArtSpecz593';
    var tripleBZeroA = localStorage.getItem(valueBSave593);
    document.getElementById("imgSqr594").src = tripleBZeroA;};

function artsquare594(){
    var sBQz594 = document.getElementById("aImgSqr595").src;
    valueBSave594 = 'zSqrArtSpecz594';
    localStorage.setItem(valueBSave594, sBQz594);
};
function squareBToSzzZValue594(){
    valueBSave594 = 'zSqrArtSpecz594';
    var tripleBZeroA = localStorage.getItem(valueBSave594);
    document.getElementById("imgSqr595").src = tripleBZeroA;};

function artsquare595(){
    var sBQz595 = document.getElementById("aImgSqr596").src;
    valueBSave595 = 'zSqrArtSpecz595';
    localStorage.setItem(valueBSave595, sBQz595);
};
function squareBToSzzZValue595(){
    valueBSave595 = 'zSqrArtSpecz595';
    var tripleBZeroA = localStorage.getItem(valueBSave595);
    document.getElementById("imgSqr596").src = tripleBZeroA;};

function artsquare596(){
    var sBQz596 = document.getElementById("aImgSqr597").src;
    valueBSave596 = 'zSqrArtSpecz596';
    localStorage.setItem(valueBSave596, sBQz596);
};
function squareBToSzzZValue596(){
    valueBSave596 = 'zSqrArtSpecz596';
    var tripleBZeroA = localStorage.getItem(valueBSave596);
    document.getElementById("imgSqr597").src = tripleBZeroA;};

function artsquare597(){
    var sBQz597 = document.getElementById("aImgSqr598").src;
    valueBSave597 = 'zSqrArtSpecz597';
    localStorage.setItem(valueBSave597, sBQz597);
};
function squareBToSzzZValue597(){
    valueBSave597 = 'zSqrArtSpecz597';
    var tripleBZeroA = localStorage.getItem(valueBSave597);
    document.getElementById("imgSqr598").src = tripleBZeroA;};

function artsquare598(){
    var sBQz598 = document.getElementById("aImgSqr599").src;
    valueBSave598 = 'zSqrArtSpecz598';
    localStorage.setItem(valueBSave598, sBQz598);
};
function squareBToSzzZValue598(){
    valueBSave598 = 'zSqrArtSpecz598';
    var tripleBZeroA = localStorage.getItem(valueBSave598);
    document.getElementById("imgSqr599").src = tripleBZeroA;};

function artsquare599(){
    var sBQz599 = document.getElementById("aImgSqr600").src;
    valueBSave599 = 'zSqrArtSpecz599';
    localStorage.setItem(valueBSave599, sBQz599);
};
function squareBToSzzZValue599(){
    valueBSave599 = 'zSqrArtSpecz599';
    var tripleBZeroA = localStorage.getItem(valueBSave599);
    document.getElementById("imgSqr600").src = tripleBZeroA;};

function artsquare600(){
    var sBQz600 = document.getElementById("aImgSqr601").src;
    valueBSave600 = 'zSqrArtSpecz600';
    localStorage.setItem(valueBSave600, sBQz600);
};
function squareBToSzzZValue600(){
    valueBSave600 = 'zSqrArtSpecz600';
    var tripleBZeroA = localStorage.getItem(valueBSave600);
    document.getElementById("imgSqr601").src = tripleBZeroA;};

function artsquare601(){
    var sBQz601 = document.getElementById("aImgSqr602").src;
    valueBSave601 = 'zSqrArtSpecz601';
    localStorage.setItem(valueBSave601, sBQz601);
};
function squareBToSzzZValue601(){
    valueBSave601 = 'zSqrArtSpecz601';
    var tripleBZeroA = localStorage.getItem(valueBSave601);
    document.getElementById("imgSqr602").src = tripleBZeroA;};

function artsquare602(){
    var sBQz602 = document.getElementById("aImgSqr603").src;
    valueBSave602 = 'zSqrArtSpecz602';
    localStorage.setItem(valueBSave602, sBQz602);
};
function squareBToSzzZValue602(){
    valueBSave602 = 'zSqrArtSpecz602';
    var tripleBZeroA = localStorage.getItem(valueBSave602);
    document.getElementById("imgSqr603").src = tripleBZeroA;};

function artsquare603(){
    var sBQz603 = document.getElementById("aImgSqr604").src;
    valueBSave603 = 'zSqrArtSpecz603';
    localStorage.setItem(valueBSave603, sBQz603);
};
function squareBToSzzZValue603(){
    valueBSave603 = 'zSqrArtSpecz603';
    var tripleBZeroA = localStorage.getItem(valueBSave603);
    document.getElementById("imgSqr604").src = tripleBZeroA;};

function artsquare604(){
    var sBQz604 = document.getElementById("aImgSqr605").src;
    valueBSave604 = 'zSqrArtSpecz604';
    localStorage.setItem(valueBSave604, sBQz604);
};
function squareBToSzzZValue604(){
    valueBSave604 = 'zSqrArtSpecz604';
    var tripleBZeroA = localStorage.getItem(valueBSave604);
    document.getElementById("imgSqr605").src = tripleBZeroA;};

function artsquare605(){
    var sBQz605 = document.getElementById("aImgSqr606").src;
    valueBSave605 = 'zSqrArtSpecz605';
    localStorage.setItem(valueBSave605, sBQz605);
};
function squareBToSzzZValue605(){
    valueBSave605 = 'zSqrArtSpecz605';
    var tripleBZeroA = localStorage.getItem(valueBSave605);
    document.getElementById("imgSqr606").src = tripleBZeroA;};

function artsquare606(){
    var sBQz606 = document.getElementById("aImgSqr607").src;
    valueBSave606 = 'zSqrArtSpecz606';
    localStorage.setItem(valueBSave606, sBQz606);
};
function squareBToSzzZValue606(){
    valueBSave606 = 'zSqrArtSpecz606';
    var tripleBZeroA = localStorage.getItem(valueBSave606);
    document.getElementById("imgSqr607").src = tripleBZeroA;};

function artsquare607(){
    var sBQz607 = document.getElementById("aImgSqr608").src;
    valueBSave607 = 'zSqrArtSpecz607';
    localStorage.setItem(valueBSave607, sBQz607);
};
function squareBToSzzZValue607(){
    valueBSave607 = 'zSqrArtSpecz607';
    var tripleBZeroA = localStorage.getItem(valueBSave607);
    document.getElementById("imgSqr608").src = tripleBZeroA;};

function artsquare608(){
    var sBQz608 = document.getElementById("aImgSqr609").src;
    valueBSave608 = 'zSqrArtSpecz608';
    localStorage.setItem(valueBSave608, sBQz608);
};
function squareBToSzzZValue608(){
    valueBSave608 = 'zSqrArtSpecz608';
    var tripleBZeroA = localStorage.getItem(valueBSave608);
    document.getElementById("imgSqr609").src = tripleBZeroA;};

function artsquare609(){
    var sBQz609 = document.getElementById("aImgSqr610").src;
    valueBSave609 = 'zSqrArtSpecz609';
    localStorage.setItem(valueBSave609, sBQz609);
};
function squareBToSzzZValue609(){
    valueBSave609 = 'zSqrArtSpecz609';
    var tripleBZeroA = localStorage.getItem(valueBSave609);
    document.getElementById("imgSqr610").src = tripleBZeroA;};

function artsquare610(){
    var sBQz610 = document.getElementById("aImgSqr611").src;
    valueBSave610 = 'zSqrArtSpecz610';
    localStorage.setItem(valueBSave610, sBQz610);
};
function squareBToSzzZValue610(){
    valueBSave610 = 'zSqrArtSpecz610';
    var tripleBZeroA = localStorage.getItem(valueBSave610);
    document.getElementById("imgSqr611").src = tripleBZeroA;};

function artsquare611(){
    var sBQz611 = document.getElementById("aImgSqr612").src;
    valueBSave611 = 'zSqrArtSpecz611';
    localStorage.setItem(valueBSave611, sBQz611);
};
function squareBToSzzZValue611(){
    valueBSave611 = 'zSqrArtSpecz611';
    var tripleBZeroA = localStorage.getItem(valueBSave611);
    document.getElementById("imgSqr612").src = tripleBZeroA;};

function artsquare612(){
    var sBQz612 = document.getElementById("aImgSqr613").src;
    valueBSave612 = 'zSqrArtSpecz612';
    localStorage.setItem(valueBSave612, sBQz612);
};
function squareBToSzzZValue612(){
    valueBSave612 = 'zSqrArtSpecz612';
    var tripleBZeroA = localStorage.getItem(valueBSave612);
    document.getElementById("imgSqr613").src = tripleBZeroA;};

function artsquare613(){
    var sBQz613 = document.getElementById("aImgSqr614").src;
    valueBSave613 = 'zSqrArtSpecz613';
    localStorage.setItem(valueBSave613, sBQz613);
};
function squareBToSzzZValue613(){
    valueBSave613 = 'zSqrArtSpecz613';
    var tripleBZeroA = localStorage.getItem(valueBSave613);
    document.getElementById("imgSqr614").src = tripleBZeroA;};

function artsquare614(){
    var sBQz614 = document.getElementById("aImgSqr615").src;
    valueBSave614 = 'zSqrArtSpecz614';
    localStorage.setItem(valueBSave614, sBQz614);
};
function squareBToSzzZValue614(){
    valueBSave614 = 'zSqrArtSpecz614';
    var tripleBZeroA = localStorage.getItem(valueBSave614);
    document.getElementById("imgSqr615").src = tripleBZeroA;};

function artsquare615(){
    var sBQz615 = document.getElementById("aImgSqr616").src;
    valueBSave615 = 'zSqrArtSpecz615';
    localStorage.setItem(valueBSave615, sBQz615);
};
function squareBToSzzZValue615(){
    valueBSave615 = 'zSqrArtSpecz615';
    var tripleBZeroA = localStorage.getItem(valueBSave615);
    document.getElementById("imgSqr616").src = tripleBZeroA;};

function artsquare616(){
    var sBQz616 = document.getElementById("aImgSqr617").src;
    valueBSave616 = 'zSqrArtSpecz616';
    localStorage.setItem(valueBSave616, sBQz616);
};
function squareBToSzzZValue616(){
    valueBSave616 = 'zSqrArtSpecz616';
    var tripleBZeroA = localStorage.getItem(valueBSave616);
    document.getElementById("imgSqr617").src = tripleBZeroA;};

function artsquare617(){
    var sBQz617 = document.getElementById("aImgSqr618").src;
    valueBSave617 = 'zSqrArtSpecz617';
    localStorage.setItem(valueBSave617, sBQz617);
};
function squareBToSzzZValue617(){
    valueBSave617 = 'zSqrArtSpecz617';
    var tripleBZeroA = localStorage.getItem(valueBSave617);
    document.getElementById("imgSqr618").src = tripleBZeroA;};

function artsquare618(){
    var sBQz618 = document.getElementById("aImgSqr619").src;
    valueBSave618 = 'zSqrArtSpecz618';
    localStorage.setItem(valueBSave618, sBQz618);
};
function squareBToSzzZValue618(){
    valueBSave618 = 'zSqrArtSpecz618';
    var tripleBZeroA = localStorage.getItem(valueBSave618);
    document.getElementById("imgSqr619").src = tripleBZeroA;};

function artsquare619(){
    var sBQz619 = document.getElementById("aImgSqr620").src;
    valueBSave619 = 'zSqrArtSpecz619';
    localStorage.setItem(valueBSave619, sBQz619);
};
function squareBToSzzZValue619(){
    valueBSave619 = 'zSqrArtSpecz619';
    var tripleBZeroA = localStorage.getItem(valueBSave619);
    document.getElementById("imgSqr620").src = tripleBZeroA;};

function artsquare620(){
    var sBQz620 = document.getElementById("aImgSqr621").src;
    valueBSave620 = 'zSqrArtSpecz620';
    localStorage.setItem(valueBSave620, sBQz620);
};
function squareBToSzzZValue620(){
    valueBSave620 = 'zSqrArtSpecz620';
    var tripleBZeroA = localStorage.getItem(valueBSave620);
    document.getElementById("imgSqr621").src = tripleBZeroA;};

function artsquare621(){
    var sBQz621 = document.getElementById("aImgSqr622").src;
    valueBSave621 = 'zSqrArtSpecz621';
    localStorage.setItem(valueBSave621, sBQz621);
};
function squareBToSzzZValue621(){
    valueBSave621 = 'zSqrArtSpecz621';
    var tripleBZeroA = localStorage.getItem(valueBSave621);
    document.getElementById("imgSqr622").src = tripleBZeroA;};

function artsquare622(){
    var sBQz622 = document.getElementById("aImgSqr623").src;
    valueBSave622 = 'zSqrArtSpecz622';
    localStorage.setItem(valueBSave622, sBQz622);
};
function squareBToSzzZValue622(){
    valueBSave622 = 'zSqrArtSpecz622';
    var tripleBZeroA = localStorage.getItem(valueBSave622);
    document.getElementById("imgSqr623").src = tripleBZeroA;};

function artsquare623(){
    var sBQz623 = document.getElementById("aImgSqr624").src;
    valueBSave623 = 'zSqrArtSpecz623';
    localStorage.setItem(valueBSave623, sBQz623);
};
function squareBToSzzZValue623(){
    valueBSave623 = 'zSqrArtSpecz623';
    var tripleBZeroA = localStorage.getItem(valueBSave623);
    document.getElementById("imgSqr624").src = tripleBZeroA;};

function artsquare624(){
    var sBQz624 = document.getElementById("aImgSqr625").src;
    valueBSave624 = 'zSqrArtSpecz624';
    localStorage.setItem(valueBSave624, sBQz624);
};
function squareBToSzzZValue624(){
    valueBSave624 = 'zSqrArtSpecz624';
    var tripleBZeroA = localStorage.getItem(valueBSave624);
    document.getElementById("imgSqr625").src = tripleBZeroA;};


function setAThis2(){
    artsquare0()
    artsquare1()
    artsquare2()
    artsquare3()
    artsquare4()
    artsquare5()
    artsquare6()
    artsquare7()
    artsquare8()
    artsquare9()
    artsquare10()
    artsquare11()
    artsquare12()
    artsquare13()
    artsquare14()
    artsquare15()
    artsquare16()
    artsquare17()
    artsquare18()
    artsquare19()
    artsquare20()
    artsquare21()
    artsquare22()
    artsquare23()
    artsquare24()
    artsquare25()
    artsquare26()
    artsquare27()
    artsquare28()
    artsquare29()
    artsquare30()
    artsquare31()
    artsquare32()
    artsquare33()
    artsquare34()
    artsquare35()
    artsquare36()
    artsquare37()
    artsquare38()
    artsquare39()
    artsquare40()
    artsquare41()
    artsquare42()
    artsquare43()
    artsquare44()
    artsquare45()
    artsquare46()
    artsquare47()
    artsquare48()
    artsquare49()
    artsquare50()
    artsquare51()
    artsquare52()
    artsquare53()
    artsquare54()
    artsquare55()
    artsquare56()
    artsquare57()
    artsquare58()
    artsquare59()
    artsquare60()
    artsquare61()
    artsquare62()
    artsquare63()
    artsquare64()
    artsquare65()
    artsquare66()
    artsquare67()
    artsquare68()
    artsquare69()
    artsquare70()
    artsquare71()
    artsquare72()
    artsquare73()
    artsquare74()
    artsquare75()
    artsquare76()
    artsquare77()
    artsquare78()
    artsquare79()
    artsquare80()
    artsquare81()
    artsquare82()
    artsquare83()
    artsquare84()
    artsquare85()
    artsquare86()
    artsquare87()
    artsquare88()
    artsquare89()
    artsquare90()
    artsquare91()
    artsquare92()
    artsquare93()
    artsquare94()
    artsquare95()
    artsquare96()
    artsquare97()
    artsquare98()
    artsquare99()
    artsquare100()
    artsquare101()
    artsquare102()
    artsquare103()
    artsquare104()
    artsquare105()
    artsquare106()
    artsquare107()
    artsquare108()
    artsquare109()
    artsquare110()
    artsquare111()
    artsquare112()
    artsquare113()
    artsquare114()
    artsquare115()
    artsquare116()
    artsquare117()
    artsquare118()
    artsquare119()
    artsquare120()
    artsquare121()
    artsquare122()
    artsquare123()
    artsquare124()
    artsquare125()
    artsquare126()
    artsquare127()
    artsquare128()
    artsquare129()
    artsquare130()
    artsquare131()
    artsquare132()
    artsquare133()
    artsquare134()
    artsquare135()
    artsquare136()
    artsquare137()
    artsquare138()
    artsquare139()
    artsquare140()
    artsquare141()
    artsquare142()
    artsquare143()
    artsquare144()
    artsquare145()
    artsquare146()
    artsquare147()
    artsquare148()
    artsquare149()
    artsquare150()
    artsquare151()
    artsquare152()
    artsquare153()
    artsquare154()
    artsquare155()
    artsquare156()
    artsquare157()
    artsquare158()
    artsquare159()
    artsquare160()
    artsquare161()
    artsquare162()
    artsquare163()
    artsquare164()
    artsquare165()
    artsquare166()
    artsquare167()
    artsquare168()
    artsquare169()
    artsquare170()
    artsquare171()
    artsquare172()
    artsquare173()
    artsquare174()
    artsquare175()
    artsquare176()
    artsquare177()
    artsquare178()
    artsquare179()
    artsquare180()
    artsquare181()
    artsquare182()
    artsquare183()
    artsquare184()
    artsquare185()
    artsquare186()
    artsquare187()
    artsquare188()
    artsquare189()
    artsquare190()
    artsquare191()
    artsquare192()
    artsquare193()
    artsquare194()
    artsquare195()
    artsquare196()
    artsquare197()
    artsquare198()
    artsquare199()
    artsquare200()
    artsquare201()
    artsquare202()
    artsquare203()
    artsquare204()
    artsquare205()
    artsquare206()
    artsquare207()
    artsquare208()
    artsquare209()
    artsquare210()
    artsquare211()
    artsquare212()
    artsquare213()
    artsquare214()
    artsquare215()
    artsquare216()
    artsquare217()
    artsquare218()
    artsquare219()
    artsquare220()
    artsquare221()
    artsquare222()
    artsquare223()
    artsquare224()
    artsquare225()
    artsquare226()
    artsquare227()
    artsquare228()
    artsquare229()
    artsquare230()
    artsquare231()
    artsquare232()
    artsquare233()
    artsquare234()
    artsquare235()
    artsquare236()
    artsquare237()
    artsquare238()
    artsquare239()
    artsquare240()
    artsquare241()
    artsquare242()
    artsquare243()
    artsquare244()
    artsquare245()
    artsquare246()
    artsquare247()
    artsquare248()
    artsquare249()
    artsquare250()
    artsquare251()
    artsquare252()
    artsquare253()
    artsquare254()
    artsquare255()
    artsquare256()
    artsquare257()
    artsquare258()
    artsquare259()
    artsquare260()
    artsquare261()
    artsquare262()
    artsquare263()
    artsquare264()
    artsquare265()
    artsquare266()
    artsquare267()
    artsquare268()
    artsquare269()
    artsquare270()
    artsquare271()
    artsquare272()
    artsquare273()
    artsquare274()
    artsquare275()
    artsquare276()
    artsquare277()
    artsquare278()
    artsquare279()
    artsquare280()
    artsquare281()
    artsquare282()
    artsquare283()
    artsquare284()
    artsquare285()
    artsquare286()
    artsquare287()
    artsquare288()
    artsquare289()
    artsquare290()
    artsquare291()
    artsquare292()
    artsquare293()
    artsquare294()
    artsquare295()
    artsquare296()
    artsquare297()
    artsquare298()
    artsquare299()
    artsquare300()
    artsquare301()
    artsquare302()
    artsquare303()
    artsquare304()
    artsquare305()
    artsquare306()
    artsquare307()
    artsquare308()
    artsquare309()
    artsquare310()
    artsquare311()
    artsquare312()
    artsquare313()
    artsquare314()
    artsquare315()
    artsquare316()
    artsquare317()
    artsquare318()
    artsquare319()
    artsquare320()
    artsquare321()
    artsquare322()
    artsquare323()
    artsquare324()
    artsquare325()
    artsquare326()
    artsquare327()
    artsquare328()
    artsquare329()
    artsquare330()
    artsquare331()
    artsquare332()
    artsquare333()
    artsquare334()
    artsquare335()
    artsquare336()
    artsquare337()
    artsquare338()
    artsquare339()
    artsquare340()
    artsquare341()
    artsquare342()
    artsquare343()
    artsquare344()
    artsquare345()
    artsquare346()
    artsquare347()
    artsquare348()
    artsquare349()
    artsquare350()
    artsquare351()
    artsquare352()
    artsquare353()
    artsquare354()
    artsquare355()
    artsquare356()
    artsquare357()
    artsquare358()
    artsquare359()
    artsquare360()
    artsquare361()
    artsquare362()
    artsquare363()
    artsquare364()
    artsquare365()
    artsquare366()
    artsquare367()
    artsquare368()
    artsquare369()
    artsquare370()
    artsquare371()
    artsquare372()
    artsquare373()
    artsquare374()
    artsquare375()
    artsquare376()
    artsquare377()
    artsquare378()
    artsquare379()
    artsquare380()
    artsquare381()
    artsquare382()
    artsquare383()
    artsquare384()
    artsquare385()
    artsquare386()
    artsquare387()
    artsquare388()
    artsquare389()
    artsquare390()
    artsquare391()
    artsquare392()
    artsquare393()
    artsquare394()
    artsquare395()
    artsquare396()
    artsquare397()
    artsquare398()
    artsquare399()
    artsquare400()
    artsquare401()
    artsquare402()
    artsquare403()
    artsquare404()
    artsquare405()
    artsquare406()
    artsquare407()
    artsquare408()
    artsquare409()
    artsquare410()
    artsquare411()
    artsquare412()
    artsquare413()
    artsquare414()
    artsquare415()
    artsquare416()
    artsquare417()
    artsquare418()
    artsquare419()
    artsquare420()
    artsquare421()
    artsquare422()
    artsquare423()
    artsquare424()
    artsquare425()
    artsquare426()
    artsquare427()
    artsquare428()
    artsquare429()
    artsquare430()
    artsquare431()
    artsquare432()
    artsquare433()
    artsquare434()
    artsquare435()
    artsquare436()
    artsquare437()
    artsquare438()
    artsquare439()
    artsquare440()
    artsquare441()
    artsquare442()
    artsquare443()
    artsquare444()
    artsquare445()
    artsquare446()
    artsquare447()
    artsquare448()
    artsquare449()
    artsquare450()
    artsquare451()
    artsquare452()
    artsquare453()
    artsquare454()
    artsquare455()
    artsquare456()
    artsquare457()
    artsquare458()
    artsquare459()
    artsquare460()
    artsquare461()
    artsquare462()
    artsquare463()
    artsquare464()
    artsquare465()
    artsquare466()
    artsquare467()
    artsquare468()
    artsquare469()
    artsquare470()
    artsquare471()
    artsquare472()
    artsquare473()
    artsquare474()
    artsquare475()
    artsquare476()
    artsquare477()
    artsquare478()
    artsquare479()
    artsquare480()
    artsquare481()
    artsquare482()
    artsquare483()
    artsquare484()
    artsquare485()
    artsquare486()
    artsquare487()
    artsquare488()
    artsquare489()
    artsquare490()
    artsquare491()
    artsquare492()
    artsquare493()
    artsquare494()
    artsquare495()
    artsquare496()
    artsquare497()
    artsquare498()
    artsquare499()
    artsquare500()
    artsquare501()
    artsquare502()
    artsquare503()
    artsquare504()
    artsquare505()
    artsquare506()
    artsquare507()
    artsquare508()
    artsquare509()
    artsquare510()
    artsquare511()
    artsquare512()
    artsquare513()
    artsquare514()
    artsquare515()
    artsquare516()
    artsquare517()
    artsquare518()
    artsquare519()
    artsquare520()
    artsquare521()
    artsquare522()
    artsquare523()
    artsquare524()
    artsquare525()
    artsquare526()
    artsquare527()
    artsquare528()
    artsquare529()
    artsquare530()
    artsquare531()
    artsquare532()
    artsquare533()
    artsquare534()
    artsquare535()
    artsquare536()
    artsquare537()
    artsquare538()
    artsquare539()
    artsquare540()
    artsquare541()
    artsquare542()
    artsquare543()
    artsquare544()
    artsquare545()
    artsquare546()
    artsquare547()
    artsquare548()
    artsquare549()
    artsquare550()
    artsquare551()
    artsquare552()
    artsquare553()
    artsquare554()
    artsquare555()
    artsquare556()
    artsquare557()
    artsquare558()
    artsquare559()
    artsquare560()
    artsquare561()
    artsquare562()
    artsquare563()
    artsquare564()
    artsquare565()
    artsquare566()
    artsquare567()
    artsquare568()
    artsquare569()
    artsquare570()
    artsquare571()
    artsquare572()
    artsquare573()
    artsquare574()
    artsquare575()
    artsquare576()
    artsquare577()
    artsquare578()
    artsquare579()
    artsquare580()
    artsquare581()
    artsquare582()
    artsquare583()
    artsquare584()
    artsquare585()
    artsquare586()
    artsquare587()
    artsquare588()
    artsquare589()
    artsquare590()
    artsquare591()
    artsquare592()
    artsquare593()
    artsquare594()
    artsquare595()
    artsquare596()
    artsquare597()
    artsquare598()
    artsquare599()
    artsquare600()
    artsquare601()
    artsquare602()
    artsquare603()
    artsquare604()
    artsquare605()
    artsquare606()
    artsquare607()
    artsquare608()
    artsquare609()
    artsquare610()
    artsquare611()
    artsquare612()
    artsquare613()
    artsquare614()
    artsquare615()
    artsquare616()
    artsquare617()
    artsquare618()
    artsquare619()
    artsquare620()
    artsquare621()
    artsquare622()
    artsquare623()
    artsquare624()
    alert("Your art has been saved locally, to your local browser storage.");
};

function getAThis2(){
    
    squareBToSzzZValue0()
    squareBToSzzZValue1()
    squareBToSzzZValue2()
    squareBToSzzZValue3()
    squareBToSzzZValue4()
    squareBToSzzZValue5()
    squareBToSzzZValue6()
    squareBToSzzZValue7()
    squareBToSzzZValue8()
    squareBToSzzZValue9()
    squareBToSzzZValue10()
    squareBToSzzZValue11()
    squareBToSzzZValue12()
    squareBToSzzZValue13()
    squareBToSzzZValue14()
    squareBToSzzZValue15()
    squareBToSzzZValue16()
    squareBToSzzZValue17()
    squareBToSzzZValue18()
    squareBToSzzZValue19()
    squareBToSzzZValue20()
    squareBToSzzZValue21()
    squareBToSzzZValue22()
    squareBToSzzZValue23()
    squareBToSzzZValue24()
    squareBToSzzZValue25()
    squareBToSzzZValue26()
    squareBToSzzZValue27()
    squareBToSzzZValue28()
    squareBToSzzZValue29()
    squareBToSzzZValue30()
    squareBToSzzZValue31()
    squareBToSzzZValue32()
    squareBToSzzZValue33()
    squareBToSzzZValue34()
    squareBToSzzZValue35()
    squareBToSzzZValue36()
    squareBToSzzZValue37()
    squareBToSzzZValue38()
    squareBToSzzZValue39()
    squareBToSzzZValue40()
    squareBToSzzZValue41()
    squareBToSzzZValue42()
    squareBToSzzZValue43()
    squareBToSzzZValue44()
    squareBToSzzZValue45()
    squareBToSzzZValue46()
    squareBToSzzZValue47()
    squareBToSzzZValue48()
    squareBToSzzZValue49()
    squareBToSzzZValue50()
    squareBToSzzZValue51()
    squareBToSzzZValue52()
    squareBToSzzZValue53()
    squareBToSzzZValue54()
    squareBToSzzZValue55()
    squareBToSzzZValue56()
    squareBToSzzZValue57()
    squareBToSzzZValue58()
    squareBToSzzZValue59()
    squareBToSzzZValue60()
    squareBToSzzZValue61()
    squareBToSzzZValue62()
    squareBToSzzZValue63()
    squareBToSzzZValue64()
    squareBToSzzZValue65()
    squareBToSzzZValue66()
    squareBToSzzZValue67()
    squareBToSzzZValue68()
    squareBToSzzZValue69()
    squareBToSzzZValue70()
    squareBToSzzZValue71()
    squareBToSzzZValue72()
    squareBToSzzZValue73()
    squareBToSzzZValue74()
    squareBToSzzZValue75()
    squareBToSzzZValue76()
    squareBToSzzZValue77()
    squareBToSzzZValue78()
    squareBToSzzZValue79()
    squareBToSzzZValue80()
    squareBToSzzZValue81()
    squareBToSzzZValue82()
    squareBToSzzZValue83()
    squareBToSzzZValue84()
    squareBToSzzZValue85()
    squareBToSzzZValue86()
    squareBToSzzZValue87()
    squareBToSzzZValue88()
    squareBToSzzZValue89()
    squareBToSzzZValue90()
    squareBToSzzZValue91()
    squareBToSzzZValue92()
    squareBToSzzZValue93()
    squareBToSzzZValue94()
    squareBToSzzZValue95()
    squareBToSzzZValue96()
    squareBToSzzZValue97()
    squareBToSzzZValue98()
    squareBToSzzZValue99()
    squareBToSzzZValue100()
    squareBToSzzZValue101()
    squareBToSzzZValue102()
    squareBToSzzZValue103()
    squareBToSzzZValue104()
    squareBToSzzZValue105()
    squareBToSzzZValue106()
    squareBToSzzZValue107()
    squareBToSzzZValue108()
    squareBToSzzZValue109()
    squareBToSzzZValue110()
    squareBToSzzZValue111()
    squareBToSzzZValue112()
    squareBToSzzZValue113()
    squareBToSzzZValue114()
    squareBToSzzZValue115()
    squareBToSzzZValue116()
    squareBToSzzZValue117()
    squareBToSzzZValue118()
    squareBToSzzZValue119()
    squareBToSzzZValue120()
    squareBToSzzZValue121()
    squareBToSzzZValue122()
    squareBToSzzZValue123()
    squareBToSzzZValue124()
    squareBToSzzZValue125()
    squareBToSzzZValue126()
    squareBToSzzZValue127()
    squareBToSzzZValue128()
    squareBToSzzZValue129()
    squareBToSzzZValue130()
    squareBToSzzZValue131()
    squareBToSzzZValue132()
    squareBToSzzZValue133()
    squareBToSzzZValue134()
    squareBToSzzZValue135()
    squareBToSzzZValue136()
    squareBToSzzZValue137()
    squareBToSzzZValue138()
    squareBToSzzZValue139()
    squareBToSzzZValue140()
    squareBToSzzZValue141()
    squareBToSzzZValue142()
    squareBToSzzZValue143()
    squareBToSzzZValue144()
    squareBToSzzZValue145()
    squareBToSzzZValue146()
    squareBToSzzZValue147()
    squareBToSzzZValue148()
    squareBToSzzZValue149()
    squareBToSzzZValue150()
    squareBToSzzZValue151()
    squareBToSzzZValue152()
    squareBToSzzZValue153()
    squareBToSzzZValue154()
    squareBToSzzZValue155()
    squareBToSzzZValue156()
    squareBToSzzZValue157()
    squareBToSzzZValue158()
    squareBToSzzZValue159()
    squareBToSzzZValue160()
    squareBToSzzZValue161()
    squareBToSzzZValue162()
    squareBToSzzZValue163()
    squareBToSzzZValue164()
    squareBToSzzZValue165()
    squareBToSzzZValue166()
    squareBToSzzZValue167()
    squareBToSzzZValue168()
    squareBToSzzZValue169()
    squareBToSzzZValue170()
    squareBToSzzZValue171()
    squareBToSzzZValue172()
    squareBToSzzZValue173()
    squareBToSzzZValue174()
    squareBToSzzZValue175()
    squareBToSzzZValue176()
    squareBToSzzZValue177()
    squareBToSzzZValue178()
    squareBToSzzZValue179()
    squareBToSzzZValue180()
    squareBToSzzZValue181()
    squareBToSzzZValue182()
    squareBToSzzZValue183()
    squareBToSzzZValue184()
    squareBToSzzZValue185()
    squareBToSzzZValue186()
    squareBToSzzZValue187()
    squareBToSzzZValue188()
    squareBToSzzZValue189()
    squareBToSzzZValue190()
    squareBToSzzZValue191()
    squareBToSzzZValue192()
    squareBToSzzZValue193()
    squareBToSzzZValue194()
    squareBToSzzZValue195()
    squareBToSzzZValue196()
    squareBToSzzZValue197()
    squareBToSzzZValue198()
    squareBToSzzZValue199()
    squareBToSzzZValue200()
    squareBToSzzZValue201()
    squareBToSzzZValue202()
    squareBToSzzZValue203()
    squareBToSzzZValue204()
    squareBToSzzZValue205()
    squareBToSzzZValue206()
    squareBToSzzZValue207()
    squareBToSzzZValue208()
    squareBToSzzZValue209()
    squareBToSzzZValue210()
    squareBToSzzZValue211()
    squareBToSzzZValue212()
    squareBToSzzZValue213()
    squareBToSzzZValue214()
    squareBToSzzZValue215()
    squareBToSzzZValue216()
    squareBToSzzZValue217()
    squareBToSzzZValue218()
    squareBToSzzZValue219()
    squareBToSzzZValue220()
    squareBToSzzZValue221()
    squareBToSzzZValue222()
    squareBToSzzZValue223()
    squareBToSzzZValue224()
    squareBToSzzZValue225()
    squareBToSzzZValue226()
    squareBToSzzZValue227()
    squareBToSzzZValue228()
    squareBToSzzZValue229()
    squareBToSzzZValue230()
    squareBToSzzZValue231()
    squareBToSzzZValue232()
    squareBToSzzZValue233()
    squareBToSzzZValue234()
    squareBToSzzZValue235()
    squareBToSzzZValue236()
    squareBToSzzZValue237()
    squareBToSzzZValue238()
    squareBToSzzZValue239()
    squareBToSzzZValue240()
    squareBToSzzZValue241()
    squareBToSzzZValue242()
    squareBToSzzZValue243()
    squareBToSzzZValue244()
    squareBToSzzZValue245()
    squareBToSzzZValue246()
    squareBToSzzZValue247()
    squareBToSzzZValue248()
    squareBToSzzZValue249()
    squareBToSzzZValue250()
    squareBToSzzZValue251()
    squareBToSzzZValue252()
    squareBToSzzZValue253()
    squareBToSzzZValue254()
    squareBToSzzZValue255()
    squareBToSzzZValue256()
    squareBToSzzZValue257()
    squareBToSzzZValue258()
    squareBToSzzZValue259()
    squareBToSzzZValue260()
    squareBToSzzZValue261()
    squareBToSzzZValue262()
    squareBToSzzZValue263()
    squareBToSzzZValue264()
    squareBToSzzZValue265()
    squareBToSzzZValue266()
    squareBToSzzZValue267()
    squareBToSzzZValue268()
    squareBToSzzZValue269()
    squareBToSzzZValue270()
    squareBToSzzZValue271()
    squareBToSzzZValue272()
    squareBToSzzZValue273()
    squareBToSzzZValue274()
    squareBToSzzZValue275()
    squareBToSzzZValue276()
    squareBToSzzZValue277()
    squareBToSzzZValue278()
    squareBToSzzZValue279()
    squareBToSzzZValue280()
    squareBToSzzZValue281()
    squareBToSzzZValue282()
    squareBToSzzZValue283()
    squareBToSzzZValue284()
    squareBToSzzZValue285()
    squareBToSzzZValue286()
    squareBToSzzZValue287()
    squareBToSzzZValue288()
    squareBToSzzZValue289()
    squareBToSzzZValue290()
    squareBToSzzZValue291()
    squareBToSzzZValue292()
    squareBToSzzZValue293()
    squareBToSzzZValue294()
    squareBToSzzZValue295()
    squareBToSzzZValue296()
    squareBToSzzZValue297()
    squareBToSzzZValue298()
    squareBToSzzZValue299()
    squareBToSzzZValue300()
    squareBToSzzZValue301()
    squareBToSzzZValue302()
    squareBToSzzZValue303()
    squareBToSzzZValue304()
    squareBToSzzZValue305()
    squareBToSzzZValue306()
    squareBToSzzZValue307()
    squareBToSzzZValue308()
    squareBToSzzZValue309()
    squareBToSzzZValue310()
    squareBToSzzZValue311()
    squareBToSzzZValue312()
    squareBToSzzZValue313()
    squareBToSzzZValue314()
    squareBToSzzZValue315()
    squareBToSzzZValue316()
    squareBToSzzZValue317()
    squareBToSzzZValue318()
    squareBToSzzZValue319()
    squareBToSzzZValue320()
    squareBToSzzZValue321()
    squareBToSzzZValue322()
    squareBToSzzZValue323()
    squareBToSzzZValue324()
    squareBToSzzZValue325()
    squareBToSzzZValue326()
    squareBToSzzZValue327()
    squareBToSzzZValue328()
    squareBToSzzZValue329()
    squareBToSzzZValue330()
    squareBToSzzZValue331()
    squareBToSzzZValue332()
    squareBToSzzZValue333()
    squareBToSzzZValue334()
    squareBToSzzZValue335()
    squareBToSzzZValue336()
    squareBToSzzZValue337()
    squareBToSzzZValue338()
    squareBToSzzZValue339()
    squareBToSzzZValue340()
    squareBToSzzZValue341()
    squareBToSzzZValue342()
    squareBToSzzZValue343()
    squareBToSzzZValue344()
    squareBToSzzZValue345()
    squareBToSzzZValue346()
    squareBToSzzZValue347()
    squareBToSzzZValue348()
    squareBToSzzZValue349()
    squareBToSzzZValue350()
    squareBToSzzZValue351()
    squareBToSzzZValue352()
    squareBToSzzZValue353()
    squareBToSzzZValue354()
    squareBToSzzZValue355()
    squareBToSzzZValue356()
    squareBToSzzZValue357()
    squareBToSzzZValue358()
    squareBToSzzZValue359()
    squareBToSzzZValue360()
    squareBToSzzZValue361()
    squareBToSzzZValue362()
    squareBToSzzZValue363()
    squareBToSzzZValue364()
    squareBToSzzZValue365()
    squareBToSzzZValue366()
    squareBToSzzZValue367()
    squareBToSzzZValue368()
    squareBToSzzZValue369()
    squareBToSzzZValue370()
    squareBToSzzZValue371()
    squareBToSzzZValue372()
    squareBToSzzZValue373()
    squareBToSzzZValue374()
    squareBToSzzZValue375()
    squareBToSzzZValue376()
    squareBToSzzZValue377()
    squareBToSzzZValue378()
    squareBToSzzZValue379()
    squareBToSzzZValue380()
    squareBToSzzZValue381()
    squareBToSzzZValue382()
    squareBToSzzZValue383()
    squareBToSzzZValue384()
    squareBToSzzZValue385()
    squareBToSzzZValue386()
    squareBToSzzZValue387()
    squareBToSzzZValue388()
    squareBToSzzZValue389()
    squareBToSzzZValue390()
    squareBToSzzZValue391()
    squareBToSzzZValue392()
    squareBToSzzZValue393()
    squareBToSzzZValue394()
    squareBToSzzZValue395()
    squareBToSzzZValue396()
    squareBToSzzZValue397()
    squareBToSzzZValue398()
    squareBToSzzZValue399()
    squareBToSzzZValue400()
    squareBToSzzZValue401()
    squareBToSzzZValue402()
    squareBToSzzZValue403()
    squareBToSzzZValue404()
    squareBToSzzZValue405()
    squareBToSzzZValue406()
    squareBToSzzZValue407()
    squareBToSzzZValue408()
    squareBToSzzZValue409()
    squareBToSzzZValue410()
    squareBToSzzZValue411()
    squareBToSzzZValue412()
    squareBToSzzZValue413()
    squareBToSzzZValue414()
    squareBToSzzZValue415()
    squareBToSzzZValue416()
    squareBToSzzZValue417()
    squareBToSzzZValue418()
    squareBToSzzZValue419()
    squareBToSzzZValue420()
    squareBToSzzZValue421()
    squareBToSzzZValue422()
    squareBToSzzZValue423()
    squareBToSzzZValue424()
    squareBToSzzZValue425()
    squareBToSzzZValue426()
    squareBToSzzZValue427()
    squareBToSzzZValue428()
    squareBToSzzZValue429()
    squareBToSzzZValue430()
    squareBToSzzZValue431()
    squareBToSzzZValue432()
    squareBToSzzZValue433()
    squareBToSzzZValue434()
    squareBToSzzZValue435()
    squareBToSzzZValue436()
    squareBToSzzZValue437()
    squareBToSzzZValue438()
    squareBToSzzZValue439()
    squareBToSzzZValue440()
    squareBToSzzZValue441()
    squareBToSzzZValue442()
    squareBToSzzZValue443()
    squareBToSzzZValue444()
    squareBToSzzZValue445()
    squareBToSzzZValue446()
    squareBToSzzZValue447()
    squareBToSzzZValue448()
    squareBToSzzZValue449()
    squareBToSzzZValue450()
    squareBToSzzZValue451()
    squareBToSzzZValue452()
    squareBToSzzZValue453()
    squareBToSzzZValue454()
    squareBToSzzZValue455()
    squareBToSzzZValue456()
    squareBToSzzZValue457()
    squareBToSzzZValue458()
    squareBToSzzZValue459()
    squareBToSzzZValue460()
    squareBToSzzZValue461()
    squareBToSzzZValue462()
    squareBToSzzZValue463()
    squareBToSzzZValue464()
    squareBToSzzZValue465()
    squareBToSzzZValue466()
    squareBToSzzZValue467()
    squareBToSzzZValue468()
    squareBToSzzZValue469()
    squareBToSzzZValue470()
    squareBToSzzZValue471()
    squareBToSzzZValue472()
    squareBToSzzZValue473()
    squareBToSzzZValue474()
    squareBToSzzZValue475()
    squareBToSzzZValue476()
    squareBToSzzZValue477()
    squareBToSzzZValue478()
    squareBToSzzZValue479()
    squareBToSzzZValue480()
    squareBToSzzZValue481()
    squareBToSzzZValue482()
    squareBToSzzZValue483()
    squareBToSzzZValue484()
    squareBToSzzZValue485()
    squareBToSzzZValue486()
    squareBToSzzZValue487()
    squareBToSzzZValue488()
    squareBToSzzZValue489()
    squareBToSzzZValue490()
    squareBToSzzZValue491()
    squareBToSzzZValue492()
    squareBToSzzZValue493()
    squareBToSzzZValue494()
    squareBToSzzZValue495()
    squareBToSzzZValue496()
    squareBToSzzZValue497()
    squareBToSzzZValue498()
    squareBToSzzZValue499()
    squareBToSzzZValue500()
    squareBToSzzZValue501()
    squareBToSzzZValue502()
    squareBToSzzZValue503()
    squareBToSzzZValue504()
    squareBToSzzZValue505()
    squareBToSzzZValue506()
    squareBToSzzZValue507()
    squareBToSzzZValue508()
    squareBToSzzZValue509()
    squareBToSzzZValue510()
    squareBToSzzZValue511()
    squareBToSzzZValue512()
    squareBToSzzZValue513()
    squareBToSzzZValue514()
    squareBToSzzZValue515()
    squareBToSzzZValue516()
    squareBToSzzZValue517()
    squareBToSzzZValue518()
    squareBToSzzZValue519()
    squareBToSzzZValue520()
    squareBToSzzZValue521()
    squareBToSzzZValue522()
    squareBToSzzZValue523()
    squareBToSzzZValue524()
    squareBToSzzZValue525()
    squareBToSzzZValue526()
    squareBToSzzZValue527()
    squareBToSzzZValue528()
    squareBToSzzZValue529()
    squareBToSzzZValue530()
    squareBToSzzZValue531()
    squareBToSzzZValue532()
    squareBToSzzZValue533()
    squareBToSzzZValue534()
    squareBToSzzZValue535()
    squareBToSzzZValue536()
    squareBToSzzZValue537()
    squareBToSzzZValue538()
    squareBToSzzZValue539()
    squareBToSzzZValue540()
    squareBToSzzZValue541()
    squareBToSzzZValue542()
    squareBToSzzZValue543()
    squareBToSzzZValue544()
    squareBToSzzZValue545()
    squareBToSzzZValue546()
    squareBToSzzZValue547()
    squareBToSzzZValue548()
    squareBToSzzZValue549()
    squareBToSzzZValue550()
    squareBToSzzZValue551()
    squareBToSzzZValue552()
    squareBToSzzZValue553()
    squareBToSzzZValue554()
    squareBToSzzZValue555()
    squareBToSzzZValue556()
    squareBToSzzZValue557()
    squareBToSzzZValue558()
    squareBToSzzZValue559()
    squareBToSzzZValue560()
    squareBToSzzZValue561()
    squareBToSzzZValue562()
    squareBToSzzZValue563()
    squareBToSzzZValue564()
    squareBToSzzZValue565()
    squareBToSzzZValue566()
    squareBToSzzZValue567()
    squareBToSzzZValue568()
    squareBToSzzZValue569()
    squareBToSzzZValue570()
    squareBToSzzZValue571()
    squareBToSzzZValue572()
    squareBToSzzZValue573()
    squareBToSzzZValue574()
    squareBToSzzZValue575()
    squareBToSzzZValue576()
    squareBToSzzZValue577()
    squareBToSzzZValue578()
    squareBToSzzZValue579()
    squareBToSzzZValue580()
    squareBToSzzZValue581()
    squareBToSzzZValue582()
    squareBToSzzZValue583()
    squareBToSzzZValue584()
    squareBToSzzZValue585()
    squareBToSzzZValue586()
    squareBToSzzZValue587()
    squareBToSzzZValue588()
    squareBToSzzZValue589()
    squareBToSzzZValue590()
    squareBToSzzZValue591()
    squareBToSzzZValue592()
    squareBToSzzZValue593()
    squareBToSzzZValue594()
    squareBToSzzZValue595()
    squareBToSzzZValue596()
    squareBToSzzZValue597()
    squareBToSzzZValue598()
    squareBToSzzZValue599()
    squareBToSzzZValue600()
    squareBToSzzZValue601()
    squareBToSzzZValue602()
    squareBToSzzZValue603()
    squareBToSzzZValue604()
    squareBToSzzZValue605()
    squareBToSzzZValue606()
    squareBToSzzZValue607()
    squareBToSzzZValue608()
    squareBToSzzZValue609()
    squareBToSzzZValue610()
    squareBToSzzZValue611()
    squareBToSzzZValue612()
    squareBToSzzZValue613()
    squareBToSzzZValue614()
    squareBToSzzZValue615()
    squareBToSzzZValue616()
    squareBToSzzZValue617()
    squareBToSzzZValue618()
    squareBToSzzZValue619()
    squareBToSzzZValue620()
    squareBToSzzZValue621()
    squareBToSzzZValue622()
    squareBToSzzZValue623()
    squareBToSzzZValue624()
    
    alert("Your art has been loaded successfully from your browser's local browser storage.");

};

function squareNull(){
    valueCSave = 'zSqrArtSpecz0';
    var tripleBZeroA = localStorage.getItem(valueCSave);
    if(tripleBZeroA == null){
        setAThis();
    }else{
        getBThis();
    };
};