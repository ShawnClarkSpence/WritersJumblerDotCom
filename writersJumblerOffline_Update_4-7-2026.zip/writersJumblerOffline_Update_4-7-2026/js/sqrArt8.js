function RasqrA1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr1").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr1").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrA2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr2").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr2").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrA3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr3").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr3").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrA4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr4").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr4").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrA5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr5").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr5").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrA6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr6").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr6").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrA7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr7").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr7").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrA8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr8").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr8").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrA9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr9").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr9").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrA10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr10").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr10").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrA11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr11").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr11").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrA12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr12").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr12").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrA13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr13").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr13").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrA14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr14").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr14").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrA15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr15").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr15").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrA16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr16").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr16").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrA17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr17").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr17").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrA18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr18").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr18").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrA19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr19").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr19").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrA20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr20").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr20").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrA21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr21").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr21").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrA22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr22").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr22").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrA23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr23").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr23").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrA24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr24").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr24").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrA25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr25").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr25").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrB1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr26").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr26").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrB2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr27").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr27").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrB3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr28").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr28").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrB4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr29").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr29").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrB5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr30").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr30").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrB6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr31").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr31").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrB7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr32").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr32").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrB8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr33").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr33").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrB9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr34").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr34").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrB10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr35").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr35").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrB11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr36").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr36").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrB12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr37").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr37").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrB13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr38").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr38").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrB14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr39").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr39").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrB15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr40").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr40").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrB16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr41").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr41").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrB17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr42").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr42").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrB18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr43").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr43").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrB19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr44").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr44").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrB20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr45").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr45").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrB21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr46").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr46").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrB22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr47").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr47").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrB23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr48").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr48").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrB24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr49").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr49").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrB25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr50").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr50").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrC1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr51").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr51").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrC2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr52").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr52").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrC3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr53").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr53").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrC4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr54").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr54").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrC5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr55").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr55").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrC6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr56").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr56").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrC7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr57").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr57").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrC8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr58").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr58").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrC9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr59").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr59").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrC10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr60").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr60").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrC11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr61").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr61").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrC12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr62").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr62").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrC13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr63").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr63").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrC14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr64").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr64").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrC15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr65").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr65").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrC16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr66").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr66").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrC17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr67").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr67").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrC18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr68").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr68").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrC19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr69").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr69").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrC20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr70").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr70").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrC21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr71").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr71").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrC22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr72").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr72").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrC23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr73").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr73").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrC24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr74").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr74").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrC25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr75").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr75").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrD1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr76").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr76").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrD2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr77").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr77").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrD3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr78").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr78").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrD4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr79").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr79").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrD5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr80").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr80").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrD6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr81").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr81").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrD7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr82").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr82").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrD8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr83").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr83").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrD9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr84").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr84").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrD10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr85").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr85").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrD11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr86").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr86").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrD12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr87").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr87").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrD13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr88").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr88").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrD14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr89").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr89").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrD15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr90").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr90").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrD16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr91").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr91").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrD17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr92").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr92").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrD18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr93").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr93").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrD19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr94").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr94").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrD20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr95").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr95").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrD21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr96").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr96").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrD22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr97").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr97").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrD23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr98").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr98").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrD24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr99").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr99").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrD25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr100").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr100").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrE1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr101").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr101").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrE2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr102").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr102").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrE3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr103").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr103").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrE4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr104").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr104").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrE5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr105").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr105").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrE6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr106").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr106").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrE7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr107").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr107").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrE8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr108").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr108").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrE9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr109").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr109").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrE10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr110").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr110").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrE11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr111").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr111").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrE12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr112").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr112").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrE13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr113").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr113").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrE14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr114").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr114").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrE15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr115").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr115").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrE16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr116").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr116").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrE17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr117").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr117").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrE18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr118").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr118").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrE19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr119").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr119").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrE20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr120").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr120").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrE21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr121").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr121").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrE22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr122").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr122").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrE23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr123").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr123").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrE24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr124").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr124").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrE25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr125").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr125").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrF1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr126").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr126").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrF2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr127").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr127").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrF3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr128").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr128").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrF4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr129").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr129").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrF5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr130").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr130").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrF6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr131").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr131").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrF7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr132").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr132").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrF8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr133").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr133").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrF9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr134").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr134").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrF10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr135").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr135").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrF11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr136").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr136").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrF12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr137").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr137").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrF13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr138").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr138").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrF14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr139").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr139").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrF15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr140").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr140").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrF16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr141").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr141").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrF17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr142").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr142").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrF18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr143").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr143").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrF19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr144").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr144").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrF20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr145").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr145").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrF21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr146").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr146").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrF22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr147").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr147").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrF23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr148").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr148").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrF24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr149").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr149").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrF25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr150").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr150").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrG1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr151").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr151").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrG2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr152").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr152").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrG3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr153").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr153").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrG4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr154").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr154").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrG5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr155").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr155").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrG6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr156").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr156").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrG7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr157").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr157").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrG8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr158").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr158").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrG9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr159").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr159").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrG10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr160").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr160").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrG11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr161").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr161").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrG12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr162").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr162").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrG13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr163").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr163").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrG14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr164").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr164").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrG15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr165").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr165").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrG16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr166").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr166").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrG17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr167").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr167").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrG18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr168").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr168").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrG19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr169").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr169").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrG20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr170").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr170").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrG21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr171").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr171").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrG22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr172").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr172").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrG23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr173").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr173").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrG24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr174").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr174").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrG25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr175").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr175").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrH1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr176").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr176").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrH2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr177").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr177").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrH3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr178").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr178").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrH4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr179").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr179").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrH5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr180").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr180").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrH6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr181").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr181").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrH7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr182").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr182").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrH8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr183").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr183").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrH9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr184").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr184").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrH10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr185").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr185").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrH11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr186").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr186").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrH12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr187").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr187").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrH13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr188").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr188").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrH14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr189").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr189").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrH15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr190").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr190").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrH16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr191").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr191").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrH17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr192").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr192").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrH18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr193").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr193").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrH19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr194").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr194").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrH20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr195").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr195").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrH21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr196").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr196").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrH22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr197").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr197").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrH23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr198").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr198").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrH24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr199").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr199").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrH25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr200").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr200").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrI1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr201").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr201").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrI2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr202").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr202").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrI3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr203").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr203").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrI4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr204").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr204").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrI5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr205").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr205").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrI6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr206").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr206").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrI7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr207").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr207").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrI8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr208").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr208").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrI9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr209").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr209").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrI10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr210").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr210").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrI11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr211").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr211").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrI12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr212").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr212").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrI13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr213").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr213").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrI14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr214").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr214").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrI15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr215").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr215").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrI16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr216").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr216").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrI17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr217").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr217").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrI18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr218").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr218").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrI19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr219").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr219").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrI20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr220").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr220").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrI21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr221").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr221").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrI22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr222").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr222").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrI23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr223").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr223").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrI24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr224").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr224").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrI25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr225").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr225").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrJ1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr226").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr226").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrJ2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr227").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr227").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrJ3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr228").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr228").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrJ4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr229").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr229").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrJ5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr230").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr230").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrJ6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr231").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr231").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrJ7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr232").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr232").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrJ8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr233").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr233").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrJ9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr234").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr234").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrJ10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr235").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr235").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrJ11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr236").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr236").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrJ12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr237").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr237").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrJ13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr238").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr238").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrJ14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr239").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr239").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrJ15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr240").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr240").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrJ16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr241").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr241").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrJ17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr242").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr242").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrJ18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr243").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr243").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrJ19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr244").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr244").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrJ20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr245").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr245").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrJ21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr246").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr246").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrJ22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr247").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr247").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrJ23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr248").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr248").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrJ24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr249").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr249").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrJ25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr250").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr250").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrK1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr251").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr251").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrK2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr252").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr252").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrK3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr253").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr253").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrK4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr254").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr254").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrK5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr255").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr255").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrK6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr256").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr256").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrK7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr257").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr257").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrK8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr258").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr258").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrK9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr259").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr259").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrK10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr260").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr260").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrK11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr261").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr261").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrK12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr262").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr262").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrK13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr263").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr263").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrK14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr264").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr264").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrK15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr265").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr265").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrK16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr266").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr266").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrK17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr267").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr267").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrK18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr268").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr268").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrK19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr269").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr269").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrK20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr270").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr270").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrK21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr271").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr271").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrK22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr272").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr272").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrK23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr273").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr273").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrK24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr274").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr274").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrK25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr275").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr275").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrL1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr276").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr276").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrL2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr277").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr277").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrL3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr278").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr278").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrL4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr279").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr279").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrL5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr280").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr280").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrL6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr281").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr281").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrL7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr282").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr282").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrL8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr283").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr283").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrL9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr284").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr284").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrL10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr285").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr285").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrL11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr286").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr286").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrL12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr287").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr287").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrL13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr288").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr288").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrL14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr289").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr289").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrL15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr290").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr290").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrL16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr291").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr291").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrL17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr292").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr292").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrL18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr293").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr293").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrL19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr294").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr294").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrL20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr295").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr295").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrL21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr296").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr296").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrL22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr297").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr297").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrL23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr298").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr298").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrL24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr299").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr299").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrL25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr300").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr300").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrM1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr301").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr301").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrM2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr302").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr302").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrM3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr303").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr303").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrM4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr304").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr304").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrM5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr305").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr305").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrM6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr306").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr306").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrM7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr307").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr307").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrM8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr308").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr308").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrM9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr309").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr309").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrM10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr310").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr310").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrM11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr311").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr311").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrM12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr312").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr312").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrM13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr313").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr313").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrM14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr314").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr314").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrM15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr315").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr315").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrM16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr316").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr316").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrM17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr317").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr317").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrM18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr318").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr318").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrM19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr319").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr319").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrM20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr320").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr320").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrM21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr321").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr321").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrM22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr322").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr322").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrM23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr323").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr323").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrM24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr324").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr324").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrM25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr325").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr325").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrN1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr326").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr326").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrN2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr327").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr327").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrN3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr328").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr328").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrN4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr329").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr329").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrN5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr330").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr330").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrN6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr331").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr331").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrN7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr332").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr332").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrN8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr333").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr333").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrN9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr334").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr334").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrN10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr335").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr335").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrN11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr336").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr336").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrN12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr337").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr337").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrN13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr338").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr338").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrN14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr339").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr339").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrN15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr340").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr340").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrN16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr341").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr341").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrN17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr342").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr342").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrN18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr343").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr343").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrN19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr344").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr344").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrN20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr345").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr345").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrN21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr346").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr346").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrN22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr347").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr347").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrN23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr348").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr348").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrN24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr349").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr349").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrN25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr350").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr350").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrO1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr351").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr351").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrO2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr352").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr352").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrO3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr353").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr353").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrO4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr354").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr354").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrO5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr355").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr355").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrO6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr356").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr356").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrO7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr357").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr357").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrO8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr358").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr358").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrO9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr359").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr359").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrO10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr360").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr360").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrO11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr361").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr361").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrO12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr362").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr362").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrO13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr363").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr363").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrO14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr364").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr364").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrO15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr365").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr365").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrO16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr366").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr366").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrO17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr367").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr367").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrO18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr368").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr368").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrO19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr369").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr369").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrO20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr370").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr370").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrO21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr371").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr371").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrO22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr372").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr372").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrO23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr373").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr373").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrO24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr374").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr374").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrO25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr375").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr375").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrP1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr376").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr376").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrP2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr377").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr377").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrP3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr378").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr378").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrP4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr379").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr379").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrP5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr380").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr380").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrP6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr381").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr381").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrP7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr382").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr382").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrP8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr383").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr383").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrP9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr384").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr384").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrP10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr385").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr385").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrP11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr386").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr386").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrP12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr387").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr387").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrP13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr388").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr388").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrP14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr389").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr389").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrP15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr390").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr390").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrP16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr391").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr391").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrP17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr392").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr392").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrP18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr393").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr393").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrP19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr394").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr394").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrP20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr395").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr395").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrP21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr396").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr396").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrP22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr397").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr397").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrP23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr398").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr398").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrP24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr399").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr399").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrP25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr400").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr400").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrQ1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr401").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr401").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrQ2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr402").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr402").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrQ3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr403").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr403").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrQ4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr404").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr404").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrQ5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr405").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr405").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrQ6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr406").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr406").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrQ7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr407").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr407").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrQ8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr408").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr408").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrQ9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr409").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr409").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrQ10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr410").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr410").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrQ11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr411").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr411").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrQ12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr412").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr412").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrQ13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr413").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr413").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrQ14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr414").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr414").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrQ15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr415").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr415").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrQ16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr416").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr416").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrQ17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr417").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr417").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrQ18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr418").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr418").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrQ19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr419").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr419").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrQ20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr420").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr420").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrQ21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr421").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr421").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrQ22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr422").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr422").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrQ23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr423").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr423").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrQ24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr424").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr424").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrQ25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr425").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr425").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrR1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr426").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr426").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrR2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr427").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr427").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrR3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr428").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr428").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrR4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr429").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr429").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrR5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr430").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr430").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrR6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr431").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr431").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrR7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr432").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr432").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrR8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr433").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr433").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrR9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr434").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr434").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrR10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr435").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr435").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrR11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr436").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr436").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrR12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr437").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr437").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrR13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr438").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr438").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrR14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr439").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr439").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrR15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr440").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr440").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrR16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr441").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr441").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrR17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr442").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr442").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrR18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr443").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr443").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrR19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr444").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr444").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrR20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr445").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr445").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrR21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr446").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr446").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrR22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr447").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr447").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrR23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr448").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr448").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrR24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr449").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr449").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrR25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr450").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr450").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrS1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr451").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr451").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrS2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr452").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr452").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrS3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr453").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr453").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrS4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr454").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr454").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrS5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr455").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr455").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrS6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr456").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr456").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrS7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr457").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr457").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrS8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr458").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr458").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrS9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr459").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr459").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrS10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr460").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr460").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrS11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr461").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr461").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrS12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr462").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr462").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrS13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr463").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr463").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrS14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr464").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr464").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrS15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr465").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr465").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrS16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr466").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr466").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrS17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr467").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr467").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrS18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr468").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr468").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrS19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr469").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr469").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrS20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr470").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr470").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrS21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr471").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr471").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrS22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr472").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr472").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrS23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr473").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr473").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrS24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr474").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr474").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrS25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr475").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr475").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrT1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr476").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr476").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrT2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr477").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr477").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrT3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr478").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr478").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrT4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr479").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr479").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrT5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr480").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr480").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrT6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr481").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr481").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrT7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr482").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr482").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrT8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr483").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr483").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrT9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr484").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr484").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrT10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr485").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr485").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrT11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr486").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr486").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrT12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr487").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr487").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrT13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr488").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr488").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrT14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr489").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr489").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrT15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr490").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr490").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrT16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr491").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr491").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrT17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr492").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr492").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrT18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr493").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr493").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrT19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr494").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr494").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrT20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr495").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr495").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrT21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr496").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr496").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrT22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr497").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr497").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrT23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr498").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr498").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrT24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr499").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr499").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrT25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr500").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr500").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrU1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr501").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr501").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrU2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr502").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr502").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrU3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr503").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr503").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrU4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr504").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr504").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrU5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr505").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr505").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrU6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr506").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr506").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrU7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr507").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr507").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrU8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr508").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr508").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrU9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr509").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr509").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrU10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr510").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr510").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrU11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr511").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr511").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrU12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr512").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr512").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrU13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr513").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr513").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrU14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr514").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr514").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrU15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr515").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr515").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrU16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr516").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr516").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrU17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr517").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr517").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrU18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr518").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr518").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrU19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr519").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr519").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrU20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr520").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr520").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrU21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr521").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr521").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrU22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr522").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr522").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrU23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr523").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr523").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrU24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr524").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr524").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrU25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr525").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr525").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrV1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr526").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr526").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrV2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr527").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr527").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrV3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr528").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr528").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrV4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr529").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr529").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrV5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr530").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr530").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrV6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr531").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr531").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrV7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr532").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr532").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrV8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr533").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr533").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrV9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr534").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr534").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrV10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr535").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr535").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrV11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr536").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr536").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrV12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr537").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr537").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrV13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr538").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr538").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrV14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr539").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr539").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrV15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr540").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr540").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrV16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr541").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr541").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrV17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr542").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr542").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrV18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr543").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr543").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrV19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr544").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr544").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrV20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr545").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr545").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrV21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr546").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr546").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrV22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr547").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr547").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrV23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr548").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr548").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrV24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr549").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr549").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrV25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr550").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr550").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrW1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr551").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr551").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrW2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr552").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr552").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrW3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr553").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr553").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrW4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr554").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr554").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrW5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr555").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr555").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrW6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr556").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr556").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrW7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr557").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr557").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrW8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr558").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr558").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrW9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr559").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr559").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrW10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr560").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr560").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrW11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr561").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr561").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrW12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr562").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr562").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrW13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr563").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr563").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrW14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr564").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr564").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrW15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr565").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr565").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrW16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr566").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr566").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrW17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr567").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr567").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrW18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr568").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr568").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrW19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr569").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr569").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrW20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr570").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr570").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrW21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr571").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr571").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrW22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr572").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr572").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrW23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr573").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr573").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrW24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr574").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr574").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrW25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr575").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr575").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrX1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr576").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr576").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrX2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr577").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr577").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrX3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr578").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr578").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrX4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr579").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr579").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrX5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr580").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr580").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrX6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr581").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr581").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrX7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr582").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr582").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrX8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr583").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr583").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrX9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr584").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr584").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrX10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr585").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr585").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrX11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr586").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr586").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrX12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr587").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr587").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrX13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr588").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr588").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrX14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr589").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr589").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrX15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr590").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr590").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrX16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr591").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr591").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrX17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr592").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr592").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrX18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr593").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr593").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrX19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr594").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr594").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrX20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr595").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr595").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrX21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr596").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr596").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrX22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr597").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr597").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrX23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr598").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr598").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrX24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr599").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr599").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrX25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr600").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr600").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrY1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr601").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr601").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrY2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr602").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr602").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrY3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr603").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr603").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrY4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr604").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr604").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrY5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr605").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr605").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrY6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr606").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr606").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrY7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr607").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr607").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrY8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr608").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr608").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrY9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr609").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr609").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrY10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr610").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr610").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrY11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr611").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr611").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrY12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr612").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr612").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrY13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr613").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr613").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrY14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr614").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr614").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrY15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr615").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr615").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrY16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr616").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr616").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrY17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr617").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr617").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrY18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr618").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr618").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrY19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr619").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr619").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrY20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr620").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr620").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrY21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr621").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr621").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrY22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr622").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr622").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrY23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr623").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr623").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrY24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr624").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr624").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};
function RasqrY25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr625").src = "https://www.writersjumbler.com/img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr625").src = "https://www.writersjumbler.com/img/sqrs/blSqr.png"
};};};