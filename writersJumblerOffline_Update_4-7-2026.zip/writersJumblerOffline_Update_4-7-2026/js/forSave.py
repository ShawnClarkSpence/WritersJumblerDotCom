a = "function artsquare"
b = "(){"
c = "    var sBQz"
d = """ = document.getElementById("aImgSqr"""
a1 = """").src;"""
b1 = "    valueBSave"
c1 = " = 'zSqrArtSpecz"
d1 = "';"
a2 = "    localStorage.setItem(valueBSave"
a3 = ", sBQz"
a4 = ");"
b2 = "};"
b3 = "function squareBToSzzZValue"
b4 = "(){"
c2 = "    valueBSave"
c5 = " = 'zSqrArtSpecz"
c3 = "';"
c4 = "    var tripleBZeroA = localStorage.getItem(valueBSave"
d2 = ");"
d3 = """"    document.getElementById("imgSqr"""
d4 = """").src = tripleBZeroA;"""
e1 = "};"
e = 1
for e in range(0, 625):
    print(a + str(e) + b + '\n' + c + str(e) + d + str(e+1) + a1 + '\n' + b1 + str(e) +
          c1 + str(e) + d1 + '\n' + a2 + str(e) + a3 + str(e) + a4 + '\n' + b2 + '\n' + b3 + str(e) +
          b4 + '\n' + c2 + str(e) + c5 + str(e) + c3 + '\n' + c4 + str(e) + d2 + '\n' + d3 + str(e+1) +
          d4 + e1 + '\n')
