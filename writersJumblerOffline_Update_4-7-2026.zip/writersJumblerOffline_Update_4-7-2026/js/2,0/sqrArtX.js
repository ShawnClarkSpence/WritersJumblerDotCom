function sqrA1() {
    if(document.getElementById("imgSqr1").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr1").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrA2() {
    if(document.getElementById("imgSqr2").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr2").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrA3() {
    if(document.getElementById("imgSqr3").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr3").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrA4() {
    if(document.getElementById("imgSqr4").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr4").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrA5() {
    if(document.getElementById("imgSqr5").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr5").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrA6() {
    if(document.getElementById("imgSqr6").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr6").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrA7() {
    if(document.getElementById("imgSqr7").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr7").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrA8() {
    if(document.getElementById("imgSqr8").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr8").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrA9() {
    if(document.getElementById("imgSqr9").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr9").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrA10() {
    if(document.getElementById("imgSqr10").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr10").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrA11() {
    if(document.getElementById("imgSqr11").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr11").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrA12() {
    if(document.getElementById("imgSqr12").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr12").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrA13() {
    if(document.getElementById("imgSqr13").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr13").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrA14() {
    if(document.getElementById("imgSqr14").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr14").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrA15() {
    if(document.getElementById("imgSqr15").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr15").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrA16() {
    if(document.getElementById("imgSqr16").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr16").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrA17() {
    if(document.getElementById("imgSqr17").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr17").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrA18() {
    if(document.getElementById("imgSqr18").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr18").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrA19() {
    if(document.getElementById("imgSqr19").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr19").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrA20() {
    if(document.getElementById("imgSqr20").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr20").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrA21() {
    if(document.getElementById("imgSqr21").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr21").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrA22() {
    if(document.getElementById("imgSqr22").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr22").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrA23() {
    if(document.getElementById("imgSqr23").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr23").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrA24() {
    if(document.getElementById("imgSqr24").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr24").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrA25() {
    if(document.getElementById("imgSqr25").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr25").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrB1() {
    if(document.getElementById("imgSqr26").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr26").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrB2() {
    if(document.getElementById("imgSqr27").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr27").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrB3() {
    if(document.getElementById("imgSqr28").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr28").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrB4() {
    if(document.getElementById("imgSqr29").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr29").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrB5() {
    if(document.getElementById("imgSqr30").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr30").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrB6() {
    if(document.getElementById("imgSqr31").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr31").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrB7() {
    if(document.getElementById("imgSqr32").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr32").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrB8() {
    if(document.getElementById("imgSqr33").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr33").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrB9() {
    if(document.getElementById("imgSqr34").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr34").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrB10() {
    if(document.getElementById("imgSqr35").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr35").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrB11() {
    if(document.getElementById("imgSqr36").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr36").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrB12() {
    if(document.getElementById("imgSqr37").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr37").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrB13() {
    if(document.getElementById("imgSqr38").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr38").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrB14() {
    if(document.getElementById("imgSqr39").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr39").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrB15() {
    if(document.getElementById("imgSqr40").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr40").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrB16() {
    if(document.getElementById("imgSqr41").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr41").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrB17() {
    if(document.getElementById("imgSqr42").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr42").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrB18() {
    if(document.getElementById("imgSqr43").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr43").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrB19() {
    if(document.getElementById("imgSqr44").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr44").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrB20() {
    if(document.getElementById("imgSqr45").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr45").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrB21() {
    if(document.getElementById("imgSqr46").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr46").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrB22() {
    if(document.getElementById("imgSqr47").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr47").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrB23() {
    if(document.getElementById("imgSqr48").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr48").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrB24() {
    if(document.getElementById("imgSqr49").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr49").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrB25() {
    if(document.getElementById("imgSqr50").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr50").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrC1() {
    if(document.getElementById("imgSqr51").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr51").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrC2() {
    if(document.getElementById("imgSqr52").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr52").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrC3() {
    if(document.getElementById("imgSqr53").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr53").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrC4() {
    if(document.getElementById("imgSqr54").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr54").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrC5() {
    if(document.getElementById("imgSqr55").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr55").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrC6() {
    if(document.getElementById("imgSqr56").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr56").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrC7() {
    if(document.getElementById("imgSqr57").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr57").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrC8() {
    if(document.getElementById("imgSqr58").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr58").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrC9() {
    if(document.getElementById("imgSqr59").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr59").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrC10() {
    if(document.getElementById("imgSqr60").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr60").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrC11() {
    if(document.getElementById("imgSqr61").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr61").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrC12() {
    if(document.getElementById("imgSqr62").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr62").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrC13() {
    if(document.getElementById("imgSqr63").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr63").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrC14() {
    if(document.getElementById("imgSqr64").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr64").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrC15() {
    if(document.getElementById("imgSqr65").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr65").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrC16() {
    if(document.getElementById("imgSqr66").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr66").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrC17() {
    if(document.getElementById("imgSqr67").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr67").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrC18() {
    if(document.getElementById("imgSqr68").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr68").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrC19() {
    if(document.getElementById("imgSqr69").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr69").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrC20() {
    if(document.getElementById("imgSqr70").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr70").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrC21() {
    if(document.getElementById("imgSqr71").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr71").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrC22() {
    if(document.getElementById("imgSqr72").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr72").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrC23() {
    if(document.getElementById("imgSqr73").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr73").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrC24() {
    if(document.getElementById("imgSqr74").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr74").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrC25() {
    if(document.getElementById("imgSqr75").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr75").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
 };
};

function sqrD1() {
    if(document.getElementById("imgSqr76").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr76").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrD2() {
    if(document.getElementById("imgSqr77").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr77").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrD3() {
    if(document.getElementById("imgSqr78").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr78").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrD4() {
    if(document.getElementById("imgSqr79").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr79").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrD5() {
    if(document.getElementById("imgSqr80").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr80").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrD6() {
    if(document.getElementById("imgSqr81").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr81").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrD7() {
    if(document.getElementById("imgSqr82").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr82").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrD8() {
    if(document.getElementById("imgSqr83").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr83").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrD9() {
    if(document.getElementById("imgSqr84").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr84").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrD10() {
    if(document.getElementById("imgSqr85").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr85").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrD11() {
    if(document.getElementById("imgSqr86").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr86").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrD12() {
    if(document.getElementById("imgSqr87").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr87").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrD13() {
    if(document.getElementById("imgSqr88").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr88").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrD14() {
    if(document.getElementById("imgSqr89").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr89").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrD15() {
    if(document.getElementById("imgSqr90").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr90").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrD16() {
    if(document.getElementById("imgSqr91").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr91").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrD17() {
    if(document.getElementById("imgSqr92").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr92").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrD18() {
    if(document.getElementById("imgSqr93").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr93").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrD19() {
    if(document.getElementById("imgSqr94").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr94").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrD20() {
    if(document.getElementById("imgSqr95").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr95").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrD21() {
    if(document.getElementById("imgSqr96").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr96").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrD22() {
    if(document.getElementById("imgSqr97").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr97").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrD23() {
    if(document.getElementById("imgSqr98").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr98").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrD24() {
    if(document.getElementById("imgSqr99").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr99").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrD25() {
    if(document.getElementById("imgSqr100").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr100").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
 };
};

function sqrE1() {
    if(document.getElementById("imgSqr101").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr101").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrE2() {
    if(document.getElementById("imgSqr102").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr102").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrE3() {
    if(document.getElementById("imgSqr103").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr103").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrE4() {
    if(document.getElementById("imgSqr104").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr104").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrE5() {
    if(document.getElementById("imgSqr105").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr105").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrE6() {
    if(document.getElementById("imgSqr106").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr106").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrE7() {
    if(document.getElementById("imgSqr107").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr107").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrE8() {
    if(document.getElementById("imgSqr108").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr108").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrE9() {
    if(document.getElementById("imgSqr109").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr109").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrE10() {
    if(document.getElementById("imgSqr100").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr110").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrE11() {
    if(document.getElementById("imgSqr111").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr111").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrE12() {
    if(document.getElementById("imgSqr112").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr112").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrE13() {
    if(document.getElementById("imgSqr113").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr113").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrE14() {
    if(document.getElementById("imgSqr114").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr114").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrE15() {
    if(document.getElementById("imgSqr115").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr115").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrE16() {
    if(document.getElementById("imgSqr116").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr116").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrE17() {
    if(document.getElementById("imgSqr117").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr117").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrE18() {
    if(document.getElementById("imgSqr118").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr118").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrE19() {
    if(document.getElementById("imgSqr119").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr119").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrE20() {
    if(document.getElementById("imgSqr120").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr120").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrE21() {
    if(document.getElementById("imgSqr121").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr121").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrE22() {
    if(document.getElementById("imgSqr122").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr122").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrE23() {
    if(document.getElementById("imgSqr123").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr123").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrE24() {
    if(document.getElementById("imgSqr124").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr124").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrE25() {
    if(document.getElementById("imgSqr125").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr125").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
 };
};

function sqrF1() {
    if(document.getElementById("imgSqr126").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr126").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrF2() {
    if(document.getElementById("imgSqr127").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr127").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrF3() {
    if(document.getElementById("imgSqr128").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr128").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrF4() {
    if(document.getElementById("imgSqr129").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr129").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrF5() {
    if(document.getElementById("imgSqr130").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr130").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrF6() {
    if(document.getElementById("imgSqr131").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr131").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrF7() {
    if(document.getElementById("imgSqr132").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr132").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrF8() {
    if(document.getElementById("imgSqr133").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr133").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrF9() {
    if(document.getElementById("imgSqr134").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr134").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrF10() {
    if(document.getElementById("imgSqr135").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr135").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrF11() {
    if(document.getElementById("imgSqr136").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr136").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrF12() {
    if(document.getElementById("imgSqr137").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr137").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrF13() {
    if(document.getElementById("imgSqr138").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr138").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrF14() {
    if(document.getElementById("imgSqr139").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr139").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrF15() {
    if(document.getElementById("imgSqr140").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr140").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrF16() {
    if(document.getElementById("imgSqr141").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr141").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrF17() {
    if(document.getElementById("imgSqr142").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr142").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrF18() {
    if(document.getElementById("imgSqr143").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr143").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrF19() {
    if(document.getElementById("imgSqr144").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr144").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrF20() {
    if(document.getElementById("imgSqr145").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr145").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrF21() {
    if(document.getElementById("imgSqr146").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr146").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrF22() {
    if(document.getElementById("imgSqr147").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr147").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrF23() {
    if(document.getElementById("imgSqr148").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr148").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrF24() {
    if(document.getElementById("imgSqr149").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr149").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrF25() {
    if(document.getElementById("imgSqr150").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr150").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
 };
};

function sqrG1() {
    if(document.getElementById("imgSqr151").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr151").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrG2() {
    if(document.getElementById("imgSqr152").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr152").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrG3() {
    if(document.getElementById("imgSqr153").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr153").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrG4() {
    if(document.getElementById("imgSqr154").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr154").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrG5() {
    if(document.getElementById("imgSqr155").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr155").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrG6() {
    if(document.getElementById("imgSqr156").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr156").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrG7() {
    if(document.getElementById("imgSqr157").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr157").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrG8() {
    if(document.getElementById("imgSqr158").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr158").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrG9() {
    if(document.getElementById("imgSqr159").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr159").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrG10() {
    if(document.getElementById("imgSqr160").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr160").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrG11() {
    if(document.getElementById("imgSqr161").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr161").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrG12() {
    if(document.getElementById("imgSqr162").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr162").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrG13() {
    if(document.getElementById("imgSqr163").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr163").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrG14() {
    if(document.getElementById("imgSqr164").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr164").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrG15() {
    if(document.getElementById("imgSqr165").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr165").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrG16() {
    if(document.getElementById("imgSqr166").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr166").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrG17() {
    if(document.getElementById("imgSqr167").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr167").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrG18() {
    if(document.getElementById("imgSqr168").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr168").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrG19() {
    if(document.getElementById("imgSqr169").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr169").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrG20() {
    if(document.getElementById("imgSqr170").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr170").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrG21() {
    if(document.getElementById("imgSqr171").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr171").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrG22() {
    if(document.getElementById("imgSqr172").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr172").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrG23() {
    if(document.getElementById("imgSqr173").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr173").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrG24() {
    if(document.getElementById("imgSqr174").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr174").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrG25() {
    if(document.getElementById("imgSqr175").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr175").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
 };
};

function sqrH1() {
    if(document.getElementById("imgSqr176").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr176").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrH2() {
    if(document.getElementById("imgSqr177").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr177").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrH3() {
    if(document.getElementById("imgSqr178").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr178").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrH4() {
    if(document.getElementById("imgSqr179").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr179").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrH5() {
    if(document.getElementById("imgSqr180").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr180").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrH6() {
    if(document.getElementById("imgSqr181").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr181").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrH7() {
    if(document.getElementById("imgSqr182").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr182").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrH8() {
    if(document.getElementById("imgSqr183").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr183").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrH9() {
    if(document.getElementById("imgSqr184").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr184").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrH10() {
    if(document.getElementById("imgSqr185").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr185").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrH11() {
    if(document.getElementById("imgSqr186").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr186").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrH12() {
    if(document.getElementById("imgSqr187").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr187").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrH13() {
    if(document.getElementById("imgSqr188").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr188").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrH14() {
    if(document.getElementById("imgSqr189").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr189").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrH15() {
    if(document.getElementById("imgSqr190").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr190").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrH16() {
    if(document.getElementById("imgSqr191").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr191").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrH17() {
    if(document.getElementById("imgSqr192").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr192").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrH18() {
    if(document.getElementById("imgSqr193").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr193").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrH19() {
    if(document.getElementById("imgSqr194").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr194").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrH20() {
    if(document.getElementById("imgSqr195").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr195").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrH21() {
    if(document.getElementById("imgSqr196").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr196").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrH22() {
    if(document.getElementById("imgSqr197").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr197").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrH23() {
    if(document.getElementById("imgSqr198").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr198").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrH24() {
    if(document.getElementById("imgSqr199").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr199").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrH25() {
    if(document.getElementById("imgSqr200").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr200").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
 };
};

function sqrI1() {
    if(document.getElementById("imgSqr201").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr201").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrI2() {
    if(document.getElementById("imgSqr202").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr202").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrI3() {
    if(document.getElementById("imgSqr203").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr203").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrI4() {
    if(document.getElementById("imgSqr204").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr204").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrI5() {
    if(document.getElementById("imgSqr205").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr205").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrI6() {
    if(document.getElementById("imgSqr206").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr206").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrI7() {
    if(document.getElementById("imgSqr207").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr207").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrI8() {
    if(document.getElementById("imgSqr208").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr208").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrI9() {
    if(document.getElementById("imgSqr209").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr209").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrI10() {
    if(document.getElementById("imgSqr210").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr210").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrI11() {
    if(document.getElementById("imgSqr211").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr211").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrI12() {
    if(document.getElementById("imgSqr212").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr212").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrI13() {
    if(document.getElementById("imgSqr213").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr213").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrI14() {
    if(document.getElementById("imgSqr214").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr214").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrI15() {
    if(document.getElementById("imgSqr215").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr215").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrI16() {
    if(document.getElementById("imgSqr216").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr216").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrI17() {
    if(document.getElementById("imgSqr217").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr217").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrI18() {
    if(document.getElementById("imgSqr218").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr218").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrI19() {
    if(document.getElementById("imgSqr219").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr219").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrI20() {
    if(document.getElementById("imgSqr220").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr220").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrI21() {
    if(document.getElementById("imgSqr221").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr221").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrI22() {
    if(document.getElementById("imgSqr222").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr222").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrI23() {
    if(document.getElementById("imgSqr223").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr223").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrI24() {
    if(document.getElementById("imgSqr224").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr224").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrI25() {
    if(document.getElementById("imgSqr225").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr225").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
 };
};

function sqrJ1() {
    if(document.getElementById("imgSqr226").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr226").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrJ2() {
    if(document.getElementById("imgSqr227").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr227").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrJ3() {
    if(document.getElementById("imgSqr228").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr228").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrJ4() {
    if(document.getElementById("imgSqr229").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr229").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrJ5() {
    if(document.getElementById("imgSqr230").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr230").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrJ6() {
    if(document.getElementById("imgSqr231").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr231").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrJ7() {
    if(document.getElementById("imgSqr232").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr232").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrJ8() {
    if(document.getElementById("imgSqr233").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr233").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrJ9() {
    if(document.getElementById("imgSqr234").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr234").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrJ10() {
    if(document.getElementById("imgSqr235").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr235").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrJ11() {
    if(document.getElementById("imgSqr236").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr236").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrJ12() {
    if(document.getElementById("imgSqr237").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr237").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrJ13() {
    if(document.getElementById("imgSqr238").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr238").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrJ14() {
    if(document.getElementById("imgSqr239").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr239").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrJ15() {
    if(document.getElementById("imgSqr240").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr240").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrJ16() {
    if(document.getElementById("imgSqr241").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr241").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrJ17() {
    if(document.getElementById("imgSqr242").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr242").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrJ18() {
    if(document.getElementById("imgSqr243").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr243").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrJ19() {
    if(document.getElementById("imgSqr244").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr244").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrJ20() {
    if(document.getElementById("imgSqr245").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr245").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrJ21() {
    if(document.getElementById("imgSqr246").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr246").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrJ22() {
    if(document.getElementById("imgSqr247").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr247").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrJ23() {
    if(document.getElementById("imgSqr248").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr248").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrJ24() {
    if(document.getElementById("imgSqr249").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr249").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrJ25() {
    if(document.getElementById("imgSqr250").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr250").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
 };
};

function sqrK1() {
    if(document.getElementById("imgSqr251").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr251").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrK2() {
    if(document.getElementById("imgSqr252").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr252").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrK3() {
    if(document.getElementById("imgSqr253").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr253").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrK4() {
    if(document.getElementById("imgSqr254").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr254").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrK5() {
    if(document.getElementById("imgSqr255").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr255").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrK6() {
    if(document.getElementById("imgSqr256").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr256").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrK7() {
    if(document.getElementById("imgSqr257").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr257").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrK8() {
    if(document.getElementById("imgSqr258").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr258").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrK9() {
    if(document.getElementById("imgSqr259").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr259").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrK10() {
    if(document.getElementById("imgSqr260").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr260").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrK11() {
    if(document.getElementById("imgSqr261").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr261").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrK12() {
    if(document.getElementById("imgSqr262").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr262").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrK13() {
    if(document.getElementById("imgSqr263").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr263").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrK14() {
    if(document.getElementById("imgSqr264").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr264").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrK15() {
    if(document.getElementById("imgSqr265").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr265").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrK16() {
    if(document.getElementById("imgSqr266").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr266").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrK17() {
    if(document.getElementById("imgSqr267").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr267").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrK18() {
    if(document.getElementById("imgSqr268").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr268").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrK19() {
    if(document.getElementById("imgSqr269").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr269").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrK20() {
    if(document.getElementById("imgSqr270").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr270").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrK21() {
    if(document.getElementById("imgSqr271").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr271").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrK22() {
    if(document.getElementById("imgSqr272").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr272").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrK23() {
    if(document.getElementById("imgSqr273").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr273").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrK24() {
    if(document.getElementById("imgSqr274").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr274").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrK25() {
    if(document.getElementById("imgSqr275").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr275").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
 };
};

function sqrL1() {
    if(document.getElementById("imgSqr276").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr276").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrL2() {
    if(document.getElementById("imgSqr277").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr277").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrL3() {
    if(document.getElementById("imgSqr278").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr278").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrL4() {
    if(document.getElementById("imgSqr279").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr279").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrL5() {
    if(document.getElementById("imgSqr280").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr280").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrL6() {
    if(document.getElementById("imgSqr281").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr281").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrL7() {
    if(document.getElementById("imgSqr282").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr282").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrL8() {
    if(document.getElementById("imgSqr283").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr283").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrL9() {
    if(document.getElementById("imgSqr284").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr284").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrL10() {
    if(document.getElementById("imgSqr285").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr285").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrL11() {
    if(document.getElementById("imgSqr286").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr286").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrL12() {
    if(document.getElementById("imgSqr287").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr287").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrL13() {
    if(document.getElementById("imgSqr288").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr288").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrL14() {
    if(document.getElementById("imgSqr289").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr289").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrL15() {
    if(document.getElementById("imgSqr290").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr290").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrL16() {
    if(document.getElementById("imgSqr291").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr291").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrL17() {
    if(document.getElementById("imgSqr292").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr292").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrL18() {
    if(document.getElementById("imgSqr293").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr293").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrL19() {
    if(document.getElementById("imgSqr294").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr294").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrL20() {
    if(document.getElementById("imgSqr295").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr295").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrL21() {
    if(document.getElementById("imgSqr296").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr296").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrL22() {
    if(document.getElementById("imgSqr297").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr297").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrL23() {
    if(document.getElementById("imgSqr298").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr298").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrL24() {
    if(document.getElementById("imgSqr299").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr299").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrL25() {
    if(document.getElementById("imgSqr300").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr300").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
 };
};

function sqrM1() {
    if(document.getElementById("imgSqr301").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr301").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrM2() {
    if(document.getElementById("imgSqr302").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr302").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrM3() {
    if(document.getElementById("imgSqr303").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr303").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrM4() {
    if(document.getElementById("imgSqr304").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr304").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrM5() {
    if(document.getElementById("imgSqr305").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr305").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrM6() {
    if(document.getElementById("imgSqr306").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr306").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrM7() {
    if(document.getElementById("imgSqr307").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr307").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrM8() {
    if(document.getElementById("imgSqr308").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr308").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrM9() {
    if(document.getElementById("imgSqr309").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr309").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrM10() {
    if(document.getElementById("imgSqr310").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr310").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrM11() {
    if(document.getElementById("imgSqr311").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr311").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrM12() {
    if(document.getElementById("imgSqr312").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr312").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrM13() {
    if(document.getElementById("imgSqr313").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr313").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrM14() {
    if(document.getElementById("imgSqr314").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr314").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrM15() {
    if(document.getElementById("imgSqr315").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr315").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrM16() {
    if(document.getElementById("imgSqr316").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr316").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrM17() {
    if(document.getElementById("imgSqr317").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr317").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrM18() {
    if(document.getElementById("imgSqr318").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr318").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrM19() {
    if(document.getElementById("imgSqr319").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr319").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrM20() {
    if(document.getElementById("imgSqr320").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr320").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrM21() {
    if(document.getElementById("imgSqr321").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr321").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrM22() {
    if(document.getElementById("imgSqr322").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr322").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrM23() {
    if(document.getElementById("imgSqr323").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr323").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrM24() {
    if(document.getElementById("imgSqr324").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr324").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrM25() {
    if(document.getElementById("imgSqr325").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr325").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
 };
};

function sqrN1() {
    if(document.getElementById("imgSqr326").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr326").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrN2() {
    if(document.getElementById("imgSqr327").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr327").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrN3() {
    if(document.getElementById("imgSqr328").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr328").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrN4() {
    if(document.getElementById("imgSqr329").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr329").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrN5() {
    if(document.getElementById("imgSqr330").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr330").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrN6() {
    if(document.getElementById("imgSqr331").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr331").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrN7() {
    if(document.getElementById("imgSqr332").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr332").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrN8() {
    if(document.getElementById("imgSqr333").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr333").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrN9() {
    if(document.getElementById("imgSqr334").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr334").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrN10() {
    if(document.getElementById("imgSqr335").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr335").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrN11() {
    if(document.getElementById("imgSqr336").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr336").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrN12() {
    if(document.getElementById("imgSqr337").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr337").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrN13() {
    if(document.getElementById("imgSqr338").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr338").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrN14() {
    if(document.getElementById("imgSqr339").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr339").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrN15() {
    if(document.getElementById("imgSqr340").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr340").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrN16() {
    if(document.getElementById("imgSqr341").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr341").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrN17() {
    if(document.getElementById("imgSqr342").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr342").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrN18() {
    if(document.getElementById("imgSqr343").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr343").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrN19() {
    if(document.getElementById("imgSqr344").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr344").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrN20() {
    if(document.getElementById("imgSqr345").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr345").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrN21() {
    if(document.getElementById("imgSqr346").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr346").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrN22() {
    if(document.getElementById("imgSqr347").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr347").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrN23() {
    if(document.getElementById("imgSqr348").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr348").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrN24() {
    if(document.getElementById("imgSqr349").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr349").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrN25() {
    if(document.getElementById("imgSqr350").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr350").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
 };
};

function sqrO1() {
    if(document.getElementById("imgSqr351").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr351").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrO2() {
    if(document.getElementById("imgSqr352").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr352").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrO3() {
    if(document.getElementById("imgSqr353").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr353").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrO4() {
    if(document.getElementById("imgSqr354").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr354").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrO5() {
    if(document.getElementById("imgSqr355").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr355").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrO6() {
    if(document.getElementById("imgSqr356").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr356").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrO7() {
    if(document.getElementById("imgSqr357").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr357").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrO8() {
    if(document.getElementById("imgSqr358").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr358").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrO9() {
    if(document.getElementById("imgSqr359").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr359").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrO10() {
    if(document.getElementById("imgSqr360").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr360").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrO11() {
    if(document.getElementById("imgSqr361").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr361").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrO12() {
    if(document.getElementById("imgSqr362").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr362").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrO13() {
    if(document.getElementById("imgSqr363").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr363").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrO14() {
    if(document.getElementById("imgSqr364").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr364").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrO15() {
    if(document.getElementById("imgSqr365").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr365").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrO16() {
    if(document.getElementById("imgSqr366").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr366").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrO17() {
    if(document.getElementById("imgSqr367").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr367").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrO18() {
    if(document.getElementById("imgSqr368").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr368").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrO19() {
    if(document.getElementById("imgSqr369").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr369").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrO20() {
    if(document.getElementById("imgSqr370").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr370").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrO21() {
    if(document.getElementById("imgSqr371").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr371").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrO22() {
    if(document.getElementById("imgSqr372").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr372").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrO23() {
    if(document.getElementById("imgSqr373").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr373").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrO24() {
    if(document.getElementById("imgSqr374").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr374").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrO25() {
    if(document.getElementById("imgSqr375").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr375").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
 };
};

function sqrP1() {
    if(document.getElementById("imgSqr376").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr376").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrP2() {
    if(document.getElementById("imgSqr377").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr377").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrP3() {
    if(document.getElementById("imgSqr378").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr378").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrP4() {
    if(document.getElementById("imgSqr379").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr379").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrP5() {
    if(document.getElementById("imgSqr380").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr380").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrP6() {
    if(document.getElementById("imgSqr381").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr381").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrP7() {
    if(document.getElementById("imgSqr382").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr382").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrP8() {
    if(document.getElementById("imgSqr383").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr383").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrP9() {
    if(document.getElementById("imgSqr384").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr384").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrP10() {
    if(document.getElementById("imgSqr385").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr385").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrP11() {
    if(document.getElementById("imgSqr386").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr386").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrP12() {
    if(document.getElementById("imgSqr387").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr387").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrP13() {
    if(document.getElementById("imgSqr388").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr388").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrP14() {
    if(document.getElementById("imgSqr389").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr389").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrP15() {
    if(document.getElementById("imgSqr390").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr390").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrP16() {
    if(document.getElementById("imgSqr391").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr391").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrP17() {
    if(document.getElementById("imgSqr392").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr392").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrP18() {
    if(document.getElementById("imgSqr393").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr393").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrP19() {
    if(document.getElementById("imgSqr394").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr394").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrP20() {
    if(document.getElementById("imgSqr395").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr395").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrP21() {
    if(document.getElementById("imgSqr396").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr396").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrP22() {
    if(document.getElementById("imgSqr397").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr397").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrP23() {
    if(document.getElementById("imgSqr398").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr398").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrP24() {
    if(document.getElementById("imgSqr399").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr399").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrP25() {
    if(document.getElementById("imgSqr400").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr400").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
 };
};

function sqrQ1() {
    if(document.getElementById("imgSqr401").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr401").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQ2() {
    if(document.getElementById("imgSqr402").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr402").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQ3() {
    if(document.getElementById("imgSqr403").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr403").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQ4() {
    if(document.getElementById("imgSqr404").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr404").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQ5() {
    if(document.getElementById("imgSqr405").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr405").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQ6() {
    if(document.getElementById("imgSqr406").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr406").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQ7() {
    if(document.getElementById("imgSqr407").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr407").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQ8() {
    if(document.getElementById("imgSqr408").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr408").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQ9() {
    if(document.getElementById("imgSqr409").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr409").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQ10() {
    if(document.getElementById("imgSqr410").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr410").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQ11() {
    if(document.getElementById("imgSqr411").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr411").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQ12() {
    if(document.getElementById("imgSqr412").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr412").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQ13() {
    if(document.getElementById("imgSqr413").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr413").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQ14() {
    if(document.getElementById("imgSqr414").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr414").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQ15() {
    if(document.getElementById("imgSqr415").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr415").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQ16() {
    if(document.getElementById("imgSqr416").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr416").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQ17() {
    if(document.getElementById("imgSqr417").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr417").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQ18() {
    if(document.getElementById("imgSqr418").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr418").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQ19() {
    if(document.getElementById("imgSqr419").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr419").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQ20() {
    if(document.getElementById("imgSqr420").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr420").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQ21() {
    if(document.getElementById("imgSqr421").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr421").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQ22() {
    if(document.getElementById("imgSqr422").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr422").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQ23() {
    if(document.getElementById("imgSqr423").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr423").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQ24() {
    if(document.getElementById("imgSqr424").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr424").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQ25() {
    if(document.getElementById("imgSqr425").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr425").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
 };
};

function sqrR1() {
    if(document.getElementById("imgSqr426").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr426").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrR2() {
    if(document.getElementById("imgSqr427").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr427").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrR3() {
    if(document.getElementById("imgSqr428").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr428").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrR4() {
    if(document.getElementById("imgSqr429").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr429").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrR5() {
    if(document.getElementById("imgSqr430").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr430").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrR6() {
    if(document.getElementById("imgSqr431").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr431").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrR7() {
    if(document.getElementById("imgSqr432").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr432").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrR8() {
    if(document.getElementById("imgSqr433").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr433").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrR9() {
    if(document.getElementById("imgSqr434").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr434").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrR10() {
    if(document.getElementById("imgSqr435").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr435").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrR11() {
    if(document.getElementById("imgSqr436").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr436").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrR12() {
    if(document.getElementById("imgSqr437").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr437").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrR13() {
    if(document.getElementById("imgSqr438").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr438").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrR14() {
    if(document.getElementById("imgSqr439").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr439").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrR15() {
    if(document.getElementById("imgSqr440").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr440").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrR16() {
    if(document.getElementById("imgSqr441").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr441").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrR17() {
    if(document.getElementById("imgSqr442").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr442").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrR18() {
    if(document.getElementById("imgSqr443").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr443").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrR19() {
    if(document.getElementById("imgSqr444").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr444").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrR20() {
    if(document.getElementById("imgSqr445").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr445").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrR21() {
    if(document.getElementById("imgSqr446").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr446").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrR22() {
    if(document.getElementById("imgSqr447").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr447").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrR23() {
    if(document.getElementById("imgSqr448").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr448").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrR24() {
    if(document.getElementById("imgSqr449").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr449").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrR25() {
    if(document.getElementById("imgSqr450").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr450").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
 };
};

function sqrS1() {
    if(document.getElementById("imgSqr451").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr451").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrS2() {
    if(document.getElementById("imgSqr452").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr452").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrS3() {
    if(document.getElementById("imgSqr453").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr453").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrS4() {
    if(document.getElementById("imgSqr454").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr454").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrS5() {
    if(document.getElementById("imgSqr455").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr455").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrS6() {
    if(document.getElementById("imgSqr456").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr456").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrS7() {
    if(document.getElementById("imgSqr457").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr457").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrS8() {
    if(document.getElementById("imgSqr458").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr458").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrS9() {
    if(document.getElementById("imgSqr459").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr459").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrS10() {
    if(document.getElementById("imgSqr460").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr460").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrS11() {
    if(document.getElementById("imgSqr461").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr461").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrS12() {
    if(document.getElementById("imgSqr462").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr462").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrS13() {
    if(document.getElementById("imgSqr463").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr463").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrS14() {
    if(document.getElementById("imgSqr464").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr464").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrS15() {
    if(document.getElementById("imgSqr465").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr465").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrS16() {
    if(document.getElementById("imgSqr466").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr466").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrS17() {
    if(document.getElementById("imgSqr467").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr467").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrS18() {
    if(document.getElementById("imgSqr468").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr468").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrS19() {
    if(document.getElementById("imgSqr469").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr469").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrS20() {
    if(document.getElementById("imgSqr470").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr470").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrS21() {
    if(document.getElementById("imgSqr471").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr471").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrS22() {
    if(document.getElementById("imgSqr472").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr472").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrS23() {
    if(document.getElementById("imgSqr473").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr473").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrS24() {
    if(document.getElementById("imgSqr474").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr474").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrS25() {
    if(document.getElementById("imgSqr475").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr475").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
 };
};

function sqrT1() {
    if(document.getElementById("imgSqr476").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr476").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrT2() {
    if(document.getElementById("imgSqr477").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr477").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrT3() {
    if(document.getElementById("imgSqr478").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr478").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrT4() {
    if(document.getElementById("imgSqr479").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr479").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrT5() {
    if(document.getElementById("imgSqr480").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr480").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrT6() {
    if(document.getElementById("imgSqr481").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr481").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrT7() {
    if(document.getElementById("imgSqr482").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr482").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrT8() {
    if(document.getElementById("imgSqr483").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr483").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrT9() {
    if(document.getElementById("imgSqr484").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr484").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrT10() {
    if(document.getElementById("imgSqr485").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr485").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrT11() {
    if(document.getElementById("imgSqr486").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr486").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrT12() {
    if(document.getElementById("imgSqr487").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr487").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrT13() {
    if(document.getElementById("imgSqr488").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr488").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrT14() {
    if(document.getElementById("imgSqr489").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr489").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrT15() {
    if(document.getElementById("imgSqr490").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr490").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrT16() {
    if(document.getElementById("imgSqr491").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr491").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrT17() {
    if(document.getElementById("imgSqr492").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr492").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrT18() {
    if(document.getElementById("imgSqr493").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr493").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrT19() {
    if(document.getElementById("imgSqr494").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr494").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrT20() {
    if(document.getElementById("imgSqr495").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr495").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrT21() {
    if(document.getElementById("imgSqr496").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr496").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrT22() {
    if(document.getElementById("imgSqr497").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr497").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrT23() {
    if(document.getElementById("imgSqr498").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr498").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrT24() {
    if(document.getElementById("imgSqr499").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr499").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrT25() {
    if(document.getElementById("imgSqr500").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr500").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
 };
};

function sqrU1() {
    if(document.getElementById("imgSqr501").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr501").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrU2() {
    if(document.getElementById("imgSqr502").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr502").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrU3() {
    if(document.getElementById("imgSqr503").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr503").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrU4() {
    if(document.getElementById("imgSqr504").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr504").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrU5() {
    if(document.getElementById("imgSqr505").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr505").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrU6() {
    if(document.getElementById("imgSqr506").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr506").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrU7() {
    if(document.getElementById("imgSqr507").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr507").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrU8() {
    if(document.getElementById("imgSqr508").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr508").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrU9() {
    if(document.getElementById("imgSqr509").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr509").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrU10() {
    if(document.getElementById("imgSqr510").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr510").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrU11() {
    if(document.getElementById("imgSqr511").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr511").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrU12() {
    if(document.getElementById("imgSqr512").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr512").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrU13() {
    if(document.getElementById("imgSqr513").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr513").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrU14() {
    if(document.getElementById("imgSqr514").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr514").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrU15() {
    if(document.getElementById("imgSqr515").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr515").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrU16() {
    if(document.getElementById("imgSqr516").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr516").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrU17() {
    if(document.getElementById("imgSqr517").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr517").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrU18() {
    if(document.getElementById("imgSqr518").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr518").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrU19() {
    if(document.getElementById("imgSqr519").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr519").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrU20() {
    if(document.getElementById("imgSqr520").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr520").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrU21() {
    if(document.getElementById("imgSqr521").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr521").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrU22() {
    if(document.getElementById("imgSqr522").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr522").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrU23() {
    if(document.getElementById("imgSqr523").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr523").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrU24() {
    if(document.getElementById("imgSqr524").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr524").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrU25() {
    if(document.getElementById("imgSqr525").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr525").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
 };
};

function sqrV1() {
    if(document.getElementById("imgSqr526").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr526").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrV2() {
    if(document.getElementById("imgSqr527").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr527").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrV3() {
    if(document.getElementById("imgSqr528").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr528").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrV4() {
    if(document.getElementById("imgSqr529").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr529").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrV5() {
    if(document.getElementById("imgSqr530").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr530").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrV6() {
    if(document.getElementById("imgSqr531").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr531").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrV7() {
    if(document.getElementById("imgSqr532").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr532").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrV8() {
    if(document.getElementById("imgSqr533").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr533").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrV9() {
    if(document.getElementById("imgSqr534").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr534").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrV10() {
    if(document.getElementById("imgSqr535").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr535").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrV11() {
    if(document.getElementById("imgSqr536").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr536").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrV12() {
    if(document.getElementById("imgSqr537").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr537").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrV13() {
    if(document.getElementById("imgSqr538").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr538").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrV14() {
    if(document.getElementById("imgSqr539").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr539").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrV15() {
    if(document.getElementById("imgSqr540").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr540").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrV16() {
    if(document.getElementById("imgSqr541").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr541").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrV17() {
    if(document.getElementById("imgSqr542").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr542").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrV18() {
    if(document.getElementById("imgSqr543").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr543").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrV19() {
    if(document.getElementById("imgSqr544").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr544").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrV20() {
    if(document.getElementById("imgSqr545").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr545").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrV21() {
    if(document.getElementById("imgSqr546").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr546").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrV22() {
    if(document.getElementById("imgSqr547").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr547").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrV23() {
    if(document.getElementById("imgSqr548").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr548").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrV24() {
    if(document.getElementById("imgSqr549").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr549").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrV25() {
    if(document.getElementById("imgSqr550").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr550").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
 };
};

function sqrW1() {
    if(document.getElementById("imgSqr551").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr551").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrW2() {
    if(document.getElementById("imgSqr552").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr552").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrW3() {
    if(document.getElementById("imgSqr553").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr553").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrW4() {
    if(document.getElementById("imgSqr554").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr554").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrW5() {
    if(document.getElementById("imgSqr555").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr555").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrW6() {
    if(document.getElementById("imgSqr556").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr556").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrW7() {
    if(document.getElementById("imgSqr557").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr557").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrW8() {
    if(document.getElementById("imgSqr558").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr558").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrW9() {
    if(document.getElementById("imgSqr559").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr559").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrW10() {
    if(document.getElementById("imgSqr560").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr560").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrW11() {
    if(document.getElementById("imgSqr561").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr561").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrW12() {
    if(document.getElementById("imgSqr562").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr562").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrW13() {
    if(document.getElementById("imgSqr563").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr563").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrW14() {
    if(document.getElementById("imgSqr564").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr564").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrW15() {
    if(document.getElementById("imgSqr565").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr565").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrW16() {
    if(document.getElementById("imgSqr566").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr566").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrW17() {
    if(document.getElementById("imgSqr567").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr567").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrW18() {
    if(document.getElementById("imgSqr568").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr568").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrW19() {
    if(document.getElementById("imgSqr569").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr569").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrW20() {
    if(document.getElementById("imgSqr570").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr570").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrW21() {
    if(document.getElementById("imgSqr571").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr571").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrW22() {
    if(document.getElementById("imgSqr572").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr572").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrW23() {
    if(document.getElementById("imgSqr573").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr573").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrW24() {
    if(document.getElementById("imgSqr574").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr574").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrW25() {
    if(document.getElementById("imgSqr575").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr575").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
 };
};

function sqrX1() {
    if(document.getElementById("imgSqr576").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr576").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrX2() {
    if(document.getElementById("imgSqr577").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr577").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrX3() {
    if(document.getElementById("imgSqr578").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr578").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrX4() {
    if(document.getElementById("imgSqr579").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr579").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrX5() {
    if(document.getElementById("imgSqr580").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr580").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrX6() {
    if(document.getElementById("imgSqr581").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr581").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrX7() {
    if(document.getElementById("imgSqr582").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr582").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrX8() {
    if(document.getElementById("imgSqr583").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr583").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrX9() {
    if(document.getElementById("imgSqr584").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr584").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrX10() {
    if(document.getElementById("imgSqr585").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr585").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrX11() {
    if(document.getElementById("imgSqr586").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr586").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrX12() {
    if(document.getElementById("imgSqr587").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr587").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrX13() {
    if(document.getElementById("imgSqr588").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr588").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrX14() {
    if(document.getElementById("imgSqr589").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr589").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrX15() {
    if(document.getElementById("imgSqr590").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr590").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrX16() {
    if(document.getElementById("imgSqr591").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr591").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrX17() {
    if(document.getElementById("imgSqr592").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr592").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrX18() {
    if(document.getElementById("imgSqr593").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr593").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrX19() {
    if(document.getElementById("imgSqr594").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr594").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrX20() {
    if(document.getElementById("imgSqr595").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr595").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrX21() {
    if(document.getElementById("imgSqr596").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr596").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrX22() {
    if(document.getElementById("imgSqr597").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr597").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrX23() {
    if(document.getElementById("imgSqr598").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr598").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrX24() {
    if(document.getElementById("imgSqr599").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr599").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrX25() {
    if(document.getElementById("imgSqr600").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr600").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
 };
};

function sqrY1() {
    if(document.getElementById("imgSqr601").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr601").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrY2() {
    if(document.getElementById("imgSqr602").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr602").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrY3() {
    if(document.getElementById("imgSqr603").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr603").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrY4() {
    if(document.getElementById("imgSqr604").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr604").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrY5() {
    if(document.getElementById("imgSqr605").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr605").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrY6() {
    if(document.getElementById("imgSqr606").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr606").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrY7() {
    if(document.getElementById("imgSqr607").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr607").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrY8() {
    if(document.getElementById("imgSqr608").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr608").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrY9() {
    if(document.getElementById("imgSqr609").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr609").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrY10() {
    if(document.getElementById("imgSqr610").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr610").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrY11() {
    if(document.getElementById("imgSqr611").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr611").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrY12() {
    if(document.getElementById("imgSqr612").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr612").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrY13() {
    if(document.getElementById("imgSqr613").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr613").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrY14() {
    if(document.getElementById("imgSqr614").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr614").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrY15() {
    if(document.getElementById("imgSqr615").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr615").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrY16() {
    if(document.getElementById("imgSqr616").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr616").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrY17() {
    if(document.getElementById("imgSqr617").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr617").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrY18() {
    if(document.getElementById("imgSqr618").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr618").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrY19() {
    if(document.getElementById("imgSqr619").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr619").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrY20() {
    if(document.getElementById("imgSqr620").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr620").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrY21() {
    if(document.getElementById("imgSqr621").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr621").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrY22() {
    if(document.getElementById("imgSqr622").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr622").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrY23() {
    if(document.getElementById("imgSqr623").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr623").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrY24() {
    if(document.getElementById("imgSqr624").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr624").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrY25() {
    if(document.getElementById("imgSqr625").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr625").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrA1b() {
    if(document.getElementById("imgSqr1").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr1").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrA2b() {
    if(document.getElementById("imgSqr2").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr2").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrA3b() {
    if(document.getElementById("imgSqr3").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr3").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrA4b() {
    if(document.getElementById("imgSqr4").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr4").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrA5b() {
    if(document.getElementById("imgSqr5").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr5").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrA6b() {
    if(document.getElementById("imgSqr6").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr6").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrA7b() {
    if(document.getElementById("imgSqr7").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr7").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrA8b() {
    if(document.getElementById("imgSqr8").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr8").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrA9b() {
    if(document.getElementById("imgSqr9").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr9").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrA10b() {
    if(document.getElementById("imgSqr10").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr10").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrA11b() {
    if(document.getElementById("imgSqr11").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr11").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrA12b() {
    if(document.getElementById("imgSqr12").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr12").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrA13b() {
    if(document.getElementById("imgSqr13").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr13").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrA14b() {
    if(document.getElementById("imgSqr14").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr14").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrA15b() {
    if(document.getElementById("imgSqr15").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr15").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrA16b() {
    if(document.getElementById("imgSqr16").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr16").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrA17b() {
    if(document.getElementById("imgSqr17").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr17").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrA18b() {
    if(document.getElementById("imgSqr18").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr18").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrA19b() {
    if(document.getElementById("imgSqr19").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr19").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrA20b() {
    if(document.getElementById("imgSqr20").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr20").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrA21b() {
    if(document.getElementById("imgSqr21").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr21").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrA22b() {
    if(document.getElementById("imgSqr22").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr22").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrA23b() {
    if(document.getElementById("imgSqr23").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr23").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrA24b() {
    if(document.getElementById("imgSqr24").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr24").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrA25b() {
    if(document.getElementById("imgSqr25").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr25").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
 };
};

function sqrB1b() {
    if(document.getElementById("imgSqr26").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr26").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrB2b() {
    if(document.getElementById("imgSqr27").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr27").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrB3b() {
    if(document.getElementById("imgSqr28").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr28").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrB4b() {
    if(document.getElementById("imgSqr29").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr29").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrB5b() {
    if(document.getElementById("imgSqr30").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr30").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrB6b() {
    if(document.getElementById("imgSqr31").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr31").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrB7b() {
    if(document.getElementById("imgSqr32").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr32").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrB8b() {
    if(document.getElementById("imgSqr33").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr33").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrB9b() {
    if(document.getElementById("imgSqr34").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr34").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrB10b() {
    if(document.getElementById("imgSqr35").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr35").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrB11b() {
    if(document.getElementById("imgSqr36").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr36").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrB12b() {
    if(document.getElementById("imgSqr37").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr37").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrB13b() {
    if(document.getElementById("imgSqr38").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr38").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrB14b() {
    if(document.getElementById("imgSqr39").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr39").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrB15b() {
    if(document.getElementById("imgSqr40").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr40").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrB16b() {
    if(document.getElementById("imgSqr41").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr41").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrB17b() {
    if(document.getElementById("imgSqr42").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr42").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrB18b() {
    if(document.getElementById("imgSqr43").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr43").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrB19b() {
    if(document.getElementById("imgSqr44").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr44").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrB20b() {
    if(document.getElementById("imgSqr45").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr45").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrB21b() {
    if(document.getElementById("imgSqr46").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr46").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrB22b() {
    if(document.getElementById("imgSqr47").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr47").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrB23b() {
    if(document.getElementById("imgSqr48").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr48").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrB24b() {
    if(document.getElementById("imgSqr49").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr49").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrB25b() {
    if(document.getElementById("imgSqr50").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr50").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrC1b() {
    if(document.getElementById("imgSqr51").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr51").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrC2b() {
    if(document.getElementById("imgSqr52").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr52").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrC3b() {
    if(document.getElementById("imgSqr53").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr53").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrC4b() {
    if(document.getElementById("imgSqr54").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr54").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrC5b() {
    if(document.getElementById("imgSqr55").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr55").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrC6b() {
    if(document.getElementById("imgSqr56").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr56").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrC7b() {
    if(document.getElementById("imgSqr57").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr57").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrC8b() {
    if(document.getElementById("imgSqr58").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr58").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrC9b() {
    if(document.getElementById("imgSqr59").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr59").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrC10b() {
    if(document.getElementById("imgSqr60").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr60").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrC11b() {
    if(document.getElementById("imgSqr61").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr61").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrC12b() {
    if(document.getElementById("imgSqr62").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr62").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrC13b() {
    if(document.getElementById("imgSqr63").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr63").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrC14b() {
    if(document.getElementById("imgSqr64").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr64").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrC15b() {
    if(document.getElementById("imgSqr65").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr65").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrC16b() {
    if(document.getElementById("imgSqr66").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr66").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrC17b() {
    if(document.getElementById("imgSqr67").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr67").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrC18b() {
    if(document.getElementById("imgSqr68").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr68").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrC19b() {
    if(document.getElementById("imgSqr69").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr69").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrC20b() {
    if(document.getElementById("imgSqr70").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr70").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrC21b() {
    if(document.getElementById("imgSqr71").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr71").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrC22b() {
    if(document.getElementById("imgSqr72").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr72").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrC23b() {
    if(document.getElementById("imgSqr73").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr73").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrC24b() {
    if(document.getElementById("imgSqr74").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr74").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrC25b() {
    if(document.getElementById("imgSqr75").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr75").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
 };
};

function sqrD1b() {
    if(document.getElementById("imgSqr76").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr76").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrD2b() {
    if(document.getElementById("imgSqr77").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr77").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrD3b() {
    if(document.getElementById("imgSqr78").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr78").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrD4b() {
    if(document.getElementById("imgSqr79").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr79").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrD5b() {
    if(document.getElementById("imgSqr80").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr80").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrD6b() {
    if(document.getElementById("imgSqr81").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr81").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrD7b() {
    if(document.getElementById("imgSqr82").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr82").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrD8b() {
    if(document.getElementById("imgSqr83").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr83").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrD9b() {
    if(document.getElementById("imgSqr84").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr84").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrD10b() {
    if(document.getElementById("imgSqr85").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr85").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrD11b() {
    if(document.getElementById("imgSqr86").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr86").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrD12b() {
    if(document.getElementById("imgSqr87").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr87").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrD13b() {
    if(document.getElementById("imgSqr88").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr88").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrD14b() {
    if(document.getElementById("imgSqr89").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr89").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrD15b() {
    if(document.getElementById("imgSqr90").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr90").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrD16b() {
    if(document.getElementById("imgSqr91").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr91").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrD17b() {
    if(document.getElementById("imgSqr92").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr92").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrD18b() {
    if(document.getElementById("imgSqr93").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr93").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrD19b() {
    if(document.getElementById("imgSqr94").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr94").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrD20b() {
    if(document.getElementById("imgSqr95").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr95").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrD21b() {
    if(document.getElementById("imgSqr96").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr96").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrD22b() {
    if(document.getElementById("imgSqr97").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr97").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrD23b() {
    if(document.getElementById("imgSqr98").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr98").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrD24b() {
    if(document.getElementById("imgSqr99").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr99").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrD25b() {
    if(document.getElementById("imgSqr100").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr100").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
 };
};

function sqrE1b() {
    if(document.getElementById("imgSqr101").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr101").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrE2b() {
    if(document.getElementById("imgSqr102").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr102").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrE3b() {
    if(document.getElementById("imgSqr103").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr103").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrE4b() {
    if(document.getElementById("imgSqr104").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr104").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrE5b() {
    if(document.getElementById("imgSqr105").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr105").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrE6b() {
    if(document.getElementById("imgSqr106").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr106").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrE7b() {
    if(document.getElementById("imgSqr107").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr107").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrE8b() {
    if(document.getElementById("imgSqr108").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr108").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrE9b() {
    if(document.getElementById("imgSqr109").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr109").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrE10b() {
    if(document.getElementById("imgSqr100").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr110").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrE11b() {
    if(document.getElementById("imgSqr111").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr111").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrE12b() {
    if(document.getElementById("imgSqr112").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr112").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrE13b() {
    if(document.getElementById("imgSqr113").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr113").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrE14b() {
    if(document.getElementById("imgSqr114").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr114").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrE15b() {
    if(document.getElementById("imgSqr115").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr115").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrE16b() {
    if(document.getElementById("imgSqr116").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr116").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrE17b() {
    if(document.getElementById("imgSqr117").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr117").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrE18b() {
    if(document.getElementById("imgSqr118").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr118").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrE19b() {
    if(document.getElementById("imgSqr119").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr119").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrE20b() {
    if(document.getElementById("imgSqr120").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr120").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrE21b() {
    if(document.getElementById("imgSqr121").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr121").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrE22b() {
    if(document.getElementById("imgSqr122").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr122").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrE23b() {
    if(document.getElementById("imgSqr123").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr123").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrE24b() {
    if(document.getElementById("imgSqr124").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr124").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrE25b() {
    if(document.getElementById("imgSqr125").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr125").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
 };
};

function sqrF1b() {
    if(document.getElementById("imgSqr126").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr126").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrF2b() {
    if(document.getElementById("imgSqr127").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr127").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrF3b() {
    if(document.getElementById("imgSqr128").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr128").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrF4b() {
    if(document.getElementById("imgSqr129").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr129").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrF5b() {
    if(document.getElementById("imgSqr130").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr130").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrF6b() {
    if(document.getElementById("imgSqr131").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr131").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrF7b() {
    if(document.getElementById("imgSqr132").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr132").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrF8b() {
    if(document.getElementById("imgSqr133").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr133").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrF9b() {
    if(document.getElementById("imgSqr134").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr134").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrF10b() {
    if(document.getElementById("imgSqr135").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr135").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrF11b() {
    if(document.getElementById("imgSqr136").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr136").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrF12b() {
    if(document.getElementById("imgSqr137").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr137").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrF13b() {
    if(document.getElementById("imgSqr138").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr138").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrF14b() {
    if(document.getElementById("imgSqr139").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr139").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrF15b() {
    if(document.getElementById("imgSqr140").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr140").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrF16b() {
    if(document.getElementById("imgSqr141").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr141").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrF17b() {
    if(document.getElementById("imgSqr142").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr142").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrF18b() {
    if(document.getElementById("imgSqr143").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr143").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrF19b() {
    if(document.getElementById("imgSqr144").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr144").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrF20b() {
    if(document.getElementById("imgSqr145").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr145").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrF21b() {
    if(document.getElementById("imgSqr146").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr146").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrF22b() {
    if(document.getElementById("imgSqr147").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr147").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrF23b() {
    if(document.getElementById("imgSqr148").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr148").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrF24b() {
    if(document.getElementById("imgSqr149").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr149").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrF25b() {
    if(document.getElementById("imgSqr150").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr150").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
 };
};

function sqrG1b() {
    if(document.getElementById("imgSqr151").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr151").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrG2b() {
    if(document.getElementById("imgSqr152").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr152").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrG3b() {
    if(document.getElementById("imgSqr153").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr153").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrG4b() {
    if(document.getElementById("imgSqr154").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr154").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrG5b() {
    if(document.getElementById("imgSqr155").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr155").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrG6b() {
    if(document.getElementById("imgSqr156").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr156").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrG7b() {
    if(document.getElementById("imgSqr157").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr157").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrG8b() {
    if(document.getElementById("imgSqr158").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr158").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrG9b() {
    if(document.getElementById("imgSqr159").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr159").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrG10b() {
    if(document.getElementById("imgSqr160").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr160").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrG11b() {
    if(document.getElementById("imgSqr161").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr161").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrG12b() {
    if(document.getElementById("imgSqr162").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr162").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrG13b() {
    if(document.getElementById("imgSqr163").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr163").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrG14b() {
    if(document.getElementById("imgSqr164").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr164").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrG15b() {
    if(document.getElementById("imgSqr165").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr165").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrG16b() {
    if(document.getElementById("imgSqr166").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr166").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrG17b() {
    if(document.getElementById("imgSqr167").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr167").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrG18b() {
    if(document.getElementById("imgSqr168").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr168").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrG19b() {
    if(document.getElementById("imgSqr169").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr169").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrG20b() {
    if(document.getElementById("imgSqr170").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr170").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrG21b() {
    if(document.getElementById("imgSqr171").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr171").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrG22b() {
    if(document.getElementById("imgSqr172").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr172").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrG23b() {
    if(document.getElementById("imgSqr173").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr173").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrG24b() {
    if(document.getElementById("imgSqr174").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr174").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrG25b() {
    if(document.getElementById("imgSqr175").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr175").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrH1b() {
    if(document.getElementById("imgSqr176").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr176").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrH2b() {
    if(document.getElementById("imgSqr177").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr177").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrH3b() {
    if(document.getElementById("imgSqr178").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr178").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrH4b() {
    if(document.getElementById("imgSqr179").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr179").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrH5b() {
    if(document.getElementById("imgSqr180").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr180").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrH6b() {
    if(document.getElementById("imgSqr181").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr181").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrH7b() {
    if(document.getElementById("imgSqr182").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr182").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrH8b() {
    if(document.getElementById("imgSqr183").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr183").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrH9b() {
    if(document.getElementById("imgSqr184").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr184").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrH10b() {
    if(document.getElementById("imgSqr185").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr185").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrH11b() {
    if(document.getElementById("imgSqr186").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr186").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrH12b() {
    if(document.getElementById("imgSqr187").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr187").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrH13b() {
    if(document.getElementById("imgSqr188").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr188").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrH14b() {
    if(document.getElementById("imgSqr189").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr189").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrH15b() {
    if(document.getElementById("imgSqr190").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr190").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrH16b() {
    if(document.getElementById("imgSqr191").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr191").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrH17b() {
    if(document.getElementById("imgSqr192").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr192").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrH18b() {
    if(document.getElementById("imgSqr193").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr193").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrH19b() {
    if(document.getElementById("imgSqr194").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr194").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrH20b() {
    if(document.getElementById("imgSqr195").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr195").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrH21b() {
    if(document.getElementById("imgSqr196").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr196").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrH22b() {
    if(document.getElementById("imgSqr197").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr197").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrH23b() {
    if(document.getElementById("imgSqr198").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr198").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrH24b() {
    if(document.getElementById("imgSqr199").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr199").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrH25b() {
    if(document.getElementById("imgSqr200").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr200").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
 };
};

function sqrI1b() {
    if(document.getElementById("imgSqr201").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr201").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrI2b() {
    if(document.getElementById("imgSqr202").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr202").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrI3b() {
    if(document.getElementById("imgSqr203").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr203").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrI4b() {
    if(document.getElementById("imgSqr204").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr204").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrI5b() {
    if(document.getElementById("imgSqr205").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr205").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrI6b() {
    if(document.getElementById("imgSqr206").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr206").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrI7b() {
    if(document.getElementById("imgSqr207").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr207").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrI8b() {
    if(document.getElementById("imgSqr208").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr208").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrI9b() {
    if(document.getElementById("imgSqr209").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr209").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrI10b() {
    if(document.getElementById("imgSqr210").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr210").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrI11b() {
    if(document.getElementById("imgSqr211").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr211").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrI12b() {
    if(document.getElementById("imgSqr212").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr212").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrI13b() {
    if(document.getElementById("imgSqr213").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr213").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrI14b() {
    if(document.getElementById("imgSqr214").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr214").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrI15b() {
    if(document.getElementById("imgSqr215").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr215").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrI16b() {
    if(document.getElementById("imgSqr216").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr216").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrI17b() {
    if(document.getElementById("imgSqr217").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr217").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrI18b() {
    if(document.getElementById("imgSqr218").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr218").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrI19b() {
    if(document.getElementById("imgSqr219").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr219").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrI20b() {
    if(document.getElementById("imgSqr220").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr220").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrI21b() {
    if(document.getElementById("imgSqr221").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr221").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrI22b() {
    if(document.getElementById("imgSqr222").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr222").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrI23b() {
    if(document.getElementById("imgSqr223").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr223").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrI24b() {
    if(document.getElementById("imgSqr224").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr224").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrI25b() {
    if(document.getElementById("imgSqr225").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr225").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
 };
};

function sqrJ1b() {
    if(document.getElementById("imgSqr226").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr226").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrJ2b() {
    if(document.getElementById("imgSqr227").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr227").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrJ3b() {
    if(document.getElementById("imgSqr228").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr228").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrJ4b() {
    if(document.getElementById("imgSqr229").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr229").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrJ5b() {
    if(document.getElementById("imgSqr230").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr230").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrJ6b() {
    if(document.getElementById("imgSqr231").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr231").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrJ7b() {
    if(document.getElementById("imgSqr232").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr232").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrJ8b() {
    if(document.getElementById("imgSqr233").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr233").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrJ9b() {
    if(document.getElementById("imgSqr234").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr234").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrJ10b() {
    if(document.getElementById("imgSqr235").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr235").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrJ11b() {
    if(document.getElementById("imgSqr236").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr236").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrJ12b() {
    if(document.getElementById("imgSqr237").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr237").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrJ13b() {
    if(document.getElementById("imgSqr238").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr238").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrJ14b() {
    if(document.getElementById("imgSqr239").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr239").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrJ15b() {
    if(document.getElementById("imgSqr240").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr240").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrJ16b() {
    if(document.getElementById("imgSqr241").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr241").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrJ17b() {
    if(document.getElementById("imgSqr242").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr242").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrJ18b() {
    if(document.getElementById("imgSqr243").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr243").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrJ19b() {
    if(document.getElementById("imgSqr244").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr244").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrJ20b() {
    if(document.getElementById("imgSqr245").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr245").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrJ21b() {
    if(document.getElementById("imgSqr246").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr246").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrJ22b() {
    if(document.getElementById("imgSqr247").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr247").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrJ23b() {
    if(document.getElementById("imgSqr248").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr248").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrJ24b() {
    if(document.getElementById("imgSqr249").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr249").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrJ25b() {
    if(document.getElementById("imgSqr250").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr250").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
 };
};

function sqrK1b() {
    if(document.getElementById("imgSqr251").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr251").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrK2b() {
    if(document.getElementById("imgSqr252").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr252").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrK3b() {
    if(document.getElementById("imgSqr253").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr253").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrK4b() {
    if(document.getElementById("imgSqr254").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr254").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrK5b() {
    if(document.getElementById("imgSqr255").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr255").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrK6b() {
    if(document.getElementById("imgSqr256").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr256").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrK7b() {
    if(document.getElementById("imgSqr257").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr257").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrK8b() {
    if(document.getElementById("imgSqr258").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr258").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrK9b() {
    if(document.getElementById("imgSqr259").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr259").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrK10b() {
    if(document.getElementById("imgSqr260").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr260").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrK11b() {
    if(document.getElementById("imgSqr261").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr261").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrK12b() {
    if(document.getElementById("imgSqr262").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr262").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrK13b() {
    if(document.getElementById("imgSqr263").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr263").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrK14b() {
    if(document.getElementById("imgSqr264").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr264").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrK15b() {
    if(document.getElementById("imgSqr265").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr265").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrK16b() {
    if(document.getElementById("imgSqr266").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr266").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrK17b() {
    if(document.getElementById("imgSqr267").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr267").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrK18b() {
    if(document.getElementById("imgSqr268").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr268").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrK19b() {
    if(document.getElementById("imgSqr269").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr269").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrK20b() {
    if(document.getElementById("imgSqr270").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr270").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrK21b() {
    if(document.getElementById("imgSqr271").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr271").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrK22b() {
    if(document.getElementById("imgSqr272").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr272").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrK23b() {
    if(document.getElementById("imgSqr273").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr273").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrK24b() {
    if(document.getElementById("imgSqr274").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr274").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrK25b() {
    if(document.getElementById("imgSqr275").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr275").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
 };
};

function sqrL1b() {
    if(document.getElementById("imgSqr276").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr276").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrL2b() {
    if(document.getElementById("imgSqr277").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr277").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrL3b() {
    if(document.getElementById("imgSqr278").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr278").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrL4b() {
    if(document.getElementById("imgSqr279").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr279").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrL5b() {
    if(document.getElementById("imgSqr280").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr280").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrL6b() {
    if(document.getElementById("imgSqr281").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr281").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrL7b() {
    if(document.getElementById("imgSqr282").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr282").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrL8b() {
    if(document.getElementById("imgSqr283").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr283").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrL9b() {
    if(document.getElementById("imgSqr284").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr284").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrL10b() {
    if(document.getElementById("imgSqr285").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr285").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrL11b() {
    if(document.getElementById("imgSqr286").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr286").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrL12b() {
    if(document.getElementById("imgSqr287").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr287").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrL13b() {
    if(document.getElementById("imgSqr288").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr288").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrL14b() {
    if(document.getElementById("imgSqr289").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr289").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrL15b() {
    if(document.getElementById("imgSqr290").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr290").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrL16b() {
    if(document.getElementById("imgSqr291").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr291").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrL17b() {
    if(document.getElementById("imgSqr292").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr292").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrL18b() {
    if(document.getElementById("imgSqr293").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr293").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrL19b() {
    if(document.getElementById("imgSqr294").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr294").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrL20b() {
    if(document.getElementById("imgSqr295").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr295").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrL21b() {
    if(document.getElementById("imgSqr296").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr296").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrL22b() {
    if(document.getElementById("imgSqr297").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr297").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrL23b() {
    if(document.getElementById("imgSqr298").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr298").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrL24b() {
    if(document.getElementById("imgSqr299").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr299").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrL25b() {
    if(document.getElementById("imgSqr300").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr300").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
 };
};

function sqrM1b() {
    if(document.getElementById("imgSqr301").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr301").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrM2b() {
    if(document.getElementById("imgSqr302").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr302").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrM3b() {
    if(document.getElementById("imgSqr303").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr303").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrM4b() {
    if(document.getElementById("imgSqr304").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr304").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrM5b() {
    if(document.getElementById("imgSqr305").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr305").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrM6b() {
    if(document.getElementById("imgSqr306").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr306").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrM7b() {
    if(document.getElementById("imgSqr307").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr307").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrM8b() {
    if(document.getElementById("imgSqr308").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr308").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrM9b() {
    if(document.getElementById("imgSqr309").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr309").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrM10b() {
    if(document.getElementById("imgSqr310").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr310").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrM11b() {
    if(document.getElementById("imgSqr311").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr311").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrM12b() {
    if(document.getElementById("imgSqr312").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr312").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrM13b() {
    if(document.getElementById("imgSqr313").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr313").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrM14b() {
    if(document.getElementById("imgSqr314").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr314").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrM15b() {
    if(document.getElementById("imgSqr315").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr315").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrM16b() {
    if(document.getElementById("imgSqr316").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr316").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrM17b() {
    if(document.getElementById("imgSqr317").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr317").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrM18b() {
    if(document.getElementById("imgSqr318").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr318").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrM19b() {
    if(document.getElementById("imgSqr319").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr319").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrM20b() {
    if(document.getElementById("imgSqr320").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr320").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrM21b() {
    if(document.getElementById("imgSqr321").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr321").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrM22b() {
    if(document.getElementById("imgSqr322").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr322").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrM23b() {
    if(document.getElementById("imgSqr323").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr323").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrM24b() {
    if(document.getElementById("imgSqr324").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr324").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrM25b() {
    if(document.getElementById("imgSqr325").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr325").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
 };
};

function sqrN1b() {
    if(document.getElementById("imgSqr326").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr326").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrN2b() {
    if(document.getElementById("imgSqr327").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr327").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrN3b() {
    if(document.getElementById("imgSqr328").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr328").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrN4b() {
    if(document.getElementById("imgSqr329").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr329").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrN5b() {
    if(document.getElementById("imgSqr330").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr330").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrN6b() {
    if(document.getElementById("imgSqr331").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr331").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrN7b() {
    if(document.getElementById("imgSqr332").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr332").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrN8b() {
    if(document.getElementById("imgSqr333").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr333").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrN9b() {
    if(document.getElementById("imgSqr334").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr334").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrN10b() {
    if(document.getElementById("imgSqr335").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr335").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrN11b() {
    if(document.getElementById("imgSqr336").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr336").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrN12b() {
    if(document.getElementById("imgSqr337").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr337").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrN13b() {
    if(document.getElementById("imgSqr338").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr338").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrN14b() {
    if(document.getElementById("imgSqr339").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr339").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrN15b() {
    if(document.getElementById("imgSqr340").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr340").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrN16b() {
    if(document.getElementById("imgSqr341").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr341").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrN17b() {
    if(document.getElementById("imgSqr342").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr342").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrN18b() {
    if(document.getElementById("imgSqr343").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr343").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrN19b() {
    if(document.getElementById("imgSqr344").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr344").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrN20b() {
    if(document.getElementById("imgSqr345").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr345").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrN21b() {
    if(document.getElementById("imgSqr346").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr346").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrN22b() {
    if(document.getElementById("imgSqr347").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr347").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrN23b() {
    if(document.getElementById("imgSqr348").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr348").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrN24b() {
    if(document.getElementById("imgSqr349").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr349").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrN25b() {
    if(document.getElementById("imgSqr350").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr350").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
 };
};

function sqrO1b() {
    if(document.getElementById("imgSqr351").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr351").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrO2b() {
    if(document.getElementById("imgSqr352").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr352").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrO3b() {
    if(document.getElementById("imgSqr353").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr353").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrO4b() {
    if(document.getElementById("imgSqr354").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr354").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrO5b() {
    if(document.getElementById("imgSqr355").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr355").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrO6b() {
    if(document.getElementById("imgSqr356").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr356").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrO7b() {
    if(document.getElementById("imgSqr357").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr357").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrO8b() {
    if(document.getElementById("imgSqr358").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr358").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrO9b() {
    if(document.getElementById("imgSqr359").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr359").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrO10b() {
    if(document.getElementById("imgSqr360").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr360").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrO11b() {
    if(document.getElementById("imgSqr361").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr361").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrO12b() {
    if(document.getElementById("imgSqr362").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr362").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrO13b() {
    if(document.getElementById("imgSqr363").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr363").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrO14b() {
    if(document.getElementById("imgSqr364").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr364").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrO15b() {
    if(document.getElementById("imgSqr365").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr365").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrO16b() {
    if(document.getElementById("imgSqr366").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr366").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrO17b() {
    if(document.getElementById("imgSqr367").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr367").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrO18b() {
    if(document.getElementById("imgSqr368").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr368").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrO19b() {
    if(document.getElementById("imgSqr369").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr369").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrO20b() {
    if(document.getElementById("imgSqr370").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr370").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrO21b() {
    if(document.getElementById("imgSqr371").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr371").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrO22b() {
    if(document.getElementById("imgSqr372").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr372").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrO23b() {
    if(document.getElementById("imgSqr373").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr373").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrO24b() {
    if(document.getElementById("imgSqr374").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr374").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrO25b() {
    if(document.getElementById("imgSqr375").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr375").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
 };
};

function sqrP1b() {
    if(document.getElementById("imgSqr376").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr376").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrP2b() {
    if(document.getElementById("imgSqr377").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr377").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrP3b() {
    if(document.getElementById("imgSqr378").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr378").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrP4b() {
    if(document.getElementById("imgSqr379").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr379").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrP5b() {
    if(document.getElementById("imgSqr380").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr380").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrP6b() {
    if(document.getElementById("imgSqr381").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr381").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrP7b() {
    if(document.getElementById("imgSqr382").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr382").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrP8b() {
    if(document.getElementById("imgSqr383").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr383").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrP9b() {
    if(document.getElementById("imgSqr384").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr384").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrP10b() {
    if(document.getElementById("imgSqr385").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr385").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrP11b() {
    if(document.getElementById("imgSqr386").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr386").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrP12b() {
    if(document.getElementById("imgSqr387").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr387").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrP13b() {
    if(document.getElementById("imgSqr388").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr388").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrP14b() {
    if(document.getElementById("imgSqr389").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr389").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrP15b() {
    if(document.getElementById("imgSqr390").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr390").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrP16b() {
    if(document.getElementById("imgSqr391").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr391").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrP17b() {
    if(document.getElementById("imgSqr392").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr392").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrP18b() {
    if(document.getElementById("imgSqr393").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr393").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrP19b() {
    if(document.getElementById("imgSqr394").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr394").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrP20b() {
    if(document.getElementById("imgSqr395").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr395").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrP21b() {
    if(document.getElementById("imgSqr396").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr396").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrP22b() {
    if(document.getElementById("imgSqr397").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr397").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrP23b() {
    if(document.getElementById("imgSqr398").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr398").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrP24b() {
    if(document.getElementById("imgSqr399").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr399").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrP25b() {
    if(document.getElementById("imgSqr400").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr400").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
 };
};

function sqrQ1b() {
    if(document.getElementById("imgSqr401").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr401").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQ2b() {
    if(document.getElementById("imgSqr402").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr402").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQ3b() {
    if(document.getElementById("imgSqr403").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr403").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQ4b() {
    if(document.getElementById("imgSqr404").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr404").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQ5b() {
    if(document.getElementById("imgSqr405").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr405").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQ6b() {
    if(document.getElementById("imgSqr406").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr406").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQ7b() {
    if(document.getElementById("imgSqr407").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr407").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQ8b() {
    if(document.getElementById("imgSqr408").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr408").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQ9b() {
    if(document.getElementById("imgSqr409").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr409").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQ10b() {
    if(document.getElementById("imgSqr410").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr410").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQ11b() {
    if(document.getElementById("imgSqr411").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr411").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQ12b() {
    if(document.getElementById("imgSqr412").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr412").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQ13b() {
    if(document.getElementById("imgSqr413").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr413").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQ14b() {
    if(document.getElementById("imgSqr414").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr414").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQ15b() {
    if(document.getElementById("imgSqr415").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr415").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQ16b() {
    if(document.getElementById("imgSqr416").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr416").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQ17b() {
    if(document.getElementById("imgSqr417").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr417").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQ18b() {
    if(document.getElementById("imgSqr418").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr418").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQ19b() {
    if(document.getElementById("imgSqr419").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr419").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQ20b() {
    if(document.getElementById("imgSqr420").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr420").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQ21b() {
    if(document.getElementById("imgSqr421").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr421").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQ22b() {
    if(document.getElementById("imgSqr422").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr422").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQ23b() {
    if(document.getElementById("imgSqr423").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr423").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQ24b() {
    if(document.getElementById("imgSqr424").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr424").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQ25b() {
    if(document.getElementById("imgSqr425").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr425").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
 };
};

function sqrR1b() {
    if(document.getElementById("imgSqr426").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr426").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrR2b() {
    if(document.getElementById("imgSqr427").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr427").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrR3b() {
    if(document.getElementById("imgSqr428").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr428").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrR4b() {
    if(document.getElementById("imgSqr429").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr429").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrR5b() {
    if(document.getElementById("imgSqr430").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr430").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrR6b() {
    if(document.getElementById("imgSqr431").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr431").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrR7b() {
    if(document.getElementById("imgSqr432").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr432").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrR8b() {
    if(document.getElementById("imgSqr433").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr433").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrR9b() {
    if(document.getElementById("imgSqr434").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr434").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrR10b() {
    if(document.getElementById("imgSqr435").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr435").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrR11b() {
    if(document.getElementById("imgSqr436").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr436").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrR12b() {
    if(document.getElementById("imgSqr437").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr437").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrR13b() {
    if(document.getElementById("imgSqr438").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr438").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrR14b() {
    if(document.getElementById("imgSqr439").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr439").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrR15b() {
    if(document.getElementById("imgSqr440").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr440").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrR16b() {
    if(document.getElementById("imgSqr441").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr441").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrR17b() {
    if(document.getElementById("imgSqr442").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr442").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrR18b() {
    if(document.getElementById("imgSqr443").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr443").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrR19b() {
    if(document.getElementById("imgSqr444").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr444").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrR20b() {
    if(document.getElementById("imgSqr445").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr445").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrR21b() {
    if(document.getElementById("imgSqr446").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr446").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrR22b() {
    if(document.getElementById("imgSqr447").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr447").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrR23b() {
    if(document.getElementById("imgSqr448").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr448").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrR24b() {
    if(document.getElementById("imgSqr449").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr449").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrR25b() {
    if(document.getElementById("imgSqr450").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr450").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
 };
};

function sqrS1b() {
    if(document.getElementById("imgSqr451").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr451").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrS2b() {
    if(document.getElementById("imgSqr452").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr452").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrS3b() {
    if(document.getElementById("imgSqr453").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr453").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrS4b() {
    if(document.getElementById("imgSqr454").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr454").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrS5b() {
    if(document.getElementById("imgSqr455").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr455").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrS6b() {
    if(document.getElementById("imgSqr456").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr456").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrS7b() {
    if(document.getElementById("imgSqr457").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr457").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrS8b() {
    if(document.getElementById("imgSqr458").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr458").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrS9b() {
    if(document.getElementById("imgSqr459").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr459").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrS10b() {
    if(document.getElementById("imgSqr460").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr460").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrS11b() {
    if(document.getElementById("imgSqr461").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr461").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrS12b() {
    if(document.getElementById("imgSqr462").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr462").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrS13b() {
    if(document.getElementById("imgSqr463").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr463").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrS14b() {
    if(document.getElementById("imgSqr464").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr464").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrS15b() {
    if(document.getElementById("imgSqr465").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr465").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrS16b() {
    if(document.getElementById("imgSqr466").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr466").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrS17b() {
    if(document.getElementById("imgSqr467").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr467").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrS18b() {
    if(document.getElementById("imgSqr468").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr468").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrS19b() {
    if(document.getElementById("imgSqr469").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr469").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrS20b() {
    if(document.getElementById("imgSqr470").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr470").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrS21b() {
    if(document.getElementById("imgSqr471").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr471").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrS22b() {
    if(document.getElementById("imgSqr472").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr472").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrS23b() {
    if(document.getElementById("imgSqr473").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr473").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrS24b() {
    if(document.getElementById("imgSqr474").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr474").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrS25b() {
    if(document.getElementById("imgSqr475").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr475").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
 };
};

function sqrT1b() {
    if(document.getElementById("imgSqr476").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr476").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrT2b() {
    if(document.getElementById("imgSqr477").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr477").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrT3b() {
    if(document.getElementById("imgSqr478").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr478").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrT4b() {
    if(document.getElementById("imgSqr479").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr479").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrT5b() {
    if(document.getElementById("imgSqr480").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr480").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrT6b() {
    if(document.getElementById("imgSqr481").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr481").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrT7b() {
    if(document.getElementById("imgSqr482").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr482").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrT8b() {
    if(document.getElementById("imgSqr483").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr483").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrT9b() {
    if(document.getElementById("imgSqr484").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr484").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrT10b() {
    if(document.getElementById("imgSqr485").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr485").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrT11b() {
    if(document.getElementById("imgSqr486").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr486").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrT12b() {
    if(document.getElementById("imgSqr487").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr487").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrT13b() {
    if(document.getElementById("imgSqr488").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr488").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrT14b() {
    if(document.getElementById("imgSqr489").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr489").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrT15b() {
    if(document.getElementById("imgSqr490").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr490").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrT16b() {
    if(document.getElementById("imgSqr491").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr491").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrT17b() {
    if(document.getElementById("imgSqr492").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr492").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrT18b() {
    if(document.getElementById("imgSqr493").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr493").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrT19b() {
    if(document.getElementById("imgSqr494").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr494").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrT20b() {
    if(document.getElementById("imgSqr495").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr495").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrT21b() {
    if(document.getElementById("imgSqr496").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr496").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrT22b() {
    if(document.getElementById("imgSqr497").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr497").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrT23b() {
    if(document.getElementById("imgSqr498").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr498").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrT24b() {
    if(document.getElementById("imgSqr499").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr499").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrT25b() {
    if(document.getElementById("imgSqr500").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr500").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
 };
};

function sqrU1b() {
    if(document.getElementById("imgSqr501").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr501").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrU2b() {
    if(document.getElementById("imgSqr502").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr502").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrU3b() {
    if(document.getElementById("imgSqr503").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr503").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrU4b() {
    if(document.getElementById("imgSqr504").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr504").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrU5b() {
    if(document.getElementById("imgSqr505").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr505").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrU6b() {
    if(document.getElementById("imgSqr506").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr506").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrU7b() {
    if(document.getElementById("imgSqr507").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr507").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrU8b() {
    if(document.getElementById("imgSqr508").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr508").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrU9b() {
    if(document.getElementById("imgSqr509").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr509").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrU10b() {
    if(document.getElementById("imgSqr510").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr510").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrU11b() {
    if(document.getElementById("imgSqr511").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr511").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrU12b() {
    if(document.getElementById("imgSqr512").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr512").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrU13b() {
    if(document.getElementById("imgSqr513").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr513").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrU14b() {
    if(document.getElementById("imgSqr514").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr514").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrU15b() {
    if(document.getElementById("imgSqr515").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr515").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrU16b() {
    if(document.getElementById("imgSqr516").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr516").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrU17b() {
    if(document.getElementById("imgSqr517").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr517").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrU18b() {
    if(document.getElementById("imgSqr518").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr518").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrU19b() {
    if(document.getElementById("imgSqr519").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr519").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrU20b() {
    if(document.getElementById("imgSqr520").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr520").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrU21b() {
    if(document.getElementById("imgSqr521").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr521").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrU22b() {
    if(document.getElementById("imgSqr522").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr522").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrU23b() {
    if(document.getElementById("imgSqr523").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr523").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrU24b() {
    if(document.getElementById("imgSqr524").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr524").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrU25b() {
    if(document.getElementById("imgSqr525").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr525").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
 };
};

function sqrV1b() {
    if(document.getElementById("imgSqr526").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr526").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrV2b() {
    if(document.getElementById("imgSqr527").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr527").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrV3b() {
    if(document.getElementById("imgSqr528").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr528").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrV4b() {
    if(document.getElementById("imgSqr529").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr529").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrV5b() {
    if(document.getElementById("imgSqr530").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr530").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrV6b() {
    if(document.getElementById("imgSqr531").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr531").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrV7b() {
    if(document.getElementById("imgSqr532").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr532").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrV8b() {
    if(document.getElementById("imgSqr533").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr533").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrV9b() {
    if(document.getElementById("imgSqr534").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr534").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrV10b() {
    if(document.getElementById("imgSqr535").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr535").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrV11b() {
    if(document.getElementById("imgSqr536").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr536").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrV12b() {
    if(document.getElementById("imgSqr537").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr537").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrV13b() {
    if(document.getElementById("imgSqr538").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr538").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrV14b() {
    if(document.getElementById("imgSqr539").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr539").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrV15b() {
    if(document.getElementById("imgSqr540").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr540").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrV16b() {
    if(document.getElementById("imgSqr541").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr541").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrV17b() {
    if(document.getElementById("imgSqr542").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr542").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrV18b() {
    if(document.getElementById("imgSqr543").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr543").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrV19b() {
    if(document.getElementById("imgSqr544").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr544").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrV20b() {
    if(document.getElementById("imgSqr545").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr545").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrV21b() {
    if(document.getElementById("imgSqr546").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr546").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrV22b() {
    if(document.getElementById("imgSqr547").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr547").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrV23b() {
    if(document.getElementById("imgSqr548").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr548").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrV24b() {
    if(document.getElementById("imgSqr549").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr549").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrV25b() {
    if(document.getElementById("imgSqr550").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr550").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
 };
};

function sqrW1b() {
    if(document.getElementById("imgSqr551").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
         document.getElementById("imgSqr551").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrW2b() {
    if(document.getElementById("imgSqr552").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr552").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrW3b() {
    if(document.getElementById("imgSqr553").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr553").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrW4b() {
    if(document.getElementById("imgSqr554").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr554").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrW5b() {
    if(document.getElementById("imgSqr555").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr555").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrW6b() {
    if(document.getElementById("imgSqr556").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr556").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrW7b() {
    if(document.getElementById("imgSqr557").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr557").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrW8b() {
    if(document.getElementById("imgSqr558").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr558").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrW9b() {
    if(document.getElementById("imgSqr559").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr559").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrW10b() {
    if(document.getElementById("imgSqr560").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr560").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrW11b() {
    if(document.getElementById("imgSqr561").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr561").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrW12b() {
    if(document.getElementById("imgSqr562").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr562").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrW13b() {
    if(document.getElementById("imgSqr563").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr563").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrW14b() {
    if(document.getElementById("imgSqr564").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr564").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrW15b() {
    if(document.getElementById("imgSqr565").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr565").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrW16b() {
    if(document.getElementById("imgSqr566").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr566").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrW17b() {
    if(document.getElementById("imgSqr567").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr567").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrW18b() {
    if(document.getElementById("imgSqr568").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr568").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrW19b() {
    if(document.getElementById("imgSqr569").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr569").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrW20b() {
    if(document.getElementById("imgSqr570").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr570").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrW21b() {
    if(document.getElementById("imgSqr571").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr571").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrW22b() {
    if(document.getElementById("imgSqr572").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr572").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrW23b() {
    if(document.getElementById("imgSqr573").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr573").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrW24b() {
    if(document.getElementById("imgSqr574").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr574").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrW25b() {
    if(document.getElementById("imgSqr575").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr575").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
 };
};

function sqrX1b() {
    if(document.getElementById("imgSqr576").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr576").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrX2b() {
    if(document.getElementById("imgSqr577").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr577").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrX3b() {
    if(document.getElementById("imgSqr578").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr578").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrX4b() {
    if(document.getElementById("imgSqr579").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr579").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrX5b() {
    if(document.getElementById("imgSqr580").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr580").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrX6b() {
    if(document.getElementById("imgSqr581").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr581").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrX7b() {
    if(document.getElementById("imgSqr582").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr582").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrX8b() {
    if(document.getElementById("imgSqr583").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr583").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrX9b() {
    if(document.getElementById("imgSqr584").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr584").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrX10b() {
    if(document.getElementById("imgSqr585").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr585").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrX11b() {
    if(document.getElementById("imgSqr586").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr586").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrX12b() {
    if(document.getElementById("imgSqr587").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr587").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrX13b() {
    if(document.getElementById("imgSqr588").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr588").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrX14b() {
    if(document.getElementById("imgSqr589").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr589").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrX15b() {
    if(document.getElementById("imgSqr590").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr590").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrX16b() {
    if(document.getElementById("imgSqr591").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr591").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrX17b() {
    if(document.getElementById("imgSqr592").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr592").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrX18b() {
    if(document.getElementById("imgSqr593").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr593").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrX19b() {
    if(document.getElementById("imgSqr594").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr594").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrX20b() {
    if(document.getElementById("imgSqr595").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr595").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrX21b() {
    if(document.getElementById("imgSqr596").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr596").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrX22b() {
    if(document.getElementById("imgSqr597").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr597").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrX23b() {
    if(document.getElementById("imgSqr598").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr598").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrX24b() {
    if(document.getElementById("imgSqr599").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr599").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrX25b() {
    if(document.getElementById("imgSqr600").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("imgSqr600").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
 };
};

function sqrY1b() {
    if(document.getElementById("imgSqr601").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr601").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrY2b() {
    if(document.getElementById("imgSqr602").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr602").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrY3b() {
    if(document.getElementById("imgSqr603").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr603").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrY4b() {
    if(document.getElementById("imgSqr604").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr604").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrY5b() {
    if(document.getElementById("imgSqr605").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr605").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrY6b() {
    if(document.getElementById("imgSqr606").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr606").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrY7b() {
    if(document.getElementById("imgSqr607").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr607").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrY8b() {
    if(document.getElementById("imgSqr608").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr608").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrY9b() {
    if(document.getElementById("imgSqr609").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr609").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrY10b() {
    if(document.getElementById("imgSqr610").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr610").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrY11b() {
    if(document.getElementById("imgSqr611").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr611").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrY12b() {
    if(document.getElementById("imgSqr612").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr612").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrY13b() {
    if(document.getElementById("imgSqr613").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr613").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrY14b() {
    if(document.getElementById("imgSqr614").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr614").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrY15b() {
    if(document.getElementById("imgSqr615").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr615").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrY16b() {
    if(document.getElementById("imgSqr616").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr616").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrY17b() {
    if(document.getElementById("imgSqr617").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr617").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrY18b() {
    if(document.getElementById("imgSqr618").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr618").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrY19b() {
    if(document.getElementById("imgSqr619").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("imgSqr619").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrY20b() {
    if(document.getElementById("imgSqr620").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
    document.getElementById("imgSqr620").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrY21b() {
    if(document.getElementById("imgSqr621").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
    document.getElementById("imgSqr621").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrY22b() {
    if(document.getElementById("imgSqr622").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
    document.getElementById("imgSqr622").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrY23b() {
    if(document.getElementById("imgSqr623").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
    document.getElementById("imgSqr623").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrY24b() {
    if(document.getElementById("imgSqr624").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
    document.getElementById("imgSqr624").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrY25b() {
    if(document.getElementById("imgSqr625").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
    document.getElementById("imgSqr625").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};