function sqrQA1() {
    if(document.getElementById("aImgSqr1").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr1").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQA2() {
    if(document.getElementById("aImgSqr2").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr2").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQA3() {
    if(document.getElementById("aImgSqr3").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr3").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQA4() {
    if(document.getElementById("aImgSqr4").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr4").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQA5() {
    if(document.getElementById("aImgSqr5").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr5").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQA6() {
    if(document.getElementById("aImgSqr6").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr6").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQA7() {
    if(document.getElementById("aImgSqr7").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr7").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQA8() {
    if(document.getElementById("aImgSqr8").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr8").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQA9() {
    if(document.getElementById("aImgSqr9").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr9").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQA10() {
    if(document.getElementById("aImgSqr10").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr10").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQA11() {
    if(document.getElementById("aImgSqr11").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr11").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQA12() {
    if(document.getElementById("aImgSqr12").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr12").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQA13() {
    if(document.getElementById("aImgSqr13").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr13").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQA14() {
    if(document.getElementById("aImgSqr14").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr14").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQA15() {
    if(document.getElementById("aImgSqr15").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr15").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQA16() {
    if(document.getElementById("aImgSqr16").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr16").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQA17() {
    if(document.getElementById("aImgSqr17").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr17").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQA18() {
    if(document.getElementById("aImgSqr18").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr18").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQA19() {
    if(document.getElementById("aImgSqr19").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr19").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQA20() {
    if(document.getElementById("aImgSqr20").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr20").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQA21() {
    if(document.getElementById("aImgSqr21").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr21").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQA22() {
    if(document.getElementById("aImgSqr22").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr22").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQA23() {
    if(document.getElementById("aImgSqr23").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr23").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQA24() {
    if(document.getElementById("aImgSqr24").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr24").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQA25() {
    if(document.getElementById("aImgSqr25").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr25").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQB1() {
    if(document.getElementById("aImgSqr26").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr26").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQB2() {
    if(document.getElementById("aImgSqr27").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr27").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQB3() {
    if(document.getElementById("aImgSqr28").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr28").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQB4() {
    if(document.getElementById("aImgSqr29").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr29").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQB5() {
    if(document.getElementById("aImgSqr30").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr30").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQB6() {
    if(document.getElementById("aImgSqr31").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr31").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQB7() {
    if(document.getElementById("aImgSqr32").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr32").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQB8() {
    if(document.getElementById("aImgSqr33").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr33").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQB9() {
    if(document.getElementById("aImgSqr34").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr34").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQB10() {
    if(document.getElementById("aImgSqr35").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr35").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQB11() {
    if(document.getElementById("aImgSqr36").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr36").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQB12() {
    if(document.getElementById("aImgSqr37").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr37").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQB13() {
    if(document.getElementById("aImgSqr38").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr38").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQB14() {
    if(document.getElementById("aImgSqr39").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr39").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQB15() {
    if(document.getElementById("aImgSqr40").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr40").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQB16() {
    if(document.getElementById("aImgSqr41").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr41").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQB17() {
    if(document.getElementById("aImgSqr42").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr42").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQB18() {
    if(document.getElementById("aImgSqr43").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr43").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQB19() {
    if(document.getElementById("aImgSqr44").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr44").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQB20() {
    if(document.getElementById("aImgSqr45").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr45").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQB21() {
    if(document.getElementById("aImgSqr46").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr46").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQB22() {
    if(document.getElementById("aImgSqr47").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr47").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQB23() {
    if(document.getElementById("aImgSqr48").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr48").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQB24() {
    if(document.getElementById("aImgSqr49").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr49").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQB25() {
    if(document.getElementById("aImgSqr50").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr50").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQC1() {
    if(document.getElementById("aImgSqr51").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr51").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQC2() {
    if(document.getElementById("aImgSqr52").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr52").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQC3() {
    if(document.getElementById("aImgSqr53").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr53").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQC4() {
    if(document.getElementById("aImgSqr54").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr54").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQC5() {
    if(document.getElementById("aImgSqr55").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr55").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQC6() {
    if(document.getElementById("aImgSqr56").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr56").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQC7() {
    if(document.getElementById("aImgSqr57").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr57").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQC8() {
    if(document.getElementById("aImgSqr58").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr58").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQC9() {
    if(document.getElementById("aImgSqr59").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr59").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQC10() {
    if(document.getElementById("aImgSqr60").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr60").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQC11() {
    if(document.getElementById("aImgSqr61").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr61").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQC12() {
    if(document.getElementById("aImgSqr62").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr62").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQC13() {
    if(document.getElementById("aImgSqr63").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr63").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQC14() {
    if(document.getElementById("aImgSqr64").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr64").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQC15() {
    if(document.getElementById("aImgSqr65").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr65").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQC16() {
    if(document.getElementById("aImgSqr66").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr66").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQC17() {
    if(document.getElementById("aImgSqr67").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr67").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQC18() {
    if(document.getElementById("aImgSqr68").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr68").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQC19() {
    if(document.getElementById("aImgSqr69").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr69").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQC20() {
    if(document.getElementById("aImgSqr70").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr70").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQC21() {
    if(document.getElementById("aImgSqr71").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr71").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQC22() {
    if(document.getElementById("aImgSqr72").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr72").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQC23() {
    if(document.getElementById("aImgSqr73").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr73").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQC24() {
    if(document.getElementById("aImgSqr74").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr74").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQC25() {
    if(document.getElementById("aImgSqr75").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr75").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
 };
};

function sqrQD1() {
    if(document.getElementById("aImgSqr76").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr76").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQD2() {
    if(document.getElementById("aImgSqr77").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr77").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQD3() {
    if(document.getElementById("aImgSqr78").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr78").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQD4() {
    if(document.getElementById("aImgSqr79").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr79").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQD5() {
    if(document.getElementById("aImgSqr80").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr80").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQD6() {
    if(document.getElementById("aImgSqr81").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr81").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQD7() {
    if(document.getElementById("aImgSqr82").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr82").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQD8() {
    if(document.getElementById("aImgSqr83").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr83").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQD9() {
    if(document.getElementById("aImgSqr84").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr84").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQD10() {
    if(document.getElementById("aImgSqr85").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr85").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQD11() {
    if(document.getElementById("aImgSqr86").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr86").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQD12() {
    if(document.getElementById("aImgSqr87").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr87").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQD13() {
    if(document.getElementById("aImgSqr88").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr88").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQD14() {
    if(document.getElementById("aImgSqr89").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr89").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQD15() {
    if(document.getElementById("aImgSqr90").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr90").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQD16() {
    if(document.getElementById("aImgSqr91").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr91").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQD17() {
    if(document.getElementById("aImgSqr92").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr92").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQD18() {
    if(document.getElementById("aImgSqr93").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr93").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQD19() {
    if(document.getElementById("aImgSqr94").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr94").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQD20() {
    if(document.getElementById("aImgSqr95").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr95").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQD21() {
    if(document.getElementById("aImgSqr96").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr96").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQD22() {
    if(document.getElementById("aImgSqr97").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr97").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQD23() {
    if(document.getElementById("aImgSqr98").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr98").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQD24() {
    if(document.getElementById("aImgSqr99").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr99").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQD25() {
    if(document.getElementById("aImgSqr100").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr100").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
 };
};

function sqrQE1() {
    if(document.getElementById("aImgSqr101").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr101").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQE2() {
    if(document.getElementById("aImgSqr102").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr102").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQE3() {
    if(document.getElementById("aImgSqr103").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr103").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQE4() {
    if(document.getElementById("aImgSqr104").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr104").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQE5() {
    if(document.getElementById("aImgSqr105").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr105").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQE6() {
    if(document.getElementById("aImgSqr106").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr106").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQE7() {
    if(document.getElementById("aImgSqr107").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr107").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQE8() {
    if(document.getElementById("aImgSqr108").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr108").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQE9() {
    if(document.getElementById("aImgSqr109").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr109").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQE10() {
    if(document.getElementById("aImgSqr100").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr110").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQE11() {
    if(document.getElementById("aImgSqr111").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr111").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQE12() {
    if(document.getElementById("aImgSqr112").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr112").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQE13() {
    if(document.getElementById("aImgSqr113").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr113").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQE14() {
    if(document.getElementById("aImgSqr114").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr114").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQE15() {
    if(document.getElementById("aImgSqr115").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr115").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQE16() {
    if(document.getElementById("aImgSqr116").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr116").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQE17() {
    if(document.getElementById("aImgSqr117").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr117").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQE18() {
    if(document.getElementById("aImgSqr118").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr118").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQE19() {
    if(document.getElementById("aImgSqr119").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr119").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQE20() {
    if(document.getElementById("aImgSqr120").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr120").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQE21() {
    if(document.getElementById("aImgSqr121").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr121").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQE22() {
    if(document.getElementById("aImgSqr122").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr122").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQE23() {
    if(document.getElementById("aImgSqr123").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr123").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQE24() {
    if(document.getElementById("aImgSqr124").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr124").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQE25() {
    if(document.getElementById("aImgSqr125").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr125").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
 };
};

function sqrQF1() {
    if(document.getElementById("aImgSqr126").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr126").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQF2() {
    if(document.getElementById("aImgSqr127").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr127").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQF3() {
    if(document.getElementById("aImgSqr128").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr128").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQF4() {
    if(document.getElementById("aImgSqr129").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr129").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQF5() {
    if(document.getElementById("aImgSqr130").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr130").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQF6() {
    if(document.getElementById("aImgSqr131").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr131").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQF7() {
    if(document.getElementById("aImgSqr132").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr132").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQF8() {
    if(document.getElementById("aImgSqr133").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr133").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQF9() {
    if(document.getElementById("aImgSqr134").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr134").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQF10() {
    if(document.getElementById("aImgSqr135").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr135").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQF11() {
    if(document.getElementById("aImgSqr136").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr136").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQF12() {
    if(document.getElementById("aImgSqr137").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr137").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQF13() {
    if(document.getElementById("aImgSqr138").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr138").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQF14() {
    if(document.getElementById("aImgSqr139").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr139").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQF15() {
    if(document.getElementById("aImgSqr140").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr140").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQF16() {
    if(document.getElementById("aImgSqr141").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr141").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQF17() {
    if(document.getElementById("aImgSqr142").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr142").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQF18() {
    if(document.getElementById("aImgSqr143").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr143").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQF19() {
    if(document.getElementById("aImgSqr144").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr144").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQF20() {
    if(document.getElementById("aImgSqr145").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr145").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQF21() {
    if(document.getElementById("aImgSqr146").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr146").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQF22() {
    if(document.getElementById("aImgSqr147").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr147").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQF23() {
    if(document.getElementById("aImgSqr148").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr148").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQF24() {
    if(document.getElementById("aImgSqr149").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr149").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQF25() {
    if(document.getElementById("aImgSqr150").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr150").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
 };
};

function sqrQG1() {
    if(document.getElementById("aImgSqr151").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr151").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQG2() {
    if(document.getElementById("aImgSqr152").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr152").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQG3() {
    if(document.getElementById("aImgSqr153").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr153").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQG4() {
    if(document.getElementById("aImgSqr154").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr154").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQG5() {
    if(document.getElementById("aImgSqr155").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr155").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQG6() {
    if(document.getElementById("aImgSqr156").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr156").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQG7() {
    if(document.getElementById("aImgSqr157").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr157").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQG8() {
    if(document.getElementById("aImgSqr158").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr158").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQG9() {
    if(document.getElementById("aImgSqr159").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr159").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQG10() {
    if(document.getElementById("aImgSqr160").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr160").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQG11() {
    if(document.getElementById("aImgSqr161").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr161").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQG12() {
    if(document.getElementById("aImgSqr162").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr162").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQG13() {
    if(document.getElementById("aImgSqr163").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr163").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQG14() {
    if(document.getElementById("aImgSqr164").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr164").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQG15() {
    if(document.getElementById("aImgSqr165").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr165").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQG16() {
    if(document.getElementById("aImgSqr166").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr166").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQG17() {
    if(document.getElementById("aImgSqr167").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr167").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQG18() {
    if(document.getElementById("aImgSqr168").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr168").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQG19() {
    if(document.getElementById("aImgSqr169").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr169").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQG20() {
    if(document.getElementById("aImgSqr170").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr170").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQG21() {
    if(document.getElementById("aImgSqr171").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr171").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQG22() {
    if(document.getElementById("aImgSqr172").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr172").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQG23() {
    if(document.getElementById("aImgSqr173").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr173").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQG24() {
    if(document.getElementById("aImgSqr174").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr174").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQG25() {
    if(document.getElementById("aImgSqr175").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr175").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
 };
};

function sqrQH1() {
    if(document.getElementById("aImgSqr176").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr176").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQH2() {
    if(document.getElementById("aImgSqr177").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr177").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQH3() {
    if(document.getElementById("aImgSqr178").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr178").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQH4() {
    if(document.getElementById("aImgSqr179").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr179").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQH5() {
    if(document.getElementById("aImgSqr180").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr180").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQH6() {
    if(document.getElementById("aImgSqr181").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr181").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQH7() {
    if(document.getElementById("aImgSqr182").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr182").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQH8() {
    if(document.getElementById("aImgSqr183").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr183").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQH9() {
    if(document.getElementById("aImgSqr184").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr184").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQH10() {
    if(document.getElementById("aImgSqr185").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr185").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQH11() {
    if(document.getElementById("aImgSqr186").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr186").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQH12() {
    if(document.getElementById("aImgSqr187").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr187").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQH13() {
    if(document.getElementById("aImgSqr188").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr188").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQH14() {
    if(document.getElementById("aImgSqr189").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr189").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQH15() {
    if(document.getElementById("aImgSqr190").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr190").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQH16() {
    if(document.getElementById("aImgSqr191").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr191").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQH17() {
    if(document.getElementById("aImgSqr192").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr192").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQH18() {
    if(document.getElementById("aImgSqr193").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr193").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQH19() {
    if(document.getElementById("aImgSqr194").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr194").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQH20() {
    if(document.getElementById("aImgSqr195").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr195").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQH21() {
    if(document.getElementById("aImgSqr196").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr196").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQH22() {
    if(document.getElementById("aImgSqr197").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr197").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQH23() {
    if(document.getElementById("aImgSqr198").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr198").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQH24() {
    if(document.getElementById("aImgSqr199").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr199").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQH25() {
    if(document.getElementById("aImgSqr200").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr200").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
 };
};

function sqrQI1() {
    if(document.getElementById("aImgSqr201").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr201").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQI2() {
    if(document.getElementById("aImgSqr202").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr202").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQI3() {
    if(document.getElementById("aImgSqr203").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr203").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQI4() {
    if(document.getElementById("aImgSqr204").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr204").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQI5() {
    if(document.getElementById("aImgSqr205").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr205").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQI6() {
    if(document.getElementById("aImgSqr206").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr206").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQI7() {
    if(document.getElementById("aImgSqr207").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr207").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQI8() {
    if(document.getElementById("aImgSqr208").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr208").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQI9() {
    if(document.getElementById("aImgSqr209").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr209").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQI10() {
    if(document.getElementById("aImgSqr210").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr210").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQI11() {
    if(document.getElementById("aImgSqr211").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr211").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQI12() {
    if(document.getElementById("aImgSqr212").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr212").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQI13() {
    if(document.getElementById("aImgSqr213").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr213").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQI14() {
    if(document.getElementById("aImgSqr214").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr214").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQI15() {
    if(document.getElementById("aImgSqr215").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr215").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQI16() {
    if(document.getElementById("aImgSqr216").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr216").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQI17() {
    if(document.getElementById("aImgSqr217").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr217").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQI18() {
    if(document.getElementById("aImgSqr218").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr218").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQI19() {
    if(document.getElementById("aImgSqr219").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr219").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQI20() {
    if(document.getElementById("aImgSqr220").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr220").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQI21() {
    if(document.getElementById("aImgSqr221").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr221").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQI22() {
    if(document.getElementById("aImgSqr222").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr222").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQI23() {
    if(document.getElementById("aImgSqr223").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr223").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQI24() {
    if(document.getElementById("aImgSqr224").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr224").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQI25() {
    if(document.getElementById("aImgSqr225").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr225").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
 };
};

function sqrQJ1() {
    if(document.getElementById("aImgSqr226").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr226").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQJ2() {
    if(document.getElementById("aImgSqr227").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr227").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQJ3() {
    if(document.getElementById("aImgSqr228").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr228").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQJ4() {
    if(document.getElementById("aImgSqr229").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr229").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQJ5() {
    if(document.getElementById("aImgSqr230").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr230").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQJ6() {
    if(document.getElementById("aImgSqr231").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr231").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQJ7() {
    if(document.getElementById("aImgSqr232").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr232").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQJ8() {
    if(document.getElementById("aImgSqr233").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr233").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQJ9() {
    if(document.getElementById("aImgSqr234").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr234").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQJ10() {
    if(document.getElementById("aImgSqr235").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr235").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQJ11() {
    if(document.getElementById("aImgSqr236").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr236").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQJ12() {
    if(document.getElementById("aImgSqr237").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr237").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQJ13() {
    if(document.getElementById("aImgSqr238").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr238").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQJ14() {
    if(document.getElementById("aImgSqr239").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr239").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQJ15() {
    if(document.getElementById("aImgSqr240").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr240").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQJ16() {
    if(document.getElementById("aImgSqr241").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr241").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQJ17() {
    if(document.getElementById("aImgSqr242").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr242").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQJ18() {
    if(document.getElementById("aImgSqr243").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr243").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQJ19() {
    if(document.getElementById("aImgSqr244").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr244").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQJ20() {
    if(document.getElementById("aImgSqr245").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr245").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQJ21() {
    if(document.getElementById("aImgSqr246").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr246").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQJ22() {
    if(document.getElementById("aImgSqr247").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr247").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQJ23() {
    if(document.getElementById("aImgSqr248").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr248").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQJ24() {
    if(document.getElementById("aImgSqr249").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr249").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQJ25() {
    if(document.getElementById("aImgSqr250").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr250").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
 };
};

function sqrQK1() {
    if(document.getElementById("aImgSqr251").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr251").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQK2() {
    if(document.getElementById("aImgSqr252").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr252").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQK3() {
    if(document.getElementById("aImgSqr253").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr253").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQK4() {
    if(document.getElementById("aImgSqr254").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr254").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQK5() {
    if(document.getElementById("aImgSqr255").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr255").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQK6() {
    if(document.getElementById("aImgSqr256").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr256").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQK7() {
    if(document.getElementById("aImgSqr257").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr257").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQK8() {
    if(document.getElementById("aImgSqr258").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr258").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQK9() {
    if(document.getElementById("aImgSqr259").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr259").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQK10() {
    if(document.getElementById("aImgSqr260").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr260").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQK11() {
    if(document.getElementById("aImgSqr261").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr261").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQK12() {
    if(document.getElementById("aImgSqr262").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr262").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQK13() {
    if(document.getElementById("aImgSqr263").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr263").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQK14() {
    if(document.getElementById("aImgSqr264").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr264").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQK15() {
    if(document.getElementById("aImgSqr265").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr265").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQK16() {
    if(document.getElementById("aImgSqr266").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr266").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQK17() {
    if(document.getElementById("aImgSqr267").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr267").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQK18() {
    if(document.getElementById("aImgSqr268").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr268").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQK19() {
    if(document.getElementById("aImgSqr269").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr269").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQK20() {
    if(document.getElementById("aImgSqr270").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr270").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQK21() {
    if(document.getElementById("aImgSqr271").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr271").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQK22() {
    if(document.getElementById("aImgSqr272").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr272").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQK23() {
    if(document.getElementById("aImgSqr273").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr273").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQK24() {
    if(document.getElementById("aImgSqr274").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr274").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQK25() {
    if(document.getElementById("aImgSqr275").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr275").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
 };
};

function sqrQL1() {
    if(document.getElementById("aImgSqr276").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr276").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQL2() {
    if(document.getElementById("aImgSqr277").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr277").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQL3() {
    if(document.getElementById("aImgSqr278").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr278").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQL4() {
    if(document.getElementById("aImgSqr279").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr279").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQL5() {
    if(document.getElementById("aImgSqr280").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr280").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQL6() {
    if(document.getElementById("aImgSqr281").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr281").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQL7() {
    if(document.getElementById("aImgSqr282").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr282").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQL8() {
    if(document.getElementById("aImgSqr283").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr283").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQL9() {
    if(document.getElementById("aImgSqr284").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr284").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQL10() {
    if(document.getElementById("aImgSqr285").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr285").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQL11() {
    if(document.getElementById("aImgSqr286").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr286").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQL12() {
    if(document.getElementById("aImgSqr287").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr287").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQL13() {
    if(document.getElementById("aImgSqr288").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr288").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQL14() {
    if(document.getElementById("aImgSqr289").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr289").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQL15() {
    if(document.getElementById("aImgSqr290").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr290").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQL16() {
    if(document.getElementById("aImgSqr291").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr291").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQL17() {
    if(document.getElementById("aImgSqr292").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr292").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQL18() {
    if(document.getElementById("aImgSqr293").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr293").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQL19() {
    if(document.getElementById("aImgSqr294").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr294").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQL20() {
    if(document.getElementById("aImgSqr295").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr295").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQL21() {
    if(document.getElementById("aImgSqr296").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr296").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQL22() {
    if(document.getElementById("aImgSqr297").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr297").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQL23() {
    if(document.getElementById("aImgSqr298").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr298").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQL24() {
    if(document.getElementById("aImgSqr299").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr299").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQL25() {
    if(document.getElementById("aImgSqr300").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr300").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
 };
};

function sqrQM1() {
    if(document.getElementById("aImgSqr301").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr301").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQM2() {
    if(document.getElementById("aImgSqr302").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr302").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQM3() {
    if(document.getElementById("aImgSqr303").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr303").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQM4() {
    if(document.getElementById("aImgSqr304").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr304").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQM5() {
    if(document.getElementById("aImgSqr305").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr305").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQM6() {
    if(document.getElementById("aImgSqr306").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr306").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQM7() {
    if(document.getElementById("aImgSqr307").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr307").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQM8() {
    if(document.getElementById("aImgSqr308").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr308").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQM9() {
    if(document.getElementById("aImgSqr309").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr309").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQM10() {
    if(document.getElementById("aImgSqr310").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr310").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQM11() {
    if(document.getElementById("aImgSqr311").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr311").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQM12() {
    if(document.getElementById("aImgSqr312").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr312").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQM13() {
    if(document.getElementById("aImgSqr313").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr313").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQM14() {
    if(document.getElementById("aImgSqr314").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr314").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQM15() {
    if(document.getElementById("aImgSqr315").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr315").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQM16() {
    if(document.getElementById("aImgSqr316").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr316").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQM17() {
    if(document.getElementById("aImgSqr317").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr317").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQM18() {
    if(document.getElementById("aImgSqr318").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr318").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQM19() {
    if(document.getElementById("aImgSqr319").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr319").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQM20() {
    if(document.getElementById("aImgSqr320").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr320").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQM21() {
    if(document.getElementById("aImgSqr321").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr321").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQM22() {
    if(document.getElementById("aImgSqr322").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr322").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQM23() {
    if(document.getElementById("aImgSqr323").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr323").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQM24() {
    if(document.getElementById("aImgSqr324").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr324").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQM25() {
    if(document.getElementById("aImgSqr325").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr325").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
 };
};

function sqrQN1() {
    if(document.getElementById("aImgSqr326").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr326").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQN2() {
    if(document.getElementById("aImgSqr327").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr327").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQN3() {
    if(document.getElementById("aImgSqr328").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr328").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQN4() {
    if(document.getElementById("aImgSqr329").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr329").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQN5() {
    if(document.getElementById("aImgSqr330").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr330").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQN6() {
    if(document.getElementById("aImgSqr331").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr331").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQN7() {
    if(document.getElementById("aImgSqr332").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr332").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQN8() {
    if(document.getElementById("aImgSqr333").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr333").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQN9() {
    if(document.getElementById("aImgSqr334").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr334").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQN10() {
    if(document.getElementById("aImgSqr335").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr335").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQN11() {
    if(document.getElementById("aImgSqr336").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr336").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQN12() {
    if(document.getElementById("aImgSqr337").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr337").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQN13() {
    if(document.getElementById("aImgSqr338").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr338").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQN14() {
    if(document.getElementById("aImgSqr339").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr339").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQN15() {
    if(document.getElementById("aImgSqr340").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr340").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQN16() {
    if(document.getElementById("aImgSqr341").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr341").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQN17() {
    if(document.getElementById("aImgSqr342").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr342").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQN18() {
    if(document.getElementById("aImgSqr343").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr343").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQN19() {
    if(document.getElementById("aImgSqr344").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr344").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQN20() {
    if(document.getElementById("aImgSqr345").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr345").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQN21() {
    if(document.getElementById("aImgSqr346").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr346").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQN22() {
    if(document.getElementById("aImgSqr347").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr347").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQN23() {
    if(document.getElementById("aImgSqr348").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr348").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQN24() {
    if(document.getElementById("aImgSqr349").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr349").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQN25() {
    if(document.getElementById("aImgSqr350").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr350").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
 };
};

function sqrQO1() {
    if(document.getElementById("aImgSqr351").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr351").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQO2() {
    if(document.getElementById("aImgSqr352").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr352").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQO3() {
    if(document.getElementById("aImgSqr353").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr353").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQO4() {
    if(document.getElementById("aImgSqr354").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr354").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQO5() {
    if(document.getElementById("aImgSqr355").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr355").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQO6() {
    if(document.getElementById("aImgSqr356").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr356").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQO7() {
    if(document.getElementById("aImgSqr357").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr357").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQO8() {
    if(document.getElementById("aImgSqr358").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr358").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQO9() {
    if(document.getElementById("aImgSqr359").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr359").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQO10() {
    if(document.getElementById("aImgSqr360").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr360").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQO11() {
    if(document.getElementById("aImgSqr361").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr361").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQO12() {
    if(document.getElementById("aImgSqr362").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr362").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQO13() {
    if(document.getElementById("aImgSqr363").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr363").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQO14() {
    if(document.getElementById("aImgSqr364").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr364").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQO15() {
    if(document.getElementById("aImgSqr365").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr365").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQO16() {
    if(document.getElementById("aImgSqr366").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr366").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQO17() {
    if(document.getElementById("aImgSqr367").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr367").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQO18() {
    if(document.getElementById("aImgSqr368").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr368").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQO19() {
    if(document.getElementById("aImgSqr369").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr369").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQO20() {
    if(document.getElementById("aImgSqr370").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr370").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQO21() {
    if(document.getElementById("aImgSqr371").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr371").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQO22() {
    if(document.getElementById("aImgSqr372").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr372").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQO23() {
    if(document.getElementById("aImgSqr373").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr373").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQO24() {
    if(document.getElementById("aImgSqr374").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr374").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQO25() {
    if(document.getElementById("aImgSqr375").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr375").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
 };
};

function sqrQP1() {
    if(document.getElementById("aImgSqr376").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr376").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQP2() {
    if(document.getElementById("aImgSqr377").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr377").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQP3() {
    if(document.getElementById("aImgSqr378").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr378").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQP4() {
    if(document.getElementById("aImgSqr379").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr379").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQP5() {
    if(document.getElementById("aImgSqr380").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr380").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQP6() {
    if(document.getElementById("aImgSqr381").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr381").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQP7() {
    if(document.getElementById("aImgSqr382").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr382").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQP8() {
    if(document.getElementById("aImgSqr383").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr383").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQP9() {
    if(document.getElementById("aImgSqr384").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr384").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQP10() {
    if(document.getElementById("aImgSqr385").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr385").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQP11() {
    if(document.getElementById("aImgSqr386").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr386").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQP12() {
    if(document.getElementById("aImgSqr387").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr387").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQP13() {
    if(document.getElementById("aImgSqr388").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr388").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQP14() {
    if(document.getElementById("aImgSqr389").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr389").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQP15() {
    if(document.getElementById("aImgSqr390").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr390").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQP16() {
    if(document.getElementById("aImgSqr391").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr391").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQP17() {
    if(document.getElementById("aImgSqr392").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr392").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQP18() {
    if(document.getElementById("aImgSqr393").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr393").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQP19() {
    if(document.getElementById("aImgSqr394").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr394").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQP20() {
    if(document.getElementById("aImgSqr395").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr395").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQP21() {
    if(document.getElementById("aImgSqr396").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr396").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQP22() {
    if(document.getElementById("aImgSqr397").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr397").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQP23() {
    if(document.getElementById("aImgSqr398").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr398").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQP24() {
    if(document.getElementById("aImgSqr399").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr399").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQP25() {
    if(document.getElementById("aImgSqr400").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr400").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
 };
};

function sqrQQ1() {
    if(document.getElementById("aImgSqr401").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr401").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQQ2() {
    if(document.getElementById("aImgSqr402").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr402").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQQ3() {
    if(document.getElementById("aImgSqr403").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr403").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQQ4() {
    if(document.getElementById("aImgSqr404").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr404").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQQ5() {
    if(document.getElementById("aImgSqr405").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr405").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQQ6() {
    if(document.getElementById("aImgSqr406").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr406").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQQ7() {
    if(document.getElementById("aImgSqr407").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr407").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQQ8() {
    if(document.getElementById("aImgSqr408").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr408").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQQ9() {
    if(document.getElementById("aImgSqr409").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr409").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQQ10() {
    if(document.getElementById("aImgSqr410").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr410").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQQ11() {
    if(document.getElementById("aImgSqr411").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr411").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQQ12() {
    if(document.getElementById("aImgSqr412").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr412").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQQ13() {
    if(document.getElementById("aImgSqr413").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr413").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQQ14() {
    if(document.getElementById("aImgSqr414").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr414").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQQ15() {
    if(document.getElementById("aImgSqr415").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr415").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQQ16() {
    if(document.getElementById("aImgSqr416").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr416").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQQ17() {
    if(document.getElementById("aImgSqr417").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr417").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQQ18() {
    if(document.getElementById("aImgSqr418").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr418").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQQ19() {
    if(document.getElementById("aImgSqr419").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr419").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQQ20() {
    if(document.getElementById("aImgSqr420").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr420").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQQ21() {
    if(document.getElementById("aImgSqr421").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr421").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQQ22() {
    if(document.getElementById("aImgSqr422").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr422").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQQ23() {
    if(document.getElementById("aImgSqr423").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr423").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQQ24() {
    if(document.getElementById("aImgSqr424").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr424").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQQ25() {
    if(document.getElementById("aImgSqr425").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr425").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
 };
};

function sqrQR1() {
    if(document.getElementById("aImgSqr426").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr426").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQR2() {
    if(document.getElementById("aImgSqr427").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr427").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQR3() {
    if(document.getElementById("aImgSqr428").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr428").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQR4() {
    if(document.getElementById("aImgSqr429").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr429").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQR5() {
    if(document.getElementById("aImgSqr430").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr430").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQR6() {
    if(document.getElementById("aImgSqr431").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr431").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQR7() {
    if(document.getElementById("aImgSqr432").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr432").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQR8() {
    if(document.getElementById("aImgSqr433").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr433").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQR9() {
    if(document.getElementById("aImgSqr434").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr434").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQR10() {
    if(document.getElementById("aImgSqr435").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr435").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQR11() {
    if(document.getElementById("aImgSqr436").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr436").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQR12() {
    if(document.getElementById("aImgSqr437").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr437").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQR13() {
    if(document.getElementById("aImgSqr438").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr438").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQR14() {
    if(document.getElementById("aImgSqr439").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr439").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQR15() {
    if(document.getElementById("aImgSqr440").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr440").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQR16() {
    if(document.getElementById("aImgSqr441").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr441").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQR17() {
    if(document.getElementById("aImgSqr442").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr442").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQR18() {
    if(document.getElementById("aImgSqr443").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr443").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQR19() {
    if(document.getElementById("aImgSqr444").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr444").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQR20() {
    if(document.getElementById("aImgSqr445").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr445").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQR21() {
    if(document.getElementById("aImgSqr446").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr446").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQR22() {
    if(document.getElementById("aImgSqr447").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr447").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQR23() {
    if(document.getElementById("aImgSqr448").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr448").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQR24() {
    if(document.getElementById("aImgSqr449").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr449").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQR25() {
    if(document.getElementById("aImgSqr450").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr450").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
 };
};

function sqrQS1() {
    if(document.getElementById("aImgSqr451").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr451").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQS2() {
    if(document.getElementById("aImgSqr452").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr452").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQS3() {
    if(document.getElementById("aImgSqr453").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr453").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQS4() {
    if(document.getElementById("aImgSqr454").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr454").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQS5() {
    if(document.getElementById("aImgSqr455").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr455").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQS6() {
    if(document.getElementById("aImgSqr456").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr456").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQS7() {
    if(document.getElementById("aImgSqr457").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr457").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQS8() {
    if(document.getElementById("aImgSqr458").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr458").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQS9() {
    if(document.getElementById("aImgSqr459").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr459").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQS10() {
    if(document.getElementById("aImgSqr460").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr460").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQS11() {
    if(document.getElementById("aImgSqr461").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr461").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQS12() {
    if(document.getElementById("aImgSqr462").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr462").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQS13() {
    if(document.getElementById("aImgSqr463").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr463").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQS14() {
    if(document.getElementById("aImgSqr464").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr464").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQS15() {
    if(document.getElementById("aImgSqr465").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr465").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQS16() {
    if(document.getElementById("aImgSqr466").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr466").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQS17() {
    if(document.getElementById("aImgSqr467").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr467").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQS18() {
    if(document.getElementById("aImgSqr468").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr468").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQS19() {
    if(document.getElementById("aImgSqr469").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr469").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQS20() {
    if(document.getElementById("aImgSqr470").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr470").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQS21() {
    if(document.getElementById("aImgSqr471").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr471").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQS22() {
    if(document.getElementById("aImgSqr472").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr472").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQS23() {
    if(document.getElementById("aImgSqr473").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr473").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQS24() {
    if(document.getElementById("aImgSqr474").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr474").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQS25() {
    if(document.getElementById("aImgSqr475").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr475").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
 };
};

function sqrQT1() {
    if(document.getElementById("aImgSqr476").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr476").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQT2() {
    if(document.getElementById("aImgSqr477").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr477").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQT3() {
    if(document.getElementById("aImgSqr478").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr478").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQT4() {
    if(document.getElementById("aImgSqr479").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr479").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQT5() {
    if(document.getElementById("aImgSqr480").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr480").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQT6() {
    if(document.getElementById("aImgSqr481").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr481").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQT7() {
    if(document.getElementById("aImgSqr482").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr482").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQT8() {
    if(document.getElementById("aImgSqr483").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr483").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQT9() {
    if(document.getElementById("aImgSqr484").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr484").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQT10() {
    if(document.getElementById("aImgSqr485").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr485").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQT11() {
    if(document.getElementById("aImgSqr486").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr486").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQT12() {
    if(document.getElementById("aImgSqr487").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr487").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQT13() {
    if(document.getElementById("aImgSqr488").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr488").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQT14() {
    if(document.getElementById("aImgSqr489").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr489").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQT15() {
    if(document.getElementById("aImgSqr490").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr490").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQT16() {
    if(document.getElementById("aImgSqr491").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr491").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQT17() {
    if(document.getElementById("aImgSqr492").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr492").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQT18() {
    if(document.getElementById("aImgSqr493").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr493").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQT19() {
    if(document.getElementById("aImgSqr494").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr494").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQT20() {
    if(document.getElementById("aImgSqr495").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr495").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQT21() {
    if(document.getElementById("aImgSqr496").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr496").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQT22() {
    if(document.getElementById("aImgSqr497").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr497").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQT23() {
    if(document.getElementById("aImgSqr498").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr498").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQT24() {
    if(document.getElementById("aImgSqr499").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr499").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQT25() {
    if(document.getElementById("aImgSqr500").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr500").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
 };
};

function sqrQU1() {
    if(document.getElementById("aImgSqr501").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr501").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQU2() {
    if(document.getElementById("aImgSqr502").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr502").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQU3() {
    if(document.getElementById("aImgSqr503").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr503").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQU4() {
    if(document.getElementById("aImgSqr504").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr504").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQU5() {
    if(document.getElementById("aImgSqr505").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr505").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQU6() {
    if(document.getElementById("aImgSqr506").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr506").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQU7() {
    if(document.getElementById("aImgSqr507").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr507").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQU8() {
    if(document.getElementById("aImgSqr508").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr508").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQU9() {
    if(document.getElementById("aImgSqr509").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr509").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQU10() {
    if(document.getElementById("aImgSqr510").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr510").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQU11() {
    if(document.getElementById("aImgSqr511").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr511").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQU12() {
    if(document.getElementById("aImgSqr512").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr512").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQU13() {
    if(document.getElementById("aImgSqr513").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr513").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQU14() {
    if(document.getElementById("aImgSqr514").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr514").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQU15() {
    if(document.getElementById("aImgSqr515").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr515").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQU16() {
    if(document.getElementById("aImgSqr516").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr516").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQU17() {
    if(document.getElementById("aImgSqr517").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr517").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQU18() {
    if(document.getElementById("aImgSqr518").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr518").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQU19() {
    if(document.getElementById("aImgSqr519").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr519").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQU20() {
    if(document.getElementById("aImgSqr520").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr520").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQU21() {
    if(document.getElementById("aImgSqr521").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr521").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQU22() {
    if(document.getElementById("aImgSqr522").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr522").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQU23() {
    if(document.getElementById("aImgSqr523").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr523").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQU24() {
    if(document.getElementById("aImgSqr524").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr524").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQU25() {
    if(document.getElementById("aImgSqr525").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr525").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
 };
};

function sqrQV1() {
    if(document.getElementById("aImgSqr526").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr526").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQV2() {
    if(document.getElementById("aImgSqr527").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr527").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQV3() {
    if(document.getElementById("aImgSqr528").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr528").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQV4() {
    if(document.getElementById("aImgSqr529").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr529").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQV5() {
    if(document.getElementById("aImgSqr530").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr530").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQV6() {
    if(document.getElementById("aImgSqr531").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr531").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQV7() {
    if(document.getElementById("aImgSqr532").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr532").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQV8() {
    if(document.getElementById("aImgSqr533").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr533").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQV9() {
    if(document.getElementById("aImgSqr534").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr534").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQV10() {
    if(document.getElementById("aImgSqr535").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr535").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQV11() {
    if(document.getElementById("aImgSqr536").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr536").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQV12() {
    if(document.getElementById("aImgSqr537").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr537").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQV13() {
    if(document.getElementById("aImgSqr538").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr538").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQV14() {
    if(document.getElementById("aImgSqr539").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr539").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQV15() {
    if(document.getElementById("aImgSqr540").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr540").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQV16() {
    if(document.getElementById("aImgSqr541").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr541").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQV17() {
    if(document.getElementById("aImgSqr542").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr542").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQV18() {
    if(document.getElementById("aImgSqr543").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr543").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQV19() {
    if(document.getElementById("aImgSqr544").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr544").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQV20() {
    if(document.getElementById("aImgSqr545").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr545").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQV21() {
    if(document.getElementById("aImgSqr546").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr546").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQV22() {
    if(document.getElementById("aImgSqr547").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr547").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQV23() {
    if(document.getElementById("aImgSqr548").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr548").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQV24() {
    if(document.getElementById("aImgSqr549").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr549").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQV25() {
    if(document.getElementById("aImgSqr550").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr550").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
 };
};

function sqrQW1() {
    if(document.getElementById("aImgSqr551").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr551").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQW2() {
    if(document.getElementById("aImgSqr552").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr552").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQW3() {
    if(document.getElementById("aImgSqr553").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr553").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQW4() {
    if(document.getElementById("aImgSqr554").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr554").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQW5() {
    if(document.getElementById("aImgSqr555").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr555").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQW6() {
    if(document.getElementById("aImgSqr556").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr556").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQW7() {
    if(document.getElementById("aImgSqr557").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr557").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQW8() {
    if(document.getElementById("aImgSqr558").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr558").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQW9() {
    if(document.getElementById("aImgSqr559").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr559").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQW10() {
    if(document.getElementById("aImgSqr560").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr560").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQW11() {
    if(document.getElementById("aImgSqr561").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr561").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQW12() {
    if(document.getElementById("aImgSqr562").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr562").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQW13() {
    if(document.getElementById("aImgSqr563").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr563").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQW14() {
    if(document.getElementById("aImgSqr564").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr564").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQW15() {
    if(document.getElementById("aImgSqr565").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr565").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQW16() {
    if(document.getElementById("aImgSqr566").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr566").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQW17() {
    if(document.getElementById("aImgSqr567").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr567").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQW18() {
    if(document.getElementById("aImgSqr568").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr568").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQW19() {
    if(document.getElementById("aImgSqr569").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr569").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQW20() {
    if(document.getElementById("aImgSqr570").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr570").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQW21() {
    if(document.getElementById("aImgSqr571").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr571").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQW22() {
    if(document.getElementById("aImgSqr572").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr572").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQW23() {
    if(document.getElementById("aImgSqr573").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr573").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQW24() {
    if(document.getElementById("aImgSqr574").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr574").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQW25() {
    if(document.getElementById("aImgSqr575").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr575").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
 };
};

function sqrQX1() {
    if(document.getElementById("aImgSqr576").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr576").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQX2() {
    if(document.getElementById("aImgSqr577").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr577").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQX3() {
    if(document.getElementById("aImgSqr578").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr578").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQX4() {
    if(document.getElementById("aImgSqr579").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr579").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQX5() {
    if(document.getElementById("aImgSqr580").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr580").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQX6() {
    if(document.getElementById("aImgSqr581").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr581").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQX7() {
    if(document.getElementById("aImgSqr582").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr582").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQX8() {
    if(document.getElementById("aImgSqr583").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr583").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQX9() {
    if(document.getElementById("aImgSqr584").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr584").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQX10() {
    if(document.getElementById("aImgSqr585").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr585").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQX11() {
    if(document.getElementById("aImgSqr586").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr586").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQX12() {
    if(document.getElementById("aImgSqr587").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr587").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQX13() {
    if(document.getElementById("aImgSqr588").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr588").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQX14() {
    if(document.getElementById("aImgSqr589").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr589").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQX15() {
    if(document.getElementById("aImgSqr590").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr590").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQX16() {
    if(document.getElementById("aImgSqr591").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr591").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQX17() {
    if(document.getElementById("aImgSqr592").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr592").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQX18() {
    if(document.getElementById("aImgSqr593").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr593").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQX19() {
    if(document.getElementById("aImgSqr594").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr594").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQX20() {
    if(document.getElementById("aImgSqr595").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr595").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQX21() {
    if(document.getElementById("aImgSqr596").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr596").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQX22() {
    if(document.getElementById("aImgSqr597").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr597").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQX23() {
    if(document.getElementById("aImgSqr598").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr598").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQX24() {
    if(document.getElementById("aImgSqr599").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr599").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQX25() {
    if(document.getElementById("aImgSqr600").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("aImgSqr600").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
 };
};

function sqrQY1() {
    if(document.getElementById("aImgSqr601").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr601").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQY2() {
    if(document.getElementById("aImgSqr602").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr602").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQY3() {
    if(document.getElementById("aImgSqr603").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr603").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQY4() {
    if(document.getElementById("aImgSqr604").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr604").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQY5() {
    if(document.getElementById("aImgSqr605").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr605").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQY6() {
    if(document.getElementById("aImgSqr606").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr606").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQY7() {
    if(document.getElementById("aImgSqr607").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr607").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQY8() {
    if(document.getElementById("aImgSqr608").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr608").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQY9() {
    if(document.getElementById("aImgSqr609").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr609").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQY10() {
    if(document.getElementById("aImgSqr610").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr610").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQY11() {
    if(document.getElementById("aImgSqr611").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr611").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQY12() {
    if(document.getElementById("aImgSqr612").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr612").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQY13() {
    if(document.getElementById("aImgSqr613").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr613").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQY14() {
    if(document.getElementById("aImgSqr614").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr614").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQY15() {
    if(document.getElementById("aImgSqr615").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr615").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQY16() {
    if(document.getElementById("aImgSqr616").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr616").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQY17() {
    if(document.getElementById("aImgSqr617").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr617").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQY18() {
    if(document.getElementById("aImgSqr618").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr618").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQY19() {
    if(document.getElementById("aImgSqr619").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr619").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQY20() {
    if(document.getElementById("aImgSqr620").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr620").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};
};

function sqrQY21() {
    if(document.getElementById("aImgSqr621").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr621").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQY22() {
    if(document.getElementById("aImgSqr622").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr622").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQY23() {
    if(document.getElementById("aImgSqr623").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr623").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQY24() {
    if(document.getElementById("aImgSqr624").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr624").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQY25() {
    if(document.getElementById("aImgSqr625").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("aImgSqr625").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};
};

function sqrQA1b() {
    if(document.getElementById("aImgSqr1").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr1").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQA2b() {
    if(document.getElementById("aImgSqr2").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr2").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQA3b() {
    if(document.getElementById("aImgSqr3").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr3").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQA4b() {
    if(document.getElementById("aImgSqr4").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr4").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQA5b() {
    if(document.getElementById("aImgSqr5").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr5").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQA6b() {
    if(document.getElementById("aImgSqr6").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr6").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQA7b() {
    if(document.getElementById("aImgSqr7").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr7").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQA8b() {
    if(document.getElementById("aImgSqr8").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr8").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQA9b() {
    if(document.getElementById("aImgSqr9").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr9").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQA10b() {
    if(document.getElementById("aImgSqr10").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr10").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQA11b() {
    if(document.getElementById("aImgSqr11").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr11").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQA12b() {
    if(document.getElementById("aImgSqr12").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr12").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQA13b() {
    if(document.getElementById("aImgSqr13").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr13").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQA14b() {
    if(document.getElementById("aImgSqr14").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr14").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQA15b() {
    if(document.getElementById("aImgSqr15").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr15").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQA16b() {
    if(document.getElementById("aImgSqr16").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr16").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQA17b() {
    if(document.getElementById("aImgSqr17").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr17").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQA18b() {
    if(document.getElementById("aImgSqr18").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr18").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQA19b() {
    if(document.getElementById("aImgSqr19").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr19").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQA20b() {
    if(document.getElementById("aImgSqr20").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr20").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQA21b() {
    if(document.getElementById("aImgSqr21").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr21").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQA22b() {
    if(document.getElementById("aImgSqr22").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr22").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQA23b() {
    if(document.getElementById("aImgSqr23").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr23").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQA24b() {
    if(document.getElementById("aImgSqr24").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr24").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQA25b() {
    if(document.getElementById("aImgSqr25").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr25").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
 };
};

function sqrQB1b() {
    if(document.getElementById("aImgSqr26").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr26").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQB2b() {
    if(document.getElementById("aImgSqr27").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr27").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQB3b() {
    if(document.getElementById("aImgSqr28").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr28").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQB4b() {
    if(document.getElementById("aImgSqr29").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr29").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQB5b() {
    if(document.getElementById("aImgSqr30").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr30").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQB6b() {
    if(document.getElementById("aImgSqr31").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr31").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQB7b() {
    if(document.getElementById("aImgSqr32").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr32").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQB8b() {
    if(document.getElementById("aImgSqr33").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr33").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQB9b() {
    if(document.getElementById("aImgSqr34").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr34").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQB10b() {
    if(document.getElementById("aImgSqr35").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr35").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQB11b() {
    if(document.getElementById("aImgSqr36").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr36").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQB12b() {
    if(document.getElementById("aImgSqr37").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr37").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQB13b() {
    if(document.getElementById("aImgSqr38").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr38").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQB14b() {
    if(document.getElementById("aImgSqr39").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr39").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQB15b() {
    if(document.getElementById("aImgSqr40").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr40").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQB16b() {
    if(document.getElementById("aImgSqr41").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr41").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQB17b() {
    if(document.getElementById("aImgSqr42").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr42").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQB18b() {
    if(document.getElementById("aImgSqr43").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr43").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQB19b() {
    if(document.getElementById("aImgSqr44").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr44").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQB20b() {
    if(document.getElementById("aImgSqr45").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr45").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQB21b() {
    if(document.getElementById("aImgSqr46").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr46").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQB22b() {
    if(document.getElementById("aImgSqr47").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr47").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQB23b() {
    if(document.getElementById("aImgSqr48").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr48").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQB24b() {
    if(document.getElementById("aImgSqr49").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr49").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQB25b() {
    if(document.getElementById("aImgSqr50").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr50").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQC1b() {
    if(document.getElementById("aImgSqr51").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr51").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQC2b() {
    if(document.getElementById("aImgSqr52").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr52").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQC3b() {
    if(document.getElementById("aImgSqr53").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr53").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQC4b() {
    if(document.getElementById("aImgSqr54").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr54").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQC5b() {
    if(document.getElementById("aImgSqr55").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr55").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQC6b() {
    if(document.getElementById("aImgSqr56").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr56").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQC7b() {
    if(document.getElementById("aImgSqr57").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr57").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQC8b() {
    if(document.getElementById("aImgSqr58").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr58").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQC9b() {
    if(document.getElementById("aImgSqr59").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr59").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQC10b() {
    if(document.getElementById("aImgSqr60").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr60").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQC11b() {
    if(document.getElementById("aImgSqr61").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr61").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQC12b() {
    if(document.getElementById("aImgSqr62").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr62").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQC13b() {
    if(document.getElementById("aImgSqr63").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr63").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQC14b() {
    if(document.getElementById("aImgSqr64").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr64").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQC15b() {
    if(document.getElementById("aImgSqr65").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr65").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQC16b() {
    if(document.getElementById("aImgSqr66").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr66").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQC17b() {
    if(document.getElementById("aImgSqr67").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr67").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQC18b() {
    if(document.getElementById("aImgSqr68").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr68").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQC19b() {
    if(document.getElementById("aImgSqr69").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr69").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQC20b() {
    if(document.getElementById("aImgSqr70").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr70").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQC21b() {
    if(document.getElementById("aImgSqr71").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr71").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQC22b() {
    if(document.getElementById("aImgSqr72").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr72").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQC23b() {
    if(document.getElementById("aImgSqr73").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr73").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQC24b() {
    if(document.getElementById("aImgSqr74").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr74").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQC25b() {
    if(document.getElementById("aImgSqr75").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr75").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
 };
};

function sqrQD1b() {
    if(document.getElementById("aImgSqr76").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr76").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQD2b() {
    if(document.getElementById("aImgSqr77").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr77").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQD3b() {
    if(document.getElementById("aImgSqr78").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr78").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQD4b() {
    if(document.getElementById("aImgSqr79").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr79").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQD5b() {
    if(document.getElementById("aImgSqr80").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr80").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQD6b() {
    if(document.getElementById("aImgSqr81").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr81").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQD7b() {
    if(document.getElementById("aImgSqr82").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr82").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQD8b() {
    if(document.getElementById("aImgSqr83").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr83").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQD9b() {
    if(document.getElementById("aImgSqr84").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr84").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQD10b() {
    if(document.getElementById("aImgSqr85").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr85").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQD11b() {
    if(document.getElementById("aImgSqr86").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr86").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQD12b() {
    if(document.getElementById("aImgSqr87").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr87").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQD13b() {
    if(document.getElementById("aImgSqr88").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr88").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQD14b() {
    if(document.getElementById("aImgSqr89").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr89").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQD15b() {
    if(document.getElementById("aImgSqr90").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr90").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQD16b() {
    if(document.getElementById("aImgSqr91").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr91").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQD17b() {
    if(document.getElementById("aImgSqr92").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr92").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQD18b() {
    if(document.getElementById("aImgSqr93").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr93").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQD19b() {
    if(document.getElementById("aImgSqr94").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr94").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQD20b() {
    if(document.getElementById("aImgSqr95").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr95").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQD21b() {
    if(document.getElementById("aImgSqr96").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr96").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQD22b() {
    if(document.getElementById("aImgSqr97").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr97").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQD23b() {
    if(document.getElementById("aImgSqr98").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr98").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQD24b() {
    if(document.getElementById("aImgSqr99").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr99").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQD25b() {
    if(document.getElementById("aImgSqr100").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr100").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
 };
};

function sqrQE1b() {
    if(document.getElementById("aImgSqr101").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr101").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQE2b() {
    if(document.getElementById("aImgSqr102").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr102").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQE3b() {
    if(document.getElementById("aImgSqr103").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr103").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQE4b() {
    if(document.getElementById("aImgSqr104").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr104").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQE5b() {
    if(document.getElementById("aImgSqr105").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr105").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQE6b() {
    if(document.getElementById("aImgSqr106").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr106").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQE7b() {
    if(document.getElementById("aImgSqr107").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr107").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQE8b() {
    if(document.getElementById("aImgSqr108").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr108").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQE9b() {
    if(document.getElementById("aImgSqr109").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr109").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQE10b() {
    if(document.getElementById("aImgSqr100").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr110").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQE11b() {
    if(document.getElementById("aImgSqr111").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr111").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQE12b() {
    if(document.getElementById("aImgSqr112").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr112").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQE13b() {
    if(document.getElementById("aImgSqr113").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr113").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQE14b() {
    if(document.getElementById("aImgSqr114").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr114").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQE15b() {
    if(document.getElementById("aImgSqr115").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr115").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQE16b() {
    if(document.getElementById("aImgSqr116").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr116").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQE17b() {
    if(document.getElementById("aImgSqr117").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr117").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQE18b() {
    if(document.getElementById("aImgSqr118").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr118").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQE19b() {
    if(document.getElementById("aImgSqr119").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr119").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQE20b() {
    if(document.getElementById("aImgSqr120").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr120").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQE21b() {
    if(document.getElementById("aImgSqr121").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr121").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQE22b() {
    if(document.getElementById("aImgSqr122").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr122").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQE23b() {
    if(document.getElementById("aImgSqr123").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr123").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQE24b() {
    if(document.getElementById("aImgSqr124").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr124").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQE25b() {
    if(document.getElementById("aImgSqr125").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr125").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
 };
};

function sqrQF1b() {
    if(document.getElementById("aImgSqr126").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr126").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQF2b() {
    if(document.getElementById("aImgSqr127").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr127").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQF3b() {
    if(document.getElementById("aImgSqr128").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr128").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQF4b() {
    if(document.getElementById("aImgSqr129").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr129").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQF5b() {
    if(document.getElementById("aImgSqr130").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr130").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQF6b() {
    if(document.getElementById("aImgSqr131").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr131").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQF7b() {
    if(document.getElementById("aImgSqr132").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr132").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQF8b() {
    if(document.getElementById("aImgSqr133").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr133").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQF9b() {
    if(document.getElementById("aImgSqr134").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr134").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQF10b() {
    if(document.getElementById("aImgSqr135").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr135").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQF11b() {
    if(document.getElementById("aImgSqr136").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr136").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQF12b() {
    if(document.getElementById("aImgSqr137").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr137").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQF13b() {
    if(document.getElementById("aImgSqr138").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr138").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQF14b() {
    if(document.getElementById("aImgSqr139").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr139").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQF15b() {
    if(document.getElementById("aImgSqr140").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr140").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQF16b() {
    if(document.getElementById("aImgSqr141").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr141").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQF17b() {
    if(document.getElementById("aImgSqr142").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr142").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQF18b() {
    if(document.getElementById("aImgSqr143").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr143").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQF19b() {
    if(document.getElementById("aImgSqr144").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr144").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQF20b() {
    if(document.getElementById("aImgSqr145").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr145").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQF21b() {
    if(document.getElementById("aImgSqr146").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr146").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQF22b() {
    if(document.getElementById("aImgSqr147").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr147").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQF23b() {
    if(document.getElementById("aImgSqr148").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr148").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQF24b() {
    if(document.getElementById("aImgSqr149").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr149").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQF25b() {
    if(document.getElementById("aImgSqr150").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr150").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
 };
};

function sqrQG1b() {
    if(document.getElementById("aImgSqr151").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr151").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQG2b() {
    if(document.getElementById("aImgSqr152").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr152").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQG3b() {
    if(document.getElementById("aImgSqr153").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr153").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQG4b() {
    if(document.getElementById("aImgSqr154").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr154").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQG5b() {
    if(document.getElementById("aImgSqr155").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr155").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQG6b() {
    if(document.getElementById("aImgSqr156").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr156").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQG7b() {
    if(document.getElementById("aImgSqr157").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr157").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQG8b() {
    if(document.getElementById("aImgSqr158").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr158").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQG9b() {
    if(document.getElementById("aImgSqr159").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr159").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQG10b() {
    if(document.getElementById("aImgSqr160").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr160").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQG11b() {
    if(document.getElementById("aImgSqr161").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr161").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQG12b() {
    if(document.getElementById("aImgSqr162").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr162").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQG13b() {
    if(document.getElementById("aImgSqr163").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr163").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQG14b() {
    if(document.getElementById("aImgSqr164").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr164").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQG15b() {
    if(document.getElementById("aImgSqr165").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr165").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQG16b() {
    if(document.getElementById("aImgSqr166").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr166").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQG17b() {
    if(document.getElementById("aImgSqr167").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr167").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQG18b() {
    if(document.getElementById("aImgSqr168").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr168").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQG19b() {
    if(document.getElementById("aImgSqr169").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr169").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQG20b() {
    if(document.getElementById("aImgSqr170").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr170").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQG21b() {
    if(document.getElementById("aImgSqr171").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr171").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQG22b() {
    if(document.getElementById("aImgSqr172").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr172").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQG23b() {
    if(document.getElementById("aImgSqr173").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr173").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQG24b() {
    if(document.getElementById("aImgSqr174").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr174").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQG25b() {
    if(document.getElementById("aImgSqr175").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr175").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQH1b() {
    if(document.getElementById("aImgSqr176").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr176").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQH2b() {
    if(document.getElementById("aImgSqr177").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr177").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQH3b() {
    if(document.getElementById("aImgSqr178").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr178").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQH4b() {
    if(document.getElementById("aImgSqr179").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr179").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQH5b() {
    if(document.getElementById("aImgSqr180").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr180").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQH6b() {
    if(document.getElementById("aImgSqr181").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr181").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQH7b() {
    if(document.getElementById("aImgSqr182").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr182").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQH8b() {
    if(document.getElementById("aImgSqr183").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr183").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQH9b() {
    if(document.getElementById("aImgSqr184").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr184").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQH10b() {
    if(document.getElementById("aImgSqr185").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr185").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQH11b() {
    if(document.getElementById("aImgSqr186").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr186").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQH12b() {
    if(document.getElementById("aImgSqr187").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr187").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQH13b() {
    if(document.getElementById("aImgSqr188").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr188").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQH14b() {
    if(document.getElementById("aImgSqr189").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr189").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQH15b() {
    if(document.getElementById("aImgSqr190").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr190").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQH16b() {
    if(document.getElementById("aImgSqr191").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr191").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQH17b() {
    if(document.getElementById("aImgSqr192").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr192").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQH18b() {
    if(document.getElementById("aImgSqr193").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr193").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQH19b() {
    if(document.getElementById("aImgSqr194").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr194").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQH20b() {
    if(document.getElementById("aImgSqr195").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr195").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQH21b() {
    if(document.getElementById("aImgSqr196").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr196").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQH22b() {
    if(document.getElementById("aImgSqr197").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr197").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQH23b() {
    if(document.getElementById("aImgSqr198").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr198").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQH24b() {
    if(document.getElementById("aImgSqr199").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr199").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQH25b() {
    if(document.getElementById("aImgSqr200").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr200").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
 };
};

function sqrQI1b() {
    if(document.getElementById("aImgSqr201").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr201").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQI2b() {
    if(document.getElementById("aImgSqr202").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr202").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQI3b() {
    if(document.getElementById("aImgSqr203").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr203").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQI4b() {
    if(document.getElementById("aImgSqr204").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr204").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQI5b() {
    if(document.getElementById("aImgSqr205").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr205").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQI6b() {
    if(document.getElementById("aImgSqr206").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr206").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQI7b() {
    if(document.getElementById("aImgSqr207").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr207").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQI8b() {
    if(document.getElementById("aImgSqr208").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr208").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQI9b() {
    if(document.getElementById("aImgSqr209").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr209").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQI10b() {
    if(document.getElementById("aImgSqr210").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr210").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQI11b() {
    if(document.getElementById("aImgSqr211").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr211").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQI12b() {
    if(document.getElementById("aImgSqr212").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr212").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQI13b() {
    if(document.getElementById("aImgSqr213").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr213").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQI14b() {
    if(document.getElementById("aImgSqr214").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr214").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQI15b() {
    if(document.getElementById("aImgSqr215").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr215").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQI16b() {
    if(document.getElementById("aImgSqr216").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr216").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQI17b() {
    if(document.getElementById("aImgSqr217").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr217").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQI18b() {
    if(document.getElementById("aImgSqr218").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr218").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQI19b() {
    if(document.getElementById("aImgSqr219").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr219").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQI20b() {
    if(document.getElementById("aImgSqr220").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr220").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQI21b() {
    if(document.getElementById("aImgSqr221").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr221").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQI22b() {
    if(document.getElementById("aImgSqr222").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr222").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQI23b() {
    if(document.getElementById("aImgSqr223").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr223").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQI24b() {
    if(document.getElementById("aImgSqr224").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr224").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQI25b() {
    if(document.getElementById("aImgSqr225").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr225").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
 };
};

function sqrQJ1b() {
    if(document.getElementById("aImgSqr226").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr226").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQJ2b() {
    if(document.getElementById("aImgSqr227").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr227").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQJ3b() {
    if(document.getElementById("aImgSqr228").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr228").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQJ4b() {
    if(document.getElementById("aImgSqr229").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr229").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQJ5b() {
    if(document.getElementById("aImgSqr230").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr230").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQJ6b() {
    if(document.getElementById("aImgSqr231").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr231").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQJ7b() {
    if(document.getElementById("aImgSqr232").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr232").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQJ8b() {
    if(document.getElementById("aImgSqr233").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr233").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQJ9b() {
    if(document.getElementById("aImgSqr234").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr234").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQJ10b() {
    if(document.getElementById("aImgSqr235").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr235").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQJ11b() {
    if(document.getElementById("aImgSqr236").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr236").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQJ12b() {
    if(document.getElementById("aImgSqr237").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr237").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQJ13b() {
    if(document.getElementById("aImgSqr238").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr238").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQJ14b() {
    if(document.getElementById("aImgSqr239").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr239").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQJ15b() {
    if(document.getElementById("aImgSqr240").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr240").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQJ16b() {
    if(document.getElementById("aImgSqr241").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr241").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQJ17b() {
    if(document.getElementById("aImgSqr242").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr242").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQJ18b() {
    if(document.getElementById("aImgSqr243").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr243").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQJ19b() {
    if(document.getElementById("aImgSqr244").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr244").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQJ20b() {
    if(document.getElementById("aImgSqr245").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr245").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQJ21b() {
    if(document.getElementById("aImgSqr246").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr246").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQJ22b() {
    if(document.getElementById("aImgSqr247").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr247").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQJ23b() {
    if(document.getElementById("aImgSqr248").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr248").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQJ24b() {
    if(document.getElementById("aImgSqr249").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr249").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQJ25b() {
    if(document.getElementById("aImgSqr250").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr250").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
 };
};

function sqrQK1b() {
    if(document.getElementById("aImgSqr251").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr251").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQK2b() {
    if(document.getElementById("aImgSqr252").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr252").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQK3b() {
    if(document.getElementById("aImgSqr253").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr253").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQK4b() {
    if(document.getElementById("aImgSqr254").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr254").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQK5b() {
    if(document.getElementById("aImgSqr255").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr255").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQK6b() {
    if(document.getElementById("aImgSqr256").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr256").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQK7b() {
    if(document.getElementById("aImgSqr257").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr257").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQK8b() {
    if(document.getElementById("aImgSqr258").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr258").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQK9b() {
    if(document.getElementById("aImgSqr259").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr259").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQK10b() {
    if(document.getElementById("aImgSqr260").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr260").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQK11b() {
    if(document.getElementById("aImgSqr261").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr261").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQK12b() {
    if(document.getElementById("aImgSqr262").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr262").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQK13b() {
    if(document.getElementById("aImgSqr263").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr263").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQK14b() {
    if(document.getElementById("aImgSqr264").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr264").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQK15b() {
    if(document.getElementById("aImgSqr265").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr265").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQK16b() {
    if(document.getElementById("aImgSqr266").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr266").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQK17b() {
    if(document.getElementById("aImgSqr267").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr267").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQK18b() {
    if(document.getElementById("aImgSqr268").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr268").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQK19b() {
    if(document.getElementById("aImgSqr269").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr269").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQK20b() {
    if(document.getElementById("aImgSqr270").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr270").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQK21b() {
    if(document.getElementById("aImgSqr271").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr271").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQK22b() {
    if(document.getElementById("aImgSqr272").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr272").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQK23b() {
    if(document.getElementById("aImgSqr273").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr273").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQK24b() {
    if(document.getElementById("aImgSqr274").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr274").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQK25b() {
    if(document.getElementById("aImgSqr275").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr275").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
 };
};

function sqrQL1b() {
    if(document.getElementById("aImgSqr276").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr276").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQL2b() {
    if(document.getElementById("aImgSqr277").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr277").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQL3b() {
    if(document.getElementById("aImgSqr278").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr278").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQL4b() {
    if(document.getElementById("aImgSqr279").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr279").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQL5b() {
    if(document.getElementById("aImgSqr280").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr280").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQL6b() {
    if(document.getElementById("aImgSqr281").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr281").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQL7b() {
    if(document.getElementById("aImgSqr282").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr282").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQL8b() {
    if(document.getElementById("aImgSqr283").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr283").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQL9b() {
    if(document.getElementById("aImgSqr284").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr284").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQL10b() {
    if(document.getElementById("aImgSqr285").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr285").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQL11b() {
    if(document.getElementById("aImgSqr286").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr286").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQL12b() {
    if(document.getElementById("aImgSqr287").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr287").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQL13b() {
    if(document.getElementById("aImgSqr288").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr288").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQL14b() {
    if(document.getElementById("aImgSqr289").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr289").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQL15b() {
    if(document.getElementById("aImgSqr290").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr290").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQL16b() {
    if(document.getElementById("aImgSqr291").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr291").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQL17b() {
    if(document.getElementById("aImgSqr292").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr292").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQL18b() {
    if(document.getElementById("aImgSqr293").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr293").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQL19b() {
    if(document.getElementById("aImgSqr294").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr294").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQL20b() {
    if(document.getElementById("aImgSqr295").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr295").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQL21b() {
    if(document.getElementById("aImgSqr296").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr296").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQL22b() {
    if(document.getElementById("aImgSqr297").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr297").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQL23b() {
    if(document.getElementById("aImgSqr298").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr298").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQL24b() {
    if(document.getElementById("aImgSqr299").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr299").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQL25b() {
    if(document.getElementById("aImgSqr300").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr300").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
 };
};

function sqrQM1b() {
    if(document.getElementById("aImgSqr301").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr301").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQM2b() {
    if(document.getElementById("aImgSqr302").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr302").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQM3b() {
    if(document.getElementById("aImgSqr303").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr303").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQM4b() {
    if(document.getElementById("aImgSqr304").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr304").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQM5b() {
    if(document.getElementById("aImgSqr305").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr305").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQM6b() {
    if(document.getElementById("aImgSqr306").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr306").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQM7b() {
    if(document.getElementById("aImgSqr307").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr307").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQM8b() {
    if(document.getElementById("aImgSqr308").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr308").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQM9b() {
    if(document.getElementById("aImgSqr309").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr309").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQM10b() {
    if(document.getElementById("aImgSqr310").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr310").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQM11b() {
    if(document.getElementById("aImgSqr311").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr311").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQM12b() {
    if(document.getElementById("aImgSqr312").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr312").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQM13b() {
    if(document.getElementById("aImgSqr313").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr313").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQM14b() {
    if(document.getElementById("aImgSqr314").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr314").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQM15b() {
    if(document.getElementById("aImgSqr315").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr315").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQM16b() {
    if(document.getElementById("aImgSqr316").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr316").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQM17b() {
    if(document.getElementById("aImgSqr317").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr317").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQM18b() {
    if(document.getElementById("aImgSqr318").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr318").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQM19b() {
    if(document.getElementById("aImgSqr319").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr319").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQM20b() {
    if(document.getElementById("aImgSqr320").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr320").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQM21b() {
    if(document.getElementById("aImgSqr321").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr321").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQM22b() {
    if(document.getElementById("aImgSqr322").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr322").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQM23b() {
    if(document.getElementById("aImgSqr323").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr323").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQM24b() {
    if(document.getElementById("aImgSqr324").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr324").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQM25b() {
    if(document.getElementById("aImgSqr325").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr325").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
 };
};

function sqrQN1b() {
    if(document.getElementById("aImgSqr326").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr326").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQN2b() {
    if(document.getElementById("aImgSqr327").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr327").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQN3b() {
    if(document.getElementById("aImgSqr328").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr328").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQN4b() {
    if(document.getElementById("aImgSqr329").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr329").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQN5b() {
    if(document.getElementById("aImgSqr330").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr330").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQN6b() {
    if(document.getElementById("aImgSqr331").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr331").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQN7b() {
    if(document.getElementById("aImgSqr332").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr332").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQN8b() {
    if(document.getElementById("aImgSqr333").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr333").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQN9b() {
    if(document.getElementById("aImgSqr334").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr334").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQN10b() {
    if(document.getElementById("aImgSqr335").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr335").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQN11b() {
    if(document.getElementById("aImgSqr336").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr336").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQN12b() {
    if(document.getElementById("aImgSqr337").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr337").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQN13b() {
    if(document.getElementById("aImgSqr338").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr338").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQN14b() {
    if(document.getElementById("aImgSqr339").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr339").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQN15b() {
    if(document.getElementById("aImgSqr340").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr340").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQN16b() {
    if(document.getElementById("aImgSqr341").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr341").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQN17b() {
    if(document.getElementById("aImgSqr342").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr342").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQN18b() {
    if(document.getElementById("aImgSqr343").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr343").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQN19b() {
    if(document.getElementById("aImgSqr344").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr344").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQN20b() {
    if(document.getElementById("aImgSqr345").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr345").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQN21b() {
    if(document.getElementById("aImgSqr346").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr346").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQN22b() {
    if(document.getElementById("aImgSqr347").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr347").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQN23b() {
    if(document.getElementById("aImgSqr348").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr348").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQN24b() {
    if(document.getElementById("aImgSqr349").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr349").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQN25b() {
    if(document.getElementById("aImgSqr350").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr350").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
 };
};

function sqrQO1b() {
    if(document.getElementById("aImgSqr351").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr351").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQO2b() {
    if(document.getElementById("aImgSqr352").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr352").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQO3b() {
    if(document.getElementById("aImgSqr353").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr353").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQO4b() {
    if(document.getElementById("aImgSqr354").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr354").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQO5b() {
    if(document.getElementById("aImgSqr355").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr355").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQO6b() {
    if(document.getElementById("aImgSqr356").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr356").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQO7b() {
    if(document.getElementById("aImgSqr357").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr357").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQO8b() {
    if(document.getElementById("aImgSqr358").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr358").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQO9b() {
    if(document.getElementById("aImgSqr359").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr359").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQO10b() {
    if(document.getElementById("aImgSqr360").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr360").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQO11b() {
    if(document.getElementById("aImgSqr361").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr361").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQO12b() {
    if(document.getElementById("aImgSqr362").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr362").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQO13b() {
    if(document.getElementById("aImgSqr363").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr363").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQO14b() {
    if(document.getElementById("aImgSqr364").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr364").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQO15b() {
    if(document.getElementById("aImgSqr365").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr365").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQO16b() {
    if(document.getElementById("aImgSqr366").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr366").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQO17b() {
    if(document.getElementById("aImgSqr367").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr367").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQO18b() {
    if(document.getElementById("aImgSqr368").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr368").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQO19b() {
    if(document.getElementById("aImgSqr369").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr369").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQO20b() {
    if(document.getElementById("aImgSqr370").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr370").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQO21b() {
    if(document.getElementById("aImgSqr371").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr371").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQO22b() {
    if(document.getElementById("aImgSqr372").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr372").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQO23b() {
    if(document.getElementById("aImgSqr373").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr373").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQO24b() {
    if(document.getElementById("aImgSqr374").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr374").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQO25b() {
    if(document.getElementById("aImgSqr375").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr375").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
 };
};

function sqrQP1b() {
    if(document.getElementById("aImgSqr376").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr376").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQP2b() {
    if(document.getElementById("aImgSqr377").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr377").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQP3b() {
    if(document.getElementById("aImgSqr378").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr378").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQP4b() {
    if(document.getElementById("aImgSqr379").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr379").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQP5b() {
    if(document.getElementById("aImgSqr380").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr380").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQP6b() {
    if(document.getElementById("aImgSqr381").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr381").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQP7b() {
    if(document.getElementById("aImgSqr382").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr382").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQP8b() {
    if(document.getElementById("aImgSqr383").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr383").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQP9b() {
    if(document.getElementById("aImgSqr384").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr384").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQP10b() {
    if(document.getElementById("aImgSqr385").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr385").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQP11b() {
    if(document.getElementById("aImgSqr386").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr386").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQP12b() {
    if(document.getElementById("aImgSqr387").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr387").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQP13b() {
    if(document.getElementById("aImgSqr388").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr388").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQP14b() {
    if(document.getElementById("aImgSqr389").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr389").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQP15b() {
    if(document.getElementById("aImgSqr390").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr390").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQP16b() {
    if(document.getElementById("aImgSqr391").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr391").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQP17b() {
    if(document.getElementById("aImgSqr392").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr392").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQP18b() {
    if(document.getElementById("aImgSqr393").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr393").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQP19b() {
    if(document.getElementById("aImgSqr394").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr394").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQP20b() {
    if(document.getElementById("aImgSqr395").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr395").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQP21b() {
    if(document.getElementById("aImgSqr396").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr396").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQP22b() {
    if(document.getElementById("aImgSqr397").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr397").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQP23b() {
    if(document.getElementById("aImgSqr398").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr398").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQP24b() {
    if(document.getElementById("aImgSqr399").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr399").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQP25b() {
    if(document.getElementById("aImgSqr400").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr400").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
 };
};

function sqrQQ1b() {
    if(document.getElementById("aImgSqr401").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr401").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQQ2b() {
    if(document.getElementById("aImgSqr402").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr402").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQQ3b() {
    if(document.getElementById("aImgSqr403").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr403").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQQ4b() {
    if(document.getElementById("aImgSqr404").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr404").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQQ5b() {
    if(document.getElementById("aImgSqr405").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr405").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQQ6b() {
    if(document.getElementById("aImgSqr406").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr406").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQQ7b() {
    if(document.getElementById("aImgSqr407").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr407").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQQ8b() {
    if(document.getElementById("aImgSqr408").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr408").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQQ9b() {
    if(document.getElementById("aImgSqr409").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr409").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQQ10b() {
    if(document.getElementById("aImgSqr410").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr410").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQQ11b() {
    if(document.getElementById("aImgSqr411").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr411").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQQ12b() {
    if(document.getElementById("aImgSqr412").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr412").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQQ13b() {
    if(document.getElementById("aImgSqr413").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr413").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQQ14b() {
    if(document.getElementById("aImgSqr414").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr414").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQQ15b() {
    if(document.getElementById("aImgSqr415").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr415").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQQ16b() {
    if(document.getElementById("aImgSqr416").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr416").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQQ17b() {
    if(document.getElementById("aImgSqr417").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr417").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQQ18b() {
    if(document.getElementById("aImgSqr418").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr418").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQQ19b() {
    if(document.getElementById("aImgSqr419").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr419").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQQ20b() {
    if(document.getElementById("aImgSqr420").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr420").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQQ21b() {
    if(document.getElementById("aImgSqr421").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr421").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQQ22b() {
    if(document.getElementById("aImgSqr422").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr422").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQQ23b() {
    if(document.getElementById("aImgSqr423").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr423").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQQ24b() {
    if(document.getElementById("aImgSqr424").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr424").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQQ25b() {
    if(document.getElementById("aImgSqr425").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr425").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
 };
};

function sqrQR1b() {
    if(document.getElementById("aImgSqr426").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr426").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQR2b() {
    if(document.getElementById("aImgSqr427").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr427").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQR3b() {
    if(document.getElementById("aImgSqr428").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr428").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQR4b() {
    if(document.getElementById("aImgSqr429").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr429").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQR5b() {
    if(document.getElementById("aImgSqr430").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr430").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQR6b() {
    if(document.getElementById("aImgSqr431").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr431").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQR7b() {
    if(document.getElementById("aImgSqr432").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr432").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQR8b() {
    if(document.getElementById("aImgSqr433").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr433").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQR9b() {
    if(document.getElementById("aImgSqr434").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr434").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQR10b() {
    if(document.getElementById("aImgSqr435").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr435").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQR11b() {
    if(document.getElementById("aImgSqr436").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr436").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQR12b() {
    if(document.getElementById("aImgSqr437").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr437").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQR13b() {
    if(document.getElementById("aImgSqr438").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr438").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQR14b() {
    if(document.getElementById("aImgSqr439").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr439").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQR15b() {
    if(document.getElementById("aImgSqr440").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr440").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQR16b() {
    if(document.getElementById("aImgSqr441").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr441").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQR17b() {
    if(document.getElementById("aImgSqr442").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr442").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQR18b() {
    if(document.getElementById("aImgSqr443").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr443").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQR19b() {
    if(document.getElementById("aImgSqr444").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr444").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQR20b() {
    if(document.getElementById("aImgSqr445").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr445").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQR21b() {
    if(document.getElementById("aImgSqr446").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr446").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQR22b() {
    if(document.getElementById("aImgSqr447").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr447").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQR23b() {
    if(document.getElementById("aImgSqr448").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr448").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQR24b() {
    if(document.getElementById("aImgSqr449").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr449").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQR25b() {
    if(document.getElementById("aImgSqr450").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr450").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
 };
};

function sqrQS1b() {
    if(document.getElementById("aImgSqr451").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr451").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQS2b() {
    if(document.getElementById("aImgSqr452").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr452").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQS3b() {
    if(document.getElementById("aImgSqr453").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr453").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQS4b() {
    if(document.getElementById("aImgSqr454").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr454").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQS5b() {
    if(document.getElementById("aImgSqr455").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr455").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQS6b() {
    if(document.getElementById("aImgSqr456").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr456").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQS7b() {
    if(document.getElementById("aImgSqr457").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr457").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQS8b() {
    if(document.getElementById("aImgSqr458").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr458").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQS9b() {
    if(document.getElementById("aImgSqr459").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr459").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQS10b() {
    if(document.getElementById("aImgSqr460").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr460").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQS11b() {
    if(document.getElementById("aImgSqr461").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr461").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQS12b() {
    if(document.getElementById("aImgSqr462").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr462").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQS13b() {
    if(document.getElementById("aImgSqr463").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr463").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQS14b() {
    if(document.getElementById("aImgSqr464").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr464").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQS15b() {
    if(document.getElementById("aImgSqr465").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr465").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQS16b() {
    if(document.getElementById("aImgSqr466").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr466").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQS17b() {
    if(document.getElementById("aImgSqr467").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr467").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQS18b() {
    if(document.getElementById("aImgSqr468").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr468").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQS19b() {
    if(document.getElementById("aImgSqr469").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr469").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQS20b() {
    if(document.getElementById("aImgSqr470").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr470").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQS21b() {
    if(document.getElementById("aImgSqr471").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr471").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQS22b() {
    if(document.getElementById("aImgSqr472").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr472").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQS23b() {
    if(document.getElementById("aImgSqr473").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr473").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQS24b() {
    if(document.getElementById("aImgSqr474").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr474").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQS25b() {
    if(document.getElementById("aImgSqr475").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr475").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
 };
};

function sqrQT1b() {
    if(document.getElementById("aImgSqr476").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr476").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQT2b() {
    if(document.getElementById("aImgSqr477").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr477").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQT3b() {
    if(document.getElementById("aImgSqr478").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr478").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQT4b() {
    if(document.getElementById("aImgSqr479").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr479").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQT5b() {
    if(document.getElementById("aImgSqr480").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr480").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQT6b() {
    if(document.getElementById("aImgSqr481").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr481").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQT7b() {
    if(document.getElementById("aImgSqr482").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr482").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQT8b() {
    if(document.getElementById("aImgSqr483").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr483").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQT9b() {
    if(document.getElementById("aImgSqr484").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr484").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQT10b() {
    if(document.getElementById("aImgSqr485").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr485").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQT11b() {
    if(document.getElementById("aImgSqr486").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr486").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQT12b() {
    if(document.getElementById("aImgSqr487").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr487").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQT13b() {
    if(document.getElementById("aImgSqr488").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr488").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQT14b() {
    if(document.getElementById("aImgSqr489").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr489").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQT15b() {
    if(document.getElementById("aImgSqr490").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr490").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQT16b() {
    if(document.getElementById("aImgSqr491").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr491").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQT17b() {
    if(document.getElementById("aImgSqr492").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr492").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQT18b() {
    if(document.getElementById("aImgSqr493").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr493").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQT19b() {
    if(document.getElementById("aImgSqr494").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr494").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQT20b() {
    if(document.getElementById("aImgSqr495").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr495").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQT21b() {
    if(document.getElementById("aImgSqr496").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr496").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQT22b() {
    if(document.getElementById("aImgSqr497").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr497").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQT23b() {
    if(document.getElementById("aImgSqr498").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr498").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQT24b() {
    if(document.getElementById("aImgSqr499").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr499").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQT25b() {
    if(document.getElementById("aImgSqr500").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr500").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
 };
};

function sqrQU1b() {
    if(document.getElementById("aImgSqr501").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr501").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQU2b() {
    if(document.getElementById("aImgSqr502").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr502").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQU3b() {
    if(document.getElementById("aImgSqr503").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr503").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQU4b() {
    if(document.getElementById("aImgSqr504").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr504").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQU5b() {
    if(document.getElementById("aImgSqr505").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr505").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQU6b() {
    if(document.getElementById("aImgSqr506").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr506").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQU7b() {
    if(document.getElementById("aImgSqr507").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr507").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQU8b() {
    if(document.getElementById("aImgSqr508").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr508").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQU9b() {
    if(document.getElementById("aImgSqr509").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr509").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQU10b() {
    if(document.getElementById("aImgSqr510").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr510").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQU11b() {
    if(document.getElementById("aImgSqr511").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr511").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQU12b() {
    if(document.getElementById("aImgSqr512").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr512").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQU13b() {
    if(document.getElementById("aImgSqr513").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr513").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQU14b() {
    if(document.getElementById("aImgSqr514").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr514").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQU15b() {
    if(document.getElementById("aImgSqr515").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr515").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQU16b() {
    if(document.getElementById("aImgSqr516").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr516").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQU17b() {
    if(document.getElementById("aImgSqr517").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr517").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQU18b() {
    if(document.getElementById("aImgSqr518").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr518").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQU19b() {
    if(document.getElementById("aImgSqr519").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr519").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQU20b() {
    if(document.getElementById("aImgSqr520").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr520").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQU21b() {
    if(document.getElementById("aImgSqr521").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr521").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQU22b() {
    if(document.getElementById("aImgSqr522").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr522").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQU23b() {
    if(document.getElementById("aImgSqr523").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr523").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQU24b() {
    if(document.getElementById("aImgSqr524").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr524").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQU25b() {
    if(document.getElementById("aImgSqr525").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr525").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
 };
};

function sqrQV1b() {
    if(document.getElementById("aImgSqr526").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr526").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQV2b() {
    if(document.getElementById("aImgSqr527").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr527").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQV3b() {
    if(document.getElementById("aImgSqr528").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr528").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQV4b() {
    if(document.getElementById("aImgSqr529").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr529").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQV5b() {
    if(document.getElementById("aImgSqr530").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr530").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQV6b() {
    if(document.getElementById("aImgSqr531").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr531").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQV7b() {
    if(document.getElementById("aImgSqr532").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr532").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQV8b() {
    if(document.getElementById("aImgSqr533").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr533").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQV9b() {
    if(document.getElementById("aImgSqr534").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr534").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQV10b() {
    if(document.getElementById("aImgSqr535").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr535").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQV11b() {
    if(document.getElementById("aImgSqr536").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr536").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQV12b() {
    if(document.getElementById("aImgSqr537").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr537").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQV13b() {
    if(document.getElementById("aImgSqr538").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr538").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQV14b() {
    if(document.getElementById("aImgSqr539").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr539").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQV15b() {
    if(document.getElementById("aImgSqr540").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr540").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQV16b() {
    if(document.getElementById("aImgSqr541").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr541").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQV17b() {
    if(document.getElementById("aImgSqr542").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr542").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQV18b() {
    if(document.getElementById("aImgSqr543").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr543").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQV19b() {
    if(document.getElementById("aImgSqr544").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr544").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQV20b() {
    if(document.getElementById("aImgSqr545").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr545").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQV21b() {
    if(document.getElementById("aImgSqr546").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr546").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQV22b() {
    if(document.getElementById("aImgSqr547").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr547").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQV23b() {
    if(document.getElementById("aImgSqr548").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr548").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQV24b() {
    if(document.getElementById("aImgSqr549").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr549").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQV25b() {
    if(document.getElementById("aImgSqr550").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr550").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
 };
};

function sqrQW1b() {
    if(document.getElementById("aImgSqr551").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
         document.getElementById("aImgSqr551").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQW2b() {
    if(document.getElementById("aImgSqr552").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr552").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQW3b() {
    if(document.getElementById("aImgSqr553").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr553").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQW4b() {
    if(document.getElementById("aImgSqr554").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr554").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQW5b() {
    if(document.getElementById("aImgSqr555").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr555").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQW6b() {
    if(document.getElementById("aImgSqr556").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr556").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQW7b() {
    if(document.getElementById("aImgSqr557").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr557").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQW8b() {
    if(document.getElementById("aImgSqr558").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr558").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQW9b() {
    if(document.getElementById("aImgSqr559").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr559").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQW10b() {
    if(document.getElementById("aImgSqr560").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr560").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQW11b() {
    if(document.getElementById("aImgSqr561").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr561").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQW12b() {
    if(document.getElementById("aImgSqr562").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr562").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQW13b() {
    if(document.getElementById("aImgSqr563").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr563").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQW14b() {
    if(document.getElementById("aImgSqr564").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr564").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQW15b() {
    if(document.getElementById("aImgSqr565").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr565").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQW16b() {
    if(document.getElementById("aImgSqr566").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr566").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQW17b() {
    if(document.getElementById("aImgSqr567").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr567").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQW18b() {
    if(document.getElementById("aImgSqr568").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr568").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQW19b() {
    if(document.getElementById("aImgSqr569").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr569").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQW20b() {
    if(document.getElementById("aImgSqr570").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr570").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQW21b() {
    if(document.getElementById("aImgSqr571").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr571").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQW22b() {
    if(document.getElementById("aImgSqr572").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr572").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQW23b() {
    if(document.getElementById("aImgSqr573").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr573").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQW24b() {
    if(document.getElementById("aImgSqr574").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr574").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQW25b() {
    if(document.getElementById("aImgSqr575").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr575").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
 };
};

function sqrQX1b() {
    if(document.getElementById("aImgSqr576").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr576").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQX2b() {
    if(document.getElementById("aImgSqr577").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr577").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQX3b() {
    if(document.getElementById("aImgSqr578").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr578").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQX4b() {
    if(document.getElementById("aImgSqr579").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr579").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQX5b() {
    if(document.getElementById("aImgSqr580").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr580").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQX6b() {
    if(document.getElementById("aImgSqr581").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr581").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQX7b() {
    if(document.getElementById("aImgSqr582").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr582").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQX8b() {
    if(document.getElementById("aImgSqr583").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr583").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQX9b() {
    if(document.getElementById("aImgSqr584").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr584").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQX10b() {
    if(document.getElementById("aImgSqr585").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr585").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQX11b() {
    if(document.getElementById("aImgSqr586").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr586").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQX12b() {
    if(document.getElementById("aImgSqr587").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr587").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQX13b() {
    if(document.getElementById("aImgSqr588").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr588").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQX14b() {
    if(document.getElementById("aImgSqr589").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr589").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQX15b() {
    if(document.getElementById("aImgSqr590").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr590").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQX16b() {
    if(document.getElementById("aImgSqr591").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr591").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQX17b() {
    if(document.getElementById("aImgSqr592").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr592").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQX18b() {
    if(document.getElementById("aImgSqr593").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr593").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQX19b() {
    if(document.getElementById("aImgSqr594").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr594").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQX20b() {
    if(document.getElementById("aImgSqr595").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr595").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQX21b() {
    if(document.getElementById("aImgSqr596").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr596").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQX22b() {
    if(document.getElementById("aImgSqr597").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr597").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQX23b() {
    if(document.getElementById("aImgSqr598").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr598").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQX24b() {
    if(document.getElementById("aImgSqr599").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr599").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQX25b() {
    if(document.getElementById("aImgSqr600").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png") {
     document.getElementById("aImgSqr600").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
 };
};

function sqrQY1b() {
    if(document.getElementById("aImgSqr601").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr601").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQY2b() {
    if(document.getElementById("aImgSqr602").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr602").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQY3b() {
    if(document.getElementById("aImgSqr603").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr603").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQY4b() {
    if(document.getElementById("aImgSqr604").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr604").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQY5b() {
    if(document.getElementById("aImgSqr605").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr605").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQY6b() {
    if(document.getElementById("aImgSqr606").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr606").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQY7b() {
    if(document.getElementById("aImgSqr607").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr607").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQY8b() {
    if(document.getElementById("aImgSqr608").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr608").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQY9b() {
    if(document.getElementById("aImgSqr609").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr609").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQY10b() {
    if(document.getElementById("aImgSqr610").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr610").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQY11b() {
    if(document.getElementById("aImgSqr611").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr611").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png"
};
};

function sqrQY12b() {
    if(document.getElementById("aImgSqr612").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr612").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQY13b() {
    if(document.getElementById("aImgSqr613").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr613").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQY14b() {
    if(document.getElementById("aImgSqr614").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr614").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQY15b() {
    if(document.getElementById("aImgSqr615").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr615").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQY16b() {
    if(document.getElementById("aImgSqr616").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr616").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQY17b() {
    if(document.getElementById("aImgSqr617").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr617").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQY18b() {
    if(document.getElementById("aImgSqr618").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr618").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQY19b() {
    if(document.getElementById("aImgSqr619").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
     document.getElementById("aImgSqr619").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQY20b() {
    if(document.getElementById("aImgSqr620").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
    document.getElementById("aImgSqr620").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQY21b() {
    if(document.getElementById("aImgSqr621").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
    document.getElementById("aImgSqr621").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQY22b() {
    if(document.getElementById("aImgSqr622").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
    document.getElementById("aImgSqr622").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQY23b() {
    if(document.getElementById("aImgSqr623").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
    document.getElementById("aImgSqr623").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQY24b() {
    if(document.getElementById("aImgSqr624").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
    document.getElementById("aImgSqr624").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};

function sqrQY25b() {
    if(document.getElementById("aImgSqr625").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png") {
    document.getElementById("aImgSqr625").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png"
};
};