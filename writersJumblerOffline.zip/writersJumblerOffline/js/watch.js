function addZero(i) {
if (i <= 9) {
    i = "0" + i;
}
return i;
}
function watch() {
var d = new Date();
var dte = ["st", "nd", "rd", "th", "th", "th", "th", "th", "th", "th", 
"th", "th", "th", "th", "th", "th", "th", "th", "th", "th", 
"st", "nd", "rd", "th", "th", "th", "th", "th", "th", "th", 
"st"];
var m = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November","December"];
var h = ["12", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11"]
var time = new Date().getHours();
var day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
var amPm;
if (time <= 11) {
	amPm = "AM";
	} else {
	amPm = "PM";
}
document.getElementById("year").innerHTML = '<div id="year"><p id="year2">' + d.getFullYear() + '</p></div>';
document.getElementById("day").innerHTML = '<div id="day"><p id="day2">' + day[d.getDay()] + '</p></div>';
document.getElementById("month").innerHTML = '<div id="month"><p id="month2">' + m[d.getMonth()] + '</p></div>';
document.getElementById("date").innerHTML = '<div id="date"><p id="date2">' + d.getDate() + dte[d.getDate() - 1] + '</p></div>';
document.getElementById("hNmNs").innerHTML = '<div id="hNmNs"><p id="hNmNs2">' + h[d.getHours()] + ':' + addZero(d.getMinutes()) + ':' + addZero(d.getSeconds()) + amPm + '</p></div>';
}
setInterval(watch, 1000);

