function oMz1() {
    document.getElementById("aImg").src = "img/hexs/hexRdWrt.png";
};
function oMz2() {
    document.getElementById("bImg").src = "img/hexs/hexSqrArt.png";
};
function oMz3() {
    document.getElementById("cImg").src = "img/hexs/hexArt.png";
};
function oMz4() {
    document.getElementById("dImg").src = "img/hexs/hex1.png";
};

function oMsA1() {
    document.getElementById("aImg").src = "img/hexs/hex0.png";
};
function oMsA2() {
    document.getElementById("bImg").src = "img/hexs/hex0.png";
};
function oMsA3() {
    document.getElementById("cImg").src = "img/hexs/hex0.png";
};
function oMsA4() {
    document.getElementById("dImg").src = "img/hexs/hex0.png";
};

function oMsC1() {
    document.getElementById("aImg").src = "img/hexs/cube1.png";
};
function oMsC2() {
    document.getElementById("bImg").src = "img/hexs/cube1.png";
};
function oMsC3() {
    document.getElementById("cImg").src = "img/hexs/cube1.png";
};
function oMsC4() {
    document.getElementById("dImg").src = "img/hexs/cube1.png";
};