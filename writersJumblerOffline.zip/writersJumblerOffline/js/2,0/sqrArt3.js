function asqrA1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr1").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr1").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrA2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr2").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr2").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrA3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr3").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr3").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrA4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr4").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr4").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrA5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr5").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr5").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrA6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr6").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr6").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrA7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr7").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr7").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrA8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr8").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr8").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrA9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr9").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr9").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrA10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr10").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr10").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrA11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr11").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr11").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrA12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr12").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr12").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrA13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr13").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr13").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrA14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr14").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr14").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrA15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr15").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr15").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrA16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr16").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr16").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrA17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr17").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr17").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrA18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr18").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr18").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrA19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr19").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr19").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrA20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr20").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr20").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrA21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr21").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr21").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrA22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr22").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr22").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrA23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr23").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr23").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrA24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr24").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr24").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrA25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr25").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr25").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrB1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr26").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr26").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrB2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr27").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr27").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrB3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr28").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr28").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrB4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr29").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr29").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrB5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr30").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr30").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrB6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr31").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr31").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrB7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr32").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr32").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrB8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr33").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr33").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrB9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr34").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr34").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrB10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr35").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr35").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrB11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr36").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr36").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrB12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr37").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr37").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrB13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr38").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr38").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrB14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr39").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr39").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrB15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr40").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr40").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrB16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr41").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr41").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrB17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr42").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr42").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrB18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr43").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr43").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrB19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr44").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr44").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrB20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr45").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr45").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrB21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr46").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr46").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrB22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr47").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr47").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrB23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr48").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr48").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrB24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr49").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr49").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrB25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr50").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr50").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrC1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr51").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr51").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrC2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr52").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr52").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrC3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr53").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr53").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrC4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr54").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr54").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrC5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr55").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr55").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrC6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr56").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr56").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrC7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr57").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr57").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrC8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr58").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr58").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrC9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr59").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr59").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrC10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr60").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr60").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrC11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr61").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr61").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrC12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr62").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr62").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrC13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr63").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr63").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrC14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr64").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr64").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrC15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr65").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr65").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrC16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr66").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr66").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrC17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr67").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr67").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrC18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr68").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr68").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrC19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr69").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr69").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrC20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr70").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr70").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrC21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr71").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr71").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrC22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr72").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr72").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrC23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr73").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr73").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrC24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr74").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr74").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrC25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr75").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr75").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrD1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr76").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr76").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrD2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr77").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr77").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrD3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr78").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr78").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrD4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr79").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr79").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrD5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr80").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr80").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrD6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr81").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr81").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrD7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr82").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr82").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrD8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr83").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr83").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrD9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr84").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr84").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrD10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr85").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr85").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrD11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr86").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr86").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrD12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr87").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr87").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrD13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr88").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr88").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrD14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr89").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr89").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrD15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr90").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr90").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrD16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr91").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr91").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrD17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr92").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr92").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrD18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr93").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr93").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrD19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr94").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr94").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrD20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr95").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr95").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrD21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr96").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr96").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrD22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr97").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr97").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrD23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr98").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr98").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrD24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr99").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr99").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrD25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr100").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr100").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrE1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr101").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr101").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrE2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr102").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr102").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrE3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr103").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr103").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrE4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr104").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr104").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrE5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr105").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr105").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrE6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr106").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr106").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrE7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr107").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr107").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrE8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr108").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr108").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrE9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr109").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr109").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrE10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr110").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr110").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrE11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr111").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr111").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrE12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr112").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr112").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrE13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr113").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr113").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrE14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr114").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr114").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrE15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr115").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr115").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrE16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr116").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr116").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrE17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr117").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr117").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrE18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr118").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr118").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrE19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr119").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr119").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrE20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr120").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr120").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrE21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr121").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr121").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrE22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr122").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr122").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrE23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr123").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr123").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrE24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr124").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr124").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrE25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr125").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr125").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrF1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr126").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr126").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrF2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr127").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr127").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrF3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr128").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr128").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrF4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr129").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr129").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrF5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr130").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr130").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrF6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr131").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr131").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrF7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr132").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr132").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrF8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr133").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr133").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrF9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr134").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr134").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrF10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr135").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr135").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrF11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr136").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr136").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrF12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr137").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr137").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrF13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr138").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr138").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrF14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr139").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr139").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrF15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr140").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr140").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrF16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr141").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr141").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrF17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr142").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr142").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrF18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr143").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr143").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrF19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr144").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr144").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrF20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr145").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr145").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrF21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr146").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr146").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrF22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr147").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr147").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrF23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr148").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr148").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrF24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr149").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr149").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrF25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr150").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr150").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrG1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr151").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr151").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrG2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr152").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr152").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrG3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr153").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr153").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrG4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr154").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr154").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrG5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr155").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr155").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrG6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr156").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr156").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrG7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr157").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr157").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrG8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr158").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr158").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrG9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr159").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr159").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrG10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr160").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr160").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrG11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr161").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr161").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrG12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr162").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr162").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrG13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr163").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr163").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrG14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr164").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr164").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrG15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr165").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr165").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrG16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr166").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr166").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrG17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr167").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr167").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrG18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr168").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr168").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrG19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr169").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr169").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrG20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr170").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr170").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrG21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr171").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr171").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrG22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr172").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr172").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrG23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr173").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr173").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrG24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr174").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr174").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrG25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr175").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr175").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrH1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr176").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr176").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrH2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr177").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr177").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrH3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr178").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr178").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrH4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr179").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr179").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrH5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr180").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr180").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrH6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr181").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr181").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrH7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr182").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr182").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrH8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr183").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr183").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrH9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr184").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr184").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrH10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr185").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr185").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrH11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr186").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr186").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrH12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr187").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr187").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrH13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr188").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr188").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrH14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr189").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr189").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrH15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr190").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr190").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrH16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr191").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr191").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrH17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr192").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr192").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrH18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr193").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr193").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrH19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr194").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr194").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrH20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr195").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr195").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrH21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr196").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr196").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrH22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr197").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr197").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrH23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr198").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr198").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrH24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr199").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr199").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrH25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr200").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr200").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrI1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr201").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr201").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrI2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr202").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr202").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrI3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr203").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr203").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrI4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr204").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr204").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrI5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr205").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr205").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrI6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr206").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr206").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrI7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr207").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr207").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrI8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr208").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr208").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrI9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr209").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr209").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrI10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr210").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr210").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrI11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr211").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr211").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrI12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr212").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr212").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrI13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr213").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr213").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrI14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr214").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr214").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrI15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr215").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr215").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrI16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr216").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr216").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrI17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr217").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr217").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrI18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr218").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr218").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrI19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr219").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr219").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrI20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr220").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr220").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrI21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr221").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr221").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrI22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr222").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr222").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrI23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr223").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr223").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrI24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr224").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr224").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrI25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr225").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr225").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrJ1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr226").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr226").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrJ2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr227").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr227").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrJ3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr228").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr228").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrJ4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr229").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr229").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrJ5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr230").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr230").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrJ6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr231").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr231").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrJ7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr232").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr232").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrJ8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr233").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr233").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrJ9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr234").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr234").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrJ10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr235").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr235").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrJ11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr236").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr236").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrJ12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr237").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr237").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrJ13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr238").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr238").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrJ14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr239").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr239").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrJ15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr240").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr240").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrJ16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr241").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr241").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrJ17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr242").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr242").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrJ18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr243").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr243").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrJ19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr244").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr244").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrJ20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr245").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr245").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrJ21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr246").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr246").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrJ22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr247").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr247").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrJ23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr248").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr248").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrJ24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr249").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr249").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrJ25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr250").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr250").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrK1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr251").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr251").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrK2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr252").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr252").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrK3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr253").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr253").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrK4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr254").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr254").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrK5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr255").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr255").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrK6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr256").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr256").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrK7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr257").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr257").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrK8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr258").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr258").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrK9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr259").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr259").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrK10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr260").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr260").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrK11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr261").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr261").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrK12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr262").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr262").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrK13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr263").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr263").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrK14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr264").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr264").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrK15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr265").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr265").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrK16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr266").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr266").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrK17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr267").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr267").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrK18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr268").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr268").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrK19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr269").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr269").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrK20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr270").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr270").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrK21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr271").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr271").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrK22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr272").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr272").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrK23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr273").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr273").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrK24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr274").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr274").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrK25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr275").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr275").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrL1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr276").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr276").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrL2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr277").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr277").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrL3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr278").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr278").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrL4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr279").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr279").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrL5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr280").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr280").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrL6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr281").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr281").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrL7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr282").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr282").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrL8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr283").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr283").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrL9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr284").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr284").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrL10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr285").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr285").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrL11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr286").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr286").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrL12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr287").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr287").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrL13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr288").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr288").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrL14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr289").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr289").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrL15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr290").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr290").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrL16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr291").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr291").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrL17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr292").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr292").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrL18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr293").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr293").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrL19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr294").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr294").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrL20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr295").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr295").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrL21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr296").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr296").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrL22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr297").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr297").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrL23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr298").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr298").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrL24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr299").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr299").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrL25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr300").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr300").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrM1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr301").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr301").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrM2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr302").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr302").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrM3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr303").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr303").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrM4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr304").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr304").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrM5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr305").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr305").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrM6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr306").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr306").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrM7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr307").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr307").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrM8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr308").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr308").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrM9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr309").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr309").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrM10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr310").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr310").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrM11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr311").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr311").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrM12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr312").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr312").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrM13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr313").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr313").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrM14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr314").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr314").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrM15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr315").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr315").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrM16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr316").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr316").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrM17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr317").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr317").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrM18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr318").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr318").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrM19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr319").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr319").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrM20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr320").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr320").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrM21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr321").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr321").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrM22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr322").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr322").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrM23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr323").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr323").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrM24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr324").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr324").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrM25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr325").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr325").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrN1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr326").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr326").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrN2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr327").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr327").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrN3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr328").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr328").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrN4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr329").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr329").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrN5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr330").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr330").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrN6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr331").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr331").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrN7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr332").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr332").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrN8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr333").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr333").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrN9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr334").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr334").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrN10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr335").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr335").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrN11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr336").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr336").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrN12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr337").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr337").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrN13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr338").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr338").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrN14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr339").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr339").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrN15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr340").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr340").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrN16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr341").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr341").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrN17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr342").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr342").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrN18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr343").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr343").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrN19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr344").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr344").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrN20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr345").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr345").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrN21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr346").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr346").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrN22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr347").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr347").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrN23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr348").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr348").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrN24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr349").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr349").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrN25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr350").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr350").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrO1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr351").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr351").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrO2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr352").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr352").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrO3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr353").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr353").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrO4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr354").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr354").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrO5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr355").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr355").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrO6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr356").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr356").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrO7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr357").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr357").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrO8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr358").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr358").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrO9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr359").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr359").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrO10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr360").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr360").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrO11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr361").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr361").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrO12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr362").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr362").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrO13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr363").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr363").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrO14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr364").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr364").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrO15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr365").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr365").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrO16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr366").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr366").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrO17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr367").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr367").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrO18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr368").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr368").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrO19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr369").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr369").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrO20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr370").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr370").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrO21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr371").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr371").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrO22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr372").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr372").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrO23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr373").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr373").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrO24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr374").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr374").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrO25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr375").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr375").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrP1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr376").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr376").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrP2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr377").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr377").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrP3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr378").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr378").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrP4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr379").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr379").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrP5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr380").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr380").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrP6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr381").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr381").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrP7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr382").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr382").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrP8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr383").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr383").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrP9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr384").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr384").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrP10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr385").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr385").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrP11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr386").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr386").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrP12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr387").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr387").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrP13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr388").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr388").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrP14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr389").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr389").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrP15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr390").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr390").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrP16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr391").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr391").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrP17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr392").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr392").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrP18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr393").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr393").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrP19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr394").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr394").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrP20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr395").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr395").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrP21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr396").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr396").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrP22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr397").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr397").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrP23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr398").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr398").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrP24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr399").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr399").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrP25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr400").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr400").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrQ1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr401").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr401").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrQ2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr402").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr402").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrQ3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr403").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr403").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrQ4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr404").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr404").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrQ5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr405").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr405").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrQ6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr406").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr406").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrQ7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr407").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr407").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrQ8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr408").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr408").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrQ9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr409").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr409").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrQ10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr410").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr410").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrQ11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr411").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr411").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrQ12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr412").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr412").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrQ13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr413").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr413").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrQ14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr414").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr414").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrQ15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr415").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr415").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrQ16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr416").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr416").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrQ17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr417").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr417").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrQ18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr418").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr418").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrQ19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr419").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr419").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrQ20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr420").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr420").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrQ21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr421").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr421").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrQ22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr422").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr422").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrQ23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr423").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr423").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrQ24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr424").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr424").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrQ25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr425").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr425").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrR1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr426").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr426").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrR2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr427").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr427").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrR3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr428").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr428").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrR4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr429").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr429").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrR5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr430").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr430").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrR6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr431").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr431").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrR7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr432").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr432").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrR8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr433").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr433").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrR9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr434").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr434").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrR10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr435").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr435").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrR11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr436").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr436").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrR12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr437").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr437").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrR13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr438").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr438").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrR14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr439").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr439").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrR15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr440").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr440").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrR16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr441").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr441").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrR17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr442").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr442").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrR18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr443").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr443").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrR19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr444").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr444").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrR20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr445").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr445").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrR21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr446").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr446").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrR22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr447").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr447").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrR23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr448").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr448").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrR24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr449").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr449").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrR25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr450").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr450").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrS1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr451").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr451").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrS2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr452").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr452").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrS3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr453").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr453").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrS4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr454").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr454").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrS5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr455").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr455").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrS6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr456").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr456").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrS7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr457").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr457").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrS8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr458").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr458").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrS9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr459").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr459").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrS10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr460").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr460").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrS11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr461").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr461").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrS12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr462").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr462").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrS13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr463").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr463").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrS14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr464").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr464").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrS15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr465").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr465").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrS16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr466").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr466").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrS17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr467").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr467").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrS18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr468").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr468").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrS19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr469").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr469").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrS20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr470").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr470").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrS21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr471").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr471").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrS22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr472").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr472").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrS23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr473").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr473").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrS24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr474").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr474").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrS25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr475").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr475").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrT1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr476").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr476").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrT2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr477").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr477").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrT3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr478").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr478").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrT4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr479").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr479").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrT5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr480").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr480").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrT6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr481").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr481").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrT7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr482").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr482").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrT8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr483").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr483").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrT9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr484").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr484").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrT10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr485").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr485").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrT11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr486").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr486").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrT12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr487").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr487").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrT13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr488").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr488").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrT14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr489").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr489").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrT15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr490").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr490").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrT16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr491").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr491").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrT17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr492").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr492").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrT18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr493").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr493").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrT19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr494").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr494").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrT20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr495").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr495").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrT21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr496").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr496").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrT22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr497").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr497").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrT23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr498").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr498").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrT24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr499").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr499").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrT25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr500").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr500").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrU1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr501").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr501").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrU2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr502").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr502").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrU3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr503").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr503").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrU4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr504").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr504").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrU5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr505").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr505").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrU6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr506").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr506").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrU7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr507").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr507").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrU8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr508").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr508").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrU9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr509").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr509").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrU10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr510").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr510").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrU11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr511").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr511").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrU12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr512").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr512").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrU13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr513").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr513").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrU14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr514").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr514").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrU15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr515").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr515").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrU16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr516").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr516").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrU17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr517").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr517").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrU18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr518").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr518").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrU19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr519").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr519").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrU20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr520").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr520").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrU21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr521").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr521").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrU22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr522").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr522").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrU23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr523").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr523").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrU24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr524").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr524").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrU25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr525").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr525").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrV1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr526").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr526").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrV2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr527").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr527").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrV3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr528").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr528").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrV4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr529").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr529").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrV5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr530").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr530").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrV6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr531").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr531").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrV7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr532").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr532").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrV8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr533").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr533").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrV9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr534").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr534").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrV10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr535").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr535").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrV11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr536").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr536").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrV12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr537").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr537").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrV13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr538").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr538").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrV14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr539").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr539").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrV15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr540").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr540").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrV16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr541").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr541").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrV17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr542").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr542").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrV18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr543").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr543").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrV19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr544").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr544").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrV20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr545").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr545").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrV21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr546").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr546").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrV22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr547").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr547").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrV23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr548").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr548").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrV24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr549").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr549").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrV25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr550").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr550").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrW1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr551").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr551").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrW2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr552").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr552").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrW3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr553").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr553").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrW4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr554").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr554").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrW5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr555").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr555").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrW6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr556").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr556").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrW7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr557").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr557").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrW8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr558").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr558").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrW9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr559").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr559").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrW10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr560").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr560").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrW11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr561").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr561").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrW12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr562").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr562").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrW13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr563").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr563").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrW14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr564").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr564").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrW15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr565").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr565").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrW16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr566").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr566").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrW17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr567").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr567").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrW18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr568").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr568").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrW19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr569").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr569").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrW20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr570").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr570").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrW21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr571").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr571").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrW22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr572").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr572").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrW23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr573").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr573").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrW24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr574").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr574").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrW25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr575").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr575").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrX1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr576").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr576").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrX2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr577").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr577").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrX3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr578").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr578").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrX4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr579").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr579").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrX5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr580").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr580").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrX6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr581").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr581").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrX7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr582").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr582").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrX8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr583").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr583").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrX9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr584").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr584").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrX10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr585").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr585").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrX11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr586").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr586").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrX12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr587").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr587").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrX13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr588").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr588").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrX14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr589").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr589").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrX15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr590").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr590").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrX16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr591").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr591").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrX17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr592").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr592").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrX18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr593").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr593").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrX19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr594").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr594").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrX20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr595").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr595").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrX21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr596").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr596").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrX22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr597").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr597").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrX23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr598").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr598").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrX24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr599").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr599").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrX25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr600").src = "https://www.writersjumbler.com/img/sqrs/wSqr2.png") {
    document.getElementById("imgSqr600").src = "https://www.writersjumbler.com/img/sqrs/blSqr2.png"
};};};
function asqrY1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr601").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr601").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrY2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr602").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr602").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrY3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr603").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr603").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrY4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr604").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr604").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrY5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr605").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr605").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrY6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr606").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr606").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrY7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr607").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr607").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrY8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr608").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr608").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrY9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr609").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr609").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrY10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr610").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr610").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrY11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr611").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr611").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrY12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr612").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr612").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrY13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr613").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr613").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrY14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr614").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr614").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrY15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr615").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr615").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrY16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr616").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr616").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrY17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr617").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr617").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrY18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr618").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr618").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrY19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr619").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr619").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrY20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr620").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr620").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrY21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr621").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr621").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrY22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr622").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr622").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrY23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr623").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr623").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrY24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr624").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr624").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};
function asqrY25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr625").src = "https://www.writersjumbler.com/img/sqrs/wSqr3.png") {
    document.getElementById("imgSqr625").src = "https://www.writersjumbler.com/img/sqrs/blSqr3.png"
};};};