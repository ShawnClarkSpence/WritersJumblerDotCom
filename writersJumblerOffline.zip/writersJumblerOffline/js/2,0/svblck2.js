function square1(){
    var sQAz0 = document.getElementById("imgSqr1").src;
    valueQaSave1 = 'zSqrArtSpecz0';
    localStorage.setItem(valueQaSave1, sQAz0);
};

function square2(){
    var sQAz1 = document.getElementById("imgSqr2").src;
    valueQaSave2 = 'zSqrArtSpecz1';
    localStorage.setItem(valueQaSave2, sQAz1);
};

function square3(){
    var sQAz2 = document.getElementById("imgSqr3").src;
    valueQaSave3 = 'zSqrArtSpecz2';
    localStorage.setItem(valueQaSave3, sQAz2);
};

function square4(){
    var sQAz3 = document.getElementById("imgSqr4").src;
    valueQaSave4 = 'zSqrArtSpecz3';
    localStorage.setItem(valueQaSave4, sQAz3);
};

function square5(){
    var sQAz4 = document.getElementById("imgSqr5").src;
    valueQaSave5 = 'zSqrArtSpecz4';
    localStorage.setItem(valueQaSave5, sQAz4);
};

function square6(){
    var sQAz5 = document.getElementById("imgSqr6").src;
    valueQaSave6 = 'zSqrArtSpecz5';
    localStorage.setItem(valueQaSave6, sQAz5);
};

function square7(){
    var sQAz6 = document.getElementById("imgSqr7").src;
    valueQaSave7 = 'zSqrArtSpecz6';
    localStorage.setItem(valueQaSave7, sQAz6);
};

function square8(){
    var sQAz7 = document.getElementById("imgSqr8").src;
    valueQaSave8 = 'zSqrArtSpecz7';
    localStorage.setItem(valueQaSave8, sQAz7);
};

function square9(){
    var sQAz8 = document.getElementById("imgSqr9").src;
    valueQaSave9 = 'zSqrArtSpecz8';
    localStorage.setItem(valueQaSave9, sQAz8);
};

function square10(){
    var sQAz9 = document.getElementById("imgSqr10").src;
    valueQaSave10 = 'zSqrArtSpecz9';
    localStorage.setItem(valueQaSave10, sQAz9);
};

function square11(){
    var sQAz10 = document.getElementById("imgSqr11").src;
    valueQaSave11 = 'zSqrArtSpecz10';
    localStorage.setItem(valueQaSave11, sQAz10);
};

function square12(){
    var sQAz11 = document.getElementById("imgSqr12").src;
    valueQaSave12 = 'zSqrArtSpecz11';
    localStorage.setItem(valueQaSave12, sQAz11);
};

function square13(){
    var sQAz12 = document.getElementById("imgSqr13").src;
    valueQaSave13 = 'zSqrArtSpecz12';
    localStorage.setItem(valueQaSave13, sQAz12);
};

function square14(){
    var sQAz13 = document.getElementById("imgSqr14").src;
    valueQaSave14 = 'zSqrArtSpecz13';
    localStorage.setItem(valueQaSave14, sQAz13);
};

function square15(){
    var sQAz14 = document.getElementById("imgSqr15").src;
    valueQaSave15 = 'zSqrArtSpecz14';
    localStorage.setItem(valueQaSave15, sQAz14);
};

function square16(){
    var sQAz15 = document.getElementById("imgSqr16").src;
    valueQaSave16 = 'zSqrArtSpecz15';
    localStorage.setItem(valueQaSave16, sQAz15);
};

function square17(){
    var sQAz16 = document.getElementById("imgSqr17").src;
    valueQaSave17 = 'zSqrArtSpecz16';
    localStorage.setItem(valueQaSave17, sQAz16);
};

function square18(){
    var sQAz17 = document.getElementById("imgSqr18").src;
    valueQaSave18 = 'zSqrArtSpecz17';
    localStorage.setItem(valueQaSave18, sQAz17);
};

function square19(){
    var sQAz18 = document.getElementById("imgSqr19").src;
    valueQaSave19 = 'zSqrArtSpecz18';
    localStorage.setItem(valueQaSave19, sQAz18);
};

function square20(){
    var sQAz19 = document.getElementById("imgSqr20").src;
    valueQaSave20 = 'zSqrArtSpecz19';
    localStorage.setItem(valueQaSave20, sQAz19);
};

function square21(){
    var sQAz20 = document.getElementById("imgSqr21").src;
    valueQaSave21 = 'zSqrArtSpecz20';
    localStorage.setItem(valueQaSave21, sQAz20);
};

function square22(){
    var sQAz21 = document.getElementById("imgSqr22").src;
    valueQaSave22 = 'zSqrArtSpecz21';
    localStorage.setItem(valueQaSave22, sQAz21);
};

function square23(){
    var sQAz22 = document.getElementById("imgSqr23").src;
    valueQaSave23 = 'zSqrArtSpecz22';
    localStorage.setItem(valueQaSave23, sQAz22);
};

function square24(){
    var sQAz23 = document.getElementById("imgSqr24").src;
    valueQaSave24 = 'zSqrArtSpecz23';
    localStorage.setItem(valueQaSave24, sQAz23);
};

function square25(){
    var sQAz24 = document.getElementById("imgSqr25").src;
    valueQaSave25 = 'zSqrArtSpecz24';
    localStorage.setItem(valueQaSave25, sQAz24);
};

function square26(){
    var sQAz25 = document.getElementById("imgSqr26").src;
    valueQaSave26 = 'zSqrArtSpecz25';
    localStorage.setItem(valueQaSave26, sQAz25);
};

function square27(){
    var sQAz26 = document.getElementById("imgSqr27").src;
    valueQaSave27 = 'zSqrArtSpecz26';
    localStorage.setItem(valueQaSave27, sQAz26);
};

function square28(){
    var sQAz27 = document.getElementById("imgSqr28").src;
    valueQaSave28 = 'zSqrArtSpecz27';
    localStorage.setItem(valueQaSave28, sQAz27);
};

function square29(){
    var sQAz28 = document.getElementById("imgSqr29").src;
    valueQaSave29 = 'zSqrArtSpecz28';
    localStorage.setItem(valueQaSave29, sQAz28);
};

function square30(){
    var sQAz29 = document.getElementById("imgSqr30").src;
    valueQaSave30 = 'zSqrArtSpecz29';
    localStorage.setItem(valueQaSave30, sQAz29);
};

function square31(){
    var sQAz30 = document.getElementById("imgSqr31").src;
    valueQaSave31 = 'zSqrArtSpecz30';
    localStorage.setItem(valueQaSave31, sQAz30);
};

function square32(){
    var sQAz31 = document.getElementById("imgSqr32").src;
    valueQaSave32 = 'zSqrArtSpecz31';
    localStorage.setItem(valueQaSave32, sQAz31);
};

function square33(){
    var sQAz32 = document.getElementById("imgSqr33").src;
    valueQaSave33 = 'zSqrArtSpecz32';
    localStorage.setItem(valueQaSave33, sQAz32);
};

function square34(){
    var sQAz33 = document.getElementById("imgSqr34").src;
    valueQaSave34 = 'zSqrArtSpecz33';
    localStorage.setItem(valueQaSave34, sQAz33);
};

function square35(){
    var sQAz34 = document.getElementById("imgSqr35").src;
    valueQaSave35 = 'zSqrArtSpecz34';
    localStorage.setItem(valueQaSave35, sQAz34);
};

function square36(){
    var sQAz35 = document.getElementById("imgSqr36").src;
    valueQaSave36 = 'zSqrArtSpecz35';
    localStorage.setItem(valueQaSave36, sQAz35);
};

function square37(){
    var sQAz36 = document.getElementById("imgSqr37").src;
    valueQaSave37 = 'zSqrArtSpecz36';
    localStorage.setItem(valueQaSave37, sQAz36);
};

function square38(){
    var sQAz37 = document.getElementById("imgSqr38").src;
    valueQaSave38 = 'zSqrArtSpecz37';
    localStorage.setItem(valueQaSave38, sQAz37);
};

function square39(){
    var sQAz38 = document.getElementById("imgSqr39").src;
    valueQaSave39 = 'zSqrArtSpecz38';
    localStorage.setItem(valueQaSave39, sQAz38);
};

function square40(){
    var sQAz39 = document.getElementById("imgSqr40").src;
    valueQaSave40 = 'zSqrArtSpecz39';
    localStorage.setItem(valueQaSave40, sQAz39);
};

function square41(){
    var sQAz40 = document.getElementById("imgSqr41").src;
    valueQaSave41 = 'zSqrArtSpecz40';
    localStorage.setItem(valueQaSave41, sQAz40);
};

function square42(){
    var sQAz41 = document.getElementById("imgSqr42").src;
    valueQaSave42 = 'zSqrArtSpecz41';
    localStorage.setItem(valueQaSave42, sQAz41);
};

function square43(){
    var sQAz42 = document.getElementById("imgSqr43").src;
    valueQaSave43 = 'zSqrArtSpecz42';
    localStorage.setItem(valueQaSave43, sQAz42);
};

function square44(){
    var sQAz43 = document.getElementById("imgSqr44").src;
    valueQaSave44 = 'zSqrArtSpecz43';
    localStorage.setItem(valueQaSave44, sQAz43);
};

function square45(){
    var sQAz44 = document.getElementById("imgSqr45").src;
    valueQaSave45 = 'zSqrArtSpecz44';
    localStorage.setItem(valueQaSave45, sQAz44);
};

function square46(){
    var sQAz45 = document.getElementById("imgSqr46").src;
    valueQaSave46 = 'zSqrArtSpecz45';
    localStorage.setItem(valueQaSave46, sQAz45);
};

function square47(){
    var sQAz46 = document.getElementById("imgSqr47").src;
    valueQaSave47 = 'zSqrArtSpecz46';
    localStorage.setItem(valueQaSave47, sQAz46);
};

function square48(){
    var sQAz47 = document.getElementById("imgSqr48").src;
    valueQaSave48 = 'zSqrArtSpecz47';
    localStorage.setItem(valueQaSave48, sQAz47);
};

function square49(){
    var sQAz48 = document.getElementById("imgSqr49").src;
    valueQaSave49 = 'zSqrArtSpecz48';
    localStorage.setItem(valueQaSave49, sQAz48);
};

function square50(){
    var sQAz49 = document.getElementById("imgSqr50").src;
    valueQaSave50 = 'zSqrArtSpecz49';
    localStorage.setItem(valueQaSave50, sQAz49);
};

function square51(){
    var sQAz50 = document.getElementById("imgSqr51").src;
    valueQaSave51 = 'zSqrArtSpecz50';
    localStorage.setItem(valueQaSave51, sQAz50);
};

function square52(){
    var sQAz51 = document.getElementById("imgSqr52").src;
    valueQaSave52 = 'zSqrArtSpecz51';
    localStorage.setItem(valueQaSave52, sQAz51);
};

function square53(){
    var sQAz52 = document.getElementById("imgSqr53").src;
    valueQaSave53 = 'zSqrArtSpecz52';
    localStorage.setItem(valueQaSave53, sQAz52);
};

function square54(){
    var sQAz53 = document.getElementById("imgSqr54").src;
    valueQaSave54 = 'zSqrArtSpecz53';
    localStorage.setItem(valueQaSave54, sQAz53);
};

function square55(){
    var sQAz54 = document.getElementById("imgSqr55").src;
    valueQaSave55 = 'zSqrArtSpecz54';
    localStorage.setItem(valueQaSave55, sQAz54);
};

function square56(){
    var sQAz55 = document.getElementById("imgSqr56").src;
    valueQaSave56 = 'zSqrArtSpecz55';
    localStorage.setItem(valueQaSave56, sQAz55);
};

function square57(){
    var sQAz56 = document.getElementById("imgSqr57").src;
    valueQaSave57 = 'zSqrArtSpecz56';
    localStorage.setItem(valueQaSave57, sQAz56);
};

function square58(){
    var sQAz57 = document.getElementById("imgSqr58").src;
    valueQaSave58 = 'zSqrArtSpecz57';
    localStorage.setItem(valueQaSave58, sQAz57);
};

function square59(){
    var sQAz58 = document.getElementById("imgSqr59").src;
    valueQaSave59 = 'zSqrArtSpecz58';
    localStorage.setItem(valueQaSave59, sQAz58);
};

function square60(){
    var sQAz59 = document.getElementById("imgSqr60").src;
    valueQaSave60 = 'zSqrArtSpecz59';
    localStorage.setItem(valueQaSave60, sQAz59);
};

function square61(){
    var sQAz60 = document.getElementById("imgSqr61").src;
    valueQaSave61 = 'zSqrArtSpecz60';
    localStorage.setItem(valueQaSave61, sQAz60);
};

function square62(){
    var sQAz61 = document.getElementById("imgSqr62").src;
    valueQaSave62 = 'zSqrArtSpecz61';
    localStorage.setItem(valueQaSave62, sQAz61);
};

function square63(){
    var sQAz62 = document.getElementById("imgSqr63").src;
    valueQaSave63 = 'zSqrArtSpecz62';
    localStorage.setItem(valueQaSave63, sQAz62);
};

function square64(){
    var sQAz63 = document.getElementById("imgSqr64").src;
    valueQaSave64 = 'zSqrArtSpecz63';
    localStorage.setItem(valueQaSave64, sQAz63);
};

function square65(){
    var sQAz64 = document.getElementById("imgSqr65").src;
    valueQaSave65 = 'zSqrArtSpecz64';
    localStorage.setItem(valueQaSave65, sQAz64);
};

function square66(){
    var sQAz65 = document.getElementById("imgSqr66").src;
    valueQaSave66 = 'zSqrArtSpecz65';
    localStorage.setItem(valueQaSave66, sQAz65);
};

function square67(){
    var sQAz66 = document.getElementById("imgSqr67").src;
    valueQaSave67 = 'zSqrArtSpecz66';
    localStorage.setItem(valueQaSave67, sQAz66);
};

function square68(){
    var sQAz67 = document.getElementById("imgSqr68").src;
    valueQaSave68 = 'zSqrArtSpecz67';
    localStorage.setItem(valueQaSave68, sQAz67);
};

function square69(){
    var sQAz68 = document.getElementById("imgSqr69").src;
    valueQaSave69 = 'zSqrArtSpecz68';
    localStorage.setItem(valueQaSave69, sQAz68);
};

function square70(){
    var sQAz69 = document.getElementById("imgSqr70").src;
    valueQaSave70 = 'zSqrArtSpecz69';
    localStorage.setItem(valueQaSave70, sQAz69);
};

function square71(){
    var sQAz70 = document.getElementById("imgSqr71").src;
    valueQaSave71 = 'zSqrArtSpecz70';
    localStorage.setItem(valueQaSave71, sQAz70);
};

function square72(){
    var sQAz71 = document.getElementById("imgSqr72").src;
    valueQaSave72 = 'zSqrArtSpecz71';
    localStorage.setItem(valueQaSave72, sQAz71);
};

function square73(){
    var sQAz72 = document.getElementById("imgSqr73").src;
    valueQaSave73 = 'zSqrArtSpecz72';
    localStorage.setItem(valueQaSave73, sQAz72);
};

function square74(){
    var sQAz73 = document.getElementById("imgSqr74").src;
    valueQaSave74 = 'zSqrArtSpecz73';
    localStorage.setItem(valueQaSave74, sQAz73);
};

function square75(){
    var sQAz74 = document.getElementById("imgSqr75").src;
    valueQaSave75 = 'zSqrArtSpecz74';
    localStorage.setItem(valueQaSave75, sQAz74);
};

function square76(){
    var sQAz75 = document.getElementById("imgSqr76").src;
    valueQaSave76 = 'zSqrArtSpecz75';
    localStorage.setItem(valueQaSave76, sQAz75);
};

function square77(){
    var sQAz76 = document.getElementById("imgSqr77").src;
    valueQaSave77 = 'zSqrArtSpecz76';
    localStorage.setItem(valueQaSave77, sQAz76);
};

function square78(){
    var sQAz77 = document.getElementById("imgSqr78").src;
    valueQaSave78 = 'zSqrArtSpecz77';
    localStorage.setItem(valueQaSave78, sQAz77);
};

function square79(){
    var sQAz78 = document.getElementById("imgSqr79").src;
    valueQaSave79 = 'zSqrArtSpecz78';
    localStorage.setItem(valueQaSave79, sQAz78);
};

function square80(){
    var sQAz79 = document.getElementById("imgSqr80").src;
    valueQaSave80 = 'zSqrArtSpecz79';
    localStorage.setItem(valueQaSave80, sQAz79);
};

function square81(){
    var sQAz80 = document.getElementById("imgSqr81").src;
    valueQaSave81 = 'zSqrArtSpecz80';
    localStorage.setItem(valueQaSave81, sQAz80);
};

function square82(){
    var sQAz81 = document.getElementById("imgSqr82").src;
    valueQaSave82 = 'zSqrArtSpecz81';
    localStorage.setItem(valueQaSave82, sQAz81);
};

function square83(){
    var sQAz82 = document.getElementById("imgSqr83").src;
    valueQaSave83 = 'zSqrArtSpecz82';
    localStorage.setItem(valueQaSave83, sQAz82);
};

function square84(){
    var sQAz83 = document.getElementById("imgSqr84").src;
    valueQaSave84 = 'zSqrArtSpecz83';
    localStorage.setItem(valueQaSave84, sQAz83);
};

function square85(){
    var sQAz84 = document.getElementById("imgSqr85").src;
    valueQaSave85 = 'zSqrArtSpecz84';
    localStorage.setItem(valueQaSave85, sQAz84);
};

function square86(){
    var sQAz85 = document.getElementById("imgSqr86").src;
    valueQaSave86 = 'zSqrArtSpecz85';
    localStorage.setItem(valueQaSave86, sQAz85);
};

function square87(){
    var sQAz86 = document.getElementById("imgSqr87").src;
    valueQaSave87 = 'zSqrArtSpecz86';
    localStorage.setItem(valueQaSave87, sQAz86);
};

function square88(){
    var sQAz87 = document.getElementById("imgSqr88").src;
    valueQaSave88 = 'zSqrArtSpecz87';
    localStorage.setItem(valueQaSave88, sQAz87);
};

function square89(){
    var sQAz88 = document.getElementById("imgSqr89").src;
    valueQaSave89 = 'zSqrArtSpecz88';
    localStorage.setItem(valueQaSave89, sQAz88);
};

function square90(){
    var sQAz89 = document.getElementById("imgSqr90").src;
    valueQaSave90 = 'zSqrArtSpecz89';
    localStorage.setItem(valueQaSave90, sQAz89);
};

function square91(){
    var sQAz90 = document.getElementById("imgSqr91").src;
    valueQaSave91 = 'zSqrArtSpecz90';
    localStorage.setItem(valueQaSave91, sQAz90);
};

function square92(){
    var sQAz91 = document.getElementById("imgSqr92").src;
    valueQaSave92 = 'zSqrArtSpecz91';
    localStorage.setItem(valueQaSave92, sQAz91);
};

function square93(){
    var sQAz92 = document.getElementById("imgSqr93").src;
    valueQaSave93 = 'zSqrArtSpecz92';
    localStorage.setItem(valueQaSave93, sQAz92);
};

function square94(){
    var sQAz93 = document.getElementById("imgSqr94").src;
    valueQaSave94 = 'zSqrArtSpecz93';
    localStorage.setItem(valueQaSave94, sQAz93);
};

function square95(){
    var sQAz94 = document.getElementById("imgSqr95").src;
    valueQaSave95 = 'zSqrArtSpecz94';
    localStorage.setItem(valueQaSave95, sQAz94);
};

function square96(){
    var sQAz95 = document.getElementById("imgSqr96").src;
    valueQaSave96 = 'zSqrArtSpecz95';
    localStorage.setItem(valueQaSave96, sQAz95);
};

function square97(){
    var sQAz96 = document.getElementById("imgSqr97").src;
    valueQaSave97 = 'zSqrArtSpecz96';
    localStorage.setItem(valueQaSave97, sQAz96);
};

function square98(){
    var sQAz97 = document.getElementById("imgSqr98").src;
    valueQaSave98 = 'zSqrArtSpecz97';
    localStorage.setItem(valueQaSave98, sQAz97);
};

function square99(){
    var sQAz98 = document.getElementById("imgSqr99").src;
    valueQaSave99 = 'zSqrArtSpecz98';
    localStorage.setItem(valueQaSave99, sQAz98);
};

function square100(){
    var sQAz99 = document.getElementById("imgSqr100").src;
    valueQaSave100 = 'zSqrArtSpecz99';
    localStorage.setItem(valueQaSave100, sQAz99);
};

function square101(){
    var sQAz100 = document.getElementById("imgSqr101").src;
    valueQaSave101 = 'zSqrArtSpecz100';
    localStorage.setItem(valueQaSave101, sQAz100);
};

function square102(){
    var sQAz101 = document.getElementById("imgSqr102").src;
    valueQaSave102 = 'zSqrArtSpecz101';
    localStorage.setItem(valueQaSave102, sQAz101);
};

function square103(){
    var sQAz102 = document.getElementById("imgSqr103").src;
    valueQaSave103 = 'zSqrArtSpecz102';
    localStorage.setItem(valueQaSave103, sQAz102);
};

function square104(){
    var sQAz103 = document.getElementById("imgSqr104").src;
    valueQaSave104 = 'zSqrArtSpecz103';
    localStorage.setItem(valueQaSave104, sQAz103);
};

function square105(){
    var sQAz104 = document.getElementById("imgSqr105").src;
    valueQaSave105 = 'zSqrArtSpecz104';
    localStorage.setItem(valueQaSave105, sQAz104);
};

function square106(){
    var sQAz105 = document.getElementById("imgSqr106").src;
    valueQaSave106 = 'zSqrArtSpecz105';
    localStorage.setItem(valueQaSave106, sQAz105);
};

function square107(){
    var sQAz106 = document.getElementById("imgSqr107").src;
    valueQaSave107 = 'zSqrArtSpecz106';
    localStorage.setItem(valueQaSave107, sQAz106);
};

function square108(){
    var sQAz107 = document.getElementById("imgSqr108").src;
    valueQaSave108 = 'zSqrArtSpecz107';
    localStorage.setItem(valueQaSave108, sQAz107);
};

function square109(){
    var sQAz108 = document.getElementById("imgSqr109").src;
    valueQaSave109 = 'zSqrArtSpecz108';
    localStorage.setItem(valueQaSave109, sQAz108);
};

function square110(){
    var sQAz109 = document.getElementById("imgSqr110").src;
    valueQaSave110 = 'zSqrArtSpecz109';
    localStorage.setItem(valueQaSave110, sQAz109);
};

function square111(){
    var sQAz110 = document.getElementById("imgSqr111").src;
    valueQaSave111 = 'zSqrArtSpecz110';
    localStorage.setItem(valueQaSave111, sQAz110);
};

function square112(){
    var sQAz111 = document.getElementById("imgSqr112").src;
    valueQaSave112 = 'zSqrArtSpecz111';
    localStorage.setItem(valueQaSave112, sQAz111);
};

function square113(){
    var sQAz112 = document.getElementById("imgSqr113").src;
    valueQaSave113 = 'zSqrArtSpecz112';
    localStorage.setItem(valueQaSave113, sQAz112);
};

function square114(){
    var sQAz113 = document.getElementById("imgSqr114").src;
    valueQaSave114 = 'zSqrArtSpecz113';
    localStorage.setItem(valueQaSave114, sQAz113);
};

function square115(){
    var sQAz114 = document.getElementById("imgSqr115").src;
    valueQaSave115 = 'zSqrArtSpecz114';
    localStorage.setItem(valueQaSave115, sQAz114);
};

function square116(){
    var sQAz115 = document.getElementById("imgSqr116").src;
    valueQaSave116 = 'zSqrArtSpecz115';
    localStorage.setItem(valueQaSave116, sQAz115);
};

function square117(){
    var sQAz116 = document.getElementById("imgSqr117").src;
    valueQaSave117 = 'zSqrArtSpecz116';
    localStorage.setItem(valueQaSave117, sQAz116);
};

function square118(){
    var sQAz117 = document.getElementById("imgSqr118").src;
    valueQaSave118 = 'zSqrArtSpecz117';
    localStorage.setItem(valueQaSave118, sQAz117);
};

function square119(){
    var sQAz118 = document.getElementById("imgSqr119").src;
    valueQaSave119 = 'zSqrArtSpecz118';
    localStorage.setItem(valueQaSave119, sQAz118);
};

function square120(){
    var sQAz119 = document.getElementById("imgSqr120").src;
    valueQaSave120 = 'zSqrArtSpecz119';
    localStorage.setItem(valueQaSave120, sQAz119);
};

function square121(){
    var sQAz120 = document.getElementById("imgSqr121").src;
    valueQaSave121 = 'zSqrArtSpecz120';
    localStorage.setItem(valueQaSave121, sQAz120);
};

function square122(){
    var sQAz121 = document.getElementById("imgSqr122").src;
    valueQaSave122 = 'zSqrArtSpecz121';
    localStorage.setItem(valueQaSave122, sQAz121);
};

function square123(){
    var sQAz122 = document.getElementById("imgSqr123").src;
    valueQaSave123 = 'zSqrArtSpecz122';
    localStorage.setItem(valueQaSave123, sQAz122);
};

function square124(){
    var sQAz123 = document.getElementById("imgSqr124").src;
    valueQaSave124 = 'zSqrArtSpecz123';
    localStorage.setItem(valueQaSave124, sQAz123);
};

function square125(){
    var sQAz124 = document.getElementById("imgSqr125").src;
    valueQaSave125 = 'zSqrArtSpecz124';
    localStorage.setItem(valueQaSave125, sQAz124);
};

function square126(){
    var sQAz125 = document.getElementById("imgSqr126").src;
    valueQaSave126 = 'zSqrArtSpecz125';
    localStorage.setItem(valueQaSave126, sQAz125);
};

function square127(){
    var sQAz126 = document.getElementById("imgSqr127").src;
    valueQaSave127 = 'zSqrArtSpecz126';
    localStorage.setItem(valueQaSave127, sQAz126);
};

function square128(){
    var sQAz127 = document.getElementById("imgSqr128").src;
    valueQaSave128 = 'zSqrArtSpecz127';
    localStorage.setItem(valueQaSave128, sQAz127);
};

function square129(){
    var sQAz128 = document.getElementById("imgSqr129").src;
    valueQaSave129 = 'zSqrArtSpecz128';
    localStorage.setItem(valueQaSave129, sQAz128);
};

function square130(){
    var sQAz129 = document.getElementById("imgSqr130").src;
    valueQaSave130 = 'zSqrArtSpecz129';
    localStorage.setItem(valueQaSave130, sQAz129);
};

function square131(){
    var sQAz130 = document.getElementById("imgSqr131").src;
    valueQaSave131 = 'zSqrArtSpecz130';
    localStorage.setItem(valueQaSave131, sQAz130);
};

function square132(){
    var sQAz131 = document.getElementById("imgSqr132").src;
    valueQaSave132 = 'zSqrArtSpecz131';
    localStorage.setItem(valueQaSave132, sQAz131);
};

function square133(){
    var sQAz132 = document.getElementById("imgSqr133").src;
    valueQaSave133 = 'zSqrArtSpecz132';
    localStorage.setItem(valueQaSave133, sQAz132);
};

function square134(){
    var sQAz133 = document.getElementById("imgSqr134").src;
    valueQaSave134 = 'zSqrArtSpecz133';
    localStorage.setItem(valueQaSave134, sQAz133);
};

function square135(){
    var sQAz134 = document.getElementById("imgSqr135").src;
    valueQaSave135 = 'zSqrArtSpecz134';
    localStorage.setItem(valueQaSave135, sQAz134);
};

function square136(){
    var sQAz135 = document.getElementById("imgSqr136").src;
    valueQaSave136 = 'zSqrArtSpecz135';
    localStorage.setItem(valueQaSave136, sQAz135);
};

function square137(){
    var sQAz136 = document.getElementById("imgSqr137").src;
    valueQaSave137 = 'zSqrArtSpecz136';
    localStorage.setItem(valueQaSave137, sQAz136);
};

function square138(){
    var sQAz137 = document.getElementById("imgSqr138").src;
    valueQaSave138 = 'zSqrArtSpecz137';
    localStorage.setItem(valueQaSave138, sQAz137);
};

function square139(){
    var sQAz138 = document.getElementById("imgSqr139").src;
    valueQaSave139 = 'zSqrArtSpecz138';
    localStorage.setItem(valueQaSave139, sQAz138);
};

function square140(){
    var sQAz139 = document.getElementById("imgSqr140").src;
    valueQaSave140 = 'zSqrArtSpecz139';
    localStorage.setItem(valueQaSave140, sQAz139);
};

function square141(){
    var sQAz140 = document.getElementById("imgSqr141").src;
    valueQaSave141 = 'zSqrArtSpecz140';
    localStorage.setItem(valueQaSave141, sQAz140);
};

function square142(){
    var sQAz141 = document.getElementById("imgSqr142").src;
    valueQaSave142 = 'zSqrArtSpecz141';
    localStorage.setItem(valueQaSave142, sQAz141);
};

function square143(){
    var sQAz142 = document.getElementById("imgSqr143").src;
    valueQaSave143 = 'zSqrArtSpecz142';
    localStorage.setItem(valueQaSave143, sQAz142);
};

function square144(){
    var sQAz143 = document.getElementById("imgSqr144").src;
    valueQaSave144 = 'zSqrArtSpecz143';
    localStorage.setItem(valueQaSave144, sQAz143);
};

function square145(){
    var sQAz144 = document.getElementById("imgSqr145").src;
    valueQaSave145 = 'zSqrArtSpecz144';
    localStorage.setItem(valueQaSave145, sQAz144);
};

function square146(){
    var sQAz145 = document.getElementById("imgSqr146").src;
    valueQaSave146 = 'zSqrArtSpecz145';
    localStorage.setItem(valueQaSave146, sQAz145);
};

function square147(){
    var sQAz146 = document.getElementById("imgSqr147").src;
    valueQaSave147 = 'zSqrArtSpecz146';
    localStorage.setItem(valueQaSave147, sQAz146);
};

function square148(){
    var sQAz147 = document.getElementById("imgSqr148").src;
    valueQaSave148 = 'zSqrArtSpecz147';
    localStorage.setItem(valueQaSave148, sQAz147);
};

function square149(){
    var sQAz148 = document.getElementById("imgSqr149").src;
    valueQaSave149 = 'zSqrArtSpecz148';
    localStorage.setItem(valueQaSave149, sQAz148);
};

function square150(){
    var sQAz149 = document.getElementById("imgSqr150").src;
    valueQaSave150 = 'zSqrArtSpecz149';
    localStorage.setItem(valueQaSave150, sQAz149);
};

function square151(){
    var sQAz150 = document.getElementById("imgSqr151").src;
    valueQaSave151 = 'zSqrArtSpecz150';
    localStorage.setItem(valueQaSave151, sQAz150);
};

function square152(){
    var sQAz151 = document.getElementById("imgSqr152").src;
    valueQaSave152 = 'zSqrArtSpecz151';
    localStorage.setItem(valueQaSave152, sQAz151);
};

function square153(){
    var sQAz152 = document.getElementById("imgSqr153").src;
    valueQaSave153 = 'zSqrArtSpecz152';
    localStorage.setItem(valueQaSave153, sQAz152);
};

function square154(){
    var sQAz153 = document.getElementById("imgSqr154").src;
    valueQaSave154 = 'zSqrArtSpecz153';
    localStorage.setItem(valueQaSave154, sQAz153);
};

function square155(){
    var sQAz154 = document.getElementById("imgSqr155").src;
    valueQaSave155 = 'zSqrArtSpecz154';
    localStorage.setItem(valueQaSave155, sQAz154);
};

function square156(){
    var sQAz155 = document.getElementById("imgSqr156").src;
    valueQaSave156 = 'zSqrArtSpecz155';
    localStorage.setItem(valueQaSave156, sQAz155);
};

function square157(){
    var sQAz156 = document.getElementById("imgSqr157").src;
    valueQaSave157 = 'zSqrArtSpecz156';
    localStorage.setItem(valueQaSave157, sQAz156);
};

function square158(){
    var sQAz157 = document.getElementById("imgSqr158").src;
    valueQaSave158 = 'zSqrArtSpecz157';
    localStorage.setItem(valueQaSave158, sQAz157);
};

function square159(){
    var sQAz158 = document.getElementById("imgSqr159").src;
    valueQaSave159 = 'zSqrArtSpecz158';
    localStorage.setItem(valueQaSave159, sQAz158);
};

function square160(){
    var sQAz159 = document.getElementById("imgSqr160").src;
    valueQaSave160 = 'zSqrArtSpecz159';
    localStorage.setItem(valueQaSave160, sQAz159);
};

function square161(){
    var sQAz160 = document.getElementById("imgSqr161").src;
    valueQaSave161 = 'zSqrArtSpecz160';
    localStorage.setItem(valueQaSave161, sQAz160);
};

function square162(){
    var sQAz161 = document.getElementById("imgSqr162").src;
    valueQaSave162 = 'zSqrArtSpecz161';
    localStorage.setItem(valueQaSave162, sQAz161);
};

function square163(){
    var sQAz162 = document.getElementById("imgSqr163").src;
    valueQaSave163 = 'zSqrArtSpecz162';
    localStorage.setItem(valueQaSave163, sQAz162);
};

function square164(){
    var sQAz163 = document.getElementById("imgSqr164").src;
    valueQaSave164 = 'zSqrArtSpecz163';
    localStorage.setItem(valueQaSave164, sQAz163);
};

function square165(){
    var sQAz164 = document.getElementById("imgSqr165").src;
    valueQaSave165 = 'zSqrArtSpecz164';
    localStorage.setItem(valueQaSave165, sQAz164);
};

function square166(){
    var sQAz165 = document.getElementById("imgSqr166").src;
    valueQaSave166 = 'zSqrArtSpecz165';
    localStorage.setItem(valueQaSave166, sQAz165);
};

function square167(){
    var sQAz166 = document.getElementById("imgSqr167").src;
    valueQaSave167 = 'zSqrArtSpecz166';
    localStorage.setItem(valueQaSave167, sQAz166);
};

function square168(){
    var sQAz167 = document.getElementById("imgSqr168").src;
    valueQaSave168 = 'zSqrArtSpecz167';
    localStorage.setItem(valueQaSave168, sQAz167);
};

function square169(){
    var sQAz168 = document.getElementById("imgSqr169").src;
    valueQaSave169 = 'zSqrArtSpecz168';
    localStorage.setItem(valueQaSave169, sQAz168);
};

function square170(){
    var sQAz169 = document.getElementById("imgSqr170").src;
    valueQaSave170 = 'zSqrArtSpecz169';
    localStorage.setItem(valueQaSave170, sQAz169);
};

function square171(){
    var sQAz170 = document.getElementById("imgSqr171").src;
    valueQaSave171 = 'zSqrArtSpecz170';
    localStorage.setItem(valueQaSave171, sQAz170);
};

function square172(){
    var sQAz171 = document.getElementById("imgSqr172").src;
    valueQaSave172 = 'zSqrArtSpecz171';
    localStorage.setItem(valueQaSave172, sQAz171);
};

function square173(){
    var sQAz172 = document.getElementById("imgSqr173").src;
    valueQaSave173 = 'zSqrArtSpecz172';
    localStorage.setItem(valueQaSave173, sQAz172);
};

function square174(){
    var sQAz173 = document.getElementById("imgSqr174").src;
    valueQaSave174 = 'zSqrArtSpecz173';
    localStorage.setItem(valueQaSave174, sQAz173);
};

function square175(){
    var sQAz174 = document.getElementById("imgSqr175").src;
    valueQaSave175 = 'zSqrArtSpecz174';
    localStorage.setItem(valueQaSave175, sQAz174);
};

function square176(){
    var sQAz175 = document.getElementById("imgSqr176").src;
    valueQaSave176 = 'zSqrArtSpecz175';
    localStorage.setItem(valueQaSave176, sQAz175);
};

function square177(){
    var sQAz176 = document.getElementById("imgSqr177").src;
    valueQaSave177 = 'zSqrArtSpecz176';
    localStorage.setItem(valueQaSave177, sQAz176);
};

function square178(){
    var sQAz177 = document.getElementById("imgSqr178").src;
    valueQaSave178 = 'zSqrArtSpecz177';
    localStorage.setItem(valueQaSave178, sQAz177);
};

function square179(){
    var sQAz178 = document.getElementById("imgSqr179").src;
    valueQaSave179 = 'zSqrArtSpecz178';
    localStorage.setItem(valueQaSave179, sQAz178);
};

function square180(){
    var sQAz179 = document.getElementById("imgSqr180").src;
    valueQaSave180 = 'zSqrArtSpecz179';
    localStorage.setItem(valueQaSave180, sQAz179);
};

function square181(){
    var sQAz180 = document.getElementById("imgSqr181").src;
    valueQaSave181 = 'zSqrArtSpecz180';
    localStorage.setItem(valueQaSave181, sQAz180);
};

function square182(){
    var sQAz181 = document.getElementById("imgSqr182").src;
    valueQaSave182 = 'zSqrArtSpecz181';
    localStorage.setItem(valueQaSave182, sQAz181);
};

function square183(){
    var sQAz182 = document.getElementById("imgSqr183").src;
    valueQaSave183 = 'zSqrArtSpecz182';
    localStorage.setItem(valueQaSave183, sQAz182);
};

function square184(){
    var sQAz183 = document.getElementById("imgSqr184").src;
    valueQaSave184 = 'zSqrArtSpecz183';
    localStorage.setItem(valueQaSave184, sQAz183);
};

function square185(){
    var sQAz184 = document.getElementById("imgSqr185").src;
    valueQaSave185 = 'zSqrArtSpecz184';
    localStorage.setItem(valueQaSave185, sQAz184);
};

function square186(){
    var sQAz185 = document.getElementById("imgSqr186").src;
    valueQaSave186 = 'zSqrArtSpecz185';
    localStorage.setItem(valueQaSave186, sQAz185);
};

function square187(){
    var sQAz186 = document.getElementById("imgSqr187").src;
    valueQaSave187 = 'zSqrArtSpecz186';
    localStorage.setItem(valueQaSave187, sQAz186);
};

function square188(){
    var sQAz187 = document.getElementById("imgSqr188").src;
    valueQaSave188 = 'zSqrArtSpecz187';
    localStorage.setItem(valueQaSave188, sQAz187);
};

function square189(){
    var sQAz188 = document.getElementById("imgSqr189").src;
    valueQaSave189 = 'zSqrArtSpecz188';
    localStorage.setItem(valueQaSave189, sQAz188);
};

function square190(){
    var sQAz189 = document.getElementById("imgSqr190").src;
    valueQaSave190 = 'zSqrArtSpecz189';
    localStorage.setItem(valueQaSave190, sQAz189);
};

function square191(){
    var sQAz190 = document.getElementById("imgSqr191").src;
    valueQaSave191 = 'zSqrArtSpecz190';
    localStorage.setItem(valueQaSave191, sQAz190);
};

function square192(){
    var sQAz191 = document.getElementById("imgSqr192").src;
    valueQaSave192 = 'zSqrArtSpecz191';
    localStorage.setItem(valueQaSave192, sQAz191);
};

function square193(){
    var sQAz192 = document.getElementById("imgSqr193").src;
    valueQaSave193 = 'zSqrArtSpecz192';
    localStorage.setItem(valueQaSave193, sQAz192);
};

function square194(){
    var sQAz193 = document.getElementById("imgSqr194").src;
    valueQaSave194 = 'zSqrArtSpecz193';
    localStorage.setItem(valueQaSave194, sQAz193);
};

function square195(){
    var sQAz194 = document.getElementById("imgSqr195").src;
    valueQaSave195 = 'zSqrArtSpecz194';
    localStorage.setItem(valueQaSave195, sQAz194);
};

function square196(){
    var sQAz195 = document.getElementById("imgSqr196").src;
    valueQaSave196 = 'zSqrArtSpecz195';
    localStorage.setItem(valueQaSave196, sQAz195);
};

function square197(){
    var sQAz196 = document.getElementById("imgSqr197").src;
    valueQaSave197 = 'zSqrArtSpecz196';
    localStorage.setItem(valueQaSave197, sQAz196);
};

function square198(){
    var sQAz197 = document.getElementById("imgSqr198").src;
    valueQaSave198 = 'zSqrArtSpecz197';
    localStorage.setItem(valueQaSave198, sQAz197);
};

function square199(){
    var sQAz198 = document.getElementById("imgSqr199").src;
    valueQaSave199 = 'zSqrArtSpecz198';
    localStorage.setItem(valueQaSave199, sQAz198);
};

function square200(){
    var sQAz199 = document.getElementById("imgSqr200").src;
    valueQaSave200 = 'zSqrArtSpecz199';
    localStorage.setItem(valueQaSave200, sQAz199);
};

function square201(){
    var sQAz200 = document.getElementById("imgSqr201").src;
    valueQaSave201 = 'zSqrArtSpecz200';
    localStorage.setItem(valueQaSave201, sQAz200);
};

function square202(){
    var sQAz201 = document.getElementById("imgSqr202").src;
    valueQaSave202 = 'zSqrArtSpecz201';
    localStorage.setItem(valueQaSave202, sQAz201);
};

function square203(){
    var sQAz202 = document.getElementById("imgSqr203").src;
    valueQaSave203 = 'zSqrArtSpecz202';
    localStorage.setItem(valueQaSave203, sQAz202);
};

function square204(){
    var sQAz203 = document.getElementById("imgSqr204").src;
    valueQaSave204 = 'zSqrArtSpecz203';
    localStorage.setItem(valueQaSave204, sQAz203);
};

function square205(){
    var sQAz204 = document.getElementById("imgSqr205").src;
    valueQaSave205 = 'zSqrArtSpecz204';
    localStorage.setItem(valueQaSave205, sQAz204);
};

function square206(){
    var sQAz205 = document.getElementById("imgSqr206").src;
    valueQaSave206 = 'zSqrArtSpecz205';
    localStorage.setItem(valueQaSave206, sQAz205);
};

function square207(){
    var sQAz206 = document.getElementById("imgSqr207").src;
    valueQaSave207 = 'zSqrArtSpecz206';
    localStorage.setItem(valueQaSave207, sQAz206);
};

function square208(){
    var sQAz207 = document.getElementById("imgSqr208").src;
    valueQaSave208 = 'zSqrArtSpecz207';
    localStorage.setItem(valueQaSave208, sQAz207);
};

function square209(){
    var sQAz208 = document.getElementById("imgSqr209").src;
    valueQaSave209 = 'zSqrArtSpecz208';
    localStorage.setItem(valueQaSave209, sQAz208);
};

function square210(){
    var sQAz209 = document.getElementById("imgSqr210").src;
    valueQaSave210 = 'zSqrArtSpecz209';
    localStorage.setItem(valueQaSave210, sQAz209);
};

function square211(){
    var sQAz210 = document.getElementById("imgSqr211").src;
    valueQaSave211 = 'zSqrArtSpecz210';
    localStorage.setItem(valueQaSave211, sQAz210);
};

function square212(){
    var sQAz211 = document.getElementById("imgSqr212").src;
    valueQaSave212 = 'zSqrArtSpecz211';
    localStorage.setItem(valueQaSave212, sQAz211);
};

function square213(){
    var sQAz212 = document.getElementById("imgSqr213").src;
    valueQaSave213 = 'zSqrArtSpecz212';
    localStorage.setItem(valueQaSave213, sQAz212);
};

function square214(){
    var sQAz213 = document.getElementById("imgSqr214").src;
    valueQaSave214 = 'zSqrArtSpecz213';
    localStorage.setItem(valueQaSave214, sQAz213);
};

function square215(){
    var sQAz214 = document.getElementById("imgSqr215").src;
    valueQaSave215 = 'zSqrArtSpecz214';
    localStorage.setItem(valueQaSave215, sQAz214);
};

function square216(){
    var sQAz215 = document.getElementById("imgSqr216").src;
    valueQaSave216 = 'zSqrArtSpecz215';
    localStorage.setItem(valueQaSave216, sQAz215);
};

function square217(){
    var sQAz216 = document.getElementById("imgSqr217").src;
    valueQaSave217 = 'zSqrArtSpecz216';
    localStorage.setItem(valueQaSave217, sQAz216);
};

function square218(){
    var sQAz217 = document.getElementById("imgSqr218").src;
    valueQaSave218 = 'zSqrArtSpecz217';
    localStorage.setItem(valueQaSave218, sQAz217);
};

function square219(){
    var sQAz218 = document.getElementById("imgSqr219").src;
    valueQaSave219 = 'zSqrArtSpecz218';
    localStorage.setItem(valueQaSave219, sQAz218);
};

function square220(){
    var sQAz219 = document.getElementById("imgSqr220").src;
    valueQaSave220 = 'zSqrArtSpecz219';
    localStorage.setItem(valueQaSave220, sQAz219);
};

function square221(){
    var sQAz220 = document.getElementById("imgSqr221").src;
    valueQaSave221 = 'zSqrArtSpecz220';
    localStorage.setItem(valueQaSave221, sQAz220);
};

function square222(){
    var sQAz221 = document.getElementById("imgSqr222").src;
    valueQaSave222 = 'zSqrArtSpecz221';
    localStorage.setItem(valueQaSave222, sQAz221);
};

function square223(){
    var sQAz222 = document.getElementById("imgSqr223").src;
    valueQaSave223 = 'zSqrArtSpecz222';
    localStorage.setItem(valueQaSave223, sQAz222);
};

function square224(){
    var sQAz223 = document.getElementById("imgSqr224").src;
    valueQaSave224 = 'zSqrArtSpecz223';
    localStorage.setItem(valueQaSave224, sQAz223);
};

function square225(){
    var sQAz224 = document.getElementById("imgSqr225").src;
    valueQaSave225 = 'zSqrArtSpecz224';
    localStorage.setItem(valueQaSave225, sQAz224);
};

function square226(){
    var sQAz225 = document.getElementById("imgSqr226").src;
    valueQaSave226 = 'zSqrArtSpecz225';
    localStorage.setItem(valueQaSave226, sQAz225);
};

function square227(){
    var sQAz226 = document.getElementById("imgSqr227").src;
    valueQaSave227 = 'zSqrArtSpecz226';
    localStorage.setItem(valueQaSave227, sQAz226);
};

function square228(){
    var sQAz227 = document.getElementById("imgSqr228").src;
    valueQaSave228 = 'zSqrArtSpecz227';
    localStorage.setItem(valueQaSave228, sQAz227);
};

function square229(){
    var sQAz228 = document.getElementById("imgSqr229").src;
    valueQaSave229 = 'zSqrArtSpecz228';
    localStorage.setItem(valueQaSave229, sQAz228);
};

function square230(){
    var sQAz229 = document.getElementById("imgSqr230").src;
    valueQaSave230 = 'zSqrArtSpecz229';
    localStorage.setItem(valueQaSave230, sQAz229);
};

function square231(){
    var sQAz230 = document.getElementById("imgSqr231").src;
    valueQaSave231 = 'zSqrArtSpecz230';
    localStorage.setItem(valueQaSave231, sQAz230);
};

function square232(){
    var sQAz231 = document.getElementById("imgSqr232").src;
    valueQaSave232 = 'zSqrArtSpecz231';
    localStorage.setItem(valueQaSave232, sQAz231);
};

function square233(){
    var sQAz232 = document.getElementById("imgSqr233").src;
    valueQaSave233 = 'zSqrArtSpecz232';
    localStorage.setItem(valueQaSave233, sQAz232);
};

function square234(){
    var sQAz233 = document.getElementById("imgSqr234").src;
    valueQaSave234 = 'zSqrArtSpecz233';
    localStorage.setItem(valueQaSave234, sQAz233);
};

function square235(){
    var sQAz234 = document.getElementById("imgSqr235").src;
    valueQaSave235 = 'zSqrArtSpecz234';
    localStorage.setItem(valueQaSave235, sQAz234);
};

function square236(){
    var sQAz235 = document.getElementById("imgSqr236").src;
    valueQaSave236 = 'zSqrArtSpecz235';
    localStorage.setItem(valueQaSave236, sQAz235);
};

function square237(){
    var sQAz236 = document.getElementById("imgSqr237").src;
    valueQaSave237 = 'zSqrArtSpecz236';
    localStorage.setItem(valueQaSave237, sQAz236);
};

function square238(){
    var sQAz237 = document.getElementById("imgSqr238").src;
    valueQaSave238 = 'zSqrArtSpecz237';
    localStorage.setItem(valueQaSave238, sQAz237);
};

function square239(){
    var sQAz238 = document.getElementById("imgSqr239").src;
    valueQaSave239 = 'zSqrArtSpecz238';
    localStorage.setItem(valueQaSave239, sQAz238);
};

function square240(){
    var sQAz239 = document.getElementById("imgSqr240").src;
    valueQaSave240 = 'zSqrArtSpecz239';
    localStorage.setItem(valueQaSave240, sQAz239);
};

function square241(){
    var sQAz240 = document.getElementById("imgSqr241").src;
    valueQaSave241 = 'zSqrArtSpecz240';
    localStorage.setItem(valueQaSave241, sQAz240);
};

function square242(){
    var sQAz241 = document.getElementById("imgSqr242").src;
    valueQaSave242 = 'zSqrArtSpecz241';
    localStorage.setItem(valueQaSave242, sQAz241);
};

function square243(){
    var sQAz242 = document.getElementById("imgSqr243").src;
    valueQaSave243 = 'zSqrArtSpecz242';
    localStorage.setItem(valueQaSave243, sQAz242);
};

function square244(){
    var sQAz243 = document.getElementById("imgSqr244").src;
    valueQaSave244 = 'zSqrArtSpecz243';
    localStorage.setItem(valueQaSave244, sQAz243);
};

function square245(){
    var sQAz244 = document.getElementById("imgSqr245").src;
    valueQaSave245 = 'zSqrArtSpecz244';
    localStorage.setItem(valueQaSave245, sQAz244);
};

function square246(){
    var sQAz245 = document.getElementById("imgSqr246").src;
    valueQaSave246 = 'zSqrArtSpecz245';
    localStorage.setItem(valueQaSave246, sQAz245);
};

function square247(){
    var sQAz246 = document.getElementById("imgSqr247").src;
    valueQaSave247 = 'zSqrArtSpecz246';
    localStorage.setItem(valueQaSave247, sQAz246);
};

function square248(){
    var sQAz247 = document.getElementById("imgSqr248").src;
    valueQaSave248 = 'zSqrArtSpecz247';
    localStorage.setItem(valueQaSave248, sQAz247);
};

function square249(){
    var sQAz248 = document.getElementById("imgSqr249").src;
    valueQaSave249 = 'zSqrArtSpecz248';
    localStorage.setItem(valueQaSave249, sQAz248);
};

function square250(){
    var sQAz249 = document.getElementById("imgSqr250").src;
    valueQaSave250 = 'zSqrArtSpecz249';
    localStorage.setItem(valueQaSave250, sQAz249);
};

function square251(){
    var sQAz250 = document.getElementById("imgSqr251").src;
    valueQaSave251 = 'zSqrArtSpecz250';
    localStorage.setItem(valueQaSave251, sQAz250);
};

function square252(){
    var sQAz251 = document.getElementById("imgSqr252").src;
    valueQaSave252 = 'zSqrArtSpecz251';
    localStorage.setItem(valueQaSave252, sQAz251);
};

function square253(){
    var sQAz252 = document.getElementById("imgSqr253").src;
    valueQaSave253 = 'zSqrArtSpecz252';
    localStorage.setItem(valueQaSave253, sQAz252);
};

function square254(){
    var sQAz253 = document.getElementById("imgSqr254").src;
    valueQaSave254 = 'zSqrArtSpecz253';
    localStorage.setItem(valueQaSave254, sQAz253);
};

function square255(){
    var sQAz254 = document.getElementById("imgSqr255").src;
    valueQaSave255 = 'zSqrArtSpecz254';
    localStorage.setItem(valueQaSave255, sQAz254);
};

function square256(){
    var sQAz255 = document.getElementById("imgSqr256").src;
    valueQaSave256 = 'zSqrArtSpecz255';
    localStorage.setItem(valueQaSave256, sQAz255);
};

function square257(){
    var sQAz256 = document.getElementById("imgSqr257").src;
    valueQaSave257 = 'zSqrArtSpecz256';
    localStorage.setItem(valueQaSave257, sQAz256);
};

function square258(){
    var sQAz257 = document.getElementById("imgSqr258").src;
    valueQaSave258 = 'zSqrArtSpecz257';
    localStorage.setItem(valueQaSave258, sQAz257);
};

function square259(){
    var sQAz258 = document.getElementById("imgSqr259").src;
    valueQaSave259 = 'zSqrArtSpecz258';
    localStorage.setItem(valueQaSave259, sQAz258);
};

function square260(){
    var sQAz259 = document.getElementById("imgSqr260").src;
    valueQaSave260 = 'zSqrArtSpecz259';
    localStorage.setItem(valueQaSave260, sQAz259);
};

function square261(){
    var sQAz260 = document.getElementById("imgSqr261").src;
    valueQaSave261 = 'zSqrArtSpecz260';
    localStorage.setItem(valueQaSave261, sQAz260);
};

function square262(){
    var sQAz261 = document.getElementById("imgSqr262").src;
    valueQaSave262 = 'zSqrArtSpecz261';
    localStorage.setItem(valueQaSave262, sQAz261);
};

function square263(){
    var sQAz262 = document.getElementById("imgSqr263").src;
    valueQaSave263 = 'zSqrArtSpecz262';
    localStorage.setItem(valueQaSave263, sQAz262);
};

function square264(){
    var sQAz263 = document.getElementById("imgSqr264").src;
    valueQaSave264 = 'zSqrArtSpecz263';
    localStorage.setItem(valueQaSave264, sQAz263);
};

function square265(){
    var sQAz264 = document.getElementById("imgSqr265").src;
    valueQaSave265 = 'zSqrArtSpecz264';
    localStorage.setItem(valueQaSave265, sQAz264);
};

function square266(){
    var sQAz265 = document.getElementById("imgSqr266").src;
    valueQaSave266 = 'zSqrArtSpecz265';
    localStorage.setItem(valueQaSave266, sQAz265);
};

function square267(){
    var sQAz266 = document.getElementById("imgSqr267").src;
    valueQaSave267 = 'zSqrArtSpecz266';
    localStorage.setItem(valueQaSave267, sQAz266);
};

function square268(){
    var sQAz267 = document.getElementById("imgSqr268").src;
    valueQaSave268 = 'zSqrArtSpecz267';
    localStorage.setItem(valueQaSave268, sQAz267);
};

function square269(){
    var sQAz268 = document.getElementById("imgSqr269").src;
    valueQaSave269 = 'zSqrArtSpecz268';
    localStorage.setItem(valueQaSave269, sQAz268);
};

function square270(){
    var sQAz269 = document.getElementById("imgSqr270").src;
    valueQaSave270 = 'zSqrArtSpecz269';
    localStorage.setItem(valueQaSave270, sQAz269);
};

function square271(){
    var sQAz270 = document.getElementById("imgSqr271").src;
    valueQaSave271 = 'zSqrArtSpecz270';
    localStorage.setItem(valueQaSave271, sQAz270);
};

function square272(){
    var sQAz271 = document.getElementById("imgSqr272").src;
    valueQaSave272 = 'zSqrArtSpecz271';
    localStorage.setItem(valueQaSave272, sQAz271);
};

function square273(){
    var sQAz272 = document.getElementById("imgSqr273").src;
    valueQaSave273 = 'zSqrArtSpecz272';
    localStorage.setItem(valueQaSave273, sQAz272);
};

function square274(){
    var sQAz273 = document.getElementById("imgSqr274").src;
    valueQaSave274 = 'zSqrArtSpecz273';
    localStorage.setItem(valueQaSave274, sQAz273);
};

function square275(){
    var sQAz274 = document.getElementById("imgSqr275").src;
    valueQaSave275 = 'zSqrArtSpecz274';
    localStorage.setItem(valueQaSave275, sQAz274);
};

function square276(){
    var sQAz275 = document.getElementById("imgSqr276").src;
    valueQaSave276 = 'zSqrArtSpecz275';
    localStorage.setItem(valueQaSave276, sQAz275);
};

function square277(){
    var sQAz276 = document.getElementById("imgSqr277").src;
    valueQaSave277 = 'zSqrArtSpecz276';
    localStorage.setItem(valueQaSave277, sQAz276);
};

function square278(){
    var sQAz277 = document.getElementById("imgSqr278").src;
    valueQaSave278 = 'zSqrArtSpecz277';
    localStorage.setItem(valueQaSave278, sQAz277);
};

function square279(){
    var sQAz278 = document.getElementById("imgSqr279").src;
    valueQaSave279 = 'zSqrArtSpecz278';
    localStorage.setItem(valueQaSave279, sQAz278);
};

function square280(){
    var sQAz279 = document.getElementById("imgSqr280").src;
    valueQaSave280 = 'zSqrArtSpecz279';
    localStorage.setItem(valueQaSave280, sQAz279);
};

function square281(){
    var sQAz280 = document.getElementById("imgSqr281").src;
    valueQaSave281 = 'zSqrArtSpecz280';
    localStorage.setItem(valueQaSave281, sQAz280);
};

function square282(){
    var sQAz281 = document.getElementById("imgSqr282").src;
    valueQaSave282 = 'zSqrArtSpecz281';
    localStorage.setItem(valueQaSave282, sQAz281);
};

function square283(){
    var sQAz282 = document.getElementById("imgSqr283").src;
    valueQaSave283 = 'zSqrArtSpecz282';
    localStorage.setItem(valueQaSave283, sQAz282);
};

function square284(){
    var sQAz283 = document.getElementById("imgSqr284").src;
    valueQaSave284 = 'zSqrArtSpecz283';
    localStorage.setItem(valueQaSave284, sQAz283);
};

function square285(){
    var sQAz284 = document.getElementById("imgSqr285").src;
    valueQaSave285 = 'zSqrArtSpecz284';
    localStorage.setItem(valueQaSave285, sQAz284);
};

function square286(){
    var sQAz285 = document.getElementById("imgSqr286").src;
    valueQaSave286 = 'zSqrArtSpecz285';
    localStorage.setItem(valueQaSave286, sQAz285);
};

function square287(){
    var sQAz286 = document.getElementById("imgSqr287").src;
    valueQaSave287 = 'zSqrArtSpecz286';
    localStorage.setItem(valueQaSave287, sQAz286);
};

function square288(){
    var sQAz287 = document.getElementById("imgSqr288").src;
    valueQaSave288 = 'zSqrArtSpecz287';
    localStorage.setItem(valueQaSave288, sQAz287);
};

function square289(){
    var sQAz288 = document.getElementById("imgSqr289").src;
    valueQaSave289 = 'zSqrArtSpecz288';
    localStorage.setItem(valueQaSave289, sQAz288);
};

function square290(){
    var sQAz289 = document.getElementById("imgSqr290").src;
    valueQaSave290 = 'zSqrArtSpecz289';
    localStorage.setItem(valueQaSave290, sQAz289);
};

function square291(){
    var sQAz290 = document.getElementById("imgSqr291").src;
    valueQaSave291 = 'zSqrArtSpecz290';
    localStorage.setItem(valueQaSave291, sQAz290);
};

function square292(){
    var sQAz291 = document.getElementById("imgSqr292").src;
    valueQaSave292 = 'zSqrArtSpecz291';
    localStorage.setItem(valueQaSave292, sQAz291);
};

function square293(){
    var sQAz292 = document.getElementById("imgSqr293").src;
    valueQaSave293 = 'zSqrArtSpecz292';
    localStorage.setItem(valueQaSave293, sQAz292);
};

function square294(){
    var sQAz293 = document.getElementById("imgSqr294").src;
    valueQaSave294 = 'zSqrArtSpecz293';
    localStorage.setItem(valueQaSave294, sQAz293);
};

function square295(){
    var sQAz294 = document.getElementById("imgSqr295").src;
    valueQaSave295 = 'zSqrArtSpecz294';
    localStorage.setItem(valueQaSave295, sQAz294);
};

function square296(){
    var sQAz295 = document.getElementById("imgSqr296").src;
    valueQaSave296 = 'zSqrArtSpecz295';
    localStorage.setItem(valueQaSave296, sQAz295);
};

function square297(){
    var sQAz296 = document.getElementById("imgSqr297").src;
    valueQaSave297 = 'zSqrArtSpecz296';
    localStorage.setItem(valueQaSave297, sQAz296);
};

function square298(){
    var sQAz297 = document.getElementById("imgSqr298").src;
    valueQaSave298 = 'zSqrArtSpecz297';
    localStorage.setItem(valueQaSave298, sQAz297);
};

function square299(){
    var sQAz298 = document.getElementById("imgSqr299").src;
    valueQaSave299 = 'zSqrArtSpecz298';
    localStorage.setItem(valueQaSave299, sQAz298);
};

function square300(){
    var sQAz299 = document.getElementById("imgSqr300").src;
    valueQaSave300 = 'zSqrArtSpecz299';
    localStorage.setItem(valueQaSave300, sQAz299);
};

function square301(){
    var sQAz300 = document.getElementById("imgSqr301").src;
    valueQaSave301 = 'zSqrArtSpecz300';
    localStorage.setItem(valueQaSave301, sQAz300);
};

function square302(){
    var sQAz301 = document.getElementById("imgSqr302").src;
    valueQaSave302 = 'zSqrArtSpecz301';
    localStorage.setItem(valueQaSave302, sQAz301);
};

function square303(){
    var sQAz302 = document.getElementById("imgSqr303").src;
    valueQaSave303 = 'zSqrArtSpecz302';
    localStorage.setItem(valueQaSave303, sQAz302);
};

function square304(){
    var sQAz303 = document.getElementById("imgSqr304").src;
    valueQaSave304 = 'zSqrArtSpecz303';
    localStorage.setItem(valueQaSave304, sQAz303);
};

function square305(){
    var sQAz304 = document.getElementById("imgSqr305").src;
    valueQaSave305 = 'zSqrArtSpecz304';
    localStorage.setItem(valueQaSave305, sQAz304);
};

function square306(){
    var sQAz305 = document.getElementById("imgSqr306").src;
    valueQaSave306 = 'zSqrArtSpecz305';
    localStorage.setItem(valueQaSave306, sQAz305);
};

function square307(){
    var sQAz306 = document.getElementById("imgSqr307").src;
    valueQaSave307 = 'zSqrArtSpecz306';
    localStorage.setItem(valueQaSave307, sQAz306);
};

function square308(){
    var sQAz307 = document.getElementById("imgSqr308").src;
    valueQaSave308 = 'zSqrArtSpecz307';
    localStorage.setItem(valueQaSave308, sQAz307);
};

function square309(){
    var sQAz308 = document.getElementById("imgSqr309").src;
    valueQaSave309 = 'zSqrArtSpecz308';
    localStorage.setItem(valueQaSave309, sQAz308);
};

function square310(){
    var sQAz309 = document.getElementById("imgSqr310").src;
    valueQaSave310 = 'zSqrArtSpecz309';
    localStorage.setItem(valueQaSave310, sQAz309);
};

function square311(){
    var sQAz310 = document.getElementById("imgSqr311").src;
    valueQaSave311 = 'zSqrArtSpecz310';
    localStorage.setItem(valueQaSave311, sQAz310);
};

function square312(){
    var sQAz311 = document.getElementById("imgSqr312").src;
    valueQaSave312 = 'zSqrArtSpecz311';
    localStorage.setItem(valueQaSave312, sQAz311);
};

function square313(){
    var sQAz312 = document.getElementById("imgSqr313").src;
    valueQaSave313 = 'zSqrArtSpecz312';
    localStorage.setItem(valueQaSave313, sQAz312);
};

function square314(){
    var sQAz313 = document.getElementById("imgSqr314").src;
    valueQaSave314 = 'zSqrArtSpecz313';
    localStorage.setItem(valueQaSave314, sQAz313);
};

function square315(){
    var sQAz314 = document.getElementById("imgSqr315").src;
    valueQaSave315 = 'zSqrArtSpecz314';
    localStorage.setItem(valueQaSave315, sQAz314);
};

function square316(){
    var sQAz315 = document.getElementById("imgSqr316").src;
    valueQaSave316 = 'zSqrArtSpecz315';
    localStorage.setItem(valueQaSave316, sQAz315);
};

function square317(){
    var sQAz316 = document.getElementById("imgSqr317").src;
    valueQaSave317 = 'zSqrArtSpecz316';
    localStorage.setItem(valueQaSave317, sQAz316);
};

function square318(){
    var sQAz317 = document.getElementById("imgSqr318").src;
    valueQaSave318 = 'zSqrArtSpecz317';
    localStorage.setItem(valueQaSave318, sQAz317);
};

function square319(){
    var sQAz318 = document.getElementById("imgSqr319").src;
    valueQaSave319 = 'zSqrArtSpecz318';
    localStorage.setItem(valueQaSave319, sQAz318);
};

function square320(){
    var sQAz319 = document.getElementById("imgSqr320").src;
    valueQaSave320 = 'zSqrArtSpecz319';
    localStorage.setItem(valueQaSave320, sQAz319);
};

function square321(){
    var sQAz320 = document.getElementById("imgSqr321").src;
    valueQaSave321 = 'zSqrArtSpecz320';
    localStorage.setItem(valueQaSave321, sQAz320);
};

function square322(){
    var sQAz321 = document.getElementById("imgSqr322").src;
    valueQaSave322 = 'zSqrArtSpecz321';
    localStorage.setItem(valueQaSave322, sQAz321);
};

function square323(){
    var sQAz322 = document.getElementById("imgSqr323").src;
    valueQaSave323 = 'zSqrArtSpecz322';
    localStorage.setItem(valueQaSave323, sQAz322);
};

function square324(){
    var sQAz323 = document.getElementById("imgSqr324").src;
    valueQaSave324 = 'zSqrArtSpecz323';
    localStorage.setItem(valueQaSave324, sQAz323);
};

function square325(){
    var sQAz324 = document.getElementById("imgSqr325").src;
    valueQaSave325 = 'zSqrArtSpecz324';
    localStorage.setItem(valueQaSave325, sQAz324);
};

function square326(){
    var sQAz325 = document.getElementById("imgSqr326").src;
    valueQaSave326 = 'zSqrArtSpecz325';
    localStorage.setItem(valueQaSave326, sQAz325);
};

function square327(){
    var sQAz326 = document.getElementById("imgSqr327").src;
    valueQaSave327 = 'zSqrArtSpecz326';
    localStorage.setItem(valueQaSave327, sQAz326);
};

function square328(){
    var sQAz327 = document.getElementById("imgSqr328").src;
    valueQaSave328 = 'zSqrArtSpecz327';
    localStorage.setItem(valueQaSave328, sQAz327);
};

function square329(){
    var sQAz328 = document.getElementById("imgSqr329").src;
    valueQaSave329 = 'zSqrArtSpecz328';
    localStorage.setItem(valueQaSave329, sQAz328);
};

function square330(){
    var sQAz329 = document.getElementById("imgSqr330").src;
    valueQaSave330 = 'zSqrArtSpecz329';
    localStorage.setItem(valueQaSave330, sQAz329);
};

function square331(){
    var sQAz330 = document.getElementById("imgSqr331").src;
    valueQaSave331 = 'zSqrArtSpecz330';
    localStorage.setItem(valueQaSave331, sQAz330);
};

function square332(){
    var sQAz331 = document.getElementById("imgSqr332").src;
    valueQaSave332 = 'zSqrArtSpecz331';
    localStorage.setItem(valueQaSave332, sQAz331);
};

function square333(){
    var sQAz332 = document.getElementById("imgSqr333").src;
    valueQaSave333 = 'zSqrArtSpecz332';
    localStorage.setItem(valueQaSave333, sQAz332);
};

function square334(){
    var sQAz333 = document.getElementById("imgSqr334").src;
    valueQaSave334 = 'zSqrArtSpecz333';
    localStorage.setItem(valueQaSave334, sQAz333);
};

function square335(){
    var sQAz334 = document.getElementById("imgSqr335").src;
    valueQaSave335 = 'zSqrArtSpecz334';
    localStorage.setItem(valueQaSave335, sQAz334);
};

function square336(){
    var sQAz335 = document.getElementById("imgSqr336").src;
    valueQaSave336 = 'zSqrArtSpecz335';
    localStorage.setItem(valueQaSave336, sQAz335);
};

function square337(){
    var sQAz336 = document.getElementById("imgSqr337").src;
    valueQaSave337 = 'zSqrArtSpecz336';
    localStorage.setItem(valueQaSave337, sQAz336);
};

function square338(){
    var sQAz337 = document.getElementById("imgSqr338").src;
    valueQaSave338 = 'zSqrArtSpecz337';
    localStorage.setItem(valueQaSave338, sQAz337);
};

function square339(){
    var sQAz338 = document.getElementById("imgSqr339").src;
    valueQaSave339 = 'zSqrArtSpecz338';
    localStorage.setItem(valueQaSave339, sQAz338);
};

function square340(){
    var sQAz339 = document.getElementById("imgSqr340").src;
    valueQaSave340 = 'zSqrArtSpecz339';
    localStorage.setItem(valueQaSave340, sQAz339);
};

function square341(){
    var sQAz340 = document.getElementById("imgSqr341").src;
    valueQaSave341 = 'zSqrArtSpecz340';
    localStorage.setItem(valueQaSave341, sQAz340);
};

function square342(){
    var sQAz341 = document.getElementById("imgSqr342").src;
    valueQaSave342 = 'zSqrArtSpecz341';
    localStorage.setItem(valueQaSave342, sQAz341);
};

function square343(){
    var sQAz342 = document.getElementById("imgSqr343").src;
    valueQaSave343 = 'zSqrArtSpecz342';
    localStorage.setItem(valueQaSave343, sQAz342);
};

function square344(){
    var sQAz343 = document.getElementById("imgSqr344").src;
    valueQaSave344 = 'zSqrArtSpecz343';
    localStorage.setItem(valueQaSave344, sQAz343);
};

function square345(){
    var sQAz344 = document.getElementById("imgSqr345").src;
    valueQaSave345 = 'zSqrArtSpecz344';
    localStorage.setItem(valueQaSave345, sQAz344);
};

function square346(){
    var sQAz345 = document.getElementById("imgSqr346").src;
    valueQaSave346 = 'zSqrArtSpecz345';
    localStorage.setItem(valueQaSave346, sQAz345);
};

function square347(){
    var sQAz346 = document.getElementById("imgSqr347").src;
    valueQaSave347 = 'zSqrArtSpecz346';
    localStorage.setItem(valueQaSave347, sQAz346);
};

function square348(){
    var sQAz347 = document.getElementById("imgSqr348").src;
    valueQaSave348 = 'zSqrArtSpecz347';
    localStorage.setItem(valueQaSave348, sQAz347);
};

function square349(){
    var sQAz348 = document.getElementById("imgSqr349").src;
    valueQaSave349 = 'zSqrArtSpecz348';
    localStorage.setItem(valueQaSave349, sQAz348);
};

function square350(){
    var sQAz349 = document.getElementById("imgSqr350").src;
    valueQaSave350 = 'zSqrArtSpecz349';
    localStorage.setItem(valueQaSave350, sQAz349);
};

function square351(){
    var sQAz350 = document.getElementById("imgSqr351").src;
    valueQaSave351 = 'zSqrArtSpecz350';
    localStorage.setItem(valueQaSave351, sQAz350);
};

function square352(){
    var sQAz351 = document.getElementById("imgSqr352").src;
    valueQaSave352 = 'zSqrArtSpecz351';
    localStorage.setItem(valueQaSave352, sQAz351);
};

function square353(){
    var sQAz352 = document.getElementById("imgSqr353").src;
    valueQaSave353 = 'zSqrArtSpecz352';
    localStorage.setItem(valueQaSave353, sQAz352);
};

function square354(){
    var sQAz353 = document.getElementById("imgSqr354").src;
    valueQaSave354 = 'zSqrArtSpecz353';
    localStorage.setItem(valueQaSave354, sQAz353);
};

function square355(){
    var sQAz354 = document.getElementById("imgSqr355").src;
    valueQaSave355 = 'zSqrArtSpecz354';
    localStorage.setItem(valueQaSave355, sQAz354);
};

function square356(){
    var sQAz355 = document.getElementById("imgSqr356").src;
    valueQaSave356 = 'zSqrArtSpecz355';
    localStorage.setItem(valueQaSave356, sQAz355);
};

function square357(){
    var sQAz356 = document.getElementById("imgSqr357").src;
    valueQaSave357 = 'zSqrArtSpecz356';
    localStorage.setItem(valueQaSave357, sQAz356);
};

function square358(){
    var sQAz357 = document.getElementById("imgSqr358").src;
    valueQaSave358 = 'zSqrArtSpecz357';
    localStorage.setItem(valueQaSave358, sQAz357);
};

function square359(){
    var sQAz358 = document.getElementById("imgSqr359").src;
    valueQaSave359 = 'zSqrArtSpecz358';
    localStorage.setItem(valueQaSave359, sQAz358);
};

function square360(){
    var sQAz359 = document.getElementById("imgSqr360").src;
    valueQaSave360 = 'zSqrArtSpecz359';
    localStorage.setItem(valueQaSave360, sQAz359);
};

function square361(){
    var sQAz360 = document.getElementById("imgSqr361").src;
    valueQaSave361 = 'zSqrArtSpecz360';
    localStorage.setItem(valueQaSave361, sQAz360);
};

function square362(){
    var sQAz361 = document.getElementById("imgSqr362").src;
    valueQaSave362 = 'zSqrArtSpecz361';
    localStorage.setItem(valueQaSave362, sQAz361);
};

function square363(){
    var sQAz362 = document.getElementById("imgSqr363").src;
    valueQaSave363 = 'zSqrArtSpecz362';
    localStorage.setItem(valueQaSave363, sQAz362);
};

function square364(){
    var sQAz363 = document.getElementById("imgSqr364").src;
    valueQaSave364 = 'zSqrArtSpecz363';
    localStorage.setItem(valueQaSave364, sQAz363);
};

function square365(){
    var sQAz364 = document.getElementById("imgSqr365").src;
    valueQaSave365 = 'zSqrArtSpecz364';
    localStorage.setItem(valueQaSave365, sQAz364);
};

function square366(){
    var sQAz365 = document.getElementById("imgSqr366").src;
    valueQaSave366 = 'zSqrArtSpecz365';
    localStorage.setItem(valueQaSave366, sQAz365);
};

function square367(){
    var sQAz366 = document.getElementById("imgSqr367").src;
    valueQaSave367 = 'zSqrArtSpecz366';
    localStorage.setItem(valueQaSave367, sQAz366);
};

function square368(){
    var sQAz367 = document.getElementById("imgSqr368").src;
    valueQaSave368 = 'zSqrArtSpecz367';
    localStorage.setItem(valueQaSave368, sQAz367);
};

function square369(){
    var sQAz368 = document.getElementById("imgSqr369").src;
    valueQaSave369 = 'zSqrArtSpecz368';
    localStorage.setItem(valueQaSave369, sQAz368);
};

function square370(){
    var sQAz369 = document.getElementById("imgSqr370").src;
    valueQaSave370 = 'zSqrArtSpecz369';
    localStorage.setItem(valueQaSave370, sQAz369);
};

function square371(){
    var sQAz370 = document.getElementById("imgSqr371").src;
    valueQaSave371 = 'zSqrArtSpecz370';
    localStorage.setItem(valueQaSave371, sQAz370);
};

function square372(){
    var sQAz371 = document.getElementById("imgSqr372").src;
    valueQaSave372 = 'zSqrArtSpecz371';
    localStorage.setItem(valueQaSave372, sQAz371);
};

function square373(){
    var sQAz372 = document.getElementById("imgSqr373").src;
    valueQaSave373 = 'zSqrArtSpecz372';
    localStorage.setItem(valueQaSave373, sQAz372);
};

function square374(){
    var sQAz373 = document.getElementById("imgSqr374").src;
    valueQaSave374 = 'zSqrArtSpecz373';
    localStorage.setItem(valueQaSave374, sQAz373);
};

function square375(){
    var sQAz374 = document.getElementById("imgSqr375").src;
    valueQaSave375 = 'zSqrArtSpecz374';
    localStorage.setItem(valueQaSave375, sQAz374);
};

function square376(){
    var sQAz375 = document.getElementById("imgSqr376").src;
    valueQaSave376 = 'zSqrArtSpecz375';
    localStorage.setItem(valueQaSave376, sQAz375);
};

function square377(){
    var sQAz376 = document.getElementById("imgSqr377").src;
    valueQaSave377 = 'zSqrArtSpecz376';
    localStorage.setItem(valueQaSave377, sQAz376);
};

function square378(){
    var sQAz377 = document.getElementById("imgSqr378").src;
    valueQaSave378 = 'zSqrArtSpecz377';
    localStorage.setItem(valueQaSave378, sQAz377);
};

function square379(){
    var sQAz378 = document.getElementById("imgSqr379").src;
    valueQaSave379 = 'zSqrArtSpecz378';
    localStorage.setItem(valueQaSave379, sQAz378);
};

function square380(){
    var sQAz379 = document.getElementById("imgSqr380").src;
    valueQaSave380 = 'zSqrArtSpecz379';
    localStorage.setItem(valueQaSave380, sQAz379);
};

function square381(){
    var sQAz380 = document.getElementById("imgSqr381").src;
    valueQaSave381 = 'zSqrArtSpecz380';
    localStorage.setItem(valueQaSave381, sQAz380);
};

function square382(){
    var sQAz381 = document.getElementById("imgSqr382").src;
    valueQaSave382 = 'zSqrArtSpecz381';
    localStorage.setItem(valueQaSave382, sQAz381);
};

function square383(){
    var sQAz382 = document.getElementById("imgSqr383").src;
    valueQaSave383 = 'zSqrArtSpecz382';
    localStorage.setItem(valueQaSave383, sQAz382);
};

function square384(){
    var sQAz383 = document.getElementById("imgSqr384").src;
    valueQaSave384 = 'zSqrArtSpecz383';
    localStorage.setItem(valueQaSave384, sQAz383);
};

function square385(){
    var sQAz384 = document.getElementById("imgSqr385").src;
    valueQaSave385 = 'zSqrArtSpecz384';
    localStorage.setItem(valueQaSave385, sQAz384);
};

function square386(){
    var sQAz385 = document.getElementById("imgSqr386").src;
    valueQaSave386 = 'zSqrArtSpecz385';
    localStorage.setItem(valueQaSave386, sQAz385);
};

function square387(){
    var sQAz386 = document.getElementById("imgSqr387").src;
    valueQaSave387 = 'zSqrArtSpecz386';
    localStorage.setItem(valueQaSave387, sQAz386);
};

function square388(){
    var sQAz387 = document.getElementById("imgSqr388").src;
    valueQaSave388 = 'zSqrArtSpecz387';
    localStorage.setItem(valueQaSave388, sQAz387);
};

function square389(){
    var sQAz388 = document.getElementById("imgSqr389").src;
    valueQaSave389 = 'zSqrArtSpecz388';
    localStorage.setItem(valueQaSave389, sQAz388);
};

function square390(){
    var sQAz389 = document.getElementById("imgSqr390").src;
    valueQaSave390 = 'zSqrArtSpecz389';
    localStorage.setItem(valueQaSave390, sQAz389);
};

function square391(){
    var sQAz390 = document.getElementById("imgSqr391").src;
    valueQaSave391 = 'zSqrArtSpecz390';
    localStorage.setItem(valueQaSave391, sQAz390);
};

function square392(){
    var sQAz391 = document.getElementById("imgSqr392").src;
    valueQaSave392 = 'zSqrArtSpecz391';
    localStorage.setItem(valueQaSave392, sQAz391);
};

function square393(){
    var sQAz392 = document.getElementById("imgSqr393").src;
    valueQaSave393 = 'zSqrArtSpecz392';
    localStorage.setItem(valueQaSave393, sQAz392);
};

function square394(){
    var sQAz393 = document.getElementById("imgSqr394").src;
    valueQaSave394 = 'zSqrArtSpecz393';
    localStorage.setItem(valueQaSave394, sQAz393);
};

function square395(){
    var sQAz394 = document.getElementById("imgSqr395").src;
    valueQaSave395 = 'zSqrArtSpecz394';
    localStorage.setItem(valueQaSave395, sQAz394);
};

function square396(){
    var sQAz395 = document.getElementById("imgSqr396").src;
    valueQaSave396 = 'zSqrArtSpecz395';
    localStorage.setItem(valueQaSave396, sQAz395);
};

function square397(){
    var sQAz396 = document.getElementById("imgSqr397").src;
    valueQaSave397 = 'zSqrArtSpecz396';
    localStorage.setItem(valueQaSave397, sQAz396);
};

function square398(){
    var sQAz397 = document.getElementById("imgSqr398").src;
    valueQaSave398 = 'zSqrArtSpecz397';
    localStorage.setItem(valueQaSave398, sQAz397);
};

function square399(){
    var sQAz398 = document.getElementById("imgSqr399").src;
    valueQaSave399 = 'zSqrArtSpecz398';
    localStorage.setItem(valueQaSave399, sQAz398);
};

function square400(){
    var sQAz399 = document.getElementById("imgSqr400").src;
    valueQaSave400 = 'zSqrArtSpecz399';
    localStorage.setItem(valueQaSave400, sQAz399);
};

function square401(){
    var sQAz400 = document.getElementById("imgSqr401").src;
    valueQaSave401 = 'zSqrArtSpecz400';
    localStorage.setItem(valueQaSave401, sQAz400);
};

function square402(){
    var sQAz401 = document.getElementById("imgSqr402").src;
    valueQaSave402 = 'zSqrArtSpecz401';
    localStorage.setItem(valueQaSave402, sQAz401);
};

function square403(){
    var sQAz402 = document.getElementById("imgSqr403").src;
    valueQaSave403 = 'zSqrArtSpecz402';
    localStorage.setItem(valueQaSave403, sQAz402);
};

function square404(){
    var sQAz403 = document.getElementById("imgSqr404").src;
    valueQaSave404 = 'zSqrArtSpecz403';
    localStorage.setItem(valueQaSave404, sQAz403);
};

function square405(){
    var sQAz404 = document.getElementById("imgSqr405").src;
    valueQaSave405 = 'zSqrArtSpecz404';
    localStorage.setItem(valueQaSave405, sQAz404);
};

function square406(){
    var sQAz405 = document.getElementById("imgSqr406").src;
    valueQaSave406 = 'zSqrArtSpecz405';
    localStorage.setItem(valueQaSave406, sQAz405);
};

function square407(){
    var sQAz406 = document.getElementById("imgSqr407").src;
    valueQaSave407 = 'zSqrArtSpecz406';
    localStorage.setItem(valueQaSave407, sQAz406);
};

function square408(){
    var sQAz407 = document.getElementById("imgSqr408").src;
    valueQaSave408 = 'zSqrArtSpecz407';
    localStorage.setItem(valueQaSave408, sQAz407);
};

function square409(){
    var sQAz408 = document.getElementById("imgSqr409").src;
    valueQaSave409 = 'zSqrArtSpecz408';
    localStorage.setItem(valueQaSave409, sQAz408);
};

function square410(){
    var sQAz409 = document.getElementById("imgSqr410").src;
    valueQaSave410 = 'zSqrArtSpecz409';
    localStorage.setItem(valueQaSave410, sQAz409);
};

function square411(){
    var sQAz410 = document.getElementById("imgSqr411").src;
    valueQaSave411 = 'zSqrArtSpecz410';
    localStorage.setItem(valueQaSave411, sQAz410);
};

function square412(){
    var sQAz411 = document.getElementById("imgSqr412").src;
    valueQaSave412 = 'zSqrArtSpecz411';
    localStorage.setItem(valueQaSave412, sQAz411);
};

function square413(){
    var sQAz412 = document.getElementById("imgSqr413").src;
    valueQaSave413 = 'zSqrArtSpecz412';
    localStorage.setItem(valueQaSave413, sQAz412);
};

function square414(){
    var sQAz413 = document.getElementById("imgSqr414").src;
    valueQaSave414 = 'zSqrArtSpecz413';
    localStorage.setItem(valueQaSave414, sQAz413);
};

function square415(){
    var sQAz414 = document.getElementById("imgSqr415").src;
    valueQaSave415 = 'zSqrArtSpecz414';
    localStorage.setItem(valueQaSave415, sQAz414);
};

function square416(){
    var sQAz415 = document.getElementById("imgSqr416").src;
    valueQaSave416 = 'zSqrArtSpecz415';
    localStorage.setItem(valueQaSave416, sQAz415);
};

function square417(){
    var sQAz416 = document.getElementById("imgSqr417").src;
    valueQaSave417 = 'zSqrArtSpecz416';
    localStorage.setItem(valueQaSave417, sQAz416);
};

function square418(){
    var sQAz417 = document.getElementById("imgSqr418").src;
    valueQaSave418 = 'zSqrArtSpecz417';
    localStorage.setItem(valueQaSave418, sQAz417);
};

function square419(){
    var sQAz418 = document.getElementById("imgSqr419").src;
    valueQaSave419 = 'zSqrArtSpecz418';
    localStorage.setItem(valueQaSave419, sQAz418);
};

function square420(){
    var sQAz419 = document.getElementById("imgSqr420").src;
    valueQaSave420 = 'zSqrArtSpecz419';
    localStorage.setItem(valueQaSave420, sQAz419);
};

function square421(){
    var sQAz420 = document.getElementById("imgSqr421").src;
    valueQaSave421 = 'zSqrArtSpecz420';
    localStorage.setItem(valueQaSave421, sQAz420);
};

function square422(){
    var sQAz421 = document.getElementById("imgSqr422").src;
    valueQaSave422 = 'zSqrArtSpecz421';
    localStorage.setItem(valueQaSave422, sQAz421);
};

function square423(){
    var sQAz422 = document.getElementById("imgSqr423").src;
    valueQaSave423 = 'zSqrArtSpecz422';
    localStorage.setItem(valueQaSave423, sQAz422);
};

function square424(){
    var sQAz423 = document.getElementById("imgSqr424").src;
    valueQaSave424 = 'zSqrArtSpecz423';
    localStorage.setItem(valueQaSave424, sQAz423);
};

function square425(){
    var sQAz424 = document.getElementById("imgSqr425").src;
    valueQaSave425 = 'zSqrArtSpecz424';
    localStorage.setItem(valueQaSave425, sQAz424);
};

function square426(){
    var sQAz425 = document.getElementById("imgSqr426").src;
    valueQaSave426 = 'zSqrArtSpecz425';
    localStorage.setItem(valueQaSave426, sQAz425);
};

function square427(){
    var sQAz426 = document.getElementById("imgSqr427").src;
    valueQaSave427 = 'zSqrArtSpecz426';
    localStorage.setItem(valueQaSave427, sQAz426);
};

function square428(){
    var sQAz427 = document.getElementById("imgSqr428").src;
    valueQaSave428 = 'zSqrArtSpecz427';
    localStorage.setItem(valueQaSave428, sQAz427);
};

function square429(){
    var sQAz428 = document.getElementById("imgSqr429").src;
    valueQaSave429 = 'zSqrArtSpecz428';
    localStorage.setItem(valueQaSave429, sQAz428);
};

function square430(){
    var sQAz429 = document.getElementById("imgSqr430").src;
    valueQaSave430 = 'zSqrArtSpecz429';
    localStorage.setItem(valueQaSave430, sQAz429);
};

function square431(){
    var sQAz430 = document.getElementById("imgSqr431").src;
    valueQaSave431 = 'zSqrArtSpecz430';
    localStorage.setItem(valueQaSave431, sQAz430);
};

function square432(){
    var sQAz431 = document.getElementById("imgSqr432").src;
    valueQaSave432 = 'zSqrArtSpecz431';
    localStorage.setItem(valueQaSave432, sQAz431);
};

function square433(){
    var sQAz432 = document.getElementById("imgSqr433").src;
    valueQaSave433 = 'zSqrArtSpecz432';
    localStorage.setItem(valueQaSave433, sQAz432);
};

function square434(){
    var sQAz433 = document.getElementById("imgSqr434").src;
    valueQaSave434 = 'zSqrArtSpecz433';
    localStorage.setItem(valueQaSave434, sQAz433);
};

function square435(){
    var sQAz434 = document.getElementById("imgSqr435").src;
    valueQaSave435 = 'zSqrArtSpecz434';
    localStorage.setItem(valueQaSave435, sQAz434);
};

function square436(){
    var sQAz435 = document.getElementById("imgSqr436").src;
    valueQaSave436 = 'zSqrArtSpecz435';
    localStorage.setItem(valueQaSave436, sQAz435);
};

function square437(){
    var sQAz436 = document.getElementById("imgSqr437").src;
    valueQaSave437 = 'zSqrArtSpecz436';
    localStorage.setItem(valueQaSave437, sQAz436);
};

function square438(){
    var sQAz437 = document.getElementById("imgSqr438").src;
    valueQaSave438 = 'zSqrArtSpecz437';
    localStorage.setItem(valueQaSave438, sQAz437);
};

function square439(){
    var sQAz438 = document.getElementById("imgSqr439").src;
    valueQaSave439 = 'zSqrArtSpecz438';
    localStorage.setItem(valueQaSave439, sQAz438);
};

function square440(){
    var sQAz439 = document.getElementById("imgSqr440").src;
    valueQaSave440 = 'zSqrArtSpecz439';
    localStorage.setItem(valueQaSave440, sQAz439);
};

function square441(){
    var sQAz440 = document.getElementById("imgSqr441").src;
    valueQaSave441 = 'zSqrArtSpecz440';
    localStorage.setItem(valueQaSave441, sQAz440);
};

function square442(){
    var sQAz441 = document.getElementById("imgSqr442").src;
    valueQaSave442 = 'zSqrArtSpecz441';
    localStorage.setItem(valueQaSave442, sQAz441);
};

function square443(){
    var sQAz442 = document.getElementById("imgSqr443").src;
    valueQaSave443 = 'zSqrArtSpecz442';
    localStorage.setItem(valueQaSave443, sQAz442);
};

function square444(){
    var sQAz443 = document.getElementById("imgSqr444").src;
    valueQaSave444 = 'zSqrArtSpecz443';
    localStorage.setItem(valueQaSave444, sQAz443);
};

function square445(){
    var sQAz444 = document.getElementById("imgSqr445").src;
    valueQaSave445 = 'zSqrArtSpecz444';
    localStorage.setItem(valueQaSave445, sQAz444);
};

function square446(){
    var sQAz445 = document.getElementById("imgSqr446").src;
    valueQaSave446 = 'zSqrArtSpecz445';
    localStorage.setItem(valueQaSave446, sQAz445);
};

function square447(){
    var sQAz446 = document.getElementById("imgSqr447").src;
    valueQaSave447 = 'zSqrArtSpecz446';
    localStorage.setItem(valueQaSave447, sQAz446);
};

function square448(){
    var sQAz447 = document.getElementById("imgSqr448").src;
    valueQaSave448 = 'zSqrArtSpecz447';
    localStorage.setItem(valueQaSave448, sQAz447);
};

function square449(){
    var sQAz448 = document.getElementById("imgSqr449").src;
    valueQaSave449 = 'zSqrArtSpecz448';
    localStorage.setItem(valueQaSave449, sQAz448);
};

function square450(){
    var sQAz449 = document.getElementById("imgSqr450").src;
    valueQaSave450 = 'zSqrArtSpecz449';
    localStorage.setItem(valueQaSave450, sQAz449);
};

function square451(){
    var sQAz450 = document.getElementById("imgSqr451").src;
    valueQaSave451 = 'zSqrArtSpecz450';
    localStorage.setItem(valueQaSave451, sQAz450);
};

function square452(){
    var sQAz451 = document.getElementById("imgSqr452").src;
    valueQaSave452 = 'zSqrArtSpecz451';
    localStorage.setItem(valueQaSave452, sQAz451);
};

function square453(){
    var sQAz452 = document.getElementById("imgSqr453").src;
    valueQaSave453 = 'zSqrArtSpecz452';
    localStorage.setItem(valueQaSave453, sQAz452);
};

function square454(){
    var sQAz453 = document.getElementById("imgSqr454").src;
    valueQaSave454 = 'zSqrArtSpecz453';
    localStorage.setItem(valueQaSave454, sQAz453);
};

function square455(){
    var sQAz454 = document.getElementById("imgSqr455").src;
    valueQaSave455 = 'zSqrArtSpecz454';
    localStorage.setItem(valueQaSave455, sQAz454);
};

function square456(){
    var sQAz455 = document.getElementById("imgSqr456").src;
    valueQaSave456 = 'zSqrArtSpecz455';
    localStorage.setItem(valueQaSave456, sQAz455);
};

function square457(){
    var sQAz456 = document.getElementById("imgSqr457").src;
    valueQaSave457 = 'zSqrArtSpecz456';
    localStorage.setItem(valueQaSave457, sQAz456);
};

function square458(){
    var sQAz457 = document.getElementById("imgSqr458").src;
    valueQaSave458 = 'zSqrArtSpecz457';
    localStorage.setItem(valueQaSave458, sQAz457);
};

function square459(){
    var sQAz458 = document.getElementById("imgSqr459").src;
    valueQaSave459 = 'zSqrArtSpecz458';
    localStorage.setItem(valueQaSave459, sQAz458);
};

function square460(){
    var sQAz459 = document.getElementById("imgSqr460").src;
    valueQaSave460 = 'zSqrArtSpecz459';
    localStorage.setItem(valueQaSave460, sQAz459);
};

function square461(){
    var sQAz460 = document.getElementById("imgSqr461").src;
    valueQaSave461 = 'zSqrArtSpecz460';
    localStorage.setItem(valueQaSave461, sQAz460);
};

function square462(){
    var sQAz461 = document.getElementById("imgSqr462").src;
    valueQaSave462 = 'zSqrArtSpecz461';
    localStorage.setItem(valueQaSave462, sQAz461);
};

function square463(){
    var sQAz462 = document.getElementById("imgSqr463").src;
    valueQaSave463 = 'zSqrArtSpecz462';
    localStorage.setItem(valueQaSave463, sQAz462);
};

function square464(){
    var sQAz463 = document.getElementById("imgSqr464").src;
    valueQaSave464 = 'zSqrArtSpecz463';
    localStorage.setItem(valueQaSave464, sQAz463);
};

function square465(){
    var sQAz464 = document.getElementById("imgSqr465").src;
    valueQaSave465 = 'zSqrArtSpecz464';
    localStorage.setItem(valueQaSave465, sQAz464);
};

function square466(){
    var sQAz465 = document.getElementById("imgSqr466").src;
    valueQaSave466 = 'zSqrArtSpecz465';
    localStorage.setItem(valueQaSave466, sQAz465);
};

function square467(){
    var sQAz466 = document.getElementById("imgSqr467").src;
    valueQaSave467 = 'zSqrArtSpecz466';
    localStorage.setItem(valueQaSave467, sQAz466);
};

function square468(){
    var sQAz467 = document.getElementById("imgSqr468").src;
    valueQaSave468 = 'zSqrArtSpecz467';
    localStorage.setItem(valueQaSave468, sQAz467);
};

function square469(){
    var sQAz468 = document.getElementById("imgSqr469").src;
    valueQaSave469 = 'zSqrArtSpecz468';
    localStorage.setItem(valueQaSave469, sQAz468);
};

function square470(){
    var sQAz469 = document.getElementById("imgSqr470").src;
    valueQaSave470 = 'zSqrArtSpecz469';
    localStorage.setItem(valueQaSave470, sQAz469);
};

function square471(){
    var sQAz470 = document.getElementById("imgSqr471").src;
    valueQaSave471 = 'zSqrArtSpecz470';
    localStorage.setItem(valueQaSave471, sQAz470);
};

function square472(){
    var sQAz471 = document.getElementById("imgSqr472").src;
    valueQaSave472 = 'zSqrArtSpecz471';
    localStorage.setItem(valueQaSave472, sQAz471);
};

function square473(){
    var sQAz472 = document.getElementById("imgSqr473").src;
    valueQaSave473 = 'zSqrArtSpecz472';
    localStorage.setItem(valueQaSave473, sQAz472);
};

function square474(){
    var sQAz473 = document.getElementById("imgSqr474").src;
    valueQaSave474 = 'zSqrArtSpecz473';
    localStorage.setItem(valueQaSave474, sQAz473);
};

function square475(){
    var sQAz474 = document.getElementById("imgSqr475").src;
    valueQaSave475 = 'zSqrArtSpecz474';
    localStorage.setItem(valueQaSave475, sQAz474);
};

function square476(){
    var sQAz475 = document.getElementById("imgSqr476").src;
    valueQaSave476 = 'zSqrArtSpecz475';
    localStorage.setItem(valueQaSave476, sQAz475);
};

function square477(){
    var sQAz476 = document.getElementById("imgSqr477").src;
    valueQaSave477 = 'zSqrArtSpecz476';
    localStorage.setItem(valueQaSave477, sQAz476);
};

function square478(){
    var sQAz477 = document.getElementById("imgSqr478").src;
    valueQaSave478 = 'zSqrArtSpecz477';
    localStorage.setItem(valueQaSave478, sQAz477);
};

function square479(){
    var sQAz478 = document.getElementById("imgSqr479").src;
    valueQaSave479 = 'zSqrArtSpecz478';
    localStorage.setItem(valueQaSave479, sQAz478);
};

function square480(){
    var sQAz479 = document.getElementById("imgSqr480").src;
    valueQaSave480 = 'zSqrArtSpecz479';
    localStorage.setItem(valueQaSave480, sQAz479);
};

function square481(){
    var sQAz480 = document.getElementById("imgSqr481").src;
    valueQaSave481 = 'zSqrArtSpecz480';
    localStorage.setItem(valueQaSave481, sQAz480);
};

function square482(){
    var sQAz481 = document.getElementById("imgSqr482").src;
    valueQaSave482 = 'zSqrArtSpecz481';
    localStorage.setItem(valueQaSave482, sQAz481);
};

function square483(){
    var sQAz482 = document.getElementById("imgSqr483").src;
    valueQaSave483 = 'zSqrArtSpecz482';
    localStorage.setItem(valueQaSave483, sQAz482);
};

function square484(){
    var sQAz483 = document.getElementById("imgSqr484").src;
    valueQaSave484 = 'zSqrArtSpecz483';
    localStorage.setItem(valueQaSave484, sQAz483);
};

function square485(){
    var sQAz484 = document.getElementById("imgSqr485").src;
    valueQaSave485 = 'zSqrArtSpecz484';
    localStorage.setItem(valueQaSave485, sQAz484);
};

function square486(){
    var sQAz485 = document.getElementById("imgSqr486").src;
    valueQaSave486 = 'zSqrArtSpecz485';
    localStorage.setItem(valueQaSave486, sQAz485);
};

function square487(){
    var sQAz486 = document.getElementById("imgSqr487").src;
    valueQaSave487 = 'zSqrArtSpecz486';
    localStorage.setItem(valueQaSave487, sQAz486);
};

function square488(){
    var sQAz487 = document.getElementById("imgSqr488").src;
    valueQaSave488 = 'zSqrArtSpecz487';
    localStorage.setItem(valueQaSave488, sQAz487);
};

function square489(){
    var sQAz488 = document.getElementById("imgSqr489").src;
    valueQaSave489 = 'zSqrArtSpecz488';
    localStorage.setItem(valueQaSave489, sQAz488);
};

function square490(){
    var sQAz489 = document.getElementById("imgSqr490").src;
    valueQaSave490 = 'zSqrArtSpecz489';
    localStorage.setItem(valueQaSave490, sQAz489);
};

function square491(){
    var sQAz490 = document.getElementById("imgSqr491").src;
    valueQaSave491 = 'zSqrArtSpecz490';
    localStorage.setItem(valueQaSave491, sQAz490);
};

function square492(){
    var sQAz491 = document.getElementById("imgSqr492").src;
    valueQaSave492 = 'zSqrArtSpecz491';
    localStorage.setItem(valueQaSave492, sQAz491);
};

function square493(){
    var sQAz492 = document.getElementById("imgSqr493").src;
    valueQaSave493 = 'zSqrArtSpecz492';
    localStorage.setItem(valueQaSave493, sQAz492);
};

function square494(){
    var sQAz493 = document.getElementById("imgSqr494").src;
    valueQaSave494 = 'zSqrArtSpecz493';
    localStorage.setItem(valueQaSave494, sQAz493);
};

function square495(){
    var sQAz494 = document.getElementById("imgSqr495").src;
    valueQaSave495 = 'zSqrArtSpecz494';
    localStorage.setItem(valueQaSave495, sQAz494);
};

function square496(){
    var sQAz495 = document.getElementById("imgSqr496").src;
    valueQaSave496 = 'zSqrArtSpecz495';
    localStorage.setItem(valueQaSave496, sQAz495);
};

function square497(){
    var sQAz496 = document.getElementById("imgSqr497").src;
    valueQaSave497 = 'zSqrArtSpecz496';
    localStorage.setItem(valueQaSave497, sQAz496);
};

function square498(){
    var sQAz497 = document.getElementById("imgSqr498").src;
    valueQaSave498 = 'zSqrArtSpecz497';
    localStorage.setItem(valueQaSave498, sQAz497);
};

function square499(){
    var sQAz498 = document.getElementById("imgSqr499").src;
    valueQaSave499 = 'zSqrArtSpecz498';
    localStorage.setItem(valueQaSave499, sQAz498);
};

function square500(){
    var sQAz499 = document.getElementById("imgSqr500").src;
    valueQaSave500 = 'zSqrArtSpecz499';
    localStorage.setItem(valueQaSave500, sQAz499);
};

function square501(){
    var sQAz500 = document.getElementById("imgSqr501").src;
    valueQaSave501 = 'zSqrArtSpecz500';
    localStorage.setItem(valueQaSave501, sQAz500);
};

function square502(){
    var sQAz501 = document.getElementById("imgSqr502").src;
    valueQaSave502 = 'zSqrArtSpecz501';
    localStorage.setItem(valueQaSave502, sQAz501);
};

function square503(){
    var sQAz502 = document.getElementById("imgSqr503").src;
    valueQaSave503 = 'zSqrArtSpecz502';
    localStorage.setItem(valueQaSave503, sQAz502);
};

function square504(){
    var sQAz503 = document.getElementById("imgSqr504").src;
    valueQaSave504 = 'zSqrArtSpecz503';
    localStorage.setItem(valueQaSave504, sQAz503);
};

function square505(){
    var sQAz504 = document.getElementById("imgSqr505").src;
    valueQaSave505 = 'zSqrArtSpecz504';
    localStorage.setItem(valueQaSave505, sQAz504);
};

function square506(){
    var sQAz505 = document.getElementById("imgSqr506").src;
    valueQaSave506 = 'zSqrArtSpecz505';
    localStorage.setItem(valueQaSave506, sQAz505);
};

function square507(){
    var sQAz506 = document.getElementById("imgSqr507").src;
    valueQaSave507 = 'zSqrArtSpecz506';
    localStorage.setItem(valueQaSave507, sQAz506);
};

function square508(){
    var sQAz507 = document.getElementById("imgSqr508").src;
    valueQaSave508 = 'zSqrArtSpecz507';
    localStorage.setItem(valueQaSave508, sQAz507);
};

function square509(){
    var sQAz508 = document.getElementById("imgSqr509").src;
    valueQaSave509 = 'zSqrArtSpecz508';
    localStorage.setItem(valueQaSave509, sQAz508);
};

function square510(){
    var sQAz509 = document.getElementById("imgSqr510").src;
    valueQaSave510 = 'zSqrArtSpecz509';
    localStorage.setItem(valueQaSave510, sQAz509);
};

function square511(){
    var sQAz510 = document.getElementById("imgSqr511").src;
    valueQaSave511 = 'zSqrArtSpecz510';
    localStorage.setItem(valueQaSave511, sQAz510);
};

function square512(){
    var sQAz511 = document.getElementById("imgSqr512").src;
    valueQaSave512 = 'zSqrArtSpecz511';
    localStorage.setItem(valueQaSave512, sQAz511);
};

function square513(){
    var sQAz512 = document.getElementById("imgSqr513").src;
    valueQaSave513 = 'zSqrArtSpecz512';
    localStorage.setItem(valueQaSave513, sQAz512);
};

function square514(){
    var sQAz513 = document.getElementById("imgSqr514").src;
    valueQaSave514 = 'zSqrArtSpecz513';
    localStorage.setItem(valueQaSave514, sQAz513);
};

function square515(){
    var sQAz514 = document.getElementById("imgSqr515").src;
    valueQaSave515 = 'zSqrArtSpecz514';
    localStorage.setItem(valueQaSave515, sQAz514);
};

function square516(){
    var sQAz515 = document.getElementById("imgSqr516").src;
    valueQaSave516 = 'zSqrArtSpecz515';
    localStorage.setItem(valueQaSave516, sQAz515);
};

function square517(){
    var sQAz516 = document.getElementById("imgSqr517").src;
    valueQaSave517 = 'zSqrArtSpecz516';
    localStorage.setItem(valueQaSave517, sQAz516);
};

function square518(){
    var sQAz517 = document.getElementById("imgSqr518").src;
    valueQaSave518 = 'zSqrArtSpecz517';
    localStorage.setItem(valueQaSave518, sQAz517);
};

function square519(){
    var sQAz518 = document.getElementById("imgSqr519").src;
    valueQaSave519 = 'zSqrArtSpecz518';
    localStorage.setItem(valueQaSave519, sQAz518);
};

function square520(){
    var sQAz519 = document.getElementById("imgSqr520").src;
    valueQaSave520 = 'zSqrArtSpecz519';
    localStorage.setItem(valueQaSave520, sQAz519);
};

function square521(){
    var sQAz520 = document.getElementById("imgSqr521").src;
    valueQaSave521 = 'zSqrArtSpecz520';
    localStorage.setItem(valueQaSave521, sQAz520);
};

function square522(){
    var sQAz521 = document.getElementById("imgSqr522").src;
    valueQaSave522 = 'zSqrArtSpecz521';
    localStorage.setItem(valueQaSave522, sQAz521);
};

function square523(){
    var sQAz522 = document.getElementById("imgSqr523").src;
    valueQaSave523 = 'zSqrArtSpecz522';
    localStorage.setItem(valueQaSave523, sQAz522);
};

function square524(){
    var sQAz523 = document.getElementById("imgSqr524").src;
    valueQaSave524 = 'zSqrArtSpecz523';
    localStorage.setItem(valueQaSave524, sQAz523);
};

function square525(){
    var sQAz524 = document.getElementById("imgSqr525").src;
    valueQaSave525 = 'zSqrArtSpecz524';
    localStorage.setItem(valueQaSave525, sQAz524);
};

function square526(){
    var sQAz525 = document.getElementById("imgSqr526").src;
    valueQaSave526 = 'zSqrArtSpecz525';
    localStorage.setItem(valueQaSave526, sQAz525);
};

function square527(){
    var sQAz526 = document.getElementById("imgSqr527").src;
    valueQaSave527 = 'zSqrArtSpecz526';
    localStorage.setItem(valueQaSave527, sQAz526);
};

function square528(){
    var sQAz527 = document.getElementById("imgSqr528").src;
    valueQaSave528 = 'zSqrArtSpecz527';
    localStorage.setItem(valueQaSave528, sQAz527);
};

function square529(){
    var sQAz528 = document.getElementById("imgSqr529").src;
    valueQaSave529 = 'zSqrArtSpecz528';
    localStorage.setItem(valueQaSave529, sQAz528);
};

function square530(){
    var sQAz529 = document.getElementById("imgSqr530").src;
    valueQaSave530 = 'zSqrArtSpecz529';
    localStorage.setItem(valueQaSave530, sQAz529);
};

function square531(){
    var sQAz530 = document.getElementById("imgSqr531").src;
    valueQaSave531 = 'zSqrArtSpecz530';
    localStorage.setItem(valueQaSave531, sQAz530);
};

function square532(){
    var sQAz531 = document.getElementById("imgSqr532").src;
    valueQaSave532 = 'zSqrArtSpecz531';
    localStorage.setItem(valueQaSave532, sQAz531);
};

function square533(){
    var sQAz532 = document.getElementById("imgSqr533").src;
    valueQaSave533 = 'zSqrArtSpecz532';
    localStorage.setItem(valueQaSave533, sQAz532);
};

function square534(){
    var sQAz533 = document.getElementById("imgSqr534").src;
    valueQaSave534 = 'zSqrArtSpecz533';
    localStorage.setItem(valueQaSave534, sQAz533);
};

function square535(){
    var sQAz534 = document.getElementById("imgSqr535").src;
    valueQaSave535 = 'zSqrArtSpecz534';
    localStorage.setItem(valueQaSave535, sQAz534);
};

function square536(){
    var sQAz535 = document.getElementById("imgSqr536").src;
    valueQaSave536 = 'zSqrArtSpecz535';
    localStorage.setItem(valueQaSave536, sQAz535);
};

function square537(){
    var sQAz536 = document.getElementById("imgSqr537").src;
    valueQaSave537 = 'zSqrArtSpecz536';
    localStorage.setItem(valueQaSave537, sQAz536);
};

function square538(){
    var sQAz537 = document.getElementById("imgSqr538").src;
    valueQaSave538 = 'zSqrArtSpecz537';
    localStorage.setItem(valueQaSave538, sQAz537);
};

function square539(){
    var sQAz538 = document.getElementById("imgSqr539").src;
    valueQaSave539 = 'zSqrArtSpecz538';
    localStorage.setItem(valueQaSave539, sQAz538);
};

function square540(){
    var sQAz539 = document.getElementById("imgSqr540").src;
    valueQaSave540 = 'zSqrArtSpecz539';
    localStorage.setItem(valueQaSave540, sQAz539);
};

function square541(){
    var sQAz540 = document.getElementById("imgSqr541").src;
    valueQaSave541 = 'zSqrArtSpecz540';
    localStorage.setItem(valueQaSave541, sQAz540);
};

function square542(){
    var sQAz541 = document.getElementById("imgSqr542").src;
    valueQaSave542 = 'zSqrArtSpecz541';
    localStorage.setItem(valueQaSave542, sQAz541);
};

function square543(){
    var sQAz542 = document.getElementById("imgSqr543").src;
    valueQaSave543 = 'zSqrArtSpecz542';
    localStorage.setItem(valueQaSave543, sQAz542);
};

function square544(){
    var sQAz543 = document.getElementById("imgSqr544").src;
    valueQaSave544 = 'zSqrArtSpecz543';
    localStorage.setItem(valueQaSave544, sQAz543);
};

function square545(){
    var sQAz544 = document.getElementById("imgSqr545").src;
    valueQaSave545 = 'zSqrArtSpecz544';
    localStorage.setItem(valueQaSave545, sQAz544);
};

function square546(){
    var sQAz545 = document.getElementById("imgSqr546").src;
    valueQaSave546 = 'zSqrArtSpecz545';
    localStorage.setItem(valueQaSave546, sQAz545);
};

function square547(){
    var sQAz546 = document.getElementById("imgSqr547").src;
    valueQaSave547 = 'zSqrArtSpecz546';
    localStorage.setItem(valueQaSave547, sQAz546);
};

function square548(){
    var sQAz547 = document.getElementById("imgSqr548").src;
    valueQaSave548 = 'zSqrArtSpecz547';
    localStorage.setItem(valueQaSave548, sQAz547);
};

function square549(){
    var sQAz548 = document.getElementById("imgSqr549").src;
    valueQaSave549 = 'zSqrArtSpecz548';
    localStorage.setItem(valueQaSave549, sQAz548);
};

function square550(){
    var sQAz549 = document.getElementById("imgSqr550").src;
    valueQaSave550 = 'zSqrArtSpecz549';
    localStorage.setItem(valueQaSave550, sQAz549);
};

function square551(){
    var sQAz550 = document.getElementById("imgSqr551").src;
    valueQaSave551 = 'zSqrArtSpecz550';
    localStorage.setItem(valueQaSave551, sQAz550);
};

function square552(){
    var sQAz551 = document.getElementById("imgSqr552").src;
    valueQaSave552 = 'zSqrArtSpecz551';
    localStorage.setItem(valueQaSave552, sQAz551);
};

function square553(){
    var sQAz552 = document.getElementById("imgSqr553").src;
    valueQaSave553 = 'zSqrArtSpecz552';
    localStorage.setItem(valueQaSave553, sQAz552);
};

function square554(){
    var sQAz553 = document.getElementById("imgSqr554").src;
    valueQaSave554 = 'zSqrArtSpecz553';
    localStorage.setItem(valueQaSave554, sQAz553);
};

function square555(){
    var sQAz554 = document.getElementById("imgSqr555").src;
    valueQaSave555 = 'zSqrArtSpecz554';
    localStorage.setItem(valueQaSave555, sQAz554);
};

function square556(){
    var sQAz555 = document.getElementById("imgSqr556").src;
    valueQaSave556 = 'zSqrArtSpecz555';
    localStorage.setItem(valueQaSave556, sQAz555);
};

function square557(){
    var sQAz556 = document.getElementById("imgSqr557").src;
    valueQaSave557 = 'zSqrArtSpecz556';
    localStorage.setItem(valueQaSave557, sQAz556);
};

function square558(){
    var sQAz557 = document.getElementById("imgSqr558").src;
    valueQaSave558 = 'zSqrArtSpecz557';
    localStorage.setItem(valueQaSave558, sQAz557);
};

function square559(){
    var sQAz558 = document.getElementById("imgSqr559").src;
    valueQaSave559 = 'zSqrArtSpecz558';
    localStorage.setItem(valueQaSave559, sQAz558);
};

function square560(){
    var sQAz559 = document.getElementById("imgSqr560").src;
    valueQaSave560 = 'zSqrArtSpecz559';
    localStorage.setItem(valueQaSave560, sQAz559);
};

function square561(){
    var sQAz560 = document.getElementById("imgSqr561").src;
    valueQaSave561 = 'zSqrArtSpecz560';
    localStorage.setItem(valueQaSave561, sQAz560);
};

function square562(){
    var sQAz561 = document.getElementById("imgSqr562").src;
    valueQaSave562 = 'zSqrArtSpecz561';
    localStorage.setItem(valueQaSave562, sQAz561);
};

function square563(){
    var sQAz562 = document.getElementById("imgSqr563").src;
    valueQaSave563 = 'zSqrArtSpecz562';
    localStorage.setItem(valueQaSave563, sQAz562);
};

function square564(){
    var sQAz563 = document.getElementById("imgSqr564").src;
    valueQaSave564 = 'zSqrArtSpecz563';
    localStorage.setItem(valueQaSave564, sQAz563);
};

function square565(){
    var sQAz564 = document.getElementById("imgSqr565").src;
    valueQaSave565 = 'zSqrArtSpecz564';
    localStorage.setItem(valueQaSave565, sQAz564);
};

function square566(){
    var sQAz565 = document.getElementById("imgSqr566").src;
    valueQaSave566 = 'zSqrArtSpecz565';
    localStorage.setItem(valueQaSave566, sQAz565);
};

function square567(){
    var sQAz566 = document.getElementById("imgSqr567").src;
    valueQaSave567 = 'zSqrArtSpecz566';
    localStorage.setItem(valueQaSave567, sQAz566);
};

function square568(){
    var sQAz567 = document.getElementById("imgSqr568").src;
    valueQaSave568 = 'zSqrArtSpecz567';
    localStorage.setItem(valueQaSave568, sQAz567);
};

function square569(){
    var sQAz568 = document.getElementById("imgSqr569").src;
    valueQaSave569 = 'zSqrArtSpecz568';
    localStorage.setItem(valueQaSave569, sQAz568);
};

function square570(){
    var sQAz569 = document.getElementById("imgSqr570").src;
    valueQaSave570 = 'zSqrArtSpecz569';
    localStorage.setItem(valueQaSave570, sQAz569);
};

function square571(){
    var sQAz570 = document.getElementById("imgSqr571").src;
    valueQaSave571 = 'zSqrArtSpecz570';
    localStorage.setItem(valueQaSave571, sQAz570);
};

function square572(){
    var sQAz571 = document.getElementById("imgSqr572").src;
    valueQaSave572 = 'zSqrArtSpecz571';
    localStorage.setItem(valueQaSave572, sQAz571);
};

function square573(){
    var sQAz572 = document.getElementById("imgSqr573").src;
    valueQaSave573 = 'zSqrArtSpecz572';
    localStorage.setItem(valueQaSave573, sQAz572);
};

function square574(){
    var sQAz573 = document.getElementById("imgSqr574").src;
    valueQaSave574 = 'zSqrArtSpecz573';
    localStorage.setItem(valueQaSave574, sQAz573);
};

function square575(){
    var sQAz574 = document.getElementById("imgSqr575").src;
    valueQaSave575 = 'zSqrArtSpecz574';
    localStorage.setItem(valueQaSave575, sQAz574);
};

function square576(){
    var sQAz575 = document.getElementById("imgSqr576").src;
    valueQaSave576 = 'zSqrArtSpecz575';
    localStorage.setItem(valueQaSave576, sQAz575);
};

function square577(){
    var sQAz576 = document.getElementById("imgSqr577").src;
    valueQaSave577 = 'zSqrArtSpecz576';
    localStorage.setItem(valueQaSave577, sQAz576);
};

function square578(){
    var sQAz577 = document.getElementById("imgSqr578").src;
    valueQaSave578 = 'zSqrArtSpecz577';
    localStorage.setItem(valueQaSave578, sQAz577);
};

function square579(){
    var sQAz578 = document.getElementById("imgSqr579").src;
    valueQaSave579 = 'zSqrArtSpecz578';
    localStorage.setItem(valueQaSave579, sQAz578);
};

function square580(){
    var sQAz579 = document.getElementById("imgSqr580").src;
    valueQaSave580 = 'zSqrArtSpecz579';
    localStorage.setItem(valueQaSave580, sQAz579);
};

function square581(){
    var sQAz580 = document.getElementById("imgSqr581").src;
    valueQaSave581 = 'zSqrArtSpecz580';
    localStorage.setItem(valueQaSave581, sQAz580);
};

function square582(){
    var sQAz581 = document.getElementById("imgSqr582").src;
    valueQaSave582 = 'zSqrArtSpecz581';
    localStorage.setItem(valueQaSave582, sQAz581);
};

function square583(){
    var sQAz582 = document.getElementById("imgSqr583").src;
    valueQaSave583 = 'zSqrArtSpecz582';
    localStorage.setItem(valueQaSave583, sQAz582);
};

function square584(){
    var sQAz583 = document.getElementById("imgSqr584").src;
    valueQaSave584 = 'zSqrArtSpecz583';
    localStorage.setItem(valueQaSave584, sQAz583);
};

function square585(){
    var sQAz584 = document.getElementById("imgSqr585").src;
    valueQaSave585 = 'zSqrArtSpecz584';
    localStorage.setItem(valueQaSave585, sQAz584);
};

function square586(){
    var sQAz585 = document.getElementById("imgSqr586").src;
    valueQaSave586 = 'zSqrArtSpecz585';
    localStorage.setItem(valueQaSave586, sQAz585);
};

function square587(){
    var sQAz586 = document.getElementById("imgSqr587").src;
    valueQaSave587 = 'zSqrArtSpecz586';
    localStorage.setItem(valueQaSave587, sQAz586);
};

function square588(){
    var sQAz587 = document.getElementById("imgSqr588").src;
    valueQaSave588 = 'zSqrArtSpecz587';
    localStorage.setItem(valueQaSave588, sQAz587);
};

function square589(){
    var sQAz588 = document.getElementById("imgSqr589").src;
    valueQaSave589 = 'zSqrArtSpecz588';
    localStorage.setItem(valueQaSave589, sQAz588);
};

function square590(){
    var sQAz589 = document.getElementById("imgSqr590").src;
    valueQaSave590 = 'zSqrArtSpecz589';
    localStorage.setItem(valueQaSave590, sQAz589);
};

function square591(){
    var sQAz590 = document.getElementById("imgSqr591").src;
    valueQaSave591 = 'zSqrArtSpecz590';
    localStorage.setItem(valueQaSave591, sQAz590);
};

function square592(){
    var sQAz591 = document.getElementById("imgSqr592").src;
    valueQaSave592 = 'zSqrArtSpecz591';
    localStorage.setItem(valueQaSave592, sQAz591);
};

function square593(){
    var sQAz592 = document.getElementById("imgSqr593").src;
    valueQaSave593 = 'zSqrArtSpecz592';
    localStorage.setItem(valueQaSave593, sQAz592);
};

function square594(){
    var sQAz593 = document.getElementById("imgSqr594").src;
    valueQaSave594 = 'zSqrArtSpecz593';
    localStorage.setItem(valueQaSave594, sQAz593);
};

function square595(){
    var sQAz594 = document.getElementById("imgSqr595").src;
    valueQaSave595 = 'zSqrArtSpecz594';
    localStorage.setItem(valueQaSave595, sQAz594);
};

function square596(){
    var sQAz595 = document.getElementById("imgSqr596").src;
    valueQaSave596 = 'zSqrArtSpecz595';
    localStorage.setItem(valueQaSave596, sQAz595);
};

function square597(){
    var sQAz596 = document.getElementById("imgSqr597").src;
    valueQaSave597 = 'zSqrArtSpecz596';
    localStorage.setItem(valueQaSave597, sQAz596);
};

function square598(){
    var sQAz597 = document.getElementById("imgSqr598").src;
    valueQaSave598 = 'zSqrArtSpecz597';
    localStorage.setItem(valueQaSave598, sQAz597);
};

function square599(){
    var sQAz598 = document.getElementById("imgSqr599").src;
    valueQaSave599 = 'zSqrArtSpecz598';
    localStorage.setItem(valueQaSave599, sQAz598);
};

function square600(){
    var sQAz599 = document.getElementById("imgSqr600").src;
    valueQaSave600 = 'zSqrArtSpecz599';
    localStorage.setItem(valueQaSave600, sQAz599);
};

function square601(){
    var sQAz600 = document.getElementById("imgSqr601").src;
    valueQaSave601 = 'zSqrArtSpecz600';
    localStorage.setItem(valueQaSave601, sQAz600);
};

function square602(){
    var sQAz601 = document.getElementById("imgSqr602").src;
    valueQaSave602 = 'zSqrArtSpecz601';
    localStorage.setItem(valueQaSave602, sQAz601);
};

function square603(){
    var sQAz602 = document.getElementById("imgSqr603").src;
    valueQaSave603 = 'zSqrArtSpecz602';
    localStorage.setItem(valueQaSave603, sQAz602);
};

function square604(){
    var sQAz603 = document.getElementById("imgSqr604").src;
    valueQaSave604 = 'zSqrArtSpecz603';
    localStorage.setItem(valueQaSave604, sQAz603);
};

function square605(){
    var sQAz604 = document.getElementById("imgSqr605").src;
    valueQaSave605 = 'zSqrArtSpecz604';
    localStorage.setItem(valueQaSave605, sQAz604);
};

function square606(){
    var sQAz605 = document.getElementById("imgSqr606").src;
    valueQaSave606 = 'zSqrArtSpecz605';
    localStorage.setItem(valueQaSave606, sQAz605);
};

function square607(){
    var sQAz606 = document.getElementById("imgSqr607").src;
    valueQaSave607 = 'zSqrArtSpecz606';
    localStorage.setItem(valueQaSave607, sQAz606);
};

function square608(){
    var sQAz607 = document.getElementById("imgSqr608").src;
    valueQaSave608 = 'zSqrArtSpecz607';
    localStorage.setItem(valueQaSave608, sQAz607);
};

function square609(){
    var sQAz608 = document.getElementById("imgSqr609").src;
    valueQaSave609 = 'zSqrArtSpecz608';
    localStorage.setItem(valueQaSave609, sQAz608);
};

function square610(){
    var sQAz609 = document.getElementById("imgSqr610").src;
    valueQaSave610 = 'zSqrArtSpecz609';
    localStorage.setItem(valueQaSave610, sQAz609);
};

function square611(){
    var sQAz610 = document.getElementById("imgSqr611").src;
    valueQaSave611 = 'zSqrArtSpecz610';
    localStorage.setItem(valueQaSave611, sQAz610);
};

function square612(){
    var sQAz611 = document.getElementById("imgSqr612").src;
    valueQaSave612 = 'zSqrArtSpecz611';
    localStorage.setItem(valueQaSave612, sQAz611);
};

function square613(){
    var sQAz612 = document.getElementById("imgSqr613").src;
    valueQaSave613 = 'zSqrArtSpecz612';
    localStorage.setItem(valueQaSave613, sQAz612);
};

function square614(){
    var sQAz613 = document.getElementById("imgSqr614").src;
    valueQaSave614 = 'zSqrArtSpecz613';
    localStorage.setItem(valueQaSave614, sQAz613);
};

function square615(){
    var sQAz614 = document.getElementById("imgSqr615").src;
    valueQaSave615 = 'zSqrArtSpecz614';
    localStorage.setItem(valueQaSave615, sQAz614);
};

function square616(){
    var sQAz615 = document.getElementById("imgSqr616").src;
    valueQaSave616 = 'zSqrArtSpecz615';
    localStorage.setItem(valueQaSave616, sQAz615);
};

function square617(){
    var sQAz616 = document.getElementById("imgSqr617").src;
    valueQaSave617 = 'zSqrArtSpecz616';
    localStorage.setItem(valueQaSave617, sQAz616);
};

function square618(){
    var sQAz617 = document.getElementById("imgSqr618").src;
    valueQaSave618 = 'zSqrArtSpecz617';
    localStorage.setItem(valueQaSave618, sQAz617);
};

function square619(){
    var sQAz618 = document.getElementById("imgSqr619").src;
    valueQaSave619 = 'zSqrArtSpecz618';
    localStorage.setItem(valueQaSave619, sQAz618);
};

function square620(){
    var sQAz619 = document.getElementById("imgSqr620").src;
    valueQaSave620 = 'zSqrArtSpecz619';
    localStorage.setItem(valueQaSave620, sQAz619);
};

function square621(){
    var sQAz620 = document.getElementById("imgSqr621").src;
    valueQaSave621 = 'zSqrArtSpecz620';
    localStorage.setItem(valueQaSave621, sQAz620);
};

function square622(){
    var sQAz621 = document.getElementById("imgSqr622").src;
    valueQaSave622 = 'zSqrArtSpecz621';
    localStorage.setItem(valueQaSave622, sQAz621);
};

function square623(){
    var sQAz622 = document.getElementById("imgSqr623").src;
    valueQaSave623 = 'zSqrArtSpecz622';
    localStorage.setItem(valueQaSave623, sQAz622);
};

function square624(){
    var sQAz623 = document.getElementById("imgSqr624").src;
    valueQaSave624 = 'zSqrArtSpecz623';
    localStorage.setItem(valueQaSave624, sQAz623);
};

function square625(){
    var sQAz624 = document.getElementById("imgSqr625").src;
    valueQaSave625 = 'zSqrArtSpecz624';
    localStorage.setItem(valueQaSave625, sQAz624);
};

function setAThis(){
    square1()
    square2()
    square3()
    square4()
    square5()
    square6()
    square7()
    square8()
    square9()
    square10()
    square11()
    square12()
    square13()
    square14()
    square15()
    square16()
    square17()
    square18()
    square19()
    square20()
    square21()
    square22()
    square23()
    square24()
    square25()
    square26()
    square27()
    square28()
    square29()
    square30()
    square31()
    square32()
    square33()
    square34()
    square35()
    square36()
    square37()
    square38()
    square39()
    square40()
    square41()
    square42()
    square43()
    square44()
    square45()
    square46()
    square47()
    square48()
    square49()
    square50()
    square51()
    square52()
    square53()
    square54()
    square55()
    square56()
    square57()
    square58()
    square59()
    square60()
    square61()
    square62()
    square63()
    square64()
    square65()
    square66()
    square67()
    square68()
    square69()
    square70()
    square71()
    square72()
    square73()
    square74()
    square75()
    square76()
    square77()
    square78()
    square79()
    square80()
    square81()
    square82()
    square83()
    square84()
    square85()
    square86()
    square87()
    square88()
    square89()
    square90()
    square91()
    square92()
    square93()
    square94()
    square95()
    square96()
    square97()
    square98()
    square99()
    square100()
    square101()
    square102()
    square103()
    square104()
    square105()
    square106()
    square107()
    square108()
    square109()
    square110()
    square111()
    square112()
    square113()
    square114()
    square115()
    square116()
    square117()
    square118()
    square119()
    square120()
    square121()
    square122()
    square123()
    square124()
    square125()
    square126()
    square127()
    square128()
    square129()
    square130()
    square131()
    square132()
    square133()
    square134()
    square135()
    square136()
    square137()
    square138()
    square139()
    square140()
    square141()
    square142()
    square143()
    square144()
    square145()
    square146()
    square147()
    square148()
    square149()
    square150()
    square151()
    square152()
    square153()
    square154()
    square155()
    square156()
    square157()
    square158()
    square159()
    square160()
    square161()
    square162()
    square163()
    square164()
    square165()
    square166()
    square167()
    square168()
    square169()
    square170()
    square171()
    square172()
    square173()
    square174()
    square175()
    square176()
    square177()
    square178()
    square179()
    square180()
    square181()
    square182()
    square183()
    square184()
    square185()
    square186()
    square187()
    square188()
    square189()
    square190()
    square191()
    square192()
    square193()
    square194()
    square195()
    square196()
    square197()
    square198()
    square199()
    square200()
    square201()
    square202()
    square203()
    square204()
    square205()
    square206()
    square207()
    square208()
    square209()
    square210()
    square211()
    square212()
    square213()
    square214()
    square215()
    square216()
    square217()
    square218()
    square219()
    square220()
    square221()
    square222()
    square223()
    square224()
    square225()
    square226()
    square227()
    square228()
    square229()
    square230()
    square231()
    square232()
    square233()
    square234()
    square235()
    square236()
    square237()
    square238()
    square239()
    square240()
    square241()
    square242()
    square243()
    square244()
    square245()
    square246()
    square247()
    square248()
    square249()
    square250()
    square251()
    square252()
    square253()
    square254()
    square255()
    square256()
    square257()
    square258()
    square259()
    square260()
    square261()
    square262()
    square263()
    square264()
    square265()
    square266()
    square267()
    square268()
    square269()
    square270()
    square271()
    square272()
    square273()
    square274()
    square275()
    square276()
    square277()
    square278()
    square279()
    square280()
    square281()
    square282()
    square283()
    square284()
    square285()
    square286()
    square287()
    square288()
    square289()
    square290()
    square291()
    square292()
    square293()
    square294()
    square295()
    square296()
    square297()
    square298()
    square299()
    square300()
    square301()
    square302()
    square303()
    square304()
    square305()
    square306()
    square307()
    square308()
    square309()
    square310()
    square311()
    square312()
    square313()
    square314()
    square315()
    square316()
    square317()
    square318()
    square319()
    square320()
    square321()
    square322()
    square323()
    square324()
    square325()
    square326()
    square327()
    square328()
    square329()
    square330()
    square331()
    square332()
    square333()
    square334()
    square335()
    square336()
    square337()
    square338()
    square339()
    square340()
    square341()
    square342()
    square343()
    square344()
    square345()
    square346()
    square347()
    square348()
    square349()
    square350()
    square351()
    square352()
    square353()
    square354()
    square355()
    square356()
    square357()
    square358()
    square359()
    square360()
    square361()
    square362()
    square363()
    square364()
    square365()
    square366()
    square367()
    square368()
    square369()
    square370()
    square371()
    square372()
    square373()
    square374()
    square375()
    square376()
    square377()
    square378()
    square379()
    square380()
    square381()
    square382()
    square383()
    square384()
    square385()
    square386()
    square387()
    square388()
    square389()
    square390()
    square391()
    square392()
    square393()
    square394()
    square395()
    square396()
    square397()
    square398()
    square399()
    square400()
    square401()
    square402()
    square403()
    square404()
    square405()
    square406()
    square407()
    square408()
    square409()
    square410()
    square411()
    square412()
    square413()
    square414()
    square415()
    square416()
    square417()
    square418()
    square419()
    square420()
    square421()
    square422()
    square423()
    square424()
    square425()
    square426()
    square427()
    square428()
    square429()
    square430()
    square431()
    square432()
    square433()
    square434()
    square435()
    square436()
    square437()
    square438()
    square439()
    square440()
    square441()
    square442()
    square443()
    square444()
    square445()
    square446()
    square447()
    square448()
    square449()
    square450()
    square451()
    square452()
    square453()
    square454()
    square455()
    square456()
    square457()
    square458()
    square459()
    square460()
    square461()
    square462()
    square463()
    square464()
    square465()
    square466()
    square467()
    square468()
    square469()
    square470()
    square471()
    square472()
    square473()
    square474()
    square475()
    square476()
    square477()
    square478()
    square479()
    square480()
    square481()
    square482()
    square483()
    square484()
    square485()
    square486()
    square487()
    square488()
    square489()
    square490()
    square491()
    square492()
    square493()
    square494()
    square495()
    square496()
    square497()
    square498()
    square499()
    square500()
    square501()
    square502()
    square503()
    square504()
    square505()
    square506()
    square507()
    square508()
    square509()
    square510()
    square511()
    square512()
    square513()
    square514()
    square515()
    square516()
    square517()
    square518()
    square519()
    square520()
    square521()
    square522()
    square523()
    square524()
    square525()
    square526()
    square527()
    square528()
    square529()
    square530()
    square531()
    square532()
    square533()
    square534()
    square535()
    square536()
    square537()
    square538()
    square539()
    square540()
    square541()
    square542()
    square543()
    square544()
    square545()
    square546()
    square547()
    square548()
    square549()
    square550()
    square551()
    square552()
    square553()
    square554()
    square555()
    square556()
    square557()
    square558()
    square559()
    square560()
    square561()
    square562()
    square563()
    square564()
    square565()
    square566()
    square567()
    square568()
    square569()
    square570()
    square571()
    square572()
    square573()
    square574()
    square575()
    square576()
    square577()
    square578()
    square579()
    square580()
    square581()
    square582()
    square583()
    square584()
    square585()
    square586()
    square587()
    square588()
    square589()
    square590()
    square591()
    square592()
    square593()
    square594()
    square595()
    square596()
    square597()
    square598()
    square599()
    square600()
    square601()
    square602()
    square603()
    square604()
    square605()
    square606()
    square607()
    square608()
    square609()
    square610()
    square611()
    square612()
    square613()
    square614()
    square615()
    square616()
    square617()
    square618()
    square619()
    square620()
    square621()
    square622()
    square623()
    square624()
    square625()
    alert("Your art has been saved locally, to your local browser storage.");
};

function squareToSzzZValue0(){
    valueQaSave = 'zSqrArtSpecz0';
    var tripleZeroA = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr1").src = tripleZeroA;
};

function squareToSzzZValue1(){
    valueQaSave = 'zSqrArtSpecz1';
    var tripleZero0 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr2").src = tripleZero0;
};

function squareToSzzZValue2(){
    valueQaSave = 'zSqrArtSpecz2';
    var tripleZero1 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr3").src = tripleZero1;
};

function squareToSzzZValue3(){
    valueQaSave = 'zSqrArtSpecz3';
    var tripleZero2 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr4").src = tripleZero2;
};

function squareToSzzZValue4(){
    valueQaSave = 'zSqrArtSpecz4';
    var tripleZero3 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr5").src = tripleZero3;
};

function squareToSzzZValue5(){
    valueQaSave = 'zSqrArtSpecz5';
    var tripleZero4 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr6").src = tripleZero4;
};

function squareToSzzZValue6(){
    valueQaSave = 'zSqrArtSpecz6';
    var tripleZero5 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr7").src = tripleZero5;
};

function squareToSzzZValue7(){
    valueQaSave = 'zSqrArtSpecz7';
    var tripleZero6 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr8").src = tripleZero6;
};

function squareToSzzZValue8(){
    valueQaSave = 'zSqrArtSpecz8';
    var tripleZero7 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr9").src = tripleZero7;
};

function squareToSzzZValue9(){
    valueQaSave = 'zSqrArtSpecz9';
    var tripleZero8 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr10").src = tripleZero8;
};

function squareToSzzZValue10(){
    valueQaSave = 'zSqrArtSpecz10';
    var tripleZero9 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr11").src = tripleZero9;
};

function squareToSzzZValue11(){
    valueQaSave = 'zSqrArtSpecz11';
    var tripleZero10 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr12").src = tripleZero10;
};

function squareToSzzZValue12(){
    valueQaSave = 'zSqrArtSpecz12';
    var tripleZero11 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr13").src = tripleZero11;
};

function squareToSzzZValue13(){
    valueQaSave = 'zSqrArtSpecz13';
    var tripleZero12 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr14").src = tripleZero12;
};

function squareToSzzZValue14(){
    valueQaSave = 'zSqrArtSpecz14';
    var tripleZero13 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr15").src = tripleZero13;
};

function squareToSzzZValue15(){
    valueQaSave = 'zSqrArtSpecz15';
    var tripleZero14 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr16").src = tripleZero14;
};

function squareToSzzZValue16(){
    valueQaSave = 'zSqrArtSpecz16';
    var tripleZero15 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr17").src = tripleZero15;
};

function squareToSzzZValue17(){
    valueQaSave = 'zSqrArtSpecz17';
    var tripleZero16 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr18").src = tripleZero16;
};

function squareToSzzZValue18(){
    valueQaSave = 'zSqrArtSpecz18';
    var tripleZero17 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr19").src = tripleZero17;
};

function squareToSzzZValue19(){
    valueQaSave = 'zSqrArtSpecz19';
    var tripleZero18 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr20").src = tripleZero18;
};

function squareToSzzZValue20(){
    valueQaSave = 'zSqrArtSpecz20';
    var tripleZero19 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr21").src = tripleZero19;
};

function squareToSzzZValue21(){
    valueQaSave = 'zSqrArtSpecz21';
    var tripleZero20 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr22").src = tripleZero20;
};

function squareToSzzZValue22(){
    valueQaSave = 'zSqrArtSpecz22';
    var tripleZero21 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr23").src = tripleZero21;
};

function squareToSzzZValue23(){
    valueQaSave = 'zSqrArtSpecz23';
    var tripleZero22 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr24").src = tripleZero22;
};

function squareToSzzZValue24(){
    valueQaSave = 'zSqrArtSpecz24';
    var tripleZero23 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr25").src = tripleZero23;
};

function squareToSzzZValue25(){
    valueQaSave = 'zSqrArtSpecz25';
    var tripleZero24 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr26").src = tripleZero24;
};

function squareToSzzZValue26(){
    valueQaSave = 'zSqrArtSpecz26';
    var tripleZero25 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr27").src = tripleZero25;
};

function squareToSzzZValue27(){
    valueQaSave = 'zSqrArtSpecz27';
    var tripleZero26 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr28").src = tripleZero26;
};

function squareToSzzZValue28(){
    valueQaSave = 'zSqrArtSpecz28';
    var tripleZero27 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr29").src = tripleZero27;
};

function squareToSzzZValue29(){
    valueQaSave = 'zSqrArtSpecz29';
    var tripleZero28 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr30").src = tripleZero28;
};

function squareToSzzZValue30(){
    valueQaSave = 'zSqrArtSpecz30';
    var tripleZero29 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr31").src = tripleZero29;
};

function squareToSzzZValue31(){
    valueQaSave = 'zSqrArtSpecz31';
    var tripleZero30 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr32").src = tripleZero30;
};

function squareToSzzZValue32(){
    valueQaSave = 'zSqrArtSpecz32';
    var tripleZero31 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr33").src = tripleZero31;
};

function squareToSzzZValue33(){
    valueQaSave = 'zSqrArtSpecz33';
    var tripleZero32 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr34").src = tripleZero32;
};

function squareToSzzZValue34(){
    valueQaSave = 'zSqrArtSpecz34';
    var tripleZero33 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr35").src = tripleZero33;
};

function squareToSzzZValue35(){
    valueQaSave = 'zSqrArtSpecz35';
    var tripleZero34 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr36").src = tripleZero34;
};

function squareToSzzZValue36(){
    valueQaSave = 'zSqrArtSpecz36';
    var tripleZero35 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr37").src = tripleZero35;
};

function squareToSzzZValue37(){
    valueQaSave = 'zSqrArtSpecz37';
    var tripleZero36 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr38").src = tripleZero36;
};

function squareToSzzZValue38(){
    valueQaSave = 'zSqrArtSpecz38';
    var tripleZero37 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr39").src = tripleZero37;
};

function squareToSzzZValue39(){
    valueQaSave = 'zSqrArtSpecz39';
    var tripleZero38 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr40").src = tripleZero38;
};

function squareToSzzZValue40(){
    valueQaSave = 'zSqrArtSpecz40';
    var tripleZero39 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr41").src = tripleZero39;
};

function squareToSzzZValue41(){
    valueQaSave = 'zSqrArtSpecz41';
    var tripleZero40 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr42").src = tripleZero40;
};

function squareToSzzZValue42(){
    valueQaSave = 'zSqrArtSpecz42';
    var tripleZero41 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr43").src = tripleZero41;
};

function squareToSzzZValue43(){
    valueQaSave = 'zSqrArtSpecz43';
    var tripleZero42 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr44").src = tripleZero42;
};

function squareToSzzZValue44(){
    valueQaSave = 'zSqrArtSpecz44';
    var tripleZero43 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr45").src = tripleZero43;
};

function squareToSzzZValue45(){
    valueQaSave = 'zSqrArtSpecz45';
    var tripleZero44 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr46").src = tripleZero44;
};

function squareToSzzZValue46(){
    valueQaSave = 'zSqrArtSpecz46';
    var tripleZero45 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr47").src = tripleZero45;
};

function squareToSzzZValue47(){
    valueQaSave = 'zSqrArtSpecz47';
    var tripleZero46 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr48").src = tripleZero46;
};

function squareToSzzZValue48(){
    valueQaSave = 'zSqrArtSpecz48';
    var tripleZero47 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr49").src = tripleZero47;
};

function squareToSzzZValue49(){
    valueQaSave = 'zSqrArtSpecz49';
    var tripleZero48 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr50").src = tripleZero48;
};

function squareToSzzZValue50(){
    valueQaSave = 'zSqrArtSpecz50';
    var tripleZero49 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr51").src = tripleZero49;
};

function squareToSzzZValue51(){
    valueQaSave = 'zSqrArtSpecz51';
    var tripleZero50 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr52").src = tripleZero50;
};

function squareToSzzZValue52(){
    valueQaSave = 'zSqrArtSpecz52';
    var tripleZero51 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr53").src = tripleZero51;
};

function squareToSzzZValue53(){
    valueQaSave = 'zSqrArtSpecz53';
    var tripleZero52 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr54").src = tripleZero52;
};

function squareToSzzZValue54(){
    valueQaSave = 'zSqrArtSpecz54';
    var tripleZero53 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr55").src = tripleZero53;
};

function squareToSzzZValue55(){
    valueQaSave = 'zSqrArtSpecz55';
    var tripleZero54 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr56").src = tripleZero54;
};

function squareToSzzZValue56(){
    valueQaSave = 'zSqrArtSpecz56';
    var tripleZero55 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr57").src = tripleZero55;
};

function squareToSzzZValue57(){
    valueQaSave = 'zSqrArtSpecz57';
    var tripleZero56 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr58").src = tripleZero56;
};

function squareToSzzZValue58(){
    valueQaSave = 'zSqrArtSpecz58';
    var tripleZero57 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr59").src = tripleZero57;
};

function squareToSzzZValue59(){
    valueQaSave = 'zSqrArtSpecz59';
    var tripleZero58 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr60").src = tripleZero58;
};

function squareToSzzZValue60(){
    valueQaSave = 'zSqrArtSpecz60';
    var tripleZero59 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr61").src = tripleZero59;
};

function squareToSzzZValue61(){
    valueQaSave = 'zSqrArtSpecz61';
    var tripleZero60 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr62").src = tripleZero60;
};

function squareToSzzZValue62(){
    valueQaSave = 'zSqrArtSpecz62';
    var tripleZero61 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr63").src = tripleZero61;
};

function squareToSzzZValue63(){
    valueQaSave = 'zSqrArtSpecz63';
    var tripleZero62 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr64").src = tripleZero62;
};

function squareToSzzZValue64(){
    valueQaSave = 'zSqrArtSpecz64';
    var tripleZero63 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr65").src = tripleZero63;
};

function squareToSzzZValue65(){
    valueQaSave = 'zSqrArtSpecz65';
    var tripleZero64 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr66").src = tripleZero64;
};

function squareToSzzZValue66(){
    valueQaSave = 'zSqrArtSpecz66';
    var tripleZero65 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr67").src = tripleZero65;
};

function squareToSzzZValue67(){
    valueQaSave = 'zSqrArtSpecz67';
    var tripleZero66 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr68").src = tripleZero66;
};

function squareToSzzZValue68(){
    valueQaSave = 'zSqrArtSpecz68';
    var tripleZero67 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr69").src = tripleZero67;
};

function squareToSzzZValue69(){
    valueQaSave = 'zSqrArtSpecz69';
    var tripleZero68 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr70").src = tripleZero68;
};

function squareToSzzZValue70(){
    valueQaSave = 'zSqrArtSpecz70';
    var tripleZero69 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr71").src = tripleZero69;
};

function squareToSzzZValue71(){
    valueQaSave = 'zSqrArtSpecz71';
    var tripleZero70 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr72").src = tripleZero70;
};

function squareToSzzZValue72(){
    valueQaSave = 'zSqrArtSpecz72';
    var tripleZero71 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr73").src = tripleZero71;
};

function squareToSzzZValue73(){
    valueQaSave = 'zSqrArtSpecz73';
    var tripleZero72 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr74").src = tripleZero72;
};

function squareToSzzZValue74(){
    valueQaSave = 'zSqrArtSpecz74';
    var tripleZero73 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr75").src = tripleZero73;
};

function squareToSzzZValue75(){
    valueQaSave = 'zSqrArtSpecz75';
    var tripleZero74 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr76").src = tripleZero74;
};

function squareToSzzZValue76(){
    valueQaSave = 'zSqrArtSpecz76';
    var tripleZero75 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr77").src = tripleZero75;
};

function squareToSzzZValue77(){
    valueQaSave = 'zSqrArtSpecz77';
    var tripleZero76 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr78").src = tripleZero76;
};

function squareToSzzZValue78(){
    valueQaSave = 'zSqrArtSpecz78';
    var tripleZero77 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr79").src = tripleZero77;
};

function squareToSzzZValue79(){
    valueQaSave = 'zSqrArtSpecz79';
    var tripleZero78 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr80").src = tripleZero78;
};

function squareToSzzZValue80(){
    valueQaSave = 'zSqrArtSpecz80';
    var tripleZero79 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr81").src = tripleZero79;
};

function squareToSzzZValue81(){
    valueQaSave = 'zSqrArtSpecz81';
    var tripleZero80 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr82").src = tripleZero80;
};

function squareToSzzZValue82(){
    valueQaSave = 'zSqrArtSpecz82';
    var tripleZero81 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr83").src = tripleZero81;
};

function squareToSzzZValue83(){
    valueQaSave = 'zSqrArtSpecz83';
    var tripleZero82 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr84").src = tripleZero82;
};

function squareToSzzZValue84(){
    valueQaSave = 'zSqrArtSpecz84';
    var tripleZero83 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr85").src = tripleZero83;
};

function squareToSzzZValue85(){
    valueQaSave = 'zSqrArtSpecz85';
    var tripleZero84 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr86").src = tripleZero84;
};

function squareToSzzZValue86(){
    valueQaSave = 'zSqrArtSpecz86';
    var tripleZero85 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr87").src = tripleZero85;
};

function squareToSzzZValue87(){
    valueQaSave = 'zSqrArtSpecz87';
    var tripleZero86 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr88").src = tripleZero86;
};

function squareToSzzZValue88(){
    valueQaSave = 'zSqrArtSpecz88';
    var tripleZero87 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr89").src = tripleZero87;
};

function squareToSzzZValue89(){
    valueQaSave = 'zSqrArtSpecz89';
    var tripleZero88 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr90").src = tripleZero88;
};

function squareToSzzZValue90(){
    valueQaSave = 'zSqrArtSpecz90';
    var tripleZero89 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr91").src = tripleZero89;
};

function squareToSzzZValue91(){
    valueQaSave = 'zSqrArtSpecz91';
    var tripleZero90 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr92").src = tripleZero90;
};

function squareToSzzZValue92(){
    valueQaSave = 'zSqrArtSpecz92';
    var tripleZero91 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr93").src = tripleZero91;
};

function squareToSzzZValue93(){
    valueQaSave = 'zSqrArtSpecz93';
    var tripleZero92 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr94").src = tripleZero92;
};

function squareToSzzZValue94(){
    valueQaSave = 'zSqrArtSpecz94';
    var tripleZero93 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr95").src = tripleZero93;
};

function squareToSzzZValue95(){
    valueQaSave = 'zSqrArtSpecz95';
    var tripleZero94 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr96").src = tripleZero94;
};

function squareToSzzZValue96(){
    valueQaSave = 'zSqrArtSpecz96';
    var tripleZero95 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr97").src = tripleZero95;
};

function squareToSzzZValue97(){
    valueQaSave = 'zSqrArtSpecz97';
    var tripleZero96 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr98").src = tripleZero96;
};

function squareToSzzZValue98(){
    valueQaSave = 'zSqrArtSpecz98';
    var tripleZero97 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr99").src = tripleZero97;
};

function squareToSzzZValue99(){
    valueQaSave = 'zSqrArtSpecz99';
    var tripleZero98 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr100").src = tripleZero98;
};

function squareToSzzZValue100(){
    valueQaSave = 'zSqrArtSpecz100';
    var tripleZero99 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr101").src = tripleZero99;
};

function squareToSzzZValue101(){
    valueQaSave = 'zSqrArtSpecz101';
    var tripleZero100 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr102").src = tripleZero100;
};

function squareToSzzZValue102(){
    valueQaSave = 'zSqrArtSpecz102';
    var tripleZero101 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr103").src = tripleZero101;
};

function squareToSzzZValue103(){
    valueQaSave = 'zSqrArtSpecz103';
    var tripleZero102 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr104").src = tripleZero102;
};

function squareToSzzZValue104(){
    valueQaSave = 'zSqrArtSpecz104';
    var tripleZero103 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr105").src = tripleZero103;
};

function squareToSzzZValue105(){
    valueQaSave = 'zSqrArtSpecz105';
    var tripleZero104 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr106").src = tripleZero104;
};

function squareToSzzZValue106(){
    valueQaSave = 'zSqrArtSpecz106';
    var tripleZero105 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr107").src = tripleZero105;
};

function squareToSzzZValue107(){
    valueQaSave = 'zSqrArtSpecz107';
    var tripleZero106 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr108").src = tripleZero106;
};

function squareToSzzZValue108(){
    valueQaSave = 'zSqrArtSpecz108';
    var tripleZero107 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr109").src = tripleZero107;
};

function squareToSzzZValue109(){
    valueQaSave = 'zSqrArtSpecz109';
    var tripleZero108 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr110").src = tripleZero108;
};

function squareToSzzZValue110(){
    valueQaSave = 'zSqrArtSpecz110';
    var tripleZero109 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr111").src = tripleZero109;
};

function squareToSzzZValue111(){
    valueQaSave = 'zSqrArtSpecz111';
    var tripleZero110 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr112").src = tripleZero110;
};

function squareToSzzZValue112(){
    valueQaSave = 'zSqrArtSpecz112';
    var tripleZero111 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr113").src = tripleZero111;
};

function squareToSzzZValue113(){
    valueQaSave = 'zSqrArtSpecz113';
    var tripleZero112 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr114").src = tripleZero112;
};

function squareToSzzZValue114(){
    valueQaSave = 'zSqrArtSpecz114';
    var tripleZero113 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr115").src = tripleZero113;
};

function squareToSzzZValue115(){
    valueQaSave = 'zSqrArtSpecz115';
    var tripleZero114 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr116").src = tripleZero114;
};

function squareToSzzZValue116(){
    valueQaSave = 'zSqrArtSpecz116';
    var tripleZero115 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr117").src = tripleZero115;
};

function squareToSzzZValue117(){
    valueQaSave = 'zSqrArtSpecz117';
    var tripleZero116 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr118").src = tripleZero116;
};

function squareToSzzZValue118(){
    valueQaSave = 'zSqrArtSpecz118';
    var tripleZero117 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr119").src = tripleZero117;
};

function squareToSzzZValue119(){
    valueQaSave = 'zSqrArtSpecz119';
    var tripleZero118 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr120").src = tripleZero118;
};

function squareToSzzZValue120(){
    valueQaSave = 'zSqrArtSpecz120';
    var tripleZero119 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr121").src = tripleZero119;
};

function squareToSzzZValue121(){
    valueQaSave = 'zSqrArtSpecz121';
    var tripleZero120 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr122").src = tripleZero120;
};

function squareToSzzZValue122(){
    valueQaSave = 'zSqrArtSpecz122';
    var tripleZero121 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr123").src = tripleZero121;
};

function squareToSzzZValue123(){
    valueQaSave = 'zSqrArtSpecz123';
    var tripleZero122 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr124").src = tripleZero122;
};

function squareToSzzZValue124(){
    valueQaSave = 'zSqrArtSpecz124';
    var tripleZero123 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr125").src = tripleZero123;
};

function squareToSzzZValue125(){
    valueQaSave = 'zSqrArtSpecz125';
    var tripleZero124 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr126").src = tripleZero124;
};

function squareToSzzZValue126(){
    valueQaSave = 'zSqrArtSpecz126';
    var tripleZero125 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr127").src = tripleZero125;
};

function squareToSzzZValue127(){
    valueQaSave = 'zSqrArtSpecz127';
    var tripleZero126 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr128").src = tripleZero126;
};

function squareToSzzZValue128(){
    valueQaSave = 'zSqrArtSpecz128';
    var tripleZero127 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr129").src = tripleZero127;
};

function squareToSzzZValue129(){
    valueQaSave = 'zSqrArtSpecz129';
    var tripleZero128 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr130").src = tripleZero128;
};

function squareToSzzZValue130(){
    valueQaSave = 'zSqrArtSpecz130';
    var tripleZero129 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr131").src = tripleZero129;
};

function squareToSzzZValue131(){
    valueQaSave = 'zSqrArtSpecz131';
    var tripleZero130 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr132").src = tripleZero130;
};

function squareToSzzZValue132(){
    valueQaSave = 'zSqrArtSpecz132';
    var tripleZero131 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr133").src = tripleZero131;
};

function squareToSzzZValue133(){
    valueQaSave = 'zSqrArtSpecz133';
    var tripleZero132 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr134").src = tripleZero132;
};

function squareToSzzZValue134(){
    valueQaSave = 'zSqrArtSpecz134';
    var tripleZero133 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr135").src = tripleZero133;
};

function squareToSzzZValue135(){
    valueQaSave = 'zSqrArtSpecz135';
    var tripleZero134 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr136").src = tripleZero134;
};

function squareToSzzZValue136(){
    valueQaSave = 'zSqrArtSpecz136';
    var tripleZero135 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr137").src = tripleZero135;
};

function squareToSzzZValue137(){
    valueQaSave = 'zSqrArtSpecz137';
    var tripleZero136 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr138").src = tripleZero136;
};

function squareToSzzZValue138(){
    valueQaSave = 'zSqrArtSpecz138';
    var tripleZero137 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr139").src = tripleZero137;
};

function squareToSzzZValue139(){
    valueQaSave = 'zSqrArtSpecz139';
    var tripleZero138 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr140").src = tripleZero138;
};

function squareToSzzZValue140(){
    valueQaSave = 'zSqrArtSpecz140';
    var tripleZero139 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr141").src = tripleZero139;
};

function squareToSzzZValue141(){
    valueQaSave = 'zSqrArtSpecz141';
    var tripleZero140 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr142").src = tripleZero140;
};

function squareToSzzZValue142(){
    valueQaSave = 'zSqrArtSpecz142';
    var tripleZero141 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr143").src = tripleZero141;
};

function squareToSzzZValue143(){
    valueQaSave = 'zSqrArtSpecz143';
    var tripleZero142 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr144").src = tripleZero142;
};

function squareToSzzZValue144(){
    valueQaSave = 'zSqrArtSpecz144';
    var tripleZero143 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr145").src = tripleZero143;
};

function squareToSzzZValue145(){
    valueQaSave = 'zSqrArtSpecz145';
    var tripleZero144 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr146").src = tripleZero144;
};

function squareToSzzZValue146(){
    valueQaSave = 'zSqrArtSpecz146';
    var tripleZero145 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr147").src = tripleZero145;
};

function squareToSzzZValue147(){
    valueQaSave = 'zSqrArtSpecz147';
    var tripleZero146 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr148").src = tripleZero146;
};

function squareToSzzZValue148(){
    valueQaSave = 'zSqrArtSpecz148';
    var tripleZero147 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr149").src = tripleZero147;
};

function squareToSzzZValue149(){
    valueQaSave = 'zSqrArtSpecz149';
    var tripleZero148 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr150").src = tripleZero148;
};

function squareToSzzZValue150(){
    valueQaSave = 'zSqrArtSpecz150';
    var tripleZero149 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr151").src = tripleZero149;
};

function squareToSzzZValue151(){
    valueQaSave = 'zSqrArtSpecz151';
    var tripleZero150 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr152").src = tripleZero150;
};

function squareToSzzZValue152(){
    valueQaSave = 'zSqrArtSpecz152';
    var tripleZero151 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr153").src = tripleZero151;
};

function squareToSzzZValue153(){
    valueQaSave = 'zSqrArtSpecz153';
    var tripleZero152 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr154").src = tripleZero152;
};

function squareToSzzZValue154(){
    valueQaSave = 'zSqrArtSpecz154';
    var tripleZero153 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr155").src = tripleZero153;
};

function squareToSzzZValue155(){
    valueQaSave = 'zSqrArtSpecz155';
    var tripleZero154 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr156").src = tripleZero154;
};

function squareToSzzZValue156(){
    valueQaSave = 'zSqrArtSpecz156';
    var tripleZero155 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr157").src = tripleZero155;
};

function squareToSzzZValue157(){
    valueQaSave = 'zSqrArtSpecz157';
    var tripleZero156 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr158").src = tripleZero156;
};

function squareToSzzZValue158(){
    valueQaSave = 'zSqrArtSpecz158';
    var tripleZero157 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr159").src = tripleZero157;
};

function squareToSzzZValue159(){
    valueQaSave = 'zSqrArtSpecz159';
    var tripleZero158 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr160").src = tripleZero158;
};

function squareToSzzZValue160(){
    valueQaSave = 'zSqrArtSpecz160';
    var tripleZero159 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr161").src = tripleZero159;
};

function squareToSzzZValue161(){
    valueQaSave = 'zSqrArtSpecz161';
    var tripleZero160 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr162").src = tripleZero160;
};

function squareToSzzZValue162(){
    valueQaSave = 'zSqrArtSpecz162';
    var tripleZero161 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr163").src = tripleZero161;
};

function squareToSzzZValue163(){
    valueQaSave = 'zSqrArtSpecz163';
    var tripleZero162 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr164").src = tripleZero162;
};

function squareToSzzZValue164(){
    valueQaSave = 'zSqrArtSpecz164';
    var tripleZero163 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr165").src = tripleZero163;
};

function squareToSzzZValue165(){
    valueQaSave = 'zSqrArtSpecz165';
    var tripleZero164 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr166").src = tripleZero164;
};

function squareToSzzZValue166(){
    valueQaSave = 'zSqrArtSpecz166';
    var tripleZero165 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr167").src = tripleZero165;
};

function squareToSzzZValue167(){
    valueQaSave = 'zSqrArtSpecz167';
    var tripleZero166 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr168").src = tripleZero166;
};

function squareToSzzZValue168(){
    valueQaSave = 'zSqrArtSpecz168';
    var tripleZero167 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr169").src = tripleZero167;
};

function squareToSzzZValue169(){
    valueQaSave = 'zSqrArtSpecz169';
    var tripleZero168 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr170").src = tripleZero168;
};

function squareToSzzZValue170(){
    valueQaSave = 'zSqrArtSpecz170';
    var tripleZero169 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr171").src = tripleZero169;
};

function squareToSzzZValue171(){
    valueQaSave = 'zSqrArtSpecz171';
    var tripleZero170 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr172").src = tripleZero170;
};

function squareToSzzZValue172(){
    valueQaSave = 'zSqrArtSpecz172';
    var tripleZero171 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr173").src = tripleZero171;
};

function squareToSzzZValue173(){
    valueQaSave = 'zSqrArtSpecz173';
    var tripleZero172 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr174").src = tripleZero172;
};

function squareToSzzZValue174(){
    valueQaSave = 'zSqrArtSpecz174';
    var tripleZero173 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr175").src = tripleZero173;
};

function squareToSzzZValue175(){
    valueQaSave = 'zSqrArtSpecz175';
    var tripleZero174 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr176").src = tripleZero174;
};

function squareToSzzZValue176(){
    valueQaSave = 'zSqrArtSpecz176';
    var tripleZero175 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr177").src = tripleZero175;
};

function squareToSzzZValue177(){
    valueQaSave = 'zSqrArtSpecz177';
    var tripleZero176 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr178").src = tripleZero176;
};

function squareToSzzZValue178(){
    valueQaSave = 'zSqrArtSpecz178';
    var tripleZero177 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr179").src = tripleZero177;
};

function squareToSzzZValue179(){
    valueQaSave = 'zSqrArtSpecz179';
    var tripleZero178 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr180").src = tripleZero178;
};

function squareToSzzZValue180(){
    valueQaSave = 'zSqrArtSpecz180';
    var tripleZero179 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr181").src = tripleZero179;
};

function squareToSzzZValue181(){
    valueQaSave = 'zSqrArtSpecz181';
    var tripleZero180 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr182").src = tripleZero180;
};

function squareToSzzZValue182(){
    valueQaSave = 'zSqrArtSpecz182';
    var tripleZero181 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr183").src = tripleZero181;
};

function squareToSzzZValue183(){
    valueQaSave = 'zSqrArtSpecz183';
    var tripleZero182 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr184").src = tripleZero182;
};

function squareToSzzZValue184(){
    valueQaSave = 'zSqrArtSpecz184';
    var tripleZero183 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr185").src = tripleZero183;
};

function squareToSzzZValue185(){
    valueQaSave = 'zSqrArtSpecz185';
    var tripleZero184 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr186").src = tripleZero184;
};

function squareToSzzZValue186(){
    valueQaSave = 'zSqrArtSpecz186';
    var tripleZero185 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr187").src = tripleZero185;
};

function squareToSzzZValue187(){
    valueQaSave = 'zSqrArtSpecz187';
    var tripleZero186 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr188").src = tripleZero186;
};

function squareToSzzZValue188(){
    valueQaSave = 'zSqrArtSpecz188';
    var tripleZero187 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr189").src = tripleZero187;
};

function squareToSzzZValue189(){
    valueQaSave = 'zSqrArtSpecz189';
    var tripleZero188 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr190").src = tripleZero188;
};

function squareToSzzZValue190(){
    valueQaSave = 'zSqrArtSpecz190';
    var tripleZero189 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr191").src = tripleZero189;
};

function squareToSzzZValue191(){
    valueQaSave = 'zSqrArtSpecz191';
    var tripleZero190 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr192").src = tripleZero190;
};

function squareToSzzZValue192(){
    valueQaSave = 'zSqrArtSpecz192';
    var tripleZero191 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr193").src = tripleZero191;
};

function squareToSzzZValue193(){
    valueQaSave = 'zSqrArtSpecz193';
    var tripleZero192 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr194").src = tripleZero192;
};

function squareToSzzZValue194(){
    valueQaSave = 'zSqrArtSpecz194';
    var tripleZero193 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr195").src = tripleZero193;
};

function squareToSzzZValue195(){
    valueQaSave = 'zSqrArtSpecz195';
    var tripleZero194 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr196").src = tripleZero194;
};

function squareToSzzZValue196(){
    valueQaSave = 'zSqrArtSpecz196';
    var tripleZero195 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr197").src = tripleZero195;
};

function squareToSzzZValue197(){
    valueQaSave = 'zSqrArtSpecz197';
    var tripleZero196 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr198").src = tripleZero196;
};

function squareToSzzZValue198(){
    valueQaSave = 'zSqrArtSpecz198';
    var tripleZero197 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr199").src = tripleZero197;
};

function squareToSzzZValue199(){
    valueQaSave = 'zSqrArtSpecz199';
    var tripleZero198 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr200").src = tripleZero198;
};

function squareToSzzZValue200(){
    valueQaSave = 'zSqrArtSpecz200';
    var tripleZero199 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr201").src = tripleZero199;
};

function squareToSzzZValue201(){
    valueQaSave = 'zSqrArtSpecz201';
    var tripleZero200 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr202").src = tripleZero200;
};

function squareToSzzZValue202(){
    valueQaSave = 'zSqrArtSpecz202';
    var tripleZero201 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr203").src = tripleZero201;
};

function squareToSzzZValue203(){
    valueQaSave = 'zSqrArtSpecz203';
    var tripleZero202 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr204").src = tripleZero202;
};

function squareToSzzZValue204(){
    valueQaSave = 'zSqrArtSpecz204';
    var tripleZero203 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr205").src = tripleZero203;
};

function squareToSzzZValue205(){
    valueQaSave = 'zSqrArtSpecz205';
    var tripleZero204 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr206").src = tripleZero204;
};

function squareToSzzZValue206(){
    valueQaSave = 'zSqrArtSpecz206';
    var tripleZero205 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr207").src = tripleZero205;
};

function squareToSzzZValue207(){
    valueQaSave = 'zSqrArtSpecz207';
    var tripleZero206 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr208").src = tripleZero206;
};

function squareToSzzZValue208(){
    valueQaSave = 'zSqrArtSpecz208';
    var tripleZero207 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr209").src = tripleZero207;
};

function squareToSzzZValue209(){
    valueQaSave = 'zSqrArtSpecz209';
    var tripleZero208 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr210").src = tripleZero208;
};

function squareToSzzZValue210(){
    valueQaSave = 'zSqrArtSpecz210';
    var tripleZero209 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr211").src = tripleZero209;
};

function squareToSzzZValue211(){
    valueQaSave = 'zSqrArtSpecz211';
    var tripleZero210 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr212").src = tripleZero210;
};

function squareToSzzZValue212(){
    valueQaSave = 'zSqrArtSpecz212';
    var tripleZero211 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr213").src = tripleZero211;
};

function squareToSzzZValue213(){
    valueQaSave = 'zSqrArtSpecz213';
    var tripleZero212 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr214").src = tripleZero212;
};

function squareToSzzZValue214(){
    valueQaSave = 'zSqrArtSpecz214';
    var tripleZero213 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr215").src = tripleZero213;
};

function squareToSzzZValue215(){
    valueQaSave = 'zSqrArtSpecz215';
    var tripleZero214 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr216").src = tripleZero214;
};

function squareToSzzZValue216(){
    valueQaSave = 'zSqrArtSpecz216';
    var tripleZero215 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr217").src = tripleZero215;
};

function squareToSzzZValue217(){
    valueQaSave = 'zSqrArtSpecz217';
    var tripleZero216 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr218").src = tripleZero216;
};

function squareToSzzZValue218(){
    valueQaSave = 'zSqrArtSpecz218';
    var tripleZero217 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr219").src = tripleZero217;
};

function squareToSzzZValue219(){
    valueQaSave = 'zSqrArtSpecz219';
    var tripleZero218 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr220").src = tripleZero218;
};

function squareToSzzZValue220(){
    valueQaSave = 'zSqrArtSpecz220';
    var tripleZero219 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr221").src = tripleZero219;
};

function squareToSzzZValue221(){
    valueQaSave = 'zSqrArtSpecz221';
    var tripleZero220 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr222").src = tripleZero220;
};

function squareToSzzZValue222(){
    valueQaSave = 'zSqrArtSpecz222';
    var tripleZero221 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr223").src = tripleZero221;
};

function squareToSzzZValue223(){
    valueQaSave = 'zSqrArtSpecz223';
    var tripleZero222 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr224").src = tripleZero222;
};

function squareToSzzZValue224(){
    valueQaSave = 'zSqrArtSpecz224';
    var tripleZero223 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr225").src = tripleZero223;
};

function squareToSzzZValue225(){
    valueQaSave = 'zSqrArtSpecz225';
    var tripleZero224 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr226").src = tripleZero224;
};

function squareToSzzZValue226(){
    valueQaSave = 'zSqrArtSpecz226';
    var tripleZero225 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr227").src = tripleZero225;
};

function squareToSzzZValue227(){
    valueQaSave = 'zSqrArtSpecz227';
    var tripleZero226 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr228").src = tripleZero226;
};

function squareToSzzZValue228(){
    valueQaSave = 'zSqrArtSpecz228';
    var tripleZero227 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr229").src = tripleZero227;
};

function squareToSzzZValue229(){
    valueQaSave = 'zSqrArtSpecz229';
    var tripleZero228 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr230").src = tripleZero228;
};

function squareToSzzZValue230(){
    valueQaSave = 'zSqrArtSpecz230';
    var tripleZero229 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr231").src = tripleZero229;
};

function squareToSzzZValue231(){
    valueQaSave = 'zSqrArtSpecz231';
    var tripleZero230 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr232").src = tripleZero230;
};

function squareToSzzZValue232(){
    valueQaSave = 'zSqrArtSpecz232';
    var tripleZero231 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr233").src = tripleZero231;
};

function squareToSzzZValue233(){
    valueQaSave = 'zSqrArtSpecz233';
    var tripleZero232 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr234").src = tripleZero232;
};

function squareToSzzZValue234(){
    valueQaSave = 'zSqrArtSpecz234';
    var tripleZero233 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr235").src = tripleZero233;
};

function squareToSzzZValue235(){
    valueQaSave = 'zSqrArtSpecz235';
    var tripleZero234 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr236").src = tripleZero234;
};

function squareToSzzZValue236(){
    valueQaSave = 'zSqrArtSpecz236';
    var tripleZero235 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr237").src = tripleZero235;
};

function squareToSzzZValue237(){
    valueQaSave = 'zSqrArtSpecz237';
    var tripleZero236 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr238").src = tripleZero236;
};

function squareToSzzZValue238(){
    valueQaSave = 'zSqrArtSpecz238';
    var tripleZero237 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr239").src = tripleZero237;
};

function squareToSzzZValue239(){
    valueQaSave = 'zSqrArtSpecz239';
    var tripleZero238 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr240").src = tripleZero238;
};

function squareToSzzZValue240(){
    valueQaSave = 'zSqrArtSpecz240';
    var tripleZero239 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr241").src = tripleZero239;
};

function squareToSzzZValue241(){
    valueQaSave = 'zSqrArtSpecz241';
    var tripleZero240 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr242").src = tripleZero240;
};

function squareToSzzZValue242(){
    valueQaSave = 'zSqrArtSpecz242';
    var tripleZero241 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr243").src = tripleZero241;
};

function squareToSzzZValue243(){
    valueQaSave = 'zSqrArtSpecz243';
    var tripleZero242 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr244").src = tripleZero242;
};

function squareToSzzZValue244(){
    valueQaSave = 'zSqrArtSpecz244';
    var tripleZero243 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr245").src = tripleZero243;
};

function squareToSzzZValue245(){
    valueQaSave = 'zSqrArtSpecz245';
    var tripleZero244 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr246").src = tripleZero244;
};

function squareToSzzZValue246(){
    valueQaSave = 'zSqrArtSpecz246';
    var tripleZero245 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr247").src = tripleZero245;
};

function squareToSzzZValue247(){
    valueQaSave = 'zSqrArtSpecz247';
    var tripleZero246 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr248").src = tripleZero246;
};

function squareToSzzZValue248(){
    valueQaSave = 'zSqrArtSpecz248';
    var tripleZero247 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr249").src = tripleZero247;
};

function squareToSzzZValue249(){
    valueQaSave = 'zSqrArtSpecz249';
    var tripleZero248 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr250").src = tripleZero248;
};

function squareToSzzZValue250(){
    valueQaSave = 'zSqrArtSpecz250';
    var tripleZero249 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr251").src = tripleZero249;
};

function squareToSzzZValue251(){
    valueQaSave = 'zSqrArtSpecz251';
    var tripleZero250 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr252").src = tripleZero250;
};

function squareToSzzZValue252(){
    valueQaSave = 'zSqrArtSpecz252';
    var tripleZero251 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr253").src = tripleZero251;
};

function squareToSzzZValue253(){
    valueQaSave = 'zSqrArtSpecz253';
    var tripleZero252 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr254").src = tripleZero252;
};

function squareToSzzZValue254(){
    valueQaSave = 'zSqrArtSpecz254';
    var tripleZero253 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr255").src = tripleZero253;
};

function squareToSzzZValue255(){
    valueQaSave = 'zSqrArtSpecz255';
    var tripleZero254 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr256").src = tripleZero254;
};

function squareToSzzZValue256(){
    valueQaSave = 'zSqrArtSpecz256';
    var tripleZero255 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr257").src = tripleZero255;
};

function squareToSzzZValue257(){
    valueQaSave = 'zSqrArtSpecz257';
    var tripleZero256 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr258").src = tripleZero256;
};

function squareToSzzZValue258(){
    valueQaSave = 'zSqrArtSpecz258';
    var tripleZero257 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr259").src = tripleZero257;
};

function squareToSzzZValue259(){
    valueQaSave = 'zSqrArtSpecz259';
    var tripleZero258 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr260").src = tripleZero258;
};

function squareToSzzZValue260(){
    valueQaSave = 'zSqrArtSpecz260';
    var tripleZero259 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr261").src = tripleZero259;
};

function squareToSzzZValue261(){
    valueQaSave = 'zSqrArtSpecz261';
    var tripleZero260 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr262").src = tripleZero260;
};

function squareToSzzZValue262(){
    valueQaSave = 'zSqrArtSpecz262';
    var tripleZero261 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr263").src = tripleZero261;
};

function squareToSzzZValue263(){
    valueQaSave = 'zSqrArtSpecz263';
    var tripleZero262 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr264").src = tripleZero262;
};

function squareToSzzZValue264(){
    valueQaSave = 'zSqrArtSpecz264';
    var tripleZero263 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr265").src = tripleZero263;
};

function squareToSzzZValue265(){
    valueQaSave = 'zSqrArtSpecz265';
    var tripleZero264 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr266").src = tripleZero264;
};

function squareToSzzZValue266(){
    valueQaSave = 'zSqrArtSpecz266';
    var tripleZero265 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr267").src = tripleZero265;
};

function squareToSzzZValue267(){
    valueQaSave = 'zSqrArtSpecz267';
    var tripleZero266 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr268").src = tripleZero266;
};

function squareToSzzZValue268(){
    valueQaSave = 'zSqrArtSpecz268';
    var tripleZero267 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr269").src = tripleZero267;
};

function squareToSzzZValue269(){
    valueQaSave = 'zSqrArtSpecz269';
    var tripleZero268 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr270").src = tripleZero268;
};

function squareToSzzZValue270(){
    valueQaSave = 'zSqrArtSpecz270';
    var tripleZero269 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr271").src = tripleZero269;
};

function squareToSzzZValue271(){
    valueQaSave = 'zSqrArtSpecz271';
    var tripleZero270 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr272").src = tripleZero270;
};

function squareToSzzZValue272(){
    valueQaSave = 'zSqrArtSpecz272';
    var tripleZero271 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr273").src = tripleZero271;
};

function squareToSzzZValue273(){
    valueQaSave = 'zSqrArtSpecz273';
    var tripleZero272 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr274").src = tripleZero272;
};

function squareToSzzZValue274(){
    valueQaSave = 'zSqrArtSpecz274';
    var tripleZero273 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr275").src = tripleZero273;
};

function squareToSzzZValue275(){
    valueQaSave = 'zSqrArtSpecz275';
    var tripleZero274 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr276").src = tripleZero274;
};

function squareToSzzZValue276(){
    valueQaSave = 'zSqrArtSpecz276';
    var tripleZero275 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr277").src = tripleZero275;
};

function squareToSzzZValue277(){
    valueQaSave = 'zSqrArtSpecz277';
    var tripleZero276 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr278").src = tripleZero276;
};

function squareToSzzZValue278(){
    valueQaSave = 'zSqrArtSpecz278';
    var tripleZero277 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr279").src = tripleZero277;
};

function squareToSzzZValue279(){
    valueQaSave = 'zSqrArtSpecz279';
    var tripleZero278 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr280").src = tripleZero278;
};

function squareToSzzZValue280(){
    valueQaSave = 'zSqrArtSpecz280';
    var tripleZero279 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr281").src = tripleZero279;
};

function squareToSzzZValue281(){
    valueQaSave = 'zSqrArtSpecz281';
    var tripleZero280 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr282").src = tripleZero280;
};

function squareToSzzZValue282(){
    valueQaSave = 'zSqrArtSpecz282';
    var tripleZero281 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr283").src = tripleZero281;
};

function squareToSzzZValue283(){
    valueQaSave = 'zSqrArtSpecz283';
    var tripleZero282 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr284").src = tripleZero282;
};

function squareToSzzZValue284(){
    valueQaSave = 'zSqrArtSpecz284';
    var tripleZero283 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr285").src = tripleZero283;
};

function squareToSzzZValue285(){
    valueQaSave = 'zSqrArtSpecz285';
    var tripleZero284 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr286").src = tripleZero284;
};

function squareToSzzZValue286(){
    valueQaSave = 'zSqrArtSpecz286';
    var tripleZero285 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr287").src = tripleZero285;
};

function squareToSzzZValue287(){
    valueQaSave = 'zSqrArtSpecz287';
    var tripleZero286 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr288").src = tripleZero286;
};

function squareToSzzZValue288(){
    valueQaSave = 'zSqrArtSpecz288';
    var tripleZero287 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr289").src = tripleZero287;
};

function squareToSzzZValue289(){
    valueQaSave = 'zSqrArtSpecz289';
    var tripleZero288 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr290").src = tripleZero288;
};

function squareToSzzZValue290(){
    valueQaSave = 'zSqrArtSpecz290';
    var tripleZero289 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr291").src = tripleZero289;
};

function squareToSzzZValue291(){
    valueQaSave = 'zSqrArtSpecz291';
    var tripleZero290 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr292").src = tripleZero290;
};

function squareToSzzZValue292(){
    valueQaSave = 'zSqrArtSpecz292';
    var tripleZero291 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr293").src = tripleZero291;
};

function squareToSzzZValue293(){
    valueQaSave = 'zSqrArtSpecz293';
    var tripleZero292 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr294").src = tripleZero292;
};

function squareToSzzZValue294(){
    valueQaSave = 'zSqrArtSpecz294';
    var tripleZero293 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr295").src = tripleZero293;
};

function squareToSzzZValue295(){
    valueQaSave = 'zSqrArtSpecz295';
    var tripleZero294 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr296").src = tripleZero294;
};

function squareToSzzZValue296(){
    valueQaSave = 'zSqrArtSpecz296';
    var tripleZero295 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr297").src = tripleZero295;
};

function squareToSzzZValue297(){
    valueQaSave = 'zSqrArtSpecz297';
    var tripleZero296 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr298").src = tripleZero296;
};

function squareToSzzZValue298(){
    valueQaSave = 'zSqrArtSpecz298';
    var tripleZero297 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr299").src = tripleZero297;
};

function squareToSzzZValue299(){
    valueQaSave = 'zSqrArtSpecz299';
    var tripleZero298 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr300").src = tripleZero298;
};

function squareToSzzZValue300(){
    valueQaSave = 'zSqrArtSpecz300';
    var tripleZero299 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr301").src = tripleZero299;
};

function squareToSzzZValue301(){
    valueQaSave = 'zSqrArtSpecz301';
    var tripleZero300 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr302").src = tripleZero300;
};

function squareToSzzZValue302(){
    valueQaSave = 'zSqrArtSpecz302';
    var tripleZero301 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr303").src = tripleZero301;
};

function squareToSzzZValue303(){
    valueQaSave = 'zSqrArtSpecz303';
    var tripleZero302 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr304").src = tripleZero302;
};

function squareToSzzZValue304(){
    valueQaSave = 'zSqrArtSpecz304';
    var tripleZero303 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr305").src = tripleZero303;
};

function squareToSzzZValue305(){
    valueQaSave = 'zSqrArtSpecz305';
    var tripleZero304 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr306").src = tripleZero304;
};

function squareToSzzZValue306(){
    valueQaSave = 'zSqrArtSpecz306';
    var tripleZero305 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr307").src = tripleZero305;
};

function squareToSzzZValue307(){
    valueQaSave = 'zSqrArtSpecz307';
    var tripleZero306 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr308").src = tripleZero306;
};

function squareToSzzZValue308(){
    valueQaSave = 'zSqrArtSpecz308';
    var tripleZero307 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr309").src = tripleZero307;
};

function squareToSzzZValue309(){
    valueQaSave = 'zSqrArtSpecz309';
    var tripleZero308 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr310").src = tripleZero308;
};

function squareToSzzZValue310(){
    valueQaSave = 'zSqrArtSpecz310';
    var tripleZero309 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr311").src = tripleZero309;
};

function squareToSzzZValue311(){
    valueQaSave = 'zSqrArtSpecz311';
    var tripleZero310 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr312").src = tripleZero310;
};

function squareToSzzZValue312(){
    valueQaSave = 'zSqrArtSpecz312';
    var tripleZero311 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr313").src = tripleZero311;
};

function squareToSzzZValue313(){
    valueQaSave = 'zSqrArtSpecz313';
    var tripleZero312 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr314").src = tripleZero312;
};

function squareToSzzZValue314(){
    valueQaSave = 'zSqrArtSpecz314';
    var tripleZero313 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr315").src = tripleZero313;
};

function squareToSzzZValue315(){
    valueQaSave = 'zSqrArtSpecz315';
    var tripleZero314 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr316").src = tripleZero314;
};

function squareToSzzZValue316(){
    valueQaSave = 'zSqrArtSpecz316';
    var tripleZero315 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr317").src = tripleZero315;
};

function squareToSzzZValue317(){
    valueQaSave = 'zSqrArtSpecz317';
    var tripleZero316 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr318").src = tripleZero316;
};

function squareToSzzZValue318(){
    valueQaSave = 'zSqrArtSpecz318';
    var tripleZero317 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr319").src = tripleZero317;
};

function squareToSzzZValue319(){
    valueQaSave = 'zSqrArtSpecz319';
    var tripleZero318 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr320").src = tripleZero318;
};

function squareToSzzZValue320(){
    valueQaSave = 'zSqrArtSpecz320';
    var tripleZero319 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr321").src = tripleZero319;
};

function squareToSzzZValue321(){
    valueQaSave = 'zSqrArtSpecz321';
    var tripleZero320 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr322").src = tripleZero320;
};

function squareToSzzZValue322(){
    valueQaSave = 'zSqrArtSpecz322';
    var tripleZero321 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr323").src = tripleZero321;
};

function squareToSzzZValue323(){
    valueQaSave = 'zSqrArtSpecz323';
    var tripleZero322 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr324").src = tripleZero322;
};

function squareToSzzZValue324(){
    valueQaSave = 'zSqrArtSpecz324';
    var tripleZero323 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr325").src = tripleZero323;
};

function squareToSzzZValue325(){
    valueQaSave = 'zSqrArtSpecz325';
    var tripleZero324 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr326").src = tripleZero324;
};

function squareToSzzZValue326(){
    valueQaSave = 'zSqrArtSpecz326';
    var tripleZero325 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr327").src = tripleZero325;
};

function squareToSzzZValue327(){
    valueQaSave = 'zSqrArtSpecz327';
    var tripleZero326 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr328").src = tripleZero326;
};

function squareToSzzZValue328(){
    valueQaSave = 'zSqrArtSpecz328';
    var tripleZero327 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr329").src = tripleZero327;
};

function squareToSzzZValue329(){
    valueQaSave = 'zSqrArtSpecz329';
    var tripleZero328 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr330").src = tripleZero328;
};

function squareToSzzZValue330(){
    valueQaSave = 'zSqrArtSpecz330';
    var tripleZero329 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr331").src = tripleZero329;
};

function squareToSzzZValue331(){
    valueQaSave = 'zSqrArtSpecz331';
    var tripleZero330 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr332").src = tripleZero330;
};

function squareToSzzZValue332(){
    valueQaSave = 'zSqrArtSpecz332';
    var tripleZero331 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr333").src = tripleZero331;
};

function squareToSzzZValue333(){
    valueQaSave = 'zSqrArtSpecz333';
    var tripleZero332 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr334").src = tripleZero332;
};

function squareToSzzZValue334(){
    valueQaSave = 'zSqrArtSpecz334';
    var tripleZero333 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr335").src = tripleZero333;
};

function squareToSzzZValue335(){
    valueQaSave = 'zSqrArtSpecz335';
    var tripleZero334 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr336").src = tripleZero334;
};

function squareToSzzZValue336(){
    valueQaSave = 'zSqrArtSpecz336';
    var tripleZero335 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr337").src = tripleZero335;
};

function squareToSzzZValue337(){
    valueQaSave = 'zSqrArtSpecz337';
    var tripleZero336 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr338").src = tripleZero336;
};

function squareToSzzZValue338(){
    valueQaSave = 'zSqrArtSpecz338';
    var tripleZero337 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr339").src = tripleZero337;
};

function squareToSzzZValue339(){
    valueQaSave = 'zSqrArtSpecz339';
    var tripleZero338 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr340").src = tripleZero338;
};

function squareToSzzZValue340(){
    valueQaSave = 'zSqrArtSpecz340';
    var tripleZero339 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr341").src = tripleZero339;
};

function squareToSzzZValue341(){
    valueQaSave = 'zSqrArtSpecz341';
    var tripleZero340 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr342").src = tripleZero340;
};

function squareToSzzZValue342(){
    valueQaSave = 'zSqrArtSpecz342';
    var tripleZero341 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr343").src = tripleZero341;
};

function squareToSzzZValue343(){
    valueQaSave = 'zSqrArtSpecz343';
    var tripleZero342 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr344").src = tripleZero342;
};

function squareToSzzZValue344(){
    valueQaSave = 'zSqrArtSpecz344';
    var tripleZero343 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr345").src = tripleZero343;
};

function squareToSzzZValue345(){
    valueQaSave = 'zSqrArtSpecz345';
    var tripleZero344 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr346").src = tripleZero344;
};

function squareToSzzZValue346(){
    valueQaSave = 'zSqrArtSpecz346';
    var tripleZero345 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr347").src = tripleZero345;
};

function squareToSzzZValue347(){
    valueQaSave = 'zSqrArtSpecz347';
    var tripleZero346 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr348").src = tripleZero346;
};

function squareToSzzZValue348(){
    valueQaSave = 'zSqrArtSpecz348';
    var tripleZero347 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr349").src = tripleZero347;
};

function squareToSzzZValue349(){
    valueQaSave = 'zSqrArtSpecz349';
    var tripleZero348 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr350").src = tripleZero348;
};

function squareToSzzZValue350(){
    valueQaSave = 'zSqrArtSpecz350';
    var tripleZero349 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr351").src = tripleZero349;
};

function squareToSzzZValue351(){
    valueQaSave = 'zSqrArtSpecz351';
    var tripleZero350 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr352").src = tripleZero350;
};

function squareToSzzZValue352(){
    valueQaSave = 'zSqrArtSpecz352';
    var tripleZero351 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr353").src = tripleZero351;
};

function squareToSzzZValue353(){
    valueQaSave = 'zSqrArtSpecz353';
    var tripleZero352 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr354").src = tripleZero352;
};

function squareToSzzZValue354(){
    valueQaSave = 'zSqrArtSpecz354';
    var tripleZero353 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr355").src = tripleZero353;
};

function squareToSzzZValue355(){
    valueQaSave = 'zSqrArtSpecz355';
    var tripleZero354 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr356").src = tripleZero354;
};

function squareToSzzZValue356(){
    valueQaSave = 'zSqrArtSpecz356';
    var tripleZero355 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr357").src = tripleZero355;
};

function squareToSzzZValue357(){
    valueQaSave = 'zSqrArtSpecz357';
    var tripleZero356 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr358").src = tripleZero356;
};

function squareToSzzZValue358(){
    valueQaSave = 'zSqrArtSpecz358';
    var tripleZero357 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr359").src = tripleZero357;
};

function squareToSzzZValue359(){
    valueQaSave = 'zSqrArtSpecz359';
    var tripleZero358 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr360").src = tripleZero358;
};

function squareToSzzZValue360(){
    valueQaSave = 'zSqrArtSpecz360';
    var tripleZero359 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr361").src = tripleZero359;
};

function squareToSzzZValue361(){
    valueQaSave = 'zSqrArtSpecz361';
    var tripleZero360 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr362").src = tripleZero360;
};

function squareToSzzZValue362(){
    valueQaSave = 'zSqrArtSpecz362';
    var tripleZero361 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr363").src = tripleZero361;
};

function squareToSzzZValue363(){
    valueQaSave = 'zSqrArtSpecz363';
    var tripleZero362 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr364").src = tripleZero362;
};

function squareToSzzZValue364(){
    valueQaSave = 'zSqrArtSpecz364';
    var tripleZero363 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr365").src = tripleZero363;
};

function squareToSzzZValue365(){
    valueQaSave = 'zSqrArtSpecz365';
    var tripleZero364 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr366").src = tripleZero364;
};

function squareToSzzZValue366(){
    valueQaSave = 'zSqrArtSpecz366';
    var tripleZero365 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr367").src = tripleZero365;
};

function squareToSzzZValue367(){
    valueQaSave = 'zSqrArtSpecz367';
    var tripleZero366 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr368").src = tripleZero366;
};

function squareToSzzZValue368(){
    valueQaSave = 'zSqrArtSpecz368';
    var tripleZero367 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr369").src = tripleZero367;
};

function squareToSzzZValue369(){
    valueQaSave = 'zSqrArtSpecz369';
    var tripleZero368 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr370").src = tripleZero368;
};

function squareToSzzZValue370(){
    valueQaSave = 'zSqrArtSpecz370';
    var tripleZero369 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr371").src = tripleZero369;
};

function squareToSzzZValue371(){
    valueQaSave = 'zSqrArtSpecz371';
    var tripleZero370 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr372").src = tripleZero370;
};

function squareToSzzZValue372(){
    valueQaSave = 'zSqrArtSpecz372';
    var tripleZero371 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr373").src = tripleZero371;
};

function squareToSzzZValue373(){
    valueQaSave = 'zSqrArtSpecz373';
    var tripleZero372 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr374").src = tripleZero372;
};

function squareToSzzZValue374(){
    valueQaSave = 'zSqrArtSpecz374';
    var tripleZero373 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr375").src = tripleZero373;
};

function squareToSzzZValue375(){
    valueQaSave = 'zSqrArtSpecz375';
    var tripleZero374 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr376").src = tripleZero374;
};

function squareToSzzZValue376(){
    valueQaSave = 'zSqrArtSpecz376';
    var tripleZero375 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr377").src = tripleZero375;
};

function squareToSzzZValue377(){
    valueQaSave = 'zSqrArtSpecz377';
    var tripleZero376 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr378").src = tripleZero376;
};

function squareToSzzZValue378(){
    valueQaSave = 'zSqrArtSpecz378';
    var tripleZero377 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr379").src = tripleZero377;
};

function squareToSzzZValue379(){
    valueQaSave = 'zSqrArtSpecz379';
    var tripleZero378 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr380").src = tripleZero378;
};

function squareToSzzZValue380(){
    valueQaSave = 'zSqrArtSpecz380';
    var tripleZero379 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr381").src = tripleZero379;
};

function squareToSzzZValue381(){
    valueQaSave = 'zSqrArtSpecz381';
    var tripleZero380 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr382").src = tripleZero380;
};

function squareToSzzZValue382(){
    valueQaSave = 'zSqrArtSpecz382';
    var tripleZero381 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr383").src = tripleZero381;
};

function squareToSzzZValue383(){
    valueQaSave = 'zSqrArtSpecz383';
    var tripleZero382 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr384").src = tripleZero382;
};

function squareToSzzZValue384(){
    valueQaSave = 'zSqrArtSpecz384';
    var tripleZero383 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr385").src = tripleZero383;
};

function squareToSzzZValue385(){
    valueQaSave = 'zSqrArtSpecz385';
    var tripleZero384 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr386").src = tripleZero384;
};

function squareToSzzZValue386(){
    valueQaSave = 'zSqrArtSpecz386';
    var tripleZero385 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr387").src = tripleZero385;
};

function squareToSzzZValue387(){
    valueQaSave = 'zSqrArtSpecz387';
    var tripleZero386 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr388").src = tripleZero386;
};

function squareToSzzZValue388(){
    valueQaSave = 'zSqrArtSpecz388';
    var tripleZero387 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr389").src = tripleZero387;
};

function squareToSzzZValue389(){
    valueQaSave = 'zSqrArtSpecz389';
    var tripleZero388 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr390").src = tripleZero388;
};

function squareToSzzZValue390(){
    valueQaSave = 'zSqrArtSpecz390';
    var tripleZero389 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr391").src = tripleZero389;
};

function squareToSzzZValue391(){
    valueQaSave = 'zSqrArtSpecz391';
    var tripleZero390 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr392").src = tripleZero390;
};

function squareToSzzZValue392(){
    valueQaSave = 'zSqrArtSpecz392';
    var tripleZero391 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr393").src = tripleZero391;
};

function squareToSzzZValue393(){
    valueQaSave = 'zSqrArtSpecz393';
    var tripleZero392 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr394").src = tripleZero392;
};

function squareToSzzZValue394(){
    valueQaSave = 'zSqrArtSpecz394';
    var tripleZero393 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr395").src = tripleZero393;
};

function squareToSzzZValue395(){
    valueQaSave = 'zSqrArtSpecz395';
    var tripleZero394 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr396").src = tripleZero394;
};

function squareToSzzZValue396(){
    valueQaSave = 'zSqrArtSpecz396';
    var tripleZero395 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr397").src = tripleZero395;
};

function squareToSzzZValue397(){
    valueQaSave = 'zSqrArtSpecz397';
    var tripleZero396 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr398").src = tripleZero396;
};

function squareToSzzZValue398(){
    valueQaSave = 'zSqrArtSpecz398';
    var tripleZero397 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr399").src = tripleZero397;
};

function squareToSzzZValue399(){
    valueQaSave = 'zSqrArtSpecz399';
    var tripleZero398 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr400").src = tripleZero398;
};

function squareToSzzZValue400(){
    valueQaSave = 'zSqrArtSpecz400';
    var tripleZero399 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr401").src = tripleZero399;
};

function squareToSzzZValue401(){
    valueQaSave = 'zSqrArtSpecz401';
    var tripleZero400 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr402").src = tripleZero400;
};

function squareToSzzZValue402(){
    valueQaSave = 'zSqrArtSpecz402';
    var tripleZero401 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr403").src = tripleZero401;
};

function squareToSzzZValue403(){
    valueQaSave = 'zSqrArtSpecz403';
    var tripleZero402 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr404").src = tripleZero402;
};

function squareToSzzZValue404(){
    valueQaSave = 'zSqrArtSpecz404';
    var tripleZero403 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr405").src = tripleZero403;
};

function squareToSzzZValue405(){
    valueQaSave = 'zSqrArtSpecz405';
    var tripleZero404 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr406").src = tripleZero404;
};

function squareToSzzZValue406(){
    valueQaSave = 'zSqrArtSpecz406';
    var tripleZero405 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr407").src = tripleZero405;
};

function squareToSzzZValue407(){
    valueQaSave = 'zSqrArtSpecz407';
    var tripleZero406 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr408").src = tripleZero406;
};

function squareToSzzZValue408(){
    valueQaSave = 'zSqrArtSpecz408';
    var tripleZero407 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr409").src = tripleZero407;
};

function squareToSzzZValue409(){
    valueQaSave = 'zSqrArtSpecz409';
    var tripleZero408 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr410").src = tripleZero408;
};

function squareToSzzZValue410(){
    valueQaSave = 'zSqrArtSpecz410';
    var tripleZero409 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr411").src = tripleZero409;
};

function squareToSzzZValue411(){
    valueQaSave = 'zSqrArtSpecz411';
    var tripleZero410 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr412").src = tripleZero410;
};

function squareToSzzZValue412(){
    valueQaSave = 'zSqrArtSpecz412';
    var tripleZero411 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr413").src = tripleZero411;
};

function squareToSzzZValue413(){
    valueQaSave = 'zSqrArtSpecz413';
    var tripleZero412 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr414").src = tripleZero412;
};

function squareToSzzZValue414(){
    valueQaSave = 'zSqrArtSpecz414';
    var tripleZero413 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr415").src = tripleZero413;
};

function squareToSzzZValue415(){
    valueQaSave = 'zSqrArtSpecz415';
    var tripleZero414 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr416").src = tripleZero414;
};

function squareToSzzZValue416(){
    valueQaSave = 'zSqrArtSpecz416';
    var tripleZero415 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr417").src = tripleZero415;
};

function squareToSzzZValue417(){
    valueQaSave = 'zSqrArtSpecz417';
    var tripleZero416 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr418").src = tripleZero416;
};

function squareToSzzZValue418(){
    valueQaSave = 'zSqrArtSpecz418';
    var tripleZero417 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr419").src = tripleZero417;
};

function squareToSzzZValue419(){
    valueQaSave = 'zSqrArtSpecz419';
    var tripleZero418 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr420").src = tripleZero418;
};

function squareToSzzZValue420(){
    valueQaSave = 'zSqrArtSpecz420';
    var tripleZero419 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr421").src = tripleZero419;
};

function squareToSzzZValue421(){
    valueQaSave = 'zSqrArtSpecz421';
    var tripleZero420 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr422").src = tripleZero420;
};

function squareToSzzZValue422(){
    valueQaSave = 'zSqrArtSpecz422';
    var tripleZero421 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr423").src = tripleZero421;
};

function squareToSzzZValue423(){
    valueQaSave = 'zSqrArtSpecz423';
    var tripleZero422 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr424").src = tripleZero422;
};

function squareToSzzZValue424(){
    valueQaSave = 'zSqrArtSpecz424';
    var tripleZero423 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr425").src = tripleZero423;
};

function squareToSzzZValue425(){
    valueQaSave = 'zSqrArtSpecz425';
    var tripleZero424 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr426").src = tripleZero424;
};

function squareToSzzZValue426(){
    valueQaSave = 'zSqrArtSpecz426';
    var tripleZero425 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr427").src = tripleZero425;
};

function squareToSzzZValue427(){
    valueQaSave = 'zSqrArtSpecz427';
    var tripleZero426 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr428").src = tripleZero426;
};

function squareToSzzZValue428(){
    valueQaSave = 'zSqrArtSpecz428';
    var tripleZero427 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr429").src = tripleZero427;
};

function squareToSzzZValue429(){
    valueQaSave = 'zSqrArtSpecz429';
    var tripleZero428 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr430").src = tripleZero428;
};

function squareToSzzZValue430(){
    valueQaSave = 'zSqrArtSpecz430';
    var tripleZero429 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr431").src = tripleZero429;
};

function squareToSzzZValue431(){
    valueQaSave = 'zSqrArtSpecz431';
    var tripleZero430 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr432").src = tripleZero430;
};

function squareToSzzZValue432(){
    valueQaSave = 'zSqrArtSpecz432';
    var tripleZero431 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr433").src = tripleZero431;
};

function squareToSzzZValue433(){
    valueQaSave = 'zSqrArtSpecz433';
    var tripleZero432 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr434").src = tripleZero432;
};

function squareToSzzZValue434(){
    valueQaSave = 'zSqrArtSpecz434';
    var tripleZero433 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr435").src = tripleZero433;
};

function squareToSzzZValue435(){
    valueQaSave = 'zSqrArtSpecz435';
    var tripleZero434 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr436").src = tripleZero434;
};

function squareToSzzZValue436(){
    valueQaSave = 'zSqrArtSpecz436';
    var tripleZero435 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr437").src = tripleZero435;
};

function squareToSzzZValue437(){
    valueQaSave = 'zSqrArtSpecz437';
    var tripleZero436 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr438").src = tripleZero436;
};

function squareToSzzZValue438(){
    valueQaSave = 'zSqrArtSpecz438';
    var tripleZero437 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr439").src = tripleZero437;
};

function squareToSzzZValue439(){
    valueQaSave = 'zSqrArtSpecz439';
    var tripleZero438 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr440").src = tripleZero438;
};

function squareToSzzZValue440(){
    valueQaSave = 'zSqrArtSpecz440';
    var tripleZero439 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr441").src = tripleZero439;
};

function squareToSzzZValue441(){
    valueQaSave = 'zSqrArtSpecz441';
    var tripleZero440 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr442").src = tripleZero440;
};

function squareToSzzZValue442(){
    valueQaSave = 'zSqrArtSpecz442';
    var tripleZero441 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr443").src = tripleZero441;
};

function squareToSzzZValue443(){
    valueQaSave = 'zSqrArtSpecz443';
    var tripleZero442 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr444").src = tripleZero442;
};

function squareToSzzZValue444(){
    valueQaSave = 'zSqrArtSpecz444';
    var tripleZero443 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr445").src = tripleZero443;
};

function squareToSzzZValue445(){
    valueQaSave = 'zSqrArtSpecz445';
    var tripleZero444 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr446").src = tripleZero444;
};

function squareToSzzZValue446(){
    valueQaSave = 'zSqrArtSpecz446';
    var tripleZero445 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr447").src = tripleZero445;
};

function squareToSzzZValue447(){
    valueQaSave = 'zSqrArtSpecz447';
    var tripleZero446 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr448").src = tripleZero446;
};

function squareToSzzZValue448(){
    valueQaSave = 'zSqrArtSpecz448';
    var tripleZero447 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr449").src = tripleZero447;
};

function squareToSzzZValue449(){
    valueQaSave = 'zSqrArtSpecz449';
    var tripleZero448 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr450").src = tripleZero448;
};

function squareToSzzZValue450(){
    valueQaSave = 'zSqrArtSpecz450';
    var tripleZero449 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr451").src = tripleZero449;
};

function squareToSzzZValue451(){
    valueQaSave = 'zSqrArtSpecz451';
    var tripleZero450 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr452").src = tripleZero450;
};

function squareToSzzZValue452(){
    valueQaSave = 'zSqrArtSpecz452';
    var tripleZero451 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr453").src = tripleZero451;
};

function squareToSzzZValue453(){
    valueQaSave = 'zSqrArtSpecz453';
    var tripleZero452 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr454").src = tripleZero452;
};

function squareToSzzZValue454(){
    valueQaSave = 'zSqrArtSpecz454';
    var tripleZero453 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr455").src = tripleZero453;
};

function squareToSzzZValue455(){
    valueQaSave = 'zSqrArtSpecz455';
    var tripleZero454 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr456").src = tripleZero454;
};

function squareToSzzZValue456(){
    valueQaSave = 'zSqrArtSpecz456';
    var tripleZero455 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr457").src = tripleZero455;
};

function squareToSzzZValue457(){
    valueQaSave = 'zSqrArtSpecz457';
    var tripleZero456 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr458").src = tripleZero456;
};

function squareToSzzZValue458(){
    valueQaSave = 'zSqrArtSpecz458';
    var tripleZero457 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr459").src = tripleZero457;
};

function squareToSzzZValue459(){
    valueQaSave = 'zSqrArtSpecz459';
    var tripleZero458 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr460").src = tripleZero458;
};

function squareToSzzZValue460(){
    valueQaSave = 'zSqrArtSpecz460';
    var tripleZero459 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr461").src = tripleZero459;
};

function squareToSzzZValue461(){
    valueQaSave = 'zSqrArtSpecz461';
    var tripleZero460 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr462").src = tripleZero460;
};

function squareToSzzZValue462(){
    valueQaSave = 'zSqrArtSpecz462';
    var tripleZero461 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr463").src = tripleZero461;
};

function squareToSzzZValue463(){
    valueQaSave = 'zSqrArtSpecz463';
    var tripleZero462 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr464").src = tripleZero462;
};

function squareToSzzZValue464(){
    valueQaSave = 'zSqrArtSpecz464';
    var tripleZero463 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr465").src = tripleZero463;
};

function squareToSzzZValue465(){
    valueQaSave = 'zSqrArtSpecz465';
    var tripleZero464 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr466").src = tripleZero464;
};

function squareToSzzZValue466(){
    valueQaSave = 'zSqrArtSpecz466';
    var tripleZero465 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr467").src = tripleZero465;
};

function squareToSzzZValue467(){
    valueQaSave = 'zSqrArtSpecz467';
    var tripleZero466 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr468").src = tripleZero466;
};

function squareToSzzZValue468(){
    valueQaSave = 'zSqrArtSpecz468';
    var tripleZero467 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr469").src = tripleZero467;
};

function squareToSzzZValue469(){
    valueQaSave = 'zSqrArtSpecz469';
    var tripleZero468 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr470").src = tripleZero468;
};

function squareToSzzZValue470(){
    valueQaSave = 'zSqrArtSpecz470';
    var tripleZero469 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr471").src = tripleZero469;
};

function squareToSzzZValue471(){
    valueQaSave = 'zSqrArtSpecz471';
    var tripleZero470 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr472").src = tripleZero470;
};

function squareToSzzZValue472(){
    valueQaSave = 'zSqrArtSpecz472';
    var tripleZero471 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr473").src = tripleZero471;
};

function squareToSzzZValue473(){
    valueQaSave = 'zSqrArtSpecz473';
    var tripleZero472 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr474").src = tripleZero472;
};

function squareToSzzZValue474(){
    valueQaSave = 'zSqrArtSpecz474';
    var tripleZero473 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr475").src = tripleZero473;
};

function squareToSzzZValue475(){
    valueQaSave = 'zSqrArtSpecz475';
    var tripleZero474 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr476").src = tripleZero474;
};

function squareToSzzZValue476(){
    valueQaSave = 'zSqrArtSpecz476';
    var tripleZero475 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr477").src = tripleZero475;
};

function squareToSzzZValue477(){
    valueQaSave = 'zSqrArtSpecz477';
    var tripleZero476 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr478").src = tripleZero476;
};

function squareToSzzZValue478(){
    valueQaSave = 'zSqrArtSpecz478';
    var tripleZero477 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr479").src = tripleZero477;
};

function squareToSzzZValue479(){
    valueQaSave = 'zSqrArtSpecz479';
    var tripleZero478 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr480").src = tripleZero478;
};

function squareToSzzZValue480(){
    valueQaSave = 'zSqrArtSpecz480';
    var tripleZero479 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr481").src = tripleZero479;
};

function squareToSzzZValue481(){
    valueQaSave = 'zSqrArtSpecz481';
    var tripleZero480 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr482").src = tripleZero480;
};

function squareToSzzZValue482(){
    valueQaSave = 'zSqrArtSpecz482';
    var tripleZero481 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr483").src = tripleZero481;
};

function squareToSzzZValue483(){
    valueQaSave = 'zSqrArtSpecz483';
    var tripleZero482 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr484").src = tripleZero482;
};

function squareToSzzZValue484(){
    valueQaSave = 'zSqrArtSpecz484';
    var tripleZero483 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr485").src = tripleZero483;
};

function squareToSzzZValue485(){
    valueQaSave = 'zSqrArtSpecz485';
    var tripleZero484 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr486").src = tripleZero484;
};

function squareToSzzZValue486(){
    valueQaSave = 'zSqrArtSpecz486';
    var tripleZero485 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr487").src = tripleZero485;
};

function squareToSzzZValue487(){
    valueQaSave = 'zSqrArtSpecz487';
    var tripleZero486 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr488").src = tripleZero486;
};

function squareToSzzZValue488(){
    valueQaSave = 'zSqrArtSpecz488';
    var tripleZero487 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr489").src = tripleZero487;
};

function squareToSzzZValue489(){
    valueQaSave = 'zSqrArtSpecz489';
    var tripleZero488 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr490").src = tripleZero488;
};

function squareToSzzZValue490(){
    valueQaSave = 'zSqrArtSpecz490';
    var tripleZero489 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr491").src = tripleZero489;
};

function squareToSzzZValue491(){
    valueQaSave = 'zSqrArtSpecz491';
    var tripleZero490 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr492").src = tripleZero490;
};

function squareToSzzZValue492(){
    valueQaSave = 'zSqrArtSpecz492';
    var tripleZero491 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr493").src = tripleZero491;
};

function squareToSzzZValue493(){
    valueQaSave = 'zSqrArtSpecz493';
    var tripleZero492 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr494").src = tripleZero492;
};

function squareToSzzZValue494(){
    valueQaSave = 'zSqrArtSpecz494';
    var tripleZero493 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr495").src = tripleZero493;
};

function squareToSzzZValue495(){
    valueQaSave = 'zSqrArtSpecz495';
    var tripleZero494 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr496").src = tripleZero494;
};

function squareToSzzZValue496(){
    valueQaSave = 'zSqrArtSpecz496';
    var tripleZero495 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr497").src = tripleZero495;
};

function squareToSzzZValue497(){
    valueQaSave = 'zSqrArtSpecz497';
    var tripleZero496 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr498").src = tripleZero496;
};

function squareToSzzZValue498(){
    valueQaSave = 'zSqrArtSpecz498';
    var tripleZero497 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr499").src = tripleZero497;
};

function squareToSzzZValue499(){
    valueQaSave = 'zSqrArtSpecz499';
    var tripleZero498 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr500").src = tripleZero498;
};

function squareToSzzZValue500(){
    valueQaSave = 'zSqrArtSpecz500';
    var tripleZero499 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr501").src = tripleZero499;
};

function squareToSzzZValue501(){
    valueQaSave = 'zSqrArtSpecz501';
    var tripleZero500 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr502").src = tripleZero500;
};

function squareToSzzZValue502(){
    valueQaSave = 'zSqrArtSpecz502';
    var tripleZero501 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr503").src = tripleZero501;
};

function squareToSzzZValue503(){
    valueQaSave = 'zSqrArtSpecz503';
    var tripleZero502 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr504").src = tripleZero502;
};

function squareToSzzZValue504(){
    valueQaSave = 'zSqrArtSpecz504';
    var tripleZero503 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr505").src = tripleZero503;
};

function squareToSzzZValue505(){
    valueQaSave = 'zSqrArtSpecz505';
    var tripleZero504 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr506").src = tripleZero504;
};

function squareToSzzZValue506(){
    valueQaSave = 'zSqrArtSpecz506';
    var tripleZero505 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr507").src = tripleZero505;
};

function squareToSzzZValue507(){
    valueQaSave = 'zSqrArtSpecz507';
    var tripleZero506 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr508").src = tripleZero506;
};

function squareToSzzZValue508(){
    valueQaSave = 'zSqrArtSpecz508';
    var tripleZero507 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr509").src = tripleZero507;
};

function squareToSzzZValue509(){
    valueQaSave = 'zSqrArtSpecz509';
    var tripleZero508 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr510").src = tripleZero508;
};

function squareToSzzZValue510(){
    valueQaSave = 'zSqrArtSpecz510';
    var tripleZero509 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr511").src = tripleZero509;
};

function squareToSzzZValue511(){
    valueQaSave = 'zSqrArtSpecz511';
    var tripleZero510 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr512").src = tripleZero510;
};

function squareToSzzZValue512(){
    valueQaSave = 'zSqrArtSpecz512';
    var tripleZero511 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr513").src = tripleZero511;
};

function squareToSzzZValue513(){
    valueQaSave = 'zSqrArtSpecz513';
    var tripleZero512 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr514").src = tripleZero512;
};

function squareToSzzZValue514(){
    valueQaSave = 'zSqrArtSpecz514';
    var tripleZero513 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr515").src = tripleZero513;
};

function squareToSzzZValue515(){
    valueQaSave = 'zSqrArtSpecz515';
    var tripleZero514 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr516").src = tripleZero514;
};

function squareToSzzZValue516(){
    valueQaSave = 'zSqrArtSpecz516';
    var tripleZero515 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr517").src = tripleZero515;
};

function squareToSzzZValue517(){
    valueQaSave = 'zSqrArtSpecz517';
    var tripleZero516 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr518").src = tripleZero516;
};

function squareToSzzZValue518(){
    valueQaSave = 'zSqrArtSpecz518';
    var tripleZero517 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr519").src = tripleZero517;
};

function squareToSzzZValue519(){
    valueQaSave = 'zSqrArtSpecz519';
    var tripleZero518 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr520").src = tripleZero518;
};

function squareToSzzZValue520(){
    valueQaSave = 'zSqrArtSpecz520';
    var tripleZero519 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr521").src = tripleZero519;
};

function squareToSzzZValue521(){
    valueQaSave = 'zSqrArtSpecz521';
    var tripleZero520 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr522").src = tripleZero520;
};

function squareToSzzZValue522(){
    valueQaSave = 'zSqrArtSpecz522';
    var tripleZero521 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr523").src = tripleZero521;
};

function squareToSzzZValue523(){
    valueQaSave = 'zSqrArtSpecz523';
    var tripleZero522 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr524").src = tripleZero522;
};

function squareToSzzZValue524(){
    valueQaSave = 'zSqrArtSpecz524';
    var tripleZero523 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr525").src = tripleZero523;
};

function squareToSzzZValue525(){
    valueQaSave = 'zSqrArtSpecz525';
    var tripleZero524 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr526").src = tripleZero524;
};

function squareToSzzZValue526(){
    valueQaSave = 'zSqrArtSpecz526';
    var tripleZero525 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr527").src = tripleZero525;
};

function squareToSzzZValue527(){
    valueQaSave = 'zSqrArtSpecz527';
    var tripleZero526 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr528").src = tripleZero526;
};

function squareToSzzZValue528(){
    valueQaSave = 'zSqrArtSpecz528';
    var tripleZero527 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr529").src = tripleZero527;
};

function squareToSzzZValue529(){
    valueQaSave = 'zSqrArtSpecz529';
    var tripleZero528 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr530").src = tripleZero528;
};

function squareToSzzZValue530(){
    valueQaSave = 'zSqrArtSpecz530';
    var tripleZero529 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr531").src = tripleZero529;
};

function squareToSzzZValue531(){
    valueQaSave = 'zSqrArtSpecz531';
    var tripleZero530 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr532").src = tripleZero530;
};

function squareToSzzZValue532(){
    valueQaSave = 'zSqrArtSpecz532';
    var tripleZero531 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr533").src = tripleZero531;
};

function squareToSzzZValue533(){
    valueQaSave = 'zSqrArtSpecz533';
    var tripleZero532 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr534").src = tripleZero532;
};

function squareToSzzZValue534(){
    valueQaSave = 'zSqrArtSpecz534';
    var tripleZero533 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr535").src = tripleZero533;
};

function squareToSzzZValue535(){
    valueQaSave = 'zSqrArtSpecz535';
    var tripleZero534 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr536").src = tripleZero534;
};

function squareToSzzZValue536(){
    valueQaSave = 'zSqrArtSpecz536';
    var tripleZero535 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr537").src = tripleZero535;
};

function squareToSzzZValue537(){
    valueQaSave = 'zSqrArtSpecz537';
    var tripleZero536 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr538").src = tripleZero536;
};

function squareToSzzZValue538(){
    valueQaSave = 'zSqrArtSpecz538';
    var tripleZero537 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr539").src = tripleZero537;
};

function squareToSzzZValue539(){
    valueQaSave = 'zSqrArtSpecz539';
    var tripleZero538 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr540").src = tripleZero538;
};

function squareToSzzZValue540(){
    valueQaSave = 'zSqrArtSpecz540';
    var tripleZero539 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr541").src = tripleZero539;
};

function squareToSzzZValue541(){
    valueQaSave = 'zSqrArtSpecz541';
    var tripleZero540 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr542").src = tripleZero540;
};

function squareToSzzZValue542(){
    valueQaSave = 'zSqrArtSpecz542';
    var tripleZero541 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr543").src = tripleZero541;
};

function squareToSzzZValue543(){
    valueQaSave = 'zSqrArtSpecz543';
    var tripleZero542 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr544").src = tripleZero542;
};

function squareToSzzZValue544(){
    valueQaSave = 'zSqrArtSpecz544';
    var tripleZero543 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr545").src = tripleZero543;
};

function squareToSzzZValue545(){
    valueQaSave = 'zSqrArtSpecz545';
    var tripleZero544 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr546").src = tripleZero544;
};

function squareToSzzZValue546(){
    valueQaSave = 'zSqrArtSpecz546';
    var tripleZero545 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr547").src = tripleZero545;
};

function squareToSzzZValue547(){
    valueQaSave = 'zSqrArtSpecz547';
    var tripleZero546 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr548").src = tripleZero546;
};

function squareToSzzZValue548(){
    valueQaSave = 'zSqrArtSpecz548';
    var tripleZero547 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr549").src = tripleZero547;
};

function squareToSzzZValue549(){
    valueQaSave = 'zSqrArtSpecz549';
    var tripleZero548 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr550").src = tripleZero548;
};

function squareToSzzZValue550(){
    valueQaSave = 'zSqrArtSpecz550';
    var tripleZero549 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr551").src = tripleZero549;
};

function squareToSzzZValue551(){
    valueQaSave = 'zSqrArtSpecz551';
    var tripleZero550 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr552").src = tripleZero550;
};

function squareToSzzZValue552(){
    valueQaSave = 'zSqrArtSpecz552';
    var tripleZero551 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr553").src = tripleZero551;
};

function squareToSzzZValue553(){
    valueQaSave = 'zSqrArtSpecz553';
    var tripleZero552 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr554").src = tripleZero552;
};

function squareToSzzZValue554(){
    valueQaSave = 'zSqrArtSpecz554';
    var tripleZero553 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr555").src = tripleZero553;
};

function squareToSzzZValue555(){
    valueQaSave = 'zSqrArtSpecz555';
    var tripleZero554 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr556").src = tripleZero554;
};

function squareToSzzZValue556(){
    valueQaSave = 'zSqrArtSpecz556';
    var tripleZero555 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr557").src = tripleZero555;
};

function squareToSzzZValue557(){
    valueQaSave = 'zSqrArtSpecz557';
    var tripleZero556 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr558").src = tripleZero556;
};

function squareToSzzZValue558(){
    valueQaSave = 'zSqrArtSpecz558';
    var tripleZero557 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr559").src = tripleZero557;
};

function squareToSzzZValue559(){
    valueQaSave = 'zSqrArtSpecz559';
    var tripleZero558 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr560").src = tripleZero558;
};

function squareToSzzZValue560(){
    valueQaSave = 'zSqrArtSpecz560';
    var tripleZero559 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr561").src = tripleZero559;
};

function squareToSzzZValue561(){
    valueQaSave = 'zSqrArtSpecz561';
    var tripleZero560 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr562").src = tripleZero560;
};

function squareToSzzZValue562(){
    valueQaSave = 'zSqrArtSpecz562';
    var tripleZero561 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr563").src = tripleZero561;
};

function squareToSzzZValue563(){
    valueQaSave = 'zSqrArtSpecz563';
    var tripleZero562 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr564").src = tripleZero562;
};

function squareToSzzZValue564(){
    valueQaSave = 'zSqrArtSpecz564';
    var tripleZero563 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr565").src = tripleZero563;
};

function squareToSzzZValue565(){
    valueQaSave = 'zSqrArtSpecz565';
    var tripleZero564 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr566").src = tripleZero564;
};

function squareToSzzZValue566(){
    valueQaSave = 'zSqrArtSpecz566';
    var tripleZero565 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr567").src = tripleZero565;
};

function squareToSzzZValue567(){
    valueQaSave = 'zSqrArtSpecz567';
    var tripleZero566 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr568").src = tripleZero566;
};

function squareToSzzZValue568(){
    valueQaSave = 'zSqrArtSpecz568';
    var tripleZero567 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr569").src = tripleZero567;
};

function squareToSzzZValue569(){
    valueQaSave = 'zSqrArtSpecz569';
    var tripleZero568 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr570").src = tripleZero568;
};

function squareToSzzZValue570(){
    valueQaSave = 'zSqrArtSpecz570';
    var tripleZero569 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr571").src = tripleZero569;
};

function squareToSzzZValue571(){
    valueQaSave = 'zSqrArtSpecz571';
    var tripleZero570 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr572").src = tripleZero570;
};

function squareToSzzZValue572(){
    valueQaSave = 'zSqrArtSpecz572';
    var tripleZero571 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr573").src = tripleZero571;
};

function squareToSzzZValue573(){
    valueQaSave = 'zSqrArtSpecz573';
    var tripleZero572 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr574").src = tripleZero572;
};

function squareToSzzZValue574(){
    valueQaSave = 'zSqrArtSpecz574';
    var tripleZero573 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr575").src = tripleZero573;
};

function squareToSzzZValue575(){
    valueQaSave = 'zSqrArtSpecz575';
    var tripleZero574 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr576").src = tripleZero574;
};

function squareToSzzZValue576(){
    valueQaSave = 'zSqrArtSpecz576';
    var tripleZero575 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr577").src = tripleZero575;
};

function squareToSzzZValue577(){
    valueQaSave = 'zSqrArtSpecz577';
    var tripleZero576 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr578").src = tripleZero576;
};

function squareToSzzZValue578(){
    valueQaSave = 'zSqrArtSpecz578';
    var tripleZero577 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr579").src = tripleZero577;
};

function squareToSzzZValue579(){
    valueQaSave = 'zSqrArtSpecz579';
    var tripleZero578 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr580").src = tripleZero578;
};

function squareToSzzZValue580(){
    valueQaSave = 'zSqrArtSpecz580';
    var tripleZero579 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr581").src = tripleZero579;
};

function squareToSzzZValue581(){
    valueQaSave = 'zSqrArtSpecz581';
    var tripleZero580 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr582").src = tripleZero580;
};

function squareToSzzZValue582(){
    valueQaSave = 'zSqrArtSpecz582';
    var tripleZero581 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr583").src = tripleZero581;
};

function squareToSzzZValue583(){
    valueQaSave = 'zSqrArtSpecz583';
    var tripleZero582 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr584").src = tripleZero582;
};

function squareToSzzZValue584(){
    valueQaSave = 'zSqrArtSpecz584';
    var tripleZero583 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr585").src = tripleZero583;
};

function squareToSzzZValue585(){
    valueQaSave = 'zSqrArtSpecz585';
    var tripleZero584 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr586").src = tripleZero584;
};

function squareToSzzZValue586(){
    valueQaSave = 'zSqrArtSpecz586';
    var tripleZero585 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr587").src = tripleZero585;
};

function squareToSzzZValue587(){
    valueQaSave = 'zSqrArtSpecz587';
    var tripleZero586 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr588").src = tripleZero586;
};

function squareToSzzZValue588(){
    valueQaSave = 'zSqrArtSpecz588';
    var tripleZero587 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr589").src = tripleZero587;
};

function squareToSzzZValue589(){
    valueQaSave = 'zSqrArtSpecz589';
    var tripleZero588 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr590").src = tripleZero588;
};

function squareToSzzZValue590(){
    valueQaSave = 'zSqrArtSpecz590';
    var tripleZero589 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr591").src = tripleZero589;
};

function squareToSzzZValue591(){
    valueQaSave = 'zSqrArtSpecz591';
    var tripleZero590 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr592").src = tripleZero590;
};

function squareToSzzZValue592(){
    valueQaSave = 'zSqrArtSpecz592';
    var tripleZero591 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr593").src = tripleZero591;
};

function squareToSzzZValue593(){
    valueQaSave = 'zSqrArtSpecz593';
    var tripleZero592 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr594").src = tripleZero592;
};

function squareToSzzZValue594(){
    valueQaSave = 'zSqrArtSpecz594';
    var tripleZero593 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr595").src = tripleZero593;
};

function squareToSzzZValue595(){
    valueQaSave = 'zSqrArtSpecz595';
    var tripleZero594 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr596").src = tripleZero594;
};

function squareToSzzZValue596(){
    valueQaSave = 'zSqrArtSpecz596';
    var tripleZero595 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr597").src = tripleZero595;
};

function squareToSzzZValue597(){
    valueQaSave = 'zSqrArtSpecz597';
    var tripleZero596 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr598").src = tripleZero596;
};

function squareToSzzZValue598(){
    valueQaSave = 'zSqrArtSpecz598';
    var tripleZero597 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr599").src = tripleZero597;
};

function squareToSzzZValue599(){
    valueQaSave = 'zSqrArtSpecz599';
    var tripleZero598 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr600").src = tripleZero598;
};

function squareToSzzZValue600(){
    valueQaSave = 'zSqrArtSpecz600';
    var tripleZero599 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr601").src = tripleZero599;
};

function squareToSzzZValue601(){
    valueQaSave = 'zSqrArtSpecz601';
    var tripleZero600 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr602").src = tripleZero600;
};

function squareToSzzZValue602(){
    valueQaSave = 'zSqrArtSpecz602';
    var tripleZero601 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr603").src = tripleZero601;
};

function squareToSzzZValue603(){
    valueQaSave = 'zSqrArtSpecz603';
    var tripleZero602 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr604").src = tripleZero602;
};

function squareToSzzZValue604(){
    valueQaSave = 'zSqrArtSpecz604';
    var tripleZero603 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr605").src = tripleZero603;
};

function squareToSzzZValue605(){
    valueQaSave = 'zSqrArtSpecz605';
    var tripleZero604 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr606").src = tripleZero604;
};

function squareToSzzZValue606(){
    valueQaSave = 'zSqrArtSpecz606';
    var tripleZero605 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr607").src = tripleZero605;
};

function squareToSzzZValue607(){
    valueQaSave = 'zSqrArtSpecz607';
    var tripleZero606 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr608").src = tripleZero606;
};

function squareToSzzZValue608(){
    valueQaSave = 'zSqrArtSpecz608';
    var tripleZero607 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr609").src = tripleZero607;
};

function squareToSzzZValue609(){
    valueQaSave = 'zSqrArtSpecz609';
    var tripleZero608 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr610").src = tripleZero608;
};

function squareToSzzZValue610(){
    valueQaSave = 'zSqrArtSpecz610';
    var tripleZero609 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr611").src = tripleZero609;
};

function squareToSzzZValue611(){
    valueQaSave = 'zSqrArtSpecz611';
    var tripleZero610 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr612").src = tripleZero610;
};

function squareToSzzZValue612(){
    valueQaSave = 'zSqrArtSpecz612';
    var tripleZero611 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr613").src = tripleZero611;
};

function squareToSzzZValue613(){
    valueQaSave = 'zSqrArtSpecz613';
    var tripleZero612 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr614").src = tripleZero612;
};

function squareToSzzZValue614(){
    valueQaSave = 'zSqrArtSpecz614';
    var tripleZero613 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr615").src = tripleZero613;
};

function squareToSzzZValue615(){
    valueQaSave = 'zSqrArtSpecz615';
    var tripleZero614 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr616").src = tripleZero614;
};

function squareToSzzZValue616(){
    valueQaSave = 'zSqrArtSpecz616';
    var tripleZero615 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr617").src = tripleZero615;
};

function squareToSzzZValue617(){
    valueQaSave = 'zSqrArtSpecz617';
    var tripleZero616 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr618").src = tripleZero616;
};

function squareToSzzZValue618(){
    valueQaSave = 'zSqrArtSpecz618';
    var tripleZero617 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr619").src = tripleZero617;
};

function squareToSzzZValue619(){
    valueQaSave = 'zSqrArtSpecz619';
    var tripleZero618 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr620").src = tripleZero618;
};

function squareToSzzZValue620(){
    valueQaSave = 'zSqrArtSpecz620';
    var tripleZero619 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr621").src = tripleZero619;
};

function squareToSzzZValue621(){
    valueQaSave = 'zSqrArtSpecz621';
    var tripleZero620 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr622").src = tripleZero620;
};

function squareToSzzZValue622(){
    valueQaSave = 'zSqrArtSpecz622';
    var tripleZero621 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr623").src = tripleZero621;
};

function squareToSzzZValue623(){
    valueQaSave = 'zSqrArtSpecz623';
    var tripleZero622 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr624").src = tripleZero622;
};

function squareToSzzZValue624(){
    valueQaSave = 'zSqrArtSpecz624';
    var tripleZero623 = localStorage.getItem(valueQaSave);
    document.getElementById("imgSqr625").src = tripleZero623;
};

function getBThis(){
    
    squareToSzzZValue0()
    squareToSzzZValue1()
    squareToSzzZValue2()
    squareToSzzZValue3()
    squareToSzzZValue4()
    squareToSzzZValue5()
    squareToSzzZValue6()
    squareToSzzZValue7()
    squareToSzzZValue8()
    squareToSzzZValue9()
    squareToSzzZValue10()
    squareToSzzZValue11()
    squareToSzzZValue12()
    squareToSzzZValue13()
    squareToSzzZValue14()
    squareToSzzZValue15()
    squareToSzzZValue16()
    squareToSzzZValue17()
    squareToSzzZValue18()
    squareToSzzZValue19()
    squareToSzzZValue20()
    squareToSzzZValue21()
    squareToSzzZValue22()
    squareToSzzZValue23()
    squareToSzzZValue24()
    squareToSzzZValue25()
    squareToSzzZValue26()
    squareToSzzZValue27()
    squareToSzzZValue28()
    squareToSzzZValue29()
    squareToSzzZValue30()
    squareToSzzZValue31()
    squareToSzzZValue32()
    squareToSzzZValue33()
    squareToSzzZValue34()
    squareToSzzZValue35()
    squareToSzzZValue36()
    squareToSzzZValue37()
    squareToSzzZValue38()
    squareToSzzZValue39()
    squareToSzzZValue40()
    squareToSzzZValue41()
    squareToSzzZValue42()
    squareToSzzZValue43()
    squareToSzzZValue44()
    squareToSzzZValue45()
    squareToSzzZValue46()
    squareToSzzZValue47()
    squareToSzzZValue48()
    squareToSzzZValue49()
    squareToSzzZValue50()
    squareToSzzZValue51()
    squareToSzzZValue52()
    squareToSzzZValue53()
    squareToSzzZValue54()
    squareToSzzZValue55()
    squareToSzzZValue56()
    squareToSzzZValue57()
    squareToSzzZValue58()
    squareToSzzZValue59()
    squareToSzzZValue60()
    squareToSzzZValue61()
    squareToSzzZValue62()
    squareToSzzZValue63()
    squareToSzzZValue64()
    squareToSzzZValue65()
    squareToSzzZValue66()
    squareToSzzZValue67()
    squareToSzzZValue68()
    squareToSzzZValue69()
    squareToSzzZValue70()
    squareToSzzZValue71()
    squareToSzzZValue72()
    squareToSzzZValue73()
    squareToSzzZValue74()
    squareToSzzZValue75()
    squareToSzzZValue76()
    squareToSzzZValue77()
    squareToSzzZValue78()
    squareToSzzZValue79()
    squareToSzzZValue80()
    squareToSzzZValue81()
    squareToSzzZValue82()
    squareToSzzZValue83()
    squareToSzzZValue84()
    squareToSzzZValue85()
    squareToSzzZValue86()
    squareToSzzZValue87()
    squareToSzzZValue88()
    squareToSzzZValue89()
    squareToSzzZValue90()
    squareToSzzZValue91()
    squareToSzzZValue92()
    squareToSzzZValue93()
    squareToSzzZValue94()
    squareToSzzZValue95()
    squareToSzzZValue96()
    squareToSzzZValue97()
    squareToSzzZValue98()
    squareToSzzZValue99()
    squareToSzzZValue100()
    squareToSzzZValue101()
    squareToSzzZValue102()
    squareToSzzZValue103()
    squareToSzzZValue104()
    squareToSzzZValue105()
    squareToSzzZValue106()
    squareToSzzZValue107()
    squareToSzzZValue108()
    squareToSzzZValue109()
    squareToSzzZValue110()
    squareToSzzZValue111()
    squareToSzzZValue112()
    squareToSzzZValue113()
    squareToSzzZValue114()
    squareToSzzZValue115()
    squareToSzzZValue116()
    squareToSzzZValue117()
    squareToSzzZValue118()
    squareToSzzZValue119()
    squareToSzzZValue120()
    squareToSzzZValue121()
    squareToSzzZValue122()
    squareToSzzZValue123()
    squareToSzzZValue124()
    squareToSzzZValue125()
    squareToSzzZValue126()
    squareToSzzZValue127()
    squareToSzzZValue128()
    squareToSzzZValue129()
    squareToSzzZValue130()
    squareToSzzZValue131()
    squareToSzzZValue132()
    squareToSzzZValue133()
    squareToSzzZValue134()
    squareToSzzZValue135()
    squareToSzzZValue136()
    squareToSzzZValue137()
    squareToSzzZValue138()
    squareToSzzZValue139()
    squareToSzzZValue140()
    squareToSzzZValue141()
    squareToSzzZValue142()
    squareToSzzZValue143()
    squareToSzzZValue144()
    squareToSzzZValue145()
    squareToSzzZValue146()
    squareToSzzZValue147()
    squareToSzzZValue148()
    squareToSzzZValue149()
    squareToSzzZValue150()
    squareToSzzZValue151()
    squareToSzzZValue152()
    squareToSzzZValue153()
    squareToSzzZValue154()
    squareToSzzZValue155()
    squareToSzzZValue156()
    squareToSzzZValue157()
    squareToSzzZValue158()
    squareToSzzZValue159()
    squareToSzzZValue160()
    squareToSzzZValue161()
    squareToSzzZValue162()
    squareToSzzZValue163()
    squareToSzzZValue164()
    squareToSzzZValue165()
    squareToSzzZValue166()
    squareToSzzZValue167()
    squareToSzzZValue168()
    squareToSzzZValue169()
    squareToSzzZValue170()
    squareToSzzZValue171()
    squareToSzzZValue172()
    squareToSzzZValue173()
    squareToSzzZValue174()
    squareToSzzZValue175()
    squareToSzzZValue176()
    squareToSzzZValue177()
    squareToSzzZValue178()
    squareToSzzZValue179()
    squareToSzzZValue180()
    squareToSzzZValue181()
    squareToSzzZValue182()
    squareToSzzZValue183()
    squareToSzzZValue184()
    squareToSzzZValue185()
    squareToSzzZValue186()
    squareToSzzZValue187()
    squareToSzzZValue188()
    squareToSzzZValue189()
    squareToSzzZValue190()
    squareToSzzZValue191()
    squareToSzzZValue192()
    squareToSzzZValue193()
    squareToSzzZValue194()
    squareToSzzZValue195()
    squareToSzzZValue196()
    squareToSzzZValue197()
    squareToSzzZValue198()
    squareToSzzZValue199()
    squareToSzzZValue200()
    squareToSzzZValue201()
    squareToSzzZValue202()
    squareToSzzZValue203()
    squareToSzzZValue204()
    squareToSzzZValue205()
    squareToSzzZValue206()
    squareToSzzZValue207()
    squareToSzzZValue208()
    squareToSzzZValue209()
    squareToSzzZValue210()
    squareToSzzZValue211()
    squareToSzzZValue212()
    squareToSzzZValue213()
    squareToSzzZValue214()
    squareToSzzZValue215()
    squareToSzzZValue216()
    squareToSzzZValue217()
    squareToSzzZValue218()
    squareToSzzZValue219()
    squareToSzzZValue220()
    squareToSzzZValue221()
    squareToSzzZValue222()
    squareToSzzZValue223()
    squareToSzzZValue224()
    squareToSzzZValue225()
    squareToSzzZValue226()
    squareToSzzZValue227()
    squareToSzzZValue228()
    squareToSzzZValue229()
    squareToSzzZValue230()
    squareToSzzZValue231()
    squareToSzzZValue232()
    squareToSzzZValue233()
    squareToSzzZValue234()
    squareToSzzZValue235()
    squareToSzzZValue236()
    squareToSzzZValue237()
    squareToSzzZValue238()
    squareToSzzZValue239()
    squareToSzzZValue240()
    squareToSzzZValue241()
    squareToSzzZValue242()
    squareToSzzZValue243()
    squareToSzzZValue244()
    squareToSzzZValue245()
    squareToSzzZValue246()
    squareToSzzZValue247()
    squareToSzzZValue248()
    squareToSzzZValue249()
    squareToSzzZValue250()
    squareToSzzZValue251()
    squareToSzzZValue252()
    squareToSzzZValue253()
    squareToSzzZValue254()
    squareToSzzZValue255()
    squareToSzzZValue256()
    squareToSzzZValue257()
    squareToSzzZValue258()
    squareToSzzZValue259()
    squareToSzzZValue260()
    squareToSzzZValue261()
    squareToSzzZValue262()
    squareToSzzZValue263()
    squareToSzzZValue264()
    squareToSzzZValue265()
    squareToSzzZValue266()
    squareToSzzZValue267()
    squareToSzzZValue268()
    squareToSzzZValue269()
    squareToSzzZValue270()
    squareToSzzZValue271()
    squareToSzzZValue272()
    squareToSzzZValue273()
    squareToSzzZValue274()
    squareToSzzZValue275()
    squareToSzzZValue276()
    squareToSzzZValue277()
    squareToSzzZValue278()
    squareToSzzZValue279()
    squareToSzzZValue280()
    squareToSzzZValue281()
    squareToSzzZValue282()
    squareToSzzZValue283()
    squareToSzzZValue284()
    squareToSzzZValue285()
    squareToSzzZValue286()
    squareToSzzZValue287()
    squareToSzzZValue288()
    squareToSzzZValue289()
    squareToSzzZValue290()
    squareToSzzZValue291()
    squareToSzzZValue292()
    squareToSzzZValue293()
    squareToSzzZValue294()
    squareToSzzZValue295()
    squareToSzzZValue296()
    squareToSzzZValue297()
    squareToSzzZValue298()
    squareToSzzZValue299()
    squareToSzzZValue300()
    squareToSzzZValue301()
    squareToSzzZValue302()
    squareToSzzZValue303()
    squareToSzzZValue304()
    squareToSzzZValue305()
    squareToSzzZValue306()
    squareToSzzZValue307()
    squareToSzzZValue308()
    squareToSzzZValue309()
    squareToSzzZValue310()
    squareToSzzZValue311()
    squareToSzzZValue312()
    squareToSzzZValue313()
    squareToSzzZValue314()
    squareToSzzZValue315()
    squareToSzzZValue316()
    squareToSzzZValue317()
    squareToSzzZValue318()
    squareToSzzZValue319()
    squareToSzzZValue320()
    squareToSzzZValue321()
    squareToSzzZValue322()
    squareToSzzZValue323()
    squareToSzzZValue324()
    squareToSzzZValue325()
    squareToSzzZValue326()
    squareToSzzZValue327()
    squareToSzzZValue328()
    squareToSzzZValue329()
    squareToSzzZValue330()
    squareToSzzZValue331()
    squareToSzzZValue332()
    squareToSzzZValue333()
    squareToSzzZValue334()
    squareToSzzZValue335()
    squareToSzzZValue336()
    squareToSzzZValue337()
    squareToSzzZValue338()
    squareToSzzZValue339()
    squareToSzzZValue340()
    squareToSzzZValue341()
    squareToSzzZValue342()
    squareToSzzZValue343()
    squareToSzzZValue344()
    squareToSzzZValue345()
    squareToSzzZValue346()
    squareToSzzZValue347()
    squareToSzzZValue348()
    squareToSzzZValue349()
    squareToSzzZValue350()
    squareToSzzZValue351()
    squareToSzzZValue352()
    squareToSzzZValue353()
    squareToSzzZValue354()
    squareToSzzZValue355()
    squareToSzzZValue356()
    squareToSzzZValue357()
    squareToSzzZValue358()
    squareToSzzZValue359()
    squareToSzzZValue360()
    squareToSzzZValue361()
    squareToSzzZValue362()
    squareToSzzZValue363()
    squareToSzzZValue364()
    squareToSzzZValue365()
    squareToSzzZValue366()
    squareToSzzZValue367()
    squareToSzzZValue368()
    squareToSzzZValue369()
    squareToSzzZValue370()
    squareToSzzZValue371()
    squareToSzzZValue372()
    squareToSzzZValue373()
    squareToSzzZValue374()
    squareToSzzZValue375()
    squareToSzzZValue376()
    squareToSzzZValue377()
    squareToSzzZValue378()
    squareToSzzZValue379()
    squareToSzzZValue380()
    squareToSzzZValue381()
    squareToSzzZValue382()
    squareToSzzZValue383()
    squareToSzzZValue384()
    squareToSzzZValue385()
    squareToSzzZValue386()
    squareToSzzZValue387()
    squareToSzzZValue388()
    squareToSzzZValue389()
    squareToSzzZValue390()
    squareToSzzZValue391()
    squareToSzzZValue392()
    squareToSzzZValue393()
    squareToSzzZValue394()
    squareToSzzZValue395()
    squareToSzzZValue396()
    squareToSzzZValue397()
    squareToSzzZValue398()
    squareToSzzZValue399()
    squareToSzzZValue400()
    squareToSzzZValue401()
    squareToSzzZValue402()
    squareToSzzZValue403()
    squareToSzzZValue404()
    squareToSzzZValue405()
    squareToSzzZValue406()
    squareToSzzZValue407()
    squareToSzzZValue408()
    squareToSzzZValue409()
    squareToSzzZValue410()
    squareToSzzZValue411()
    squareToSzzZValue412()
    squareToSzzZValue413()
    squareToSzzZValue414()
    squareToSzzZValue415()
    squareToSzzZValue416()
    squareToSzzZValue417()
    squareToSzzZValue418()
    squareToSzzZValue419()
    squareToSzzZValue420()
    squareToSzzZValue421()
    squareToSzzZValue422()
    squareToSzzZValue423()
    squareToSzzZValue424()
    squareToSzzZValue425()
    squareToSzzZValue426()
    squareToSzzZValue427()
    squareToSzzZValue428()
    squareToSzzZValue429()
    squareToSzzZValue430()
    squareToSzzZValue431()
    squareToSzzZValue432()
    squareToSzzZValue433()
    squareToSzzZValue434()
    squareToSzzZValue435()
    squareToSzzZValue436()
    squareToSzzZValue437()
    squareToSzzZValue438()
    squareToSzzZValue439()
    squareToSzzZValue440()
    squareToSzzZValue441()
    squareToSzzZValue442()
    squareToSzzZValue443()
    squareToSzzZValue444()
    squareToSzzZValue445()
    squareToSzzZValue446()
    squareToSzzZValue447()
    squareToSzzZValue448()
    squareToSzzZValue449()
    squareToSzzZValue450()
    squareToSzzZValue451()
    squareToSzzZValue452()
    squareToSzzZValue453()
    squareToSzzZValue454()
    squareToSzzZValue455()
    squareToSzzZValue456()
    squareToSzzZValue457()
    squareToSzzZValue458()
    squareToSzzZValue459()
    squareToSzzZValue460()
    squareToSzzZValue461()
    squareToSzzZValue462()
    squareToSzzZValue463()
    squareToSzzZValue464()
    squareToSzzZValue465()
    squareToSzzZValue466()
    squareToSzzZValue467()
    squareToSzzZValue468()
    squareToSzzZValue469()
    squareToSzzZValue470()
    squareToSzzZValue471()
    squareToSzzZValue472()
    squareToSzzZValue473()
    squareToSzzZValue474()
    squareToSzzZValue475()
    squareToSzzZValue476()
    squareToSzzZValue477()
    squareToSzzZValue478()
    squareToSzzZValue479()
    squareToSzzZValue480()
    squareToSzzZValue481()
    squareToSzzZValue482()
    squareToSzzZValue483()
    squareToSzzZValue484()
    squareToSzzZValue485()
    squareToSzzZValue486()
    squareToSzzZValue487()
    squareToSzzZValue488()
    squareToSzzZValue489()
    squareToSzzZValue490()
    squareToSzzZValue491()
    squareToSzzZValue492()
    squareToSzzZValue493()
    squareToSzzZValue494()
    squareToSzzZValue495()
    squareToSzzZValue496()
    squareToSzzZValue497()
    squareToSzzZValue498()
    squareToSzzZValue499()
    squareToSzzZValue500()
    squareToSzzZValue501()
    squareToSzzZValue502()
    squareToSzzZValue503()
    squareToSzzZValue504()
    squareToSzzZValue505()
    squareToSzzZValue506()
    squareToSzzZValue507()
    squareToSzzZValue508()
    squareToSzzZValue509()
    squareToSzzZValue510()
    squareToSzzZValue511()
    squareToSzzZValue512()
    squareToSzzZValue513()
    squareToSzzZValue514()
    squareToSzzZValue515()
    squareToSzzZValue516()
    squareToSzzZValue517()
    squareToSzzZValue518()
    squareToSzzZValue519()
    squareToSzzZValue520()
    squareToSzzZValue521()
    squareToSzzZValue522()
    squareToSzzZValue523()
    squareToSzzZValue524()
    squareToSzzZValue525()
    squareToSzzZValue526()
    squareToSzzZValue527()
    squareToSzzZValue528()
    squareToSzzZValue529()
    squareToSzzZValue530()
    squareToSzzZValue531()
    squareToSzzZValue532()
    squareToSzzZValue533()
    squareToSzzZValue534()
    squareToSzzZValue535()
    squareToSzzZValue536()
    squareToSzzZValue537()
    squareToSzzZValue538()
    squareToSzzZValue539()
    squareToSzzZValue540()
    squareToSzzZValue541()
    squareToSzzZValue542()
    squareToSzzZValue543()
    squareToSzzZValue544()
    squareToSzzZValue545()
    squareToSzzZValue546()
    squareToSzzZValue547()
    squareToSzzZValue548()
    squareToSzzZValue549()
    squareToSzzZValue550()
    squareToSzzZValue551()
    squareToSzzZValue552()
    squareToSzzZValue553()
    squareToSzzZValue554()
    squareToSzzZValue555()
    squareToSzzZValue556()
    squareToSzzZValue557()
    squareToSzzZValue558()
    squareToSzzZValue559()
    squareToSzzZValue560()
    squareToSzzZValue561()
    squareToSzzZValue562()
    squareToSzzZValue563()
    squareToSzzZValue564()
    squareToSzzZValue565()
    squareToSzzZValue566()
    squareToSzzZValue567()
    squareToSzzZValue568()
    squareToSzzZValue569()
    squareToSzzZValue570()
    squareToSzzZValue571()
    squareToSzzZValue572()
    squareToSzzZValue573()
    squareToSzzZValue574()
    squareToSzzZValue575()
    squareToSzzZValue576()
    squareToSzzZValue577()
    squareToSzzZValue578()
    squareToSzzZValue579()
    squareToSzzZValue580()
    squareToSzzZValue581()
    squareToSzzZValue582()
    squareToSzzZValue583()
    squareToSzzZValue584()
    squareToSzzZValue585()
    squareToSzzZValue586()
    squareToSzzZValue587()
    squareToSzzZValue588()
    squareToSzzZValue589()
    squareToSzzZValue590()
    squareToSzzZValue591()
    squareToSzzZValue592()
    squareToSzzZValue593()
    squareToSzzZValue594()
    squareToSzzZValue595()
    squareToSzzZValue596()
    squareToSzzZValue597()
    squareToSzzZValue598()
    squareToSzzZValue599()
    squareToSzzZValue600()
    squareToSzzZValue601()
    squareToSzzZValue602()
    squareToSzzZValue603()
    squareToSzzZValue604()
    squareToSzzZValue605()
    squareToSzzZValue606()
    squareToSzzZValue607()
    squareToSzzZValue608()
    squareToSzzZValue609()
    squareToSzzZValue610()
    squareToSzzZValue611()
    squareToSzzZValue612()
    squareToSzzZValue613()
    squareToSzzZValue614()
    squareToSzzZValue615()
    squareToSzzZValue616()
    squareToSzzZValue617()
    squareToSzzZValue618()
    squareToSzzZValue619()
    squareToSzzZValue620()
    squareToSzzZValue621()
    squareToSzzZValue622()
    squareToSzzZValue623()
    squareToSzzZValue624()
    
    alert("Your art has been loaded successfully from your browser's local browser storage.");

};

function squareNull(){
    valueQaSave = 'zSqrArtSpecz0';
    var tripleZeroA = localStorage.getItem(valueQaSave);
    if(tripleZeroA == null){
        setAThis();
    }else{
        getBThis();
    };
};