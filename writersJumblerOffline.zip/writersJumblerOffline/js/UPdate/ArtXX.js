function myImg01(){

var numRand1 = Math.floor((Math.random() * 21) + 1);
var numRand2 = Math.floor((Math.random() * 21) + 1);
var numRand3 = Math.floor((Math.random() * 21) + 1);
var numRand4 = Math.floor((Math.random() * 21) + 1);
var numRand5 = Math.floor((Math.random() * 21) + 1);
var numRand6 = Math.floor((Math.random() * 21) + 1);
var numRand7 = Math.floor((Math.random() * 21) + 1);
var numRand8 = Math.floor((Math.random() * 21) + 1);
var numRand9 = Math.floor((Math.random() * 21) + 1);
var numRand10 = Math.floor((Math.random() * 21) + 1);
var numRand11 = Math.floor((Math.random() * 21) + 1);
var numRand12 = Math.floor((Math.random() * 21) + 1);
var numRand13 = Math.floor((Math.random() * 21) + 1);
var numRand14 = Math.floor((Math.random() * 21) + 1);
var numRand15 = Math.floor((Math.random() * 21) + 1);
var numRand16 = Math.floor((Math.random() * 21) + 1);
var numRand17 = Math.floor((Math.random() * 21) + 1);
var numRand18 = Math.floor((Math.random() * 21) + 1);
var numRand19 = Math.floor((Math.random() * 21) + 1);
var numRand20 = Math.floor((Math.random() * 21) + 1);
var numRand21 = Math.floor((Math.random() * 21) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;
var ig3 = document.getElementById("cz2").src;
var ig4 = document.getElementById("dz2").src;
var ig5 = document.getElementById("ez2").src;
var ig6 = document.getElementById("fz2").src;
var ig7 = document.getElementById("gz2").src;
var ig8 = document.getElementById("hz2").src;
var ig9 = document.getElementById("iz2").src;
var ig10 = document.getElementById("jz2").src;
var ig11 = document.getElementById("kz2").src;
var ig12 = document.getElementById("lz2").src;
var ig13 = document.getElementById("mz2").src;
var ig14 = document.getElementById("nz2").src;
var ig15 = document.getElementById("oz2").src;
var ig16 = document.getElementById("pz2").src;
var ig17 = document.getElementById("qz2").src;
var ig18 = document.getElementById("rz2").src;
var ig19 = document.getElementById("sz2").src;
var ig20 = document.getElementById("tz2").src;
var ig21 = document.getElementById("uz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img id="azz1" src="' + ig1 + '" style="" onclick="dotClick1()" />' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img id="bzz1" src="' + ig2 + '" style="" onclick="dotClick2()"  />' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img id="czz1" src="' + ig3 + '" style="" onclick="dotClick3()"  />' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img id="dzz1" src="' + ig4 + '" style="" onclick="dotClick4()"  />' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img id="ezz1" src="' + ig5 + '" style="" onclick="dotClick5()"  />' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img id="fzz1" src="' + ig6 + '" style="" onclick="dotClick6()"  />' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img id="gzz1" src="' + ig7 + '" style="" onclick="dotClick7()"  />' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img id="hzz1" src="' + ig8 + '" style="" onclick="dotClick8()"  />' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img id="izz1" src="' + ig9 + '" style="" onclick="dotClick9()"  />' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img id="jzz1" src="' + ig10 + '" style="" onclick="dotClick10()"  />' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img id="kzz1" src="' + ig11 + '" style="" onclick="dotClick11()"  />' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img id="lzz1" src="' + ig12 + '" style="" onclick="dotClick12()"  />' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img id="mzz1" src="' + ig13 + '" style="" onclick="dotClick13()"  />' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img id="nzz1" src="' + ig14 + '" style="" onclick="dotClick14()"  />' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img id="ozz1" src="' + ig15 + '" style="" onclick="dotClick15()"  />' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img id="pzz1" src="' + ig16 + '" style="" onclick="dotClick16()"  />' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img id="qzz1" src="' + ig17 + '" style="" onclick="dotClick17()"  />' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img id="rzz1" src="' + ig18 + '" style="" onclick="dotClick18()"  />' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img id="szz1" src="' + ig19 + '" style="" onclick="dotClick19()"  />' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img id="tzz1" src="' + ig20 + '" style="" onclick="dotClick20()"  />' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img id="uzz1" src="' + ig21 + '" style="" onclick="dotClick21()"  />' + '<p style="visibility:hidden;margin:-11px 0px;">';

var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21];
    document.getElementById("ImgL1").innerHTML = getImg1.sort();
}

function allFilters(){
	var xg1 = document.getElementById("azz1");
	var xg2 = document.getElementById("bzz1");
	var xg3 = document.getElementById("czz1");
	var xg4 = document.getElementById("dzz1");
	var xg5 = document.getElementById("ezz1");
	var xg6 = document.getElementById("fzz1");
	var xg7 = document.getElementById("gzz1");
	var xg8 = document.getElementById("hzz1");
	var xg9 = document.getElementById("izz1");
	var xg10 = document.getElementById("jzz1");
	var xg11 = document.getElementById("kzz1");
	var xg12 = document.getElementById("lzz1");
	var xg13 = document.getElementById("mzz1");
	var xg14 = document.getElementById("nzz1");
	var xg15 = document.getElementById("ozz1");
	var xg16 = document.getElementById("pzz1");
	var xg17 = document.getElementById("qzz1");
	var xg18 = document.getElementById("rzz1");
	var xg19 = document.getElementById("szz1");
	var xg20 = document.getElementById("tzz1");
	var xg21 = document.getElementById("uzz1");
	var a = "blur(" + document.getElementById("blur").value + "px)";
	var b = "brightness(" + document.getElementById("brightness").value + "%)";
	var c = "contrast(" + document.getElementById("contrast").value + "%)";
	var d = "grayscale(" + document.getElementById("grayscale").value + "%)";
	var e = "hue-rotate(" + document.getElementById("huerotate").value + "deg)";
	var f = "invert(" + document.getElementById("invert").value + "%)";
	var g = "opacity(" + document.getElementById("opacity").value + "%)";
	var h = "saturate(" + document.getElementById("saturate").value + "%)";
	var i = "sepia(" + document.getElementById("sepia").value + "%)";
	xg1.style.filter = a + b + c + d + e + f + g + h + i;
	xg1.style.WebkitFilter = a + b + c + d + e + f + g + h + i;
	xg2.style.filter = a + b + c + d + e + f + g + h + i;
	xg2.style.WebkitFilter = a + b + c + d + e + f + g + h + i;
	xg3.style.filter = a + b + c + d + e + f + g + h + i;
	xg3.style.WebkitFilter = a + b + c + d + e + f + g + h + i;
	xg4.style.filter = a + b + c + d + e + f + g + h + i;
	xg4.style.WebkitFilter = a + b + c + d + e + f + g + h + i;
	xg5.style.filter = a + b + c + d + e + f + g + h + i;
	xg5.style.WebkitFilter = a + b + c + d + e + f + g + h + i;
	xg6.style.filter = a + b + c + d + e + f + g + h + i;
	xg6.style.WebkitFilter = a + b + c + d + e + f + g + h + i;
	xg7.style.filter = a + b + c + d + e + f + g + h + i;
	xg7.style.WebkitFilter = a + b + c + d + e + f + g + h + i;
	xg8.style.filter = a + b + c + d + e + f + g + h + i;
	xg8.style.WebkitFilter = a + b + c + d + e + f + g + h + i;
	xg9.style.filter = a + b + c + d + e + f + g + h + i;
	xg9.style.WebkitFilter = a + b + c + d + e + f + g + h + i;
	xg10.style.filter = a + b + c + d + e + f + g + h + i;
	xg10.style.WebkitFilter = a + b + c + d + e + f + g + h + i;
	xg11.style.filter = a + b + c + d + e + f + g + h + i;
	xg11.style.WebkitFilter = a + b + c + d + e + f + g + h + i;
	xg12.style.filter = a + b + c + d + e + f + g + h + i;
	xg12.style.WebkitFilter = a + b + c + d + e + f + g + h + i;
	xg13.style.filter = a + b + c + d + e + f + g + h + i;
	xg13.style.WebkitFilter = a + b + c + d + e + f + g + h + i;
	xg14.style.filter = a + b + c + d + e + f + g + h + i;
	xg14.style.WebkitFilter = a + b + c + d + e + f + g + h + i;
	xg15.style.filter = a + b + c + d + e + f + g + h + i;
	xg15.style.WebkitFilter = a + b + c + d + e + f + g + h + i;
	xg16.style.filter = a + b + c + d + e + f + g + h + i;
	xg16.style.WebkitFilter = a + b + c + d + e + f + g + h + i;
	xg17.style.filter = a + b + c + d + e + f + g + h + i;
	xg17.style.WebkitFilter = a + b + c + d + e + f + g + h + i;
	xg18.style.filter = a + b + c + d + e + f + g + h + i;
	xg18.style.WebkitFilter = a + b + c + d + e + f + g + h + i;
	xg19.style.filter = a + b + c + d + e + f + g + h + i;
	xg19.style.WebkitFilter = a + b + c + d + e + f + g + h + i;
	xg20.style.filter = a + b + c + d + e + f + g + h + i;
	xg20.style.WebkitFilter = a + b + c + d + e + f + g + h + i;
	xg21.style.filter = a + b + c + d + e + f + g + h + i;
	xg21.style.WebkitFilter = a + b + c + d + e + f + g + h + i;
}

function someCtsA(){
	
    var v = document.getElementById("widthNheight").value + 'px';
    var z = document.getElementById("widthNheight2").value + 'px';
    
    
	var xg1 = document.getElementById("azz1");
	var xg2 = document.getElementById("bzz1");
	var xg3 = document.getElementById("czz1");
	var xg4 = document.getElementById("dzz1");
	var xg5 = document.getElementById("ezz1");
	var xg6 = document.getElementById("fzz1");
	var xg7 = document.getElementById("gzz1");
	var xg8 = document.getElementById("hzz1");
	var xg9 = document.getElementById("izz1");
	var xg10 = document.getElementById("jzz1");
	var xg11 = document.getElementById("kzz1");
	var xg12 = document.getElementById("lzz1");
	var xg13 = document.getElementById("mzz1");
	var xg14 = document.getElementById("nzz1");
	var xg15 = document.getElementById("ozz1");
	var xg16 = document.getElementById("pzz1");
	var xg17 = document.getElementById("qzz1");
	var xg18 = document.getElementById("rzz1");
	var xg19 = document.getElementById("szz1");
	var xg20 = document.getElementById("tzz1");
	var xg21 = document.getElementById("uzz1");
	xg1.style.width = v;
	xg1.style.height = z;
	xg2.style.width = v;
	xg2.style.height = z;
	xg3.style.width = v;
	xg3.style.height = z;
	xg4.style.width = v;
	xg4.style.height = z;
	xg5.style.width = v;
	xg5.style.height = z;
	xg6.style.width = v;
	xg6.style.height = z;
	xg7.style.width = v;
	xg7.style.height = z;
	xg8.style.width = v;
	xg8.style.height = z;
	xg9.style.width = v;
	xg9.style.height = z;
	xg10.style.width = v;
	xg10.style.height = z;
	xg11.style.width = v;
	xg11.style.height = z;
	xg12.style.width = v;
	xg12.style.height = z;
	xg13.style.width = v;
	xg13.style.height = z;
	xg14.style.width = v;
	xg14.style.height = z;
	xg15.style.width = v;
	xg15.style.height = z;
	xg16.style.width = v;
	xg16.style.height = z;
	xg17.style.width = v;
	xg17.style.height = z;
	xg18.style.width = v;
	xg18.style.height = z;
	xg19.style.width = v;
	xg19.style.height = z;
	xg20.style.width = v;
	xg20.style.height = z;
	xg21.style.width = v;
	xg21.style.height = z;
};

function dotClick1() {
	if(document.getElementById("azz1").style.visibility == "visible") {
		document.getElementById("azz1").style.visibility = "hidden";
	} else {
		document.getElementById("azz1").style.visibility = "visible";
	}
}

function dotClick2() {
	if(document.getElementById("bzz1").style.visibility == "visible") {
		document.getElementById("bzz1").style.visibility = "hidden";
	} else {
		document.getElementById("bzz1").style.visibility = "visible";
	}
}

function dotClick3() {
	if(document.getElementById("czz1").style.visibility == "visible") {
		document.getElementById("czz1").style.visibility = "hidden";
	} else {
		document.getElementById("czz1").style.visibility = "visible";
	}
}

function dotClick4() {
	if(document.getElementById("dzz1").style.visibility == "visible") {
		document.getElementById("dzz1").style.visibility = "hidden";
	} else {
		document.getElementById("dzz1").style.visibility = "visible";
	}
}

function dotClick5() {
	if(document.getElementById("ezz1").style.visibility == "visible") {
		document.getElementById("ezz1").style.visibility = "hidden";
	} else {
		document.getElementById("ezz1").style.visibility = "visible";
	}
}

function dotClick6() {
	if(document.getElementById("fzz1").style.visibility == "visible") {
		document.getElementById("fzz1").style.visibility = "hidden";
	} else {
		document.getElementById("fzz1").style.visibility = "visible";
	}
}

function dotClick7() {
	if(document.getElementById("gzz1").style.visibility == "visible") {
		document.getElementById("gzz1").style.visibility = "hidden";
	} else {
		document.getElementById("gzz1").style.visibility = "visible";
	}
}

function dotClick8() {
	if(document.getElementById("hzz1").style.visibility == "visible") {
		document.getElementById("hzz1").style.visibility = "hidden";
	} else {
		document.getElementById("hzz1").style.visibility = "visible";
	}
}

function dotClick9() {
	if(document.getElementById("izz1").style.visibility == "visible") {
		document.getElementById("izz1").style.visibility = "hidden";
	} else {
		document.getElementById("izz1").style.visibility = "visible";
	}
}

function dotClick10() {
	if(document.getElementById("jzz1").style.visibility == "visible") {
		document.getElementById("jzz1").style.visibility = "hidden";
	} else {
		document.getElementById("jzz1").style.visibility = "visible";
	}
}

function dotClick11() {
	if(document.getElementById("kzz1").style.visibility == "visible") {
		document.getElementById("kzz1").style.visibility = "hidden";
	} else {
		document.getElementById("kzz1").style.visibility = "visible";
	}
}

function dotClick12() {
	if(document.getElementById("lzz1").style.visibility == "visible") {
		document.getElementById("lzz1").style.visibility = "hidden";
	} else {
		document.getElementById("lzz1").style.visibility = "visible";
	}
}

function dotClick13() {
	if(document.getElementById("mzz1").style.visibility == "visible") {
		document.getElementById("mzz1").style.visibility = "hidden";
	} else {
		document.getElementById("mzz1").style.visibility = "visible";
	}
}

function dotClick14() {
	if(document.getElementById("nzz1").style.visibility == "visible") {
		document.getElementById("nzz1").style.visibility = "hidden";
	} else {
		document.getElementById("nzz1").style.visibility = "visible";
	}
}

function dotClick15() {
	if(document.getElementById("ozz1").style.visibility == "visible") {
		document.getElementById("ozz1").style.visibility = "hidden";
	} else {
		document.getElementById("ozz1").style.visibility = "visible";
	}
}

function dotClick16() {
	if(document.getElementById("pzz1").style.visibility == "visible") {
		document.getElementById("pzz1").style.visibility = "hidden";
	} else {
		document.getElementById("pzz1").style.visibility = "visible";
	}
}

function dotClick17() {
	if(document.getElementById("qzz1").style.visibility == "visible") {
		document.getElementById("qzz1").style.visibility = "hidden";
	} else {
		document.getElementById("qzz1").style.visibility = "visible";
	}
}

function dotClick18() {
	if(document.getElementById("rzz1").style.visibility == "visible") {
		document.getElementById("rzz1").style.visibility = "hidden";
	} else {
		document.getElementById("rzz1").style.visibility = "visible";
	}
}

function dotClick19() {
	if(document.getElementById("szz1").style.visibility == "visible") {
		document.getElementById("szz1").style.visibility = "hidden";
	} else {
		document.getElementById("szz1").style.visibility = "visible";
	}
}

function dotClick20() {
	if(document.getElementById("tzz1").style.visibility == "visible") {
		document.getElementById("tzz1").style.visibility = "hidden";
	} else {
		document.getElementById("tzz1").style.visibility = "visible";
	}
}

function dotClick21() {
	if(document.getElementById("uzz1").style.visibility == "visible") {
		document.getElementById("uzz1").style.visibility = "hidden";
	} else {
		document.getElementById("uzz1").style.visibility = "visible";
	}
}

function backgroundCrgb(){
	var j = document.getElementById("Background_Color-R").value;
	var k = document.getElementById("Background_Color-G").value;
	var l = document.getElementById("Background_Color-B").value;
	var p = "rgb(";
	var q = ")";
	var r = p + j + ", " + k + ", " + l + q;
	document.getElementById("theKeep").style.backgroundColor = r;
	if(j <= 255){
		if(k <= 255){
		    if(l <= 255){
			    document.getElementById("theKeep").style.backgroundColor = 'rgb(0,0,0)'
				if(document.getElementById("theKeep").style.backgroundColor == 'rgb(0,0,0)'){
					document.getElementById("theKeep").style.color = 'rgb(255,255,255)'
				};
			}
		}
	}
	if(j == 255){
		if(k == 255){
		    if(l == 255){
			    document.getElementById("theKeep").style.backgroundColor = 'rgb(255,255,255)'
				if(document.getElementById("theKeep").style.backgroundColor == 'rgb(255,255,255)'){
			        document.getElementById("theKeep").style.color = 'rgb(0,0,0)';
				}
			}
		}
	}
	
}

function fontCrgb(){
	var m = document.getElementById("Font_Color-R").value;
	var n = document.getElementById("Font_Color-G").value;
	var o = document.getElementById("Font_Color-B").value;
	var p = "rgb(";
	var q = ")";
	var s = p + m + ", " + n + ", " + o + q;
	document.getElementById("theKeep").style.color = s;
}
function aRefresh() {
    location.reload();
}