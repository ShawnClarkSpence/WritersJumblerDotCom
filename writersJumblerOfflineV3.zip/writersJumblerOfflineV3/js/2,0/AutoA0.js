function autoA() {
    let a = Math.floor((Math.random() * 25) + 1)
	let b = Math.floor(((Math.random() * 25) + 1) + 25)
	let c = Math.floor(((Math.random() * 25) + 1) + 50)
	let d = Math.floor(((Math.random() * 25) + 1) + 75)
	let e = Math.floor(((Math.random() * 25) + 1) + 100)
	let f = Math.floor(((Math.random() * 25) + 1) + 125)
	let g = Math.floor(((Math.random() * 25) + 1) + 150)
	let h = Math.floor(((Math.random() * 25) + 1) + 175)
	let i = Math.floor(((Math.random() * 25) + 1) + 200)
	let j = Math.floor(((Math.random() * 25) + 1) + 225)
	let k = Math.floor(((Math.random() * 25) + 1) + 250)
	let l = Math.floor(((Math.random() * 25) + 1) + 275)
	let m = Math.floor(((Math.random() * 25) + 1) + 300)
	let n = l + 50
        let o = k + 100
	let p = j + 150
	let q = i + 200
	let r = h + 250
	let s = g + 300
	let t = f + 350
	let u = e + 400
	let v = d + 450
	let w = c + 500
	let y = b + 550
	let z = a + 600
	var a4 = a
	var b4 = b
	var c4 = c
	var d4 = d
	var e4 = e
	var f4 = f
 	var g4 = g
	var h4 = h
	var i4 = i
	var j4 = j
	var k4 = k
	var l4 = l
	var m4 = m
	var n4 = n
        var o4 = o
	var p4 = p
	var q4 = q
	var r4 = r
	var s4 = s
	var t4 = t
	var u4 = u
	var v4 = v
	var w4 = w
	var y4 = y
	var z4 = z
	var a1 = 'imgSqr' + a4
	var b1 = 'imgSqr' + b4
	var c1 = 'imgSqr' + c4
	var d1 = 'imgSqr' + d4
	var e1 = 'imgSqr' + e4
	var f1 = 'imgSqr' + f4
	var g1 = 'imgSqr' + g4
	var h1 = 'imgSqr' + h4
	var i1 = 'imgSqr' + i4
	var j1 = 'imgSqr' + j4
	var k1 = 'imgSqr' + k4
	var l1 = 'imgSqr' + l4
	var m1 = 'imgSqr' + m4
	var n1 = 'imgSqr' + n4
	var o1 = 'imgSqr' + o4
	var p1 = 'imgSqr' + p4
	var q1 = 'imgSqr' + q4
	var r1 = 'imgSqr' + r4
	var s1 = 'imgSqr' + s4
	var t1 = 'imgSqr' + t4
	var u1 = 'imgSqr' + u4
	var v1 = 'imgSqr' + v4
	var w1 = 'imgSqr' + w4
	var y1 = 'imgSqr' + y4
	var z1 = 'imgSqr' + z4
	if(document.getElementById(a1).src = "img/sqrs/wSqr3.png") {
		document.getElementById(a1).src = "img/sqrs/blSqr3.png"
	};
	if(document.getElementById(b1).src = "img/sqrs/wSqr2.png") {
		document.getElementById(b1).src = "img/sqrs/blSqr2.png"
	};
	if(document.getElementById(c1).src = "img/sqrs/wSqr3.png") {
		document.getElementById(c1).src = "img/sqrs/blSqr3.png"
	};
	if(document.getElementById(d1).src = "img/sqrs/wSqr2.png") {
		document.getElementById(d1).src = "img/sqrs/blSqr2.png"
	};
	if(document.getElementById(e1).src = "img/sqrs/wSqr3.png") {
		document.getElementById(e1).src = "img/sqrs/blSqr3.png"
	};
	if(document.getElementById(f1).src = "img/sqrs/wSqr2.png") {
		document.getElementById(f1).src = "img/sqrs/blSqr2.png"
	};
	if(document.getElementById(g1).src = "img/sqrs/wSqr3.png") {
		document.getElementById(g1).src = "img/sqrs/blSqr3.png"
	};
	if(document.getElementById(h1).src = "img/sqrs/wSqr2.png") {
		document.getElementById(h1).src = "img/sqrs/blSqr2.png"
	};
	if(document.getElementById(i1).src = "img/sqrs/wSqr3.png") {
		document.getElementById(i1).src = "img/sqrs/blSqr3.png"
	};
	if(document.getElementById(j1).src = "img/sqrs/wSqr2.png") {
		document.getElementById(j1).src = "img/sqrs/blSqr2.png"
	};
	if(document.getElementById(k1).src = "img/sqrs/wSqr3.png") {
		document.getElementById(k1).src = "img/sqrs/blSqr3.png"
	};
	if(document.getElementById(l1).src = "img/sqrs/wSqr2.png") {
		document.getElementById(l1).src = "img/sqrs/blSqr2.png"
	};
	if(document.getElementById(m1).src = "img/sqrs/wSqr3.png") {
		document.getElementById(m1).src = "img/sqrs/blSqr3.png"
	};
	if(document.getElementById(n1).src = "img/sqrs/wSqr2.png") {
		document.getElementById(n1).src = "img/sqrs/blSqr2.png"
	};
	if(document.getElementById(o1).src = "img/sqrs/wSqr3.png") {
		document.getElementById(o1).src = "img/sqrs/blSqr3.png"
	};
	if(document.getElementById(p1).src = "img/sqrs/wSqr2.png") {
		document.getElementById(p1).src = "img/sqrs/blSqr2.png"
	};
	if(document.getElementById(q1).src = "img/sqrs/wSqr3.png") {
		document.getElementById(q1).src = "img/sqrs/blSqr3.png"
	};
	if(document.getElementById(r1).src = "img/sqrs/wSqr2.png") {
		document.getElementById(r1).src = "img/sqrs/blSqr2.png"
	};
	if(document.getElementById(s1).src = "img/sqrs/wSqr3.png") {
		document.getElementById(s1).src = "img/sqrs/blSqr3.png"
	};
	if(document.getElementById(t1).src = "img/sqrs/wSqr2.png") {
		document.getElementById(t1).src = "img/sqrs/blSqr2.png"
	};
	if(document.getElementById(u1).src = "img/sqrs/wSqr3.png") {
		document.getElementById(u1).src = "img/sqrs/blSqr3.png"
	};
	if(document.getElementById(v1).src = "img/sqrs/wSqr2.png") {
		document.getElementById(v1).src = "img/sqrs/blSqr2.png"
	};
	if(document.getElementById(w1).src = "img/sqrs/wSqr3.png") {
		document.getElementById(w1).src = "img/sqrs/blSqr3.png"
	};
	if(document.getElementById(y1).src = "img/sqrs/wSqr2.png") {
		document.getElementById(y1).src = "img/sqrs/blSqr2.png"
	};
	if(document.getElementById(z1).src = "img/sqrs/wSqr3.png") {
		document.getElementById(z1).src = "img/sqrs/blSqr3.png"
	};
};