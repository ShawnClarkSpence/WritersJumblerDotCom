function crcl01(){
	document.getElementById("crcl01").style.visibility = "hidden";
}

function crcl02(){
	document.getElementById("crcl02").style.visibility = "hidden";
}

function crcl03(){
	document.getElementById("crcl03").style.visibility = "hidden";
}

function crcl04(){
	document.getElementById("crcl04").style.visibility = "hidden";
}

function crcl05(){
	document.getElementById("crcl05").style.visibility = "hidden";
}

function crcl06(){
	document.getElementById("crcl06").style.visibility = "hidden";
}

function crcl07(){
	document.getElementById("crcl07").style.visibility = "hidden";
}

function crcl08(){
	document.getElementById("crcl08").style.visibility = "hidden";
}

function crcl09(){
	document.getElementById("crcl09").style.visibility = "hidden";
}

function crcl10(){
	document.getElementById("crcl10").style.visibility = "hidden";
}

function crcl11(){
	document.getElementById("crcl11").style.visibility = "hidden";
}

function crcl12(){
	document.getElementById("crcl12").style.visibility = "hidden";
}

function crcl13(){
	document.getElementById("crcl13").style.visibility = "hidden";
}

function crcl14(){
	document.getElementById("crcl14").style.visibility = "hidden";
}

function crcl15(){
	document.getElementById("crcl15").style.visibility = "hidden";
}

function crcl16(){
	document.getElementById("crcl16").style.visibility = "hidden";
}

function crcl17(){
	document.getElementById("crcl17").style.visibility = "hidden";
}

function crcl18(){
	document.getElementById("crcl18").style.visibility = "hidden";
}

function crcl19(){
	document.getElementById("crcl19").style.visibility = "hidden";
}

function crcl20(){
	document.getElementById("crcl20").style.visibility = "hidden";
}

function crcl21(){
	document.getElementById("crcl21").style.visibility = "hidden";
}

function crcl22(){
	document.getElementById("crcl22").style.visibility = "hidden";
}

function crcl23(){
	document.getElementById("crcl23").style.visibility = "hidden";
}

function crcl24(){
	document.getElementById("crcl24").style.visibility = "hidden";
}

function crcl25(){
	document.getElementById("crcl25").style.visibility = "hidden";
}

function crcl26(){
	document.getElementById("crcl26").style.visibility = "hidden";
}

function crcl27(){
	document.getElementById("crcl27").style.visibility = "hidden";
}

function crcl28(){
	document.getElementById("crcl28").style.visibility = "hidden";
}

function crcl29(){
	document.getElementById("crcl29").style.visibility = "hidden";
}

function crcl30(){
	document.getElementById("crcl30").style.visibility = "hidden";
}

function crcl31(){
	document.getElementById("crcl31").style.visibility = "hidden";
}

function crcl32(){
	document.getElementById("crcl32").style.visibility = "hidden";
}

function crcl33(){
	document.getElementById("crcl33").style.visibility = "hidden";
}

function crcl34(){
	document.getElementById("crcl34").style.visibility = "hidden";
}

function crcl35(){
	document.getElementById("crcl35").style.visibility = "hidden";
}

function crcl36(){
	document.getElementById("crcl36").style.visibility = "hidden";
}

function crcl37(){
	document.getElementById("crcl37").style.visibility = "hidden";
}

function crcl38(){
	document.getElementById("crcl38").style.visibility = "hidden";
}

function crcl39(){
	document.getElementById("crcl39").style.visibility = "hidden";
}

function crcl40(){
	document.getElementById("crcl40").style.visibility = "hidden";
}

function crcl41(){
	document.getElementById("crcl41").style.visibility = "hidden";
}

function crcl42(){
	document.getElementById("crcl42").style.visibility = "hidden";
}

function crcl43(){
	document.getElementById("crcl43").style.visibility = "hidden";
}

function crcl44(){
	document.getElementById("crcl44").style.visibility = "hidden";
}

function crcl45(){
	document.getElementById("crcl45").style.visibility = "hidden";
}

function crcl46(){
	document.getElementById("crcl46").style.visibility = "hidden";
}

function crcl47(){
	document.getElementById("crcl47").style.visibility = "hidden";
}

function crcl48(){
	document.getElementById("crcl48").style.visibility = "hidden";
}

function crcl49(){
	document.getElementById("crcl49").style.visibility = "hidden";
}

function crcl50(){
	document.getElementById("crcl50").style.visibility = "hidden";
}

function crcl51(){
	document.getElementById("crcl51").style.visibility = "hidden";
}

function crcl52(){
	document.getElementById("crcl52").style.visibility = "hidden";
}

function crcl53(){
	document.getElementById("crcl53").style.visibility = "hidden";
}

function crcl54(){
	document.getElementById("crcl54").style.visibility = "hidden";
}

function crcl55(){
	document.getElementById("crcl55").style.visibility = "hidden";
}

function crcl56(){
	document.getElementById("crcl56").style.visibility = "hidden";
}

function crcl57(){
	document.getElementById("crcl57").style.visibility = "hidden";
}

function crcl58(){
	document.getElementById("crcl58").style.visibility = "hidden";
}

function crcl59(){
	document.getElementById("crcl59").style.visibility = "hidden";
}

function crcl60(){
	document.getElementById("crcl60").style.visibility = "hidden";
}

function crcl61(){
	document.getElementById("crcl61").style.visibility = "hidden";
}

function crcl62(){
	document.getElementById("crcl62").style.visibility = "hidden";
}

function crcl63(){
	document.getElementById("crcl63").style.visibility = "hidden";
}

function crcl64(){
	document.getElementById("crcl64").style.visibility = "hidden";
}

function crcl65(){
	document.getElementById("crcl65").style.visibility = "hidden";
}

function crcl66(){
	document.getElementById("crcl66").style.visibility = "hidden";
}

function crcl67(){
	document.getElementById("crcl67").style.visibility = "hidden";
}

function crcl68(){
	document.getElementById("crcl68").style.visibility = "hidden";
}

function crcl69(){
	document.getElementById("crcl69").style.visibility = "hidden";
}

function crcl70(){
	document.getElementById("crcl70").style.visibility = "hidden";
}

function crcl71(){
	document.getElementById("crcl71").style.visibility = "hidden";
}

function crcl72(){
	document.getElementById("crcl72").style.visibility = "hidden";
}

function crcl73(){
	document.getElementById("crcl73").style.visibility = "hidden";
}

function crcl74(){
	document.getElementById("crcl74").style.visibility = "hidden";
}

function crcl75(){
	document.getElementById("crcl75").style.visibility = "hidden";
}

function crcl76(){
	document.getElementById("crcl76").style.visibility = "hidden";
}

function crcl77(){
	document.getElementById("crcl77").style.visibility = "hidden";
}

function crcl78(){
	document.getElementById("crcl78").style.visibility = "hidden";
}

function crcl79(){
	document.getElementById("crcl79").style.visibility = "hidden";
}

function crcl80(){
	document.getElementById("crcl80").style.visibility = "hidden";
}

function crcl81(){
	document.getElementById("crcl81").style.visibility = "hidden";
}

function crcl82(){
	document.getElementById("crcl82").style.visibility = "hidden";
}

function crcl83(){
	document.getElementById("crcl83").style.visibility = "hidden";
}

function crcl84(){
	document.getElementById("crcl84").style.visibility = "hidden";
}

function crcl85(){
	document.getElementById("crcl85").style.visibility = "hidden";
}

function crcl86(){
	document.getElementById("crcl86").style.visibility = "hidden";
}

function crcl87(){
	document.getElementById("crcl87").style.visibility = "hidden";
}

function crcl88(){
	document.getElementById("crcl88").style.visibility = "hidden";
}

function crcl89(){
	document.getElementById("crcl89").style.visibility = "hidden";
}

function crcl90(){
	document.getElementById("crcl90").style.visibility = "hidden";
}

function crcl91(){
	document.getElementById("crcl91").style.visibility = "hidden";
}

function crcl92(){
	document.getElementById("crcl92").style.visibility = "hidden";
}

function crcl93(){
	document.getElementById("crcl93").style.visibility = "hidden";
}

function crcl94(){
	document.getElementById("crcl94").style.visibility = "hidden";
}