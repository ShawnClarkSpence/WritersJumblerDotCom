function SomeElseArts() {
    var x = document.getElementById("artMenu").value;
    var z = document.getElementById("img0001").value;
    var y = document.getElementById("photo").value;
    z1 = '<div id="img0001"><img src="img/art/01.jpg" id="img0002" title="art" style="" alt="Image"></div>';
    z2 = '<div id="img0001"><img src="img/art/02.jpg" id="img0002" title="art" style="" alt="Image"></div>';
    z3 = '<div id="img0001"><img src="img/art/03.jpg" id="img0002" title="art" style="" alt="Image"></div>';
    z4 = '<div id="img0001"><img src="img/art/04.jpg" id="img0002" title="art" style="" alt="Image"></div>';
    z5 = '<div id="img0001"><img src="img/art/05.jpg" id="img0002" title="art" style="" alt="Image"></div>';
    z6 = '<div id="img0001"><img src="img/art/06.jpg" id="img0002" title="art" style="" alt="Image"></div>';
    z7 = '<div id="img0001"><img src="img/art/07.jpg" id="img0002" title="art" style="" alt="Image"></div>';
    z8 = '<div id="img0001"><img src="img/art/08.jpg" id="img0002" title="art" style="" alt="Image"></div>';
    z9 = '<div id="img0001"><img src="img/art/09.gif" id="img0002" title="art" style="" alt="Image"></div>';
    z10 = '<div id="img0001"><img src="img/art/10.jpg" id="img0002" title="art" style="" alt="Image"></div>';
    z11 = '<div id="img0001"><img src="img/art/11.jpg" id="img0002" title="art" style="" alt="Image"></div>';
    z12 = '<div id="img0001"><img src="img/art/12.jpg" id="img0002" title="art" style="" alt="Image"></div>';
    z13 = '<div id="img0001"><img src="img/art/13.gif" id="img0002" title="art" style="" alt="Image"></div>';
    z14 = '<div id="img0001"><img src="img/art/14.jpg" id="img0002" title="art" style="" alt="Image"></div>';
    z15 = '<div id="img0001"><img src="img/art/15.jpg" id="img0002" title="art" style="" alt="Image"></div>';
    z17 = '<div id="img0001"><img src=';
    z18 = ' id="img0002" title="yourArt" style="" alt="Image" /></div>';
    if (x == "z1") {
        document.getElementById("img0001").innerHTML = z1;
    };
    if (x == "z2") {
        document.getElementById("img0001").innerHTML = z2;
    };
    if (x == "z3") {
        document.getElementById("img0001").innerHTML = z3;
    };
    if (x == "z4") {
        document.getElementById("img0001").innerHTML = z4;
    };
    if (x == "z5") {
        document.getElementById("img0001").innerHTML = z5;
    };
    if  (x == "z6") {
        document.getElementById("img0001").innerHTML = z6;
    };
    if (x == "z7") {
        document.getElementById("img0001").innerHTML = z7;
    };
    if (x == "z8") {
        document.getElementById("img0001").innerHTML = z8;
    };
    if (x == "z9") {
        document.getElementById("img0001").innerHTML = z9;
    };
    if (x == "z10") {
        document.getElementById("img0001").innerHTML = z10;
    };
    if (x == "z11") {
        document.getElementById("img0001").innerHTML = z11;
    };
    if (x == "z12") {
        document.getElementById("img0001").innerHTML = z12;
    };
    if  (x == "z13") {
        document.getElementById("img0001").innerHTML = z13;
    };
    if (x == "z14") {
        document.getElementById("img0001").innerHTML = z14;
    };
    if (x == "z15") {
        document.getElementById("img0001").innerHTML = z15;
    };
    if (x == "z16") {
        document.getElementById("img0001").innerHTML = z17 + '"' + y + '"' + z18;
    };
};
