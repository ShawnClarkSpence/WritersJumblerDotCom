function asqrA1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr1").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr1").src = "img/sqrs/blSqr.png"
};};};
function asqrA2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr2").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr2").src = "img/sqrs/blSqr.png"
};};};
function asqrA3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr3").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr3").src = "img/sqrs/blSqr.png"
};};};
function asqrA4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr4").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr4").src = "img/sqrs/blSqr.png"
};};};
function asqrA5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr5").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr5").src = "img/sqrs/blSqr.png"
};};};
function asqrA6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr6").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr6").src = "img/sqrs/blSqr.png"
};};};
function asqrA7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr7").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr7").src = "img/sqrs/blSqr.png"
};};};
function asqrA8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr8").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr8").src = "img/sqrs/blSqr.png"
};};};
function asqrA9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr9").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr9").src = "img/sqrs/blSqr.png"
};};};
function asqrA10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr10").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr10").src = "img/sqrs/blSqr.png"
};};};
function asqrA11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr11").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr11").src = "img/sqrs/blSqr.png"
};};};
function asqrA12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr12").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr12").src = "img/sqrs/blSqr.png"
};};};
function asqrA13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr13").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr13").src = "img/sqrs/blSqr.png"
};};};
function asqrA14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr14").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr14").src = "img/sqrs/blSqr.png"
};};};
function asqrA15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr15").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr15").src = "img/sqrs/blSqr.png"
};};};
function asqrA16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr16").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr16").src = "img/sqrs/blSqr.png"
};};};
function asqrA17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr17").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr17").src = "img/sqrs/blSqr.png"
};};};
function asqrA18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr18").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr18").src = "img/sqrs/blSqr.png"
};};};
function asqrA19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr19").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr19").src = "img/sqrs/blSqr.png"
};};};
function asqrA20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr20").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr20").src = "img/sqrs/blSqr.png"
};};};
function asqrA21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr21").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr21").src = "img/sqrs/blSqr.png"
};};};
function asqrA22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr22").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr22").src = "img/sqrs/blSqr.png"
};};};
function asqrA23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr23").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr23").src = "img/sqrs/blSqr.png"
};};};
function asqrA24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr24").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr24").src = "img/sqrs/blSqr.png"
};};};
function asqrA25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr25").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr25").src = "img/sqrs/blSqr.png"
};};};
function asqrB1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr26").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr26").src = "img/sqrs/blSqr.png"
};};};
function asqrB2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr27").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr27").src = "img/sqrs/blSqr.png"
};};};
function asqrB3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr28").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr28").src = "img/sqrs/blSqr.png"
};};};
function asqrB4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr29").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr29").src = "img/sqrs/blSqr.png"
};};};
function asqrB5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr30").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr30").src = "img/sqrs/blSqr.png"
};};};
function asqrB6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr31").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr31").src = "img/sqrs/blSqr.png"
};};};
function asqrB7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr32").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr32").src = "img/sqrs/blSqr.png"
};};};
function asqrB8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr33").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr33").src = "img/sqrs/blSqr.png"
};};};
function asqrB9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr34").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr34").src = "img/sqrs/blSqr.png"
};};};
function asqrB10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr35").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr35").src = "img/sqrs/blSqr.png"
};};};
function asqrB11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr36").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr36").src = "img/sqrs/blSqr.png"
};};};
function asqrB12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr37").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr37").src = "img/sqrs/blSqr.png"
};};};
function asqrB13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr38").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr38").src = "img/sqrs/blSqr.png"
};};};
function asqrB14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr39").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr39").src = "img/sqrs/blSqr.png"
};};};
function asqrB15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr40").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr40").src = "img/sqrs/blSqr.png"
};};};
function asqrB16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr41").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr41").src = "img/sqrs/blSqr.png"
};};};
function asqrB17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr42").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr42").src = "img/sqrs/blSqr.png"
};};};
function asqrB18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr43").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr43").src = "img/sqrs/blSqr.png"
};};};
function asqrB19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr44").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr44").src = "img/sqrs/blSqr.png"
};};};
function asqrB20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr45").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr45").src = "img/sqrs/blSqr.png"
};};};
function asqrB21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr46").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr46").src = "img/sqrs/blSqr.png"
};};};
function asqrB22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr47").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr47").src = "img/sqrs/blSqr.png"
};};};
function asqrB23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr48").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr48").src = "img/sqrs/blSqr.png"
};};};
function asqrB24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr49").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr49").src = "img/sqrs/blSqr.png"
};};};
function asqrB25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr50").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr50").src = "img/sqrs/blSqr.png"
};};};
function asqrC1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr51").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr51").src = "img/sqrs/blSqr.png"
};};};
function asqrC2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr52").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr52").src = "img/sqrs/blSqr.png"
};};};
function asqrC3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr53").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr53").src = "img/sqrs/blSqr.png"
};};};
function asqrC4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr54").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr54").src = "img/sqrs/blSqr.png"
};};};
function asqrC5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr55").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr55").src = "img/sqrs/blSqr.png"
};};};
function asqrC6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr56").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr56").src = "img/sqrs/blSqr.png"
};};};
function asqrC7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr57").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr57").src = "img/sqrs/blSqr.png"
};};};
function asqrC8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr58").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr58").src = "img/sqrs/blSqr.png"
};};};
function asqrC9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr59").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr59").src = "img/sqrs/blSqr.png"
};};};
function asqrC10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr60").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr60").src = "img/sqrs/blSqr.png"
};};};
function asqrC11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr61").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr61").src = "img/sqrs/blSqr.png"
};};};
function asqrC12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr62").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr62").src = "img/sqrs/blSqr.png"
};};};
function asqrC13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr63").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr63").src = "img/sqrs/blSqr.png"
};};};
function asqrC14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr64").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr64").src = "img/sqrs/blSqr.png"
};};};
function asqrC15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr65").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr65").src = "img/sqrs/blSqr.png"
};};};
function asqrC16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr66").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr66").src = "img/sqrs/blSqr.png"
};};};
function asqrC17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr67").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr67").src = "img/sqrs/blSqr.png"
};};};
function asqrC18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr68").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr68").src = "img/sqrs/blSqr.png"
};};};
function asqrC19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr69").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr69").src = "img/sqrs/blSqr.png"
};};};
function asqrC20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr70").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr70").src = "img/sqrs/blSqr.png"
};};};
function asqrC21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr71").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr71").src = "img/sqrs/blSqr.png"
};};};
function asqrC22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr72").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr72").src = "img/sqrs/blSqr.png"
};};};
function asqrC23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr73").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr73").src = "img/sqrs/blSqr.png"
};};};
function asqrC24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr74").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr74").src = "img/sqrs/blSqr.png"
};};};
function asqrC25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr75").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr75").src = "img/sqrs/blSqr.png"
};};};
function asqrD1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr76").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr76").src = "img/sqrs/blSqr.png"
};};};
function asqrD2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr77").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr77").src = "img/sqrs/blSqr.png"
};};};
function asqrD3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr78").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr78").src = "img/sqrs/blSqr.png"
};};};
function asqrD4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr79").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr79").src = "img/sqrs/blSqr.png"
};};};
function asqrD5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr80").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr80").src = "img/sqrs/blSqr.png"
};};};
function asqrD6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr81").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr81").src = "img/sqrs/blSqr.png"
};};};
function asqrD7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr82").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr82").src = "img/sqrs/blSqr.png"
};};};
function asqrD8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr83").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr83").src = "img/sqrs/blSqr.png"
};};};
function asqrD9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr84").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr84").src = "img/sqrs/blSqr.png"
};};};
function asqrD10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr85").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr85").src = "img/sqrs/blSqr.png"
};};};
function asqrD11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr86").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr86").src = "img/sqrs/blSqr.png"
};};};
function asqrD12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr87").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr87").src = "img/sqrs/blSqr.png"
};};};
function asqrD13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr88").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr88").src = "img/sqrs/blSqr.png"
};};};
function asqrD14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr89").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr89").src = "img/sqrs/blSqr.png"
};};};
function asqrD15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr90").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr90").src = "img/sqrs/blSqr.png"
};};};
function asqrD16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr91").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr91").src = "img/sqrs/blSqr.png"
};};};
function asqrD17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr92").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr92").src = "img/sqrs/blSqr.png"
};};};
function asqrD18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr93").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr93").src = "img/sqrs/blSqr.png"
};};};
function asqrD19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr94").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr94").src = "img/sqrs/blSqr.png"
};};};
function asqrD20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr95").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr95").src = "img/sqrs/blSqr.png"
};};};
function asqrD21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr96").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr96").src = "img/sqrs/blSqr.png"
};};};
function asqrD22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr97").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr97").src = "img/sqrs/blSqr.png"
};};};
function asqrD23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr98").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr98").src = "img/sqrs/blSqr.png"
};};};
function asqrD24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr99").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr99").src = "img/sqrs/blSqr.png"
};};};
function asqrD25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr100").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr100").src = "img/sqrs/blSqr.png"
};};};
function asqrE1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr101").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr101").src = "img/sqrs/blSqr.png"
};};};
function asqrE2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr102").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr102").src = "img/sqrs/blSqr.png"
};};};
function asqrE3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr103").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr103").src = "img/sqrs/blSqr.png"
};};};
function asqrE4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr104").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr104").src = "img/sqrs/blSqr.png"
};};};
function asqrE5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr105").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr105").src = "img/sqrs/blSqr.png"
};};};
function asqrE6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr106").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr106").src = "img/sqrs/blSqr.png"
};};};
function asqrE7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr107").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr107").src = "img/sqrs/blSqr.png"
};};};
function asqrE8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr108").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr108").src = "img/sqrs/blSqr.png"
};};};
function asqrE9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr109").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr109").src = "img/sqrs/blSqr.png"
};};};
function asqrE10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr110").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr110").src = "img/sqrs/blSqr.png"
};};};
function asqrE11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr111").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr111").src = "img/sqrs/blSqr.png"
};};};
function asqrE12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr112").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr112").src = "img/sqrs/blSqr.png"
};};};
function asqrE13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr113").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr113").src = "img/sqrs/blSqr.png"
};};};
function asqrE14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr114").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr114").src = "img/sqrs/blSqr.png"
};};};
function asqrE15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr115").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr115").src = "img/sqrs/blSqr.png"
};};};
function asqrE16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr116").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr116").src = "img/sqrs/blSqr.png"
};};};
function asqrE17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr117").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr117").src = "img/sqrs/blSqr.png"
};};};
function asqrE18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr118").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr118").src = "img/sqrs/blSqr.png"
};};};
function asqrE19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr119").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr119").src = "img/sqrs/blSqr.png"
};};};
function asqrE20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr120").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr120").src = "img/sqrs/blSqr.png"
};};};
function asqrE21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr121").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr121").src = "img/sqrs/blSqr.png"
};};};
function asqrE22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr122").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr122").src = "img/sqrs/blSqr.png"
};};};
function asqrE23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr123").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr123").src = "img/sqrs/blSqr.png"
};};};
function asqrE24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr124").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr124").src = "img/sqrs/blSqr.png"
};};};
function asqrE25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr125").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr125").src = "img/sqrs/blSqr.png"
};};};
function asqrF1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr126").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr126").src = "img/sqrs/blSqr.png"
};};};
function asqrF2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr127").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr127").src = "img/sqrs/blSqr.png"
};};};
function asqrF3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr128").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr128").src = "img/sqrs/blSqr.png"
};};};
function asqrF4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr129").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr129").src = "img/sqrs/blSqr.png"
};};};
function asqrF5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr130").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr130").src = "img/sqrs/blSqr.png"
};};};
function asqrF6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr131").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr131").src = "img/sqrs/blSqr.png"
};};};
function asqrF7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr132").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr132").src = "img/sqrs/blSqr.png"
};};};
function asqrF8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr133").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr133").src = "img/sqrs/blSqr.png"
};};};
function asqrF9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr134").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr134").src = "img/sqrs/blSqr.png"
};};};
function asqrF10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr135").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr135").src = "img/sqrs/blSqr.png"
};};};
function asqrF11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr136").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr136").src = "img/sqrs/blSqr.png"
};};};
function asqrF12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr137").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr137").src = "img/sqrs/blSqr.png"
};};};
function asqrF13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr138").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr138").src = "img/sqrs/blSqr.png"
};};};
function asqrF14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr139").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr139").src = "img/sqrs/blSqr.png"
};};};
function asqrF15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr140").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr140").src = "img/sqrs/blSqr.png"
};};};
function asqrF16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr141").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr141").src = "img/sqrs/blSqr.png"
};};};
function asqrF17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr142").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr142").src = "img/sqrs/blSqr.png"
};};};
function asqrF18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr143").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr143").src = "img/sqrs/blSqr.png"
};};};
function asqrF19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr144").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr144").src = "img/sqrs/blSqr.png"
};};};
function asqrF20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr145").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr145").src = "img/sqrs/blSqr.png"
};};};
function asqrF21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr146").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr146").src = "img/sqrs/blSqr.png"
};};};
function asqrF22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr147").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr147").src = "img/sqrs/blSqr.png"
};};};
function asqrF23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr148").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr148").src = "img/sqrs/blSqr.png"
};};};
function asqrF24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr149").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr149").src = "img/sqrs/blSqr.png"
};};};
function asqrF25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr150").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr150").src = "img/sqrs/blSqr.png"
};};};
function asqrG1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr151").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr151").src = "img/sqrs/blSqr.png"
};};};
function asqrG2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr152").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr152").src = "img/sqrs/blSqr.png"
};};};
function asqrG3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr153").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr153").src = "img/sqrs/blSqr.png"
};};};
function asqrG4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr154").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr154").src = "img/sqrs/blSqr.png"
};};};
function asqrG5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr155").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr155").src = "img/sqrs/blSqr.png"
};};};
function asqrG6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr156").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr156").src = "img/sqrs/blSqr.png"
};};};
function asqrG7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr157").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr157").src = "img/sqrs/blSqr.png"
};};};
function asqrG8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr158").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr158").src = "img/sqrs/blSqr.png"
};};};
function asqrG9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr159").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr159").src = "img/sqrs/blSqr.png"
};};};
function asqrG10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr160").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr160").src = "img/sqrs/blSqr.png"
};};};
function asqrG11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr161").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr161").src = "img/sqrs/blSqr.png"
};};};
function asqrG12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr162").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr162").src = "img/sqrs/blSqr.png"
};};};
function asqrG13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr163").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr163").src = "img/sqrs/blSqr.png"
};};};
function asqrG14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr164").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr164").src = "img/sqrs/blSqr.png"
};};};
function asqrG15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr165").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr165").src = "img/sqrs/blSqr.png"
};};};
function asqrG16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr166").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr166").src = "img/sqrs/blSqr.png"
};};};
function asqrG17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr167").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr167").src = "img/sqrs/blSqr.png"
};};};
function asqrG18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr168").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr168").src = "img/sqrs/blSqr.png"
};};};
function asqrG19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr169").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr169").src = "img/sqrs/blSqr.png"
};};};
function asqrG20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr170").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr170").src = "img/sqrs/blSqr.png"
};};};
function asqrG21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr171").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr171").src = "img/sqrs/blSqr.png"
};};};
function asqrG22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr172").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr172").src = "img/sqrs/blSqr.png"
};};};
function asqrG23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr173").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr173").src = "img/sqrs/blSqr.png"
};};};
function asqrG24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr174").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr174").src = "img/sqrs/blSqr.png"
};};};
function asqrG25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr175").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr175").src = "img/sqrs/blSqr.png"
};};};
function asqrH1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr176").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr176").src = "img/sqrs/blSqr.png"
};};};
function asqrH2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr177").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr177").src = "img/sqrs/blSqr.png"
};};};
function asqrH3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr178").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr178").src = "img/sqrs/blSqr.png"
};};};
function asqrH4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr179").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr179").src = "img/sqrs/blSqr.png"
};};};
function asqrH5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr180").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr180").src = "img/sqrs/blSqr.png"
};};};
function asqrH6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr181").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr181").src = "img/sqrs/blSqr.png"
};};};
function asqrH7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr182").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr182").src = "img/sqrs/blSqr.png"
};};};
function asqrH8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr183").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr183").src = "img/sqrs/blSqr.png"
};};};
function asqrH9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr184").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr184").src = "img/sqrs/blSqr.png"
};};};
function asqrH10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr185").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr185").src = "img/sqrs/blSqr.png"
};};};
function asqrH11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr186").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr186").src = "img/sqrs/blSqr.png"
};};};
function asqrH12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr187").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr187").src = "img/sqrs/blSqr.png"
};};};
function asqrH13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr188").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr188").src = "img/sqrs/blSqr.png"
};};};
function asqrH14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr189").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr189").src = "img/sqrs/blSqr.png"
};};};
function asqrH15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr190").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr190").src = "img/sqrs/blSqr.png"
};};};
function asqrH16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr191").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr191").src = "img/sqrs/blSqr.png"
};};};
function asqrH17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr192").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr192").src = "img/sqrs/blSqr.png"
};};};
function asqrH18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr193").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr193").src = "img/sqrs/blSqr.png"
};};};
function asqrH19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr194").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr194").src = "img/sqrs/blSqr.png"
};};};
function asqrH20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr195").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr195").src = "img/sqrs/blSqr.png"
};};};
function asqrH21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr196").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr196").src = "img/sqrs/blSqr.png"
};};};
function asqrH22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr197").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr197").src = "img/sqrs/blSqr.png"
};};};
function asqrH23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr198").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr198").src = "img/sqrs/blSqr.png"
};};};
function asqrH24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr199").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr199").src = "img/sqrs/blSqr.png"
};};};
function asqrH25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr200").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr200").src = "img/sqrs/blSqr.png"
};};};
function asqrI1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr201").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr201").src = "img/sqrs/blSqr.png"
};};};
function asqrI2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr202").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr202").src = "img/sqrs/blSqr.png"
};};};
function asqrI3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr203").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr203").src = "img/sqrs/blSqr.png"
};};};
function asqrI4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr204").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr204").src = "img/sqrs/blSqr.png"
};};};
function asqrI5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr205").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr205").src = "img/sqrs/blSqr.png"
};};};
function asqrI6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr206").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr206").src = "img/sqrs/blSqr.png"
};};};
function asqrI7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr207").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr207").src = "img/sqrs/blSqr.png"
};};};
function asqrI8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr208").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr208").src = "img/sqrs/blSqr.png"
};};};
function asqrI9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr209").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr209").src = "img/sqrs/blSqr.png"
};};};
function asqrI10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr210").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr210").src = "img/sqrs/blSqr.png"
};};};
function asqrI11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr211").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr211").src = "img/sqrs/blSqr.png"
};};};
function asqrI12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr212").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr212").src = "img/sqrs/blSqr.png"
};};};
function asqrI13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr213").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr213").src = "img/sqrs/blSqr.png"
};};};
function asqrI14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr214").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr214").src = "img/sqrs/blSqr.png"
};};};
function asqrI15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr215").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr215").src = "img/sqrs/blSqr.png"
};};};
function asqrI16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr216").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr216").src = "img/sqrs/blSqr.png"
};};};
function asqrI17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr217").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr217").src = "img/sqrs/blSqr.png"
};};};
function asqrI18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr218").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr218").src = "img/sqrs/blSqr.png"
};};};
function asqrI19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr219").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr219").src = "img/sqrs/blSqr.png"
};};};
function asqrI20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr220").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr220").src = "img/sqrs/blSqr.png"
};};};
function asqrI21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr221").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr221").src = "img/sqrs/blSqr.png"
};};};
function asqrI22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr222").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr222").src = "img/sqrs/blSqr.png"
};};};
function asqrI23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr223").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr223").src = "img/sqrs/blSqr.png"
};};};
function asqrI24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr224").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr224").src = "img/sqrs/blSqr.png"
};};};
function asqrI25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr225").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr225").src = "img/sqrs/blSqr.png"
};};};
function asqrJ1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr226").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr226").src = "img/sqrs/blSqr.png"
};};};
function asqrJ2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr227").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr227").src = "img/sqrs/blSqr.png"
};};};
function asqrJ3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr228").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr228").src = "img/sqrs/blSqr.png"
};};};
function asqrJ4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr229").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr229").src = "img/sqrs/blSqr.png"
};};};
function asqrJ5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr230").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr230").src = "img/sqrs/blSqr.png"
};};};
function asqrJ6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr231").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr231").src = "img/sqrs/blSqr.png"
};};};
function asqrJ7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr232").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr232").src = "img/sqrs/blSqr.png"
};};};
function asqrJ8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr233").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr233").src = "img/sqrs/blSqr.png"
};};};
function asqrJ9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr234").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr234").src = "img/sqrs/blSqr.png"
};};};
function asqrJ10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr235").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr235").src = "img/sqrs/blSqr.png"
};};};
function asqrJ11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr236").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr236").src = "img/sqrs/blSqr.png"
};};};
function asqrJ12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr237").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr237").src = "img/sqrs/blSqr.png"
};};};
function asqrJ13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr238").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr238").src = "img/sqrs/blSqr.png"
};};};
function asqrJ14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr239").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr239").src = "img/sqrs/blSqr.png"
};};};
function asqrJ15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr240").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr240").src = "img/sqrs/blSqr.png"
};};};
function asqrJ16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr241").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr241").src = "img/sqrs/blSqr.png"
};};};
function asqrJ17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr242").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr242").src = "img/sqrs/blSqr.png"
};};};
function asqrJ18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr243").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr243").src = "img/sqrs/blSqr.png"
};};};
function asqrJ19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr244").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr244").src = "img/sqrs/blSqr.png"
};};};
function asqrJ20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr245").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr245").src = "img/sqrs/blSqr.png"
};};};
function asqrJ21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr246").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr246").src = "img/sqrs/blSqr.png"
};};};
function asqrJ22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr247").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr247").src = "img/sqrs/blSqr.png"
};};};
function asqrJ23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr248").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr248").src = "img/sqrs/blSqr.png"
};};};
function asqrJ24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr249").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr249").src = "img/sqrs/blSqr.png"
};};};
function asqrJ25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr250").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr250").src = "img/sqrs/blSqr.png"
};};};
function asqrK1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr251").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr251").src = "img/sqrs/blSqr.png"
};};};
function asqrK2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr252").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr252").src = "img/sqrs/blSqr.png"
};};};
function asqrK3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr253").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr253").src = "img/sqrs/blSqr.png"
};};};
function asqrK4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr254").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr254").src = "img/sqrs/blSqr.png"
};};};
function asqrK5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr255").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr255").src = "img/sqrs/blSqr.png"
};};};
function asqrK6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr256").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr256").src = "img/sqrs/blSqr.png"
};};};
function asqrK7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr257").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr257").src = "img/sqrs/blSqr.png"
};};};
function asqrK8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr258").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr258").src = "img/sqrs/blSqr.png"
};};};
function asqrK9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr259").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr259").src = "img/sqrs/blSqr.png"
};};};
function asqrK10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr260").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr260").src = "img/sqrs/blSqr.png"
};};};
function asqrK11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr261").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr261").src = "img/sqrs/blSqr.png"
};};};
function asqrK12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr262").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr262").src = "img/sqrs/blSqr.png"
};};};
function asqrK13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr263").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr263").src = "img/sqrs/blSqr.png"
};};};
function asqrK14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr264").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr264").src = "img/sqrs/blSqr.png"
};};};
function asqrK15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr265").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr265").src = "img/sqrs/blSqr.png"
};};};
function asqrK16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr266").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr266").src = "img/sqrs/blSqr.png"
};};};
function asqrK17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr267").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr267").src = "img/sqrs/blSqr.png"
};};};
function asqrK18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr268").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr268").src = "img/sqrs/blSqr.png"
};};};
function asqrK19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr269").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr269").src = "img/sqrs/blSqr.png"
};};};
function asqrK20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr270").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr270").src = "img/sqrs/blSqr.png"
};};};
function asqrK21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr271").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr271").src = "img/sqrs/blSqr.png"
};};};
function asqrK22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr272").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr272").src = "img/sqrs/blSqr.png"
};};};
function asqrK23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr273").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr273").src = "img/sqrs/blSqr.png"
};};};
function asqrK24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr274").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr274").src = "img/sqrs/blSqr.png"
};};};
function asqrK25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr275").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr275").src = "img/sqrs/blSqr.png"
};};};
function asqrL1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr276").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr276").src = "img/sqrs/blSqr.png"
};};};
function asqrL2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr277").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr277").src = "img/sqrs/blSqr.png"
};};};
function asqrL3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr278").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr278").src = "img/sqrs/blSqr.png"
};};};
function asqrL4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr279").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr279").src = "img/sqrs/blSqr.png"
};};};
function asqrL5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr280").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr280").src = "img/sqrs/blSqr.png"
};};};
function asqrL6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr281").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr281").src = "img/sqrs/blSqr.png"
};};};
function asqrL7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr282").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr282").src = "img/sqrs/blSqr.png"
};};};
function asqrL8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr283").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr283").src = "img/sqrs/blSqr.png"
};};};
function asqrL9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr284").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr284").src = "img/sqrs/blSqr.png"
};};};
function asqrL10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr285").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr285").src = "img/sqrs/blSqr.png"
};};};
function asqrL11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr286").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr286").src = "img/sqrs/blSqr.png"
};};};
function asqrL12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr287").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr287").src = "img/sqrs/blSqr.png"
};};};
function asqrL13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr288").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr288").src = "img/sqrs/blSqr.png"
};};};
function asqrL14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr289").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr289").src = "img/sqrs/blSqr.png"
};};};
function asqrL15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr290").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr290").src = "img/sqrs/blSqr.png"
};};};
function asqrL16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr291").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr291").src = "img/sqrs/blSqr.png"
};};};
function asqrL17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr292").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr292").src = "img/sqrs/blSqr.png"
};};};
function asqrL18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr293").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr293").src = "img/sqrs/blSqr.png"
};};};
function asqrL19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr294").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr294").src = "img/sqrs/blSqr.png"
};};};
function asqrL20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr295").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr295").src = "img/sqrs/blSqr.png"
};};};
function asqrL21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr296").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr296").src = "img/sqrs/blSqr.png"
};};};
function asqrL22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr297").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr297").src = "img/sqrs/blSqr.png"
};};};
function asqrL23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr298").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr298").src = "img/sqrs/blSqr.png"
};};};
function asqrL24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr299").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr299").src = "img/sqrs/blSqr.png"
};};};
function asqrL25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr300").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr300").src = "img/sqrs/blSqr.png"
};};};
function asqrM1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr301").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr301").src = "img/sqrs/blSqr.png"
};};};
function asqrM2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr302").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr302").src = "img/sqrs/blSqr.png"
};};};
function asqrM3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr303").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr303").src = "img/sqrs/blSqr.png"
};};};
function asqrM4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr304").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr304").src = "img/sqrs/blSqr.png"
};};};
function asqrM5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr305").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr305").src = "img/sqrs/blSqr.png"
};};};
function asqrM6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr306").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr306").src = "img/sqrs/blSqr.png"
};};};
function asqrM7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr307").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr307").src = "img/sqrs/blSqr.png"
};};};
function asqrM8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr308").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr308").src = "img/sqrs/blSqr.png"
};};};
function asqrM9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr309").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr309").src = "img/sqrs/blSqr.png"
};};};
function asqrM10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr310").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr310").src = "img/sqrs/blSqr.png"
};};};
function asqrM11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr311").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr311").src = "img/sqrs/blSqr.png"
};};};
function asqrM12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr312").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr312").src = "img/sqrs/blSqr.png"
};};};
function asqrM13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr313").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr313").src = "img/sqrs/blSqr.png"
};};};
function asqrM14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr314").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr314").src = "img/sqrs/blSqr.png"
};};};
function asqrM15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr315").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr315").src = "img/sqrs/blSqr.png"
};};};
function asqrM16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr316").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr316").src = "img/sqrs/blSqr.png"
};};};
function asqrM17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr317").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr317").src = "img/sqrs/blSqr.png"
};};};
function asqrM18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr318").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr318").src = "img/sqrs/blSqr.png"
};};};
function asqrM19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr319").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr319").src = "img/sqrs/blSqr.png"
};};};
function asqrM20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr320").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr320").src = "img/sqrs/blSqr.png"
};};};
function asqrM21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr321").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr321").src = "img/sqrs/blSqr.png"
};};};
function asqrM22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr322").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr322").src = "img/sqrs/blSqr.png"
};};};
function asqrM23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr323").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr323").src = "img/sqrs/blSqr.png"
};};};
function asqrM24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr324").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr324").src = "img/sqrs/blSqr.png"
};};};
function asqrM25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr325").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr325").src = "img/sqrs/blSqr.png"
};};};
function asqrN1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr326").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr326").src = "img/sqrs/blSqr.png"
};};};
function asqrN2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr327").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr327").src = "img/sqrs/blSqr.png"
};};};
function asqrN3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr328").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr328").src = "img/sqrs/blSqr.png"
};};};
function asqrN4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr329").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr329").src = "img/sqrs/blSqr.png"
};};};
function asqrN5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr330").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr330").src = "img/sqrs/blSqr.png"
};};};
function asqrN6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr331").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr331").src = "img/sqrs/blSqr.png"
};};};
function asqrN7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr332").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr332").src = "img/sqrs/blSqr.png"
};};};
function asqrN8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr333").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr333").src = "img/sqrs/blSqr.png"
};};};
function asqrN9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr334").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr334").src = "img/sqrs/blSqr.png"
};};};
function asqrN10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr335").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr335").src = "img/sqrs/blSqr.png"
};};};
function asqrN11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr336").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr336").src = "img/sqrs/blSqr.png"
};};};
function asqrN12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr337").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr337").src = "img/sqrs/blSqr.png"
};};};
function asqrN13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr338").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr338").src = "img/sqrs/blSqr.png"
};};};
function asqrN14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr339").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr339").src = "img/sqrs/blSqr.png"
};};};
function asqrN15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr340").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr340").src = "img/sqrs/blSqr.png"
};};};
function asqrN16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr341").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr341").src = "img/sqrs/blSqr.png"
};};};
function asqrN17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr342").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr342").src = "img/sqrs/blSqr.png"
};};};
function asqrN18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr343").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr343").src = "img/sqrs/blSqr.png"
};};};
function asqrN19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr344").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr344").src = "img/sqrs/blSqr.png"
};};};
function asqrN20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr345").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr345").src = "img/sqrs/blSqr.png"
};};};
function asqrN21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr346").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr346").src = "img/sqrs/blSqr.png"
};};};
function asqrN22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr347").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr347").src = "img/sqrs/blSqr.png"
};};};
function asqrN23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr348").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr348").src = "img/sqrs/blSqr.png"
};};};
function asqrN24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr349").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr349").src = "img/sqrs/blSqr.png"
};};};
function asqrN25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr350").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr350").src = "img/sqrs/blSqr.png"
};};};
function asqrO1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr351").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr351").src = "img/sqrs/blSqr.png"
};};};
function asqrO2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr352").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr352").src = "img/sqrs/blSqr.png"
};};};
function asqrO3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr353").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr353").src = "img/sqrs/blSqr.png"
};};};
function asqrO4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr354").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr354").src = "img/sqrs/blSqr.png"
};};};
function asqrO5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr355").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr355").src = "img/sqrs/blSqr.png"
};};};
function asqrO6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr356").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr356").src = "img/sqrs/blSqr.png"
};};};
function asqrO7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr357").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr357").src = "img/sqrs/blSqr.png"
};};};
function asqrO8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr358").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr358").src = "img/sqrs/blSqr.png"
};};};
function asqrO9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr359").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr359").src = "img/sqrs/blSqr.png"
};};};
function asqrO10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr360").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr360").src = "img/sqrs/blSqr.png"
};};};
function asqrO11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr361").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr361").src = "img/sqrs/blSqr.png"
};};};
function asqrO12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr362").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr362").src = "img/sqrs/blSqr.png"
};};};
function asqrO13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr363").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr363").src = "img/sqrs/blSqr.png"
};};};
function asqrO14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr364").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr364").src = "img/sqrs/blSqr.png"
};};};
function asqrO15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr365").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr365").src = "img/sqrs/blSqr.png"
};};};
function asqrO16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr366").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr366").src = "img/sqrs/blSqr.png"
};};};
function asqrO17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr367").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr367").src = "img/sqrs/blSqr.png"
};};};
function asqrO18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr368").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr368").src = "img/sqrs/blSqr.png"
};};};
function asqrO19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr369").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr369").src = "img/sqrs/blSqr.png"
};};};
function asqrO20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr370").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr370").src = "img/sqrs/blSqr.png"
};};};
function asqrO21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr371").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr371").src = "img/sqrs/blSqr.png"
};};};
function asqrO22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr372").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr372").src = "img/sqrs/blSqr.png"
};};};
function asqrO23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr373").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr373").src = "img/sqrs/blSqr.png"
};};};
function asqrO24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr374").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr374").src = "img/sqrs/blSqr.png"
};};};
function asqrO25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr375").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr375").src = "img/sqrs/blSqr.png"
};};};
function asqrP1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr376").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr376").src = "img/sqrs/blSqr.png"
};};};
function asqrP2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr377").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr377").src = "img/sqrs/blSqr.png"
};};};
function asqrP3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr378").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr378").src = "img/sqrs/blSqr.png"
};};};
function asqrP4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr379").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr379").src = "img/sqrs/blSqr.png"
};};};
function asqrP5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr380").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr380").src = "img/sqrs/blSqr.png"
};};};
function asqrP6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr381").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr381").src = "img/sqrs/blSqr.png"
};};};
function asqrP7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr382").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr382").src = "img/sqrs/blSqr.png"
};};};
function asqrP8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr383").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr383").src = "img/sqrs/blSqr.png"
};};};
function asqrP9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr384").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr384").src = "img/sqrs/blSqr.png"
};};};
function asqrP10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr385").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr385").src = "img/sqrs/blSqr.png"
};};};
function asqrP11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr386").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr386").src = "img/sqrs/blSqr.png"
};};};
function asqrP12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr387").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr387").src = "img/sqrs/blSqr.png"
};};};
function asqrP13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr388").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr388").src = "img/sqrs/blSqr.png"
};};};
function asqrP14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr389").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr389").src = "img/sqrs/blSqr.png"
};};};
function asqrP15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr390").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr390").src = "img/sqrs/blSqr.png"
};};};
function asqrP16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr391").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr391").src = "img/sqrs/blSqr.png"
};};};
function asqrP17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr392").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr392").src = "img/sqrs/blSqr.png"
};};};
function asqrP18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr393").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr393").src = "img/sqrs/blSqr.png"
};};};
function asqrP19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr394").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr394").src = "img/sqrs/blSqr.png"
};};};
function asqrP20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr395").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr395").src = "img/sqrs/blSqr.png"
};};};
function asqrP21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr396").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr396").src = "img/sqrs/blSqr.png"
};};};
function asqrP22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr397").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr397").src = "img/sqrs/blSqr.png"
};};};
function asqrP23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr398").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr398").src = "img/sqrs/blSqr.png"
};};};
function asqrP24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr399").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr399").src = "img/sqrs/blSqr.png"
};};};
function asqrP25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr400").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr400").src = "img/sqrs/blSqr.png"
};};};
function asqrQ1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr401").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr401").src = "img/sqrs/blSqr.png"
};};};
function asqrQ2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr402").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr402").src = "img/sqrs/blSqr.png"
};};};
function asqrQ3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr403").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr403").src = "img/sqrs/blSqr.png"
};};};
function asqrQ4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr404").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr404").src = "img/sqrs/blSqr.png"
};};};
function asqrQ5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr405").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr405").src = "img/sqrs/blSqr.png"
};};};
function asqrQ6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr406").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr406").src = "img/sqrs/blSqr.png"
};};};
function asqrQ7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr407").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr407").src = "img/sqrs/blSqr.png"
};};};
function asqrQ8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr408").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr408").src = "img/sqrs/blSqr.png"
};};};
function asqrQ9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr409").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr409").src = "img/sqrs/blSqr.png"
};};};
function asqrQ10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr410").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr410").src = "img/sqrs/blSqr.png"
};};};
function asqrQ11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr411").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr411").src = "img/sqrs/blSqr.png"
};};};
function asqrQ12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr412").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr412").src = "img/sqrs/blSqr.png"
};};};
function asqrQ13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr413").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr413").src = "img/sqrs/blSqr.png"
};};};
function asqrQ14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr414").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr414").src = "img/sqrs/blSqr.png"
};};};
function asqrQ15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr415").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr415").src = "img/sqrs/blSqr.png"
};};};
function asqrQ16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr416").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr416").src = "img/sqrs/blSqr.png"
};};};
function asqrQ17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr417").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr417").src = "img/sqrs/blSqr.png"
};};};
function asqrQ18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr418").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr418").src = "img/sqrs/blSqr.png"
};};};
function asqrQ19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr419").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr419").src = "img/sqrs/blSqr.png"
};};};
function asqrQ20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr420").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr420").src = "img/sqrs/blSqr.png"
};};};
function asqrQ21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr421").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr421").src = "img/sqrs/blSqr.png"
};};};
function asqrQ22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr422").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr422").src = "img/sqrs/blSqr.png"
};};};
function asqrQ23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr423").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr423").src = "img/sqrs/blSqr.png"
};};};
function asqrQ24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr424").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr424").src = "img/sqrs/blSqr.png"
};};};
function asqrQ25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr425").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr425").src = "img/sqrs/blSqr.png"
};};};
function asqrR1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr426").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr426").src = "img/sqrs/blSqr.png"
};};};
function asqrR2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr427").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr427").src = "img/sqrs/blSqr.png"
};};};
function asqrR3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr428").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr428").src = "img/sqrs/blSqr.png"
};};};
function asqrR4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr429").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr429").src = "img/sqrs/blSqr.png"
};};};
function asqrR5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr430").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr430").src = "img/sqrs/blSqr.png"
};};};
function asqrR6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr431").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr431").src = "img/sqrs/blSqr.png"
};};};
function asqrR7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr432").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr432").src = "img/sqrs/blSqr.png"
};};};
function asqrR8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr433").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr433").src = "img/sqrs/blSqr.png"
};};};
function asqrR9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr434").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr434").src = "img/sqrs/blSqr.png"
};};};
function asqrR10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr435").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr435").src = "img/sqrs/blSqr.png"
};};};
function asqrR11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr436").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr436").src = "img/sqrs/blSqr.png"
};};};
function asqrR12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr437").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr437").src = "img/sqrs/blSqr.png"
};};};
function asqrR13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr438").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr438").src = "img/sqrs/blSqr.png"
};};};
function asqrR14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr439").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr439").src = "img/sqrs/blSqr.png"
};};};
function asqrR15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr440").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr440").src = "img/sqrs/blSqr.png"
};};};
function asqrR16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr441").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr441").src = "img/sqrs/blSqr.png"
};};};
function asqrR17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr442").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr442").src = "img/sqrs/blSqr.png"
};};};
function asqrR18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr443").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr443").src = "img/sqrs/blSqr.png"
};};};
function asqrR19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr444").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr444").src = "img/sqrs/blSqr.png"
};};};
function asqrR20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr445").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr445").src = "img/sqrs/blSqr.png"
};};};
function asqrR21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr446").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr446").src = "img/sqrs/blSqr.png"
};};};
function asqrR22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr447").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr447").src = "img/sqrs/blSqr.png"
};};};
function asqrR23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr448").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr448").src = "img/sqrs/blSqr.png"
};};};
function asqrR24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr449").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr449").src = "img/sqrs/blSqr.png"
};};};
function asqrR25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr450").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr450").src = "img/sqrs/blSqr.png"
};};};
function asqrS1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr451").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr451").src = "img/sqrs/blSqr.png"
};};};
function asqrS2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr452").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr452").src = "img/sqrs/blSqr.png"
};};};
function asqrS3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr453").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr453").src = "img/sqrs/blSqr.png"
};};};
function asqrS4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr454").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr454").src = "img/sqrs/blSqr.png"
};};};
function asqrS5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr455").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr455").src = "img/sqrs/blSqr.png"
};};};
function asqrS6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr456").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr456").src = "img/sqrs/blSqr.png"
};};};
function asqrS7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr457").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr457").src = "img/sqrs/blSqr.png"
};};};
function asqrS8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr458").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr458").src = "img/sqrs/blSqr.png"
};};};
function asqrS9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr459").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr459").src = "img/sqrs/blSqr.png"
};};};
function asqrS10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr460").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr460").src = "img/sqrs/blSqr.png"
};};};
function asqrS11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr461").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr461").src = "img/sqrs/blSqr.png"
};};};
function asqrS12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr462").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr462").src = "img/sqrs/blSqr.png"
};};};
function asqrS13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr463").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr463").src = "img/sqrs/blSqr.png"
};};};
function asqrS14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr464").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr464").src = "img/sqrs/blSqr.png"
};};};
function asqrS15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr465").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr465").src = "img/sqrs/blSqr.png"
};};};
function asqrS16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr466").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr466").src = "img/sqrs/blSqr.png"
};};};
function asqrS17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr467").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr467").src = "img/sqrs/blSqr.png"
};};};
function asqrS18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr468").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr468").src = "img/sqrs/blSqr.png"
};};};
function asqrS19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr469").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr469").src = "img/sqrs/blSqr.png"
};};};
function asqrS20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr470").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr470").src = "img/sqrs/blSqr.png"
};};};
function asqrS21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr471").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr471").src = "img/sqrs/blSqr.png"
};};};
function asqrS22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr472").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr472").src = "img/sqrs/blSqr.png"
};};};
function asqrS23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr473").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr473").src = "img/sqrs/blSqr.png"
};};};
function asqrS24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr474").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr474").src = "img/sqrs/blSqr.png"
};};};
function asqrS25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr475").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr475").src = "img/sqrs/blSqr.png"
};};};
function asqrT1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr476").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr476").src = "img/sqrs/blSqr.png"
};};};
function asqrT2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr477").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr477").src = "img/sqrs/blSqr.png"
};};};
function asqrT3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr478").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr478").src = "img/sqrs/blSqr.png"
};};};
function asqrT4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr479").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr479").src = "img/sqrs/blSqr.png"
};};};
function asqrT5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr480").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr480").src = "img/sqrs/blSqr.png"
};};};
function asqrT6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr481").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr481").src = "img/sqrs/blSqr.png"
};};};
function asqrT7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr482").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr482").src = "img/sqrs/blSqr.png"
};};};
function asqrT8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr483").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr483").src = "img/sqrs/blSqr.png"
};};};
function asqrT9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr484").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr484").src = "img/sqrs/blSqr.png"
};};};
function asqrT10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr485").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr485").src = "img/sqrs/blSqr.png"
};};};
function asqrT11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr486").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr486").src = "img/sqrs/blSqr.png"
};};};
function asqrT12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr487").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr487").src = "img/sqrs/blSqr.png"
};};};
function asqrT13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr488").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr488").src = "img/sqrs/blSqr.png"
};};};
function asqrT14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr489").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr489").src = "img/sqrs/blSqr.png"
};};};
function asqrT15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr490").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr490").src = "img/sqrs/blSqr.png"
};};};
function asqrT16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr491").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr491").src = "img/sqrs/blSqr.png"
};};};
function asqrT17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr492").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr492").src = "img/sqrs/blSqr.png"
};};};
function asqrT18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr493").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr493").src = "img/sqrs/blSqr.png"
};};};
function asqrT19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr494").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr494").src = "img/sqrs/blSqr.png"
};};};
function asqrT20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr495").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr495").src = "img/sqrs/blSqr.png"
};};};
function asqrT21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr496").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr496").src = "img/sqrs/blSqr.png"
};};};
function asqrT22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr497").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr497").src = "img/sqrs/blSqr.png"
};};};
function asqrT23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr498").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr498").src = "img/sqrs/blSqr.png"
};};};
function asqrT24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr499").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr499").src = "img/sqrs/blSqr.png"
};};};
function asqrT25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr500").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr500").src = "img/sqrs/blSqr.png"
};};};
function asqrU1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr501").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr501").src = "img/sqrs/blSqr.png"
};};};
function asqrU2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr502").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr502").src = "img/sqrs/blSqr.png"
};};};
function asqrU3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr503").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr503").src = "img/sqrs/blSqr.png"
};};};
function asqrU4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr504").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr504").src = "img/sqrs/blSqr.png"
};};};
function asqrU5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr505").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr505").src = "img/sqrs/blSqr.png"
};};};
function asqrU6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr506").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr506").src = "img/sqrs/blSqr.png"
};};};
function asqrU7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr507").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr507").src = "img/sqrs/blSqr.png"
};};};
function asqrU8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr508").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr508").src = "img/sqrs/blSqr.png"
};};};
function asqrU9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr509").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr509").src = "img/sqrs/blSqr.png"
};};};
function asqrU10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr510").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr510").src = "img/sqrs/blSqr.png"
};};};
function asqrU11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr511").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr511").src = "img/sqrs/blSqr.png"
};};};
function asqrU12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr512").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr512").src = "img/sqrs/blSqr.png"
};};};
function asqrU13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr513").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr513").src = "img/sqrs/blSqr.png"
};};};
function asqrU14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr514").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr514").src = "img/sqrs/blSqr.png"
};};};
function asqrU15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr515").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr515").src = "img/sqrs/blSqr.png"
};};};
function asqrU16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr516").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr516").src = "img/sqrs/blSqr.png"
};};};
function asqrU17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr517").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr517").src = "img/sqrs/blSqr.png"
};};};
function asqrU18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr518").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr518").src = "img/sqrs/blSqr.png"
};};};
function asqrU19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr519").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr519").src = "img/sqrs/blSqr.png"
};};};
function asqrU20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr520").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr520").src = "img/sqrs/blSqr.png"
};};};
function asqrU21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr521").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr521").src = "img/sqrs/blSqr.png"
};};};
function asqrU22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr522").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr522").src = "img/sqrs/blSqr.png"
};};};
function asqrU23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr523").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr523").src = "img/sqrs/blSqr.png"
};};};
function asqrU24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr524").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr524").src = "img/sqrs/blSqr.png"
};};};
function asqrU25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr525").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr525").src = "img/sqrs/blSqr.png"
};};};
function asqrV1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr526").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr526").src = "img/sqrs/blSqr.png"
};};};
function asqrV2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr527").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr527").src = "img/sqrs/blSqr.png"
};};};
function asqrV3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr528").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr528").src = "img/sqrs/blSqr.png"
};};};
function asqrV4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr529").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr529").src = "img/sqrs/blSqr.png"
};};};
function asqrV5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr530").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr530").src = "img/sqrs/blSqr.png"
};};};
function asqrV6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr531").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr531").src = "img/sqrs/blSqr.png"
};};};
function asqrV7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr532").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr532").src = "img/sqrs/blSqr.png"
};};};
function asqrV8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr533").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr533").src = "img/sqrs/blSqr.png"
};};};
function asqrV9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr534").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr534").src = "img/sqrs/blSqr.png"
};};};
function asqrV10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr535").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr535").src = "img/sqrs/blSqr.png"
};};};
function asqrV11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr536").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr536").src = "img/sqrs/blSqr.png"
};};};
function asqrV12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr537").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr537").src = "img/sqrs/blSqr.png"
};};};
function asqrV13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr538").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr538").src = "img/sqrs/blSqr.png"
};};};
function asqrV14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr539").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr539").src = "img/sqrs/blSqr.png"
};};};
function asqrV15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr540").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr540").src = "img/sqrs/blSqr.png"
};};};
function asqrV16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr541").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr541").src = "img/sqrs/blSqr.png"
};};};
function asqrV17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr542").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr542").src = "img/sqrs/blSqr.png"
};};};
function asqrV18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr543").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr543").src = "img/sqrs/blSqr.png"
};};};
function asqrV19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr544").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr544").src = "img/sqrs/blSqr.png"
};};};
function asqrV20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr545").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr545").src = "img/sqrs/blSqr.png"
};};};
function asqrV21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr546").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr546").src = "img/sqrs/blSqr.png"
};};};
function asqrV22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr547").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr547").src = "img/sqrs/blSqr.png"
};};};
function asqrV23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr548").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr548").src = "img/sqrs/blSqr.png"
};};};
function asqrV24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr549").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr549").src = "img/sqrs/blSqr.png"
};};};
function asqrV25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr550").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr550").src = "img/sqrs/blSqr.png"
};};};
function asqrW1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr551").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr551").src = "img/sqrs/blSqr.png"
};};};
function asqrW2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr552").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr552").src = "img/sqrs/blSqr.png"
};};};
function asqrW3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr553").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr553").src = "img/sqrs/blSqr.png"
};};};
function asqrW4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr554").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr554").src = "img/sqrs/blSqr.png"
};};};
function asqrW5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr555").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr555").src = "img/sqrs/blSqr.png"
};};};
function asqrW6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr556").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr556").src = "img/sqrs/blSqr.png"
};};};
function asqrW7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr557").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr557").src = "img/sqrs/blSqr.png"
};};};
function asqrW8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr558").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr558").src = "img/sqrs/blSqr.png"
};};};
function asqrW9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr559").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr559").src = "img/sqrs/blSqr.png"
};};};
function asqrW10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr560").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr560").src = "img/sqrs/blSqr.png"
};};};
function asqrW11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr561").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr561").src = "img/sqrs/blSqr.png"
};};};
function asqrW12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr562").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr562").src = "img/sqrs/blSqr.png"
};};};
function asqrW13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr563").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr563").src = "img/sqrs/blSqr.png"
};};};
function asqrW14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr564").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr564").src = "img/sqrs/blSqr.png"
};};};
function asqrW15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr565").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr565").src = "img/sqrs/blSqr.png"
};};};
function asqrW16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr566").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr566").src = "img/sqrs/blSqr.png"
};};};
function asqrW17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr567").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr567").src = "img/sqrs/blSqr.png"
};};};
function asqrW18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr568").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr568").src = "img/sqrs/blSqr.png"
};};};
function asqrW19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr569").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr569").src = "img/sqrs/blSqr.png"
};};};
function asqrW20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr570").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr570").src = "img/sqrs/blSqr.png"
};};};
function asqrW21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr571").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr571").src = "img/sqrs/blSqr.png"
};};};
function asqrW22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr572").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr572").src = "img/sqrs/blSqr.png"
};};};
function asqrW23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr573").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr573").src = "img/sqrs/blSqr.png"
};};};
function asqrW24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr574").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr574").src = "img/sqrs/blSqr.png"
};};};
function asqrW25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr575").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr575").src = "img/sqrs/blSqr.png"
};};};
function asqrX1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr576").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr576").src = "img/sqrs/blSqr.png"
};};};
function asqrX2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr577").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr577").src = "img/sqrs/blSqr.png"
};};};
function asqrX3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr578").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr578").src = "img/sqrs/blSqr.png"
};};};
function asqrX4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr579").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr579").src = "img/sqrs/blSqr.png"
};};};
function asqrX5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr580").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr580").src = "img/sqrs/blSqr.png"
};};};
function asqrX6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr581").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr581").src = "img/sqrs/blSqr.png"
};};};
function asqrX7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr582").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr582").src = "img/sqrs/blSqr.png"
};};};
function asqrX8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr583").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr583").src = "img/sqrs/blSqr.png"
};};};
function asqrX9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr584").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr584").src = "img/sqrs/blSqr.png"
};};};
function asqrX10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr585").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr585").src = "img/sqrs/blSqr.png"
};};};
function asqrX11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr586").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr586").src = "img/sqrs/blSqr.png"
};};};
function asqrX12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr587").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr587").src = "img/sqrs/blSqr.png"
};};};
function asqrX13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr588").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr588").src = "img/sqrs/blSqr.png"
};};};
function asqrX14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr589").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr589").src = "img/sqrs/blSqr.png"
};};};
function asqrX15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr590").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr590").src = "img/sqrs/blSqr.png"
};};};
function asqrX16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr591").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr591").src = "img/sqrs/blSqr.png"
};};};
function asqrX17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr592").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr592").src = "img/sqrs/blSqr.png"
};};};
function asqrX18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr593").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr593").src = "img/sqrs/blSqr.png"
};};};
function asqrX19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr594").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr594").src = "img/sqrs/blSqr.png"
};};};
function asqrX20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr595").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr595").src = "img/sqrs/blSqr.png"
};};};
function asqrX21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr596").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr596").src = "img/sqrs/blSqr.png"
};};};
function asqrX22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr597").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr597").src = "img/sqrs/blSqr.png"
};};};
function asqrX23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr598").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr598").src = "img/sqrs/blSqr.png"
};};};
function asqrX24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr599").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr599").src = "img/sqrs/blSqr.png"
};};};
function asqrX25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr600").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr600").src = "img/sqrs/blSqr.png"
};};};
function asqrY1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr601").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr601").src = "img/sqrs/blSqr.png"
};};};
function asqrY2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr602").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr602").src = "img/sqrs/blSqr.png"
};};};
function asqrY3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr603").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr603").src = "img/sqrs/blSqr.png"
};};};
function asqrY4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr604").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr604").src = "img/sqrs/blSqr.png"
};};};
function asqrY5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr605").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr605").src = "img/sqrs/blSqr.png"
};};};
function asqrY6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr606").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr606").src = "img/sqrs/blSqr.png"
};};};
function asqrY7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr607").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr607").src = "img/sqrs/blSqr.png"
};};};
function asqrY8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr608").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr608").src = "img/sqrs/blSqr.png"
};};};
function asqrY9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr609").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr609").src = "img/sqrs/blSqr.png"
};};};
function asqrY10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr610").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr610").src = "img/sqrs/blSqr.png"
};};};
function asqrY11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr611").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr611").src = "img/sqrs/blSqr.png"
};};};
function asqrY12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr612").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr612").src = "img/sqrs/blSqr.png"
};};};
function asqrY13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr613").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr613").src = "img/sqrs/blSqr.png"
};};};
function asqrY14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr614").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr614").src = "img/sqrs/blSqr.png"
};};};
function asqrY15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr615").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr615").src = "img/sqrs/blSqr.png"
};};};
function asqrY16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr616").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr616").src = "img/sqrs/blSqr.png"
};};};
function asqrY17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr617").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr617").src = "img/sqrs/blSqr.png"
};};};
function asqrY18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr618").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr618").src = "img/sqrs/blSqr.png"
};};};
function asqrY19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr619").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr619").src = "img/sqrs/blSqr.png"
};};};
function asqrY20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr620").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr620").src = "img/sqrs/blSqr.png"
};};};
function asqrY21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr621").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr621").src = "img/sqrs/blSqr.png"
};};};
function asqrY22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr622").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr622").src = "img/sqrs/blSqr.png"
};};};
function asqrY23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr623").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr623").src = "img/sqrs/blSqr.png"
};};};
function asqrY24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr624").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr624").src = "img/sqrs/blSqr.png"
};};};
function asqrY25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("imgSqr625").src = "img/sqrs/wSqr.png") {
    document.getElementById("imgSqr625").src = "img/sqrs/blSqr.png"
};};};