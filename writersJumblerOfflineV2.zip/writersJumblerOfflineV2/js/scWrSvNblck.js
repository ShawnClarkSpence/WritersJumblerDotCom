function square1(){
    var sQz0 = document.getElementById("imgSqr1").src;
    valueSave1 = 'zSqrArtSpecz0';
    localStorage.setItem(valueSave1, sQz0);
};

function square2(){
    var sQz1 = document.getElementById("imgSqr2").src;
    valueSave2 = 'zSqrArtSpecz1';
    localStorage.setItem(valueSave2, sQz1);
};

function square3(){
    var sQz2 = document.getElementById("imgSqr3").src;
    valueSave3 = 'zSqrArtSpecz2';
    localStorage.setItem(valueSave3, sQz2);
};

function square4(){
    var sQz3 = document.getElementById("imgSqr4").src;
    valueSave4 = 'zSqrArtSpecz3';
    localStorage.setItem(valueSave4, sQz3);
};

function square5(){
    var sQz4 = document.getElementById("imgSqr5").src;
    valueSave5 = 'zSqrArtSpecz4';
    localStorage.setItem(valueSave5, sQz4);
};

function square6(){
    var sQz5 = document.getElementById("imgSqr6").src;
    valueSave6 = 'zSqrArtSpecz5';
    localStorage.setItem(valueSave6, sQz5);
};

function square7(){
    var sQz6 = document.getElementById("imgSqr7").src;
    valueSave7 = 'zSqrArtSpecz6';
    localStorage.setItem(valueSave7, sQz6);
};

function square8(){
    var sQz7 = document.getElementById("imgSqr8").src;
    valueSave8 = 'zSqrArtSpecz7';
    localStorage.setItem(valueSave8, sQz7);
};

function square9(){
    var sQz8 = document.getElementById("imgSqr9").src;
    valueSave9 = 'zSqrArtSpecz8';
    localStorage.setItem(valueSave9, sQz8);
};

function square10(){
    var sQz9 = document.getElementById("imgSqr10").src;
    valueSave10 = 'zSqrArtSpecz9';
    localStorage.setItem(valueSave10, sQz9);
};

function square11(){
    var sQz10 = document.getElementById("imgSqr11").src;
    valueSave11 = 'zSqrArtSpecz10';
    localStorage.setItem(valueSave11, sQz10);
};

function square12(){
    var sQz11 = document.getElementById("imgSqr12").src;
    valueSave12 = 'zSqrArtSpecz11';
    localStorage.setItem(valueSave12, sQz11);
};

function square13(){
    var sQz12 = document.getElementById("imgSqr13").src;
    valueSave13 = 'zSqrArtSpecz12';
    localStorage.setItem(valueSave13, sQz12);
};

function square14(){
    var sQz13 = document.getElementById("imgSqr14").src;
    valueSave14 = 'zSqrArtSpecz13';
    localStorage.setItem(valueSave14, sQz13);
};

function square15(){
    var sQz14 = document.getElementById("imgSqr15").src;
    valueSave15 = 'zSqrArtSpecz14';
    localStorage.setItem(valueSave15, sQz14);
};

function square16(){
    var sQz15 = document.getElementById("imgSqr16").src;
    valueSave16 = 'zSqrArtSpecz15';
    localStorage.setItem(valueSave16, sQz15);
};

function square17(){
    var sQz16 = document.getElementById("imgSqr17").src;
    valueSave17 = 'zSqrArtSpecz16';
    localStorage.setItem(valueSave17, sQz16);
};

function square18(){
    var sQz17 = document.getElementById("imgSqr18").src;
    valueSave18 = 'zSqrArtSpecz17';
    localStorage.setItem(valueSave18, sQz17);
};

function square19(){
    var sQz18 = document.getElementById("imgSqr19").src;
    valueSave19 = 'zSqrArtSpecz18';
    localStorage.setItem(valueSave19, sQz18);
};

function square20(){
    var sQz19 = document.getElementById("imgSqr20").src;
    valueSave20 = 'zSqrArtSpecz19';
    localStorage.setItem(valueSave20, sQz19);
};

function square21(){
    var sQz20 = document.getElementById("imgSqr21").src;
    valueSave21 = 'zSqrArtSpecz20';
    localStorage.setItem(valueSave21, sQz20);
};

function square22(){
    var sQz21 = document.getElementById("imgSqr22").src;
    valueSave22 = 'zSqrArtSpecz21';
    localStorage.setItem(valueSave22, sQz21);
};

function square23(){
    var sQz22 = document.getElementById("imgSqr23").src;
    valueSave23 = 'zSqrArtSpecz22';
    localStorage.setItem(valueSave23, sQz22);
};

function square24(){
    var sQz23 = document.getElementById("imgSqr24").src;
    valueSave24 = 'zSqrArtSpecz23';
    localStorage.setItem(valueSave24, sQz23);
};

function square25(){
    var sQz24 = document.getElementById("imgSqr25").src;
    valueSave25 = 'zSqrArtSpecz24';
    localStorage.setItem(valueSave25, sQz24);
};

function square26(){
    var sQz25 = document.getElementById("imgSqr26").src;
    valueSave26 = 'zSqrArtSpecz25';
    localStorage.setItem(valueSave26, sQz25);
};

function square27(){
    var sQz26 = document.getElementById("imgSqr27").src;
    valueSave27 = 'zSqrArtSpecz26';
    localStorage.setItem(valueSave27, sQz26);
};

function square28(){
    var sQz27 = document.getElementById("imgSqr28").src;
    valueSave28 = 'zSqrArtSpecz27';
    localStorage.setItem(valueSave28, sQz27);
};

function square29(){
    var sQz28 = document.getElementById("imgSqr29").src;
    valueSave29 = 'zSqrArtSpecz28';
    localStorage.setItem(valueSave29, sQz28);
};

function square30(){
    var sQz29 = document.getElementById("imgSqr30").src;
    valueSave30 = 'zSqrArtSpecz29';
    localStorage.setItem(valueSave30, sQz29);
};

function square31(){
    var sQz30 = document.getElementById("imgSqr31").src;
    valueSave31 = 'zSqrArtSpecz30';
    localStorage.setItem(valueSave31, sQz30);
};

function square32(){
    var sQz31 = document.getElementById("imgSqr32").src;
    valueSave32 = 'zSqrArtSpecz31';
    localStorage.setItem(valueSave32, sQz31);
};

function square33(){
    var sQz32 = document.getElementById("imgSqr33").src;
    valueSave33 = 'zSqrArtSpecz32';
    localStorage.setItem(valueSave33, sQz32);
};

function square34(){
    var sQz33 = document.getElementById("imgSqr34").src;
    valueSave34 = 'zSqrArtSpecz33';
    localStorage.setItem(valueSave34, sQz33);
};

function square35(){
    var sQz34 = document.getElementById("imgSqr35").src;
    valueSave35 = 'zSqrArtSpecz34';
    localStorage.setItem(valueSave35, sQz34);
};

function square36(){
    var sQz35 = document.getElementById("imgSqr36").src;
    valueSave36 = 'zSqrArtSpecz35';
    localStorage.setItem(valueSave36, sQz35);
};

function square37(){
    var sQz36 = document.getElementById("imgSqr37").src;
    valueSave37 = 'zSqrArtSpecz36';
    localStorage.setItem(valueSave37, sQz36);
};

function square38(){
    var sQz37 = document.getElementById("imgSqr38").src;
    valueSave38 = 'zSqrArtSpecz37';
    localStorage.setItem(valueSave38, sQz37);
};

function square39(){
    var sQz38 = document.getElementById("imgSqr39").src;
    valueSave39 = 'zSqrArtSpecz38';
    localStorage.setItem(valueSave39, sQz38);
};

function square40(){
    var sQz39 = document.getElementById("imgSqr40").src;
    valueSave40 = 'zSqrArtSpecz39';
    localStorage.setItem(valueSave40, sQz39);
};

function square41(){
    var sQz40 = document.getElementById("imgSqr41").src;
    valueSave41 = 'zSqrArtSpecz40';
    localStorage.setItem(valueSave41, sQz40);
};

function square42(){
    var sQz41 = document.getElementById("imgSqr42").src;
    valueSave42 = 'zSqrArtSpecz41';
    localStorage.setItem(valueSave42, sQz41);
};

function square43(){
    var sQz42 = document.getElementById("imgSqr43").src;
    valueSave43 = 'zSqrArtSpecz42';
    localStorage.setItem(valueSave43, sQz42);
};

function square44(){
    var sQz43 = document.getElementById("imgSqr44").src;
    valueSave44 = 'zSqrArtSpecz43';
    localStorage.setItem(valueSave44, sQz43);
};

function square45(){
    var sQz44 = document.getElementById("imgSqr45").src;
    valueSave45 = 'zSqrArtSpecz44';
    localStorage.setItem(valueSave45, sQz44);
};

function square46(){
    var sQz45 = document.getElementById("imgSqr46").src;
    valueSave46 = 'zSqrArtSpecz45';
    localStorage.setItem(valueSave46, sQz45);
};

function square47(){
    var sQz46 = document.getElementById("imgSqr47").src;
    valueSave47 = 'zSqrArtSpecz46';
    localStorage.setItem(valueSave47, sQz46);
};

function square48(){
    var sQz47 = document.getElementById("imgSqr48").src;
    valueSave48 = 'zSqrArtSpecz47';
    localStorage.setItem(valueSave48, sQz47);
};

function square49(){
    var sQz48 = document.getElementById("imgSqr49").src;
    valueSave49 = 'zSqrArtSpecz48';
    localStorage.setItem(valueSave49, sQz48);
};

function square50(){
    var sQz49 = document.getElementById("imgSqr50").src;
    valueSave50 = 'zSqrArtSpecz49';
    localStorage.setItem(valueSave50, sQz49);
};

function square51(){
    var sQz50 = document.getElementById("imgSqr51").src;
    valueSave51 = 'zSqrArtSpecz50';
    localStorage.setItem(valueSave51, sQz50);
};

function square52(){
    var sQz51 = document.getElementById("imgSqr52").src;
    valueSave52 = 'zSqrArtSpecz51';
    localStorage.setItem(valueSave52, sQz51);
};

function square53(){
    var sQz52 = document.getElementById("imgSqr53").src;
    valueSave53 = 'zSqrArtSpecz52';
    localStorage.setItem(valueSave53, sQz52);
};

function square54(){
    var sQz53 = document.getElementById("imgSqr54").src;
    valueSave54 = 'zSqrArtSpecz53';
    localStorage.setItem(valueSave54, sQz53);
};

function square55(){
    var sQz54 = document.getElementById("imgSqr55").src;
    valueSave55 = 'zSqrArtSpecz54';
    localStorage.setItem(valueSave55, sQz54);
};

function square56(){
    var sQz55 = document.getElementById("imgSqr56").src;
    valueSave56 = 'zSqrArtSpecz55';
    localStorage.setItem(valueSave56, sQz55);
};

function square57(){
    var sQz56 = document.getElementById("imgSqr57").src;
    valueSave57 = 'zSqrArtSpecz56';
    localStorage.setItem(valueSave57, sQz56);
};

function square58(){
    var sQz57 = document.getElementById("imgSqr58").src;
    valueSave58 = 'zSqrArtSpecz57';
    localStorage.setItem(valueSave58, sQz57);
};

function square59(){
    var sQz58 = document.getElementById("imgSqr59").src;
    valueSave59 = 'zSqrArtSpecz58';
    localStorage.setItem(valueSave59, sQz58);
};

function square60(){
    var sQz59 = document.getElementById("imgSqr60").src;
    valueSave60 = 'zSqrArtSpecz59';
    localStorage.setItem(valueSave60, sQz59);
};

function square61(){
    var sQz60 = document.getElementById("imgSqr61").src;
    valueSave61 = 'zSqrArtSpecz60';
    localStorage.setItem(valueSave61, sQz60);
};

function square62(){
    var sQz61 = document.getElementById("imgSqr62").src;
    valueSave62 = 'zSqrArtSpecz61';
    localStorage.setItem(valueSave62, sQz61);
};

function square63(){
    var sQz62 = document.getElementById("imgSqr63").src;
    valueSave63 = 'zSqrArtSpecz62';
    localStorage.setItem(valueSave63, sQz62);
};

function square64(){
    var sQz63 = document.getElementById("imgSqr64").src;
    valueSave64 = 'zSqrArtSpecz63';
    localStorage.setItem(valueSave64, sQz63);
};

function square65(){
    var sQz64 = document.getElementById("imgSqr65").src;
    valueSave65 = 'zSqrArtSpecz64';
    localStorage.setItem(valueSave65, sQz64);
};

function square66(){
    var sQz65 = document.getElementById("imgSqr66").src;
    valueSave66 = 'zSqrArtSpecz65';
    localStorage.setItem(valueSave66, sQz65);
};

function square67(){
    var sQz66 = document.getElementById("imgSqr67").src;
    valueSave67 = 'zSqrArtSpecz66';
    localStorage.setItem(valueSave67, sQz66);
};

function square68(){
    var sQz67 = document.getElementById("imgSqr68").src;
    valueSave68 = 'zSqrArtSpecz67';
    localStorage.setItem(valueSave68, sQz67);
};

function square69(){
    var sQz68 = document.getElementById("imgSqr69").src;
    valueSave69 = 'zSqrArtSpecz68';
    localStorage.setItem(valueSave69, sQz68);
};

function square70(){
    var sQz69 = document.getElementById("imgSqr70").src;
    valueSave70 = 'zSqrArtSpecz69';
    localStorage.setItem(valueSave70, sQz69);
};

function square71(){
    var sQz70 = document.getElementById("imgSqr71").src;
    valueSave71 = 'zSqrArtSpecz70';
    localStorage.setItem(valueSave71, sQz70);
};

function square72(){
    var sQz71 = document.getElementById("imgSqr72").src;
    valueSave72 = 'zSqrArtSpecz71';
    localStorage.setItem(valueSave72, sQz71);
};

function square73(){
    var sQz72 = document.getElementById("imgSqr73").src;
    valueSave73 = 'zSqrArtSpecz72';
    localStorage.setItem(valueSave73, sQz72);
};

function square74(){
    var sQz73 = document.getElementById("imgSqr74").src;
    valueSave74 = 'zSqrArtSpecz73';
    localStorage.setItem(valueSave74, sQz73);
};

function square75(){
    var sQz74 = document.getElementById("imgSqr75").src;
    valueSave75 = 'zSqrArtSpecz74';
    localStorage.setItem(valueSave75, sQz74);
};

function square76(){
    var sQz75 = document.getElementById("imgSqr76").src;
    valueSave76 = 'zSqrArtSpecz75';
    localStorage.setItem(valueSave76, sQz75);
};

function square77(){
    var sQz76 = document.getElementById("imgSqr77").src;
    valueSave77 = 'zSqrArtSpecz76';
    localStorage.setItem(valueSave77, sQz76);
};

function square78(){
    var sQz77 = document.getElementById("imgSqr78").src;
    valueSave78 = 'zSqrArtSpecz77';
    localStorage.setItem(valueSave78, sQz77);
};

function square79(){
    var sQz78 = document.getElementById("imgSqr79").src;
    valueSave79 = 'zSqrArtSpecz78';
    localStorage.setItem(valueSave79, sQz78);
};

function square80(){
    var sQz79 = document.getElementById("imgSqr80").src;
    valueSave80 = 'zSqrArtSpecz79';
    localStorage.setItem(valueSave80, sQz79);
};

function square81(){
    var sQz80 = document.getElementById("imgSqr81").src;
    valueSave81 = 'zSqrArtSpecz80';
    localStorage.setItem(valueSave81, sQz80);
};

function square82(){
    var sQz81 = document.getElementById("imgSqr82").src;
    valueSave82 = 'zSqrArtSpecz81';
    localStorage.setItem(valueSave82, sQz81);
};

function square83(){
    var sQz82 = document.getElementById("imgSqr83").src;
    valueSave83 = 'zSqrArtSpecz82';
    localStorage.setItem(valueSave83, sQz82);
};

function square84(){
    var sQz83 = document.getElementById("imgSqr84").src;
    valueSave84 = 'zSqrArtSpecz83';
    localStorage.setItem(valueSave84, sQz83);
};

function square85(){
    var sQz84 = document.getElementById("imgSqr85").src;
    valueSave85 = 'zSqrArtSpecz84';
    localStorage.setItem(valueSave85, sQz84);
};

function square86(){
    var sQz85 = document.getElementById("imgSqr86").src;
    valueSave86 = 'zSqrArtSpecz85';
    localStorage.setItem(valueSave86, sQz85);
};

function square87(){
    var sQz86 = document.getElementById("imgSqr87").src;
    valueSave87 = 'zSqrArtSpecz86';
    localStorage.setItem(valueSave87, sQz86);
};

function square88(){
    var sQz87 = document.getElementById("imgSqr88").src;
    valueSave88 = 'zSqrArtSpecz87';
    localStorage.setItem(valueSave88, sQz87);
};

function square89(){
    var sQz88 = document.getElementById("imgSqr89").src;
    valueSave89 = 'zSqrArtSpecz88';
    localStorage.setItem(valueSave89, sQz88);
};

function square90(){
    var sQz89 = document.getElementById("imgSqr90").src;
    valueSave90 = 'zSqrArtSpecz89';
    localStorage.setItem(valueSave90, sQz89);
};

function square91(){
    var sQz90 = document.getElementById("imgSqr91").src;
    valueSave91 = 'zSqrArtSpecz90';
    localStorage.setItem(valueSave91, sQz90);
};

function square92(){
    var sQz91 = document.getElementById("imgSqr92").src;
    valueSave92 = 'zSqrArtSpecz91';
    localStorage.setItem(valueSave92, sQz91);
};

function square93(){
    var sQz92 = document.getElementById("imgSqr93").src;
    valueSave93 = 'zSqrArtSpecz92';
    localStorage.setItem(valueSave93, sQz92);
};

function square94(){
    var sQz93 = document.getElementById("imgSqr94").src;
    valueSave94 = 'zSqrArtSpecz93';
    localStorage.setItem(valueSave94, sQz93);
};

function square95(){
    var sQz94 = document.getElementById("imgSqr95").src;
    valueSave95 = 'zSqrArtSpecz94';
    localStorage.setItem(valueSave95, sQz94);
};

function square96(){
    var sQz95 = document.getElementById("imgSqr96").src;
    valueSave96 = 'zSqrArtSpecz95';
    localStorage.setItem(valueSave96, sQz95);
};

function square97(){
    var sQz96 = document.getElementById("imgSqr97").src;
    valueSave97 = 'zSqrArtSpecz96';
    localStorage.setItem(valueSave97, sQz96);
};

function square98(){
    var sQz97 = document.getElementById("imgSqr98").src;
    valueSave98 = 'zSqrArtSpecz97';
    localStorage.setItem(valueSave98, sQz97);
};

function square99(){
    var sQz98 = document.getElementById("imgSqr99").src;
    valueSave99 = 'zSqrArtSpecz98';
    localStorage.setItem(valueSave99, sQz98);
};

function square100(){
    var sQz99 = document.getElementById("imgSqr100").src;
    valueSave100 = 'zSqrArtSpecz99';
    localStorage.setItem(valueSave100, sQz99);
};

function square101(){
    var sQz100 = document.getElementById("imgSqr101").src;
    valueSave101 = 'zSqrArtSpecz100';
    localStorage.setItem(valueSave101, sQz100);
};

function square102(){
    var sQz101 = document.getElementById("imgSqr102").src;
    valueSave102 = 'zSqrArtSpecz101';
    localStorage.setItem(valueSave102, sQz101);
};

function square103(){
    var sQz102 = document.getElementById("imgSqr103").src;
    valueSave103 = 'zSqrArtSpecz102';
    localStorage.setItem(valueSave103, sQz102);
};

function square104(){
    var sQz103 = document.getElementById("imgSqr104").src;
    valueSave104 = 'zSqrArtSpecz103';
    localStorage.setItem(valueSave104, sQz103);
};

function square105(){
    var sQz104 = document.getElementById("imgSqr105").src;
    valueSave105 = 'zSqrArtSpecz104';
    localStorage.setItem(valueSave105, sQz104);
};

function square106(){
    var sQz105 = document.getElementById("imgSqr106").src;
    valueSave106 = 'zSqrArtSpecz105';
    localStorage.setItem(valueSave106, sQz105);
};

function square107(){
    var sQz106 = document.getElementById("imgSqr107").src;
    valueSave107 = 'zSqrArtSpecz106';
    localStorage.setItem(valueSave107, sQz106);
};

function square108(){
    var sQz107 = document.getElementById("imgSqr108").src;
    valueSave108 = 'zSqrArtSpecz107';
    localStorage.setItem(valueSave108, sQz107);
};

function square109(){
    var sQz108 = document.getElementById("imgSqr109").src;
    valueSave109 = 'zSqrArtSpecz108';
    localStorage.setItem(valueSave109, sQz108);
};

function square110(){
    var sQz109 = document.getElementById("imgSqr110").src;
    valueSave110 = 'zSqrArtSpecz109';
    localStorage.setItem(valueSave110, sQz109);
};

function square111(){
    var sQz110 = document.getElementById("imgSqr111").src;
    valueSave111 = 'zSqrArtSpecz110';
    localStorage.setItem(valueSave111, sQz110);
};

function square112(){
    var sQz111 = document.getElementById("imgSqr112").src;
    valueSave112 = 'zSqrArtSpecz111';
    localStorage.setItem(valueSave112, sQz111);
};

function square113(){
    var sQz112 = document.getElementById("imgSqr113").src;
    valueSave113 = 'zSqrArtSpecz112';
    localStorage.setItem(valueSave113, sQz112);
};

function square114(){
    var sQz113 = document.getElementById("imgSqr114").src;
    valueSave114 = 'zSqrArtSpecz113';
    localStorage.setItem(valueSave114, sQz113);
};

function square115(){
    var sQz114 = document.getElementById("imgSqr115").src;
    valueSave115 = 'zSqrArtSpecz114';
    localStorage.setItem(valueSave115, sQz114);
};

function square116(){
    var sQz115 = document.getElementById("imgSqr116").src;
    valueSave116 = 'zSqrArtSpecz115';
    localStorage.setItem(valueSave116, sQz115);
};

function square117(){
    var sQz116 = document.getElementById("imgSqr117").src;
    valueSave117 = 'zSqrArtSpecz116';
    localStorage.setItem(valueSave117, sQz116);
};

function square118(){
    var sQz117 = document.getElementById("imgSqr118").src;
    valueSave118 = 'zSqrArtSpecz117';
    localStorage.setItem(valueSave118, sQz117);
};

function square119(){
    var sQz118 = document.getElementById("imgSqr119").src;
    valueSave119 = 'zSqrArtSpecz118';
    localStorage.setItem(valueSave119, sQz118);
};

function square120(){
    var sQz119 = document.getElementById("imgSqr120").src;
    valueSave120 = 'zSqrArtSpecz119';
    localStorage.setItem(valueSave120, sQz119);
};

function square121(){
    var sQz120 = document.getElementById("imgSqr121").src;
    valueSave121 = 'zSqrArtSpecz120';
    localStorage.setItem(valueSave121, sQz120);
};

function square122(){
    var sQz121 = document.getElementById("imgSqr122").src;
    valueSave122 = 'zSqrArtSpecz121';
    localStorage.setItem(valueSave122, sQz121);
};

function square123(){
    var sQz122 = document.getElementById("imgSqr123").src;
    valueSave123 = 'zSqrArtSpecz122';
    localStorage.setItem(valueSave123, sQz122);
};

function square124(){
    var sQz123 = document.getElementById("imgSqr124").src;
    valueSave124 = 'zSqrArtSpecz123';
    localStorage.setItem(valueSave124, sQz123);
};

function square125(){
    var sQz124 = document.getElementById("imgSqr125").src;
    valueSave125 = 'zSqrArtSpecz124';
    localStorage.setItem(valueSave125, sQz124);
};

function square126(){
    var sQz125 = document.getElementById("imgSqr126").src;
    valueSave126 = 'zSqrArtSpecz125';
    localStorage.setItem(valueSave126, sQz125);
};

function square127(){
    var sQz126 = document.getElementById("imgSqr127").src;
    valueSave127 = 'zSqrArtSpecz126';
    localStorage.setItem(valueSave127, sQz126);
};

function square128(){
    var sQz127 = document.getElementById("imgSqr128").src;
    valueSave128 = 'zSqrArtSpecz127';
    localStorage.setItem(valueSave128, sQz127);
};

function square129(){
    var sQz128 = document.getElementById("imgSqr129").src;
    valueSave129 = 'zSqrArtSpecz128';
    localStorage.setItem(valueSave129, sQz128);
};

function square130(){
    var sQz129 = document.getElementById("imgSqr130").src;
    valueSave130 = 'zSqrArtSpecz129';
    localStorage.setItem(valueSave130, sQz129);
};

function square131(){
    var sQz130 = document.getElementById("imgSqr131").src;
    valueSave131 = 'zSqrArtSpecz130';
    localStorage.setItem(valueSave131, sQz130);
};

function square132(){
    var sQz131 = document.getElementById("imgSqr132").src;
    valueSave132 = 'zSqrArtSpecz131';
    localStorage.setItem(valueSave132, sQz131);
};

function square133(){
    var sQz132 = document.getElementById("imgSqr133").src;
    valueSave133 = 'zSqrArtSpecz132';
    localStorage.setItem(valueSave133, sQz132);
};

function square134(){
    var sQz133 = document.getElementById("imgSqr134").src;
    valueSave134 = 'zSqrArtSpecz133';
    localStorage.setItem(valueSave134, sQz133);
};

function square135(){
    var sQz134 = document.getElementById("imgSqr135").src;
    valueSave135 = 'zSqrArtSpecz134';
    localStorage.setItem(valueSave135, sQz134);
};

function square136(){
    var sQz135 = document.getElementById("imgSqr136").src;
    valueSave136 = 'zSqrArtSpecz135';
    localStorage.setItem(valueSave136, sQz135);
};

function square137(){
    var sQz136 = document.getElementById("imgSqr137").src;
    valueSave137 = 'zSqrArtSpecz136';
    localStorage.setItem(valueSave137, sQz136);
};

function square138(){
    var sQz137 = document.getElementById("imgSqr138").src;
    valueSave138 = 'zSqrArtSpecz137';
    localStorage.setItem(valueSave138, sQz137);
};

function square139(){
    var sQz138 = document.getElementById("imgSqr139").src;
    valueSave139 = 'zSqrArtSpecz138';
    localStorage.setItem(valueSave139, sQz138);
};

function square140(){
    var sQz139 = document.getElementById("imgSqr140").src;
    valueSave140 = 'zSqrArtSpecz139';
    localStorage.setItem(valueSave140, sQz139);
};

function square141(){
    var sQz140 = document.getElementById("imgSqr141").src;
    valueSave141 = 'zSqrArtSpecz140';
    localStorage.setItem(valueSave141, sQz140);
};

function square142(){
    var sQz141 = document.getElementById("imgSqr142").src;
    valueSave142 = 'zSqrArtSpecz141';
    localStorage.setItem(valueSave142, sQz141);
};

function square143(){
    var sQz142 = document.getElementById("imgSqr143").src;
    valueSave143 = 'zSqrArtSpecz142';
    localStorage.setItem(valueSave143, sQz142);
};

function square144(){
    var sQz143 = document.getElementById("imgSqr144").src;
    valueSave144 = 'zSqrArtSpecz143';
    localStorage.setItem(valueSave144, sQz143);
};

function square145(){
    var sQz144 = document.getElementById("imgSqr145").src;
    valueSave145 = 'zSqrArtSpecz144';
    localStorage.setItem(valueSave145, sQz144);
};

function square146(){
    var sQz145 = document.getElementById("imgSqr146").src;
    valueSave146 = 'zSqrArtSpecz145';
    localStorage.setItem(valueSave146, sQz145);
};

function square147(){
    var sQz146 = document.getElementById("imgSqr147").src;
    valueSave147 = 'zSqrArtSpecz146';
    localStorage.setItem(valueSave147, sQz146);
};

function square148(){
    var sQz147 = document.getElementById("imgSqr148").src;
    valueSave148 = 'zSqrArtSpecz147';
    localStorage.setItem(valueSave148, sQz147);
};

function square149(){
    var sQz148 = document.getElementById("imgSqr149").src;
    valueSave149 = 'zSqrArtSpecz148';
    localStorage.setItem(valueSave149, sQz148);
};

function square150(){
    var sQz149 = document.getElementById("imgSqr150").src;
    valueSave150 = 'zSqrArtSpecz149';
    localStorage.setItem(valueSave150, sQz149);
};

function square151(){
    var sQz150 = document.getElementById("imgSqr151").src;
    valueSave151 = 'zSqrArtSpecz150';
    localStorage.setItem(valueSave151, sQz150);
};

function square152(){
    var sQz151 = document.getElementById("imgSqr152").src;
    valueSave152 = 'zSqrArtSpecz151';
    localStorage.setItem(valueSave152, sQz151);
};

function square153(){
    var sQz152 = document.getElementById("imgSqr153").src;
    valueSave153 = 'zSqrArtSpecz152';
    localStorage.setItem(valueSave153, sQz152);
};

function square154(){
    var sQz153 = document.getElementById("imgSqr154").src;
    valueSave154 = 'zSqrArtSpecz153';
    localStorage.setItem(valueSave154, sQz153);
};

function square155(){
    var sQz154 = document.getElementById("imgSqr155").src;
    valueSave155 = 'zSqrArtSpecz154';
    localStorage.setItem(valueSave155, sQz154);
};

function square156(){
    var sQz155 = document.getElementById("imgSqr156").src;
    valueSave156 = 'zSqrArtSpecz155';
    localStorage.setItem(valueSave156, sQz155);
};

function square157(){
    var sQz156 = document.getElementById("imgSqr157").src;
    valueSave157 = 'zSqrArtSpecz156';
    localStorage.setItem(valueSave157, sQz156);
};

function square158(){
    var sQz157 = document.getElementById("imgSqr158").src;
    valueSave158 = 'zSqrArtSpecz157';
    localStorage.setItem(valueSave158, sQz157);
};

function square159(){
    var sQz158 = document.getElementById("imgSqr159").src;
    valueSave159 = 'zSqrArtSpecz158';
    localStorage.setItem(valueSave159, sQz158);
};

function square160(){
    var sQz159 = document.getElementById("imgSqr160").src;
    valueSave160 = 'zSqrArtSpecz159';
    localStorage.setItem(valueSave160, sQz159);
};

function square161(){
    var sQz160 = document.getElementById("imgSqr161").src;
    valueSave161 = 'zSqrArtSpecz160';
    localStorage.setItem(valueSave161, sQz160);
};

function square162(){
    var sQz161 = document.getElementById("imgSqr162").src;
    valueSave162 = 'zSqrArtSpecz161';
    localStorage.setItem(valueSave162, sQz161);
};

function square163(){
    var sQz162 = document.getElementById("imgSqr163").src;
    valueSave163 = 'zSqrArtSpecz162';
    localStorage.setItem(valueSave163, sQz162);
};

function square164(){
    var sQz163 = document.getElementById("imgSqr164").src;
    valueSave164 = 'zSqrArtSpecz163';
    localStorage.setItem(valueSave164, sQz163);
};

function square165(){
    var sQz164 = document.getElementById("imgSqr165").src;
    valueSave165 = 'zSqrArtSpecz164';
    localStorage.setItem(valueSave165, sQz164);
};

function square166(){
    var sQz165 = document.getElementById("imgSqr166").src;
    valueSave166 = 'zSqrArtSpecz165';
    localStorage.setItem(valueSave166, sQz165);
};

function square167(){
    var sQz166 = document.getElementById("imgSqr167").src;
    valueSave167 = 'zSqrArtSpecz166';
    localStorage.setItem(valueSave167, sQz166);
};

function square168(){
    var sQz167 = document.getElementById("imgSqr168").src;
    valueSave168 = 'zSqrArtSpecz167';
    localStorage.setItem(valueSave168, sQz167);
};

function square169(){
    var sQz168 = document.getElementById("imgSqr169").src;
    valueSave169 = 'zSqrArtSpecz168';
    localStorage.setItem(valueSave169, sQz168);
};

function square170(){
    var sQz169 = document.getElementById("imgSqr170").src;
    valueSave170 = 'zSqrArtSpecz169';
    localStorage.setItem(valueSave170, sQz169);
};

function square171(){
    var sQz170 = document.getElementById("imgSqr171").src;
    valueSave171 = 'zSqrArtSpecz170';
    localStorage.setItem(valueSave171, sQz170);
};

function square172(){
    var sQz171 = document.getElementById("imgSqr172").src;
    valueSave172 = 'zSqrArtSpecz171';
    localStorage.setItem(valueSave172, sQz171);
};

function square173(){
    var sQz172 = document.getElementById("imgSqr173").src;
    valueSave173 = 'zSqrArtSpecz172';
    localStorage.setItem(valueSave173, sQz172);
};

function square174(){
    var sQz173 = document.getElementById("imgSqr174").src;
    valueSave174 = 'zSqrArtSpecz173';
    localStorage.setItem(valueSave174, sQz173);
};

function square175(){
    var sQz174 = document.getElementById("imgSqr175").src;
    valueSave175 = 'zSqrArtSpecz174';
    localStorage.setItem(valueSave175, sQz174);
};

function square176(){
    var sQz175 = document.getElementById("imgSqr176").src;
    valueSave176 = 'zSqrArtSpecz175';
    localStorage.setItem(valueSave176, sQz175);
};

function square177(){
    var sQz176 = document.getElementById("imgSqr177").src;
    valueSave177 = 'zSqrArtSpecz176';
    localStorage.setItem(valueSave177, sQz176);
};

function square178(){
    var sQz177 = document.getElementById("imgSqr178").src;
    valueSave178 = 'zSqrArtSpecz177';
    localStorage.setItem(valueSave178, sQz177);
};

function square179(){
    var sQz178 = document.getElementById("imgSqr179").src;
    valueSave179 = 'zSqrArtSpecz178';
    localStorage.setItem(valueSave179, sQz178);
};

function square180(){
    var sQz179 = document.getElementById("imgSqr180").src;
    valueSave180 = 'zSqrArtSpecz179';
    localStorage.setItem(valueSave180, sQz179);
};

function square181(){
    var sQz180 = document.getElementById("imgSqr181").src;
    valueSave181 = 'zSqrArtSpecz180';
    localStorage.setItem(valueSave181, sQz180);
};

function square182(){
    var sQz181 = document.getElementById("imgSqr182").src;
    valueSave182 = 'zSqrArtSpecz181';
    localStorage.setItem(valueSave182, sQz181);
};

function square183(){
    var sQz182 = document.getElementById("imgSqr183").src;
    valueSave183 = 'zSqrArtSpecz182';
    localStorage.setItem(valueSave183, sQz182);
};

function square184(){
    var sQz183 = document.getElementById("imgSqr184").src;
    valueSave184 = 'zSqrArtSpecz183';
    localStorage.setItem(valueSave184, sQz183);
};

function square185(){
    var sQz184 = document.getElementById("imgSqr185").src;
    valueSave185 = 'zSqrArtSpecz184';
    localStorage.setItem(valueSave185, sQz184);
};

function square186(){
    var sQz185 = document.getElementById("imgSqr186").src;
    valueSave186 = 'zSqrArtSpecz185';
    localStorage.setItem(valueSave186, sQz185);
};

function square187(){
    var sQz186 = document.getElementById("imgSqr187").src;
    valueSave187 = 'zSqrArtSpecz186';
    localStorage.setItem(valueSave187, sQz186);
};

function square188(){
    var sQz187 = document.getElementById("imgSqr188").src;
    valueSave188 = 'zSqrArtSpecz187';
    localStorage.setItem(valueSave188, sQz187);
};

function square189(){
    var sQz188 = document.getElementById("imgSqr189").src;
    valueSave189 = 'zSqrArtSpecz188';
    localStorage.setItem(valueSave189, sQz188);
};

function square190(){
    var sQz189 = document.getElementById("imgSqr190").src;
    valueSave190 = 'zSqrArtSpecz189';
    localStorage.setItem(valueSave190, sQz189);
};

function square191(){
    var sQz190 = document.getElementById("imgSqr191").src;
    valueSave191 = 'zSqrArtSpecz190';
    localStorage.setItem(valueSave191, sQz190);
};

function square192(){
    var sQz191 = document.getElementById("imgSqr192").src;
    valueSave192 = 'zSqrArtSpecz191';
    localStorage.setItem(valueSave192, sQz191);
};

function square193(){
    var sQz192 = document.getElementById("imgSqr193").src;
    valueSave193 = 'zSqrArtSpecz192';
    localStorage.setItem(valueSave193, sQz192);
};

function square194(){
    var sQz193 = document.getElementById("imgSqr194").src;
    valueSave194 = 'zSqrArtSpecz193';
    localStorage.setItem(valueSave194, sQz193);
};

function square195(){
    var sQz194 = document.getElementById("imgSqr195").src;
    valueSave195 = 'zSqrArtSpecz194';
    localStorage.setItem(valueSave195, sQz194);
};

function square196(){
    var sQz195 = document.getElementById("imgSqr196").src;
    valueSave196 = 'zSqrArtSpecz195';
    localStorage.setItem(valueSave196, sQz195);
};

function square197(){
    var sQz196 = document.getElementById("imgSqr197").src;
    valueSave197 = 'zSqrArtSpecz196';
    localStorage.setItem(valueSave197, sQz196);
};

function square198(){
    var sQz197 = document.getElementById("imgSqr198").src;
    valueSave198 = 'zSqrArtSpecz197';
    localStorage.setItem(valueSave198, sQz197);
};

function square199(){
    var sQz198 = document.getElementById("imgSqr199").src;
    valueSave199 = 'zSqrArtSpecz198';
    localStorage.setItem(valueSave199, sQz198);
};

function square200(){
    var sQz199 = document.getElementById("imgSqr200").src;
    valueSave200 = 'zSqrArtSpecz199';
    localStorage.setItem(valueSave200, sQz199);
};

function square201(){
    var sQz200 = document.getElementById("imgSqr201").src;
    valueSave201 = 'zSqrArtSpecz200';
    localStorage.setItem(valueSave201, sQz200);
};

function square202(){
    var sQz201 = document.getElementById("imgSqr202").src;
    valueSave202 = 'zSqrArtSpecz201';
    localStorage.setItem(valueSave202, sQz201);
};

function square203(){
    var sQz202 = document.getElementById("imgSqr203").src;
    valueSave203 = 'zSqrArtSpecz202';
    localStorage.setItem(valueSave203, sQz202);
};

function square204(){
    var sQz203 = document.getElementById("imgSqr204").src;
    valueSave204 = 'zSqrArtSpecz203';
    localStorage.setItem(valueSave204, sQz203);
};

function square205(){
    var sQz204 = document.getElementById("imgSqr205").src;
    valueSave205 = 'zSqrArtSpecz204';
    localStorage.setItem(valueSave205, sQz204);
};

function square206(){
    var sQz205 = document.getElementById("imgSqr206").src;
    valueSave206 = 'zSqrArtSpecz205';
    localStorage.setItem(valueSave206, sQz205);
};

function square207(){
    var sQz206 = document.getElementById("imgSqr207").src;
    valueSave207 = 'zSqrArtSpecz206';
    localStorage.setItem(valueSave207, sQz206);
};

function square208(){
    var sQz207 = document.getElementById("imgSqr208").src;
    valueSave208 = 'zSqrArtSpecz207';
    localStorage.setItem(valueSave208, sQz207);
};

function square209(){
    var sQz208 = document.getElementById("imgSqr209").src;
    valueSave209 = 'zSqrArtSpecz208';
    localStorage.setItem(valueSave209, sQz208);
};

function square210(){
    var sQz209 = document.getElementById("imgSqr210").src;
    valueSave210 = 'zSqrArtSpecz209';
    localStorage.setItem(valueSave210, sQz209);
};

function square211(){
    var sQz210 = document.getElementById("imgSqr211").src;
    valueSave211 = 'zSqrArtSpecz210';
    localStorage.setItem(valueSave211, sQz210);
};

function square212(){
    var sQz211 = document.getElementById("imgSqr212").src;
    valueSave212 = 'zSqrArtSpecz211';
    localStorage.setItem(valueSave212, sQz211);
};

function square213(){
    var sQz212 = document.getElementById("imgSqr213").src;
    valueSave213 = 'zSqrArtSpecz212';
    localStorage.setItem(valueSave213, sQz212);
};

function square214(){
    var sQz213 = document.getElementById("imgSqr214").src;
    valueSave214 = 'zSqrArtSpecz213';
    localStorage.setItem(valueSave214, sQz213);
};

function square215(){
    var sQz214 = document.getElementById("imgSqr215").src;
    valueSave215 = 'zSqrArtSpecz214';
    localStorage.setItem(valueSave215, sQz214);
};

function square216(){
    var sQz215 = document.getElementById("imgSqr216").src;
    valueSave216 = 'zSqrArtSpecz215';
    localStorage.setItem(valueSave216, sQz215);
};

function square217(){
    var sQz216 = document.getElementById("imgSqr217").src;
    valueSave217 = 'zSqrArtSpecz216';
    localStorage.setItem(valueSave217, sQz216);
};

function square218(){
    var sQz217 = document.getElementById("imgSqr218").src;
    valueSave218 = 'zSqrArtSpecz217';
    localStorage.setItem(valueSave218, sQz217);
};

function square219(){
    var sQz218 = document.getElementById("imgSqr219").src;
    valueSave219 = 'zSqrArtSpecz218';
    localStorage.setItem(valueSave219, sQz218);
};

function square220(){
    var sQz219 = document.getElementById("imgSqr220").src;
    valueSave220 = 'zSqrArtSpecz219';
    localStorage.setItem(valueSave220, sQz219);
};

function square221(){
    var sQz220 = document.getElementById("imgSqr221").src;
    valueSave221 = 'zSqrArtSpecz220';
    localStorage.setItem(valueSave221, sQz220);
};

function square222(){
    var sQz221 = document.getElementById("imgSqr222").src;
    valueSave222 = 'zSqrArtSpecz221';
    localStorage.setItem(valueSave222, sQz221);
};

function square223(){
    var sQz222 = document.getElementById("imgSqr223").src;
    valueSave223 = 'zSqrArtSpecz222';
    localStorage.setItem(valueSave223, sQz222);
};

function square224(){
    var sQz223 = document.getElementById("imgSqr224").src;
    valueSave224 = 'zSqrArtSpecz223';
    localStorage.setItem(valueSave224, sQz223);
};

function square225(){
    var sQz224 = document.getElementById("imgSqr225").src;
    valueSave225 = 'zSqrArtSpecz224';
    localStorage.setItem(valueSave225, sQz224);
};

function square226(){
    var sQz225 = document.getElementById("imgSqr226").src;
    valueSave226 = 'zSqrArtSpecz225';
    localStorage.setItem(valueSave226, sQz225);
};

function square227(){
    var sQz226 = document.getElementById("imgSqr227").src;
    valueSave227 = 'zSqrArtSpecz226';
    localStorage.setItem(valueSave227, sQz226);
};

function square228(){
    var sQz227 = document.getElementById("imgSqr228").src;
    valueSave228 = 'zSqrArtSpecz227';
    localStorage.setItem(valueSave228, sQz227);
};

function square229(){
    var sQz228 = document.getElementById("imgSqr229").src;
    valueSave229 = 'zSqrArtSpecz228';
    localStorage.setItem(valueSave229, sQz228);
};

function square230(){
    var sQz229 = document.getElementById("imgSqr230").src;
    valueSave230 = 'zSqrArtSpecz229';
    localStorage.setItem(valueSave230, sQz229);
};

function square231(){
    var sQz230 = document.getElementById("imgSqr231").src;
    valueSave231 = 'zSqrArtSpecz230';
    localStorage.setItem(valueSave231, sQz230);
};

function square232(){
    var sQz231 = document.getElementById("imgSqr232").src;
    valueSave232 = 'zSqrArtSpecz231';
    localStorage.setItem(valueSave232, sQz231);
};

function square233(){
    var sQz232 = document.getElementById("imgSqr233").src;
    valueSave233 = 'zSqrArtSpecz232';
    localStorage.setItem(valueSave233, sQz232);
};

function square234(){
    var sQz233 = document.getElementById("imgSqr234").src;
    valueSave234 = 'zSqrArtSpecz233';
    localStorage.setItem(valueSave234, sQz233);
};

function square235(){
    var sQz234 = document.getElementById("imgSqr235").src;
    valueSave235 = 'zSqrArtSpecz234';
    localStorage.setItem(valueSave235, sQz234);
};

function square236(){
    var sQz235 = document.getElementById("imgSqr236").src;
    valueSave236 = 'zSqrArtSpecz235';
    localStorage.setItem(valueSave236, sQz235);
};

function square237(){
    var sQz236 = document.getElementById("imgSqr237").src;
    valueSave237 = 'zSqrArtSpecz236';
    localStorage.setItem(valueSave237, sQz236);
};

function square238(){
    var sQz237 = document.getElementById("imgSqr238").src;
    valueSave238 = 'zSqrArtSpecz237';
    localStorage.setItem(valueSave238, sQz237);
};

function square239(){
    var sQz238 = document.getElementById("imgSqr239").src;
    valueSave239 = 'zSqrArtSpecz238';
    localStorage.setItem(valueSave239, sQz238);
};

function square240(){
    var sQz239 = document.getElementById("imgSqr240").src;
    valueSave240 = 'zSqrArtSpecz239';
    localStorage.setItem(valueSave240, sQz239);
};

function square241(){
    var sQz240 = document.getElementById("imgSqr241").src;
    valueSave241 = 'zSqrArtSpecz240';
    localStorage.setItem(valueSave241, sQz240);
};

function square242(){
    var sQz241 = document.getElementById("imgSqr242").src;
    valueSave242 = 'zSqrArtSpecz241';
    localStorage.setItem(valueSave242, sQz241);
};

function square243(){
    var sQz242 = document.getElementById("imgSqr243").src;
    valueSave243 = 'zSqrArtSpecz242';
    localStorage.setItem(valueSave243, sQz242);
};

function square244(){
    var sQz243 = document.getElementById("imgSqr244").src;
    valueSave244 = 'zSqrArtSpecz243';
    localStorage.setItem(valueSave244, sQz243);
};

function square245(){
    var sQz244 = document.getElementById("imgSqr245").src;
    valueSave245 = 'zSqrArtSpecz244';
    localStorage.setItem(valueSave245, sQz244);
};

function square246(){
    var sQz245 = document.getElementById("imgSqr246").src;
    valueSave246 = 'zSqrArtSpecz245';
    localStorage.setItem(valueSave246, sQz245);
};

function square247(){
    var sQz246 = document.getElementById("imgSqr247").src;
    valueSave247 = 'zSqrArtSpecz246';
    localStorage.setItem(valueSave247, sQz246);
};

function square248(){
    var sQz247 = document.getElementById("imgSqr248").src;
    valueSave248 = 'zSqrArtSpecz247';
    localStorage.setItem(valueSave248, sQz247);
};

function square249(){
    var sQz248 = document.getElementById("imgSqr249").src;
    valueSave249 = 'zSqrArtSpecz248';
    localStorage.setItem(valueSave249, sQz248);
};

function square250(){
    var sQz249 = document.getElementById("imgSqr250").src;
    valueSave250 = 'zSqrArtSpecz249';
    localStorage.setItem(valueSave250, sQz249);
};

function square251(){
    var sQz250 = document.getElementById("imgSqr251").src;
    valueSave251 = 'zSqrArtSpecz250';
    localStorage.setItem(valueSave251, sQz250);
};

function square252(){
    var sQz251 = document.getElementById("imgSqr252").src;
    valueSave252 = 'zSqrArtSpecz251';
    localStorage.setItem(valueSave252, sQz251);
};

function square253(){
    var sQz252 = document.getElementById("imgSqr253").src;
    valueSave253 = 'zSqrArtSpecz252';
    localStorage.setItem(valueSave253, sQz252);
};

function square254(){
    var sQz253 = document.getElementById("imgSqr254").src;
    valueSave254 = 'zSqrArtSpecz253';
    localStorage.setItem(valueSave254, sQz253);
};

function square255(){
    var sQz254 = document.getElementById("imgSqr255").src;
    valueSave255 = 'zSqrArtSpecz254';
    localStorage.setItem(valueSave255, sQz254);
};

function square256(){
    var sQz255 = document.getElementById("imgSqr256").src;
    valueSave256 = 'zSqrArtSpecz255';
    localStorage.setItem(valueSave256, sQz255);
};

function square257(){
    var sQz256 = document.getElementById("imgSqr257").src;
    valueSave257 = 'zSqrArtSpecz256';
    localStorage.setItem(valueSave257, sQz256);
};

function square258(){
    var sQz257 = document.getElementById("imgSqr258").src;
    valueSave258 = 'zSqrArtSpecz257';
    localStorage.setItem(valueSave258, sQz257);
};

function square259(){
    var sQz258 = document.getElementById("imgSqr259").src;
    valueSave259 = 'zSqrArtSpecz258';
    localStorage.setItem(valueSave259, sQz258);
};

function square260(){
    var sQz259 = document.getElementById("imgSqr260").src;
    valueSave260 = 'zSqrArtSpecz259';
    localStorage.setItem(valueSave260, sQz259);
};

function square261(){
    var sQz260 = document.getElementById("imgSqr261").src;
    valueSave261 = 'zSqrArtSpecz260';
    localStorage.setItem(valueSave261, sQz260);
};

function square262(){
    var sQz261 = document.getElementById("imgSqr262").src;
    valueSave262 = 'zSqrArtSpecz261';
    localStorage.setItem(valueSave262, sQz261);
};

function square263(){
    var sQz262 = document.getElementById("imgSqr263").src;
    valueSave263 = 'zSqrArtSpecz262';
    localStorage.setItem(valueSave263, sQz262);
};

function square264(){
    var sQz263 = document.getElementById("imgSqr264").src;
    valueSave264 = 'zSqrArtSpecz263';
    localStorage.setItem(valueSave264, sQz263);
};

function square265(){
    var sQz264 = document.getElementById("imgSqr265").src;
    valueSave265 = 'zSqrArtSpecz264';
    localStorage.setItem(valueSave265, sQz264);
};

function square266(){
    var sQz265 = document.getElementById("imgSqr266").src;
    valueSave266 = 'zSqrArtSpecz265';
    localStorage.setItem(valueSave266, sQz265);
};

function square267(){
    var sQz266 = document.getElementById("imgSqr267").src;
    valueSave267 = 'zSqrArtSpecz266';
    localStorage.setItem(valueSave267, sQz266);
};

function square268(){
    var sQz267 = document.getElementById("imgSqr268").src;
    valueSave268 = 'zSqrArtSpecz267';
    localStorage.setItem(valueSave268, sQz267);
};

function square269(){
    var sQz268 = document.getElementById("imgSqr269").src;
    valueSave269 = 'zSqrArtSpecz268';
    localStorage.setItem(valueSave269, sQz268);
};

function square270(){
    var sQz269 = document.getElementById("imgSqr270").src;
    valueSave270 = 'zSqrArtSpecz269';
    localStorage.setItem(valueSave270, sQz269);
};

function square271(){
    var sQz270 = document.getElementById("imgSqr271").src;
    valueSave271 = 'zSqrArtSpecz270';
    localStorage.setItem(valueSave271, sQz270);
};

function square272(){
    var sQz271 = document.getElementById("imgSqr272").src;
    valueSave272 = 'zSqrArtSpecz271';
    localStorage.setItem(valueSave272, sQz271);
};

function square273(){
    var sQz272 = document.getElementById("imgSqr273").src;
    valueSave273 = 'zSqrArtSpecz272';
    localStorage.setItem(valueSave273, sQz272);
};

function square274(){
    var sQz273 = document.getElementById("imgSqr274").src;
    valueSave274 = 'zSqrArtSpecz273';
    localStorage.setItem(valueSave274, sQz273);
};

function square275(){
    var sQz274 = document.getElementById("imgSqr275").src;
    valueSave275 = 'zSqrArtSpecz274';
    localStorage.setItem(valueSave275, sQz274);
};

function square276(){
    var sQz275 = document.getElementById("imgSqr276").src;
    valueSave276 = 'zSqrArtSpecz275';
    localStorage.setItem(valueSave276, sQz275);
};

function square277(){
    var sQz276 = document.getElementById("imgSqr277").src;
    valueSave277 = 'zSqrArtSpecz276';
    localStorage.setItem(valueSave277, sQz276);
};

function square278(){
    var sQz277 = document.getElementById("imgSqr278").src;
    valueSave278 = 'zSqrArtSpecz277';
    localStorage.setItem(valueSave278, sQz277);
};

function square279(){
    var sQz278 = document.getElementById("imgSqr279").src;
    valueSave279 = 'zSqrArtSpecz278';
    localStorage.setItem(valueSave279, sQz278);
};

function square280(){
    var sQz279 = document.getElementById("imgSqr280").src;
    valueSave280 = 'zSqrArtSpecz279';
    localStorage.setItem(valueSave280, sQz279);
};

function square281(){
    var sQz280 = document.getElementById("imgSqr281").src;
    valueSave281 = 'zSqrArtSpecz280';
    localStorage.setItem(valueSave281, sQz280);
};

function square282(){
    var sQz281 = document.getElementById("imgSqr282").src;
    valueSave282 = 'zSqrArtSpecz281';
    localStorage.setItem(valueSave282, sQz281);
};

function square283(){
    var sQz282 = document.getElementById("imgSqr283").src;
    valueSave283 = 'zSqrArtSpecz282';
    localStorage.setItem(valueSave283, sQz282);
};

function square284(){
    var sQz283 = document.getElementById("imgSqr284").src;
    valueSave284 = 'zSqrArtSpecz283';
    localStorage.setItem(valueSave284, sQz283);
};

function square285(){
    var sQz284 = document.getElementById("imgSqr285").src;
    valueSave285 = 'zSqrArtSpecz284';
    localStorage.setItem(valueSave285, sQz284);
};

function square286(){
    var sQz285 = document.getElementById("imgSqr286").src;
    valueSave286 = 'zSqrArtSpecz285';
    localStorage.setItem(valueSave286, sQz285);
};

function square287(){
    var sQz286 = document.getElementById("imgSqr287").src;
    valueSave287 = 'zSqrArtSpecz286';
    localStorage.setItem(valueSave287, sQz286);
};

function square288(){
    var sQz287 = document.getElementById("imgSqr288").src;
    valueSave288 = 'zSqrArtSpecz287';
    localStorage.setItem(valueSave288, sQz287);
};

function square289(){
    var sQz288 = document.getElementById("imgSqr289").src;
    valueSave289 = 'zSqrArtSpecz288';
    localStorage.setItem(valueSave289, sQz288);
};

function square290(){
    var sQz289 = document.getElementById("imgSqr290").src;
    valueSave290 = 'zSqrArtSpecz289';
    localStorage.setItem(valueSave290, sQz289);
};

function square291(){
    var sQz290 = document.getElementById("imgSqr291").src;
    valueSave291 = 'zSqrArtSpecz290';
    localStorage.setItem(valueSave291, sQz290);
};

function square292(){
    var sQz291 = document.getElementById("imgSqr292").src;
    valueSave292 = 'zSqrArtSpecz291';
    localStorage.setItem(valueSave292, sQz291);
};

function square293(){
    var sQz292 = document.getElementById("imgSqr293").src;
    valueSave293 = 'zSqrArtSpecz292';
    localStorage.setItem(valueSave293, sQz292);
};

function square294(){
    var sQz293 = document.getElementById("imgSqr294").src;
    valueSave294 = 'zSqrArtSpecz293';
    localStorage.setItem(valueSave294, sQz293);
};

function square295(){
    var sQz294 = document.getElementById("imgSqr295").src;
    valueSave295 = 'zSqrArtSpecz294';
    localStorage.setItem(valueSave295, sQz294);
};

function square296(){
    var sQz295 = document.getElementById("imgSqr296").src;
    valueSave296 = 'zSqrArtSpecz295';
    localStorage.setItem(valueSave296, sQz295);
};

function square297(){
    var sQz296 = document.getElementById("imgSqr297").src;
    valueSave297 = 'zSqrArtSpecz296';
    localStorage.setItem(valueSave297, sQz296);
};

function square298(){
    var sQz297 = document.getElementById("imgSqr298").src;
    valueSave298 = 'zSqrArtSpecz297';
    localStorage.setItem(valueSave298, sQz297);
};

function square299(){
    var sQz298 = document.getElementById("imgSqr299").src;
    valueSave299 = 'zSqrArtSpecz298';
    localStorage.setItem(valueSave299, sQz298);
};

function square300(){
    var sQz299 = document.getElementById("imgSqr300").src;
    valueSave300 = 'zSqrArtSpecz299';
    localStorage.setItem(valueSave300, sQz299);
};

function square301(){
    var sQz300 = document.getElementById("imgSqr301").src;
    valueSave301 = 'zSqrArtSpecz300';
    localStorage.setItem(valueSave301, sQz300);
};

function square302(){
    var sQz301 = document.getElementById("imgSqr302").src;
    valueSave302 = 'zSqrArtSpecz301';
    localStorage.setItem(valueSave302, sQz301);
};

function square303(){
    var sQz302 = document.getElementById("imgSqr303").src;
    valueSave303 = 'zSqrArtSpecz302';
    localStorage.setItem(valueSave303, sQz302);
};

function square304(){
    var sQz303 = document.getElementById("imgSqr304").src;
    valueSave304 = 'zSqrArtSpecz303';
    localStorage.setItem(valueSave304, sQz303);
};

function square305(){
    var sQz304 = document.getElementById("imgSqr305").src;
    valueSave305 = 'zSqrArtSpecz304';
    localStorage.setItem(valueSave305, sQz304);
};

function square306(){
    var sQz305 = document.getElementById("imgSqr306").src;
    valueSave306 = 'zSqrArtSpecz305';
    localStorage.setItem(valueSave306, sQz305);
};

function square307(){
    var sQz306 = document.getElementById("imgSqr307").src;
    valueSave307 = 'zSqrArtSpecz306';
    localStorage.setItem(valueSave307, sQz306);
};

function square308(){
    var sQz307 = document.getElementById("imgSqr308").src;
    valueSave308 = 'zSqrArtSpecz307';
    localStorage.setItem(valueSave308, sQz307);
};

function square309(){
    var sQz308 = document.getElementById("imgSqr309").src;
    valueSave309 = 'zSqrArtSpecz308';
    localStorage.setItem(valueSave309, sQz308);
};

function square310(){
    var sQz309 = document.getElementById("imgSqr310").src;
    valueSave310 = 'zSqrArtSpecz309';
    localStorage.setItem(valueSave310, sQz309);
};

function square311(){
    var sQz310 = document.getElementById("imgSqr311").src;
    valueSave311 = 'zSqrArtSpecz310';
    localStorage.setItem(valueSave311, sQz310);
};

function square312(){
    var sQz311 = document.getElementById("imgSqr312").src;
    valueSave312 = 'zSqrArtSpecz311';
    localStorage.setItem(valueSave312, sQz311);
};

function square313(){
    var sQz312 = document.getElementById("imgSqr313").src;
    valueSave313 = 'zSqrArtSpecz312';
    localStorage.setItem(valueSave313, sQz312);
};

function square314(){
    var sQz313 = document.getElementById("imgSqr314").src;
    valueSave314 = 'zSqrArtSpecz313';
    localStorage.setItem(valueSave314, sQz313);
};

function square315(){
    var sQz314 = document.getElementById("imgSqr315").src;
    valueSave315 = 'zSqrArtSpecz314';
    localStorage.setItem(valueSave315, sQz314);
};

function square316(){
    var sQz315 = document.getElementById("imgSqr316").src;
    valueSave316 = 'zSqrArtSpecz315';
    localStorage.setItem(valueSave316, sQz315);
};

function square317(){
    var sQz316 = document.getElementById("imgSqr317").src;
    valueSave317 = 'zSqrArtSpecz316';
    localStorage.setItem(valueSave317, sQz316);
};

function square318(){
    var sQz317 = document.getElementById("imgSqr318").src;
    valueSave318 = 'zSqrArtSpecz317';
    localStorage.setItem(valueSave318, sQz317);
};

function square319(){
    var sQz318 = document.getElementById("imgSqr319").src;
    valueSave319 = 'zSqrArtSpecz318';
    localStorage.setItem(valueSave319, sQz318);
};

function square320(){
    var sQz319 = document.getElementById("imgSqr320").src;
    valueSave320 = 'zSqrArtSpecz319';
    localStorage.setItem(valueSave320, sQz319);
};

function square321(){
    var sQz320 = document.getElementById("imgSqr321").src;
    valueSave321 = 'zSqrArtSpecz320';
    localStorage.setItem(valueSave321, sQz320);
};

function square322(){
    var sQz321 = document.getElementById("imgSqr322").src;
    valueSave322 = 'zSqrArtSpecz321';
    localStorage.setItem(valueSave322, sQz321);
};

function square323(){
    var sQz322 = document.getElementById("imgSqr323").src;
    valueSave323 = 'zSqrArtSpecz322';
    localStorage.setItem(valueSave323, sQz322);
};

function square324(){
    var sQz323 = document.getElementById("imgSqr324").src;
    valueSave324 = 'zSqrArtSpecz323';
    localStorage.setItem(valueSave324, sQz323);
};

function square325(){
    var sQz324 = document.getElementById("imgSqr325").src;
    valueSave325 = 'zSqrArtSpecz324';
    localStorage.setItem(valueSave325, sQz324);
};

function square326(){
    var sQz325 = document.getElementById("imgSqr326").src;
    valueSave326 = 'zSqrArtSpecz325';
    localStorage.setItem(valueSave326, sQz325);
};

function square327(){
    var sQz326 = document.getElementById("imgSqr327").src;
    valueSave327 = 'zSqrArtSpecz326';
    localStorage.setItem(valueSave327, sQz326);
};

function square328(){
    var sQz327 = document.getElementById("imgSqr328").src;
    valueSave328 = 'zSqrArtSpecz327';
    localStorage.setItem(valueSave328, sQz327);
};

function square329(){
    var sQz328 = document.getElementById("imgSqr329").src;
    valueSave329 = 'zSqrArtSpecz328';
    localStorage.setItem(valueSave329, sQz328);
};

function square330(){
    var sQz329 = document.getElementById("imgSqr330").src;
    valueSave330 = 'zSqrArtSpecz329';
    localStorage.setItem(valueSave330, sQz329);
};

function square331(){
    var sQz330 = document.getElementById("imgSqr331").src;
    valueSave331 = 'zSqrArtSpecz330';
    localStorage.setItem(valueSave331, sQz330);
};

function square332(){
    var sQz331 = document.getElementById("imgSqr332").src;
    valueSave332 = 'zSqrArtSpecz331';
    localStorage.setItem(valueSave332, sQz331);
};

function square333(){
    var sQz332 = document.getElementById("imgSqr333").src;
    valueSave333 = 'zSqrArtSpecz332';
    localStorage.setItem(valueSave333, sQz332);
};

function square334(){
    var sQz333 = document.getElementById("imgSqr334").src;
    valueSave334 = 'zSqrArtSpecz333';
    localStorage.setItem(valueSave334, sQz333);
};

function square335(){
    var sQz334 = document.getElementById("imgSqr335").src;
    valueSave335 = 'zSqrArtSpecz334';
    localStorage.setItem(valueSave335, sQz334);
};

function square336(){
    var sQz335 = document.getElementById("imgSqr336").src;
    valueSave336 = 'zSqrArtSpecz335';
    localStorage.setItem(valueSave336, sQz335);
};

function square337(){
    var sQz336 = document.getElementById("imgSqr337").src;
    valueSave337 = 'zSqrArtSpecz336';
    localStorage.setItem(valueSave337, sQz336);
};

function square338(){
    var sQz337 = document.getElementById("imgSqr338").src;
    valueSave338 = 'zSqrArtSpecz337';
    localStorage.setItem(valueSave338, sQz337);
};

function square339(){
    var sQz338 = document.getElementById("imgSqr339").src;
    valueSave339 = 'zSqrArtSpecz338';
    localStorage.setItem(valueSave339, sQz338);
};

function square340(){
    var sQz339 = document.getElementById("imgSqr340").src;
    valueSave340 = 'zSqrArtSpecz339';
    localStorage.setItem(valueSave340, sQz339);
};

function square341(){
    var sQz340 = document.getElementById("imgSqr341").src;
    valueSave341 = 'zSqrArtSpecz340';
    localStorage.setItem(valueSave341, sQz340);
};

function square342(){
    var sQz341 = document.getElementById("imgSqr342").src;
    valueSave342 = 'zSqrArtSpecz341';
    localStorage.setItem(valueSave342, sQz341);
};

function square343(){
    var sQz342 = document.getElementById("imgSqr343").src;
    valueSave343 = 'zSqrArtSpecz342';
    localStorage.setItem(valueSave343, sQz342);
};

function square344(){
    var sQz343 = document.getElementById("imgSqr344").src;
    valueSave344 = 'zSqrArtSpecz343';
    localStorage.setItem(valueSave344, sQz343);
};

function square345(){
    var sQz344 = document.getElementById("imgSqr345").src;
    valueSave345 = 'zSqrArtSpecz344';
    localStorage.setItem(valueSave345, sQz344);
};

function square346(){
    var sQz345 = document.getElementById("imgSqr346").src;
    valueSave346 = 'zSqrArtSpecz345';
    localStorage.setItem(valueSave346, sQz345);
};

function square347(){
    var sQz346 = document.getElementById("imgSqr347").src;
    valueSave347 = 'zSqrArtSpecz346';
    localStorage.setItem(valueSave347, sQz346);
};

function square348(){
    var sQz347 = document.getElementById("imgSqr348").src;
    valueSave348 = 'zSqrArtSpecz347';
    localStorage.setItem(valueSave348, sQz347);
};

function square349(){
    var sQz348 = document.getElementById("imgSqr349").src;
    valueSave349 = 'zSqrArtSpecz348';
    localStorage.setItem(valueSave349, sQz348);
};

function square350(){
    var sQz349 = document.getElementById("imgSqr350").src;
    valueSave350 = 'zSqrArtSpecz349';
    localStorage.setItem(valueSave350, sQz349);
};

function square351(){
    var sQz350 = document.getElementById("imgSqr351").src;
    valueSave351 = 'zSqrArtSpecz350';
    localStorage.setItem(valueSave351, sQz350);
};

function square352(){
    var sQz351 = document.getElementById("imgSqr352").src;
    valueSave352 = 'zSqrArtSpecz351';
    localStorage.setItem(valueSave352, sQz351);
};

function square353(){
    var sQz352 = document.getElementById("imgSqr353").src;
    valueSave353 = 'zSqrArtSpecz352';
    localStorage.setItem(valueSave353, sQz352);
};

function square354(){
    var sQz353 = document.getElementById("imgSqr354").src;
    valueSave354 = 'zSqrArtSpecz353';
    localStorage.setItem(valueSave354, sQz353);
};

function square355(){
    var sQz354 = document.getElementById("imgSqr355").src;
    valueSave355 = 'zSqrArtSpecz354';
    localStorage.setItem(valueSave355, sQz354);
};

function square356(){
    var sQz355 = document.getElementById("imgSqr356").src;
    valueSave356 = 'zSqrArtSpecz355';
    localStorage.setItem(valueSave356, sQz355);
};

function square357(){
    var sQz356 = document.getElementById("imgSqr357").src;
    valueSave357 = 'zSqrArtSpecz356';
    localStorage.setItem(valueSave357, sQz356);
};

function square358(){
    var sQz357 = document.getElementById("imgSqr358").src;
    valueSave358 = 'zSqrArtSpecz357';
    localStorage.setItem(valueSave358, sQz357);
};

function square359(){
    var sQz358 = document.getElementById("imgSqr359").src;
    valueSave359 = 'zSqrArtSpecz358';
    localStorage.setItem(valueSave359, sQz358);
};

function square360(){
    var sQz359 = document.getElementById("imgSqr360").src;
    valueSave360 = 'zSqrArtSpecz359';
    localStorage.setItem(valueSave360, sQz359);
};

function square361(){
    var sQz360 = document.getElementById("imgSqr361").src;
    valueSave361 = 'zSqrArtSpecz360';
    localStorage.setItem(valueSave361, sQz360);
};

function square362(){
    var sQz361 = document.getElementById("imgSqr362").src;
    valueSave362 = 'zSqrArtSpecz361';
    localStorage.setItem(valueSave362, sQz361);
};

function square363(){
    var sQz362 = document.getElementById("imgSqr363").src;
    valueSave363 = 'zSqrArtSpecz362';
    localStorage.setItem(valueSave363, sQz362);
};

function square364(){
    var sQz363 = document.getElementById("imgSqr364").src;
    valueSave364 = 'zSqrArtSpecz363';
    localStorage.setItem(valueSave364, sQz363);
};

function square365(){
    var sQz364 = document.getElementById("imgSqr365").src;
    valueSave365 = 'zSqrArtSpecz364';
    localStorage.setItem(valueSave365, sQz364);
};

function square366(){
    var sQz365 = document.getElementById("imgSqr366").src;
    valueSave366 = 'zSqrArtSpecz365';
    localStorage.setItem(valueSave366, sQz365);
};

function square367(){
    var sQz366 = document.getElementById("imgSqr367").src;
    valueSave367 = 'zSqrArtSpecz366';
    localStorage.setItem(valueSave367, sQz366);
};

function square368(){
    var sQz367 = document.getElementById("imgSqr368").src;
    valueSave368 = 'zSqrArtSpecz367';
    localStorage.setItem(valueSave368, sQz367);
};

function square369(){
    var sQz368 = document.getElementById("imgSqr369").src;
    valueSave369 = 'zSqrArtSpecz368';
    localStorage.setItem(valueSave369, sQz368);
};

function square370(){
    var sQz369 = document.getElementById("imgSqr370").src;
    valueSave370 = 'zSqrArtSpecz369';
    localStorage.setItem(valueSave370, sQz369);
};

function square371(){
    var sQz370 = document.getElementById("imgSqr371").src;
    valueSave371 = 'zSqrArtSpecz370';
    localStorage.setItem(valueSave371, sQz370);
};

function square372(){
    var sQz371 = document.getElementById("imgSqr372").src;
    valueSave372 = 'zSqrArtSpecz371';
    localStorage.setItem(valueSave372, sQz371);
};

function square373(){
    var sQz372 = document.getElementById("imgSqr373").src;
    valueSave373 = 'zSqrArtSpecz372';
    localStorage.setItem(valueSave373, sQz372);
};

function square374(){
    var sQz373 = document.getElementById("imgSqr374").src;
    valueSave374 = 'zSqrArtSpecz373';
    localStorage.setItem(valueSave374, sQz373);
};

function square375(){
    var sQz374 = document.getElementById("imgSqr375").src;
    valueSave375 = 'zSqrArtSpecz374';
    localStorage.setItem(valueSave375, sQz374);
};

function square376(){
    var sQz375 = document.getElementById("imgSqr376").src;
    valueSave376 = 'zSqrArtSpecz375';
    localStorage.setItem(valueSave376, sQz375);
};

function square377(){
    var sQz376 = document.getElementById("imgSqr377").src;
    valueSave377 = 'zSqrArtSpecz376';
    localStorage.setItem(valueSave377, sQz376);
};

function square378(){
    var sQz377 = document.getElementById("imgSqr378").src;
    valueSave378 = 'zSqrArtSpecz377';
    localStorage.setItem(valueSave378, sQz377);
};

function square379(){
    var sQz378 = document.getElementById("imgSqr379").src;
    valueSave379 = 'zSqrArtSpecz378';
    localStorage.setItem(valueSave379, sQz378);
};

function square380(){
    var sQz379 = document.getElementById("imgSqr380").src;
    valueSave380 = 'zSqrArtSpecz379';
    localStorage.setItem(valueSave380, sQz379);
};

function square381(){
    var sQz380 = document.getElementById("imgSqr381").src;
    valueSave381 = 'zSqrArtSpecz380';
    localStorage.setItem(valueSave381, sQz380);
};

function square382(){
    var sQz381 = document.getElementById("imgSqr382").src;
    valueSave382 = 'zSqrArtSpecz381';
    localStorage.setItem(valueSave382, sQz381);
};

function square383(){
    var sQz382 = document.getElementById("imgSqr383").src;
    valueSave383 = 'zSqrArtSpecz382';
    localStorage.setItem(valueSave383, sQz382);
};

function square384(){
    var sQz383 = document.getElementById("imgSqr384").src;
    valueSave384 = 'zSqrArtSpecz383';
    localStorage.setItem(valueSave384, sQz383);
};

function square385(){
    var sQz384 = document.getElementById("imgSqr385").src;
    valueSave385 = 'zSqrArtSpecz384';
    localStorage.setItem(valueSave385, sQz384);
};

function square386(){
    var sQz385 = document.getElementById("imgSqr386").src;
    valueSave386 = 'zSqrArtSpecz385';
    localStorage.setItem(valueSave386, sQz385);
};

function square387(){
    var sQz386 = document.getElementById("imgSqr387").src;
    valueSave387 = 'zSqrArtSpecz386';
    localStorage.setItem(valueSave387, sQz386);
};

function square388(){
    var sQz387 = document.getElementById("imgSqr388").src;
    valueSave388 = 'zSqrArtSpecz387';
    localStorage.setItem(valueSave388, sQz387);
};

function square389(){
    var sQz388 = document.getElementById("imgSqr389").src;
    valueSave389 = 'zSqrArtSpecz388';
    localStorage.setItem(valueSave389, sQz388);
};

function square390(){
    var sQz389 = document.getElementById("imgSqr390").src;
    valueSave390 = 'zSqrArtSpecz389';
    localStorage.setItem(valueSave390, sQz389);
};

function square391(){
    var sQz390 = document.getElementById("imgSqr391").src;
    valueSave391 = 'zSqrArtSpecz390';
    localStorage.setItem(valueSave391, sQz390);
};

function square392(){
    var sQz391 = document.getElementById("imgSqr392").src;
    valueSave392 = 'zSqrArtSpecz391';
    localStorage.setItem(valueSave392, sQz391);
};

function square393(){
    var sQz392 = document.getElementById("imgSqr393").src;
    valueSave393 = 'zSqrArtSpecz392';
    localStorage.setItem(valueSave393, sQz392);
};

function square394(){
    var sQz393 = document.getElementById("imgSqr394").src;
    valueSave394 = 'zSqrArtSpecz393';
    localStorage.setItem(valueSave394, sQz393);
};

function square395(){
    var sQz394 = document.getElementById("imgSqr395").src;
    valueSave395 = 'zSqrArtSpecz394';
    localStorage.setItem(valueSave395, sQz394);
};

function square396(){
    var sQz395 = document.getElementById("imgSqr396").src;
    valueSave396 = 'zSqrArtSpecz395';
    localStorage.setItem(valueSave396, sQz395);
};

function square397(){
    var sQz396 = document.getElementById("imgSqr397").src;
    valueSave397 = 'zSqrArtSpecz396';
    localStorage.setItem(valueSave397, sQz396);
};

function square398(){
    var sQz397 = document.getElementById("imgSqr398").src;
    valueSave398 = 'zSqrArtSpecz397';
    localStorage.setItem(valueSave398, sQz397);
};

function square399(){
    var sQz398 = document.getElementById("imgSqr399").src;
    valueSave399 = 'zSqrArtSpecz398';
    localStorage.setItem(valueSave399, sQz398);
};

function square400(){
    var sQz399 = document.getElementById("imgSqr400").src;
    valueSave400 = 'zSqrArtSpecz399';
    localStorage.setItem(valueSave400, sQz399);
};

function square401(){
    var sQz400 = document.getElementById("imgSqr401").src;
    valueSave401 = 'zSqrArtSpecz400';
    localStorage.setItem(valueSave401, sQz400);
};

function square402(){
    var sQz401 = document.getElementById("imgSqr402").src;
    valueSave402 = 'zSqrArtSpecz401';
    localStorage.setItem(valueSave402, sQz401);
};

function square403(){
    var sQz402 = document.getElementById("imgSqr403").src;
    valueSave403 = 'zSqrArtSpecz402';
    localStorage.setItem(valueSave403, sQz402);
};

function square404(){
    var sQz403 = document.getElementById("imgSqr404").src;
    valueSave404 = 'zSqrArtSpecz403';
    localStorage.setItem(valueSave404, sQz403);
};

function square405(){
    var sQz404 = document.getElementById("imgSqr405").src;
    valueSave405 = 'zSqrArtSpecz404';
    localStorage.setItem(valueSave405, sQz404);
};

function square406(){
    var sQz405 = document.getElementById("imgSqr406").src;
    valueSave406 = 'zSqrArtSpecz405';
    localStorage.setItem(valueSave406, sQz405);
};

function square407(){
    var sQz406 = document.getElementById("imgSqr407").src;
    valueSave407 = 'zSqrArtSpecz406';
    localStorage.setItem(valueSave407, sQz406);
};

function square408(){
    var sQz407 = document.getElementById("imgSqr408").src;
    valueSave408 = 'zSqrArtSpecz407';
    localStorage.setItem(valueSave408, sQz407);
};

function square409(){
    var sQz408 = document.getElementById("imgSqr409").src;
    valueSave409 = 'zSqrArtSpecz408';
    localStorage.setItem(valueSave409, sQz408);
};

function square410(){
    var sQz409 = document.getElementById("imgSqr410").src;
    valueSave410 = 'zSqrArtSpecz409';
    localStorage.setItem(valueSave410, sQz409);
};

function square411(){
    var sQz410 = document.getElementById("imgSqr411").src;
    valueSave411 = 'zSqrArtSpecz410';
    localStorage.setItem(valueSave411, sQz410);
};

function square412(){
    var sQz411 = document.getElementById("imgSqr412").src;
    valueSave412 = 'zSqrArtSpecz411';
    localStorage.setItem(valueSave412, sQz411);
};

function square413(){
    var sQz412 = document.getElementById("imgSqr413").src;
    valueSave413 = 'zSqrArtSpecz412';
    localStorage.setItem(valueSave413, sQz412);
};

function square414(){
    var sQz413 = document.getElementById("imgSqr414").src;
    valueSave414 = 'zSqrArtSpecz413';
    localStorage.setItem(valueSave414, sQz413);
};

function square415(){
    var sQz414 = document.getElementById("imgSqr415").src;
    valueSave415 = 'zSqrArtSpecz414';
    localStorage.setItem(valueSave415, sQz414);
};

function square416(){
    var sQz415 = document.getElementById("imgSqr416").src;
    valueSave416 = 'zSqrArtSpecz415';
    localStorage.setItem(valueSave416, sQz415);
};

function square417(){
    var sQz416 = document.getElementById("imgSqr417").src;
    valueSave417 = 'zSqrArtSpecz416';
    localStorage.setItem(valueSave417, sQz416);
};

function square418(){
    var sQz417 = document.getElementById("imgSqr418").src;
    valueSave418 = 'zSqrArtSpecz417';
    localStorage.setItem(valueSave418, sQz417);
};

function square419(){
    var sQz418 = document.getElementById("imgSqr419").src;
    valueSave419 = 'zSqrArtSpecz418';
    localStorage.setItem(valueSave419, sQz418);
};

function square420(){
    var sQz419 = document.getElementById("imgSqr420").src;
    valueSave420 = 'zSqrArtSpecz419';
    localStorage.setItem(valueSave420, sQz419);
};

function square421(){
    var sQz420 = document.getElementById("imgSqr421").src;
    valueSave421 = 'zSqrArtSpecz420';
    localStorage.setItem(valueSave421, sQz420);
};

function square422(){
    var sQz421 = document.getElementById("imgSqr422").src;
    valueSave422 = 'zSqrArtSpecz421';
    localStorage.setItem(valueSave422, sQz421);
};

function square423(){
    var sQz422 = document.getElementById("imgSqr423").src;
    valueSave423 = 'zSqrArtSpecz422';
    localStorage.setItem(valueSave423, sQz422);
};

function square424(){
    var sQz423 = document.getElementById("imgSqr424").src;
    valueSave424 = 'zSqrArtSpecz423';
    localStorage.setItem(valueSave424, sQz423);
};

function square425(){
    var sQz424 = document.getElementById("imgSqr425").src;
    valueSave425 = 'zSqrArtSpecz424';
    localStorage.setItem(valueSave425, sQz424);
};

function square426(){
    var sQz425 = document.getElementById("imgSqr426").src;
    valueSave426 = 'zSqrArtSpecz425';
    localStorage.setItem(valueSave426, sQz425);
};

function square427(){
    var sQz426 = document.getElementById("imgSqr427").src;
    valueSave427 = 'zSqrArtSpecz426';
    localStorage.setItem(valueSave427, sQz426);
};

function square428(){
    var sQz427 = document.getElementById("imgSqr428").src;
    valueSave428 = 'zSqrArtSpecz427';
    localStorage.setItem(valueSave428, sQz427);
};

function square429(){
    var sQz428 = document.getElementById("imgSqr429").src;
    valueSave429 = 'zSqrArtSpecz428';
    localStorage.setItem(valueSave429, sQz428);
};

function square430(){
    var sQz429 = document.getElementById("imgSqr430").src;
    valueSave430 = 'zSqrArtSpecz429';
    localStorage.setItem(valueSave430, sQz429);
};

function square431(){
    var sQz430 = document.getElementById("imgSqr431").src;
    valueSave431 = 'zSqrArtSpecz430';
    localStorage.setItem(valueSave431, sQz430);
};

function square432(){
    var sQz431 = document.getElementById("imgSqr432").src;
    valueSave432 = 'zSqrArtSpecz431';
    localStorage.setItem(valueSave432, sQz431);
};

function square433(){
    var sQz432 = document.getElementById("imgSqr433").src;
    valueSave433 = 'zSqrArtSpecz432';
    localStorage.setItem(valueSave433, sQz432);
};

function square434(){
    var sQz433 = document.getElementById("imgSqr434").src;
    valueSave434 = 'zSqrArtSpecz433';
    localStorage.setItem(valueSave434, sQz433);
};

function square435(){
    var sQz434 = document.getElementById("imgSqr435").src;
    valueSave435 = 'zSqrArtSpecz434';
    localStorage.setItem(valueSave435, sQz434);
};

function square436(){
    var sQz435 = document.getElementById("imgSqr436").src;
    valueSave436 = 'zSqrArtSpecz435';
    localStorage.setItem(valueSave436, sQz435);
};

function square437(){
    var sQz436 = document.getElementById("imgSqr437").src;
    valueSave437 = 'zSqrArtSpecz436';
    localStorage.setItem(valueSave437, sQz436);
};

function square438(){
    var sQz437 = document.getElementById("imgSqr438").src;
    valueSave438 = 'zSqrArtSpecz437';
    localStorage.setItem(valueSave438, sQz437);
};

function square439(){
    var sQz438 = document.getElementById("imgSqr439").src;
    valueSave439 = 'zSqrArtSpecz438';
    localStorage.setItem(valueSave439, sQz438);
};

function square440(){
    var sQz439 = document.getElementById("imgSqr440").src;
    valueSave440 = 'zSqrArtSpecz439';
    localStorage.setItem(valueSave440, sQz439);
};

function square441(){
    var sQz440 = document.getElementById("imgSqr441").src;
    valueSave441 = 'zSqrArtSpecz440';
    localStorage.setItem(valueSave441, sQz440);
};

function square442(){
    var sQz441 = document.getElementById("imgSqr442").src;
    valueSave442 = 'zSqrArtSpecz441';
    localStorage.setItem(valueSave442, sQz441);
};

function square443(){
    var sQz442 = document.getElementById("imgSqr443").src;
    valueSave443 = 'zSqrArtSpecz442';
    localStorage.setItem(valueSave443, sQz442);
};

function square444(){
    var sQz443 = document.getElementById("imgSqr444").src;
    valueSave444 = 'zSqrArtSpecz443';
    localStorage.setItem(valueSave444, sQz443);
};

function square445(){
    var sQz444 = document.getElementById("imgSqr445").src;
    valueSave445 = 'zSqrArtSpecz444';
    localStorage.setItem(valueSave445, sQz444);
};

function square446(){
    var sQz445 = document.getElementById("imgSqr446").src;
    valueSave446 = 'zSqrArtSpecz445';
    localStorage.setItem(valueSave446, sQz445);
};

function square447(){
    var sQz446 = document.getElementById("imgSqr447").src;
    valueSave447 = 'zSqrArtSpecz446';
    localStorage.setItem(valueSave447, sQz446);
};

function square448(){
    var sQz447 = document.getElementById("imgSqr448").src;
    valueSave448 = 'zSqrArtSpecz447';
    localStorage.setItem(valueSave448, sQz447);
};

function square449(){
    var sQz448 = document.getElementById("imgSqr449").src;
    valueSave449 = 'zSqrArtSpecz448';
    localStorage.setItem(valueSave449, sQz448);
};

function square450(){
    var sQz449 = document.getElementById("imgSqr450").src;
    valueSave450 = 'zSqrArtSpecz449';
    localStorage.setItem(valueSave450, sQz449);
};

function square451(){
    var sQz450 = document.getElementById("imgSqr451").src;
    valueSave451 = 'zSqrArtSpecz450';
    localStorage.setItem(valueSave451, sQz450);
};

function square452(){
    var sQz451 = document.getElementById("imgSqr452").src;
    valueSave452 = 'zSqrArtSpecz451';
    localStorage.setItem(valueSave452, sQz451);
};

function square453(){
    var sQz452 = document.getElementById("imgSqr453").src;
    valueSave453 = 'zSqrArtSpecz452';
    localStorage.setItem(valueSave453, sQz452);
};

function square454(){
    var sQz453 = document.getElementById("imgSqr454").src;
    valueSave454 = 'zSqrArtSpecz453';
    localStorage.setItem(valueSave454, sQz453);
};

function square455(){
    var sQz454 = document.getElementById("imgSqr455").src;
    valueSave455 = 'zSqrArtSpecz454';
    localStorage.setItem(valueSave455, sQz454);
};

function square456(){
    var sQz455 = document.getElementById("imgSqr456").src;
    valueSave456 = 'zSqrArtSpecz455';
    localStorage.setItem(valueSave456, sQz455);
};

function square457(){
    var sQz456 = document.getElementById("imgSqr457").src;
    valueSave457 = 'zSqrArtSpecz456';
    localStorage.setItem(valueSave457, sQz456);
};

function square458(){
    var sQz457 = document.getElementById("imgSqr458").src;
    valueSave458 = 'zSqrArtSpecz457';
    localStorage.setItem(valueSave458, sQz457);
};

function square459(){
    var sQz458 = document.getElementById("imgSqr459").src;
    valueSave459 = 'zSqrArtSpecz458';
    localStorage.setItem(valueSave459, sQz458);
};

function square460(){
    var sQz459 = document.getElementById("imgSqr460").src;
    valueSave460 = 'zSqrArtSpecz459';
    localStorage.setItem(valueSave460, sQz459);
};

function square461(){
    var sQz460 = document.getElementById("imgSqr461").src;
    valueSave461 = 'zSqrArtSpecz460';
    localStorage.setItem(valueSave461, sQz460);
};

function square462(){
    var sQz461 = document.getElementById("imgSqr462").src;
    valueSave462 = 'zSqrArtSpecz461';
    localStorage.setItem(valueSave462, sQz461);
};

function square463(){
    var sQz462 = document.getElementById("imgSqr463").src;
    valueSave463 = 'zSqrArtSpecz462';
    localStorage.setItem(valueSave463, sQz462);
};

function square464(){
    var sQz463 = document.getElementById("imgSqr464").src;
    valueSave464 = 'zSqrArtSpecz463';
    localStorage.setItem(valueSave464, sQz463);
};

function square465(){
    var sQz464 = document.getElementById("imgSqr465").src;
    valueSave465 = 'zSqrArtSpecz464';
    localStorage.setItem(valueSave465, sQz464);
};

function square466(){
    var sQz465 = document.getElementById("imgSqr466").src;
    valueSave466 = 'zSqrArtSpecz465';
    localStorage.setItem(valueSave466, sQz465);
};

function square467(){
    var sQz466 = document.getElementById("imgSqr467").src;
    valueSave467 = 'zSqrArtSpecz466';
    localStorage.setItem(valueSave467, sQz466);
};

function square468(){
    var sQz467 = document.getElementById("imgSqr468").src;
    valueSave468 = 'zSqrArtSpecz467';
    localStorage.setItem(valueSave468, sQz467);
};

function square469(){
    var sQz468 = document.getElementById("imgSqr469").src;
    valueSave469 = 'zSqrArtSpecz468';
    localStorage.setItem(valueSave469, sQz468);
};

function square470(){
    var sQz469 = document.getElementById("imgSqr470").src;
    valueSave470 = 'zSqrArtSpecz469';
    localStorage.setItem(valueSave470, sQz469);
};

function square471(){
    var sQz470 = document.getElementById("imgSqr471").src;
    valueSave471 = 'zSqrArtSpecz470';
    localStorage.setItem(valueSave471, sQz470);
};

function square472(){
    var sQz471 = document.getElementById("imgSqr472").src;
    valueSave472 = 'zSqrArtSpecz471';
    localStorage.setItem(valueSave472, sQz471);
};

function square473(){
    var sQz472 = document.getElementById("imgSqr473").src;
    valueSave473 = 'zSqrArtSpecz472';
    localStorage.setItem(valueSave473, sQz472);
};

function square474(){
    var sQz473 = document.getElementById("imgSqr474").src;
    valueSave474 = 'zSqrArtSpecz473';
    localStorage.setItem(valueSave474, sQz473);
};

function square475(){
    var sQz474 = document.getElementById("imgSqr475").src;
    valueSave475 = 'zSqrArtSpecz474';
    localStorage.setItem(valueSave475, sQz474);
};

function square476(){
    var sQz475 = document.getElementById("imgSqr476").src;
    valueSave476 = 'zSqrArtSpecz475';
    localStorage.setItem(valueSave476, sQz475);
};

function square477(){
    var sQz476 = document.getElementById("imgSqr477").src;
    valueSave477 = 'zSqrArtSpecz476';
    localStorage.setItem(valueSave477, sQz476);
};

function square478(){
    var sQz477 = document.getElementById("imgSqr478").src;
    valueSave478 = 'zSqrArtSpecz477';
    localStorage.setItem(valueSave478, sQz477);
};

function square479(){
    var sQz478 = document.getElementById("imgSqr479").src;
    valueSave479 = 'zSqrArtSpecz478';
    localStorage.setItem(valueSave479, sQz478);
};

function square480(){
    var sQz479 = document.getElementById("imgSqr480").src;
    valueSave480 = 'zSqrArtSpecz479';
    localStorage.setItem(valueSave480, sQz479);
};

function square481(){
    var sQz480 = document.getElementById("imgSqr481").src;
    valueSave481 = 'zSqrArtSpecz480';
    localStorage.setItem(valueSave481, sQz480);
};

function square482(){
    var sQz481 = document.getElementById("imgSqr482").src;
    valueSave482 = 'zSqrArtSpecz481';
    localStorage.setItem(valueSave482, sQz481);
};

function square483(){
    var sQz482 = document.getElementById("imgSqr483").src;
    valueSave483 = 'zSqrArtSpecz482';
    localStorage.setItem(valueSave483, sQz482);
};

function square484(){
    var sQz483 = document.getElementById("imgSqr484").src;
    valueSave484 = 'zSqrArtSpecz483';
    localStorage.setItem(valueSave484, sQz483);
};

function square485(){
    var sQz484 = document.getElementById("imgSqr485").src;
    valueSave485 = 'zSqrArtSpecz484';
    localStorage.setItem(valueSave485, sQz484);
};

function square486(){
    var sQz485 = document.getElementById("imgSqr486").src;
    valueSave486 = 'zSqrArtSpecz485';
    localStorage.setItem(valueSave486, sQz485);
};

function square487(){
    var sQz486 = document.getElementById("imgSqr487").src;
    valueSave487 = 'zSqrArtSpecz486';
    localStorage.setItem(valueSave487, sQz486);
};

function square488(){
    var sQz487 = document.getElementById("imgSqr488").src;
    valueSave488 = 'zSqrArtSpecz487';
    localStorage.setItem(valueSave488, sQz487);
};

function square489(){
    var sQz488 = document.getElementById("imgSqr489").src;
    valueSave489 = 'zSqrArtSpecz488';
    localStorage.setItem(valueSave489, sQz488);
};

function square490(){
    var sQz489 = document.getElementById("imgSqr490").src;
    valueSave490 = 'zSqrArtSpecz489';
    localStorage.setItem(valueSave490, sQz489);
};

function square491(){
    var sQz490 = document.getElementById("imgSqr491").src;
    valueSave491 = 'zSqrArtSpecz490';
    localStorage.setItem(valueSave491, sQz490);
};

function square492(){
    var sQz491 = document.getElementById("imgSqr492").src;
    valueSave492 = 'zSqrArtSpecz491';
    localStorage.setItem(valueSave492, sQz491);
};

function square493(){
    var sQz492 = document.getElementById("imgSqr493").src;
    valueSave493 = 'zSqrArtSpecz492';
    localStorage.setItem(valueSave493, sQz492);
};

function square494(){
    var sQz493 = document.getElementById("imgSqr494").src;
    valueSave494 = 'zSqrArtSpecz493';
    localStorage.setItem(valueSave494, sQz493);
};

function square495(){
    var sQz494 = document.getElementById("imgSqr495").src;
    valueSave495 = 'zSqrArtSpecz494';
    localStorage.setItem(valueSave495, sQz494);
};

function square496(){
    var sQz495 = document.getElementById("imgSqr496").src;
    valueSave496 = 'zSqrArtSpecz495';
    localStorage.setItem(valueSave496, sQz495);
};

function square497(){
    var sQz496 = document.getElementById("imgSqr497").src;
    valueSave497 = 'zSqrArtSpecz496';
    localStorage.setItem(valueSave497, sQz496);
};

function square498(){
    var sQz497 = document.getElementById("imgSqr498").src;
    valueSave498 = 'zSqrArtSpecz497';
    localStorage.setItem(valueSave498, sQz497);
};

function square499(){
    var sQz498 = document.getElementById("imgSqr499").src;
    valueSave499 = 'zSqrArtSpecz498';
    localStorage.setItem(valueSave499, sQz498);
};

function square500(){
    var sQz499 = document.getElementById("imgSqr500").src;
    valueSave500 = 'zSqrArtSpecz499';
    localStorage.setItem(valueSave500, sQz499);
};

function square501(){
    var sQz500 = document.getElementById("imgSqr501").src;
    valueSave501 = 'zSqrArtSpecz500';
    localStorage.setItem(valueSave501, sQz500);
};

function square502(){
    var sQz501 = document.getElementById("imgSqr502").src;
    valueSave502 = 'zSqrArtSpecz501';
    localStorage.setItem(valueSave502, sQz501);
};

function square503(){
    var sQz502 = document.getElementById("imgSqr503").src;
    valueSave503 = 'zSqrArtSpecz502';
    localStorage.setItem(valueSave503, sQz502);
};

function square504(){
    var sQz503 = document.getElementById("imgSqr504").src;
    valueSave504 = 'zSqrArtSpecz503';
    localStorage.setItem(valueSave504, sQz503);
};

function square505(){
    var sQz504 = document.getElementById("imgSqr505").src;
    valueSave505 = 'zSqrArtSpecz504';
    localStorage.setItem(valueSave505, sQz504);
};

function square506(){
    var sQz505 = document.getElementById("imgSqr506").src;
    valueSave506 = 'zSqrArtSpecz505';
    localStorage.setItem(valueSave506, sQz505);
};

function square507(){
    var sQz506 = document.getElementById("imgSqr507").src;
    valueSave507 = 'zSqrArtSpecz506';
    localStorage.setItem(valueSave507, sQz506);
};

function square508(){
    var sQz507 = document.getElementById("imgSqr508").src;
    valueSave508 = 'zSqrArtSpecz507';
    localStorage.setItem(valueSave508, sQz507);
};

function square509(){
    var sQz508 = document.getElementById("imgSqr509").src;
    valueSave509 = 'zSqrArtSpecz508';
    localStorage.setItem(valueSave509, sQz508);
};

function square510(){
    var sQz509 = document.getElementById("imgSqr510").src;
    valueSave510 = 'zSqrArtSpecz509';
    localStorage.setItem(valueSave510, sQz509);
};

function square511(){
    var sQz510 = document.getElementById("imgSqr511").src;
    valueSave511 = 'zSqrArtSpecz510';
    localStorage.setItem(valueSave511, sQz510);
};

function square512(){
    var sQz511 = document.getElementById("imgSqr512").src;
    valueSave512 = 'zSqrArtSpecz511';
    localStorage.setItem(valueSave512, sQz511);
};

function square513(){
    var sQz512 = document.getElementById("imgSqr513").src;
    valueSave513 = 'zSqrArtSpecz512';
    localStorage.setItem(valueSave513, sQz512);
};

function square514(){
    var sQz513 = document.getElementById("imgSqr514").src;
    valueSave514 = 'zSqrArtSpecz513';
    localStorage.setItem(valueSave514, sQz513);
};

function square515(){
    var sQz514 = document.getElementById("imgSqr515").src;
    valueSave515 = 'zSqrArtSpecz514';
    localStorage.setItem(valueSave515, sQz514);
};

function square516(){
    var sQz515 = document.getElementById("imgSqr516").src;
    valueSave516 = 'zSqrArtSpecz515';
    localStorage.setItem(valueSave516, sQz515);
};

function square517(){
    var sQz516 = document.getElementById("imgSqr517").src;
    valueSave517 = 'zSqrArtSpecz516';
    localStorage.setItem(valueSave517, sQz516);
};

function square518(){
    var sQz517 = document.getElementById("imgSqr518").src;
    valueSave518 = 'zSqrArtSpecz517';
    localStorage.setItem(valueSave518, sQz517);
};

function square519(){
    var sQz518 = document.getElementById("imgSqr519").src;
    valueSave519 = 'zSqrArtSpecz518';
    localStorage.setItem(valueSave519, sQz518);
};

function square520(){
    var sQz519 = document.getElementById("imgSqr520").src;
    valueSave520 = 'zSqrArtSpecz519';
    localStorage.setItem(valueSave520, sQz519);
};

function square521(){
    var sQz520 = document.getElementById("imgSqr521").src;
    valueSave521 = 'zSqrArtSpecz520';
    localStorage.setItem(valueSave521, sQz520);
};

function square522(){
    var sQz521 = document.getElementById("imgSqr522").src;
    valueSave522 = 'zSqrArtSpecz521';
    localStorage.setItem(valueSave522, sQz521);
};

function square523(){
    var sQz522 = document.getElementById("imgSqr523").src;
    valueSave523 = 'zSqrArtSpecz522';
    localStorage.setItem(valueSave523, sQz522);
};

function square524(){
    var sQz523 = document.getElementById("imgSqr524").src;
    valueSave524 = 'zSqrArtSpecz523';
    localStorage.setItem(valueSave524, sQz523);
};

function square525(){
    var sQz524 = document.getElementById("imgSqr525").src;
    valueSave525 = 'zSqrArtSpecz524';
    localStorage.setItem(valueSave525, sQz524);
};

function square526(){
    var sQz525 = document.getElementById("imgSqr526").src;
    valueSave526 = 'zSqrArtSpecz525';
    localStorage.setItem(valueSave526, sQz525);
};

function square527(){
    var sQz526 = document.getElementById("imgSqr527").src;
    valueSave527 = 'zSqrArtSpecz526';
    localStorage.setItem(valueSave527, sQz526);
};

function square528(){
    var sQz527 = document.getElementById("imgSqr528").src;
    valueSave528 = 'zSqrArtSpecz527';
    localStorage.setItem(valueSave528, sQz527);
};

function square529(){
    var sQz528 = document.getElementById("imgSqr529").src;
    valueSave529 = 'zSqrArtSpecz528';
    localStorage.setItem(valueSave529, sQz528);
};

function square530(){
    var sQz529 = document.getElementById("imgSqr530").src;
    valueSave530 = 'zSqrArtSpecz529';
    localStorage.setItem(valueSave530, sQz529);
};

function square531(){
    var sQz530 = document.getElementById("imgSqr531").src;
    valueSave531 = 'zSqrArtSpecz530';
    localStorage.setItem(valueSave531, sQz530);
};

function square532(){
    var sQz531 = document.getElementById("imgSqr532").src;
    valueSave532 = 'zSqrArtSpecz531';
    localStorage.setItem(valueSave532, sQz531);
};

function square533(){
    var sQz532 = document.getElementById("imgSqr533").src;
    valueSave533 = 'zSqrArtSpecz532';
    localStorage.setItem(valueSave533, sQz532);
};

function square534(){
    var sQz533 = document.getElementById("imgSqr534").src;
    valueSave534 = 'zSqrArtSpecz533';
    localStorage.setItem(valueSave534, sQz533);
};

function square535(){
    var sQz534 = document.getElementById("imgSqr535").src;
    valueSave535 = 'zSqrArtSpecz534';
    localStorage.setItem(valueSave535, sQz534);
};

function square536(){
    var sQz535 = document.getElementById("imgSqr536").src;
    valueSave536 = 'zSqrArtSpecz535';
    localStorage.setItem(valueSave536, sQz535);
};

function square537(){
    var sQz536 = document.getElementById("imgSqr537").src;
    valueSave537 = 'zSqrArtSpecz536';
    localStorage.setItem(valueSave537, sQz536);
};

function square538(){
    var sQz537 = document.getElementById("imgSqr538").src;
    valueSave538 = 'zSqrArtSpecz537';
    localStorage.setItem(valueSave538, sQz537);
};

function square539(){
    var sQz538 = document.getElementById("imgSqr539").src;
    valueSave539 = 'zSqrArtSpecz538';
    localStorage.setItem(valueSave539, sQz538);
};

function square540(){
    var sQz539 = document.getElementById("imgSqr540").src;
    valueSave540 = 'zSqrArtSpecz539';
    localStorage.setItem(valueSave540, sQz539);
};

function square541(){
    var sQz540 = document.getElementById("imgSqr541").src;
    valueSave541 = 'zSqrArtSpecz540';
    localStorage.setItem(valueSave541, sQz540);
};

function square542(){
    var sQz541 = document.getElementById("imgSqr542").src;
    valueSave542 = 'zSqrArtSpecz541';
    localStorage.setItem(valueSave542, sQz541);
};

function square543(){
    var sQz542 = document.getElementById("imgSqr543").src;
    valueSave543 = 'zSqrArtSpecz542';
    localStorage.setItem(valueSave543, sQz542);
};

function square544(){
    var sQz543 = document.getElementById("imgSqr544").src;
    valueSave544 = 'zSqrArtSpecz543';
    localStorage.setItem(valueSave544, sQz543);
};

function square545(){
    var sQz544 = document.getElementById("imgSqr545").src;
    valueSave545 = 'zSqrArtSpecz544';
    localStorage.setItem(valueSave545, sQz544);
};

function square546(){
    var sQz545 = document.getElementById("imgSqr546").src;
    valueSave546 = 'zSqrArtSpecz545';
    localStorage.setItem(valueSave546, sQz545);
};

function square547(){
    var sQz546 = document.getElementById("imgSqr547").src;
    valueSave547 = 'zSqrArtSpecz546';
    localStorage.setItem(valueSave547, sQz546);
};

function square548(){
    var sQz547 = document.getElementById("imgSqr548").src;
    valueSave548 = 'zSqrArtSpecz547';
    localStorage.setItem(valueSave548, sQz547);
};

function square549(){
    var sQz548 = document.getElementById("imgSqr549").src;
    valueSave549 = 'zSqrArtSpecz548';
    localStorage.setItem(valueSave549, sQz548);
};

function square550(){
    var sQz549 = document.getElementById("imgSqr550").src;
    valueSave550 = 'zSqrArtSpecz549';
    localStorage.setItem(valueSave550, sQz549);
};

function square551(){
    var sQz550 = document.getElementById("imgSqr551").src;
    valueSave551 = 'zSqrArtSpecz550';
    localStorage.setItem(valueSave551, sQz550);
};

function square552(){
    var sQz551 = document.getElementById("imgSqr552").src;
    valueSave552 = 'zSqrArtSpecz551';
    localStorage.setItem(valueSave552, sQz551);
};

function square553(){
    var sQz552 = document.getElementById("imgSqr553").src;
    valueSave553 = 'zSqrArtSpecz552';
    localStorage.setItem(valueSave553, sQz552);
};

function square554(){
    var sQz553 = document.getElementById("imgSqr554").src;
    valueSave554 = 'zSqrArtSpecz553';
    localStorage.setItem(valueSave554, sQz553);
};

function square555(){
    var sQz554 = document.getElementById("imgSqr555").src;
    valueSave555 = 'zSqrArtSpecz554';
    localStorage.setItem(valueSave555, sQz554);
};

function square556(){
    var sQz555 = document.getElementById("imgSqr556").src;
    valueSave556 = 'zSqrArtSpecz555';
    localStorage.setItem(valueSave556, sQz555);
};

function square557(){
    var sQz556 = document.getElementById("imgSqr557").src;
    valueSave557 = 'zSqrArtSpecz556';
    localStorage.setItem(valueSave557, sQz556);
};

function square558(){
    var sQz557 = document.getElementById("imgSqr558").src;
    valueSave558 = 'zSqrArtSpecz557';
    localStorage.setItem(valueSave558, sQz557);
};

function square559(){
    var sQz558 = document.getElementById("imgSqr559").src;
    valueSave559 = 'zSqrArtSpecz558';
    localStorage.setItem(valueSave559, sQz558);
};

function square560(){
    var sQz559 = document.getElementById("imgSqr560").src;
    valueSave560 = 'zSqrArtSpecz559';
    localStorage.setItem(valueSave560, sQz559);
};

function square561(){
    var sQz560 = document.getElementById("imgSqr561").src;
    valueSave561 = 'zSqrArtSpecz560';
    localStorage.setItem(valueSave561, sQz560);
};

function square562(){
    var sQz561 = document.getElementById("imgSqr562").src;
    valueSave562 = 'zSqrArtSpecz561';
    localStorage.setItem(valueSave562, sQz561);
};

function square563(){
    var sQz562 = document.getElementById("imgSqr563").src;
    valueSave563 = 'zSqrArtSpecz562';
    localStorage.setItem(valueSave563, sQz562);
};

function square564(){
    var sQz563 = document.getElementById("imgSqr564").src;
    valueSave564 = 'zSqrArtSpecz563';
    localStorage.setItem(valueSave564, sQz563);
};

function square565(){
    var sQz564 = document.getElementById("imgSqr565").src;
    valueSave565 = 'zSqrArtSpecz564';
    localStorage.setItem(valueSave565, sQz564);
};

function square566(){
    var sQz565 = document.getElementById("imgSqr566").src;
    valueSave566 = 'zSqrArtSpecz565';
    localStorage.setItem(valueSave566, sQz565);
};

function square567(){
    var sQz566 = document.getElementById("imgSqr567").src;
    valueSave567 = 'zSqrArtSpecz566';
    localStorage.setItem(valueSave567, sQz566);
};

function square568(){
    var sQz567 = document.getElementById("imgSqr568").src;
    valueSave568 = 'zSqrArtSpecz567';
    localStorage.setItem(valueSave568, sQz567);
};

function square569(){
    var sQz568 = document.getElementById("imgSqr569").src;
    valueSave569 = 'zSqrArtSpecz568';
    localStorage.setItem(valueSave569, sQz568);
};

function square570(){
    var sQz569 = document.getElementById("imgSqr570").src;
    valueSave570 = 'zSqrArtSpecz569';
    localStorage.setItem(valueSave570, sQz569);
};

function square571(){
    var sQz570 = document.getElementById("imgSqr571").src;
    valueSave571 = 'zSqrArtSpecz570';
    localStorage.setItem(valueSave571, sQz570);
};

function square572(){
    var sQz571 = document.getElementById("imgSqr572").src;
    valueSave572 = 'zSqrArtSpecz571';
    localStorage.setItem(valueSave572, sQz571);
};

function square573(){
    var sQz572 = document.getElementById("imgSqr573").src;
    valueSave573 = 'zSqrArtSpecz572';
    localStorage.setItem(valueSave573, sQz572);
};

function square574(){
    var sQz573 = document.getElementById("imgSqr574").src;
    valueSave574 = 'zSqrArtSpecz573';
    localStorage.setItem(valueSave574, sQz573);
};

function square575(){
    var sQz574 = document.getElementById("imgSqr575").src;
    valueSave575 = 'zSqrArtSpecz574';
    localStorage.setItem(valueSave575, sQz574);
};

function square576(){
    var sQz575 = document.getElementById("imgSqr576").src;
    valueSave576 = 'zSqrArtSpecz575';
    localStorage.setItem(valueSave576, sQz575);
};

function square577(){
    var sQz576 = document.getElementById("imgSqr577").src;
    valueSave577 = 'zSqrArtSpecz576';
    localStorage.setItem(valueSave577, sQz576);
};

function square578(){
    var sQz577 = document.getElementById("imgSqr578").src;
    valueSave578 = 'zSqrArtSpecz577';
    localStorage.setItem(valueSave578, sQz577);
};

function square579(){
    var sQz578 = document.getElementById("imgSqr579").src;
    valueSave579 = 'zSqrArtSpecz578';
    localStorage.setItem(valueSave579, sQz578);
};

function square580(){
    var sQz579 = document.getElementById("imgSqr580").src;
    valueSave580 = 'zSqrArtSpecz579';
    localStorage.setItem(valueSave580, sQz579);
};

function square581(){
    var sQz580 = document.getElementById("imgSqr581").src;
    valueSave581 = 'zSqrArtSpecz580';
    localStorage.setItem(valueSave581, sQz580);
};

function square582(){
    var sQz581 = document.getElementById("imgSqr582").src;
    valueSave582 = 'zSqrArtSpecz581';
    localStorage.setItem(valueSave582, sQz581);
};

function square583(){
    var sQz582 = document.getElementById("imgSqr583").src;
    valueSave583 = 'zSqrArtSpecz582';
    localStorage.setItem(valueSave583, sQz582);
};

function square584(){
    var sQz583 = document.getElementById("imgSqr584").src;
    valueSave584 = 'zSqrArtSpecz583';
    localStorage.setItem(valueSave584, sQz583);
};

function square585(){
    var sQz584 = document.getElementById("imgSqr585").src;
    valueSave585 = 'zSqrArtSpecz584';
    localStorage.setItem(valueSave585, sQz584);
};

function square586(){
    var sQz585 = document.getElementById("imgSqr586").src;
    valueSave586 = 'zSqrArtSpecz585';
    localStorage.setItem(valueSave586, sQz585);
};

function square587(){
    var sQz586 = document.getElementById("imgSqr587").src;
    valueSave587 = 'zSqrArtSpecz586';
    localStorage.setItem(valueSave587, sQz586);
};

function square588(){
    var sQz587 = document.getElementById("imgSqr588").src;
    valueSave588 = 'zSqrArtSpecz587';
    localStorage.setItem(valueSave588, sQz587);
};

function square589(){
    var sQz588 = document.getElementById("imgSqr589").src;
    valueSave589 = 'zSqrArtSpecz588';
    localStorage.setItem(valueSave589, sQz588);
};

function square590(){
    var sQz589 = document.getElementById("imgSqr590").src;
    valueSave590 = 'zSqrArtSpecz589';
    localStorage.setItem(valueSave590, sQz589);
};

function square591(){
    var sQz590 = document.getElementById("imgSqr591").src;
    valueSave591 = 'zSqrArtSpecz590';
    localStorage.setItem(valueSave591, sQz590);
};

function square592(){
    var sQz591 = document.getElementById("imgSqr592").src;
    valueSave592 = 'zSqrArtSpecz591';
    localStorage.setItem(valueSave592, sQz591);
};

function square593(){
    var sQz592 = document.getElementById("imgSqr593").src;
    valueSave593 = 'zSqrArtSpecz592';
    localStorage.setItem(valueSave593, sQz592);
};

function square594(){
    var sQz593 = document.getElementById("imgSqr594").src;
    valueSave594 = 'zSqrArtSpecz593';
    localStorage.setItem(valueSave594, sQz593);
};

function square595(){
    var sQz594 = document.getElementById("imgSqr595").src;
    valueSave595 = 'zSqrArtSpecz594';
    localStorage.setItem(valueSave595, sQz594);
};

function square596(){
    var sQz595 = document.getElementById("imgSqr596").src;
    valueSave596 = 'zSqrArtSpecz595';
    localStorage.setItem(valueSave596, sQz595);
};

function square597(){
    var sQz596 = document.getElementById("imgSqr597").src;
    valueSave597 = 'zSqrArtSpecz596';
    localStorage.setItem(valueSave597, sQz596);
};

function square598(){
    var sQz597 = document.getElementById("imgSqr598").src;
    valueSave598 = 'zSqrArtSpecz597';
    localStorage.setItem(valueSave598, sQz597);
};

function square599(){
    var sQz598 = document.getElementById("imgSqr599").src;
    valueSave599 = 'zSqrArtSpecz598';
    localStorage.setItem(valueSave599, sQz598);
};

function square600(){
    var sQz599 = document.getElementById("imgSqr600").src;
    valueSave600 = 'zSqrArtSpecz599';
    localStorage.setItem(valueSave600, sQz599);
};

function square601(){
    var sQz600 = document.getElementById("imgSqr601").src;
    valueSave601 = 'zSqrArtSpecz600';
    localStorage.setItem(valueSave601, sQz600);
};

function square602(){
    var sQz601 = document.getElementById("imgSqr602").src;
    valueSave602 = 'zSqrArtSpecz601';
    localStorage.setItem(valueSave602, sQz601);
};

function square603(){
    var sQz602 = document.getElementById("imgSqr603").src;
    valueSave603 = 'zSqrArtSpecz602';
    localStorage.setItem(valueSave603, sQz602);
};

function square604(){
    var sQz603 = document.getElementById("imgSqr604").src;
    valueSave604 = 'zSqrArtSpecz603';
    localStorage.setItem(valueSave604, sQz603);
};

function square605(){
    var sQz604 = document.getElementById("imgSqr605").src;
    valueSave605 = 'zSqrArtSpecz604';
    localStorage.setItem(valueSave605, sQz604);
};

function square606(){
    var sQz605 = document.getElementById("imgSqr606").src;
    valueSave606 = 'zSqrArtSpecz605';
    localStorage.setItem(valueSave606, sQz605);
};

function square607(){
    var sQz606 = document.getElementById("imgSqr607").src;
    valueSave607 = 'zSqrArtSpecz606';
    localStorage.setItem(valueSave607, sQz606);
};

function square608(){
    var sQz607 = document.getElementById("imgSqr608").src;
    valueSave608 = 'zSqrArtSpecz607';
    localStorage.setItem(valueSave608, sQz607);
};

function square609(){
    var sQz608 = document.getElementById("imgSqr609").src;
    valueSave609 = 'zSqrArtSpecz608';
    localStorage.setItem(valueSave609, sQz608);
};

function square610(){
    var sQz609 = document.getElementById("imgSqr610").src;
    valueSave610 = 'zSqrArtSpecz609';
    localStorage.setItem(valueSave610, sQz609);
};

function square611(){
    var sQz610 = document.getElementById("imgSqr611").src;
    valueSave611 = 'zSqrArtSpecz610';
    localStorage.setItem(valueSave611, sQz610);
};

function square612(){
    var sQz611 = document.getElementById("imgSqr612").src;
    valueSave612 = 'zSqrArtSpecz611';
    localStorage.setItem(valueSave612, sQz611);
};

function square613(){
    var sQz612 = document.getElementById("imgSqr613").src;
    valueSave613 = 'zSqrArtSpecz612';
    localStorage.setItem(valueSave613, sQz612);
};

function square614(){
    var sQz613 = document.getElementById("imgSqr614").src;
    valueSave614 = 'zSqrArtSpecz613';
    localStorage.setItem(valueSave614, sQz613);
};

function square615(){
    var sQz614 = document.getElementById("imgSqr615").src;
    valueSave615 = 'zSqrArtSpecz614';
    localStorage.setItem(valueSave615, sQz614);
};

function square616(){
    var sQz615 = document.getElementById("imgSqr616").src;
    valueSave616 = 'zSqrArtSpecz615';
    localStorage.setItem(valueSave616, sQz615);
};

function square617(){
    var sQz616 = document.getElementById("imgSqr617").src;
    valueSave617 = 'zSqrArtSpecz616';
    localStorage.setItem(valueSave617, sQz616);
};

function square618(){
    var sQz617 = document.getElementById("imgSqr618").src;
    valueSave618 = 'zSqrArtSpecz617';
    localStorage.setItem(valueSave618, sQz617);
};

function square619(){
    var sQz618 = document.getElementById("imgSqr619").src;
    valueSave619 = 'zSqrArtSpecz618';
    localStorage.setItem(valueSave619, sQz618);
};

function square620(){
    var sQz619 = document.getElementById("imgSqr620").src;
    valueSave620 = 'zSqrArtSpecz619';
    localStorage.setItem(valueSave620, sQz619);
};

function square621(){
    var sQz620 = document.getElementById("imgSqr621").src;
    valueSave621 = 'zSqrArtSpecz620';
    localStorage.setItem(valueSave621, sQz620);
};

function square622(){
    var sQz621 = document.getElementById("imgSqr622").src;
    valueSave622 = 'zSqrArtSpecz621';
    localStorage.setItem(valueSave622, sQz621);
};

function square623(){
    var sQz622 = document.getElementById("imgSqr623").src;
    valueSave623 = 'zSqrArtSpecz622';
    localStorage.setItem(valueSave623, sQz622);
};

function square624(){
    var sQz623 = document.getElementById("imgSqr624").src;
    valueSave624 = 'zSqrArtSpecz623';
    localStorage.setItem(valueSave624, sQz623);
};

function square625(){
    var sQz624 = document.getElementById("imgSqr625").src;
    valueSave625 = 'zSqrArtSpecz624';
    localStorage.setItem(valueSave625, sQz624);
};

function setAThis(){
    square1()
    square2()
    square3()
    square4()
    square5()
    square6()
    square7()
    square8()
    square9()
    square10()
    square11()
    square12()
    square13()
    square14()
    square15()
    square16()
    square17()
    square18()
    square19()
    square20()
    square21()
    square22()
    square23()
    square24()
    square25()
    square26()
    square27()
    square28()
    square29()
    square30()
    square31()
    square32()
    square33()
    square34()
    square35()
    square36()
    square37()
    square38()
    square39()
    square40()
    square41()
    square42()
    square43()
    square44()
    square45()
    square46()
    square47()
    square48()
    square49()
    square50()
    square51()
    square52()
    square53()
    square54()
    square55()
    square56()
    square57()
    square58()
    square59()
    square60()
    square61()
    square62()
    square63()
    square64()
    square65()
    square66()
    square67()
    square68()
    square69()
    square70()
    square71()
    square72()
    square73()
    square74()
    square75()
    square76()
    square77()
    square78()
    square79()
    square80()
    square81()
    square82()
    square83()
    square84()
    square85()
    square86()
    square87()
    square88()
    square89()
    square90()
    square91()
    square92()
    square93()
    square94()
    square95()
    square96()
    square97()
    square98()
    square99()
    square100()
    square101()
    square102()
    square103()
    square104()
    square105()
    square106()
    square107()
    square108()
    square109()
    square110()
    square111()
    square112()
    square113()
    square114()
    square115()
    square116()
    square117()
    square118()
    square119()
    square120()
    square121()
    square122()
    square123()
    square124()
    square125()
    square126()
    square127()
    square128()
    square129()
    square130()
    square131()
    square132()
    square133()
    square134()
    square135()
    square136()
    square137()
    square138()
    square139()
    square140()
    square141()
    square142()
    square143()
    square144()
    square145()
    square146()
    square147()
    square148()
    square149()
    square150()
    square151()
    square152()
    square153()
    square154()
    square155()
    square156()
    square157()
    square158()
    square159()
    square160()
    square161()
    square162()
    square163()
    square164()
    square165()
    square166()
    square167()
    square168()
    square169()
    square170()
    square171()
    square172()
    square173()
    square174()
    square175()
    square176()
    square177()
    square178()
    square179()
    square180()
    square181()
    square182()
    square183()
    square184()
    square185()
    square186()
    square187()
    square188()
    square189()
    square190()
    square191()
    square192()
    square193()
    square194()
    square195()
    square196()
    square197()
    square198()
    square199()
    square200()
    square201()
    square202()
    square203()
    square204()
    square205()
    square206()
    square207()
    square208()
    square209()
    square210()
    square211()
    square212()
    square213()
    square214()
    square215()
    square216()
    square217()
    square218()
    square219()
    square220()
    square221()
    square222()
    square223()
    square224()
    square225()
    square226()
    square227()
    square228()
    square229()
    square230()
    square231()
    square232()
    square233()
    square234()
    square235()
    square236()
    square237()
    square238()
    square239()
    square240()
    square241()
    square242()
    square243()
    square244()
    square245()
    square246()
    square247()
    square248()
    square249()
    square250()
    square251()
    square252()
    square253()
    square254()
    square255()
    square256()
    square257()
    square258()
    square259()
    square260()
    square261()
    square262()
    square263()
    square264()
    square265()
    square266()
    square267()
    square268()
    square269()
    square270()
    square271()
    square272()
    square273()
    square274()
    square275()
    square276()
    square277()
    square278()
    square279()
    square280()
    square281()
    square282()
    square283()
    square284()
    square285()
    square286()
    square287()
    square288()
    square289()
    square290()
    square291()
    square292()
    square293()
    square294()
    square295()
    square296()
    square297()
    square298()
    square299()
    square300()
    square301()
    square302()
    square303()
    square304()
    square305()
    square306()
    square307()
    square308()
    square309()
    square310()
    square311()
    square312()
    square313()
    square314()
    square315()
    square316()
    square317()
    square318()
    square319()
    square320()
    square321()
    square322()
    square323()
    square324()
    square325()
    square326()
    square327()
    square328()
    square329()
    square330()
    square331()
    square332()
    square333()
    square334()
    square335()
    square336()
    square337()
    square338()
    square339()
    square340()
    square341()
    square342()
    square343()
    square344()
    square345()
    square346()
    square347()
    square348()
    square349()
    square350()
    square351()
    square352()
    square353()
    square354()
    square355()
    square356()
    square357()
    square358()
    square359()
    square360()
    square361()
    square362()
    square363()
    square364()
    square365()
    square366()
    square367()
    square368()
    square369()
    square370()
    square371()
    square372()
    square373()
    square374()
    square375()
    square376()
    square377()
    square378()
    square379()
    square380()
    square381()
    square382()
    square383()
    square384()
    square385()
    square386()
    square387()
    square388()
    square389()
    square390()
    square391()
    square392()
    square393()
    square394()
    square395()
    square396()
    square397()
    square398()
    square399()
    square400()
    square401()
    square402()
    square403()
    square404()
    square405()
    square406()
    square407()
    square408()
    square409()
    square410()
    square411()
    square412()
    square413()
    square414()
    square415()
    square416()
    square417()
    square418()
    square419()
    square420()
    square421()
    square422()
    square423()
    square424()
    square425()
    square426()
    square427()
    square428()
    square429()
    square430()
    square431()
    square432()
    square433()
    square434()
    square435()
    square436()
    square437()
    square438()
    square439()
    square440()
    square441()
    square442()
    square443()
    square444()
    square445()
    square446()
    square447()
    square448()
    square449()
    square450()
    square451()
    square452()
    square453()
    square454()
    square455()
    square456()
    square457()
    square458()
    square459()
    square460()
    square461()
    square462()
    square463()
    square464()
    square465()
    square466()
    square467()
    square468()
    square469()
    square470()
    square471()
    square472()
    square473()
    square474()
    square475()
    square476()
    square477()
    square478()
    square479()
    square480()
    square481()
    square482()
    square483()
    square484()
    square485()
    square486()
    square487()
    square488()
    square489()
    square490()
    square491()
    square492()
    square493()
    square494()
    square495()
    square496()
    square497()
    square498()
    square499()
    square500()
    square501()
    square502()
    square503()
    square504()
    square505()
    square506()
    square507()
    square508()
    square509()
    square510()
    square511()
    square512()
    square513()
    square514()
    square515()
    square516()
    square517()
    square518()
    square519()
    square520()
    square521()
    square522()
    square523()
    square524()
    square525()
    square526()
    square527()
    square528()
    square529()
    square530()
    square531()
    square532()
    square533()
    square534()
    square535()
    square536()
    square537()
    square538()
    square539()
    square540()
    square541()
    square542()
    square543()
    square544()
    square545()
    square546()
    square547()
    square548()
    square549()
    square550()
    square551()
    square552()
    square553()
    square554()
    square555()
    square556()
    square557()
    square558()
    square559()
    square560()
    square561()
    square562()
    square563()
    square564()
    square565()
    square566()
    square567()
    square568()
    square569()
    square570()
    square571()
    square572()
    square573()
    square574()
    square575()
    square576()
    square577()
    square578()
    square579()
    square580()
    square581()
    square582()
    square583()
    square584()
    square585()
    square586()
    square587()
    square588()
    square589()
    square590()
    square591()
    square592()
    square593()
    square594()
    square595()
    square596()
    square597()
    square598()
    square599()
    square600()
    square601()
    square602()
    square603()
    square604()
    square605()
    square606()
    square607()
    square608()
    square609()
    square610()
    square611()
    square612()
    square613()
    square614()
    square615()
    square616()
    square617()
    square618()
    square619()
    square620()
    square621()
    square622()
    square623()
    square624()
    
    square625()
    alert("Your art has been saved locally, to your local browser storage.");
};
function squareToSzzZValue0(){
    valueSave = 'zSqrArtSpecz0';
    var tripleZeroA = localStorage.getItem(valueSave);
    document.getElementById("imgSqr1").src = tripleZeroA;
};

function squareToSzzZValue1(){
    valueSave = 'zSqrArtSpecz1';
    var tripleZero0 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr2").src = tripleZero0;
};

function squareToSzzZValue2(){
    valueSave = 'zSqrArtSpecz2';
    var tripleZero1 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr3").src = tripleZero1;
};

function squareToSzzZValue3(){
    valueSave = 'zSqrArtSpecz3';
    var tripleZero2 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr4").src = tripleZero2;
};

function squareToSzzZValue4(){
    valueSave = 'zSqrArtSpecz4';
    var tripleZero3 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr5").src = tripleZero3;
};

function squareToSzzZValue5(){
    valueSave = 'zSqrArtSpecz5';
    var tripleZero4 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr6").src = tripleZero4;
};

function squareToSzzZValue6(){
    valueSave = 'zSqrArtSpecz6';
    var tripleZero5 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr7").src = tripleZero5;
};

function squareToSzzZValue7(){
    valueSave = 'zSqrArtSpecz7';
    var tripleZero6 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr8").src = tripleZero6;
};

function squareToSzzZValue8(){
    valueSave = 'zSqrArtSpecz8';
    var tripleZero7 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr9").src = tripleZero7;
};

function squareToSzzZValue9(){
    valueSave = 'zSqrArtSpecz9';
    var tripleZero8 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr10").src = tripleZero8;
};

function squareToSzzZValue10(){
    valueSave = 'zSqrArtSpecz10';
    var tripleZero9 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr11").src = tripleZero9;
};

function squareToSzzZValue11(){
    valueSave = 'zSqrArtSpecz11';
    var tripleZero10 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr12").src = tripleZero10;
};

function squareToSzzZValue12(){
    valueSave = 'zSqrArtSpecz12';
    var tripleZero11 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr13").src = tripleZero11;
};

function squareToSzzZValue13(){
    valueSave = 'zSqrArtSpecz13';
    var tripleZero12 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr14").src = tripleZero12;
};

function squareToSzzZValue14(){
    valueSave = 'zSqrArtSpecz14';
    var tripleZero13 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr15").src = tripleZero13;
};

function squareToSzzZValue15(){
    valueSave = 'zSqrArtSpecz15';
    var tripleZero14 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr16").src = tripleZero14;
};

function squareToSzzZValue16(){
    valueSave = 'zSqrArtSpecz16';
    var tripleZero15 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr17").src = tripleZero15;
};

function squareToSzzZValue17(){
    valueSave = 'zSqrArtSpecz17';
    var tripleZero16 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr18").src = tripleZero16;
};

function squareToSzzZValue18(){
    valueSave = 'zSqrArtSpecz18';
    var tripleZero17 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr19").src = tripleZero17;
};

function squareToSzzZValue19(){
    valueSave = 'zSqrArtSpecz19';
    var tripleZero18 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr20").src = tripleZero18;
};

function squareToSzzZValue20(){
    valueSave = 'zSqrArtSpecz20';
    var tripleZero19 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr21").src = tripleZero19;
};

function squareToSzzZValue21(){
    valueSave = 'zSqrArtSpecz21';
    var tripleZero20 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr22").src = tripleZero20;
};

function squareToSzzZValue22(){
    valueSave = 'zSqrArtSpecz22';
    var tripleZero21 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr23").src = tripleZero21;
};

function squareToSzzZValue23(){
    valueSave = 'zSqrArtSpecz23';
    var tripleZero22 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr24").src = tripleZero22;
};

function squareToSzzZValue24(){
    valueSave = 'zSqrArtSpecz24';
    var tripleZero23 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr25").src = tripleZero23;
};

function squareToSzzZValue25(){
    valueSave = 'zSqrArtSpecz25';
    var tripleZero24 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr26").src = tripleZero24;
};

function squareToSzzZValue26(){
    valueSave = 'zSqrArtSpecz26';
    var tripleZero25 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr27").src = tripleZero25;
};

function squareToSzzZValue27(){
    valueSave = 'zSqrArtSpecz27';
    var tripleZero26 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr28").src = tripleZero26;
};

function squareToSzzZValue28(){
    valueSave = 'zSqrArtSpecz28';
    var tripleZero27 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr29").src = tripleZero27;
};

function squareToSzzZValue29(){
    valueSave = 'zSqrArtSpecz29';
    var tripleZero28 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr30").src = tripleZero28;
};

function squareToSzzZValue30(){
    valueSave = 'zSqrArtSpecz30';
    var tripleZero29 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr31").src = tripleZero29;
};

function squareToSzzZValue31(){
    valueSave = 'zSqrArtSpecz31';
    var tripleZero30 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr32").src = tripleZero30;
};

function squareToSzzZValue32(){
    valueSave = 'zSqrArtSpecz32';
    var tripleZero31 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr33").src = tripleZero31;
};

function squareToSzzZValue33(){
    valueSave = 'zSqrArtSpecz33';
    var tripleZero32 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr34").src = tripleZero32;
};

function squareToSzzZValue34(){
    valueSave = 'zSqrArtSpecz34';
    var tripleZero33 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr35").src = tripleZero33;
};

function squareToSzzZValue35(){
    valueSave = 'zSqrArtSpecz35';
    var tripleZero34 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr36").src = tripleZero34;
};

function squareToSzzZValue36(){
    valueSave = 'zSqrArtSpecz36';
    var tripleZero35 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr37").src = tripleZero35;
};

function squareToSzzZValue37(){
    valueSave = 'zSqrArtSpecz37';
    var tripleZero36 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr38").src = tripleZero36;
};

function squareToSzzZValue38(){
    valueSave = 'zSqrArtSpecz38';
    var tripleZero37 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr39").src = tripleZero37;
};

function squareToSzzZValue39(){
    valueSave = 'zSqrArtSpecz39';
    var tripleZero38 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr40").src = tripleZero38;
};

function squareToSzzZValue40(){
    valueSave = 'zSqrArtSpecz40';
    var tripleZero39 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr41").src = tripleZero39;
};

function squareToSzzZValue41(){
    valueSave = 'zSqrArtSpecz41';
    var tripleZero40 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr42").src = tripleZero40;
};

function squareToSzzZValue42(){
    valueSave = 'zSqrArtSpecz42';
    var tripleZero41 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr43").src = tripleZero41;
};

function squareToSzzZValue43(){
    valueSave = 'zSqrArtSpecz43';
    var tripleZero42 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr44").src = tripleZero42;
};

function squareToSzzZValue44(){
    valueSave = 'zSqrArtSpecz44';
    var tripleZero43 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr45").src = tripleZero43;
};

function squareToSzzZValue45(){
    valueSave = 'zSqrArtSpecz45';
    var tripleZero44 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr46").src = tripleZero44;
};

function squareToSzzZValue46(){
    valueSave = 'zSqrArtSpecz46';
    var tripleZero45 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr47").src = tripleZero45;
};

function squareToSzzZValue47(){
    valueSave = 'zSqrArtSpecz47';
    var tripleZero46 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr48").src = tripleZero46;
};

function squareToSzzZValue48(){
    valueSave = 'zSqrArtSpecz48';
    var tripleZero47 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr49").src = tripleZero47;
};

function squareToSzzZValue49(){
    valueSave = 'zSqrArtSpecz49';
    var tripleZero48 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr50").src = tripleZero48;
};

function squareToSzzZValue50(){
    valueSave = 'zSqrArtSpecz50';
    var tripleZero49 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr51").src = tripleZero49;
};

function squareToSzzZValue51(){
    valueSave = 'zSqrArtSpecz51';
    var tripleZero50 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr52").src = tripleZero50;
};

function squareToSzzZValue52(){
    valueSave = 'zSqrArtSpecz52';
    var tripleZero51 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr53").src = tripleZero51;
};

function squareToSzzZValue53(){
    valueSave = 'zSqrArtSpecz53';
    var tripleZero52 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr54").src = tripleZero52;
};

function squareToSzzZValue54(){
    valueSave = 'zSqrArtSpecz54';
    var tripleZero53 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr55").src = tripleZero53;
};

function squareToSzzZValue55(){
    valueSave = 'zSqrArtSpecz55';
    var tripleZero54 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr56").src = tripleZero54;
};

function squareToSzzZValue56(){
    valueSave = 'zSqrArtSpecz56';
    var tripleZero55 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr57").src = tripleZero55;
};

function squareToSzzZValue57(){
    valueSave = 'zSqrArtSpecz57';
    var tripleZero56 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr58").src = tripleZero56;
};

function squareToSzzZValue58(){
    valueSave = 'zSqrArtSpecz58';
    var tripleZero57 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr59").src = tripleZero57;
};

function squareToSzzZValue59(){
    valueSave = 'zSqrArtSpecz59';
    var tripleZero58 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr60").src = tripleZero58;
};

function squareToSzzZValue60(){
    valueSave = 'zSqrArtSpecz60';
    var tripleZero59 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr61").src = tripleZero59;
};

function squareToSzzZValue61(){
    valueSave = 'zSqrArtSpecz61';
    var tripleZero60 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr62").src = tripleZero60;
};

function squareToSzzZValue62(){
    valueSave = 'zSqrArtSpecz62';
    var tripleZero61 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr63").src = tripleZero61;
};

function squareToSzzZValue63(){
    valueSave = 'zSqrArtSpecz63';
    var tripleZero62 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr64").src = tripleZero62;
};

function squareToSzzZValue64(){
    valueSave = 'zSqrArtSpecz64';
    var tripleZero63 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr65").src = tripleZero63;
};

function squareToSzzZValue65(){
    valueSave = 'zSqrArtSpecz65';
    var tripleZero64 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr66").src = tripleZero64;
};

function squareToSzzZValue66(){
    valueSave = 'zSqrArtSpecz66';
    var tripleZero65 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr67").src = tripleZero65;
};

function squareToSzzZValue67(){
    valueSave = 'zSqrArtSpecz67';
    var tripleZero66 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr68").src = tripleZero66;
};

function squareToSzzZValue68(){
    valueSave = 'zSqrArtSpecz68';
    var tripleZero67 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr69").src = tripleZero67;
};

function squareToSzzZValue69(){
    valueSave = 'zSqrArtSpecz69';
    var tripleZero68 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr70").src = tripleZero68;
};

function squareToSzzZValue70(){
    valueSave = 'zSqrArtSpecz70';
    var tripleZero69 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr71").src = tripleZero69;
};

function squareToSzzZValue71(){
    valueSave = 'zSqrArtSpecz71';
    var tripleZero70 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr72").src = tripleZero70;
};

function squareToSzzZValue72(){
    valueSave = 'zSqrArtSpecz72';
    var tripleZero71 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr73").src = tripleZero71;
};

function squareToSzzZValue73(){
    valueSave = 'zSqrArtSpecz73';
    var tripleZero72 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr74").src = tripleZero72;
};

function squareToSzzZValue74(){
    valueSave = 'zSqrArtSpecz74';
    var tripleZero73 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr75").src = tripleZero73;
};

function squareToSzzZValue75(){
    valueSave = 'zSqrArtSpecz75';
    var tripleZero74 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr76").src = tripleZero74;
};

function squareToSzzZValue76(){
    valueSave = 'zSqrArtSpecz76';
    var tripleZero75 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr77").src = tripleZero75;
};

function squareToSzzZValue77(){
    valueSave = 'zSqrArtSpecz77';
    var tripleZero76 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr78").src = tripleZero76;
};

function squareToSzzZValue78(){
    valueSave = 'zSqrArtSpecz78';
    var tripleZero77 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr79").src = tripleZero77;
};

function squareToSzzZValue79(){
    valueSave = 'zSqrArtSpecz79';
    var tripleZero78 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr80").src = tripleZero78;
};

function squareToSzzZValue80(){
    valueSave = 'zSqrArtSpecz80';
    var tripleZero79 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr81").src = tripleZero79;
};

function squareToSzzZValue81(){
    valueSave = 'zSqrArtSpecz81';
    var tripleZero80 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr82").src = tripleZero80;
};

function squareToSzzZValue82(){
    valueSave = 'zSqrArtSpecz82';
    var tripleZero81 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr83").src = tripleZero81;
};

function squareToSzzZValue83(){
    valueSave = 'zSqrArtSpecz83';
    var tripleZero82 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr84").src = tripleZero82;
};

function squareToSzzZValue84(){
    valueSave = 'zSqrArtSpecz84';
    var tripleZero83 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr85").src = tripleZero83;
};

function squareToSzzZValue85(){
    valueSave = 'zSqrArtSpecz85';
    var tripleZero84 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr86").src = tripleZero84;
};

function squareToSzzZValue86(){
    valueSave = 'zSqrArtSpecz86';
    var tripleZero85 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr87").src = tripleZero85;
};

function squareToSzzZValue87(){
    valueSave = 'zSqrArtSpecz87';
    var tripleZero86 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr88").src = tripleZero86;
};

function squareToSzzZValue88(){
    valueSave = 'zSqrArtSpecz88';
    var tripleZero87 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr89").src = tripleZero87;
};

function squareToSzzZValue89(){
    valueSave = 'zSqrArtSpecz89';
    var tripleZero88 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr90").src = tripleZero88;
};

function squareToSzzZValue90(){
    valueSave = 'zSqrArtSpecz90';
    var tripleZero89 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr91").src = tripleZero89;
};

function squareToSzzZValue91(){
    valueSave = 'zSqrArtSpecz91';
    var tripleZero90 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr92").src = tripleZero90;
};

function squareToSzzZValue92(){
    valueSave = 'zSqrArtSpecz92';
    var tripleZero91 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr93").src = tripleZero91;
};

function squareToSzzZValue93(){
    valueSave = 'zSqrArtSpecz93';
    var tripleZero92 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr94").src = tripleZero92;
};

function squareToSzzZValue94(){
    valueSave = 'zSqrArtSpecz94';
    var tripleZero93 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr95").src = tripleZero93;
};

function squareToSzzZValue95(){
    valueSave = 'zSqrArtSpecz95';
    var tripleZero94 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr96").src = tripleZero94;
};

function squareToSzzZValue96(){
    valueSave = 'zSqrArtSpecz96';
    var tripleZero95 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr97").src = tripleZero95;
};

function squareToSzzZValue97(){
    valueSave = 'zSqrArtSpecz97';
    var tripleZero96 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr98").src = tripleZero96;
};

function squareToSzzZValue98(){
    valueSave = 'zSqrArtSpecz98';
    var tripleZero97 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr99").src = tripleZero97;
};

function squareToSzzZValue99(){
    valueSave = 'zSqrArtSpecz99';
    var tripleZero98 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr100").src = tripleZero98;
};

function squareToSzzZValue100(){
    valueSave = 'zSqrArtSpecz100';
    var tripleZero99 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr101").src = tripleZero99;
};

function squareToSzzZValue101(){
    valueSave = 'zSqrArtSpecz101';
    var tripleZero100 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr102").src = tripleZero100;
};

function squareToSzzZValue102(){
    valueSave = 'zSqrArtSpecz102';
    var tripleZero101 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr103").src = tripleZero101;
};

function squareToSzzZValue103(){
    valueSave = 'zSqrArtSpecz103';
    var tripleZero102 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr104").src = tripleZero102;
};

function squareToSzzZValue104(){
    valueSave = 'zSqrArtSpecz104';
    var tripleZero103 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr105").src = tripleZero103;
};

function squareToSzzZValue105(){
    valueSave = 'zSqrArtSpecz105';
    var tripleZero104 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr106").src = tripleZero104;
};

function squareToSzzZValue106(){
    valueSave = 'zSqrArtSpecz106';
    var tripleZero105 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr107").src = tripleZero105;
};

function squareToSzzZValue107(){
    valueSave = 'zSqrArtSpecz107';
    var tripleZero106 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr108").src = tripleZero106;
};

function squareToSzzZValue108(){
    valueSave = 'zSqrArtSpecz108';
    var tripleZero107 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr109").src = tripleZero107;
};

function squareToSzzZValue109(){
    valueSave = 'zSqrArtSpecz109';
    var tripleZero108 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr110").src = tripleZero108;
};

function squareToSzzZValue110(){
    valueSave = 'zSqrArtSpecz110';
    var tripleZero109 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr111").src = tripleZero109;
};

function squareToSzzZValue111(){
    valueSave = 'zSqrArtSpecz111';
    var tripleZero110 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr112").src = tripleZero110;
};

function squareToSzzZValue112(){
    valueSave = 'zSqrArtSpecz112';
    var tripleZero111 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr113").src = tripleZero111;
};

function squareToSzzZValue113(){
    valueSave = 'zSqrArtSpecz113';
    var tripleZero112 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr114").src = tripleZero112;
};

function squareToSzzZValue114(){
    valueSave = 'zSqrArtSpecz114';
    var tripleZero113 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr115").src = tripleZero113;
};

function squareToSzzZValue115(){
    valueSave = 'zSqrArtSpecz115';
    var tripleZero114 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr116").src = tripleZero114;
};

function squareToSzzZValue116(){
    valueSave = 'zSqrArtSpecz116';
    var tripleZero115 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr117").src = tripleZero115;
};

function squareToSzzZValue117(){
    valueSave = 'zSqrArtSpecz117';
    var tripleZero116 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr118").src = tripleZero116;
};

function squareToSzzZValue118(){
    valueSave = 'zSqrArtSpecz118';
    var tripleZero117 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr119").src = tripleZero117;
};

function squareToSzzZValue119(){
    valueSave = 'zSqrArtSpecz119';
    var tripleZero118 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr120").src = tripleZero118;
};

function squareToSzzZValue120(){
    valueSave = 'zSqrArtSpecz120';
    var tripleZero119 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr121").src = tripleZero119;
};

function squareToSzzZValue121(){
    valueSave = 'zSqrArtSpecz121';
    var tripleZero120 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr122").src = tripleZero120;
};

function squareToSzzZValue122(){
    valueSave = 'zSqrArtSpecz122';
    var tripleZero121 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr123").src = tripleZero121;
};

function squareToSzzZValue123(){
    valueSave = 'zSqrArtSpecz123';
    var tripleZero122 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr124").src = tripleZero122;
};

function squareToSzzZValue124(){
    valueSave = 'zSqrArtSpecz124';
    var tripleZero123 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr125").src = tripleZero123;
};

function squareToSzzZValue125(){
    valueSave = 'zSqrArtSpecz125';
    var tripleZero124 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr126").src = tripleZero124;
};

function squareToSzzZValue126(){
    valueSave = 'zSqrArtSpecz126';
    var tripleZero125 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr127").src = tripleZero125;
};

function squareToSzzZValue127(){
    valueSave = 'zSqrArtSpecz127';
    var tripleZero126 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr128").src = tripleZero126;
};

function squareToSzzZValue128(){
    valueSave = 'zSqrArtSpecz128';
    var tripleZero127 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr129").src = tripleZero127;
};

function squareToSzzZValue129(){
    valueSave = 'zSqrArtSpecz129';
    var tripleZero128 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr130").src = tripleZero128;
};

function squareToSzzZValue130(){
    valueSave = 'zSqrArtSpecz130';
    var tripleZero129 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr131").src = tripleZero129;
};

function squareToSzzZValue131(){
    valueSave = 'zSqrArtSpecz131';
    var tripleZero130 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr132").src = tripleZero130;
};

function squareToSzzZValue132(){
    valueSave = 'zSqrArtSpecz132';
    var tripleZero131 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr133").src = tripleZero131;
};

function squareToSzzZValue133(){
    valueSave = 'zSqrArtSpecz133';
    var tripleZero132 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr134").src = tripleZero132;
};

function squareToSzzZValue134(){
    valueSave = 'zSqrArtSpecz134';
    var tripleZero133 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr135").src = tripleZero133;
};

function squareToSzzZValue135(){
    valueSave = 'zSqrArtSpecz135';
    var tripleZero134 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr136").src = tripleZero134;
};

function squareToSzzZValue136(){
    valueSave = 'zSqrArtSpecz136';
    var tripleZero135 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr137").src = tripleZero135;
};

function squareToSzzZValue137(){
    valueSave = 'zSqrArtSpecz137';
    var tripleZero136 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr138").src = tripleZero136;
};

function squareToSzzZValue138(){
    valueSave = 'zSqrArtSpecz138';
    var tripleZero137 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr139").src = tripleZero137;
};

function squareToSzzZValue139(){
    valueSave = 'zSqrArtSpecz139';
    var tripleZero138 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr140").src = tripleZero138;
};

function squareToSzzZValue140(){
    valueSave = 'zSqrArtSpecz140';
    var tripleZero139 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr141").src = tripleZero139;
};

function squareToSzzZValue141(){
    valueSave = 'zSqrArtSpecz141';
    var tripleZero140 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr142").src = tripleZero140;
};

function squareToSzzZValue142(){
    valueSave = 'zSqrArtSpecz142';
    var tripleZero141 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr143").src = tripleZero141;
};

function squareToSzzZValue143(){
    valueSave = 'zSqrArtSpecz143';
    var tripleZero142 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr144").src = tripleZero142;
};

function squareToSzzZValue144(){
    valueSave = 'zSqrArtSpecz144';
    var tripleZero143 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr145").src = tripleZero143;
};

function squareToSzzZValue145(){
    valueSave = 'zSqrArtSpecz145';
    var tripleZero144 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr146").src = tripleZero144;
};

function squareToSzzZValue146(){
    valueSave = 'zSqrArtSpecz146';
    var tripleZero145 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr147").src = tripleZero145;
};

function squareToSzzZValue147(){
    valueSave = 'zSqrArtSpecz147';
    var tripleZero146 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr148").src = tripleZero146;
};

function squareToSzzZValue148(){
    valueSave = 'zSqrArtSpecz148';
    var tripleZero147 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr149").src = tripleZero147;
};

function squareToSzzZValue149(){
    valueSave = 'zSqrArtSpecz149';
    var tripleZero148 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr150").src = tripleZero148;
};

function squareToSzzZValue150(){
    valueSave = 'zSqrArtSpecz150';
    var tripleZero149 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr151").src = tripleZero149;
};

function squareToSzzZValue151(){
    valueSave = 'zSqrArtSpecz151';
    var tripleZero150 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr152").src = tripleZero150;
};

function squareToSzzZValue152(){
    valueSave = 'zSqrArtSpecz152';
    var tripleZero151 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr153").src = tripleZero151;
};

function squareToSzzZValue153(){
    valueSave = 'zSqrArtSpecz153';
    var tripleZero152 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr154").src = tripleZero152;
};

function squareToSzzZValue154(){
    valueSave = 'zSqrArtSpecz154';
    var tripleZero153 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr155").src = tripleZero153;
};

function squareToSzzZValue155(){
    valueSave = 'zSqrArtSpecz155';
    var tripleZero154 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr156").src = tripleZero154;
};

function squareToSzzZValue156(){
    valueSave = 'zSqrArtSpecz156';
    var tripleZero155 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr157").src = tripleZero155;
};

function squareToSzzZValue157(){
    valueSave = 'zSqrArtSpecz157';
    var tripleZero156 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr158").src = tripleZero156;
};

function squareToSzzZValue158(){
    valueSave = 'zSqrArtSpecz158';
    var tripleZero157 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr159").src = tripleZero157;
};

function squareToSzzZValue159(){
    valueSave = 'zSqrArtSpecz159';
    var tripleZero158 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr160").src = tripleZero158;
};

function squareToSzzZValue160(){
    valueSave = 'zSqrArtSpecz160';
    var tripleZero159 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr161").src = tripleZero159;
};

function squareToSzzZValue161(){
    valueSave = 'zSqrArtSpecz161';
    var tripleZero160 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr162").src = tripleZero160;
};

function squareToSzzZValue162(){
    valueSave = 'zSqrArtSpecz162';
    var tripleZero161 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr163").src = tripleZero161;
};

function squareToSzzZValue163(){
    valueSave = 'zSqrArtSpecz163';
    var tripleZero162 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr164").src = tripleZero162;
};

function squareToSzzZValue164(){
    valueSave = 'zSqrArtSpecz164';
    var tripleZero163 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr165").src = tripleZero163;
};

function squareToSzzZValue165(){
    valueSave = 'zSqrArtSpecz165';
    var tripleZero164 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr166").src = tripleZero164;
};

function squareToSzzZValue166(){
    valueSave = 'zSqrArtSpecz166';
    var tripleZero165 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr167").src = tripleZero165;
};

function squareToSzzZValue167(){
    valueSave = 'zSqrArtSpecz167';
    var tripleZero166 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr168").src = tripleZero166;
};

function squareToSzzZValue168(){
    valueSave = 'zSqrArtSpecz168';
    var tripleZero167 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr169").src = tripleZero167;
};

function squareToSzzZValue169(){
    valueSave = 'zSqrArtSpecz169';
    var tripleZero168 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr170").src = tripleZero168;
};

function squareToSzzZValue170(){
    valueSave = 'zSqrArtSpecz170';
    var tripleZero169 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr171").src = tripleZero169;
};

function squareToSzzZValue171(){
    valueSave = 'zSqrArtSpecz171';
    var tripleZero170 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr172").src = tripleZero170;
};

function squareToSzzZValue172(){
    valueSave = 'zSqrArtSpecz172';
    var tripleZero171 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr173").src = tripleZero171;
};

function squareToSzzZValue173(){
    valueSave = 'zSqrArtSpecz173';
    var tripleZero172 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr174").src = tripleZero172;
};

function squareToSzzZValue174(){
    valueSave = 'zSqrArtSpecz174';
    var tripleZero173 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr175").src = tripleZero173;
};

function squareToSzzZValue175(){
    valueSave = 'zSqrArtSpecz175';
    var tripleZero174 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr176").src = tripleZero174;
};

function squareToSzzZValue176(){
    valueSave = 'zSqrArtSpecz176';
    var tripleZero175 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr177").src = tripleZero175;
};

function squareToSzzZValue177(){
    valueSave = 'zSqrArtSpecz177';
    var tripleZero176 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr178").src = tripleZero176;
};

function squareToSzzZValue178(){
    valueSave = 'zSqrArtSpecz178';
    var tripleZero177 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr179").src = tripleZero177;
};

function squareToSzzZValue179(){
    valueSave = 'zSqrArtSpecz179';
    var tripleZero178 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr180").src = tripleZero178;
};

function squareToSzzZValue180(){
    valueSave = 'zSqrArtSpecz180';
    var tripleZero179 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr181").src = tripleZero179;
};

function squareToSzzZValue181(){
    valueSave = 'zSqrArtSpecz181';
    var tripleZero180 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr182").src = tripleZero180;
};

function squareToSzzZValue182(){
    valueSave = 'zSqrArtSpecz182';
    var tripleZero181 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr183").src = tripleZero181;
};

function squareToSzzZValue183(){
    valueSave = 'zSqrArtSpecz183';
    var tripleZero182 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr184").src = tripleZero182;
};

function squareToSzzZValue184(){
    valueSave = 'zSqrArtSpecz184';
    var tripleZero183 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr185").src = tripleZero183;
};

function squareToSzzZValue185(){
    valueSave = 'zSqrArtSpecz185';
    var tripleZero184 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr186").src = tripleZero184;
};

function squareToSzzZValue186(){
    valueSave = 'zSqrArtSpecz186';
    var tripleZero185 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr187").src = tripleZero185;
};

function squareToSzzZValue187(){
    valueSave = 'zSqrArtSpecz187';
    var tripleZero186 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr188").src = tripleZero186;
};

function squareToSzzZValue188(){
    valueSave = 'zSqrArtSpecz188';
    var tripleZero187 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr189").src = tripleZero187;
};

function squareToSzzZValue189(){
    valueSave = 'zSqrArtSpecz189';
    var tripleZero188 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr190").src = tripleZero188;
};

function squareToSzzZValue190(){
    valueSave = 'zSqrArtSpecz190';
    var tripleZero189 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr191").src = tripleZero189;
};

function squareToSzzZValue191(){
    valueSave = 'zSqrArtSpecz191';
    var tripleZero190 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr192").src = tripleZero190;
};

function squareToSzzZValue192(){
    valueSave = 'zSqrArtSpecz192';
    var tripleZero191 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr193").src = tripleZero191;
};

function squareToSzzZValue193(){
    valueSave = 'zSqrArtSpecz193';
    var tripleZero192 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr194").src = tripleZero192;
};

function squareToSzzZValue194(){
    valueSave = 'zSqrArtSpecz194';
    var tripleZero193 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr195").src = tripleZero193;
};

function squareToSzzZValue195(){
    valueSave = 'zSqrArtSpecz195';
    var tripleZero194 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr196").src = tripleZero194;
};

function squareToSzzZValue196(){
    valueSave = 'zSqrArtSpecz196';
    var tripleZero195 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr197").src = tripleZero195;
};

function squareToSzzZValue197(){
    valueSave = 'zSqrArtSpecz197';
    var tripleZero196 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr198").src = tripleZero196;
};

function squareToSzzZValue198(){
    valueSave = 'zSqrArtSpecz198';
    var tripleZero197 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr199").src = tripleZero197;
};

function squareToSzzZValue199(){
    valueSave = 'zSqrArtSpecz199';
    var tripleZero198 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr200").src = tripleZero198;
};

function squareToSzzZValue200(){
    valueSave = 'zSqrArtSpecz200';
    var tripleZero199 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr201").src = tripleZero199;
};

function squareToSzzZValue201(){
    valueSave = 'zSqrArtSpecz201';
    var tripleZero200 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr202").src = tripleZero200;
};

function squareToSzzZValue202(){
    valueSave = 'zSqrArtSpecz202';
    var tripleZero201 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr203").src = tripleZero201;
};

function squareToSzzZValue203(){
    valueSave = 'zSqrArtSpecz203';
    var tripleZero202 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr204").src = tripleZero202;
};

function squareToSzzZValue204(){
    valueSave = 'zSqrArtSpecz204';
    var tripleZero203 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr205").src = tripleZero203;
};

function squareToSzzZValue205(){
    valueSave = 'zSqrArtSpecz205';
    var tripleZero204 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr206").src = tripleZero204;
};

function squareToSzzZValue206(){
    valueSave = 'zSqrArtSpecz206';
    var tripleZero205 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr207").src = tripleZero205;
};

function squareToSzzZValue207(){
    valueSave = 'zSqrArtSpecz207';
    var tripleZero206 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr208").src = tripleZero206;
};

function squareToSzzZValue208(){
    valueSave = 'zSqrArtSpecz208';
    var tripleZero207 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr209").src = tripleZero207;
};

function squareToSzzZValue209(){
    valueSave = 'zSqrArtSpecz209';
    var tripleZero208 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr210").src = tripleZero208;
};

function squareToSzzZValue210(){
    valueSave = 'zSqrArtSpecz210';
    var tripleZero209 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr211").src = tripleZero209;
};

function squareToSzzZValue211(){
    valueSave = 'zSqrArtSpecz211';
    var tripleZero210 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr212").src = tripleZero210;
};

function squareToSzzZValue212(){
    valueSave = 'zSqrArtSpecz212';
    var tripleZero211 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr213").src = tripleZero211;
};

function squareToSzzZValue213(){
    valueSave = 'zSqrArtSpecz213';
    var tripleZero212 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr214").src = tripleZero212;
};

function squareToSzzZValue214(){
    valueSave = 'zSqrArtSpecz214';
    var tripleZero213 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr215").src = tripleZero213;
};

function squareToSzzZValue215(){
    valueSave = 'zSqrArtSpecz215';
    var tripleZero214 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr216").src = tripleZero214;
};

function squareToSzzZValue216(){
    valueSave = 'zSqrArtSpecz216';
    var tripleZero215 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr217").src = tripleZero215;
};

function squareToSzzZValue217(){
    valueSave = 'zSqrArtSpecz217';
    var tripleZero216 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr218").src = tripleZero216;
};

function squareToSzzZValue218(){
    valueSave = 'zSqrArtSpecz218';
    var tripleZero217 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr219").src = tripleZero217;
};

function squareToSzzZValue219(){
    valueSave = 'zSqrArtSpecz219';
    var tripleZero218 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr220").src = tripleZero218;
};

function squareToSzzZValue220(){
    valueSave = 'zSqrArtSpecz220';
    var tripleZero219 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr221").src = tripleZero219;
};

function squareToSzzZValue221(){
    valueSave = 'zSqrArtSpecz221';
    var tripleZero220 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr222").src = tripleZero220;
};

function squareToSzzZValue222(){
    valueSave = 'zSqrArtSpecz222';
    var tripleZero221 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr223").src = tripleZero221;
};

function squareToSzzZValue223(){
    valueSave = 'zSqrArtSpecz223';
    var tripleZero222 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr224").src = tripleZero222;
};

function squareToSzzZValue224(){
    valueSave = 'zSqrArtSpecz224';
    var tripleZero223 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr225").src = tripleZero223;
};

function squareToSzzZValue225(){
    valueSave = 'zSqrArtSpecz225';
    var tripleZero224 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr226").src = tripleZero224;
};

function squareToSzzZValue226(){
    valueSave = 'zSqrArtSpecz226';
    var tripleZero225 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr227").src = tripleZero225;
};

function squareToSzzZValue227(){
    valueSave = 'zSqrArtSpecz227';
    var tripleZero226 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr228").src = tripleZero226;
};

function squareToSzzZValue228(){
    valueSave = 'zSqrArtSpecz228';
    var tripleZero227 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr229").src = tripleZero227;
};

function squareToSzzZValue229(){
    valueSave = 'zSqrArtSpecz229';
    var tripleZero228 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr230").src = tripleZero228;
};

function squareToSzzZValue230(){
    valueSave = 'zSqrArtSpecz230';
    var tripleZero229 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr231").src = tripleZero229;
};

function squareToSzzZValue231(){
    valueSave = 'zSqrArtSpecz231';
    var tripleZero230 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr232").src = tripleZero230;
};

function squareToSzzZValue232(){
    valueSave = 'zSqrArtSpecz232';
    var tripleZero231 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr233").src = tripleZero231;
};

function squareToSzzZValue233(){
    valueSave = 'zSqrArtSpecz233';
    var tripleZero232 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr234").src = tripleZero232;
};

function squareToSzzZValue234(){
    valueSave = 'zSqrArtSpecz234';
    var tripleZero233 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr235").src = tripleZero233;
};

function squareToSzzZValue235(){
    valueSave = 'zSqrArtSpecz235';
    var tripleZero234 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr236").src = tripleZero234;
};

function squareToSzzZValue236(){
    valueSave = 'zSqrArtSpecz236';
    var tripleZero235 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr237").src = tripleZero235;
};

function squareToSzzZValue237(){
    valueSave = 'zSqrArtSpecz237';
    var tripleZero236 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr238").src = tripleZero236;
};

function squareToSzzZValue238(){
    valueSave = 'zSqrArtSpecz238';
    var tripleZero237 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr239").src = tripleZero237;
};

function squareToSzzZValue239(){
    valueSave = 'zSqrArtSpecz239';
    var tripleZero238 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr240").src = tripleZero238;
};

function squareToSzzZValue240(){
    valueSave = 'zSqrArtSpecz240';
    var tripleZero239 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr241").src = tripleZero239;
};

function squareToSzzZValue241(){
    valueSave = 'zSqrArtSpecz241';
    var tripleZero240 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr242").src = tripleZero240;
};

function squareToSzzZValue242(){
    valueSave = 'zSqrArtSpecz242';
    var tripleZero241 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr243").src = tripleZero241;
};

function squareToSzzZValue243(){
    valueSave = 'zSqrArtSpecz243';
    var tripleZero242 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr244").src = tripleZero242;
};

function squareToSzzZValue244(){
    valueSave = 'zSqrArtSpecz244';
    var tripleZero243 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr245").src = tripleZero243;
};

function squareToSzzZValue245(){
    valueSave = 'zSqrArtSpecz245';
    var tripleZero244 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr246").src = tripleZero244;
};

function squareToSzzZValue246(){
    valueSave = 'zSqrArtSpecz246';
    var tripleZero245 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr247").src = tripleZero245;
};

function squareToSzzZValue247(){
    valueSave = 'zSqrArtSpecz247';
    var tripleZero246 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr248").src = tripleZero246;
};

function squareToSzzZValue248(){
    valueSave = 'zSqrArtSpecz248';
    var tripleZero247 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr249").src = tripleZero247;
};

function squareToSzzZValue249(){
    valueSave = 'zSqrArtSpecz249';
    var tripleZero248 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr250").src = tripleZero248;
};

function squareToSzzZValue250(){
    valueSave = 'zSqrArtSpecz250';
    var tripleZero249 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr251").src = tripleZero249;
};

function squareToSzzZValue251(){
    valueSave = 'zSqrArtSpecz251';
    var tripleZero250 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr252").src = tripleZero250;
};

function squareToSzzZValue252(){
    valueSave = 'zSqrArtSpecz252';
    var tripleZero251 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr253").src = tripleZero251;
};

function squareToSzzZValue253(){
    valueSave = 'zSqrArtSpecz253';
    var tripleZero252 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr254").src = tripleZero252;
};

function squareToSzzZValue254(){
    valueSave = 'zSqrArtSpecz254';
    var tripleZero253 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr255").src = tripleZero253;
};

function squareToSzzZValue255(){
    valueSave = 'zSqrArtSpecz255';
    var tripleZero254 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr256").src = tripleZero254;
};

function squareToSzzZValue256(){
    valueSave = 'zSqrArtSpecz256';
    var tripleZero255 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr257").src = tripleZero255;
};

function squareToSzzZValue257(){
    valueSave = 'zSqrArtSpecz257';
    var tripleZero256 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr258").src = tripleZero256;
};

function squareToSzzZValue258(){
    valueSave = 'zSqrArtSpecz258';
    var tripleZero257 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr259").src = tripleZero257;
};

function squareToSzzZValue259(){
    valueSave = 'zSqrArtSpecz259';
    var tripleZero258 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr260").src = tripleZero258;
};

function squareToSzzZValue260(){
    valueSave = 'zSqrArtSpecz260';
    var tripleZero259 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr261").src = tripleZero259;
};

function squareToSzzZValue261(){
    valueSave = 'zSqrArtSpecz261';
    var tripleZero260 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr262").src = tripleZero260;
};

function squareToSzzZValue262(){
    valueSave = 'zSqrArtSpecz262';
    var tripleZero261 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr263").src = tripleZero261;
};

function squareToSzzZValue263(){
    valueSave = 'zSqrArtSpecz263';
    var tripleZero262 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr264").src = tripleZero262;
};

function squareToSzzZValue264(){
    valueSave = 'zSqrArtSpecz264';
    var tripleZero263 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr265").src = tripleZero263;
};

function squareToSzzZValue265(){
    valueSave = 'zSqrArtSpecz265';
    var tripleZero264 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr266").src = tripleZero264;
};

function squareToSzzZValue266(){
    valueSave = 'zSqrArtSpecz266';
    var tripleZero265 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr267").src = tripleZero265;
};

function squareToSzzZValue267(){
    valueSave = 'zSqrArtSpecz267';
    var tripleZero266 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr268").src = tripleZero266;
};

function squareToSzzZValue268(){
    valueSave = 'zSqrArtSpecz268';
    var tripleZero267 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr269").src = tripleZero267;
};

function squareToSzzZValue269(){
    valueSave = 'zSqrArtSpecz269';
    var tripleZero268 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr270").src = tripleZero268;
};

function squareToSzzZValue270(){
    valueSave = 'zSqrArtSpecz270';
    var tripleZero269 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr271").src = tripleZero269;
};

function squareToSzzZValue271(){
    valueSave = 'zSqrArtSpecz271';
    var tripleZero270 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr272").src = tripleZero270;
};

function squareToSzzZValue272(){
    valueSave = 'zSqrArtSpecz272';
    var tripleZero271 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr273").src = tripleZero271;
};

function squareToSzzZValue273(){
    valueSave = 'zSqrArtSpecz273';
    var tripleZero272 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr274").src = tripleZero272;
};

function squareToSzzZValue274(){
    valueSave = 'zSqrArtSpecz274';
    var tripleZero273 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr275").src = tripleZero273;
};

function squareToSzzZValue275(){
    valueSave = 'zSqrArtSpecz275';
    var tripleZero274 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr276").src = tripleZero274;
};

function squareToSzzZValue276(){
    valueSave = 'zSqrArtSpecz276';
    var tripleZero275 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr277").src = tripleZero275;
};

function squareToSzzZValue277(){
    valueSave = 'zSqrArtSpecz277';
    var tripleZero276 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr278").src = tripleZero276;
};

function squareToSzzZValue278(){
    valueSave = 'zSqrArtSpecz278';
    var tripleZero277 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr279").src = tripleZero277;
};

function squareToSzzZValue279(){
    valueSave = 'zSqrArtSpecz279';
    var tripleZero278 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr280").src = tripleZero278;
};

function squareToSzzZValue280(){
    valueSave = 'zSqrArtSpecz280';
    var tripleZero279 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr281").src = tripleZero279;
};

function squareToSzzZValue281(){
    valueSave = 'zSqrArtSpecz281';
    var tripleZero280 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr282").src = tripleZero280;
};

function squareToSzzZValue282(){
    valueSave = 'zSqrArtSpecz282';
    var tripleZero281 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr283").src = tripleZero281;
};

function squareToSzzZValue283(){
    valueSave = 'zSqrArtSpecz283';
    var tripleZero282 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr284").src = tripleZero282;
};

function squareToSzzZValue284(){
    valueSave = 'zSqrArtSpecz284';
    var tripleZero283 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr285").src = tripleZero283;
};

function squareToSzzZValue285(){
    valueSave = 'zSqrArtSpecz285';
    var tripleZero284 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr286").src = tripleZero284;
};

function squareToSzzZValue286(){
    valueSave = 'zSqrArtSpecz286';
    var tripleZero285 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr287").src = tripleZero285;
};

function squareToSzzZValue287(){
    valueSave = 'zSqrArtSpecz287';
    var tripleZero286 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr288").src = tripleZero286;
};

function squareToSzzZValue288(){
    valueSave = 'zSqrArtSpecz288';
    var tripleZero287 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr289").src = tripleZero287;
};

function squareToSzzZValue289(){
    valueSave = 'zSqrArtSpecz289';
    var tripleZero288 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr290").src = tripleZero288;
};

function squareToSzzZValue290(){
    valueSave = 'zSqrArtSpecz290';
    var tripleZero289 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr291").src = tripleZero289;
};

function squareToSzzZValue291(){
    valueSave = 'zSqrArtSpecz291';
    var tripleZero290 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr292").src = tripleZero290;
};

function squareToSzzZValue292(){
    valueSave = 'zSqrArtSpecz292';
    var tripleZero291 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr293").src = tripleZero291;
};

function squareToSzzZValue293(){
    valueSave = 'zSqrArtSpecz293';
    var tripleZero292 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr294").src = tripleZero292;
};

function squareToSzzZValue294(){
    valueSave = 'zSqrArtSpecz294';
    var tripleZero293 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr295").src = tripleZero293;
};

function squareToSzzZValue295(){
    valueSave = 'zSqrArtSpecz295';
    var tripleZero294 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr296").src = tripleZero294;
};

function squareToSzzZValue296(){
    valueSave = 'zSqrArtSpecz296';
    var tripleZero295 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr297").src = tripleZero295;
};

function squareToSzzZValue297(){
    valueSave = 'zSqrArtSpecz297';
    var tripleZero296 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr298").src = tripleZero296;
};

function squareToSzzZValue298(){
    valueSave = 'zSqrArtSpecz298';
    var tripleZero297 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr299").src = tripleZero297;
};

function squareToSzzZValue299(){
    valueSave = 'zSqrArtSpecz299';
    var tripleZero298 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr300").src = tripleZero298;
};

function squareToSzzZValue300(){
    valueSave = 'zSqrArtSpecz300';
    var tripleZero299 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr301").src = tripleZero299;
};

function squareToSzzZValue301(){
    valueSave = 'zSqrArtSpecz301';
    var tripleZero300 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr302").src = tripleZero300;
};

function squareToSzzZValue302(){
    valueSave = 'zSqrArtSpecz302';
    var tripleZero301 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr303").src = tripleZero301;
};

function squareToSzzZValue303(){
    valueSave = 'zSqrArtSpecz303';
    var tripleZero302 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr304").src = tripleZero302;
};

function squareToSzzZValue304(){
    valueSave = 'zSqrArtSpecz304';
    var tripleZero303 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr305").src = tripleZero303;
};

function squareToSzzZValue305(){
    valueSave = 'zSqrArtSpecz305';
    var tripleZero304 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr306").src = tripleZero304;
};

function squareToSzzZValue306(){
    valueSave = 'zSqrArtSpecz306';
    var tripleZero305 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr307").src = tripleZero305;
};

function squareToSzzZValue307(){
    valueSave = 'zSqrArtSpecz307';
    var tripleZero306 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr308").src = tripleZero306;
};

function squareToSzzZValue308(){
    valueSave = 'zSqrArtSpecz308';
    var tripleZero307 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr309").src = tripleZero307;
};

function squareToSzzZValue309(){
    valueSave = 'zSqrArtSpecz309';
    var tripleZero308 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr310").src = tripleZero308;
};

function squareToSzzZValue310(){
    valueSave = 'zSqrArtSpecz310';
    var tripleZero309 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr311").src = tripleZero309;
};

function squareToSzzZValue311(){
    valueSave = 'zSqrArtSpecz311';
    var tripleZero310 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr312").src = tripleZero310;
};

function squareToSzzZValue312(){
    valueSave = 'zSqrArtSpecz312';
    var tripleZero311 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr313").src = tripleZero311;
};

function squareToSzzZValue313(){
    valueSave = 'zSqrArtSpecz313';
    var tripleZero312 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr314").src = tripleZero312;
};

function squareToSzzZValue314(){
    valueSave = 'zSqrArtSpecz314';
    var tripleZero313 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr315").src = tripleZero313;
};

function squareToSzzZValue315(){
    valueSave = 'zSqrArtSpecz315';
    var tripleZero314 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr316").src = tripleZero314;
};

function squareToSzzZValue316(){
    valueSave = 'zSqrArtSpecz316';
    var tripleZero315 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr317").src = tripleZero315;
};

function squareToSzzZValue317(){
    valueSave = 'zSqrArtSpecz317';
    var tripleZero316 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr318").src = tripleZero316;
};

function squareToSzzZValue318(){
    valueSave = 'zSqrArtSpecz318';
    var tripleZero317 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr319").src = tripleZero317;
};

function squareToSzzZValue319(){
    valueSave = 'zSqrArtSpecz319';
    var tripleZero318 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr320").src = tripleZero318;
};

function squareToSzzZValue320(){
    valueSave = 'zSqrArtSpecz320';
    var tripleZero319 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr321").src = tripleZero319;
};

function squareToSzzZValue321(){
    valueSave = 'zSqrArtSpecz321';
    var tripleZero320 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr322").src = tripleZero320;
};

function squareToSzzZValue322(){
    valueSave = 'zSqrArtSpecz322';
    var tripleZero321 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr323").src = tripleZero321;
};

function squareToSzzZValue323(){
    valueSave = 'zSqrArtSpecz323';
    var tripleZero322 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr324").src = tripleZero322;
};

function squareToSzzZValue324(){
    valueSave = 'zSqrArtSpecz324';
    var tripleZero323 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr325").src = tripleZero323;
};

function squareToSzzZValue325(){
    valueSave = 'zSqrArtSpecz325';
    var tripleZero324 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr326").src = tripleZero324;
};

function squareToSzzZValue326(){
    valueSave = 'zSqrArtSpecz326';
    var tripleZero325 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr327").src = tripleZero325;
};

function squareToSzzZValue327(){
    valueSave = 'zSqrArtSpecz327';
    var tripleZero326 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr328").src = tripleZero326;
};

function squareToSzzZValue328(){
    valueSave = 'zSqrArtSpecz328';
    var tripleZero327 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr329").src = tripleZero327;
};

function squareToSzzZValue329(){
    valueSave = 'zSqrArtSpecz329';
    var tripleZero328 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr330").src = tripleZero328;
};

function squareToSzzZValue330(){
    valueSave = 'zSqrArtSpecz330';
    var tripleZero329 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr331").src = tripleZero329;
};

function squareToSzzZValue331(){
    valueSave = 'zSqrArtSpecz331';
    var tripleZero330 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr332").src = tripleZero330;
};

function squareToSzzZValue332(){
    valueSave = 'zSqrArtSpecz332';
    var tripleZero331 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr333").src = tripleZero331;
};

function squareToSzzZValue333(){
    valueSave = 'zSqrArtSpecz333';
    var tripleZero332 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr334").src = tripleZero332;
};

function squareToSzzZValue334(){
    valueSave = 'zSqrArtSpecz334';
    var tripleZero333 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr335").src = tripleZero333;
};

function squareToSzzZValue335(){
    valueSave = 'zSqrArtSpecz335';
    var tripleZero334 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr336").src = tripleZero334;
};

function squareToSzzZValue336(){
    valueSave = 'zSqrArtSpecz336';
    var tripleZero335 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr337").src = tripleZero335;
};

function squareToSzzZValue337(){
    valueSave = 'zSqrArtSpecz337';
    var tripleZero336 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr338").src = tripleZero336;
};

function squareToSzzZValue338(){
    valueSave = 'zSqrArtSpecz338';
    var tripleZero337 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr339").src = tripleZero337;
};

function squareToSzzZValue339(){
    valueSave = 'zSqrArtSpecz339';
    var tripleZero338 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr340").src = tripleZero338;
};

function squareToSzzZValue340(){
    valueSave = 'zSqrArtSpecz340';
    var tripleZero339 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr341").src = tripleZero339;
};

function squareToSzzZValue341(){
    valueSave = 'zSqrArtSpecz341';
    var tripleZero340 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr342").src = tripleZero340;
};

function squareToSzzZValue342(){
    valueSave = 'zSqrArtSpecz342';
    var tripleZero341 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr343").src = tripleZero341;
};

function squareToSzzZValue343(){
    valueSave = 'zSqrArtSpecz343';
    var tripleZero342 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr344").src = tripleZero342;
};

function squareToSzzZValue344(){
    valueSave = 'zSqrArtSpecz344';
    var tripleZero343 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr345").src = tripleZero343;
};

function squareToSzzZValue345(){
    valueSave = 'zSqrArtSpecz345';
    var tripleZero344 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr346").src = tripleZero344;
};

function squareToSzzZValue346(){
    valueSave = 'zSqrArtSpecz346';
    var tripleZero345 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr347").src = tripleZero345;
};

function squareToSzzZValue347(){
    valueSave = 'zSqrArtSpecz347';
    var tripleZero346 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr348").src = tripleZero346;
};

function squareToSzzZValue348(){
    valueSave = 'zSqrArtSpecz348';
    var tripleZero347 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr349").src = tripleZero347;
};

function squareToSzzZValue349(){
    valueSave = 'zSqrArtSpecz349';
    var tripleZero348 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr350").src = tripleZero348;
};

function squareToSzzZValue350(){
    valueSave = 'zSqrArtSpecz350';
    var tripleZero349 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr351").src = tripleZero349;
};

function squareToSzzZValue351(){
    valueSave = 'zSqrArtSpecz351';
    var tripleZero350 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr352").src = tripleZero350;
};

function squareToSzzZValue352(){
    valueSave = 'zSqrArtSpecz352';
    var tripleZero351 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr353").src = tripleZero351;
};

function squareToSzzZValue353(){
    valueSave = 'zSqrArtSpecz353';
    var tripleZero352 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr354").src = tripleZero352;
};

function squareToSzzZValue354(){
    valueSave = 'zSqrArtSpecz354';
    var tripleZero353 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr355").src = tripleZero353;
};

function squareToSzzZValue355(){
    valueSave = 'zSqrArtSpecz355';
    var tripleZero354 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr356").src = tripleZero354;
};

function squareToSzzZValue356(){
    valueSave = 'zSqrArtSpecz356';
    var tripleZero355 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr357").src = tripleZero355;
};

function squareToSzzZValue357(){
    valueSave = 'zSqrArtSpecz357';
    var tripleZero356 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr358").src = tripleZero356;
};

function squareToSzzZValue358(){
    valueSave = 'zSqrArtSpecz358';
    var tripleZero357 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr359").src = tripleZero357;
};

function squareToSzzZValue359(){
    valueSave = 'zSqrArtSpecz359';
    var tripleZero358 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr360").src = tripleZero358;
};

function squareToSzzZValue360(){
    valueSave = 'zSqrArtSpecz360';
    var tripleZero359 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr361").src = tripleZero359;
};

function squareToSzzZValue361(){
    valueSave = 'zSqrArtSpecz361';
    var tripleZero360 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr362").src = tripleZero360;
};

function squareToSzzZValue362(){
    valueSave = 'zSqrArtSpecz362';
    var tripleZero361 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr363").src = tripleZero361;
};

function squareToSzzZValue363(){
    valueSave = 'zSqrArtSpecz363';
    var tripleZero362 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr364").src = tripleZero362;
};

function squareToSzzZValue364(){
    valueSave = 'zSqrArtSpecz364';
    var tripleZero363 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr365").src = tripleZero363;
};

function squareToSzzZValue365(){
    valueSave = 'zSqrArtSpecz365';
    var tripleZero364 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr366").src = tripleZero364;
};

function squareToSzzZValue366(){
    valueSave = 'zSqrArtSpecz366';
    var tripleZero365 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr367").src = tripleZero365;
};

function squareToSzzZValue367(){
    valueSave = 'zSqrArtSpecz367';
    var tripleZero366 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr368").src = tripleZero366;
};

function squareToSzzZValue368(){
    valueSave = 'zSqrArtSpecz368';
    var tripleZero367 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr369").src = tripleZero367;
};

function squareToSzzZValue369(){
    valueSave = 'zSqrArtSpecz369';
    var tripleZero368 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr370").src = tripleZero368;
};

function squareToSzzZValue370(){
    valueSave = 'zSqrArtSpecz370';
    var tripleZero369 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr371").src = tripleZero369;
};

function squareToSzzZValue371(){
    valueSave = 'zSqrArtSpecz371';
    var tripleZero370 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr372").src = tripleZero370;
};

function squareToSzzZValue372(){
    valueSave = 'zSqrArtSpecz372';
    var tripleZero371 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr373").src = tripleZero371;
};

function squareToSzzZValue373(){
    valueSave = 'zSqrArtSpecz373';
    var tripleZero372 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr374").src = tripleZero372;
};

function squareToSzzZValue374(){
    valueSave = 'zSqrArtSpecz374';
    var tripleZero373 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr375").src = tripleZero373;
};

function squareToSzzZValue375(){
    valueSave = 'zSqrArtSpecz375';
    var tripleZero374 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr376").src = tripleZero374;
};

function squareToSzzZValue376(){
    valueSave = 'zSqrArtSpecz376';
    var tripleZero375 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr377").src = tripleZero375;
};

function squareToSzzZValue377(){
    valueSave = 'zSqrArtSpecz377';
    var tripleZero376 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr378").src = tripleZero376;
};

function squareToSzzZValue378(){
    valueSave = 'zSqrArtSpecz378';
    var tripleZero377 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr379").src = tripleZero377;
};

function squareToSzzZValue379(){
    valueSave = 'zSqrArtSpecz379';
    var tripleZero378 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr380").src = tripleZero378;
};

function squareToSzzZValue380(){
    valueSave = 'zSqrArtSpecz380';
    var tripleZero379 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr381").src = tripleZero379;
};

function squareToSzzZValue381(){
    valueSave = 'zSqrArtSpecz381';
    var tripleZero380 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr382").src = tripleZero380;
};

function squareToSzzZValue382(){
    valueSave = 'zSqrArtSpecz382';
    var tripleZero381 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr383").src = tripleZero381;
};

function squareToSzzZValue383(){
    valueSave = 'zSqrArtSpecz383';
    var tripleZero382 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr384").src = tripleZero382;
};

function squareToSzzZValue384(){
    valueSave = 'zSqrArtSpecz384';
    var tripleZero383 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr385").src = tripleZero383;
};

function squareToSzzZValue385(){
    valueSave = 'zSqrArtSpecz385';
    var tripleZero384 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr386").src = tripleZero384;
};

function squareToSzzZValue386(){
    valueSave = 'zSqrArtSpecz386';
    var tripleZero385 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr387").src = tripleZero385;
};

function squareToSzzZValue387(){
    valueSave = 'zSqrArtSpecz387';
    var tripleZero386 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr388").src = tripleZero386;
};

function squareToSzzZValue388(){
    valueSave = 'zSqrArtSpecz388';
    var tripleZero387 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr389").src = tripleZero387;
};

function squareToSzzZValue389(){
    valueSave = 'zSqrArtSpecz389';
    var tripleZero388 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr390").src = tripleZero388;
};

function squareToSzzZValue390(){
    valueSave = 'zSqrArtSpecz390';
    var tripleZero389 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr391").src = tripleZero389;
};

function squareToSzzZValue391(){
    valueSave = 'zSqrArtSpecz391';
    var tripleZero390 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr392").src = tripleZero390;
};

function squareToSzzZValue392(){
    valueSave = 'zSqrArtSpecz392';
    var tripleZero391 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr393").src = tripleZero391;
};

function squareToSzzZValue393(){
    valueSave = 'zSqrArtSpecz393';
    var tripleZero392 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr394").src = tripleZero392;
};

function squareToSzzZValue394(){
    valueSave = 'zSqrArtSpecz394';
    var tripleZero393 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr395").src = tripleZero393;
};

function squareToSzzZValue395(){
    valueSave = 'zSqrArtSpecz395';
    var tripleZero394 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr396").src = tripleZero394;
};

function squareToSzzZValue396(){
    valueSave = 'zSqrArtSpecz396';
    var tripleZero395 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr397").src = tripleZero395;
};

function squareToSzzZValue397(){
    valueSave = 'zSqrArtSpecz397';
    var tripleZero396 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr398").src = tripleZero396;
};

function squareToSzzZValue398(){
    valueSave = 'zSqrArtSpecz398';
    var tripleZero397 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr399").src = tripleZero397;
};

function squareToSzzZValue399(){
    valueSave = 'zSqrArtSpecz399';
    var tripleZero398 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr400").src = tripleZero398;
};

function squareToSzzZValue400(){
    valueSave = 'zSqrArtSpecz400';
    var tripleZero399 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr401").src = tripleZero399;
};

function squareToSzzZValue401(){
    valueSave = 'zSqrArtSpecz401';
    var tripleZero400 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr402").src = tripleZero400;
};

function squareToSzzZValue402(){
    valueSave = 'zSqrArtSpecz402';
    var tripleZero401 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr403").src = tripleZero401;
};

function squareToSzzZValue403(){
    valueSave = 'zSqrArtSpecz403';
    var tripleZero402 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr404").src = tripleZero402;
};

function squareToSzzZValue404(){
    valueSave = 'zSqrArtSpecz404';
    var tripleZero403 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr405").src = tripleZero403;
};

function squareToSzzZValue405(){
    valueSave = 'zSqrArtSpecz405';
    var tripleZero404 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr406").src = tripleZero404;
};

function squareToSzzZValue406(){
    valueSave = 'zSqrArtSpecz406';
    var tripleZero405 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr407").src = tripleZero405;
};

function squareToSzzZValue407(){
    valueSave = 'zSqrArtSpecz407';
    var tripleZero406 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr408").src = tripleZero406;
};

function squareToSzzZValue408(){
    valueSave = 'zSqrArtSpecz408';
    var tripleZero407 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr409").src = tripleZero407;
};

function squareToSzzZValue409(){
    valueSave = 'zSqrArtSpecz409';
    var tripleZero408 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr410").src = tripleZero408;
};

function squareToSzzZValue410(){
    valueSave = 'zSqrArtSpecz410';
    var tripleZero409 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr411").src = tripleZero409;
};

function squareToSzzZValue411(){
    valueSave = 'zSqrArtSpecz411';
    var tripleZero410 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr412").src = tripleZero410;
};

function squareToSzzZValue412(){
    valueSave = 'zSqrArtSpecz412';
    var tripleZero411 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr413").src = tripleZero411;
};

function squareToSzzZValue413(){
    valueSave = 'zSqrArtSpecz413';
    var tripleZero412 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr414").src = tripleZero412;
};

function squareToSzzZValue414(){
    valueSave = 'zSqrArtSpecz414';
    var tripleZero413 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr415").src = tripleZero413;
};

function squareToSzzZValue415(){
    valueSave = 'zSqrArtSpecz415';
    var tripleZero414 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr416").src = tripleZero414;
};

function squareToSzzZValue416(){
    valueSave = 'zSqrArtSpecz416';
    var tripleZero415 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr417").src = tripleZero415;
};

function squareToSzzZValue417(){
    valueSave = 'zSqrArtSpecz417';
    var tripleZero416 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr418").src = tripleZero416;
};

function squareToSzzZValue418(){
    valueSave = 'zSqrArtSpecz418';
    var tripleZero417 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr419").src = tripleZero417;
};

function squareToSzzZValue419(){
    valueSave = 'zSqrArtSpecz419';
    var tripleZero418 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr420").src = tripleZero418;
};

function squareToSzzZValue420(){
    valueSave = 'zSqrArtSpecz420';
    var tripleZero419 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr421").src = tripleZero419;
};

function squareToSzzZValue421(){
    valueSave = 'zSqrArtSpecz421';
    var tripleZero420 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr422").src = tripleZero420;
};

function squareToSzzZValue422(){
    valueSave = 'zSqrArtSpecz422';
    var tripleZero421 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr423").src = tripleZero421;
};

function squareToSzzZValue423(){
    valueSave = 'zSqrArtSpecz423';
    var tripleZero422 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr424").src = tripleZero422;
};

function squareToSzzZValue424(){
    valueSave = 'zSqrArtSpecz424';
    var tripleZero423 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr425").src = tripleZero423;
};

function squareToSzzZValue425(){
    valueSave = 'zSqrArtSpecz425';
    var tripleZero424 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr426").src = tripleZero424;
};

function squareToSzzZValue426(){
    valueSave = 'zSqrArtSpecz426';
    var tripleZero425 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr427").src = tripleZero425;
};

function squareToSzzZValue427(){
    valueSave = 'zSqrArtSpecz427';
    var tripleZero426 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr428").src = tripleZero426;
};

function squareToSzzZValue428(){
    valueSave = 'zSqrArtSpecz428';
    var tripleZero427 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr429").src = tripleZero427;
};

function squareToSzzZValue429(){
    valueSave = 'zSqrArtSpecz429';
    var tripleZero428 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr430").src = tripleZero428;
};

function squareToSzzZValue430(){
    valueSave = 'zSqrArtSpecz430';
    var tripleZero429 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr431").src = tripleZero429;
};

function squareToSzzZValue431(){
    valueSave = 'zSqrArtSpecz431';
    var tripleZero430 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr432").src = tripleZero430;
};

function squareToSzzZValue432(){
    valueSave = 'zSqrArtSpecz432';
    var tripleZero431 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr433").src = tripleZero431;
};

function squareToSzzZValue433(){
    valueSave = 'zSqrArtSpecz433';
    var tripleZero432 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr434").src = tripleZero432;
};

function squareToSzzZValue434(){
    valueSave = 'zSqrArtSpecz434';
    var tripleZero433 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr435").src = tripleZero433;
};

function squareToSzzZValue435(){
    valueSave = 'zSqrArtSpecz435';
    var tripleZero434 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr436").src = tripleZero434;
};

function squareToSzzZValue436(){
    valueSave = 'zSqrArtSpecz436';
    var tripleZero435 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr437").src = tripleZero435;
};

function squareToSzzZValue437(){
    valueSave = 'zSqrArtSpecz437';
    var tripleZero436 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr438").src = tripleZero436;
};

function squareToSzzZValue438(){
    valueSave = 'zSqrArtSpecz438';
    var tripleZero437 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr439").src = tripleZero437;
};

function squareToSzzZValue439(){
    valueSave = 'zSqrArtSpecz439';
    var tripleZero438 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr440").src = tripleZero438;
};

function squareToSzzZValue440(){
    valueSave = 'zSqrArtSpecz440';
    var tripleZero439 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr441").src = tripleZero439;
};

function squareToSzzZValue441(){
    valueSave = 'zSqrArtSpecz441';
    var tripleZero440 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr442").src = tripleZero440;
};

function squareToSzzZValue442(){
    valueSave = 'zSqrArtSpecz442';
    var tripleZero441 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr443").src = tripleZero441;
};

function squareToSzzZValue443(){
    valueSave = 'zSqrArtSpecz443';
    var tripleZero442 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr444").src = tripleZero442;
};

function squareToSzzZValue444(){
    valueSave = 'zSqrArtSpecz444';
    var tripleZero443 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr445").src = tripleZero443;
};

function squareToSzzZValue445(){
    valueSave = 'zSqrArtSpecz445';
    var tripleZero444 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr446").src = tripleZero444;
};

function squareToSzzZValue446(){
    valueSave = 'zSqrArtSpecz446';
    var tripleZero445 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr447").src = tripleZero445;
};

function squareToSzzZValue447(){
    valueSave = 'zSqrArtSpecz447';
    var tripleZero446 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr448").src = tripleZero446;
};

function squareToSzzZValue448(){
    valueSave = 'zSqrArtSpecz448';
    var tripleZero447 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr449").src = tripleZero447;
};

function squareToSzzZValue449(){
    valueSave = 'zSqrArtSpecz449';
    var tripleZero448 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr450").src = tripleZero448;
};

function squareToSzzZValue450(){
    valueSave = 'zSqrArtSpecz450';
    var tripleZero449 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr451").src = tripleZero449;
};

function squareToSzzZValue451(){
    valueSave = 'zSqrArtSpecz451';
    var tripleZero450 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr452").src = tripleZero450;
};

function squareToSzzZValue452(){
    valueSave = 'zSqrArtSpecz452';
    var tripleZero451 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr453").src = tripleZero451;
};

function squareToSzzZValue453(){
    valueSave = 'zSqrArtSpecz453';
    var tripleZero452 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr454").src = tripleZero452;
};

function squareToSzzZValue454(){
    valueSave = 'zSqrArtSpecz454';
    var tripleZero453 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr455").src = tripleZero453;
};

function squareToSzzZValue455(){
    valueSave = 'zSqrArtSpecz455';
    var tripleZero454 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr456").src = tripleZero454;
};

function squareToSzzZValue456(){
    valueSave = 'zSqrArtSpecz456';
    var tripleZero455 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr457").src = tripleZero455;
};

function squareToSzzZValue457(){
    valueSave = 'zSqrArtSpecz457';
    var tripleZero456 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr458").src = tripleZero456;
};

function squareToSzzZValue458(){
    valueSave = 'zSqrArtSpecz458';
    var tripleZero457 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr459").src = tripleZero457;
};

function squareToSzzZValue459(){
    valueSave = 'zSqrArtSpecz459';
    var tripleZero458 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr460").src = tripleZero458;
};

function squareToSzzZValue460(){
    valueSave = 'zSqrArtSpecz460';
    var tripleZero459 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr461").src = tripleZero459;
};

function squareToSzzZValue461(){
    valueSave = 'zSqrArtSpecz461';
    var tripleZero460 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr462").src = tripleZero460;
};

function squareToSzzZValue462(){
    valueSave = 'zSqrArtSpecz462';
    var tripleZero461 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr463").src = tripleZero461;
};

function squareToSzzZValue463(){
    valueSave = 'zSqrArtSpecz463';
    var tripleZero462 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr464").src = tripleZero462;
};

function squareToSzzZValue464(){
    valueSave = 'zSqrArtSpecz464';
    var tripleZero463 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr465").src = tripleZero463;
};

function squareToSzzZValue465(){
    valueSave = 'zSqrArtSpecz465';
    var tripleZero464 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr466").src = tripleZero464;
};

function squareToSzzZValue466(){
    valueSave = 'zSqrArtSpecz466';
    var tripleZero465 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr467").src = tripleZero465;
};

function squareToSzzZValue467(){
    valueSave = 'zSqrArtSpecz467';
    var tripleZero466 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr468").src = tripleZero466;
};

function squareToSzzZValue468(){
    valueSave = 'zSqrArtSpecz468';
    var tripleZero467 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr469").src = tripleZero467;
};

function squareToSzzZValue469(){
    valueSave = 'zSqrArtSpecz469';
    var tripleZero468 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr470").src = tripleZero468;
};

function squareToSzzZValue470(){
    valueSave = 'zSqrArtSpecz470';
    var tripleZero469 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr471").src = tripleZero469;
};

function squareToSzzZValue471(){
    valueSave = 'zSqrArtSpecz471';
    var tripleZero470 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr472").src = tripleZero470;
};

function squareToSzzZValue472(){
    valueSave = 'zSqrArtSpecz472';
    var tripleZero471 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr473").src = tripleZero471;
};

function squareToSzzZValue473(){
    valueSave = 'zSqrArtSpecz473';
    var tripleZero472 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr474").src = tripleZero472;
};

function squareToSzzZValue474(){
    valueSave = 'zSqrArtSpecz474';
    var tripleZero473 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr475").src = tripleZero473;
};

function squareToSzzZValue475(){
    valueSave = 'zSqrArtSpecz475';
    var tripleZero474 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr476").src = tripleZero474;
};

function squareToSzzZValue476(){
    valueSave = 'zSqrArtSpecz476';
    var tripleZero475 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr477").src = tripleZero475;
};

function squareToSzzZValue477(){
    valueSave = 'zSqrArtSpecz477';
    var tripleZero476 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr478").src = tripleZero476;
};

function squareToSzzZValue478(){
    valueSave = 'zSqrArtSpecz478';
    var tripleZero477 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr479").src = tripleZero477;
};

function squareToSzzZValue479(){
    valueSave = 'zSqrArtSpecz479';
    var tripleZero478 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr480").src = tripleZero478;
};

function squareToSzzZValue480(){
    valueSave = 'zSqrArtSpecz480';
    var tripleZero479 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr481").src = tripleZero479;
};

function squareToSzzZValue481(){
    valueSave = 'zSqrArtSpecz481';
    var tripleZero480 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr482").src = tripleZero480;
};

function squareToSzzZValue482(){
    valueSave = 'zSqrArtSpecz482';
    var tripleZero481 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr483").src = tripleZero481;
};

function squareToSzzZValue483(){
    valueSave = 'zSqrArtSpecz483';
    var tripleZero482 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr484").src = tripleZero482;
};

function squareToSzzZValue484(){
    valueSave = 'zSqrArtSpecz484';
    var tripleZero483 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr485").src = tripleZero483;
};

function squareToSzzZValue485(){
    valueSave = 'zSqrArtSpecz485';
    var tripleZero484 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr486").src = tripleZero484;
};

function squareToSzzZValue486(){
    valueSave = 'zSqrArtSpecz486';
    var tripleZero485 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr487").src = tripleZero485;
};

function squareToSzzZValue487(){
    valueSave = 'zSqrArtSpecz487';
    var tripleZero486 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr488").src = tripleZero486;
};

function squareToSzzZValue488(){
    valueSave = 'zSqrArtSpecz488';
    var tripleZero487 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr489").src = tripleZero487;
};

function squareToSzzZValue489(){
    valueSave = 'zSqrArtSpecz489';
    var tripleZero488 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr490").src = tripleZero488;
};

function squareToSzzZValue490(){
    valueSave = 'zSqrArtSpecz490';
    var tripleZero489 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr491").src = tripleZero489;
};

function squareToSzzZValue491(){
    valueSave = 'zSqrArtSpecz491';
    var tripleZero490 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr492").src = tripleZero490;
};

function squareToSzzZValue492(){
    valueSave = 'zSqrArtSpecz492';
    var tripleZero491 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr493").src = tripleZero491;
};

function squareToSzzZValue493(){
    valueSave = 'zSqrArtSpecz493';
    var tripleZero492 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr494").src = tripleZero492;
};

function squareToSzzZValue494(){
    valueSave = 'zSqrArtSpecz494';
    var tripleZero493 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr495").src = tripleZero493;
};

function squareToSzzZValue495(){
    valueSave = 'zSqrArtSpecz495';
    var tripleZero494 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr496").src = tripleZero494;
};

function squareToSzzZValue496(){
    valueSave = 'zSqrArtSpecz496';
    var tripleZero495 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr497").src = tripleZero495;
};

function squareToSzzZValue497(){
    valueSave = 'zSqrArtSpecz497';
    var tripleZero496 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr498").src = tripleZero496;
};

function squareToSzzZValue498(){
    valueSave = 'zSqrArtSpecz498';
    var tripleZero497 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr499").src = tripleZero497;
};

function squareToSzzZValue499(){
    valueSave = 'zSqrArtSpecz499';
    var tripleZero498 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr500").src = tripleZero498;
};

function squareToSzzZValue500(){
    valueSave = 'zSqrArtSpecz500';
    var tripleZero499 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr501").src = tripleZero499;
};

function squareToSzzZValue501(){
    valueSave = 'zSqrArtSpecz501';
    var tripleZero500 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr502").src = tripleZero500;
};

function squareToSzzZValue502(){
    valueSave = 'zSqrArtSpecz502';
    var tripleZero501 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr503").src = tripleZero501;
};

function squareToSzzZValue503(){
    valueSave = 'zSqrArtSpecz503';
    var tripleZero502 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr504").src = tripleZero502;
};

function squareToSzzZValue504(){
    valueSave = 'zSqrArtSpecz504';
    var tripleZero503 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr505").src = tripleZero503;
};

function squareToSzzZValue505(){
    valueSave = 'zSqrArtSpecz505';
    var tripleZero504 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr506").src = tripleZero504;
};

function squareToSzzZValue506(){
    valueSave = 'zSqrArtSpecz506';
    var tripleZero505 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr507").src = tripleZero505;
};

function squareToSzzZValue507(){
    valueSave = 'zSqrArtSpecz507';
    var tripleZero506 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr508").src = tripleZero506;
};

function squareToSzzZValue508(){
    valueSave = 'zSqrArtSpecz508';
    var tripleZero507 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr509").src = tripleZero507;
};

function squareToSzzZValue509(){
    valueSave = 'zSqrArtSpecz509';
    var tripleZero508 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr510").src = tripleZero508;
};

function squareToSzzZValue510(){
    valueSave = 'zSqrArtSpecz510';
    var tripleZero509 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr511").src = tripleZero509;
};

function squareToSzzZValue511(){
    valueSave = 'zSqrArtSpecz511';
    var tripleZero510 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr512").src = tripleZero510;
};

function squareToSzzZValue512(){
    valueSave = 'zSqrArtSpecz512';
    var tripleZero511 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr513").src = tripleZero511;
};

function squareToSzzZValue513(){
    valueSave = 'zSqrArtSpecz513';
    var tripleZero512 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr514").src = tripleZero512;
};

function squareToSzzZValue514(){
    valueSave = 'zSqrArtSpecz514';
    var tripleZero513 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr515").src = tripleZero513;
};

function squareToSzzZValue515(){
    valueSave = 'zSqrArtSpecz515';
    var tripleZero514 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr516").src = tripleZero514;
};

function squareToSzzZValue516(){
    valueSave = 'zSqrArtSpecz516';
    var tripleZero515 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr517").src = tripleZero515;
};

function squareToSzzZValue517(){
    valueSave = 'zSqrArtSpecz517';
    var tripleZero516 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr518").src = tripleZero516;
};

function squareToSzzZValue518(){
    valueSave = 'zSqrArtSpecz518';
    var tripleZero517 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr519").src = tripleZero517;
};

function squareToSzzZValue519(){
    valueSave = 'zSqrArtSpecz519';
    var tripleZero518 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr520").src = tripleZero518;
};

function squareToSzzZValue520(){
    valueSave = 'zSqrArtSpecz520';
    var tripleZero519 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr521").src = tripleZero519;
};

function squareToSzzZValue521(){
    valueSave = 'zSqrArtSpecz521';
    var tripleZero520 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr522").src = tripleZero520;
};

function squareToSzzZValue522(){
    valueSave = 'zSqrArtSpecz522';
    var tripleZero521 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr523").src = tripleZero521;
};

function squareToSzzZValue523(){
    valueSave = 'zSqrArtSpecz523';
    var tripleZero522 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr524").src = tripleZero522;
};

function squareToSzzZValue524(){
    valueSave = 'zSqrArtSpecz524';
    var tripleZero523 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr525").src = tripleZero523;
};

function squareToSzzZValue525(){
    valueSave = 'zSqrArtSpecz525';
    var tripleZero524 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr526").src = tripleZero524;
};

function squareToSzzZValue526(){
    valueSave = 'zSqrArtSpecz526';
    var tripleZero525 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr527").src = tripleZero525;
};

function squareToSzzZValue527(){
    valueSave = 'zSqrArtSpecz527';
    var tripleZero526 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr528").src = tripleZero526;
};

function squareToSzzZValue528(){
    valueSave = 'zSqrArtSpecz528';
    var tripleZero527 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr529").src = tripleZero527;
};

function squareToSzzZValue529(){
    valueSave = 'zSqrArtSpecz529';
    var tripleZero528 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr530").src = tripleZero528;
};

function squareToSzzZValue530(){
    valueSave = 'zSqrArtSpecz530';
    var tripleZero529 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr531").src = tripleZero529;
};

function squareToSzzZValue531(){
    valueSave = 'zSqrArtSpecz531';
    var tripleZero530 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr532").src = tripleZero530;
};

function squareToSzzZValue532(){
    valueSave = 'zSqrArtSpecz532';
    var tripleZero531 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr533").src = tripleZero531;
};

function squareToSzzZValue533(){
    valueSave = 'zSqrArtSpecz533';
    var tripleZero532 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr534").src = tripleZero532;
};

function squareToSzzZValue534(){
    valueSave = 'zSqrArtSpecz534';
    var tripleZero533 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr535").src = tripleZero533;
};

function squareToSzzZValue535(){
    valueSave = 'zSqrArtSpecz535';
    var tripleZero534 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr536").src = tripleZero534;
};

function squareToSzzZValue536(){
    valueSave = 'zSqrArtSpecz536';
    var tripleZero535 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr537").src = tripleZero535;
};

function squareToSzzZValue537(){
    valueSave = 'zSqrArtSpecz537';
    var tripleZero536 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr538").src = tripleZero536;
};

function squareToSzzZValue538(){
    valueSave = 'zSqrArtSpecz538';
    var tripleZero537 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr539").src = tripleZero537;
};

function squareToSzzZValue539(){
    valueSave = 'zSqrArtSpecz539';
    var tripleZero538 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr540").src = tripleZero538;
};

function squareToSzzZValue540(){
    valueSave = 'zSqrArtSpecz540';
    var tripleZero539 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr541").src = tripleZero539;
};

function squareToSzzZValue541(){
    valueSave = 'zSqrArtSpecz541';
    var tripleZero540 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr542").src = tripleZero540;
};

function squareToSzzZValue542(){
    valueSave = 'zSqrArtSpecz542';
    var tripleZero541 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr543").src = tripleZero541;
};

function squareToSzzZValue543(){
    valueSave = 'zSqrArtSpecz543';
    var tripleZero542 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr544").src = tripleZero542;
};

function squareToSzzZValue544(){
    valueSave = 'zSqrArtSpecz544';
    var tripleZero543 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr545").src = tripleZero543;
};

function squareToSzzZValue545(){
    valueSave = 'zSqrArtSpecz545';
    var tripleZero544 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr546").src = tripleZero544;
};

function squareToSzzZValue546(){
    valueSave = 'zSqrArtSpecz546';
    var tripleZero545 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr547").src = tripleZero545;
};

function squareToSzzZValue547(){
    valueSave = 'zSqrArtSpecz547';
    var tripleZero546 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr548").src = tripleZero546;
};

function squareToSzzZValue548(){
    valueSave = 'zSqrArtSpecz548';
    var tripleZero547 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr549").src = tripleZero547;
};

function squareToSzzZValue549(){
    valueSave = 'zSqrArtSpecz549';
    var tripleZero548 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr550").src = tripleZero548;
};

function squareToSzzZValue550(){
    valueSave = 'zSqrArtSpecz550';
    var tripleZero549 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr551").src = tripleZero549;
};

function squareToSzzZValue551(){
    valueSave = 'zSqrArtSpecz551';
    var tripleZero550 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr552").src = tripleZero550;
};

function squareToSzzZValue552(){
    valueSave = 'zSqrArtSpecz552';
    var tripleZero551 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr553").src = tripleZero551;
};

function squareToSzzZValue553(){
    valueSave = 'zSqrArtSpecz553';
    var tripleZero552 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr554").src = tripleZero552;
};

function squareToSzzZValue554(){
    valueSave = 'zSqrArtSpecz554';
    var tripleZero553 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr555").src = tripleZero553;
};

function squareToSzzZValue555(){
    valueSave = 'zSqrArtSpecz555';
    var tripleZero554 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr556").src = tripleZero554;
};

function squareToSzzZValue556(){
    valueSave = 'zSqrArtSpecz556';
    var tripleZero555 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr557").src = tripleZero555;
};

function squareToSzzZValue557(){
    valueSave = 'zSqrArtSpecz557';
    var tripleZero556 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr558").src = tripleZero556;
};

function squareToSzzZValue558(){
    valueSave = 'zSqrArtSpecz558';
    var tripleZero557 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr559").src = tripleZero557;
};

function squareToSzzZValue559(){
    valueSave = 'zSqrArtSpecz559';
    var tripleZero558 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr560").src = tripleZero558;
};

function squareToSzzZValue560(){
    valueSave = 'zSqrArtSpecz560';
    var tripleZero559 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr561").src = tripleZero559;
};

function squareToSzzZValue561(){
    valueSave = 'zSqrArtSpecz561';
    var tripleZero560 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr562").src = tripleZero560;
};

function squareToSzzZValue562(){
    valueSave = 'zSqrArtSpecz562';
    var tripleZero561 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr563").src = tripleZero561;
};

function squareToSzzZValue563(){
    valueSave = 'zSqrArtSpecz563';
    var tripleZero562 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr564").src = tripleZero562;
};

function squareToSzzZValue564(){
    valueSave = 'zSqrArtSpecz564';
    var tripleZero563 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr565").src = tripleZero563;
};

function squareToSzzZValue565(){
    valueSave = 'zSqrArtSpecz565';
    var tripleZero564 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr566").src = tripleZero564;
};

function squareToSzzZValue566(){
    valueSave = 'zSqrArtSpecz566';
    var tripleZero565 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr567").src = tripleZero565;
};

function squareToSzzZValue567(){
    valueSave = 'zSqrArtSpecz567';
    var tripleZero566 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr568").src = tripleZero566;
};

function squareToSzzZValue568(){
    valueSave = 'zSqrArtSpecz568';
    var tripleZero567 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr569").src = tripleZero567;
};

function squareToSzzZValue569(){
    valueSave = 'zSqrArtSpecz569';
    var tripleZero568 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr570").src = tripleZero568;
};

function squareToSzzZValue570(){
    valueSave = 'zSqrArtSpecz570';
    var tripleZero569 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr571").src = tripleZero569;
};

function squareToSzzZValue571(){
    valueSave = 'zSqrArtSpecz571';
    var tripleZero570 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr572").src = tripleZero570;
};

function squareToSzzZValue572(){
    valueSave = 'zSqrArtSpecz572';
    var tripleZero571 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr573").src = tripleZero571;
};

function squareToSzzZValue573(){
    valueSave = 'zSqrArtSpecz573';
    var tripleZero572 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr574").src = tripleZero572;
};

function squareToSzzZValue574(){
    valueSave = 'zSqrArtSpecz574';
    var tripleZero573 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr575").src = tripleZero573;
};

function squareToSzzZValue575(){
    valueSave = 'zSqrArtSpecz575';
    var tripleZero574 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr576").src = tripleZero574;
};

function squareToSzzZValue576(){
    valueSave = 'zSqrArtSpecz576';
    var tripleZero575 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr577").src = tripleZero575;
};

function squareToSzzZValue577(){
    valueSave = 'zSqrArtSpecz577';
    var tripleZero576 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr578").src = tripleZero576;
};

function squareToSzzZValue578(){
    valueSave = 'zSqrArtSpecz578';
    var tripleZero577 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr579").src = tripleZero577;
};

function squareToSzzZValue579(){
    valueSave = 'zSqrArtSpecz579';
    var tripleZero578 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr580").src = tripleZero578;
};

function squareToSzzZValue580(){
    valueSave = 'zSqrArtSpecz580';
    var tripleZero579 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr581").src = tripleZero579;
};

function squareToSzzZValue581(){
    valueSave = 'zSqrArtSpecz581';
    var tripleZero580 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr582").src = tripleZero580;
};

function squareToSzzZValue582(){
    valueSave = 'zSqrArtSpecz582';
    var tripleZero581 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr583").src = tripleZero581;
};

function squareToSzzZValue583(){
    valueSave = 'zSqrArtSpecz583';
    var tripleZero582 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr584").src = tripleZero582;
};

function squareToSzzZValue584(){
    valueSave = 'zSqrArtSpecz584';
    var tripleZero583 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr585").src = tripleZero583;
};

function squareToSzzZValue585(){
    valueSave = 'zSqrArtSpecz585';
    var tripleZero584 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr586").src = tripleZero584;
};

function squareToSzzZValue586(){
    valueSave = 'zSqrArtSpecz586';
    var tripleZero585 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr587").src = tripleZero585;
};

function squareToSzzZValue587(){
    valueSave = 'zSqrArtSpecz587';
    var tripleZero586 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr588").src = tripleZero586;
};

function squareToSzzZValue588(){
    valueSave = 'zSqrArtSpecz588';
    var tripleZero587 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr589").src = tripleZero587;
};

function squareToSzzZValue589(){
    valueSave = 'zSqrArtSpecz589';
    var tripleZero588 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr590").src = tripleZero588;
};

function squareToSzzZValue590(){
    valueSave = 'zSqrArtSpecz590';
    var tripleZero589 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr591").src = tripleZero589;
};

function squareToSzzZValue591(){
    valueSave = 'zSqrArtSpecz591';
    var tripleZero590 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr592").src = tripleZero590;
};

function squareToSzzZValue592(){
    valueSave = 'zSqrArtSpecz592';
    var tripleZero591 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr593").src = tripleZero591;
};

function squareToSzzZValue593(){
    valueSave = 'zSqrArtSpecz593';
    var tripleZero592 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr594").src = tripleZero592;
};

function squareToSzzZValue594(){
    valueSave = 'zSqrArtSpecz594';
    var tripleZero593 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr595").src = tripleZero593;
};

function squareToSzzZValue595(){
    valueSave = 'zSqrArtSpecz595';
    var tripleZero594 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr596").src = tripleZero594;
};

function squareToSzzZValue596(){
    valueSave = 'zSqrArtSpecz596';
    var tripleZero595 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr597").src = tripleZero595;
};

function squareToSzzZValue597(){
    valueSave = 'zSqrArtSpecz597';
    var tripleZero596 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr598").src = tripleZero596;
};

function squareToSzzZValue598(){
    valueSave = 'zSqrArtSpecz598';
    var tripleZero597 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr599").src = tripleZero597;
};

function squareToSzzZValue599(){
    valueSave = 'zSqrArtSpecz599';
    var tripleZero598 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr600").src = tripleZero598;
};

function squareToSzzZValue600(){
    valueSave = 'zSqrArtSpecz600';
    var tripleZero599 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr601").src = tripleZero599;
};

function squareToSzzZValue601(){
    valueSave = 'zSqrArtSpecz601';
    var tripleZero600 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr602").src = tripleZero600;
};

function squareToSzzZValue602(){
    valueSave = 'zSqrArtSpecz602';
    var tripleZero601 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr603").src = tripleZero601;
};

function squareToSzzZValue603(){
    valueSave = 'zSqrArtSpecz603';
    var tripleZero602 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr604").src = tripleZero602;
};

function squareToSzzZValue604(){
    valueSave = 'zSqrArtSpecz604';
    var tripleZero603 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr605").src = tripleZero603;
};

function squareToSzzZValue605(){
    valueSave = 'zSqrArtSpecz605';
    var tripleZero604 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr606").src = tripleZero604;
};

function squareToSzzZValue606(){
    valueSave = 'zSqrArtSpecz606';
    var tripleZero605 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr607").src = tripleZero605;
};

function squareToSzzZValue607(){
    valueSave = 'zSqrArtSpecz607';
    var tripleZero606 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr608").src = tripleZero606;
};

function squareToSzzZValue608(){
    valueSave = 'zSqrArtSpecz608';
    var tripleZero607 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr609").src = tripleZero607;
};

function squareToSzzZValue609(){
    valueSave = 'zSqrArtSpecz609';
    var tripleZero608 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr610").src = tripleZero608;
};

function squareToSzzZValue610(){
    valueSave = 'zSqrArtSpecz610';
    var tripleZero609 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr611").src = tripleZero609;
};

function squareToSzzZValue611(){
    valueSave = 'zSqrArtSpecz611';
    var tripleZero610 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr612").src = tripleZero610;
};

function squareToSzzZValue612(){
    valueSave = 'zSqrArtSpecz612';
    var tripleZero611 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr613").src = tripleZero611;
};

function squareToSzzZValue613(){
    valueSave = 'zSqrArtSpecz613';
    var tripleZero612 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr614").src = tripleZero612;
};

function squareToSzzZValue614(){
    valueSave = 'zSqrArtSpecz614';
    var tripleZero613 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr615").src = tripleZero613;
};

function squareToSzzZValue615(){
    valueSave = 'zSqrArtSpecz615';
    var tripleZero614 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr616").src = tripleZero614;
};

function squareToSzzZValue616(){
    valueSave = 'zSqrArtSpecz616';
    var tripleZero615 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr617").src = tripleZero615;
};

function squareToSzzZValue617(){
    valueSave = 'zSqrArtSpecz617';
    var tripleZero616 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr618").src = tripleZero616;
};

function squareToSzzZValue618(){
    valueSave = 'zSqrArtSpecz618';
    var tripleZero617 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr619").src = tripleZero617;
};

function squareToSzzZValue619(){
    valueSave = 'zSqrArtSpecz619';
    var tripleZero618 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr620").src = tripleZero618;
};

function squareToSzzZValue620(){
    valueSave = 'zSqrArtSpecz620';
    var tripleZero619 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr621").src = tripleZero619;
};

function squareToSzzZValue621(){
    valueSave = 'zSqrArtSpecz621';
    var tripleZero620 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr622").src = tripleZero620;
};

function squareToSzzZValue622(){
    valueSave = 'zSqrArtSpecz622';
    var tripleZero621 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr623").src = tripleZero621;
};

function squareToSzzZValue623(){
    valueSave = 'zSqrArtSpecz623';
    var tripleZero622 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr624").src = tripleZero622;
};

function squareToSzzZValue624(){
    valueSave = 'zSqrArtSpecz624';
    var tripleZero623 = localStorage.getItem(valueSave);
    document.getElementById("imgSqr625").src = tripleZero623;
};

function getBThis(){
    
    squareToSzzZValue0()
    squareToSzzZValue1()
    squareToSzzZValue2()
    squareToSzzZValue3()
    squareToSzzZValue4()
    squareToSzzZValue5()
    squareToSzzZValue6()
    squareToSzzZValue7()
    squareToSzzZValue8()
    squareToSzzZValue9()
    squareToSzzZValue10()
    squareToSzzZValue11()
    squareToSzzZValue12()
    squareToSzzZValue13()
    squareToSzzZValue14()
    squareToSzzZValue15()
    squareToSzzZValue16()
    squareToSzzZValue17()
    squareToSzzZValue18()
    squareToSzzZValue19()
    squareToSzzZValue20()
    squareToSzzZValue21()
    squareToSzzZValue22()
    squareToSzzZValue23()
    squareToSzzZValue24()
    squareToSzzZValue25()
    squareToSzzZValue26()
    squareToSzzZValue27()
    squareToSzzZValue28()
    squareToSzzZValue29()
    squareToSzzZValue30()
    squareToSzzZValue31()
    squareToSzzZValue32()
    squareToSzzZValue33()
    squareToSzzZValue34()
    squareToSzzZValue35()
    squareToSzzZValue36()
    squareToSzzZValue37()
    squareToSzzZValue38()
    squareToSzzZValue39()
    squareToSzzZValue40()
    squareToSzzZValue41()
    squareToSzzZValue42()
    squareToSzzZValue43()
    squareToSzzZValue44()
    squareToSzzZValue45()
    squareToSzzZValue46()
    squareToSzzZValue47()
    squareToSzzZValue48()
    squareToSzzZValue49()
    squareToSzzZValue50()
    squareToSzzZValue51()
    squareToSzzZValue52()
    squareToSzzZValue53()
    squareToSzzZValue54()
    squareToSzzZValue55()
    squareToSzzZValue56()
    squareToSzzZValue57()
    squareToSzzZValue58()
    squareToSzzZValue59()
    squareToSzzZValue60()
    squareToSzzZValue61()
    squareToSzzZValue62()
    squareToSzzZValue63()
    squareToSzzZValue64()
    squareToSzzZValue65()
    squareToSzzZValue66()
    squareToSzzZValue67()
    squareToSzzZValue68()
    squareToSzzZValue69()
    squareToSzzZValue70()
    squareToSzzZValue71()
    squareToSzzZValue72()
    squareToSzzZValue73()
    squareToSzzZValue74()
    squareToSzzZValue75()
    squareToSzzZValue76()
    squareToSzzZValue77()
    squareToSzzZValue78()
    squareToSzzZValue79()
    squareToSzzZValue80()
    squareToSzzZValue81()
    squareToSzzZValue82()
    squareToSzzZValue83()
    squareToSzzZValue84()
    squareToSzzZValue85()
    squareToSzzZValue86()
    squareToSzzZValue87()
    squareToSzzZValue88()
    squareToSzzZValue89()
    squareToSzzZValue90()
    squareToSzzZValue91()
    squareToSzzZValue92()
    squareToSzzZValue93()
    squareToSzzZValue94()
    squareToSzzZValue95()
    squareToSzzZValue96()
    squareToSzzZValue97()
    squareToSzzZValue98()
    squareToSzzZValue99()
    squareToSzzZValue100()
    squareToSzzZValue101()
    squareToSzzZValue102()
    squareToSzzZValue103()
    squareToSzzZValue104()
    squareToSzzZValue105()
    squareToSzzZValue106()
    squareToSzzZValue107()
    squareToSzzZValue108()
    squareToSzzZValue109()
    squareToSzzZValue110()
    squareToSzzZValue111()
    squareToSzzZValue112()
    squareToSzzZValue113()
    squareToSzzZValue114()
    squareToSzzZValue115()
    squareToSzzZValue116()
    squareToSzzZValue117()
    squareToSzzZValue118()
    squareToSzzZValue119()
    squareToSzzZValue120()
    squareToSzzZValue121()
    squareToSzzZValue122()
    squareToSzzZValue123()
    squareToSzzZValue124()
    squareToSzzZValue125()
    squareToSzzZValue126()
    squareToSzzZValue127()
    squareToSzzZValue128()
    squareToSzzZValue129()
    squareToSzzZValue130()
    squareToSzzZValue131()
    squareToSzzZValue132()
    squareToSzzZValue133()
    squareToSzzZValue134()
    squareToSzzZValue135()
    squareToSzzZValue136()
    squareToSzzZValue137()
    squareToSzzZValue138()
    squareToSzzZValue139()
    squareToSzzZValue140()
    squareToSzzZValue141()
    squareToSzzZValue142()
    squareToSzzZValue143()
    squareToSzzZValue144()
    squareToSzzZValue145()
    squareToSzzZValue146()
    squareToSzzZValue147()
    squareToSzzZValue148()
    squareToSzzZValue149()
    squareToSzzZValue150()
    squareToSzzZValue151()
    squareToSzzZValue152()
    squareToSzzZValue153()
    squareToSzzZValue154()
    squareToSzzZValue155()
    squareToSzzZValue156()
    squareToSzzZValue157()
    squareToSzzZValue158()
    squareToSzzZValue159()
    squareToSzzZValue160()
    squareToSzzZValue161()
    squareToSzzZValue162()
    squareToSzzZValue163()
    squareToSzzZValue164()
    squareToSzzZValue165()
    squareToSzzZValue166()
    squareToSzzZValue167()
    squareToSzzZValue168()
    squareToSzzZValue169()
    squareToSzzZValue170()
    squareToSzzZValue171()
    squareToSzzZValue172()
    squareToSzzZValue173()
    squareToSzzZValue174()
    squareToSzzZValue175()
    squareToSzzZValue176()
    squareToSzzZValue177()
    squareToSzzZValue178()
    squareToSzzZValue179()
    squareToSzzZValue180()
    squareToSzzZValue181()
    squareToSzzZValue182()
    squareToSzzZValue183()
    squareToSzzZValue184()
    squareToSzzZValue185()
    squareToSzzZValue186()
    squareToSzzZValue187()
    squareToSzzZValue188()
    squareToSzzZValue189()
    squareToSzzZValue190()
    squareToSzzZValue191()
    squareToSzzZValue192()
    squareToSzzZValue193()
    squareToSzzZValue194()
    squareToSzzZValue195()
    squareToSzzZValue196()
    squareToSzzZValue197()
    squareToSzzZValue198()
    squareToSzzZValue199()
    squareToSzzZValue200()
    squareToSzzZValue201()
    squareToSzzZValue202()
    squareToSzzZValue203()
    squareToSzzZValue204()
    squareToSzzZValue205()
    squareToSzzZValue206()
    squareToSzzZValue207()
    squareToSzzZValue208()
    squareToSzzZValue209()
    squareToSzzZValue210()
    squareToSzzZValue211()
    squareToSzzZValue212()
    squareToSzzZValue213()
    squareToSzzZValue214()
    squareToSzzZValue215()
    squareToSzzZValue216()
    squareToSzzZValue217()
    squareToSzzZValue218()
    squareToSzzZValue219()
    squareToSzzZValue220()
    squareToSzzZValue221()
    squareToSzzZValue222()
    squareToSzzZValue223()
    squareToSzzZValue224()
    squareToSzzZValue225()
    squareToSzzZValue226()
    squareToSzzZValue227()
    squareToSzzZValue228()
    squareToSzzZValue229()
    squareToSzzZValue230()
    squareToSzzZValue231()
    squareToSzzZValue232()
    squareToSzzZValue233()
    squareToSzzZValue234()
    squareToSzzZValue235()
    squareToSzzZValue236()
    squareToSzzZValue237()
    squareToSzzZValue238()
    squareToSzzZValue239()
    squareToSzzZValue240()
    squareToSzzZValue241()
    squareToSzzZValue242()
    squareToSzzZValue243()
    squareToSzzZValue244()
    squareToSzzZValue245()
    squareToSzzZValue246()
    squareToSzzZValue247()
    squareToSzzZValue248()
    squareToSzzZValue249()
    squareToSzzZValue250()
    squareToSzzZValue251()
    squareToSzzZValue252()
    squareToSzzZValue253()
    squareToSzzZValue254()
    squareToSzzZValue255()
    squareToSzzZValue256()
    squareToSzzZValue257()
    squareToSzzZValue258()
    squareToSzzZValue259()
    squareToSzzZValue260()
    squareToSzzZValue261()
    squareToSzzZValue262()
    squareToSzzZValue263()
    squareToSzzZValue264()
    squareToSzzZValue265()
    squareToSzzZValue266()
    squareToSzzZValue267()
    squareToSzzZValue268()
    squareToSzzZValue269()
    squareToSzzZValue270()
    squareToSzzZValue271()
    squareToSzzZValue272()
    squareToSzzZValue273()
    squareToSzzZValue274()
    squareToSzzZValue275()
    squareToSzzZValue276()
    squareToSzzZValue277()
    squareToSzzZValue278()
    squareToSzzZValue279()
    squareToSzzZValue280()
    squareToSzzZValue281()
    squareToSzzZValue282()
    squareToSzzZValue283()
    squareToSzzZValue284()
    squareToSzzZValue285()
    squareToSzzZValue286()
    squareToSzzZValue287()
    squareToSzzZValue288()
    squareToSzzZValue289()
    squareToSzzZValue290()
    squareToSzzZValue291()
    squareToSzzZValue292()
    squareToSzzZValue293()
    squareToSzzZValue294()
    squareToSzzZValue295()
    squareToSzzZValue296()
    squareToSzzZValue297()
    squareToSzzZValue298()
    squareToSzzZValue299()
    squareToSzzZValue300()
    squareToSzzZValue301()
    squareToSzzZValue302()
    squareToSzzZValue303()
    squareToSzzZValue304()
    squareToSzzZValue305()
    squareToSzzZValue306()
    squareToSzzZValue307()
    squareToSzzZValue308()
    squareToSzzZValue309()
    squareToSzzZValue310()
    squareToSzzZValue311()
    squareToSzzZValue312()
    squareToSzzZValue313()
    squareToSzzZValue314()
    squareToSzzZValue315()
    squareToSzzZValue316()
    squareToSzzZValue317()
    squareToSzzZValue318()
    squareToSzzZValue319()
    squareToSzzZValue320()
    squareToSzzZValue321()
    squareToSzzZValue322()
    squareToSzzZValue323()
    squareToSzzZValue324()
    squareToSzzZValue325()
    squareToSzzZValue326()
    squareToSzzZValue327()
    squareToSzzZValue328()
    squareToSzzZValue329()
    squareToSzzZValue330()
    squareToSzzZValue331()
    squareToSzzZValue332()
    squareToSzzZValue333()
    squareToSzzZValue334()
    squareToSzzZValue335()
    squareToSzzZValue336()
    squareToSzzZValue337()
    squareToSzzZValue338()
    squareToSzzZValue339()
    squareToSzzZValue340()
    squareToSzzZValue341()
    squareToSzzZValue342()
    squareToSzzZValue343()
    squareToSzzZValue344()
    squareToSzzZValue345()
    squareToSzzZValue346()
    squareToSzzZValue347()
    squareToSzzZValue348()
    squareToSzzZValue349()
    squareToSzzZValue350()
    squareToSzzZValue351()
    squareToSzzZValue352()
    squareToSzzZValue353()
    squareToSzzZValue354()
    squareToSzzZValue355()
    squareToSzzZValue356()
    squareToSzzZValue357()
    squareToSzzZValue358()
    squareToSzzZValue359()
    squareToSzzZValue360()
    squareToSzzZValue361()
    squareToSzzZValue362()
    squareToSzzZValue363()
    squareToSzzZValue364()
    squareToSzzZValue365()
    squareToSzzZValue366()
    squareToSzzZValue367()
    squareToSzzZValue368()
    squareToSzzZValue369()
    squareToSzzZValue370()
    squareToSzzZValue371()
    squareToSzzZValue372()
    squareToSzzZValue373()
    squareToSzzZValue374()
    squareToSzzZValue375()
    squareToSzzZValue376()
    squareToSzzZValue377()
    squareToSzzZValue378()
    squareToSzzZValue379()
    squareToSzzZValue380()
    squareToSzzZValue381()
    squareToSzzZValue382()
    squareToSzzZValue383()
    squareToSzzZValue384()
    squareToSzzZValue385()
    squareToSzzZValue386()
    squareToSzzZValue387()
    squareToSzzZValue388()
    squareToSzzZValue389()
    squareToSzzZValue390()
    squareToSzzZValue391()
    squareToSzzZValue392()
    squareToSzzZValue393()
    squareToSzzZValue394()
    squareToSzzZValue395()
    squareToSzzZValue396()
    squareToSzzZValue397()
    squareToSzzZValue398()
    squareToSzzZValue399()
    squareToSzzZValue400()
    squareToSzzZValue401()
    squareToSzzZValue402()
    squareToSzzZValue403()
    squareToSzzZValue404()
    squareToSzzZValue405()
    squareToSzzZValue406()
    squareToSzzZValue407()
    squareToSzzZValue408()
    squareToSzzZValue409()
    squareToSzzZValue410()
    squareToSzzZValue411()
    squareToSzzZValue412()
    squareToSzzZValue413()
    squareToSzzZValue414()
    squareToSzzZValue415()
    squareToSzzZValue416()
    squareToSzzZValue417()
    squareToSzzZValue418()
    squareToSzzZValue419()
    squareToSzzZValue420()
    squareToSzzZValue421()
    squareToSzzZValue422()
    squareToSzzZValue423()
    squareToSzzZValue424()
    squareToSzzZValue425()
    squareToSzzZValue426()
    squareToSzzZValue427()
    squareToSzzZValue428()
    squareToSzzZValue429()
    squareToSzzZValue430()
    squareToSzzZValue431()
    squareToSzzZValue432()
    squareToSzzZValue433()
    squareToSzzZValue434()
    squareToSzzZValue435()
    squareToSzzZValue436()
    squareToSzzZValue437()
    squareToSzzZValue438()
    squareToSzzZValue439()
    squareToSzzZValue440()
    squareToSzzZValue441()
    squareToSzzZValue442()
    squareToSzzZValue443()
    squareToSzzZValue444()
    squareToSzzZValue445()
    squareToSzzZValue446()
    squareToSzzZValue447()
    squareToSzzZValue448()
    squareToSzzZValue449()
    squareToSzzZValue450()
    squareToSzzZValue451()
    squareToSzzZValue452()
    squareToSzzZValue453()
    squareToSzzZValue454()
    squareToSzzZValue455()
    squareToSzzZValue456()
    squareToSzzZValue457()
    squareToSzzZValue458()
    squareToSzzZValue459()
    squareToSzzZValue460()
    squareToSzzZValue461()
    squareToSzzZValue462()
    squareToSzzZValue463()
    squareToSzzZValue464()
    squareToSzzZValue465()
    squareToSzzZValue466()
    squareToSzzZValue467()
    squareToSzzZValue468()
    squareToSzzZValue469()
    squareToSzzZValue470()
    squareToSzzZValue471()
    squareToSzzZValue472()
    squareToSzzZValue473()
    squareToSzzZValue474()
    squareToSzzZValue475()
    squareToSzzZValue476()
    squareToSzzZValue477()
    squareToSzzZValue478()
    squareToSzzZValue479()
    squareToSzzZValue480()
    squareToSzzZValue481()
    squareToSzzZValue482()
    squareToSzzZValue483()
    squareToSzzZValue484()
    squareToSzzZValue485()
    squareToSzzZValue486()
    squareToSzzZValue487()
    squareToSzzZValue488()
    squareToSzzZValue489()
    squareToSzzZValue490()
    squareToSzzZValue491()
    squareToSzzZValue492()
    squareToSzzZValue493()
    squareToSzzZValue494()
    squareToSzzZValue495()
    squareToSzzZValue496()
    squareToSzzZValue497()
    squareToSzzZValue498()
    squareToSzzZValue499()
    squareToSzzZValue500()
    squareToSzzZValue501()
    squareToSzzZValue502()
    squareToSzzZValue503()
    squareToSzzZValue504()
    squareToSzzZValue505()
    squareToSzzZValue506()
    squareToSzzZValue507()
    squareToSzzZValue508()
    squareToSzzZValue509()
    squareToSzzZValue510()
    squareToSzzZValue511()
    squareToSzzZValue512()
    squareToSzzZValue513()
    squareToSzzZValue514()
    squareToSzzZValue515()
    squareToSzzZValue516()
    squareToSzzZValue517()
    squareToSzzZValue518()
    squareToSzzZValue519()
    squareToSzzZValue520()
    squareToSzzZValue521()
    squareToSzzZValue522()
    squareToSzzZValue523()
    squareToSzzZValue524()
    squareToSzzZValue525()
    squareToSzzZValue526()
    squareToSzzZValue527()
    squareToSzzZValue528()
    squareToSzzZValue529()
    squareToSzzZValue530()
    squareToSzzZValue531()
    squareToSzzZValue532()
    squareToSzzZValue533()
    squareToSzzZValue534()
    squareToSzzZValue535()
    squareToSzzZValue536()
    squareToSzzZValue537()
    squareToSzzZValue538()
    squareToSzzZValue539()
    squareToSzzZValue540()
    squareToSzzZValue541()
    squareToSzzZValue542()
    squareToSzzZValue543()
    squareToSzzZValue544()
    squareToSzzZValue545()
    squareToSzzZValue546()
    squareToSzzZValue547()
    squareToSzzZValue548()
    squareToSzzZValue549()
    squareToSzzZValue550()
    squareToSzzZValue551()
    squareToSzzZValue552()
    squareToSzzZValue553()
    squareToSzzZValue554()
    squareToSzzZValue555()
    squareToSzzZValue556()
    squareToSzzZValue557()
    squareToSzzZValue558()
    squareToSzzZValue559()
    squareToSzzZValue560()
    squareToSzzZValue561()
    squareToSzzZValue562()
    squareToSzzZValue563()
    squareToSzzZValue564()
    squareToSzzZValue565()
    squareToSzzZValue566()
    squareToSzzZValue567()
    squareToSzzZValue568()
    squareToSzzZValue569()
    squareToSzzZValue570()
    squareToSzzZValue571()
    squareToSzzZValue572()
    squareToSzzZValue573()
    squareToSzzZValue574()
    squareToSzzZValue575()
    squareToSzzZValue576()
    squareToSzzZValue577()
    squareToSzzZValue578()
    squareToSzzZValue579()
    squareToSzzZValue580()
    squareToSzzZValue581()
    squareToSzzZValue582()
    squareToSzzZValue583()
    squareToSzzZValue584()
    squareToSzzZValue585()
    squareToSzzZValue586()
    squareToSzzZValue587()
    squareToSzzZValue588()
    squareToSzzZValue589()
    squareToSzzZValue590()
    squareToSzzZValue591()
    squareToSzzZValue592()
    squareToSzzZValue593()
    squareToSzzZValue594()
    squareToSzzZValue595()
    squareToSzzZValue596()
    squareToSzzZValue597()
    squareToSzzZValue598()
    squareToSzzZValue599()
    squareToSzzZValue600()
    squareToSzzZValue601()
    squareToSzzZValue602()
    squareToSzzZValue603()
    squareToSzzZValue604()
    squareToSzzZValue605()
    squareToSzzZValue606()
    squareToSzzZValue607()
    squareToSzzZValue608()
    squareToSzzZValue609()
    squareToSzzZValue610()
    squareToSzzZValue611()
    squareToSzzZValue612()
    squareToSzzZValue613()
    squareToSzzZValue614()
    squareToSzzZValue615()
    squareToSzzZValue616()
    squareToSzzZValue617()
    squareToSzzZValue618()
    squareToSzzZValue619()
    squareToSzzZValue620()
    squareToSzzZValue621()
    squareToSzzZValue622()
    squareToSzzZValue623()
    squareToSzzZValue624()
    
    alert("Your art has been loaded successfully from your browser's local browser storage.");

};

function squareNull(){
    valueSave = 'zSqrArtSpecz0';
    var tripleZeroA = localStorage.getItem(valueSave);
    if(tripleZeroA == null){
        setAThis();
    }else{
        getBThis();
    };
};