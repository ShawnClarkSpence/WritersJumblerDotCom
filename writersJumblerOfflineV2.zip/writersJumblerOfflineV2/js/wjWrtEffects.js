function textAligns() {
  var x = document.getElementById("menu0").value;
  document.getElementById("writersJumbler").style.textAlign = x;
}
function sizes() {
  var x = document.getElementById("menu1").value;
  document.getElementById("writersJumbler").style.fontSize = x;
}
function fontsA() {
  var x = document.getElementById("menu2").value;
  document.getElementById("writersJumbler").style.fontFamily = x;
}
function fontStyles() {
  var x = document.getElementById("menu3").value;
  document.getElementById("writersJumbler").style.fontStyle = x;
}
function fontWeights() {
  var x = document.getElementById("menu4").value;
  document.getElementById("writersJumbler").style.fontWeight = x;
}
function textVariants() {
  var x = document.getElementById("menu5").value;
  document.getElementById("writersJumbler").style.fontVariant = x;
}
function textSpacings() {
  var x = document.getElementById("menu6").value;
  document.getElementById("writersJumbler").style.letterSpacing = x;
}
function textTransforms() {
  var x = document.getElementById("menu7").value;
  document.getElementById("writersJumbler").style.textTransform = x;
}
function wordSpacings() {
  var x = document.getElementById("menu8").value;
  document.getElementById("writersJumbler").style.wordSpacing = x;
}
function borderSizes() {
  var x = document.getElementById("menu9").value;
  document.getElementById("writersJumbler").style.borderWidth = x;
}
function backgroundC2rgb(){
	var j = document.getElementById("Background_Color2-R").value;
	var k = document.getElementById("Background_Color2-G").value;
	var l = document.getElementById("Background_Color2-B").value;
	if(j >= 255){
		j = 255;
	};
	if(k >= 255){
		k = 255;
	};
	if(l >= 255){
		l = 255;
	};
	var p = "rgb(";
	var q = ")";
	var r = p + j + ", " + k + ", " + l + q;
	document.getElementById("WJss").style.backgroundColor = r;
	document.getElementById("slc2").style.backgroundColor = r;
	
}
function backgroundC3rgb(){
	var j = document.getElementById("Background_Color3-R").value;
	var k = document.getElementById("Background_Color3-G").value;
	var l = document.getElementById("Background_Color3-B").value;
	if(j >= 255){
		j = 255;
	};
	if(k >= 255){
		k = 255;
	};
	if(l >= 255){
		l = 255;
	};
	var p = "rgb(";
	var q = ")";
	var r = p + j + ", " + k + ", " + l + q;
	document.getElementById("writersJumbler").style.backgroundColor = r;
	
}
function fontCrgb(){
	var m = document.getElementById("Font_Color-R").value;
	var n = document.getElementById("Font_Color-G").value;
	var o = document.getElementById("Font_Color-B").value;
	if(m >= 255){
		m = 255;
	};
	if(n >= 255){
		n = 255;
	};
	if(o >= 255){
		o = 255;
	};
	var p = "rgb(";
	var q = ")";
	var s = p + m + ", " + n + ", " + o + q;
	document.getElementById("WJss").style.color = s;
}
function fontCrgb1(){
	var m = document.getElementById("Font_Color_1-R").value;
	var n = document.getElementById("Font_Color_1-G").value;
	var o = document.getElementById("Font_Color_1-B").value;
	if(m >= 255){
		m = 255;
	};
	if(n >= 255){
		n = 255;
	};
	if(o >= 255){
		o = 255;
	};
	var p = "rgb(";
	var q = ")";
	var s = p + m + ", " + n + ", " + o + q;
	document.getElementById("writersJumbler").style.color = s;
}
function fontCrgb2(){
	var m = document.getElementById("Font_Color_2-R").value;
	var n = document.getElementById("Font_Color_2-G").value;
	var o = document.getElementById("Font_Color_2-B").value;
	if(m >= 255){
		m = 255;
	};
	if(n >= 255){
		n = 255;
	};
	if(o >= 255){
		o = 255;
	};
	var p = "#";
	var dec0 = "0";
	var dec1 = "1";
	var dec2 = "2";
	var dec3 = "3";
	var dec4 = "4";
	var dec5 = "5";
	var dec6 = "6";
	var dec7 = "7";
	var dec8 = "8";
	var dec9 = "9";
	var dec10 = "10";
	var dec11 = "11";
	var dec12 = "12";
	var dec13 = "13";
	var dec14 = "14";
	var dec15 = "15";
	var dec16 = "16";
	var dec17 = "17";
	var dec18 = "18";
	var dec19 = "19";
	var dec20 = "20";
	var dec21 = "21";
	var dec22 = "22";
	var dec23 = "23";
	var dec24 = "24";
	var dec25 = "25";
	var dec26 = "26";
	var dec27 = "27";
	var dec28 = "28";
	var dec29 = "29";
	var dec30 = "30";
	var dec31 = "31";
	var dec32 = "32";
	var dec33 = "33";
	var dec34 = "34";
	var dec35 = "35";
	var dec36 = "36";
	var dec37 = "37";
	var dec38 = "38";
	var dec39 = "39";
	var dec40 = "40";
	var dec41 = "41";
	var dec42 = "42";
	var dec43 = "43";
	var dec44 = "44";
	var dec45 = "45";
	var dec46 = "46";
	var dec47 = "47";
	var dec48 = "48";
	var dec49 = "49";
	var dec50 = "50";
	var dec51 = "51";
	var dec52 = "52";
	var dec53 = "53";
	var dec54 = "54";
	var dec55 = "55";
	var dec56 = "56";
	var dec57 = "57";
	var dec58 = "58";
	var dec59 = "59";
	var dec60 = "60";
	var dec61 = "61";
	var dec62 = "62";
	var dec63 = "63";
	var dec64 = "64";
	var dec65 = "65";
	var dec66 = "66";
	var dec67 = "67";
	var dec68 = "68";
	var dec69 = "69";
	var dec70 = "70";
	var dec71 = "71";
	var dec72 = "72";
	var dec73 = "73";
	var dec74 = "74";
	var dec75 = "75";
	var dec76 = "76";
	var dec77 = "77";
	var dec78 = "78";
	var dec79 = "79";
	var dec80 = "80";
	var dec81 = "81";
	var dec82 = "82";
	var dec83 = "83";
	var dec84 = "84";
	var dec85 = "85";
	var dec86 = "86";
	var dec87 = "87";
	var dec88 = "88";
	var dec89 = "89";
	var dec90 = "90";
	var dec91 = "91";
	var dec92 = "92";
	var dec93 = "93";
	var dec94 = "94";
	var dec95 = "95";
	var dec96 = "96";
	var dec97 = "97";
	var dec98 = "98";
	var dec99 = "99";
	var dec100 = "100";
	var dec101 = "101";
	var dec102 = "102";
	var dec103 = "103";
	var dec104 = "104";
	var dec105 = "105";
	var dec106 = "106";
	var dec107 = "107";
	var dec108 = "108";
	var dec109 = "109";
	var dec110 = "110";
	var dec111 = "111";
	var dec112 = "112";
	var dec113 = "113";
	var dec114 = "114";
	var dec115 = "115";
	var dec116 = "116";
	var dec117 = "117";
	var dec118 = "118";
	var dec119 = "119";
	var dec120 = "120";
	var dec121 = "121";
	var dec122 = "122";
	var dec123 = "123";
	var dec124 = "124";
	var dec125 = "125";
	var dec126 = "126";
	var dec127 = "127";
	var dec128 = "128";
	var dec129 = "129";
	var dec130 = "130";
	var dec131 = "131";
	var dec132 = "132";
	var dec133 = "133";
	var dec134 = "134";
	var dec135 = "135";
	var dec136 = "136";
	var dec137 = "137";
	var dec138 = "138";
	var dec139 = "139";
	var dec140 = "140";
	var dec141 = "141";
	var dec142 = "142";
	var dec143 = "143";
	var dec144 = "144";
	var dec145 = "145";
	var dec146 = "146";
	var dec147 = "147";
	var dec148 = "148";
	var dec149 = "149";
	var dec150 = "150";
	var dec151 = "151";
	var dec152 = "152";
	var dec153 = "153";
	var dec154 = "154";
	var dec155 = "155";
	var dec156 = "156";
	var dec157 = "157";
	var dec158 = "158";
	var dec159 = "159";
	var dec160 = "160";
	var dec161 = "161";
	var dec162 = "162";
	var dec163 = "163";
	var dec164 = "164";
	var dec165 = "165";
	var dec166 = "166";
	var dec167 = "167";
	var dec168 = "168";
	var dec169 = "169";
	var dec170 = "170";
	var dec171 = "171";
	var dec172 = "172";
	var dec173 = "173";
	var dec174 = "174";
	var dec175 = "175";
	var dec176 = "176";
	var dec177 = "177";
	var dec178 = "178";
	var dec179 = "179";
	var dec180 = "180";
	var dec181 = "181";
	var dec182 = "182";
	var dec183 = "183";
	var dec184 = "184";
	var dec185 = "185";
	var dec186 = "186";
	var dec187 = "187";
	var dec188 = "188";
	var dec189 = "189";
	var dec190 = "190";
	var dec191 = "191";
	var dec192 = "192";
	var dec193 = "193";
	var dec194 = "194";
	var dec195 = "195";
	var dec196 = "196";
	var dec197 = "197";
	var dec198 = "198";
	var dec199 = "199";
	var dec200 = "200";
	var dec201 = "201";
	var dec202 = "202";
	var dec203 = "203";
	var dec204 = "204";
	var dec205 = "205";
	var dec206 = "206";
	var dec207 = "207";
	var dec208 = "208";
	var dec209 = "209";
	var dec210 = "210";
	var dec211 = "211";
	var dec212 = "212";
	var dec213 = "213";
	var dec214 = "214";
	var dec215 = "215";
	var dec216 = "216";
	var dec217 = "217";
	var dec218 = "218";
	var dec219 = "219";
	var dec220 = "220";
	var dec221 = "221";
	var dec222 = "222";
	var dec223 = "223";
	var dec224 = "224";
	var dec225 = "225";
	var dec226 = "226";
	var dec227 = "227";
	var dec228 = "228";
	var dec229 = "229";
	var dec230 = "230";
	var dec231 = "231";
	var dec232 = "232";
	var dec233 = "233";
	var dec234 = "234";
	var dec235 = "235";
	var dec236 = "236";
	var dec237 = "237";
	var dec238 = "238";
	var dec239 = "239";
	var dec240 = "240";
	var dec241 = "241";
	var dec242 = "242";
	var dec243 = "243";
	var dec244 = "244";
	var dec245 = "245";
	var dec246 = "246";
	var dec247 = "247";
	var dec248 = "248";
	var dec249 = "249";
	var dec250 = "250";
	var dec251 = "251";
	var dec252 = "252";
	var dec253 = "253";
	var dec254 = "254";
	var dec255 = "255";
	if(dec0 == m){
		q = "00"
	};
	if(dec1 == m){
		q = "01"
	};
	if(dec2 == m){
		q = "02"
	};
	if(dec3 == m){
		q = "03"
	};
	if(dec4 == m){
		q = "04"
	};
	if(dec5 == m){
		q = "05"
	};
	if(dec6 == m){
		q = "06"
	};
	if(dec7 == m){
		q = "07"
	};
	if(dec8 == m){
		q = "08"
	};
	if(dec9 == m){
		q = "09"
	}
	if(dec10 == m){
		q = "0a"
	};
	if(dec11 == m){
		q = "0b"
	};
	if(dec12 == m){
		q = "0c"
	};
	if(dec13 == m){
		q = "0d"
	};
	if(dec14 == m){
		q = "0e"
	};
	if(dec15 == m){
		q = "0f"
	};
	if(dec16 == m){
		q = "10"
	};
	if(dec17 == m){
		q = "11"
	};
	if(dec18 == m){
		q = "12"
	};
	if(dec19 == m){
		q = "13"
	}
	if(dec20 == m){
		q = "14"
	};
	if(dec21 == m){
		q = "15"
	};
	if(dec22 == m){
		q = "16"
	};
	if(dec23 == m){
		q = "17"
	};
	if(dec24 == m){
		q = "18"
	};
	if(dec25 == m){
		q = "19"
	};
	if(dec26 == m){
		q = "1a"
	};
	if(dec27 == m){
		q = "1b"
	};
	if(dec28 == m){
		q = "1c"
	};
	if(dec29 == m){
		q = "1d"
	}
	if(dec30 == m){
		q = "1e"
	};
	if(dec31 == m){
		q = "1f"
	};
	if(dec32 == m){
		q = "20"
	};
	if(dec33 == m){
		q = "21"
	};
	if(dec34 == m){
		q = "22"
	};
	if(dec35 == m){
		q = "23"
	};
	if(dec36 == m){
		q = "24"
	};
	if(dec37 == m){
		q = "25"
	};
	if(dec38 == m){
		q = "26"
	};
	if(dec39 == m){
		q = "27"
	}
	if(dec40 == m){
		q = "28"
	};
	if(dec41 == m){
		q = "29"
	};
	if(dec42 == m){
		q = "2a"
	};
	if(dec43 == m){
		q = "2b"
	};
	if(dec44 == m){
		q = "2c"
	};
	if(dec45 == m){
		q = "2d"
	};
	if(dec46 == m){
		q = "2e"
	};
	if(dec47 == m){
		q = "2f"
	};
	if(dec48 == m){
		q = "30"
	};
	if(dec49 == m){
		q = "31"
	}
	if(dec50 == m){
		q = "32"
	};
	if(dec51 == m){
		q = "33"
	};
	if(dec52 == m){
		q = "34"
	};
	if(dec53 == m){
		q = "35"
	};
	if(dec54 == m){
		q = "36"
	};
	if(dec55 == m){
		q = "37"
	};
	if(dec56 == m){
		q = "38"
	};
	if(dec57 == m){
		q = "39"
	};
	if(dec58 == m){
		q = "3a"
	};
	if(dec59 == m){
		q = "3b"
	}
	if(dec60 == m){
		q = "3c"
	};
	if(dec61 == m){
		q = "3d"
	};
	if(dec62 == m){
		q = "3e"
	};
	if(dec63 == m){
		q = "3f"
	};
	if(dec64 == m){
		q = "40"
	};
	if(dec65 == m){
		q = "41"
	};
	if(dec66 == m){
		q = "42"
	};
	if(dec67 == m){
		q = "43"
	};
	if(dec68 == m){
		q = "44"
	};
	if(dec69 == m){
		q = "45"
	}
	if(dec70 == m){
		q = "46"
	};
	if(dec71 == m){
		q = "47"
	};
	if(dec72 == m){
		q = "48"
	};
	if(dec73 == m){
		q = "49"
	};
	if(dec74 == m){
		q = "4a"
	};
	if(dec75 == m){
		q = "4b"
	};
	if(dec76 == m){
		q = "4c"
	};
	if(dec77 == m){
		q = "4d"
	};
	if(dec78 == m){
		q = "4e"
	};
	if(dec79 == m){
		q = "4f"
	}
	if(dec80 == m){
		q = "50"
	};
	if(dec81 == m){
		q = "51"
	};
	if(dec82 == m){
		q = "52"
	};
	if(dec83 == m){
		q = "53"
	};
	if(dec84 == m){
		q = "54"
	};
	if(dec85 == m){
		q = "55"
	};
	if(dec86 == m){
		q = "56"
	};
	if(dec87 == m){
		q = "57"
	};
	if(dec88 == m){
		q = "58"
	};
	if(dec89 == m){
		q = "59"
	}
	if(dec90 == m){
		q = "5a"
	};
	if(dec91 == m){
		q = "5b"
	};
	if(dec92 == m){
		q = "5c"
	};
	if(dec93 == m){
		q = "5d"
	};
	if(dec94 == m){
		q = "5e"
	};
	if(dec95 == m){
		q = "5f"
	};
	if(dec96 == m){
		q = "60"
	};
	if(dec97 == m){
		q = "61"
	};
	if(dec98 == m){
		q = "62"
	};
	if(dec99 == m){
		q = "63"
	}
	if(dec100 == m){
		q = "64"
	};
	if(dec101 == m){
		q = "65"
	};
	if(dec102 == m){
		q = "66"
	};
	if(dec103 == m){
		q = "67"
	};
	if(dec104 == m){
		q = "68"
	};
	if(dec105 == m){
		q = "69"
	};
	if(dec106 == m){
		q = "6a"
	};
	if(dec107 == m){
		q = "6b"
	};
	if(dec108 == m){
		q = "6c"
	};
	if(dec109 == m){
		q = "6d"
	}
	if(dec110 == m){
		q = "6e"
	};
	if(dec111 == m){
		q = "6f"
	};
	if(dec112 == m){
		q = "70"
	};
	if(dec113 == m){
		q = "71"
	};
	if(dec114 == m){
		q = "72"
	};
	if(dec115 == m){
		q = "73"
	};
	if(dec116 == m){
		q = "74"
	};
	if(dec117 == m){
		q = "75"
	};
	if(dec118 == m){
		q = "76"
	};
	if(dec119 == m){
		q = "77"
	}
	if(dec120 == m){
		q = "78"
	};
	if(dec121 == m){
		q = "79"
	};
	if(dec122 == m){
		q = "7a"
	};
	if(dec123 == m){
		q = "7b"
	};
	if(dec124 == m){
		q = "7c"
	};
	if(dec125 == m){
		q = "7d"
	};
	if(dec126 == m){
		q = "7e"
	};
	if(dec127 == m){
		q = "7f"
	};
	if(dec128 == m){
		q = "80"
	};
	if(dec129 == m){
		q = "81"
	}
	if(dec130 == m){
		q = "82"
	};
	if(dec131 == m){
		q = "83"
	};
	if(dec132 == m){
		q = "84"
	};
	if(dec133 == m){
		q = "85"
	};
	if(dec134 == m){
		q = "86"
	};
	if(dec135 == m){
		q = "87"
	};
	if(dec136 == m){
		q = "88"
	};
	if(dec137 == m){
		q = "89"
	};
	if(dec138 == m){
		q = "8a"
	};
	if(dec139 == m){
		q = "8b"
	}
	if(dec140 == m){
		q = "8c"
	};
	if(dec141 == m){
		q = "8d"
	};
	if(dec142 == m){
		q = "8e"
	};
	if(dec143 == m){
		q = "8f"
	};
	if(dec144 == m){
		q = "90"
	};
	if(dec145 == m){
		q = "91"
	};
	if(dec146 == m){
		q = "92"
	};
	if(dec147 == m){
		q = "93"
	};
	if(dec148 == m){
		q = "94"
	};
	if(dec149 == m){
		q = "95"
	}
	if(dec150 == m){
		q = "96"
	};
	if(dec151 == m){
		q = "97"
	};
	if(dec152 == m){
		q = "98"
	};
	if(dec153 == m){
		q = "99"
	};
	if(dec154 == m){
		q = "9a"
	};
	if(dec155 == m){
		q = "9b"
	};
	if(dec156 == m){
		q = "9c"
	};
	if(dec157 == m){
		q = "9d"
	};
	if(dec158 == m){
		q = "9e"
	};
	if(dec159 == m){
		q = "9f"
	}
	if(dec160 == m){
		q = "a0"
	};
	if(dec161 == m){
		q = "a1"
	};
	if(dec162 == m){
		q = "a2"
	};
	if(dec163 == m){
		q = "a3"
	};
	if(dec164 == m){
		q = "a4"
	};
	if(dec165 == m){
		q = "a5"
	};
	if(dec166 == m){
		q = "a6"
	};
	if(dec167 == m){
		q = "a7"
	};
	if(dec168 == m){
		q = "a8"
	};
	if(dec169 == m){
		q = "a9"
	}
	if(dec170 == m){
		q = "aa"
	};
	if(dec171 == m){
		q = "ab"
	};
	if(dec172 == m){
		q = "ac"
	};
	if(dec173 == m){
		q = "ad"
	};
	if(dec174 == m){
		q = "ae"
	};
	if(dec175 == m){
		q = "af"
	};
	if(dec176 == m){
		q = "b0"
	};
	if(dec177 == m){
		q = "b1"
	};
	if(dec178 == m){
		q = "b2"
	};
	if(dec179 == m){
		q = "b3"
	}
	if(dec180 == m){
		q = "b4"
	};
	if(dec181 == m){
		q = "b5"
	};
	if(dec182 == m){
		q = "b6"
	};
	if(dec183 == m){
		q = "b7"
	};
	if(dec184 == m){
		q = "b8"
	};
	if(dec185 == m){
		q = "b9"
	};
	if(dec186 == m){
		q = "ba"
	};
	if(dec187 == m){
		q = "bb"
	};
	if(dec188 == m){
		q = "bc"
	};
	if(dec189 == m){
		q = "bd"
	}
	if(dec190 == m){
		q = "be"
	};
	if(dec191 == m){
		q = "bf"
	};
	if(dec192 == m){
		q = "c0"
	};
	if(dec193 == m){
		q = "c1"
	};
	if(dec194 == m){
		q = "c2"
	};
	if(dec195 == m){
		q = "c3"
	};
	if(dec196 == m){
		q = "c4"
	};
	if(dec197 == m){
		q = "c5"
	};
	if(dec198 == m){
		q = "c6"
	};
	if(dec199 == m){
		q = "c7"
	}
	if(dec200 == m){
		q = "c8"
	};
	if(dec201 == m){
		q = "c9"
	};
	if(dec202 == m){
		q = "ca"
	};
	if(dec203 == m){
		q = "cb"
	};
	if(dec204 == m){
		q = "cc"
	};
	if(dec205 == m){
		q = "cd"
	};
	if(dec206 == m){
		q = "ce"
	};
	if(dec207 == m){
		q = "cf"
	};
	if(dec208 == m){
		q = "d0"
	};
	if(dec209 == m){
		q = "d1"
	}
	if(dec210 == m){
		q = "d2"
	};
	if(dec211 == m){
		q = "d3"
	};
	if(dec212 == m){
		q = "d4"
	};
	if(dec213 == m){
		q = "d5"
	};
	if(dec214 == m){
		q = "d6"
	};
	if(dec215 == m){
		q = "d7"
	};
	if(dec216 == m){
		q = "d8"
	};
	if(dec217 == m){
		q = "d9"
	};
	if(dec218 == m){
		q = "da"
	};
	if(dec219 == m){
		q = "db"
	}
	if(dec220 == m){
		q = "dc"
	};
	if(dec221 == m){
		q = "dd"
	};
	if(dec222 == m){
		q = "de"
	};
	if(dec223 == m){
		q = "df"
	};
	if(dec224 == m){
		q = "e0"
	};
	if(dec225 == m){
		q = "e1"
	};
	if(dec226 == m){
		q = "e2"
	};
	if(dec227 == m){
		q = "e3"
	};
	if(dec228 == m){
		q = "e4"
	};
	if(dec229 == m){
		q = "e5"
	}
	if(dec230 == m){
		q = "e6"
	};
	if(dec231 == m){
		q = "e7"
	};
	if(dec232 == m){
		q = "e8"
	};
	if(dec233 == m){
		q = "e9"
	};
	if(dec234 == m){
		q = "ea"
	};
	if(dec235 == m){
		q = "eb"
	};
	if(dec236 == m){
		q = "ec"
	};
	if(dec237 == m){
		q = "ed"
	};
	if(dec238 == m){
		q = "ee"
	};
	if(dec239 == m){
		q = "ef"
	}
	if(dec240 == m){
		q = "f0"
	};
	if(dec241 == m){
		q = "f1"
	};
	if(dec242 == m){
		q = "f2"
	};
	if(dec243 == m){
		q = "f3"
	};
	if(dec244 == m){
		q = "f4"
	};
	if(dec245 == m){
		q = "f5"
	};
	if(dec246 == m){
		q = "f6"
	};
	if(dec247 == m){
		q = "f7"
	};
	if(dec248 == m){
		q = "f8"
	};
	if(dec249 == m){
		q = "f9"
	}
	if(dec250 == m){
		q = "fa"
	};
	if(dec251 == m){
		q = "fb"
	};
	if(dec252 == m){
		q = "fc"
	};
	if(dec253 == m){
		q = "fd"
	};
	if(dec254 == m){
		q = "fe"
	};
	if(dec255 == m){
		q = "ff"
	};
	
	if(dec0 == n){
		r = "00"
	};
	if(dec1 == n){
		r = "01"
	};
	if(dec2 == n){
		r = "02"
	};
	if(dec3 == n){
		r = "03"
	};
	if(dec4 == n){
		r = "04"
	};
	if(dec5 == n){
		r = "05"
	};
	if(dec6 == n){
		r = "06"
	};
	if(dec7 == n){
		r = "07"
	};
	if(dec8 == n){
		r = "08"
	};
	if(dec9 == n){
		r = "09"
	}
	if(dec10 == n){
		r = "0a"
	};
	if(dec11 == n){
		r = "0b"
	};
	if(dec12 == n){
		r = "0c"
	};
	if(dec13 == n){
		r = "0d"
	};
	if(dec14 == n){
		r = "0e"
	};
	if(dec15 == n){
		r = "0f"
	};
	if(dec16 == n){
		r = "10"
	};
	if(dec17 == n){
		r = "11"
	};
	if(dec18 == n){
		r = "12"
	};
	if(dec19 == n){
		r = "13"
	}
	if(dec20 == n){
		r = "14"
	};
	if(dec21 == n){
		r = "15"
	};
	if(dec22 == n){
		r = "16"
	};
	if(dec23 == n){
		r = "17"
	};
	if(dec24 == n){
		r = "18"
	};
	if(dec25 == n){
		r = "19"
	};
	if(dec26 == n){
		r = "1a"
	};
	if(dec27 == n){
		r = "1b"
	};
	if(dec28 == n){
		r = "1c"
	};
	if(dec29 == n){
		r = "1d"
	}
	if(dec30 == n){
		r = "1e"
	};
	if(dec31 == n){
		r = "1f"
	};
	if(dec32 == n){
		r = "20"
	};
	if(dec33 == n){
		r = "21"
	};
	if(dec34 == n){
		r = "22"
	};
	if(dec35 == n){
		r = "23"
	};
	if(dec36 == n){
		r = "24"
	};
	if(dec37 == n){
		r = "25"
	};
	if(dec38 == n){
		r = "26"
	};
	if(dec39 == n){
		r = "27"
	}
	if(dec40 == n){
		r = "28"
	};
	if(dec41 == n){
		r = "29"
	};
	if(dec42 == n){
		r = "2a"
	};
	if(dec43 == n){
		r = "2b"
	};
	if(dec44 == n){
		r = "2c"
	};
	if(dec45 == n){
		r = "2d"
	};
	if(dec46 == n){
		r = "2e"
	};
	if(dec47 == n){
		r = "2f"
	};
	if(dec48 == n){
		r = "30"
	};
	if(dec49 == n){
		r = "31"
	}
	if(dec50 == n){
		r = "32"
	};
	if(dec51 == n){
		r = "33"
	};
	if(dec52 == n){
		r = "34"
	};
	if(dec53 == n){
		r = "35"
	};
	if(dec54 == n){
		r = "36"
	};
	if(dec55 == n){
		r = "37"
	};
	if(dec56 == n){
		r = "38"
	};
	if(dec57 == n){
		r = "39"
	};
	if(dec58 == n){
		r = "3a"
	};
	if(dec59 == n){
		r = "3b"
	}
	if(dec60 == n){
		r = "3c"
	};
	if(dec61 == n){
		r = "3d"
	};
	if(dec62 == n){
		r = "3e"
	};
	if(dec63 == n){
		r = "3f"
	};
	if(dec64 == n){
		r = "40"
	};
	if(dec65 == n){
		r = "41"
	};
	if(dec66 == n){
		r = "42"
	};
	if(dec67 == n){
		r = "43"
	};
	if(dec68 == n){
		r = "44"
	};
	if(dec69 == n){
		r = "45"
	}
	if(dec70 == n){
		r = "46"
	};
	if(dec71 == n){
		r = "47"
	};
	if(dec72 == n){
		r = "48"
	};
	if(dec73 == n){
		r = "49"
	};
	if(dec74 == n){
		r = "4a"
	};
	if(dec75 == n){
		r = "4b"
	};
	if(dec76 == n){
		r = "4c"
	};
	if(dec77 == n){
		r = "4d"
	};
	if(dec78 == n){
		r = "4e"
	};
	if(dec79 == n){
		r = "4f"
	}
	if(dec80 == n){
		r = "50"
	};
	if(dec81 == n){
		r = "51"
	};
	if(dec82 == n){
		r = "52"
	};
	if(dec83 == n){
		r = "53"
	};
	if(dec84 == n){
		r = "54"
	};
	if(dec85 == n){
		r = "55"
	};
	if(dec86 == n){
		r = "56"
	};
	if(dec87 == n){
		r = "57"
	};
	if(dec88 == n){
		r = "58"
	};
	if(dec89 == n){
		r = "59"
	}
	if(dec90 == n){
		r = "5a"
	};
	if(dec91 == n){
		r = "5b"
	};
	if(dec92 == n){
		r = "5c"
	};
	if(dec93 == n){
		r = "5d"
	};
	if(dec94 == n){
		r = "5e"
	};
	if(dec95 == n){
		r = "5f"
	};
	if(dec96 == n){
		r = "60"
	};
	if(dec97 == n){
		r = "61"
	};
	if(dec98 == n){
		r = "62"
	};
	if(dec99 == n){
		r = "63"
	}
	if(dec100 == n){
		r = "64"
	};
	if(dec101 == n){
		r = "65"
	};
	if(dec102 == n){
		r = "66"
	};
	if(dec103 == n){
		r = "67"
	};
	if(dec104 == n){
		r = "68"
	};
	if(dec105 == n){
		r = "69"
	};
	if(dec106 == n){
		r = "6a"
	};
	if(dec107 == n){
		r = "6b"
	};
	if(dec108 == n){
		r = "6c"
	};
	if(dec109 == n){
		r = "6d"
	}
	if(dec110 == n){
		r = "6e"
	};
	if(dec111 == n){
		r = "6f"
	};
	if(dec112 == n){
		r = "70"
	};
	if(dec113 == n){
		r = "71"
	};
	if(dec114 == n){
		r = "72"
	};
	if(dec115 == n){
		r = "73"
	};
	if(dec116 == n){
		r = "74"
	};
	if(dec117 == n){
		r = "75"
	};
	if(dec118 == n){
		r = "76"
	};
	if(dec119 == n){
		r = "77"
	}
	if(dec120 == n){
		r = "78"
	};
	if(dec121 == n){
		r = "79"
	};
	if(dec122 == n){
		r = "7a"
	};
	if(dec123 == n){
		r = "7b"
	};
	if(dec124 == n){
		r = "7c"
	};
	if(dec125 == n){
		r = "7d"
	};
	if(dec126 == n){
		r = "7e"
	};
	if(dec127 == n){
		r = "7f"
	};
	if(dec128 == n){
		r = "80"
	};
	if(dec129 == n){
		r = "81"
	}
	if(dec130 == n){
		r = "82"
	};
	if(dec131 == n){
		r = "83"
	};
	if(dec132 == n){
		r = "84"
	};
	if(dec133 == n){
		r = "85"
	};
	if(dec134 == n){
		r = "86"
	};
	if(dec135 == n){
		r = "87"
	};
	if(dec136 == n){
		r = "88"
	};
	if(dec137 == n){
		r = "89"
	};
	if(dec138 == n){
		r = "8a"
	};
	if(dec139 == n){
		r = "8b"
	}
	if(dec140 == n){
		r = "8c"
	};
	if(dec141 == n){
		r = "8d"
	};
	if(dec142 == n){
		r = "8e"
	};
	if(dec143 == n){
		r = "8f"
	};
	if(dec144 == n){
		r = "90"
	};
	if(dec145 == n){
		r = "91"
	};
	if(dec146 == n){
		r = "92"
	};
	if(dec147 == n){
		r = "93"
	};
	if(dec148 == n){
		r = "94"
	};
	if(dec149 == n){
		r = "95"
	}
	if(dec150 == n){
		r = "96"
	};
	if(dec151 == n){
		r = "97"
	};
	if(dec152 == n){
		r = "98"
	};
	if(dec153 == n){
		r = "99"
	};
	if(dec154 == n){
		r = "9a"
	};
	if(dec155 == n){
		r = "9b"
	};
	if(dec156 == n){
		r = "9c"
	};
	if(dec157 == n){
		r = "9d"
	};
	if(dec158 == n){
		r = "9e"
	};
	if(dec159 == n){
		r = "9f"
	}
	if(dec160 == n){
		r = "a0"
	};
	if(dec161 == n){
		r = "a1"
	};
	if(dec162 == n){
		r = "a2"
	};
	if(dec163 == n){
		r = "a3"
	};
	if(dec164 == n){
		r = "a4"
	};
	if(dec165 == n){
		r = "a5"
	};
	if(dec166 == n){
		r = "a6"
	};
	if(dec167 == n){
		r = "a7"
	};
	if(dec168 == n){
		r = "a8"
	};
	if(dec169 == n){
		r = "a9"
	}
	if(dec170 == n){
		r = "aa"
	};
	if(dec171 == n){
		r = "ab"
	};
	if(dec172 == n){
		r = "ac"
	};
	if(dec173 == n){
		r = "ad"
	};
	if(dec174 == n){
		r = "ae"
	};
	if(dec175 == n){
		r = "af"
	};
	if(dec176 == n){
		r = "b0"
	};
	if(dec177 == n){
		r = "b1"
	};
	if(dec178 == n){
		r = "b2"
	};
	if(dec179 == n){
		r = "b3"
	}
	if(dec180 == n){
		r = "b4"
	};
	if(dec181 == n){
		r = "b5"
	};
	if(dec182 == n){
		r = "b6"
	};
	if(dec183 == n){
		r = "b7"
	};
	if(dec184 == n){
		r = "b8"
	};
	if(dec185 == n){
		r = "b9"
	};
	if(dec186 == n){
		r = "ba"
	};
	if(dec187 == n){
		r = "bb"
	};
	if(dec188 == n){
		r = "bc"
	};
	if(dec189 == n){
		r = "bd"
	}
	if(dec190 == n){
		r = "be"
	};
	if(dec191 == n){
		r = "bf"
	};
	if(dec192 == n){
		r = "c0"
	};
	if(dec193 == n){
		r = "c1"
	};
	if(dec194 == n){
		r = "c2"
	};
	if(dec195 == n){
		r = "c3"
	};
	if(dec196 == n){
		r = "c4"
	};
	if(dec197 == n){
		r = "c5"
	};
	if(dec198 == n){
		r = "c6"
	};
	if(dec199 == n){
		r = "c7"
	}
	if(dec200 == n){
		r = "c8"
	};
	if(dec201 == n){
		r = "c9"
	};
	if(dec202 == n){
		r = "ca"
	};
	if(dec203 == n){
		r = "cb"
	};
	if(dec204 == n){
		r = "cc"
	};
	if(dec205 == n){
		r = "cd"
	};
	if(dec206 == n){
		r = "ce"
	};
	if(dec207 == n){
		r = "cf"
	};
	if(dec208 == n){
		r = "d0"
	};
	if(dec209 == n){
		r = "d1"
	}
	if(dec210 == n){
		r = "d2"
	};
	if(dec211 == n){
		r = "d3"
	};
	if(dec212 == n){
		r = "d4"
	};
	if(dec213 == n){
		r = "d5"
	};
	if(dec214 == n){
		r = "d6"
	};
	if(dec215 == n){
		r = "d7"
	};
	if(dec216 == n){
		r = "d8"
	};
	if(dec217 == n){
		r = "d9"
	};
	if(dec218 == n){
		r = "da"
	};
	if(dec219 == n){
		r = "db"
	}
	if(dec220 == n){
		r = "dc"
	};
	if(dec221 == n){
		r = "dd"
	};
	if(dec222 == n){
		r = "de"
	};
	if(dec223 == n){
		r = "df"
	};
	if(dec224 == n){
		r = "e0"
	};
	if(dec225 == n){
		r = "e1"
	};
	if(dec226 == n){
		r = "e2"
	};
	if(dec227 == n){
		r = "e3"
	};
	if(dec228 == n){
		r = "e4"
	};
	if(dec229 == n){
		r = "e5"
	}
	if(dec230 == n){
		r = "e6"
	};
	if(dec231 == n){
		r = "e7"
	};
	if(dec232 == n){
		r = "e8"
	};
	if(dec233 == n){
		r = "e9"
	};
	if(dec234 == n){
		r = "ea"
	};
	if(dec235 == n){
		r = "eb"
	};
	if(dec236 == n){
		r = "ec"
	};
	if(dec237 == n){
		r = "ed"
	};
	if(dec238 == n){
		r = "ee"
	};
	if(dec239 == n){
		r = "ef"
	}
	if(dec240 == n){
		r = "f0"
	};
	if(dec241 == n){
		r = "f1"
	};
	if(dec242 == n){
		r = "f2"
	};
	if(dec243 == n){
		r = "f3"
	};
	if(dec244 == n){
		r = "f4"
	};
	if(dec245 == n){
		r = "f5"
	};
	if(dec246 == n){
		r = "f6"
	};
	if(dec247 == n){
		r = "f7"
	};
	if(dec248 == n){
		r = "f8"
	};
	if(dec249 == n){
		r = "f9"
	}
	if(dec250 == n){
		r = "fa"
	};
	if(dec251 == n){
		r = "fb"
	};
	if(dec252 == n){
		r = "fc"
	};
	if(dec253 == n){
		r = "fd"
	};
	if(dec254 == n){
		r = "fe"
	};
	if(dec255 == n){
		r = "ff"
	};
	
	
	if(dec0 == o){
		s = "00"
	};
	if(dec1 == o){
		s = "01"
	};
	if(dec2 == o){
		s = "02"
	};
	if(dec3 == o){
		s = "03"
	};
	if(dec4 == o){
		s = "04"
	};
	if(dec5 == o){
		s = "05"
	};
	if(dec6 == o){
		s = "06"
	};
	if(dec7 == o){
		s = "07"
	};
	if(dec8 == o){
		s = "08"
	};
	if(dec9 == o){
		s = "09"
	}
	if(dec10 == o){
		s = "0a"
	};
	if(dec11 == o){
		s = "0b"
	};
	if(dec12 == o){
		s = "0c"
	};
	if(dec13 == o){
		s = "0d"
	};
	if(dec14 == o){
		s = "0e"
	};
	if(dec15 == o){
		s = "0f"
	};
	if(dec16 == o){
		s = "10"
	};
	if(dec17 == o){
		s = "11"
	};
	if(dec18 == o){
		s = "12"
	};
	if(dec19 == o){
		s = "13"
	}
	if(dec20 == o){
		s = "14"
	};
	if(dec21 == o){
		s = "15"
	};
	if(dec22 == o){
		s = "16"
	};
	if(dec23 == o){
		s = "17"
	};
	if(dec24 == o){
		s = "18"
	};
	if(dec25 == o){
		s = "19"
	};
	if(dec26 == o){
		s = "1a"
	};
	if(dec27 == o){
		s = "1b"
	};
	if(dec28 == o){
		s = "1c"
	};
	if(dec29 == o){
		s = "1d"
	}
	if(dec30 == o){
		s = "1e"
	};
	if(dec31 == o){
		s = "1f"
	};
	if(dec32 == o){
		s = "20"
	};
	if(dec33 == o){
		s = "21"
	};
	if(dec34 == o){
		s = "22"
	};
	if(dec35 == o){
		s = "23"
	};
	if(dec36 == o){
		s = "24"
	};
	if(dec37 == o){
		s = "25"
	};
	if(dec38 == o){
		s = "26"
	};
	if(dec39 == o){
		s = "27"
	}
	if(dec40 == o){
		s = "28"
	};
	if(dec41 == o){
		s = "29"
	};
	if(dec42 == o){
		s = "2a"
	};
	if(dec43 == o){
		s = "2b"
	};
	if(dec44 == o){
		s = "2c"
	};
	if(dec45 == o){
		s = "2d"
	};
	if(dec46 == o){
		s = "2e"
	};
	if(dec47 == o){
		s = "2f"
	};
	if(dec48 == o){
		s = "30"
	};
	if(dec49 == o){
		s = "31"
	}
	if(dec50 == o){
		s = "32"
	};
	if(dec51 == o){
		s = "33"
	};
	if(dec52 == o){
		s = "34"
	};
	if(dec53 == o){
		s = "35"
	};
	if(dec54 == o){
		s = "36"
	};
	if(dec55 == o){
		s = "37"
	};
	if(dec56 == o){
		s = "38"
	};
	if(dec57 == o){
		s = "39"
	};
	if(dec58 == o){
		s = "3a"
	};
	if(dec59 == o){
		s = "3b"
	}
	if(dec60 == o){
		s = "3c"
	};
	if(dec61 == o){
		s = "3d"
	};
	if(dec62 == o){
		s = "3e"
	};
	if(dec63 == o){
		s = "3f"
	};
	if(dec64 == o){
		s = "40"
	};
	if(dec65 == o){
		s = "41"
	};
	if(dec66 == o){
		s = "42"
	};
	if(dec67 == o){
		s = "43"
	};
	if(dec68 == o){
		s = "44"
	};
	if(dec69 == o){
		s = "45"
	}
	if(dec70 == o){
		s = "46"
	};
	if(dec71 == o){
		s = "47"
	};
	if(dec72 == o){
		s = "48"
	};
	if(dec73 == o){
		s = "49"
	};
	if(dec74 == o){
		s = "4a"
	};
	if(dec75 == o){
		s = "4b"
	};
	if(dec76 == o){
		s = "4c"
	};
	if(dec77 == o){
		s = "4d"
	};
	if(dec78 == o){
		s = "4e"
	};
	if(dec79 == o){
		s = "4f"
	}
	if(dec80 == o){
		s = "50"
	};
	if(dec81 == o){
		s = "51"
	};
	if(dec82 == o){
		s = "52"
	};
	if(dec83 == o){
		s = "53"
	};
	if(dec84 == o){
		s = "54"
	};
	if(dec85 == o){
		s = "55"
	};
	if(dec86 == o){
		s = "56"
	};
	if(dec87 == o){
		s = "57"
	};
	if(dec88 == o){
		s = "58"
	};
	if(dec89 == o){
		s = "59"
	}
	if(dec90 == o){
		s = "5a"
	};
	if(dec91 == o){
		s = "5b"
	};
	if(dec92 == o){
		s = "5c"
	};
	if(dec93 == o){
		s = "5d"
	};
	if(dec94 == o){
		s = "5e"
	};
	if(dec95 == o){
		s = "5f"
	};
	if(dec96 == o){
		s = "60"
	};
	if(dec97 == o){
		s = "61"
	};
	if(dec98 == o){
		s = "62"
	};
	if(dec99 == o){
		s = "63"
	}
	if(dec100 == o){
		s = "64"
	};
	if(dec101 == o){
		s = "65"
	};
	if(dec102 == o){
		s = "66"
	};
	if(dec103 == o){
		s = "67"
	};
	if(dec104 == o){
		s = "68"
	};
	if(dec105 == o){
		s = "69"
	};
	if(dec106 == o){
		s = "6a"
	};
	if(dec107 == o){
		s = "6b"
	};
	if(dec108 == o){
		s = "6c"
	};
	if(dec109 == o){
		s = "6d"
	}
	if(dec110 == o){
		s = "6e"
	};
	if(dec111 == o){
		s = "6f"
	};
	if(dec112 == o){
		s = "70"
	};
	if(dec113 == o){
		s = "71"
	};
	if(dec114 == o){
		s = "72"
	};
	if(dec115 == o){
		s = "73"
	};
	if(dec116 == o){
		s = "74"
	};
	if(dec117 == o){
		s = "75"
	};
	if(dec118 == o){
		s = "76"
	};
	if(dec119 == o){
		s = "77"
	}
	if(dec120 == o){
		s = "78"
	};
	if(dec121 == o){
		s = "79"
	};
	if(dec122 == o){
		s = "7a"
	};
	if(dec123 == o){
		s = "7b"
	};
	if(dec124 == o){
		s = "7c"
	};
	if(dec125 == o){
		s = "7d"
	};
	if(dec126 == o){
		s = "7e"
	};
	if(dec127 == o){
		s = "7f"
	};
	if(dec128 == o){
		s = "80"
	};
	if(dec129 == o){
		s = "81"
	}
	if(dec130 == o){
		s = "82"
	};
	if(dec131 == o){
		s = "83"
	};
	if(dec132 == o){
		s = "84"
	};
	if(dec133 == o){
		s = "85"
	};
	if(dec134 == o){
		s = "86"
	};
	if(dec135 == o){
		s = "87"
	};
	if(dec136 == o){
		s = "88"
	};
	if(dec137 == o){
		s = "89"
	};
	if(dec138 == o){
		s = "8a"
	};
	if(dec139 == o){
		s = "8b"
	}
	if(dec140 == o){
		s = "8c"
	};
	if(dec141 == o){
		s = "8d"
	};
	if(dec142 == o){
		s = "8e"
	};
	if(dec143 == o){
		s = "8f"
	};
	if(dec144 == o){
		s = "90"
	};
	if(dec145 == o){
		s = "91"
	};
	if(dec146 == o){
		s = "92"
	};
	if(dec147 == o){
		s = "93"
	};
	if(dec148 == o){
		s = "94"
	};
	if(dec149 == o){
		s = "95"
	}
	if(dec150 == o){
		s = "96"
	};
	if(dec151 == o){
		s = "97"
	};
	if(dec152 == o){
		s = "98"
	};
	if(dec153 == o){
		s = "99"
	};
	if(dec154 == o){
		s = "9a"
	};
	if(dec155 == o){
		s = "9b"
	};
	if(dec156 == o){
		s = "9c"
	};
	if(dec157 == o){
		s = "9d"
	};
	if(dec158 == o){
		s = "9e"
	};
	if(dec159 == o){
		s = "9f"
	}
	if(dec160 == o){
		s = "a0"
	};
	if(dec161 == o){
		s = "a1"
	};
	if(dec162 == o){
		s = "a2"
	};
	if(dec163 == o){
		s = "a3"
	};
	if(dec164 == o){
		s = "a4"
	};
	if(dec165 == o){
		s = "a5"
	};
	if(dec166 == o){
		s = "a6"
	};
	if(dec167 == o){
		s = "a7"
	};
	if(dec168 == o){
		s = "a8"
	};
	if(dec169 == o){
		s = "a9"
	}
	if(dec170 == o){
		s = "aa"
	};
	if(dec171 == o){
		s = "ab"
	};
	if(dec172 == o){
		s = "ac"
	};
	if(dec173 == o){
		s = "ad"
	};
	if(dec174 == o){
		s = "ae"
	};
	if(dec175 == o){
		s = "af"
	};
	if(dec176 == o){
		s = "b0"
	};
	if(dec177 == o){
		s = "b1"
	};
	if(dec178 == o){
		s = "b2"
	};
	if(dec179 == o){
		s = "b3"
	}
	if(dec180 == o){
		s = "b4"
	};
	if(dec181 == o){
		s = "b5"
	};
	if(dec182 == o){
		s = "b6"
	};
	if(dec183 == o){
		s = "b7"
	};
	if(dec184 == o){
		s = "b8"
	};
	if(dec185 == o){
		s = "b9"
	};
	if(dec186 == o){
		s = "ba"
	};
	if(dec187 == o){
		s = "bb"
	};
	if(dec188 == o){
		s = "bc"
	};
	if(dec189 == o){
		s = "bd"
	}
	if(dec190 == o){
		s = "be"
	};
	if(dec191 == o){
		s = "bf"
	};
	if(dec192 == o){
		s = "c0"
	};
	if(dec193 == o){
		s = "c1"
	};
	if(dec194 == o){
		s = "c2"
	};
	if(dec195 == o){
		s = "c3"
	};
	if(dec196 == o){
		s = "c4"
	};
	if(dec197 == o){
		s = "c5"
	};
	if(dec198 == o){
		s = "c6"
	};
	if(dec199 == o){
		s = "c7"
	}
	if(dec200 == o){
		s = "c8"
	};
	if(dec201 == o){
		s = "c9"
	};
	if(dec202 == o){
		s = "ca"
	};
	if(dec203 == o){
		s = "cb"
	};
	if(dec204 == o){
		s = "cc"
	};
	if(dec205 == o){
		s = "cd"
	};
	if(dec206 == o){
		s = "ce"
	};
	if(dec207 == o){
		s = "cf"
	};
	if(dec208 == o){
		s = "d0"
	};
	if(dec209 == o){
		s = "d1"
	}
	if(dec210 == o){
		s = "d2"
	};
	if(dec211 == o){
		s = "d3"
	};
	if(dec212 == o){
		s = "d4"
	};
	if(dec213 == o){
		s = "d5"
	};
	if(dec214 == o){
		s = "d6"
	};
	if(dec215 == o){
		s = "d7"
	};
	if(dec216 == o){
		s = "d8"
	};
	if(dec217 == o){
		s = "d9"
	};
	if(dec218 == o){
		s = "da"
	};
	if(dec219 == o){
		s = "db"
	}
	if(dec220 == o){
		s = "dc"
	};
	if(dec221 == o){
		s = "dd"
	};
	if(dec222 == o){
		s = "de"
	};
	if(dec223 == o){
		s = "df"
	};
	if(dec224 == o){
		s = "e0"
	};
	if(dec225 == o){
		s = "e1"
	};
	if(dec226 == o){
		s = "e2"
	};
	if(dec227 == o){
		s = "e3"
	};
	if(dec228 == o){
		s = "e4"
	};
	if(dec229 == o){
		s = "e5"
	}
	if(dec230 == o){
		s = "e6"
	};
	if(dec231 == o){
		s = "e7"
	};
	if(dec232 == o){
		s = "e8"
	};
	if(dec233 == o){
		s = "e9"
	};
	if(dec234 == o){
		s = "ea"
	};
	if(dec235 == o){
		s = "eb"
	};
	if(dec236 == o){
		s = "ec"
	};
	if(dec237 == o){
		s = "ed"
	};
	if(dec238 == o){
		s = "ee"
	};
	if(dec239 == o){
		s = "ef"
	}
	if(dec240 == o){
		s = "f0"
	};
	if(dec241 == o){
		s = "f1"
	};
	if(dec242 == o){
		s = "f2"
	};
	if(dec243 == o){
		s = "f3"
	};
	if(dec244 == o){
		s = "f4"
	};
	if(dec245 == o){
		s = "f5"
	};
	if(dec246 == o){
		s = "f6"
	};
	if(dec247 == o){
		s = "f7"
	};
	if(dec248 == o){
		s = "f8"
	};
	if(dec249 == o){
		s = "f9"
	}
	if(dec250 == o){
		s = "fa"
	};
	if(dec251 == o){
		s = "fb"
	};
	if(dec252 == o){
		s = "fc"
	};
	if(dec253 == o){
		s = "fd"
	};
	if(dec254 == o){
		s = "fe"
	};
	if(dec255 == o){
		s = "ff"
	};
	var t = p + q + r + s;
	var nPut1 = document.getElementById("menu12").value;
	var nPut2 = document.getElementById("menu13").value;
	var u = nPut1 + "px " + nPut2 + "px ";
	document.getElementById("writersJumbler").style.textShadow = u + t;
}
function borderCrgb(){
	var m = document.getElementById("Border_Color-R").value;
	var n = document.getElementById("Border_Color-G").value;
	var o = document.getElementById("Border_Color-B").value;
	if(m >= 255){
		m = 255;
	};
	if(n >= 255){
		n = 255;
	};
	if(o >= 255){
		o = 255;
	};
	var p = "#";
	var dec0 = "0";
	var dec1 = "1";
	var dec2 = "2";
	var dec3 = "3";
	var dec4 = "4";
	var dec5 = "5";
	var dec6 = "6";
	var dec7 = "7";
	var dec8 = "8";
	var dec9 = "9";
	var dec10 = "10";
	var dec11 = "11";
	var dec12 = "12";
	var dec13 = "13";
	var dec14 = "14";
	var dec15 = "15";
	var dec16 = "16";
	var dec17 = "17";
	var dec18 = "18";
	var dec19 = "19";
	var dec20 = "20";
	var dec21 = "21";
	var dec22 = "22";
	var dec23 = "23";
	var dec24 = "24";
	var dec25 = "25";
	var dec26 = "26";
	var dec27 = "27";
	var dec28 = "28";
	var dec29 = "29";
	var dec30 = "30";
	var dec31 = "31";
	var dec32 = "32";
	var dec33 = "33";
	var dec34 = "34";
	var dec35 = "35";
	var dec36 = "36";
	var dec37 = "37";
	var dec38 = "38";
	var dec39 = "39";
	var dec40 = "40";
	var dec41 = "41";
	var dec42 = "42";
	var dec43 = "43";
	var dec44 = "44";
	var dec45 = "45";
	var dec46 = "46";
	var dec47 = "47";
	var dec48 = "48";
	var dec49 = "49";
	var dec50 = "50";
	var dec51 = "51";
	var dec52 = "52";
	var dec53 = "53";
	var dec54 = "54";
	var dec55 = "55";
	var dec56 = "56";
	var dec57 = "57";
	var dec58 = "58";
	var dec59 = "59";
	var dec60 = "60";
	var dec61 = "61";
	var dec62 = "62";
	var dec63 = "63";
	var dec64 = "64";
	var dec65 = "65";
	var dec66 = "66";
	var dec67 = "67";
	var dec68 = "68";
	var dec69 = "69";
	var dec70 = "70";
	var dec71 = "71";
	var dec72 = "72";
	var dec73 = "73";
	var dec74 = "74";
	var dec75 = "75";
	var dec76 = "76";
	var dec77 = "77";
	var dec78 = "78";
	var dec79 = "79";
	var dec80 = "80";
	var dec81 = "81";
	var dec82 = "82";
	var dec83 = "83";
	var dec84 = "84";
	var dec85 = "85";
	var dec86 = "86";
	var dec87 = "87";
	var dec88 = "88";
	var dec89 = "89";
	var dec90 = "90";
	var dec91 = "91";
	var dec92 = "92";
	var dec93 = "93";
	var dec94 = "94";
	var dec95 = "95";
	var dec96 = "96";
	var dec97 = "97";
	var dec98 = "98";
	var dec99 = "99";
	var dec100 = "100";
	var dec101 = "101";
	var dec102 = "102";
	var dec103 = "103";
	var dec104 = "104";
	var dec105 = "105";
	var dec106 = "106";
	var dec107 = "107";
	var dec108 = "108";
	var dec109 = "109";
	var dec110 = "110";
	var dec111 = "111";
	var dec112 = "112";
	var dec113 = "113";
	var dec114 = "114";
	var dec115 = "115";
	var dec116 = "116";
	var dec117 = "117";
	var dec118 = "118";
	var dec119 = "119";
	var dec120 = "120";
	var dec121 = "121";
	var dec122 = "122";
	var dec123 = "123";
	var dec124 = "124";
	var dec125 = "125";
	var dec126 = "126";
	var dec127 = "127";
	var dec128 = "128";
	var dec129 = "129";
	var dec130 = "130";
	var dec131 = "131";
	var dec132 = "132";
	var dec133 = "133";
	var dec134 = "134";
	var dec135 = "135";
	var dec136 = "136";
	var dec137 = "137";
	var dec138 = "138";
	var dec139 = "139";
	var dec140 = "140";
	var dec141 = "141";
	var dec142 = "142";
	var dec143 = "143";
	var dec144 = "144";
	var dec145 = "145";
	var dec146 = "146";
	var dec147 = "147";
	var dec148 = "148";
	var dec149 = "149";
	var dec150 = "150";
	var dec151 = "151";
	var dec152 = "152";
	var dec153 = "153";
	var dec154 = "154";
	var dec155 = "155";
	var dec156 = "156";
	var dec157 = "157";
	var dec158 = "158";
	var dec159 = "159";
	var dec160 = "160";
	var dec161 = "161";
	var dec162 = "162";
	var dec163 = "163";
	var dec164 = "164";
	var dec165 = "165";
	var dec166 = "166";
	var dec167 = "167";
	var dec168 = "168";
	var dec169 = "169";
	var dec170 = "170";
	var dec171 = "171";
	var dec172 = "172";
	var dec173 = "173";
	var dec174 = "174";
	var dec175 = "175";
	var dec176 = "176";
	var dec177 = "177";
	var dec178 = "178";
	var dec179 = "179";
	var dec180 = "180";
	var dec181 = "181";
	var dec182 = "182";
	var dec183 = "183";
	var dec184 = "184";
	var dec185 = "185";
	var dec186 = "186";
	var dec187 = "187";
	var dec188 = "188";
	var dec189 = "189";
	var dec190 = "190";
	var dec191 = "191";
	var dec192 = "192";
	var dec193 = "193";
	var dec194 = "194";
	var dec195 = "195";
	var dec196 = "196";
	var dec197 = "197";
	var dec198 = "198";
	var dec199 = "199";
	var dec200 = "200";
	var dec201 = "201";
	var dec202 = "202";
	var dec203 = "203";
	var dec204 = "204";
	var dec205 = "205";
	var dec206 = "206";
	var dec207 = "207";
	var dec208 = "208";
	var dec209 = "209";
	var dec210 = "210";
	var dec211 = "211";
	var dec212 = "212";
	var dec213 = "213";
	var dec214 = "214";
	var dec215 = "215";
	var dec216 = "216";
	var dec217 = "217";
	var dec218 = "218";
	var dec219 = "219";
	var dec220 = "220";
	var dec221 = "221";
	var dec222 = "222";
	var dec223 = "223";
	var dec224 = "224";
	var dec225 = "225";
	var dec226 = "226";
	var dec227 = "227";
	var dec228 = "228";
	var dec229 = "229";
	var dec230 = "230";
	var dec231 = "231";
	var dec232 = "232";
	var dec233 = "233";
	var dec234 = "234";
	var dec235 = "235";
	var dec236 = "236";
	var dec237 = "237";
	var dec238 = "238";
	var dec239 = "239";
	var dec240 = "240";
	var dec241 = "241";
	var dec242 = "242";
	var dec243 = "243";
	var dec244 = "244";
	var dec245 = "245";
	var dec246 = "246";
	var dec247 = "247";
	var dec248 = "248";
	var dec249 = "249";
	var dec250 = "250";
	var dec251 = "251";
	var dec252 = "252";
	var dec253 = "253";
	var dec254 = "254";
	var dec255 = "255";
	if(dec0 == m){
		q = "00"
	};
	if(dec1 == m){
		q = "01"
	};
	if(dec2 == m){
		q = "02"
	};
	if(dec3 == m){
		q = "03"
	};
	if(dec4 == m){
		q = "04"
	};
	if(dec5 == m){
		q = "05"
	};
	if(dec6 == m){
		q = "06"
	};
	if(dec7 == m){
		q = "07"
	};
	if(dec8 == m){
		q = "08"
	};
	if(dec9 == m){
		q = "09"
	}
	if(dec10 == m){
		q = "0a"
	};
	if(dec11 == m){
		q = "0b"
	};
	if(dec12 == m){
		q = "0c"
	};
	if(dec13 == m){
		q = "0d"
	};
	if(dec14 == m){
		q = "0e"
	};
	if(dec15 == m){
		q = "0f"
	};
	if(dec16 == m){
		q = "10"
	};
	if(dec17 == m){
		q = "11"
	};
	if(dec18 == m){
		q = "12"
	};
	if(dec19 == m){
		q = "13"
	}
	if(dec20 == m){
		q = "14"
	};
	if(dec21 == m){
		q = "15"
	};
	if(dec22 == m){
		q = "16"
	};
	if(dec23 == m){
		q = "17"
	};
	if(dec24 == m){
		q = "18"
	};
	if(dec25 == m){
		q = "19"
	};
	if(dec26 == m){
		q = "1a"
	};
	if(dec27 == m){
		q = "1b"
	};
	if(dec28 == m){
		q = "1c"
	};
	if(dec29 == m){
		q = "1d"
	}
	if(dec30 == m){
		q = "1e"
	};
	if(dec31 == m){
		q = "1f"
	};
	if(dec32 == m){
		q = "20"
	};
	if(dec33 == m){
		q = "21"
	};
	if(dec34 == m){
		q = "22"
	};
	if(dec35 == m){
		q = "23"
	};
	if(dec36 == m){
		q = "24"
	};
	if(dec37 == m){
		q = "25"
	};
	if(dec38 == m){
		q = "26"
	};
	if(dec39 == m){
		q = "27"
	}
	if(dec40 == m){
		q = "28"
	};
	if(dec41 == m){
		q = "29"
	};
	if(dec42 == m){
		q = "2a"
	};
	if(dec43 == m){
		q = "2b"
	};
	if(dec44 == m){
		q = "2c"
	};
	if(dec45 == m){
		q = "2d"
	};
	if(dec46 == m){
		q = "2e"
	};
	if(dec47 == m){
		q = "2f"
	};
	if(dec48 == m){
		q = "30"
	};
	if(dec49 == m){
		q = "31"
	}
	if(dec50 == m){
		q = "32"
	};
	if(dec51 == m){
		q = "33"
	};
	if(dec52 == m){
		q = "34"
	};
	if(dec53 == m){
		q = "35"
	};
	if(dec54 == m){
		q = "36"
	};
	if(dec55 == m){
		q = "37"
	};
	if(dec56 == m){
		q = "38"
	};
	if(dec57 == m){
		q = "39"
	};
	if(dec58 == m){
		q = "3a"
	};
	if(dec59 == m){
		q = "3b"
	}
	if(dec60 == m){
		q = "3c"
	};
	if(dec61 == m){
		q = "3d"
	};
	if(dec62 == m){
		q = "3e"
	};
	if(dec63 == m){
		q = "3f"
	};
	if(dec64 == m){
		q = "40"
	};
	if(dec65 == m){
		q = "41"
	};
	if(dec66 == m){
		q = "42"
	};
	if(dec67 == m){
		q = "43"
	};
	if(dec68 == m){
		q = "44"
	};
	if(dec69 == m){
		q = "45"
	}
	if(dec70 == m){
		q = "46"
	};
	if(dec71 == m){
		q = "47"
	};
	if(dec72 == m){
		q = "48"
	};
	if(dec73 == m){
		q = "49"
	};
	if(dec74 == m){
		q = "4a"
	};
	if(dec75 == m){
		q = "4b"
	};
	if(dec76 == m){
		q = "4c"
	};
	if(dec77 == m){
		q = "4d"
	};
	if(dec78 == m){
		q = "4e"
	};
	if(dec79 == m){
		q = "4f"
	}
	if(dec80 == m){
		q = "50"
	};
	if(dec81 == m){
		q = "51"
	};
	if(dec82 == m){
		q = "52"
	};
	if(dec83 == m){
		q = "53"
	};
	if(dec84 == m){
		q = "54"
	};
	if(dec85 == m){
		q = "55"
	};
	if(dec86 == m){
		q = "56"
	};
	if(dec87 == m){
		q = "57"
	};
	if(dec88 == m){
		q = "58"
	};
	if(dec89 == m){
		q = "59"
	}
	if(dec90 == m){
		q = "5a"
	};
	if(dec91 == m){
		q = "5b"
	};
	if(dec92 == m){
		q = "5c"
	};
	if(dec93 == m){
		q = "5d"
	};
	if(dec94 == m){
		q = "5e"
	};
	if(dec95 == m){
		q = "5f"
	};
	if(dec96 == m){
		q = "60"
	};
	if(dec97 == m){
		q = "61"
	};
	if(dec98 == m){
		q = "62"
	};
	if(dec99 == m){
		q = "63"
	}
	if(dec100 == m){
		q = "64"
	};
	if(dec101 == m){
		q = "65"
	};
	if(dec102 == m){
		q = "66"
	};
	if(dec103 == m){
		q = "67"
	};
	if(dec104 == m){
		q = "68"
	};
	if(dec105 == m){
		q = "69"
	};
	if(dec106 == m){
		q = "6a"
	};
	if(dec107 == m){
		q = "6b"
	};
	if(dec108 == m){
		q = "6c"
	};
	if(dec109 == m){
		q = "6d"
	}
	if(dec110 == m){
		q = "6e"
	};
	if(dec111 == m){
		q = "6f"
	};
	if(dec112 == m){
		q = "70"
	};
	if(dec113 == m){
		q = "71"
	};
	if(dec114 == m){
		q = "72"
	};
	if(dec115 == m){
		q = "73"
	};
	if(dec116 == m){
		q = "74"
	};
	if(dec117 == m){
		q = "75"
	};
	if(dec118 == m){
		q = "76"
	};
	if(dec119 == m){
		q = "77"
	}
	if(dec120 == m){
		q = "78"
	};
	if(dec121 == m){
		q = "79"
	};
	if(dec122 == m){
		q = "7a"
	};
	if(dec123 == m){
		q = "7b"
	};
	if(dec124 == m){
		q = "7c"
	};
	if(dec125 == m){
		q = "7d"
	};
	if(dec126 == m){
		q = "7e"
	};
	if(dec127 == m){
		q = "7f"
	};
	if(dec128 == m){
		q = "80"
	};
	if(dec129 == m){
		q = "81"
	}
	if(dec130 == m){
		q = "82"
	};
	if(dec131 == m){
		q = "83"
	};
	if(dec132 == m){
		q = "84"
	};
	if(dec133 == m){
		q = "85"
	};
	if(dec134 == m){
		q = "86"
	};
	if(dec135 == m){
		q = "87"
	};
	if(dec136 == m){
		q = "88"
	};
	if(dec137 == m){
		q = "89"
	};
	if(dec138 == m){
		q = "8a"
	};
	if(dec139 == m){
		q = "8b"
	}
	if(dec140 == m){
		q = "8c"
	};
	if(dec141 == m){
		q = "8d"
	};
	if(dec142 == m){
		q = "8e"
	};
	if(dec143 == m){
		q = "8f"
	};
	if(dec144 == m){
		q = "90"
	};
	if(dec145 == m){
		q = "91"
	};
	if(dec146 == m){
		q = "92"
	};
	if(dec147 == m){
		q = "93"
	};
	if(dec148 == m){
		q = "94"
	};
	if(dec149 == m){
		q = "95"
	}
	if(dec150 == m){
		q = "96"
	};
	if(dec151 == m){
		q = "97"
	};
	if(dec152 == m){
		q = "98"
	};
	if(dec153 == m){
		q = "99"
	};
	if(dec154 == m){
		q = "9a"
	};
	if(dec155 == m){
		q = "9b"
	};
	if(dec156 == m){
		q = "9c"
	};
	if(dec157 == m){
		q = "9d"
	};
	if(dec158 == m){
		q = "9e"
	};
	if(dec159 == m){
		q = "9f"
	}
	if(dec160 == m){
		q = "a0"
	};
	if(dec161 == m){
		q = "a1"
	};
	if(dec162 == m){
		q = "a2"
	};
	if(dec163 == m){
		q = "a3"
	};
	if(dec164 == m){
		q = "a4"
	};
	if(dec165 == m){
		q = "a5"
	};
	if(dec166 == m){
		q = "a6"
	};
	if(dec167 == m){
		q = "a7"
	};
	if(dec168 == m){
		q = "a8"
	};
	if(dec169 == m){
		q = "a9"
	}
	if(dec170 == m){
		q = "aa"
	};
	if(dec171 == m){
		q = "ab"
	};
	if(dec172 == m){
		q = "ac"
	};
	if(dec173 == m){
		q = "ad"
	};
	if(dec174 == m){
		q = "ae"
	};
	if(dec175 == m){
		q = "af"
	};
	if(dec176 == m){
		q = "b0"
	};
	if(dec177 == m){
		q = "b1"
	};
	if(dec178 == m){
		q = "b2"
	};
	if(dec179 == m){
		q = "b3"
	}
	if(dec180 == m){
		q = "b4"
	};
	if(dec181 == m){
		q = "b5"
	};
	if(dec182 == m){
		q = "b6"
	};
	if(dec183 == m){
		q = "b7"
	};
	if(dec184 == m){
		q = "b8"
	};
	if(dec185 == m){
		q = "b9"
	};
	if(dec186 == m){
		q = "ba"
	};
	if(dec187 == m){
		q = "bb"
	};
	if(dec188 == m){
		q = "bc"
	};
	if(dec189 == m){
		q = "bd"
	}
	if(dec190 == m){
		q = "be"
	};
	if(dec191 == m){
		q = "bf"
	};
	if(dec192 == m){
		q = "c0"
	};
	if(dec193 == m){
		q = "c1"
	};
	if(dec194 == m){
		q = "c2"
	};
	if(dec195 == m){
		q = "c3"
	};
	if(dec196 == m){
		q = "c4"
	};
	if(dec197 == m){
		q = "c5"
	};
	if(dec198 == m){
		q = "c6"
	};
	if(dec199 == m){
		q = "c7"
	}
	if(dec200 == m){
		q = "c8"
	};
	if(dec201 == m){
		q = "c9"
	};
	if(dec202 == m){
		q = "ca"
	};
	if(dec203 == m){
		q = "cb"
	};
	if(dec204 == m){
		q = "cc"
	};
	if(dec205 == m){
		q = "cd"
	};
	if(dec206 == m){
		q = "ce"
	};
	if(dec207 == m){
		q = "cf"
	};
	if(dec208 == m){
		q = "d0"
	};
	if(dec209 == m){
		q = "d1"
	}
	if(dec210 == m){
		q = "d2"
	};
	if(dec211 == m){
		q = "d3"
	};
	if(dec212 == m){
		q = "d4"
	};
	if(dec213 == m){
		q = "d5"
	};
	if(dec214 == m){
		q = "d6"
	};
	if(dec215 == m){
		q = "d7"
	};
	if(dec216 == m){
		q = "d8"
	};
	if(dec217 == m){
		q = "d9"
	};
	if(dec218 == m){
		q = "da"
	};
	if(dec219 == m){
		q = "db"
	}
	if(dec220 == m){
		q = "dc"
	};
	if(dec221 == m){
		q = "dd"
	};
	if(dec222 == m){
		q = "de"
	};
	if(dec223 == m){
		q = "df"
	};
	if(dec224 == m){
		q = "e0"
	};
	if(dec225 == m){
		q = "e1"
	};
	if(dec226 == m){
		q = "e2"
	};
	if(dec227 == m){
		q = "e3"
	};
	if(dec228 == m){
		q = "e4"
	};
	if(dec229 == m){
		q = "e5"
	}
	if(dec230 == m){
		q = "e6"
	};
	if(dec231 == m){
		q = "e7"
	};
	if(dec232 == m){
		q = "e8"
	};
	if(dec233 == m){
		q = "e9"
	};
	if(dec234 == m){
		q = "ea"
	};
	if(dec235 == m){
		q = "eb"
	};
	if(dec236 == m){
		q = "ec"
	};
	if(dec237 == m){
		q = "ed"
	};
	if(dec238 == m){
		q = "ee"
	};
	if(dec239 == m){
		q = "ef"
	}
	if(dec240 == m){
		q = "f0"
	};
	if(dec241 == m){
		q = "f1"
	};
	if(dec242 == m){
		q = "f2"
	};
	if(dec243 == m){
		q = "f3"
	};
	if(dec244 == m){
		q = "f4"
	};
	if(dec245 == m){
		q = "f5"
	};
	if(dec246 == m){
		q = "f6"
	};
	if(dec247 == m){
		q = "f7"
	};
	if(dec248 == m){
		q = "f8"
	};
	if(dec249 == m){
		q = "f9"
	}
	if(dec250 == m){
		q = "fa"
	};
	if(dec251 == m){
		q = "fb"
	};
	if(dec252 == m){
		q = "fc"
	};
	if(dec253 == m){
		q = "fd"
	};
	if(dec254 == m){
		q = "fe"
	};
	if(dec255 == m){
		q = "ff"
	};
	
	if(dec0 == n){
		r = "00"
	};
	if(dec1 == n){
		r = "01"
	};
	if(dec2 == n){
		r = "02"
	};
	if(dec3 == n){
		r = "03"
	};
	if(dec4 == n){
		r = "04"
	};
	if(dec5 == n){
		r = "05"
	};
	if(dec6 == n){
		r = "06"
	};
	if(dec7 == n){
		r = "07"
	};
	if(dec8 == n){
		r = "08"
	};
	if(dec9 == n){
		r = "09"
	}
	if(dec10 == n){
		r = "0a"
	};
	if(dec11 == n){
		r = "0b"
	};
	if(dec12 == n){
		r = "0c"
	};
	if(dec13 == n){
		r = "0d"
	};
	if(dec14 == n){
		r = "0e"
	};
	if(dec15 == n){
		r = "0f"
	};
	if(dec16 == n){
		r = "10"
	};
	if(dec17 == n){
		r = "11"
	};
	if(dec18 == n){
		r = "12"
	};
	if(dec19 == n){
		r = "13"
	}
	if(dec20 == n){
		r = "14"
	};
	if(dec21 == n){
		r = "15"
	};
	if(dec22 == n){
		r = "16"
	};
	if(dec23 == n){
		r = "17"
	};
	if(dec24 == n){
		r = "18"
	};
	if(dec25 == n){
		r = "19"
	};
	if(dec26 == n){
		r = "1a"
	};
	if(dec27 == n){
		r = "1b"
	};
	if(dec28 == n){
		r = "1c"
	};
	if(dec29 == n){
		r = "1d"
	}
	if(dec30 == n){
		r = "1e"
	};
	if(dec31 == n){
		r = "1f"
	};
	if(dec32 == n){
		r = "20"
	};
	if(dec33 == n){
		r = "21"
	};
	if(dec34 == n){
		r = "22"
	};
	if(dec35 == n){
		r = "23"
	};
	if(dec36 == n){
		r = "24"
	};
	if(dec37 == n){
		r = "25"
	};
	if(dec38 == n){
		r = "26"
	};
	if(dec39 == n){
		r = "27"
	}
	if(dec40 == n){
		r = "28"
	};
	if(dec41 == n){
		r = "29"
	};
	if(dec42 == n){
		r = "2a"
	};
	if(dec43 == n){
		r = "2b"
	};
	if(dec44 == n){
		r = "2c"
	};
	if(dec45 == n){
		r = "2d"
	};
	if(dec46 == n){
		r = "2e"
	};
	if(dec47 == n){
		r = "2f"
	};
	if(dec48 == n){
		r = "30"
	};
	if(dec49 == n){
		r = "31"
	}
	if(dec50 == n){
		r = "32"
	};
	if(dec51 == n){
		r = "33"
	};
	if(dec52 == n){
		r = "34"
	};
	if(dec53 == n){
		r = "35"
	};
	if(dec54 == n){
		r = "36"
	};
	if(dec55 == n){
		r = "37"
	};
	if(dec56 == n){
		r = "38"
	};
	if(dec57 == n){
		r = "39"
	};
	if(dec58 == n){
		r = "3a"
	};
	if(dec59 == n){
		r = "3b"
	}
	if(dec60 == n){
		r = "3c"
	};
	if(dec61 == n){
		r = "3d"
	};
	if(dec62 == n){
		r = "3e"
	};
	if(dec63 == n){
		r = "3f"
	};
	if(dec64 == n){
		r = "40"
	};
	if(dec65 == n){
		r = "41"
	};
	if(dec66 == n){
		r = "42"
	};
	if(dec67 == n){
		r = "43"
	};
	if(dec68 == n){
		r = "44"
	};
	if(dec69 == n){
		r = "45"
	}
	if(dec70 == n){
		r = "46"
	};
	if(dec71 == n){
		r = "47"
	};
	if(dec72 == n){
		r = "48"
	};
	if(dec73 == n){
		r = "49"
	};
	if(dec74 == n){
		r = "4a"
	};
	if(dec75 == n){
		r = "4b"
	};
	if(dec76 == n){
		r = "4c"
	};
	if(dec77 == n){
		r = "4d"
	};
	if(dec78 == n){
		r = "4e"
	};
	if(dec79 == n){
		r = "4f"
	}
	if(dec80 == n){
		r = "50"
	};
	if(dec81 == n){
		r = "51"
	};
	if(dec82 == n){
		r = "52"
	};
	if(dec83 == n){
		r = "53"
	};
	if(dec84 == n){
		r = "54"
	};
	if(dec85 == n){
		r = "55"
	};
	if(dec86 == n){
		r = "56"
	};
	if(dec87 == n){
		r = "57"
	};
	if(dec88 == n){
		r = "58"
	};
	if(dec89 == n){
		r = "59"
	}
	if(dec90 == n){
		r = "5a"
	};
	if(dec91 == n){
		r = "5b"
	};
	if(dec92 == n){
		r = "5c"
	};
	if(dec93 == n){
		r = "5d"
	};
	if(dec94 == n){
		r = "5e"
	};
	if(dec95 == n){
		r = "5f"
	};
	if(dec96 == n){
		r = "60"
	};
	if(dec97 == n){
		r = "61"
	};
	if(dec98 == n){
		r = "62"
	};
	if(dec99 == n){
		r = "63"
	}
	if(dec100 == n){
		r = "64"
	};
	if(dec101 == n){
		r = "65"
	};
	if(dec102 == n){
		r = "66"
	};
	if(dec103 == n){
		r = "67"
	};
	if(dec104 == n){
		r = "68"
	};
	if(dec105 == n){
		r = "69"
	};
	if(dec106 == n){
		r = "6a"
	};
	if(dec107 == n){
		r = "6b"
	};
	if(dec108 == n){
		r = "6c"
	};
	if(dec109 == n){
		r = "6d"
	}
	if(dec110 == n){
		r = "6e"
	};
	if(dec111 == n){
		r = "6f"
	};
	if(dec112 == n){
		r = "70"
	};
	if(dec113 == n){
		r = "71"
	};
	if(dec114 == n){
		r = "72"
	};
	if(dec115 == n){
		r = "73"
	};
	if(dec116 == n){
		r = "74"
	};
	if(dec117 == n){
		r = "75"
	};
	if(dec118 == n){
		r = "76"
	};
	if(dec119 == n){
		r = "77"
	}
	if(dec120 == n){
		r = "78"
	};
	if(dec121 == n){
		r = "79"
	};
	if(dec122 == n){
		r = "7a"
	};
	if(dec123 == n){
		r = "7b"
	};
	if(dec124 == n){
		r = "7c"
	};
	if(dec125 == n){
		r = "7d"
	};
	if(dec126 == n){
		r = "7e"
	};
	if(dec127 == n){
		r = "7f"
	};
	if(dec128 == n){
		r = "80"
	};
	if(dec129 == n){
		r = "81"
	}
	if(dec130 == n){
		r = "82"
	};
	if(dec131 == n){
		r = "83"
	};
	if(dec132 == n){
		r = "84"
	};
	if(dec133 == n){
		r = "85"
	};
	if(dec134 == n){
		r = "86"
	};
	if(dec135 == n){
		r = "87"
	};
	if(dec136 == n){
		r = "88"
	};
	if(dec137 == n){
		r = "89"
	};
	if(dec138 == n){
		r = "8a"
	};
	if(dec139 == n){
		r = "8b"
	}
	if(dec140 == n){
		r = "8c"
	};
	if(dec141 == n){
		r = "8d"
	};
	if(dec142 == n){
		r = "8e"
	};
	if(dec143 == n){
		r = "8f"
	};
	if(dec144 == n){
		r = "90"
	};
	if(dec145 == n){
		r = "91"
	};
	if(dec146 == n){
		r = "92"
	};
	if(dec147 == n){
		r = "93"
	};
	if(dec148 == n){
		r = "94"
	};
	if(dec149 == n){
		r = "95"
	}
	if(dec150 == n){
		r = "96"
	};
	if(dec151 == n){
		r = "97"
	};
	if(dec152 == n){
		r = "98"
	};
	if(dec153 == n){
		r = "99"
	};
	if(dec154 == n){
		r = "9a"
	};
	if(dec155 == n){
		r = "9b"
	};
	if(dec156 == n){
		r = "9c"
	};
	if(dec157 == n){
		r = "9d"
	};
	if(dec158 == n){
		r = "9e"
	};
	if(dec159 == n){
		r = "9f"
	}
	if(dec160 == n){
		r = "a0"
	};
	if(dec161 == n){
		r = "a1"
	};
	if(dec162 == n){
		r = "a2"
	};
	if(dec163 == n){
		r = "a3"
	};
	if(dec164 == n){
		r = "a4"
	};
	if(dec165 == n){
		r = "a5"
	};
	if(dec166 == n){
		r = "a6"
	};
	if(dec167 == n){
		r = "a7"
	};
	if(dec168 == n){
		r = "a8"
	};
	if(dec169 == n){
		r = "a9"
	}
	if(dec170 == n){
		r = "aa"
	};
	if(dec171 == n){
		r = "ab"
	};
	if(dec172 == n){
		r = "ac"
	};
	if(dec173 == n){
		r = "ad"
	};
	if(dec174 == n){
		r = "ae"
	};
	if(dec175 == n){
		r = "af"
	};
	if(dec176 == n){
		r = "b0"
	};
	if(dec177 == n){
		r = "b1"
	};
	if(dec178 == n){
		r = "b2"
	};
	if(dec179 == n){
		r = "b3"
	}
	if(dec180 == n){
		r = "b4"
	};
	if(dec181 == n){
		r = "b5"
	};
	if(dec182 == n){
		r = "b6"
	};
	if(dec183 == n){
		r = "b7"
	};
	if(dec184 == n){
		r = "b8"
	};
	if(dec185 == n){
		r = "b9"
	};
	if(dec186 == n){
		r = "ba"
	};
	if(dec187 == n){
		r = "bb"
	};
	if(dec188 == n){
		r = "bc"
	};
	if(dec189 == n){
		r = "bd"
	}
	if(dec190 == n){
		r = "be"
	};
	if(dec191 == n){
		r = "bf"
	};
	if(dec192 == n){
		r = "c0"
	};
	if(dec193 == n){
		r = "c1"
	};
	if(dec194 == n){
		r = "c2"
	};
	if(dec195 == n){
		r = "c3"
	};
	if(dec196 == n){
		r = "c4"
	};
	if(dec197 == n){
		r = "c5"
	};
	if(dec198 == n){
		r = "c6"
	};
	if(dec199 == n){
		r = "c7"
	}
	if(dec200 == n){
		r = "c8"
	};
	if(dec201 == n){
		r = "c9"
	};
	if(dec202 == n){
		r = "ca"
	};
	if(dec203 == n){
		r = "cb"
	};
	if(dec204 == n){
		r = "cc"
	};
	if(dec205 == n){
		r = "cd"
	};
	if(dec206 == n){
		r = "ce"
	};
	if(dec207 == n){
		r = "cf"
	};
	if(dec208 == n){
		r = "d0"
	};
	if(dec209 == n){
		r = "d1"
	}
	if(dec210 == n){
		r = "d2"
	};
	if(dec211 == n){
		r = "d3"
	};
	if(dec212 == n){
		r = "d4"
	};
	if(dec213 == n){
		r = "d5"
	};
	if(dec214 == n){
		r = "d6"
	};
	if(dec215 == n){
		r = "d7"
	};
	if(dec216 == n){
		r = "d8"
	};
	if(dec217 == n){
		r = "d9"
	};
	if(dec218 == n){
		r = "da"
	};
	if(dec219 == n){
		r = "db"
	}
	if(dec220 == n){
		r = "dc"
	};
	if(dec221 == n){
		r = "dd"
	};
	if(dec222 == n){
		r = "de"
	};
	if(dec223 == n){
		r = "df"
	};
	if(dec224 == n){
		r = "e0"
	};
	if(dec225 == n){
		r = "e1"
	};
	if(dec226 == n){
		r = "e2"
	};
	if(dec227 == n){
		r = "e3"
	};
	if(dec228 == n){
		r = "e4"
	};
	if(dec229 == n){
		r = "e5"
	}
	if(dec230 == n){
		r = "e6"
	};
	if(dec231 == n){
		r = "e7"
	};
	if(dec232 == n){
		r = "e8"
	};
	if(dec233 == n){
		r = "e9"
	};
	if(dec234 == n){
		r = "ea"
	};
	if(dec235 == n){
		r = "eb"
	};
	if(dec236 == n){
		r = "ec"
	};
	if(dec237 == n){
		r = "ed"
	};
	if(dec238 == n){
		r = "ee"
	};
	if(dec239 == n){
		r = "ef"
	}
	if(dec240 == n){
		r = "f0"
	};
	if(dec241 == n){
		r = "f1"
	};
	if(dec242 == n){
		r = "f2"
	};
	if(dec243 == n){
		r = "f3"
	};
	if(dec244 == n){
		r = "f4"
	};
	if(dec245 == n){
		r = "f5"
	};
	if(dec246 == n){
		r = "f6"
	};
	if(dec247 == n){
		r = "f7"
	};
	if(dec248 == n){
		r = "f8"
	};
	if(dec249 == n){
		r = "f9"
	}
	if(dec250 == n){
		r = "fa"
	};
	if(dec251 == n){
		r = "fb"
	};
	if(dec252 == n){
		r = "fc"
	};
	if(dec253 == n){
		r = "fd"
	};
	if(dec254 == n){
		r = "fe"
	};
	if(dec255 == n){
		r = "ff"
	};
	
	
	if(dec0 == o){
		s = "00"
	};
	if(dec1 == o){
		s = "01"
	};
	if(dec2 == o){
		s = "02"
	};
	if(dec3 == o){
		s = "03"
	};
	if(dec4 == o){
		s = "04"
	};
	if(dec5 == o){
		s = "05"
	};
	if(dec6 == o){
		s = "06"
	};
	if(dec7 == o){
		s = "07"
	};
	if(dec8 == o){
		s = "08"
	};
	if(dec9 == o){
		s = "09"
	}
	if(dec10 == o){
		s = "0a"
	};
	if(dec11 == o){
		s = "0b"
	};
	if(dec12 == o){
		s = "0c"
	};
	if(dec13 == o){
		s = "0d"
	};
	if(dec14 == o){
		s = "0e"
	};
	if(dec15 == o){
		s = "0f"
	};
	if(dec16 == o){
		s = "10"
	};
	if(dec17 == o){
		s = "11"
	};
	if(dec18 == o){
		s = "12"
	};
	if(dec19 == o){
		s = "13"
	}
	if(dec20 == o){
		s = "14"
	};
	if(dec21 == o){
		s = "15"
	};
	if(dec22 == o){
		s = "16"
	};
	if(dec23 == o){
		s = "17"
	};
	if(dec24 == o){
		s = "18"
	};
	if(dec25 == o){
		s = "19"
	};
	if(dec26 == o){
		s = "1a"
	};
	if(dec27 == o){
		s = "1b"
	};
	if(dec28 == o){
		s = "1c"
	};
	if(dec29 == o){
		s = "1d"
	}
	if(dec30 == o){
		s = "1e"
	};
	if(dec31 == o){
		s = "1f"
	};
	if(dec32 == o){
		s = "20"
	};
	if(dec33 == o){
		s = "21"
	};
	if(dec34 == o){
		s = "22"
	};
	if(dec35 == o){
		s = "23"
	};
	if(dec36 == o){
		s = "24"
	};
	if(dec37 == o){
		s = "25"
	};
	if(dec38 == o){
		s = "26"
	};
	if(dec39 == o){
		s = "27"
	}
	if(dec40 == o){
		s = "28"
	};
	if(dec41 == o){
		s = "29"
	};
	if(dec42 == o){
		s = "2a"
	};
	if(dec43 == o){
		s = "2b"
	};
	if(dec44 == o){
		s = "2c"
	};
	if(dec45 == o){
		s = "2d"
	};
	if(dec46 == o){
		s = "2e"
	};
	if(dec47 == o){
		s = "2f"
	};
	if(dec48 == o){
		s = "30"
	};
	if(dec49 == o){
		s = "31"
	}
	if(dec50 == o){
		s = "32"
	};
	if(dec51 == o){
		s = "33"
	};
	if(dec52 == o){
		s = "34"
	};
	if(dec53 == o){
		s = "35"
	};
	if(dec54 == o){
		s = "36"
	};
	if(dec55 == o){
		s = "37"
	};
	if(dec56 == o){
		s = "38"
	};
	if(dec57 == o){
		s = "39"
	};
	if(dec58 == o){
		s = "3a"
	};
	if(dec59 == o){
		s = "3b"
	}
	if(dec60 == o){
		s = "3c"
	};
	if(dec61 == o){
		s = "3d"
	};
	if(dec62 == o){
		s = "3e"
	};
	if(dec63 == o){
		s = "3f"
	};
	if(dec64 == o){
		s = "40"
	};
	if(dec65 == o){
		s = "41"
	};
	if(dec66 == o){
		s = "42"
	};
	if(dec67 == o){
		s = "43"
	};
	if(dec68 == o){
		s = "44"
	};
	if(dec69 == o){
		s = "45"
	}
	if(dec70 == o){
		s = "46"
	};
	if(dec71 == o){
		s = "47"
	};
	if(dec72 == o){
		s = "48"
	};
	if(dec73 == o){
		s = "49"
	};
	if(dec74 == o){
		s = "4a"
	};
	if(dec75 == o){
		s = "4b"
	};
	if(dec76 == o){
		s = "4c"
	};
	if(dec77 == o){
		s = "4d"
	};
	if(dec78 == o){
		s = "4e"
	};
	if(dec79 == o){
		s = "4f"
	}
	if(dec80 == o){
		s = "50"
	};
	if(dec81 == o){
		s = "51"
	};
	if(dec82 == o){
		s = "52"
	};
	if(dec83 == o){
		s = "53"
	};
	if(dec84 == o){
		s = "54"
	};
	if(dec85 == o){
		s = "55"
	};
	if(dec86 == o){
		s = "56"
	};
	if(dec87 == o){
		s = "57"
	};
	if(dec88 == o){
		s = "58"
	};
	if(dec89 == o){
		s = "59"
	}
	if(dec90 == o){
		s = "5a"
	};
	if(dec91 == o){
		s = "5b"
	};
	if(dec92 == o){
		s = "5c"
	};
	if(dec93 == o){
		s = "5d"
	};
	if(dec94 == o){
		s = "5e"
	};
	if(dec95 == o){
		s = "5f"
	};
	if(dec96 == o){
		s = "60"
	};
	if(dec97 == o){
		s = "61"
	};
	if(dec98 == o){
		s = "62"
	};
	if(dec99 == o){
		s = "63"
	}
	if(dec100 == o){
		s = "64"
	};
	if(dec101 == o){
		s = "65"
	};
	if(dec102 == o){
		s = "66"
	};
	if(dec103 == o){
		s = "67"
	};
	if(dec104 == o){
		s = "68"
	};
	if(dec105 == o){
		s = "69"
	};
	if(dec106 == o){
		s = "6a"
	};
	if(dec107 == o){
		s = "6b"
	};
	if(dec108 == o){
		s = "6c"
	};
	if(dec109 == o){
		s = "6d"
	}
	if(dec110 == o){
		s = "6e"
	};
	if(dec111 == o){
		s = "6f"
	};
	if(dec112 == o){
		s = "70"
	};
	if(dec113 == o){
		s = "71"
	};
	if(dec114 == o){
		s = "72"
	};
	if(dec115 == o){
		s = "73"
	};
	if(dec116 == o){
		s = "74"
	};
	if(dec117 == o){
		s = "75"
	};
	if(dec118 == o){
		s = "76"
	};
	if(dec119 == o){
		s = "77"
	}
	if(dec120 == o){
		s = "78"
	};
	if(dec121 == o){
		s = "79"
	};
	if(dec122 == o){
		s = "7a"
	};
	if(dec123 == o){
		s = "7b"
	};
	if(dec124 == o){
		s = "7c"
	};
	if(dec125 == o){
		s = "7d"
	};
	if(dec126 == o){
		s = "7e"
	};
	if(dec127 == o){
		s = "7f"
	};
	if(dec128 == o){
		s = "80"
	};
	if(dec129 == o){
		s = "81"
	}
	if(dec130 == o){
		s = "82"
	};
	if(dec131 == o){
		s = "83"
	};
	if(dec132 == o){
		s = "84"
	};
	if(dec133 == o){
		s = "85"
	};
	if(dec134 == o){
		s = "86"
	};
	if(dec135 == o){
		s = "87"
	};
	if(dec136 == o){
		s = "88"
	};
	if(dec137 == o){
		s = "89"
	};
	if(dec138 == o){
		s = "8a"
	};
	if(dec139 == o){
		s = "8b"
	}
	if(dec140 == o){
		s = "8c"
	};
	if(dec141 == o){
		s = "8d"
	};
	if(dec142 == o){
		s = "8e"
	};
	if(dec143 == o){
		s = "8f"
	};
	if(dec144 == o){
		s = "90"
	};
	if(dec145 == o){
		s = "91"
	};
	if(dec146 == o){
		s = "92"
	};
	if(dec147 == o){
		s = "93"
	};
	if(dec148 == o){
		s = "94"
	};
	if(dec149 == o){
		s = "95"
	}
	if(dec150 == o){
		s = "96"
	};
	if(dec151 == o){
		s = "97"
	};
	if(dec152 == o){
		s = "98"
	};
	if(dec153 == o){
		s = "99"
	};
	if(dec154 == o){
		s = "9a"
	};
	if(dec155 == o){
		s = "9b"
	};
	if(dec156 == o){
		s = "9c"
	};
	if(dec157 == o){
		s = "9d"
	};
	if(dec158 == o){
		s = "9e"
	};
	if(dec159 == o){
		s = "9f"
	}
	if(dec160 == o){
		s = "a0"
	};
	if(dec161 == o){
		s = "a1"
	};
	if(dec162 == o){
		s = "a2"
	};
	if(dec163 == o){
		s = "a3"
	};
	if(dec164 == o){
		s = "a4"
	};
	if(dec165 == o){
		s = "a5"
	};
	if(dec166 == o){
		s = "a6"
	};
	if(dec167 == o){
		s = "a7"
	};
	if(dec168 == o){
		s = "a8"
	};
	if(dec169 == o){
		s = "a9"
	}
	if(dec170 == o){
		s = "aa"
	};
	if(dec171 == o){
		s = "ab"
	};
	if(dec172 == o){
		s = "ac"
	};
	if(dec173 == o){
		s = "ad"
	};
	if(dec174 == o){
		s = "ae"
	};
	if(dec175 == o){
		s = "af"
	};
	if(dec176 == o){
		s = "b0"
	};
	if(dec177 == o){
		s = "b1"
	};
	if(dec178 == o){
		s = "b2"
	};
	if(dec179 == o){
		s = "b3"
	}
	if(dec180 == o){
		s = "b4"
	};
	if(dec181 == o){
		s = "b5"
	};
	if(dec182 == o){
		s = "b6"
	};
	if(dec183 == o){
		s = "b7"
	};
	if(dec184 == o){
		s = "b8"
	};
	if(dec185 == o){
		s = "b9"
	};
	if(dec186 == o){
		s = "ba"
	};
	if(dec187 == o){
		s = "bb"
	};
	if(dec188 == o){
		s = "bc"
	};
	if(dec189 == o){
		s = "bd"
	}
	if(dec190 == o){
		s = "be"
	};
	if(dec191 == o){
		s = "bf"
	};
	if(dec192 == o){
		s = "c0"
	};
	if(dec193 == o){
		s = "c1"
	};
	if(dec194 == o){
		s = "c2"
	};
	if(dec195 == o){
		s = "c3"
	};
	if(dec196 == o){
		s = "c4"
	};
	if(dec197 == o){
		s = "c5"
	};
	if(dec198 == o){
		s = "c6"
	};
	if(dec199 == o){
		s = "c7"
	}
	if(dec200 == o){
		s = "c8"
	};
	if(dec201 == o){
		s = "c9"
	};
	if(dec202 == o){
		s = "ca"
	};
	if(dec203 == o){
		s = "cb"
	};
	if(dec204 == o){
		s = "cc"
	};
	if(dec205 == o){
		s = "cd"
	};
	if(dec206 == o){
		s = "ce"
	};
	if(dec207 == o){
		s = "cf"
	};
	if(dec208 == o){
		s = "d0"
	};
	if(dec209 == o){
		s = "d1"
	}
	if(dec210 == o){
		s = "d2"
	};
	if(dec211 == o){
		s = "d3"
	};
	if(dec212 == o){
		s = "d4"
	};
	if(dec213 == o){
		s = "d5"
	};
	if(dec214 == o){
		s = "d6"
	};
	if(dec215 == o){
		s = "d7"
	};
	if(dec216 == o){
		s = "d8"
	};
	if(dec217 == o){
		s = "d9"
	};
	if(dec218 == o){
		s = "da"
	};
	if(dec219 == o){
		s = "db"
	}
	if(dec220 == o){
		s = "dc"
	};
	if(dec221 == o){
		s = "dd"
	};
	if(dec222 == o){
		s = "de"
	};
	if(dec223 == o){
		s = "df"
	};
	if(dec224 == o){
		s = "e0"
	};
	if(dec225 == o){
		s = "e1"
	};
	if(dec226 == o){
		s = "e2"
	};
	if(dec227 == o){
		s = "e3"
	};
	if(dec228 == o){
		s = "e4"
	};
	if(dec229 == o){
		s = "e5"
	}
	if(dec230 == o){
		s = "e6"
	};
	if(dec231 == o){
		s = "e7"
	};
	if(dec232 == o){
		s = "e8"
	};
	if(dec233 == o){
		s = "e9"
	};
	if(dec234 == o){
		s = "ea"
	};
	if(dec235 == o){
		s = "eb"
	};
	if(dec236 == o){
		s = "ec"
	};
	if(dec237 == o){
		s = "ed"
	};
	if(dec238 == o){
		s = "ee"
	};
	if(dec239 == o){
		s = "ef"
	}
	if(dec240 == o){
		s = "f0"
	};
	if(dec241 == o){
		s = "f1"
	};
	if(dec242 == o){
		s = "f2"
	};
	if(dec243 == o){
		s = "f3"
	};
	if(dec244 == o){
		s = "f4"
	};
	if(dec245 == o){
		s = "f5"
	};
	if(dec246 == o){
		s = "f6"
	};
	if(dec247 == o){
		s = "f7"
	};
	if(dec248 == o){
		s = "f8"
	};
	if(dec249 == o){
		s = "f9"
	}
	if(dec250 == o){
		s = "fa"
	};
	if(dec251 == o){
		s = "fb"
	};
	if(dec252 == o){
		s = "fc"
	};
	if(dec253 == o){
		s = "fd"
	};
	if(dec254 == o){
		s = "fe"
	};
	if(dec255 == o){
		s = "ff"
	};
	var t = p + q + r + s;
	document.getElementById("writersJumbler").style.borderColor = t;
} 
function boxSCrgb(){
	var m = document.getElementById("Box_Color-R").value;
	var n = document.getElementById("Box_Color-G").value;
	var o = document.getElementById("Box_Color-B").value;
	if(m >= 255){
		m = 255;
	};
	if(n >= 255){
		n = 255;
	};
	if(o >= 255){
		o = 255;
	};
	var p = "#";
	var dec0 = "0";
	var dec1 = "1";
	var dec2 = "2";
	var dec3 = "3";
	var dec4 = "4";
	var dec5 = "5";
	var dec6 = "6";
	var dec7 = "7";
	var dec8 = "8";
	var dec9 = "9";
	var dec10 = "10";
	var dec11 = "11";
	var dec12 = "12";
	var dec13 = "13";
	var dec14 = "14";
	var dec15 = "15";
	var dec16 = "16";
	var dec17 = "17";
	var dec18 = "18";
	var dec19 = "19";
	var dec20 = "20";
	var dec21 = "21";
	var dec22 = "22";
	var dec23 = "23";
	var dec24 = "24";
	var dec25 = "25";
	var dec26 = "26";
	var dec27 = "27";
	var dec28 = "28";
	var dec29 = "29";
	var dec30 = "30";
	var dec31 = "31";
	var dec32 = "32";
	var dec33 = "33";
	var dec34 = "34";
	var dec35 = "35";
	var dec36 = "36";
	var dec37 = "37";
	var dec38 = "38";
	var dec39 = "39";
	var dec40 = "40";
	var dec41 = "41";
	var dec42 = "42";
	var dec43 = "43";
	var dec44 = "44";
	var dec45 = "45";
	var dec46 = "46";
	var dec47 = "47";
	var dec48 = "48";
	var dec49 = "49";
	var dec50 = "50";
	var dec51 = "51";
	var dec52 = "52";
	var dec53 = "53";
	var dec54 = "54";
	var dec55 = "55";
	var dec56 = "56";
	var dec57 = "57";
	var dec58 = "58";
	var dec59 = "59";
	var dec60 = "60";
	var dec61 = "61";
	var dec62 = "62";
	var dec63 = "63";
	var dec64 = "64";
	var dec65 = "65";
	var dec66 = "66";
	var dec67 = "67";
	var dec68 = "68";
	var dec69 = "69";
	var dec70 = "70";
	var dec71 = "71";
	var dec72 = "72";
	var dec73 = "73";
	var dec74 = "74";
	var dec75 = "75";
	var dec76 = "76";
	var dec77 = "77";
	var dec78 = "78";
	var dec79 = "79";
	var dec80 = "80";
	var dec81 = "81";
	var dec82 = "82";
	var dec83 = "83";
	var dec84 = "84";
	var dec85 = "85";
	var dec86 = "86";
	var dec87 = "87";
	var dec88 = "88";
	var dec89 = "89";
	var dec90 = "90";
	var dec91 = "91";
	var dec92 = "92";
	var dec93 = "93";
	var dec94 = "94";
	var dec95 = "95";
	var dec96 = "96";
	var dec97 = "97";
	var dec98 = "98";
	var dec99 = "99";
	var dec100 = "100";
	var dec101 = "101";
	var dec102 = "102";
	var dec103 = "103";
	var dec104 = "104";
	var dec105 = "105";
	var dec106 = "106";
	var dec107 = "107";
	var dec108 = "108";
	var dec109 = "109";
	var dec110 = "110";
	var dec111 = "111";
	var dec112 = "112";
	var dec113 = "113";
	var dec114 = "114";
	var dec115 = "115";
	var dec116 = "116";
	var dec117 = "117";
	var dec118 = "118";
	var dec119 = "119";
	var dec120 = "120";
	var dec121 = "121";
	var dec122 = "122";
	var dec123 = "123";
	var dec124 = "124";
	var dec125 = "125";
	var dec126 = "126";
	var dec127 = "127";
	var dec128 = "128";
	var dec129 = "129";
	var dec130 = "130";
	var dec131 = "131";
	var dec132 = "132";
	var dec133 = "133";
	var dec134 = "134";
	var dec135 = "135";
	var dec136 = "136";
	var dec137 = "137";
	var dec138 = "138";
	var dec139 = "139";
	var dec140 = "140";
	var dec141 = "141";
	var dec142 = "142";
	var dec143 = "143";
	var dec144 = "144";
	var dec145 = "145";
	var dec146 = "146";
	var dec147 = "147";
	var dec148 = "148";
	var dec149 = "149";
	var dec150 = "150";
	var dec151 = "151";
	var dec152 = "152";
	var dec153 = "153";
	var dec154 = "154";
	var dec155 = "155";
	var dec156 = "156";
	var dec157 = "157";
	var dec158 = "158";
	var dec159 = "159";
	var dec160 = "160";
	var dec161 = "161";
	var dec162 = "162";
	var dec163 = "163";
	var dec164 = "164";
	var dec165 = "165";
	var dec166 = "166";
	var dec167 = "167";
	var dec168 = "168";
	var dec169 = "169";
	var dec170 = "170";
	var dec171 = "171";
	var dec172 = "172";
	var dec173 = "173";
	var dec174 = "174";
	var dec175 = "175";
	var dec176 = "176";
	var dec177 = "177";
	var dec178 = "178";
	var dec179 = "179";
	var dec180 = "180";
	var dec181 = "181";
	var dec182 = "182";
	var dec183 = "183";
	var dec184 = "184";
	var dec185 = "185";
	var dec186 = "186";
	var dec187 = "187";
	var dec188 = "188";
	var dec189 = "189";
	var dec190 = "190";
	var dec191 = "191";
	var dec192 = "192";
	var dec193 = "193";
	var dec194 = "194";
	var dec195 = "195";
	var dec196 = "196";
	var dec197 = "197";
	var dec198 = "198";
	var dec199 = "199";
	var dec200 = "200";
	var dec201 = "201";
	var dec202 = "202";
	var dec203 = "203";
	var dec204 = "204";
	var dec205 = "205";
	var dec206 = "206";
	var dec207 = "207";
	var dec208 = "208";
	var dec209 = "209";
	var dec210 = "210";
	var dec211 = "211";
	var dec212 = "212";
	var dec213 = "213";
	var dec214 = "214";
	var dec215 = "215";
	var dec216 = "216";
	var dec217 = "217";
	var dec218 = "218";
	var dec219 = "219";
	var dec220 = "220";
	var dec221 = "221";
	var dec222 = "222";
	var dec223 = "223";
	var dec224 = "224";
	var dec225 = "225";
	var dec226 = "226";
	var dec227 = "227";
	var dec228 = "228";
	var dec229 = "229";
	var dec230 = "230";
	var dec231 = "231";
	var dec232 = "232";
	var dec233 = "233";
	var dec234 = "234";
	var dec235 = "235";
	var dec236 = "236";
	var dec237 = "237";
	var dec238 = "238";
	var dec239 = "239";
	var dec240 = "240";
	var dec241 = "241";
	var dec242 = "242";
	var dec243 = "243";
	var dec244 = "244";
	var dec245 = "245";
	var dec246 = "246";
	var dec247 = "247";
	var dec248 = "248";
	var dec249 = "249";
	var dec250 = "250";
	var dec251 = "251";
	var dec252 = "252";
	var dec253 = "253";
	var dec254 = "254";
	var dec255 = "255";
	if(dec0 == m){
		q = "00"
	};
	if(dec1 == m){
		q = "01"
	};
	if(dec2 == m){
		q = "02"
	};
	if(dec3 == m){
		q = "03"
	};
	if(dec4 == m){
		q = "04"
	};
	if(dec5 == m){
		q = "05"
	};
	if(dec6 == m){
		q = "06"
	};
	if(dec7 == m){
		q = "07"
	};
	if(dec8 == m){
		q = "08"
	};
	if(dec9 == m){
		q = "09"
	}
	if(dec10 == m){
		q = "0a"
	};
	if(dec11 == m){
		q = "0b"
	};
	if(dec12 == m){
		q = "0c"
	};
	if(dec13 == m){
		q = "0d"
	};
	if(dec14 == m){
		q = "0e"
	};
	if(dec15 == m){
		q = "0f"
	};
	if(dec16 == m){
		q = "10"
	};
	if(dec17 == m){
		q = "11"
	};
	if(dec18 == m){
		q = "12"
	};
	if(dec19 == m){
		q = "13"
	}
	if(dec20 == m){
		q = "14"
	};
	if(dec21 == m){
		q = "15"
	};
	if(dec22 == m){
		q = "16"
	};
	if(dec23 == m){
		q = "17"
	};
	if(dec24 == m){
		q = "18"
	};
	if(dec25 == m){
		q = "19"
	};
	if(dec26 == m){
		q = "1a"
	};
	if(dec27 == m){
		q = "1b"
	};
	if(dec28 == m){
		q = "1c"
	};
	if(dec29 == m){
		q = "1d"
	}
	if(dec30 == m){
		q = "1e"
	};
	if(dec31 == m){
		q = "1f"
	};
	if(dec32 == m){
		q = "20"
	};
	if(dec33 == m){
		q = "21"
	};
	if(dec34 == m){
		q = "22"
	};
	if(dec35 == m){
		q = "23"
	};
	if(dec36 == m){
		q = "24"
	};
	if(dec37 == m){
		q = "25"
	};
	if(dec38 == m){
		q = "26"
	};
	if(dec39 == m){
		q = "27"
	}
	if(dec40 == m){
		q = "28"
	};
	if(dec41 == m){
		q = "29"
	};
	if(dec42 == m){
		q = "2a"
	};
	if(dec43 == m){
		q = "2b"
	};
	if(dec44 == m){
		q = "2c"
	};
	if(dec45 == m){
		q = "2d"
	};
	if(dec46 == m){
		q = "2e"
	};
	if(dec47 == m){
		q = "2f"
	};
	if(dec48 == m){
		q = "30"
	};
	if(dec49 == m){
		q = "31"
	}
	if(dec50 == m){
		q = "32"
	};
	if(dec51 == m){
		q = "33"
	};
	if(dec52 == m){
		q = "34"
	};
	if(dec53 == m){
		q = "35"
	};
	if(dec54 == m){
		q = "36"
	};
	if(dec55 == m){
		q = "37"
	};
	if(dec56 == m){
		q = "38"
	};
	if(dec57 == m){
		q = "39"
	};
	if(dec58 == m){
		q = "3a"
	};
	if(dec59 == m){
		q = "3b"
	}
	if(dec60 == m){
		q = "3c"
	};
	if(dec61 == m){
		q = "3d"
	};
	if(dec62 == m){
		q = "3e"
	};
	if(dec63 == m){
		q = "3f"
	};
	if(dec64 == m){
		q = "40"
	};
	if(dec65 == m){
		q = "41"
	};
	if(dec66 == m){
		q = "42"
	};
	if(dec67 == m){
		q = "43"
	};
	if(dec68 == m){
		q = "44"
	};
	if(dec69 == m){
		q = "45"
	}
	if(dec70 == m){
		q = "46"
	};
	if(dec71 == m){
		q = "47"
	};
	if(dec72 == m){
		q = "48"
	};
	if(dec73 == m){
		q = "49"
	};
	if(dec74 == m){
		q = "4a"
	};
	if(dec75 == m){
		q = "4b"
	};
	if(dec76 == m){
		q = "4c"
	};
	if(dec77 == m){
		q = "4d"
	};
	if(dec78 == m){
		q = "4e"
	};
	if(dec79 == m){
		q = "4f"
	}
	if(dec80 == m){
		q = "50"
	};
	if(dec81 == m){
		q = "51"
	};
	if(dec82 == m){
		q = "52"
	};
	if(dec83 == m){
		q = "53"
	};
	if(dec84 == m){
		q = "54"
	};
	if(dec85 == m){
		q = "55"
	};
	if(dec86 == m){
		q = "56"
	};
	if(dec87 == m){
		q = "57"
	};
	if(dec88 == m){
		q = "58"
	};
	if(dec89 == m){
		q = "59"
	}
	if(dec90 == m){
		q = "5a"
	};
	if(dec91 == m){
		q = "5b"
	};
	if(dec92 == m){
		q = "5c"
	};
	if(dec93 == m){
		q = "5d"
	};
	if(dec94 == m){
		q = "5e"
	};
	if(dec95 == m){
		q = "5f"
	};
	if(dec96 == m){
		q = "60"
	};
	if(dec97 == m){
		q = "61"
	};
	if(dec98 == m){
		q = "62"
	};
	if(dec99 == m){
		q = "63"
	}
	if(dec100 == m){
		q = "64"
	};
	if(dec101 == m){
		q = "65"
	};
	if(dec102 == m){
		q = "66"
	};
	if(dec103 == m){
		q = "67"
	};
	if(dec104 == m){
		q = "68"
	};
	if(dec105 == m){
		q = "69"
	};
	if(dec106 == m){
		q = "6a"
	};
	if(dec107 == m){
		q = "6b"
	};
	if(dec108 == m){
		q = "6c"
	};
	if(dec109 == m){
		q = "6d"
	}
	if(dec110 == m){
		q = "6e"
	};
	if(dec111 == m){
		q = "6f"
	};
	if(dec112 == m){
		q = "70"
	};
	if(dec113 == m){
		q = "71"
	};
	if(dec114 == m){
		q = "72"
	};
	if(dec115 == m){
		q = "73"
	};
	if(dec116 == m){
		q = "74"
	};
	if(dec117 == m){
		q = "75"
	};
	if(dec118 == m){
		q = "76"
	};
	if(dec119 == m){
		q = "77"
	}
	if(dec120 == m){
		q = "78"
	};
	if(dec121 == m){
		q = "79"
	};
	if(dec122 == m){
		q = "7a"
	};
	if(dec123 == m){
		q = "7b"
	};
	if(dec124 == m){
		q = "7c"
	};
	if(dec125 == m){
		q = "7d"
	};
	if(dec126 == m){
		q = "7e"
	};
	if(dec127 == m){
		q = "7f"
	};
	if(dec128 == m){
		q = "80"
	};
	if(dec129 == m){
		q = "81"
	}
	if(dec130 == m){
		q = "82"
	};
	if(dec131 == m){
		q = "83"
	};
	if(dec132 == m){
		q = "84"
	};
	if(dec133 == m){
		q = "85"
	};
	if(dec134 == m){
		q = "86"
	};
	if(dec135 == m){
		q = "87"
	};
	if(dec136 == m){
		q = "88"
	};
	if(dec137 == m){
		q = "89"
	};
	if(dec138 == m){
		q = "8a"
	};
	if(dec139 == m){
		q = "8b"
	}
	if(dec140 == m){
		q = "8c"
	};
	if(dec141 == m){
		q = "8d"
	};
	if(dec142 == m){
		q = "8e"
	};
	if(dec143 == m){
		q = "8f"
	};
	if(dec144 == m){
		q = "90"
	};
	if(dec145 == m){
		q = "91"
	};
	if(dec146 == m){
		q = "92"
	};
	if(dec147 == m){
		q = "93"
	};
	if(dec148 == m){
		q = "94"
	};
	if(dec149 == m){
		q = "95"
	}
	if(dec150 == m){
		q = "96"
	};
	if(dec151 == m){
		q = "97"
	};
	if(dec152 == m){
		q = "98"
	};
	if(dec153 == m){
		q = "99"
	};
	if(dec154 == m){
		q = "9a"
	};
	if(dec155 == m){
		q = "9b"
	};
	if(dec156 == m){
		q = "9c"
	};
	if(dec157 == m){
		q = "9d"
	};
	if(dec158 == m){
		q = "9e"
	};
	if(dec159 == m){
		q = "9f"
	}
	if(dec160 == m){
		q = "a0"
	};
	if(dec161 == m){
		q = "a1"
	};
	if(dec162 == m){
		q = "a2"
	};
	if(dec163 == m){
		q = "a3"
	};
	if(dec164 == m){
		q = "a4"
	};
	if(dec165 == m){
		q = "a5"
	};
	if(dec166 == m){
		q = "a6"
	};
	if(dec167 == m){
		q = "a7"
	};
	if(dec168 == m){
		q = "a8"
	};
	if(dec169 == m){
		q = "a9"
	}
	if(dec170 == m){
		q = "aa"
	};
	if(dec171 == m){
		q = "ab"
	};
	if(dec172 == m){
		q = "ac"
	};
	if(dec173 == m){
		q = "ad"
	};
	if(dec174 == m){
		q = "ae"
	};
	if(dec175 == m){
		q = "af"
	};
	if(dec176 == m){
		q = "b0"
	};
	if(dec177 == m){
		q = "b1"
	};
	if(dec178 == m){
		q = "b2"
	};
	if(dec179 == m){
		q = "b3"
	}
	if(dec180 == m){
		q = "b4"
	};
	if(dec181 == m){
		q = "b5"
	};
	if(dec182 == m){
		q = "b6"
	};
	if(dec183 == m){
		q = "b7"
	};
	if(dec184 == m){
		q = "b8"
	};
	if(dec185 == m){
		q = "b9"
	};
	if(dec186 == m){
		q = "ba"
	};
	if(dec187 == m){
		q = "bb"
	};
	if(dec188 == m){
		q = "bc"
	};
	if(dec189 == m){
		q = "bd"
	}
	if(dec190 == m){
		q = "be"
	};
	if(dec191 == m){
		q = "bf"
	};
	if(dec192 == m){
		q = "c0"
	};
	if(dec193 == m){
		q = "c1"
	};
	if(dec194 == m){
		q = "c2"
	};
	if(dec195 == m){
		q = "c3"
	};
	if(dec196 == m){
		q = "c4"
	};
	if(dec197 == m){
		q = "c5"
	};
	if(dec198 == m){
		q = "c6"
	};
	if(dec199 == m){
		q = "c7"
	}
	if(dec200 == m){
		q = "c8"
	};
	if(dec201 == m){
		q = "c9"
	};
	if(dec202 == m){
		q = "ca"
	};
	if(dec203 == m){
		q = "cb"
	};
	if(dec204 == m){
		q = "cc"
	};
	if(dec205 == m){
		q = "cd"
	};
	if(dec206 == m){
		q = "ce"
	};
	if(dec207 == m){
		q = "cf"
	};
	if(dec208 == m){
		q = "d0"
	};
	if(dec209 == m){
		q = "d1"
	}
	if(dec210 == m){
		q = "d2"
	};
	if(dec211 == m){
		q = "d3"
	};
	if(dec212 == m){
		q = "d4"
	};
	if(dec213 == m){
		q = "d5"
	};
	if(dec214 == m){
		q = "d6"
	};
	if(dec215 == m){
		q = "d7"
	};
	if(dec216 == m){
		q = "d8"
	};
	if(dec217 == m){
		q = "d9"
	};
	if(dec218 == m){
		q = "da"
	};
	if(dec219 == m){
		q = "db"
	}
	if(dec220 == m){
		q = "dc"
	};
	if(dec221 == m){
		q = "dd"
	};
	if(dec222 == m){
		q = "de"
	};
	if(dec223 == m){
		q = "df"
	};
	if(dec224 == m){
		q = "e0"
	};
	if(dec225 == m){
		q = "e1"
	};
	if(dec226 == m){
		q = "e2"
	};
	if(dec227 == m){
		q = "e3"
	};
	if(dec228 == m){
		q = "e4"
	};
	if(dec229 == m){
		q = "e5"
	}
	if(dec230 == m){
		q = "e6"
	};
	if(dec231 == m){
		q = "e7"
	};
	if(dec232 == m){
		q = "e8"
	};
	if(dec233 == m){
		q = "e9"
	};
	if(dec234 == m){
		q = "ea"
	};
	if(dec235 == m){
		q = "eb"
	};
	if(dec236 == m){
		q = "ec"
	};
	if(dec237 == m){
		q = "ed"
	};
	if(dec238 == m){
		q = "ee"
	};
	if(dec239 == m){
		q = "ef"
	}
	if(dec240 == m){
		q = "f0"
	};
	if(dec241 == m){
		q = "f1"
	};
	if(dec242 == m){
		q = "f2"
	};
	if(dec243 == m){
		q = "f3"
	};
	if(dec244 == m){
		q = "f4"
	};
	if(dec245 == m){
		q = "f5"
	};
	if(dec246 == m){
		q = "f6"
	};
	if(dec247 == m){
		q = "f7"
	};
	if(dec248 == m){
		q = "f8"
	};
	if(dec249 == m){
		q = "f9"
	}
	if(dec250 == m){
		q = "fa"
	};
	if(dec251 == m){
		q = "fb"
	};
	if(dec252 == m){
		q = "fc"
	};
	if(dec253 == m){
		q = "fd"
	};
	if(dec254 == m){
		q = "fe"
	};
	if(dec255 == m){
		q = "ff"
	};
	
	if(dec0 == n){
		r = "00"
	};
	if(dec1 == n){
		r = "01"
	};
	if(dec2 == n){
		r = "02"
	};
	if(dec3 == n){
		r = "03"
	};
	if(dec4 == n){
		r = "04"
	};
	if(dec5 == n){
		r = "05"
	};
	if(dec6 == n){
		r = "06"
	};
	if(dec7 == n){
		r = "07"
	};
	if(dec8 == n){
		r = "08"
	};
	if(dec9 == n){
		r = "09"
	}
	if(dec10 == n){
		r = "0a"
	};
	if(dec11 == n){
		r = "0b"
	};
	if(dec12 == n){
		r = "0c"
	};
	if(dec13 == n){
		r = "0d"
	};
	if(dec14 == n){
		r = "0e"
	};
	if(dec15 == n){
		r = "0f"
	};
	if(dec16 == n){
		r = "10"
	};
	if(dec17 == n){
		r = "11"
	};
	if(dec18 == n){
		r = "12"
	};
	if(dec19 == n){
		r = "13"
	}
	if(dec20 == n){
		r = "14"
	};
	if(dec21 == n){
		r = "15"
	};
	if(dec22 == n){
		r = "16"
	};
	if(dec23 == n){
		r = "17"
	};
	if(dec24 == n){
		r = "18"
	};
	if(dec25 == n){
		r = "19"
	};
	if(dec26 == n){
		r = "1a"
	};
	if(dec27 == n){
		r = "1b"
	};
	if(dec28 == n){
		r = "1c"
	};
	if(dec29 == n){
		r = "1d"
	}
	if(dec30 == n){
		r = "1e"
	};
	if(dec31 == n){
		r = "1f"
	};
	if(dec32 == n){
		r = "20"
	};
	if(dec33 == n){
		r = "21"
	};
	if(dec34 == n){
		r = "22"
	};
	if(dec35 == n){
		r = "23"
	};
	if(dec36 == n){
		r = "24"
	};
	if(dec37 == n){
		r = "25"
	};
	if(dec38 == n){
		r = "26"
	};
	if(dec39 == n){
		r = "27"
	}
	if(dec40 == n){
		r = "28"
	};
	if(dec41 == n){
		r = "29"
	};
	if(dec42 == n){
		r = "2a"
	};
	if(dec43 == n){
		r = "2b"
	};
	if(dec44 == n){
		r = "2c"
	};
	if(dec45 == n){
		r = "2d"
	};
	if(dec46 == n){
		r = "2e"
	};
	if(dec47 == n){
		r = "2f"
	};
	if(dec48 == n){
		r = "30"
	};
	if(dec49 == n){
		r = "31"
	}
	if(dec50 == n){
		r = "32"
	};
	if(dec51 == n){
		r = "33"
	};
	if(dec52 == n){
		r = "34"
	};
	if(dec53 == n){
		r = "35"
	};
	if(dec54 == n){
		r = "36"
	};
	if(dec55 == n){
		r = "37"
	};
	if(dec56 == n){
		r = "38"
	};
	if(dec57 == n){
		r = "39"
	};
	if(dec58 == n){
		r = "3a"
	};
	if(dec59 == n){
		r = "3b"
	}
	if(dec60 == n){
		r = "3c"
	};
	if(dec61 == n){
		r = "3d"
	};
	if(dec62 == n){
		r = "3e"
	};
	if(dec63 == n){
		r = "3f"
	};
	if(dec64 == n){
		r = "40"
	};
	if(dec65 == n){
		r = "41"
	};
	if(dec66 == n){
		r = "42"
	};
	if(dec67 == n){
		r = "43"
	};
	if(dec68 == n){
		r = "44"
	};
	if(dec69 == n){
		r = "45"
	}
	if(dec70 == n){
		r = "46"
	};
	if(dec71 == n){
		r = "47"
	};
	if(dec72 == n){
		r = "48"
	};
	if(dec73 == n){
		r = "49"
	};
	if(dec74 == n){
		r = "4a"
	};
	if(dec75 == n){
		r = "4b"
	};
	if(dec76 == n){
		r = "4c"
	};
	if(dec77 == n){
		r = "4d"
	};
	if(dec78 == n){
		r = "4e"
	};
	if(dec79 == n){
		r = "4f"
	}
	if(dec80 == n){
		r = "50"
	};
	if(dec81 == n){
		r = "51"
	};
	if(dec82 == n){
		r = "52"
	};
	if(dec83 == n){
		r = "53"
	};
	if(dec84 == n){
		r = "54"
	};
	if(dec85 == n){
		r = "55"
	};
	if(dec86 == n){
		r = "56"
	};
	if(dec87 == n){
		r = "57"
	};
	if(dec88 == n){
		r = "58"
	};
	if(dec89 == n){
		r = "59"
	}
	if(dec90 == n){
		r = "5a"
	};
	if(dec91 == n){
		r = "5b"
	};
	if(dec92 == n){
		r = "5c"
	};
	if(dec93 == n){
		r = "5d"
	};
	if(dec94 == n){
		r = "5e"
	};
	if(dec95 == n){
		r = "5f"
	};
	if(dec96 == n){
		r = "60"
	};
	if(dec97 == n){
		r = "61"
	};
	if(dec98 == n){
		r = "62"
	};
	if(dec99 == n){
		r = "63"
	}
	if(dec100 == n){
		r = "64"
	};
	if(dec101 == n){
		r = "65"
	};
	if(dec102 == n){
		r = "66"
	};
	if(dec103 == n){
		r = "67"
	};
	if(dec104 == n){
		r = "68"
	};
	if(dec105 == n){
		r = "69"
	};
	if(dec106 == n){
		r = "6a"
	};
	if(dec107 == n){
		r = "6b"
	};
	if(dec108 == n){
		r = "6c"
	};
	if(dec109 == n){
		r = "6d"
	}
	if(dec110 == n){
		r = "6e"
	};
	if(dec111 == n){
		r = "6f"
	};
	if(dec112 == n){
		r = "70"
	};
	if(dec113 == n){
		r = "71"
	};
	if(dec114 == n){
		r = "72"
	};
	if(dec115 == n){
		r = "73"
	};
	if(dec116 == n){
		r = "74"
	};
	if(dec117 == n){
		r = "75"
	};
	if(dec118 == n){
		r = "76"
	};
	if(dec119 == n){
		r = "77"
	}
	if(dec120 == n){
		r = "78"
	};
	if(dec121 == n){
		r = "79"
	};
	if(dec122 == n){
		r = "7a"
	};
	if(dec123 == n){
		r = "7b"
	};
	if(dec124 == n){
		r = "7c"
	};
	if(dec125 == n){
		r = "7d"
	};
	if(dec126 == n){
		r = "7e"
	};
	if(dec127 == n){
		r = "7f"
	};
	if(dec128 == n){
		r = "80"
	};
	if(dec129 == n){
		r = "81"
	}
	if(dec130 == n){
		r = "82"
	};
	if(dec131 == n){
		r = "83"
	};
	if(dec132 == n){
		r = "84"
	};
	if(dec133 == n){
		r = "85"
	};
	if(dec134 == n){
		r = "86"
	};
	if(dec135 == n){
		r = "87"
	};
	if(dec136 == n){
		r = "88"
	};
	if(dec137 == n){
		r = "89"
	};
	if(dec138 == n){
		r = "8a"
	};
	if(dec139 == n){
		r = "8b"
	}
	if(dec140 == n){
		r = "8c"
	};
	if(dec141 == n){
		r = "8d"
	};
	if(dec142 == n){
		r = "8e"
	};
	if(dec143 == n){
		r = "8f"
	};
	if(dec144 == n){
		r = "90"
	};
	if(dec145 == n){
		r = "91"
	};
	if(dec146 == n){
		r = "92"
	};
	if(dec147 == n){
		r = "93"
	};
	if(dec148 == n){
		r = "94"
	};
	if(dec149 == n){
		r = "95"
	}
	if(dec150 == n){
		r = "96"
	};
	if(dec151 == n){
		r = "97"
	};
	if(dec152 == n){
		r = "98"
	};
	if(dec153 == n){
		r = "99"
	};
	if(dec154 == n){
		r = "9a"
	};
	if(dec155 == n){
		r = "9b"
	};
	if(dec156 == n){
		r = "9c"
	};
	if(dec157 == n){
		r = "9d"
	};
	if(dec158 == n){
		r = "9e"
	};
	if(dec159 == n){
		r = "9f"
	}
	if(dec160 == n){
		r = "a0"
	};
	if(dec161 == n){
		r = "a1"
	};
	if(dec162 == n){
		r = "a2"
	};
	if(dec163 == n){
		r = "a3"
	};
	if(dec164 == n){
		r = "a4"
	};
	if(dec165 == n){
		r = "a5"
	};
	if(dec166 == n){
		r = "a6"
	};
	if(dec167 == n){
		r = "a7"
	};
	if(dec168 == n){
		r = "a8"
	};
	if(dec169 == n){
		r = "a9"
	}
	if(dec170 == n){
		r = "aa"
	};
	if(dec171 == n){
		r = "ab"
	};
	if(dec172 == n){
		r = "ac"
	};
	if(dec173 == n){
		r = "ad"
	};
	if(dec174 == n){
		r = "ae"
	};
	if(dec175 == n){
		r = "af"
	};
	if(dec176 == n){
		r = "b0"
	};
	if(dec177 == n){
		r = "b1"
	};
	if(dec178 == n){
		r = "b2"
	};
	if(dec179 == n){
		r = "b3"
	}
	if(dec180 == n){
		r = "b4"
	};
	if(dec181 == n){
		r = "b5"
	};
	if(dec182 == n){
		r = "b6"
	};
	if(dec183 == n){
		r = "b7"
	};
	if(dec184 == n){
		r = "b8"
	};
	if(dec185 == n){
		r = "b9"
	};
	if(dec186 == n){
		r = "ba"
	};
	if(dec187 == n){
		r = "bb"
	};
	if(dec188 == n){
		r = "bc"
	};
	if(dec189 == n){
		r = "bd"
	}
	if(dec190 == n){
		r = "be"
	};
	if(dec191 == n){
		r = "bf"
	};
	if(dec192 == n){
		r = "c0"
	};
	if(dec193 == n){
		r = "c1"
	};
	if(dec194 == n){
		r = "c2"
	};
	if(dec195 == n){
		r = "c3"
	};
	if(dec196 == n){
		r = "c4"
	};
	if(dec197 == n){
		r = "c5"
	};
	if(dec198 == n){
		r = "c6"
	};
	if(dec199 == n){
		r = "c7"
	}
	if(dec200 == n){
		r = "c8"
	};
	if(dec201 == n){
		r = "c9"
	};
	if(dec202 == n){
		r = "ca"
	};
	if(dec203 == n){
		r = "cb"
	};
	if(dec204 == n){
		r = "cc"
	};
	if(dec205 == n){
		r = "cd"
	};
	if(dec206 == n){
		r = "ce"
	};
	if(dec207 == n){
		r = "cf"
	};
	if(dec208 == n){
		r = "d0"
	};
	if(dec209 == n){
		r = "d1"
	}
	if(dec210 == n){
		r = "d2"
	};
	if(dec211 == n){
		r = "d3"
	};
	if(dec212 == n){
		r = "d4"
	};
	if(dec213 == n){
		r = "d5"
	};
	if(dec214 == n){
		r = "d6"
	};
	if(dec215 == n){
		r = "d7"
	};
	if(dec216 == n){
		r = "d8"
	};
	if(dec217 == n){
		r = "d9"
	};
	if(dec218 == n){
		r = "da"
	};
	if(dec219 == n){
		r = "db"
	}
	if(dec220 == n){
		r = "dc"
	};
	if(dec221 == n){
		r = "dd"
	};
	if(dec222 == n){
		r = "de"
	};
	if(dec223 == n){
		r = "df"
	};
	if(dec224 == n){
		r = "e0"
	};
	if(dec225 == n){
		r = "e1"
	};
	if(dec226 == n){
		r = "e2"
	};
	if(dec227 == n){
		r = "e3"
	};
	if(dec228 == n){
		r = "e4"
	};
	if(dec229 == n){
		r = "e5"
	}
	if(dec230 == n){
		r = "e6"
	};
	if(dec231 == n){
		r = "e7"
	};
	if(dec232 == n){
		r = "e8"
	};
	if(dec233 == n){
		r = "e9"
	};
	if(dec234 == n){
		r = "ea"
	};
	if(dec235 == n){
		r = "eb"
	};
	if(dec236 == n){
		r = "ec"
	};
	if(dec237 == n){
		r = "ed"
	};
	if(dec238 == n){
		r = "ee"
	};
	if(dec239 == n){
		r = "ef"
	}
	if(dec240 == n){
		r = "f0"
	};
	if(dec241 == n){
		r = "f1"
	};
	if(dec242 == n){
		r = "f2"
	};
	if(dec243 == n){
		r = "f3"
	};
	if(dec244 == n){
		r = "f4"
	};
	if(dec245 == n){
		r = "f5"
	};
	if(dec246 == n){
		r = "f6"
	};
	if(dec247 == n){
		r = "f7"
	};
	if(dec248 == n){
		r = "f8"
	};
	if(dec249 == n){
		r = "f9"
	}
	if(dec250 == n){
		r = "fa"
	};
	if(dec251 == n){
		r = "fb"
	};
	if(dec252 == n){
		r = "fc"
	};
	if(dec253 == n){
		r = "fd"
	};
	if(dec254 == n){
		r = "fe"
	};
	if(dec255 == n){
		r = "ff"
	};
	
	
	if(dec0 == o){
		s = "00"
	};
	if(dec1 == o){
		s = "01"
	};
	if(dec2 == o){
		s = "02"
	};
	if(dec3 == o){
		s = "03"
	};
	if(dec4 == o){
		s = "04"
	};
	if(dec5 == o){
		s = "05"
	};
	if(dec6 == o){
		s = "06"
	};
	if(dec7 == o){
		s = "07"
	};
	if(dec8 == o){
		s = "08"
	};
	if(dec9 == o){
		s = "09"
	}
	if(dec10 == o){
		s = "0a"
	};
	if(dec11 == o){
		s = "0b"
	};
	if(dec12 == o){
		s = "0c"
	};
	if(dec13 == o){
		s = "0d"
	};
	if(dec14 == o){
		s = "0e"
	};
	if(dec15 == o){
		s = "0f"
	};
	if(dec16 == o){
		s = "10"
	};
	if(dec17 == o){
		s = "11"
	};
	if(dec18 == o){
		s = "12"
	};
	if(dec19 == o){
		s = "13"
	}
	if(dec20 == o){
		s = "14"
	};
	if(dec21 == o){
		s = "15"
	};
	if(dec22 == o){
		s = "16"
	};
	if(dec23 == o){
		s = "17"
	};
	if(dec24 == o){
		s = "18"
	};
	if(dec25 == o){
		s = "19"
	};
	if(dec26 == o){
		s = "1a"
	};
	if(dec27 == o){
		s = "1b"
	};
	if(dec28 == o){
		s = "1c"
	};
	if(dec29 == o){
		s = "1d"
	}
	if(dec30 == o){
		s = "1e"
	};
	if(dec31 == o){
		s = "1f"
	};
	if(dec32 == o){
		s = "20"
	};
	if(dec33 == o){
		s = "21"
	};
	if(dec34 == o){
		s = "22"
	};
	if(dec35 == o){
		s = "23"
	};
	if(dec36 == o){
		s = "24"
	};
	if(dec37 == o){
		s = "25"
	};
	if(dec38 == o){
		s = "26"
	};
	if(dec39 == o){
		s = "27"
	}
	if(dec40 == o){
		s = "28"
	};
	if(dec41 == o){
		s = "29"
	};
	if(dec42 == o){
		s = "2a"
	};
	if(dec43 == o){
		s = "2b"
	};
	if(dec44 == o){
		s = "2c"
	};
	if(dec45 == o){
		s = "2d"
	};
	if(dec46 == o){
		s = "2e"
	};
	if(dec47 == o){
		s = "2f"
	};
	if(dec48 == o){
		s = "30"
	};
	if(dec49 == o){
		s = "31"
	}
	if(dec50 == o){
		s = "32"
	};
	if(dec51 == o){
		s = "33"
	};
	if(dec52 == o){
		s = "34"
	};
	if(dec53 == o){
		s = "35"
	};
	if(dec54 == o){
		s = "36"
	};
	if(dec55 == o){
		s = "37"
	};
	if(dec56 == o){
		s = "38"
	};
	if(dec57 == o){
		s = "39"
	};
	if(dec58 == o){
		s = "3a"
	};
	if(dec59 == o){
		s = "3b"
	}
	if(dec60 == o){
		s = "3c"
	};
	if(dec61 == o){
		s = "3d"
	};
	if(dec62 == o){
		s = "3e"
	};
	if(dec63 == o){
		s = "3f"
	};
	if(dec64 == o){
		s = "40"
	};
	if(dec65 == o){
		s = "41"
	};
	if(dec66 == o){
		s = "42"
	};
	if(dec67 == o){
		s = "43"
	};
	if(dec68 == o){
		s = "44"
	};
	if(dec69 == o){
		s = "45"
	}
	if(dec70 == o){
		s = "46"
	};
	if(dec71 == o){
		s = "47"
	};
	if(dec72 == o){
		s = "48"
	};
	if(dec73 == o){
		s = "49"
	};
	if(dec74 == o){
		s = "4a"
	};
	if(dec75 == o){
		s = "4b"
	};
	if(dec76 == o){
		s = "4c"
	};
	if(dec77 == o){
		s = "4d"
	};
	if(dec78 == o){
		s = "4e"
	};
	if(dec79 == o){
		s = "4f"
	}
	if(dec80 == o){
		s = "50"
	};
	if(dec81 == o){
		s = "51"
	};
	if(dec82 == o){
		s = "52"
	};
	if(dec83 == o){
		s = "53"
	};
	if(dec84 == o){
		s = "54"
	};
	if(dec85 == o){
		s = "55"
	};
	if(dec86 == o){
		s = "56"
	};
	if(dec87 == o){
		s = "57"
	};
	if(dec88 == o){
		s = "58"
	};
	if(dec89 == o){
		s = "59"
	}
	if(dec90 == o){
		s = "5a"
	};
	if(dec91 == o){
		s = "5b"
	};
	if(dec92 == o){
		s = "5c"
	};
	if(dec93 == o){
		s = "5d"
	};
	if(dec94 == o){
		s = "5e"
	};
	if(dec95 == o){
		s = "5f"
	};
	if(dec96 == o){
		s = "60"
	};
	if(dec97 == o){
		s = "61"
	};
	if(dec98 == o){
		s = "62"
	};
	if(dec99 == o){
		s = "63"
	}
	if(dec100 == o){
		s = "64"
	};
	if(dec101 == o){
		s = "65"
	};
	if(dec102 == o){
		s = "66"
	};
	if(dec103 == o){
		s = "67"
	};
	if(dec104 == o){
		s = "68"
	};
	if(dec105 == o){
		s = "69"
	};
	if(dec106 == o){
		s = "6a"
	};
	if(dec107 == o){
		s = "6b"
	};
	if(dec108 == o){
		s = "6c"
	};
	if(dec109 == o){
		s = "6d"
	}
	if(dec110 == o){
		s = "6e"
	};
	if(dec111 == o){
		s = "6f"
	};
	if(dec112 == o){
		s = "70"
	};
	if(dec113 == o){
		s = "71"
	};
	if(dec114 == o){
		s = "72"
	};
	if(dec115 == o){
		s = "73"
	};
	if(dec116 == o){
		s = "74"
	};
	if(dec117 == o){
		s = "75"
	};
	if(dec118 == o){
		s = "76"
	};
	if(dec119 == o){
		s = "77"
	}
	if(dec120 == o){
		s = "78"
	};
	if(dec121 == o){
		s = "79"
	};
	if(dec122 == o){
		s = "7a"
	};
	if(dec123 == o){
		s = "7b"
	};
	if(dec124 == o){
		s = "7c"
	};
	if(dec125 == o){
		s = "7d"
	};
	if(dec126 == o){
		s = "7e"
	};
	if(dec127 == o){
		s = "7f"
	};
	if(dec128 == o){
		s = "80"
	};
	if(dec129 == o){
		s = "81"
	}
	if(dec130 == o){
		s = "82"
	};
	if(dec131 == o){
		s = "83"
	};
	if(dec132 == o){
		s = "84"
	};
	if(dec133 == o){
		s = "85"
	};
	if(dec134 == o){
		s = "86"
	};
	if(dec135 == o){
		s = "87"
	};
	if(dec136 == o){
		s = "88"
	};
	if(dec137 == o){
		s = "89"
	};
	if(dec138 == o){
		s = "8a"
	};
	if(dec139 == o){
		s = "8b"
	}
	if(dec140 == o){
		s = "8c"
	};
	if(dec141 == o){
		s = "8d"
	};
	if(dec142 == o){
		s = "8e"
	};
	if(dec143 == o){
		s = "8f"
	};
	if(dec144 == o){
		s = "90"
	};
	if(dec145 == o){
		s = "91"
	};
	if(dec146 == o){
		s = "92"
	};
	if(dec147 == o){
		s = "93"
	};
	if(dec148 == o){
		s = "94"
	};
	if(dec149 == o){
		s = "95"
	}
	if(dec150 == o){
		s = "96"
	};
	if(dec151 == o){
		s = "97"
	};
	if(dec152 == o){
		s = "98"
	};
	if(dec153 == o){
		s = "99"
	};
	if(dec154 == o){
		s = "9a"
	};
	if(dec155 == o){
		s = "9b"
	};
	if(dec156 == o){
		s = "9c"
	};
	if(dec157 == o){
		s = "9d"
	};
	if(dec158 == o){
		s = "9e"
	};
	if(dec159 == o){
		s = "9f"
	}
	if(dec160 == o){
		s = "a0"
	};
	if(dec161 == o){
		s = "a1"
	};
	if(dec162 == o){
		s = "a2"
	};
	if(dec163 == o){
		s = "a3"
	};
	if(dec164 == o){
		s = "a4"
	};
	if(dec165 == o){
		s = "a5"
	};
	if(dec166 == o){
		s = "a6"
	};
	if(dec167 == o){
		s = "a7"
	};
	if(dec168 == o){
		s = "a8"
	};
	if(dec169 == o){
		s = "a9"
	}
	if(dec170 == o){
		s = "aa"
	};
	if(dec171 == o){
		s = "ab"
	};
	if(dec172 == o){
		s = "ac"
	};
	if(dec173 == o){
		s = "ad"
	};
	if(dec174 == o){
		s = "ae"
	};
	if(dec175 == o){
		s = "af"
	};
	if(dec176 == o){
		s = "b0"
	};
	if(dec177 == o){
		s = "b1"
	};
	if(dec178 == o){
		s = "b2"
	};
	if(dec179 == o){
		s = "b3"
	}
	if(dec180 == o){
		s = "b4"
	};
	if(dec181 == o){
		s = "b5"
	};
	if(dec182 == o){
		s = "b6"
	};
	if(dec183 == o){
		s = "b7"
	};
	if(dec184 == o){
		s = "b8"
	};
	if(dec185 == o){
		s = "b9"
	};
	if(dec186 == o){
		s = "ba"
	};
	if(dec187 == o){
		s = "bb"
	};
	if(dec188 == o){
		s = "bc"
	};
	if(dec189 == o){
		s = "bd"
	}
	if(dec190 == o){
		s = "be"
	};
	if(dec191 == o){
		s = "bf"
	};
	if(dec192 == o){
		s = "c0"
	};
	if(dec193 == o){
		s = "c1"
	};
	if(dec194 == o){
		s = "c2"
	};
	if(dec195 == o){
		s = "c3"
	};
	if(dec196 == o){
		s = "c4"
	};
	if(dec197 == o){
		s = "c5"
	};
	if(dec198 == o){
		s = "c6"
	};
	if(dec199 == o){
		s = "c7"
	}
	if(dec200 == o){
		s = "c8"
	};
	if(dec201 == o){
		s = "c9"
	};
	if(dec202 == o){
		s = "ca"
	};
	if(dec203 == o){
		s = "cb"
	};
	if(dec204 == o){
		s = "cc"
	};
	if(dec205 == o){
		s = "cd"
	};
	if(dec206 == o){
		s = "ce"
	};
	if(dec207 == o){
		s = "cf"
	};
	if(dec208 == o){
		s = "d0"
	};
	if(dec209 == o){
		s = "d1"
	}
	if(dec210 == o){
		s = "d2"
	};
	if(dec211 == o){
		s = "d3"
	};
	if(dec212 == o){
		s = "d4"
	};
	if(dec213 == o){
		s = "d5"
	};
	if(dec214 == o){
		s = "d6"
	};
	if(dec215 == o){
		s = "d7"
	};
	if(dec216 == o){
		s = "d8"
	};
	if(dec217 == o){
		s = "d9"
	};
	if(dec218 == o){
		s = "da"
	};
	if(dec219 == o){
		s = "db"
	}
	if(dec220 == o){
		s = "dc"
	};
	if(dec221 == o){
		s = "dd"
	};
	if(dec222 == o){
		s = "de"
	};
	if(dec223 == o){
		s = "df"
	};
	if(dec224 == o){
		s = "e0"
	};
	if(dec225 == o){
		s = "e1"
	};
	if(dec226 == o){
		s = "e2"
	};
	if(dec227 == o){
		s = "e3"
	};
	if(dec228 == o){
		s = "e4"
	};
	if(dec229 == o){
		s = "e5"
	}
	if(dec230 == o){
		s = "e6"
	};
	if(dec231 == o){
		s = "e7"
	};
	if(dec232 == o){
		s = "e8"
	};
	if(dec233 == o){
		s = "e9"
	};
	if(dec234 == o){
		s = "ea"
	};
	if(dec235 == o){
		s = "eb"
	};
	if(dec236 == o){
		s = "ec"
	};
	if(dec237 == o){
		s = "ed"
	};
	if(dec238 == o){
		s = "ee"
	};
	if(dec239 == o){
		s = "ef"
	}
	if(dec240 == o){
		s = "f0"
	};
	if(dec241 == o){
		s = "f1"
	};
	if(dec242 == o){
		s = "f2"
	};
	if(dec243 == o){
		s = "f3"
	};
	if(dec244 == o){
		s = "f4"
	};
	if(dec245 == o){
		s = "f5"
	};
	if(dec246 == o){
		s = "f6"
	};
	if(dec247 == o){
		s = "f7"
	};
	if(dec248 == o){
		s = "f8"
	};
	if(dec249 == o){
		s = "f9"
	}
	if(dec250 == o){
		s = "fa"
	};
	if(dec251 == o){
		s = "fb"
	};
	if(dec252 == o){
		s = "fc"
	};
	if(dec253 == o){
		s = "fd"
	};
	if(dec254 == o){
		s = "fe"
	};
	if(dec255 == o){
		s = "ff"
	};
	var t = p + q + r + s;
	var nPut1 = document.getElementById("menu10").value;
	var nPut2 = document.getElementById("menu11").value;
	var u = nPut1 + "px " + nPut2 + "px ";
	document.getElementById("writersJumbler").style.boxShadow = u + t;
}
function borderAStyls(){
	var nPut = document.getElementById("menuB").value;
	document.getElementById("writersJumbler").style.borderStyle = nPut;	
}
function borderStyles(){
	var nPut1 = document.getElementById("menuB1").value;
	var nPut2 = document.getElementById("menuB2").value;
	var nPut3 = document.getElementById("menuB3").value;
	var nPut4 = document.getElementById("menuB4").value;
	var spc = " ";
	var toBrdr = nPut1 + spc + nPut2 + spc + nPut3 + spc + nPut4;
	document.getElementById("writersJumbler").style.borderStyle = toBrdr;	
}