function allFilters(){
	
	var a2 = document.getElementById("blur").value;
	var b2 = document.getElementById("brightness").value;
	var c2 = document.getElementById("contrast").value;
	var d2 = document.getElementById("grayscale").value;
	var e2 = document.getElementById("huerotate").value;
	var f2 = document.getElementById("invert").value;
	var g2 = document.getElementById("opacity").value;
	var h2 = document.getElementById("saturate").value;
	var i2 = document.getElementById("sepia").value;
	
	if(a2 >= 100){
		a2 = 100;
	};
	if(b2 >= 200){
		b2 = 200;
	};
	if(c2 >= 200){
		c2 = 200;
	};
	if(d2 >= 100){
		d2 = 100;
	};
	if(e2 >= 360){
		e2 = 360;
	};
	if(f2 >= 100){
		f2 = 100;
	};
	if(g2 >= 200){
		g2 = 200;
	};
	if(h2 >= 200){
		h2 = 200;
	};
	if(i2 >= 100){
		i2 = 100;
	};
	
	var xg2 = document.getElementById("img0002");
	var a = "blur(" + a2 + "px)";
	var b = "brightness(" + b2 + "%)";
	var c = "contrast(" + c2 + "%)";
	var d = "grayscale(" + d2 + "%)";
	var e = "hue-rotate(" + e2 + "deg)";
	var f = "invert(" + f2 + "%)";
	var g = "opacity(" + g2 + "%)";
	var h = "saturate(" + h2 + "%)";
	var i = "sepia(" + i2 + "%)";
	
	xg2.style.filter = a + b + c + d + e + f + g + h + i;
}

function backgroundCrgb(){
	var j = document.getElementById("Background_Color-R").value;
	var k = document.getElementById("Background_Color-G").value;
	var l = document.getElementById("Background_Color-B").value;
	if(j >= 255){
		j = 255;
	};
	if(k >= 255){
		k = 255;
	};
	if(l >= 255){
		l = 255;
	};
	var p = "rgb(";
	var q = ")";
	var r = p + j + ", " + k + ", " + l + q;
	document.getElementById("WJss").style.backgroundColor = r;
	
}

function fontCrgb(){
	var m = document.getElementById("Font_Color-R").value;
	var n = document.getElementById("Font_Color-G").value;
	var o = document.getElementById("Font_Color-B").value;
	if(m >= 255){
		m = 255;
	};
	if(n >= 255){
		n = 255;
	};
	if(o >= 255){
		o = 255;
	};

	var p = "rgb(";
	var q = ")";
	var s = p + m + ", " + n + ", " + o + q;
	document.getElementById("WJss").style.color = s;
}

function backgroundOrgb(){
	var j = document.getElementById("Background_Color-R1").value;
	var k = document.getElementById("Background_Color-G1").value;
	var l = document.getElementById("Background_Color-B1").value;
	if(j >= 255){
		j = 255;
	};
	if(k >= 255){
		k = 255;
	};
	if(l >= 255){
		l = 255;
	};
	var p = "rgb(";
	var q = ")";
	var r = p + j + ", " + k + ", " + l + q;
	document.getElementById("what").style.backgroundColor = r;
	document.getElementById("year").style.backgroundColor = r;
	document.getElementById("month").style.backgroundColor = r;
	document.getElementById("date").style.backgroundColor = r;
	
}

function fontOrgb(){
	var m = document.getElementById("Font_Color-R1").value;
	var n = document.getElementById("Font_Color-G1").value;
	var o = document.getElementById("Font_Color-B1").value;
	if(m >= 255){
		m = 255;
	};
	if(n >= 255){
		n = 255;
	};
	if(o >= 255){
		o = 255;
	};

	var p = "rgb(";
	var q = ")";
	var s = p + m + ", " + n + ", " + o + q;
	document.getElementById("year").style.color = s;
	document.getElementById("month").style.color = s;
	document.getElementById("date").style.color = s;
	document.getElementById("hNmNs").style.color = s;
	document.getElementById("amPm").style.color = s;
	document.getElementById("what").style.borderColor = s;
}

function sizeFilter(){
	var aBz = document.getElementById("widthNheight").value;
	var bBz = document.getElementById("widthNheight").value;
	if(aBz >= 99){
		aBz = 99;
	};
	if(bBz >= 99){
		bBz = 99;
	};
	
	document.getElementById("img0002").style.height = aBz + '%';
	document.getElementById("img0002").style.width = bBz + '%';	
}