function setThis() {
	var valuewj101 = document.getElementById("writersJumbler").value;
	var valueSave = document.getElementById("wjsvMenu").value;
	localStorage.setItem(valueSave, valuewj101);
	
	alert("Your writing has been saved locally, to your web browser's local browser storage.");
}

function getThis() {
	var valueSave = document.getElementById("wjsvMenu").value;
	var tripleZero1 = localStorage.getItem(valueSave);
	
	document.getElementById("writersJumbler").value = tripleZero1;
	
	alert("Your writing has been loaded locally, from your web browser's local browser storage.");
}
