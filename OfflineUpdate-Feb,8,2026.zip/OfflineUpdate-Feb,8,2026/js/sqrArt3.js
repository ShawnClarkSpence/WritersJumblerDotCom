function RsqrA1() {
    if(document.getElementById("aImgSqr1").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr1").src = "img/sqrs/blSqr.png"
};
};

function RsqrA2() {
    if(document.getElementById("aImgSqr2").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr2").src = "img/sqrs/blSqr.png"
};
};

function RsqrA3() {
    if(document.getElementById("aImgSqr3").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr3").src = "img/sqrs/blSqr.png"
};
};

function RsqrA4() {
    if(document.getElementById("aImgSqr4").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr4").src = "img/sqrs/blSqr.png"
};
};

function RsqrA5() {
    if(document.getElementById("aImgSqr5").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr5").src = "img/sqrs/blSqr.png"
};
};

function RsqrA6() {
    if(document.getElementById("aImgSqr6").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr6").src = "img/sqrs/blSqr.png"
};
};

function RsqrA7() {
    if(document.getElementById("aImgSqr7").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr7").src = "img/sqrs/blSqr.png"
};
};

function RsqrA8() {
    if(document.getElementById("aImgSqr8").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr8").src = "img/sqrs/blSqr.png"
};
};

function RsqrA9() {
    if(document.getElementById("aImgSqr9").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr9").src = "img/sqrs/blSqr.png"
};
};

function RsqrA10() {
    if(document.getElementById("aImgSqr10").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr10").src = "img/sqrs/blSqr.png"
};
};

function RsqrA11() {
    if(document.getElementById("aImgSqr11").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr11").src = "img/sqrs/blSqr.png"
};
};

function RsqrA12() {
    if(document.getElementById("aImgSqr12").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr12").src = "img/sqrs/blSqr.png"
};
};

function RsqrA13() {
    if(document.getElementById("aImgSqr13").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr13").src = "img/sqrs/blSqr.png"
};
};

function RsqrA14() {
    if(document.getElementById("aImgSqr14").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr14").src = "img/sqrs/blSqr.png"
};
};

function RsqrA15() {
    if(document.getElementById("aImgSqr15").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr15").src = "img/sqrs/blSqr.png"
};
};

function RsqrA16() {
    if(document.getElementById("aImgSqr16").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr16").src = "img/sqrs/blSqr.png"
};
};

function RsqrA17() {
    if(document.getElementById("aImgSqr17").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr17").src = "img/sqrs/blSqr.png"
};
};

function RsqrA18() {
    if(document.getElementById("aImgSqr18").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr18").src = "img/sqrs/blSqr.png"
};
};

function RsqrA19() {
    if(document.getElementById("aImgSqr19").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr19").src = "img/sqrs/blSqr.png"
};
};

function RsqrA20() {
    if(document.getElementById("aImgSqr20").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr20").src = "img/sqrs/blSqr.png"
};
};

function RsqrA21() {
    if(document.getElementById("aImgSqr21").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr21").src = "img/sqrs/blSqr.png"
};
};

function RsqrA22() {
    if(document.getElementById("aImgSqr22").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr22").src = "img/sqrs/blSqr.png"
};
};

function RsqrA23() {
    if(document.getElementById("aImgSqr23").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr23").src = "img/sqrs/blSqr.png"
};
};

function RsqrA24() {
    if(document.getElementById("aImgSqr24").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr24").src = "img/sqrs/blSqr.png"
};
};

function RsqrA25() {
    if(document.getElementById("aImgSqr25").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr25").src = "img/sqrs/blSqr.png"
};
};

function RsqrB1() {
    if(document.getElementById("aImgSqr26").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr26").src = "img/sqrs/blSqr.png"
};
};

function RsqrB2() {
    if(document.getElementById("aImgSqr27").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr27").src = "img/sqrs/blSqr.png"
};
};

function RsqrB3() {
    if(document.getElementById("aImgSqr28").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr28").src = "img/sqrs/blSqr.png"
};
};

function RsqrB4() {
    if(document.getElementById("aImgSqr29").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr29").src = "img/sqrs/blSqr.png"
};
};

function RsqrB5() {
    if(document.getElementById("aImgSqr30").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr30").src = "img/sqrs/blSqr.png"
};
};

function RsqrB6() {
    if(document.getElementById("aImgSqr31").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr31").src = "img/sqrs/blSqr.png"
};
};

function RsqrB7() {
    if(document.getElementById("aImgSqr32").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr32").src = "img/sqrs/blSqr.png"
};
};

function RsqrB8() {
    if(document.getElementById("aImgSqr33").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr33").src = "img/sqrs/blSqr.png"
};
};

function RsqrB9() {
    if(document.getElementById("aImgSqr34").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr34").src = "img/sqrs/blSqr.png"
};
};

function RsqrB10() {
    if(document.getElementById("aImgSqr35").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr35").src = "img/sqrs/blSqr.png"
};
};

function RsqrB11() {
    if(document.getElementById("aImgSqr36").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr36").src = "img/sqrs/blSqr.png"
};
};

function RsqrB12() {
    if(document.getElementById("aImgSqr37").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr37").src = "img/sqrs/blSqr.png"
};
};

function RsqrB13() {
    if(document.getElementById("aImgSqr38").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr38").src = "img/sqrs/blSqr.png"
};
};

function RsqrB14() {
    if(document.getElementById("aImgSqr39").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr39").src = "img/sqrs/blSqr.png"
};
};

function RsqrB15() {
    if(document.getElementById("aImgSqr40").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr40").src = "img/sqrs/blSqr.png"
};
};

function RsqrB16() {
    if(document.getElementById("aImgSqr41").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr41").src = "img/sqrs/blSqr.png"
};
};

function RsqrB17() {
    if(document.getElementById("aImgSqr42").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr42").src = "img/sqrs/blSqr.png"
};
};

function RsqrB18() {
    if(document.getElementById("aImgSqr43").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr43").src = "img/sqrs/blSqr.png"
};
};

function RsqrB19() {
    if(document.getElementById("aImgSqr44").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr44").src = "img/sqrs/blSqr.png"
};
};

function RsqrB20() {
    if(document.getElementById("aImgSqr45").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr45").src = "img/sqrs/blSqr.png"
};
};

function RsqrB21() {
    if(document.getElementById("aImgSqr46").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr46").src = "img/sqrs/blSqr.png"
};
};

function RsqrB22() {
    if(document.getElementById("aImgSqr47").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr47").src = "img/sqrs/blSqr.png"
};
};

function RsqrB23() {
    if(document.getElementById("aImgSqr48").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr48").src = "img/sqrs/blSqr.png"
};
};

function RsqrB24() {
    if(document.getElementById("aImgSqr49").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr49").src = "img/sqrs/blSqr.png"
};
};

function RsqrB25() {
    if(document.getElementById("aImgSqr50").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr50").src = "img/sqrs/blSqr.png"
};
};

function RsqrC1() {
    if(document.getElementById("aImgSqr51").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr51").src = "img/sqrs/blSqr.png"
};
};

function RsqrC2() {
    if(document.getElementById("aImgSqr52").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr52").src = "img/sqrs/blSqr.png"
};
};

function RsqrC3() {
    if(document.getElementById("aImgSqr53").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr53").src = "img/sqrs/blSqr.png"
};
};

function RsqrC4() {
    if(document.getElementById("aImgSqr54").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr54").src = "img/sqrs/blSqr.png"
};
};

function RsqrC5() {
    if(document.getElementById("aImgSqr55").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr55").src = "img/sqrs/blSqr.png"
};
};

function RsqrC6() {
    if(document.getElementById("aImgSqr56").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr56").src = "img/sqrs/blSqr.png"
};
};

function RsqrC7() {
    if(document.getElementById("aImgSqr57").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr57").src = "img/sqrs/blSqr.png"
};
};

function RsqrC8() {
    if(document.getElementById("aImgSqr58").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr58").src = "img/sqrs/blSqr.png"
};
};

function RsqrC9() {
    if(document.getElementById("aImgSqr59").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr59").src = "img/sqrs/blSqr.png"
};
};

function RsqrC10() {
    if(document.getElementById("aImgSqr60").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr60").src = "img/sqrs/blSqr.png"
};
};

function RsqrC11() {
    if(document.getElementById("aImgSqr61").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr61").src = "img/sqrs/blSqr.png"
};
};

function RsqrC12() {
    if(document.getElementById("aImgSqr62").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr62").src = "img/sqrs/blSqr.png"
};
};

function RsqrC13() {
    if(document.getElementById("aImgSqr63").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr63").src = "img/sqrs/blSqr.png"
};
};

function RsqrC14() {
    if(document.getElementById("aImgSqr64").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr64").src = "img/sqrs/blSqr.png"
};
};

function RsqrC15() {
    if(document.getElementById("aImgSqr65").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr65").src = "img/sqrs/blSqr.png"
};
};

function RsqrC16() {
    if(document.getElementById("aImgSqr66").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr66").src = "img/sqrs/blSqr.png"
};
};

function RsqrC17() {
    if(document.getElementById("aImgSqr67").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr67").src = "img/sqrs/blSqr.png"
};
};

function RsqrC18() {
    if(document.getElementById("aImgSqr68").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr68").src = "img/sqrs/blSqr.png"
};
};

function RsqrC19() {
    if(document.getElementById("aImgSqr69").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr69").src = "img/sqrs/blSqr.png"
};
};

function RsqrC20() {
    if(document.getElementById("aImgSqr70").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr70").src = "img/sqrs/blSqr.png"
};
};

function RsqrC21() {
    if(document.getElementById("aImgSqr71").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr71").src = "img/sqrs/blSqr.png"
};
};

function RsqrC22() {
    if(document.getElementById("aImgSqr72").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr72").src = "img/sqrs/blSqr.png"
};
};

function RsqrC23() {
    if(document.getElementById("aImgSqr73").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr73").src = "img/sqrs/blSqr.png"
};
};

function RsqrC24() {
    if(document.getElementById("aImgSqr74").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr74").src = "img/sqrs/blSqr.png"
};
};

function RsqrC25() {
    if(document.getElementById("aImgSqr75").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr75").src = "img/sqrs/blSqr.png"
 };
};

function RsqrD1() {
    if(document.getElementById("aImgSqr76").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr76").src = "img/sqrs/blSqr.png"
};
};

function RsqrD2() {
    if(document.getElementById("aImgSqr77").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr77").src = "img/sqrs/blSqr.png"
};
};

function RsqrD3() {
    if(document.getElementById("aImgSqr78").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr78").src = "img/sqrs/blSqr.png"
};
};

function RsqrD4() {
    if(document.getElementById("aImgSqr79").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr79").src = "img/sqrs/blSqr.png"
};
};

function RsqrD5() {
    if(document.getElementById("aImgSqr80").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr80").src = "img/sqrs/blSqr.png"
};
};

function RsqrD6() {
    if(document.getElementById("aImgSqr81").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr81").src = "img/sqrs/blSqr.png"
};
};

function RsqrD7() {
    if(document.getElementById("aImgSqr82").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr82").src = "img/sqrs/blSqr.png"
};
};

function RsqrD8() {
    if(document.getElementById("aImgSqr83").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr83").src = "img/sqrs/blSqr.png"
};
};

function RsqrD9() {
    if(document.getElementById("aImgSqr84").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr84").src = "img/sqrs/blSqr.png"
};
};

function RsqrD10() {
    if(document.getElementById("aImgSqr85").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr85").src = "img/sqrs/blSqr.png"
};
};

function RsqrD11() {
    if(document.getElementById("aImgSqr86").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr86").src = "img/sqrs/blSqr.png"
};
};

function RsqrD12() {
    if(document.getElementById("aImgSqr87").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr87").src = "img/sqrs/blSqr.png"
};
};

function RsqrD13() {
    if(document.getElementById("aImgSqr88").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr88").src = "img/sqrs/blSqr.png"
};
};

function RsqrD14() {
    if(document.getElementById("aImgSqr89").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr89").src = "img/sqrs/blSqr.png"
};
};

function RsqrD15() {
    if(document.getElementById("aImgSqr90").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr90").src = "img/sqrs/blSqr.png"
};
};

function RsqrD16() {
    if(document.getElementById("aImgSqr91").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr91").src = "img/sqrs/blSqr.png"
};
};

function RsqrD17() {
    if(document.getElementById("aImgSqr92").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr92").src = "img/sqrs/blSqr.png"
};
};

function RsqrD18() {
    if(document.getElementById("aImgSqr93").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr93").src = "img/sqrs/blSqr.png"
};
};

function RsqrD19() {
    if(document.getElementById("aImgSqr94").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr94").src = "img/sqrs/blSqr.png"
};
};

function RsqrD20() {
    if(document.getElementById("aImgSqr95").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr95").src = "img/sqrs/blSqr.png"
};
};

function RsqrD21() {
    if(document.getElementById("aImgSqr96").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr96").src = "img/sqrs/blSqr.png"
};
};

function RsqrD22() {
    if(document.getElementById("aImgSqr97").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr97").src = "img/sqrs/blSqr.png"
};
};

function RsqrD23() {
    if(document.getElementById("aImgSqr98").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr98").src = "img/sqrs/blSqr.png"
};
};

function RsqrD24() {
    if(document.getElementById("aImgSqr99").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr99").src = "img/sqrs/blSqr.png"
};
};

function RsqrD25() {
    if(document.getElementById("aImgSqr100").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr100").src = "img/sqrs/blSqr.png"
 };
};

function RsqrE1() {
    if(document.getElementById("aImgSqr101").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr101").src = "img/sqrs/blSqr.png"
};
};

function RsqrE2() {
    if(document.getElementById("aImgSqr102").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr102").src = "img/sqrs/blSqr.png"
};
};

function RsqrE3() {
    if(document.getElementById("aImgSqr103").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr103").src = "img/sqrs/blSqr.png"
};
};

function RsqrE4() {
    if(document.getElementById("aImgSqr104").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr104").src = "img/sqrs/blSqr.png"
};
};

function RsqrE5() {
    if(document.getElementById("aImgSqr105").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr105").src = "img/sqrs/blSqr.png"
};
};

function RsqrE6() {
    if(document.getElementById("aImgSqr106").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr106").src = "img/sqrs/blSqr.png"
};
};

function RsqrE7() {
    if(document.getElementById("aImgSqr107").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr107").src = "img/sqrs/blSqr.png"
};
};

function RsqrE8() {
    if(document.getElementById("aImgSqr108").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr108").src = "img/sqrs/blSqr.png"
};
};

function RsqrE9() {
    if(document.getElementById("aImgSqr109").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr109").src = "img/sqrs/blSqr.png"
};
};

function RsqrE10() {
    if(document.getElementById("aImgSqr100").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr110").src = "img/sqrs/blSqr.png"
};
};

function RsqrE11() {
    if(document.getElementById("aImgSqr111").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr111").src = "img/sqrs/blSqr.png"
};
};

function RsqrE12() {
    if(document.getElementById("aImgSqr112").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr112").src = "img/sqrs/blSqr.png"
};
};

function RsqrE13() {
    if(document.getElementById("aImgSqr113").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr113").src = "img/sqrs/blSqr.png"
};
};

function RsqrE14() {
    if(document.getElementById("aImgSqr114").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr114").src = "img/sqrs/blSqr.png"
};
};

function RsqrE15() {
    if(document.getElementById("aImgSqr115").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr115").src = "img/sqrs/blSqr.png"
};
};

function RsqrE16() {
    if(document.getElementById("aImgSqr116").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr116").src = "img/sqrs/blSqr.png"
};
};

function RsqrE17() {
    if(document.getElementById("aImgSqr117").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr117").src = "img/sqrs/blSqr.png"
};
};

function RsqrE18() {
    if(document.getElementById("aImgSqr118").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr118").src = "img/sqrs/blSqr.png"
};
};

function RsqrE19() {
    if(document.getElementById("aImgSqr119").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr119").src = "img/sqrs/blSqr.png"
};
};

function RsqrE20() {
    if(document.getElementById("aImgSqr120").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr120").src = "img/sqrs/blSqr.png"
};
};

function RsqrE21() {
    if(document.getElementById("aImgSqr121").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr121").src = "img/sqrs/blSqr.png"
};
};

function RsqrE22() {
    if(document.getElementById("aImgSqr122").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr122").src = "img/sqrs/blSqr.png"
};
};

function RsqrE23() {
    if(document.getElementById("aImgSqr123").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr123").src = "img/sqrs/blSqr.png"
};
};

function RsqrE24() {
    if(document.getElementById("aImgSqr124").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr124").src = "img/sqrs/blSqr.png"
};
};

function RsqrE25() {
    if(document.getElementById("aImgSqr125").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr125").src = "img/sqrs/blSqr.png"
 };
};

function RsqrF1() {
    if(document.getElementById("aImgSqr126").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr126").src = "img/sqrs/blSqr.png"
};
};

function RsqrF2() {
    if(document.getElementById("aImgSqr127").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr127").src = "img/sqrs/blSqr.png"
};
};

function RsqrF3() {
    if(document.getElementById("aImgSqr128").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr128").src = "img/sqrs/blSqr.png"
};
};

function RsqrF4() {
    if(document.getElementById("aImgSqr129").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr129").src = "img/sqrs/blSqr.png"
};
};

function RsqrF5() {
    if(document.getElementById("aImgSqr130").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr130").src = "img/sqrs/blSqr.png"
};
};

function RsqrF6() {
    if(document.getElementById("aImgSqr131").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr131").src = "img/sqrs/blSqr.png"
};
};

function RsqrF7() {
    if(document.getElementById("aImgSqr132").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr132").src = "img/sqrs/blSqr.png"
};
};

function RsqrF8() {
    if(document.getElementById("aImgSqr133").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr133").src = "img/sqrs/blSqr.png"
};
};

function RsqrF9() {
    if(document.getElementById("aImgSqr134").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr134").src = "img/sqrs/blSqr.png"
};
};

function RsqrF10() {
    if(document.getElementById("aImgSqr135").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr135").src = "img/sqrs/blSqr.png"
};
};

function RsqrF11() {
    if(document.getElementById("aImgSqr136").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr136").src = "img/sqrs/blSqr.png"
};
};

function RsqrF12() {
    if(document.getElementById("aImgSqr137").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr137").src = "img/sqrs/blSqr.png"
};
};

function RsqrF13() {
    if(document.getElementById("aImgSqr138").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr138").src = "img/sqrs/blSqr.png"
};
};

function RsqrF14() {
    if(document.getElementById("aImgSqr139").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr139").src = "img/sqrs/blSqr.png"
};
};

function RsqrF15() {
    if(document.getElementById("aImgSqr140").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr140").src = "img/sqrs/blSqr.png"
};
};

function RsqrF16() {
    if(document.getElementById("aImgSqr141").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr141").src = "img/sqrs/blSqr.png"
};
};

function RsqrF17() {
    if(document.getElementById("aImgSqr142").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr142").src = "img/sqrs/blSqr.png"
};
};

function RsqrF18() {
    if(document.getElementById("aImgSqr143").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr143").src = "img/sqrs/blSqr.png"
};
};

function RsqrF19() {
    if(document.getElementById("aImgSqr144").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr144").src = "img/sqrs/blSqr.png"
};
};

function RsqrF20() {
    if(document.getElementById("aImgSqr145").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr145").src = "img/sqrs/blSqr.png"
};
};

function RsqrF21() {
    if(document.getElementById("aImgSqr146").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr146").src = "img/sqrs/blSqr.png"
};
};

function RsqrF22() {
    if(document.getElementById("aImgSqr147").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr147").src = "img/sqrs/blSqr.png"
};
};

function RsqrF23() {
    if(document.getElementById("aImgSqr148").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr148").src = "img/sqrs/blSqr.png"
};
};

function RsqrF24() {
    if(document.getElementById("aImgSqr149").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr149").src = "img/sqrs/blSqr.png"
};
};

function RsqrF25() {
    if(document.getElementById("aImgSqr150").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr150").src = "img/sqrs/blSqr.png"
 };
};

function RsqrG1() {
    if(document.getElementById("aImgSqr151").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr151").src = "img/sqrs/blSqr.png"
};
};

function RsqrG2() {
    if(document.getElementById("aImgSqr152").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr152").src = "img/sqrs/blSqr.png"
};
};

function RsqrG3() {
    if(document.getElementById("aImgSqr153").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr153").src = "img/sqrs/blSqr.png"
};
};

function RsqrG4() {
    if(document.getElementById("aImgSqr154").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr154").src = "img/sqrs/blSqr.png"
};
};

function RsqrG5() {
    if(document.getElementById("aImgSqr155").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr155").src = "img/sqrs/blSqr.png"
};
};

function RsqrG6() {
    if(document.getElementById("aImgSqr156").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr156").src = "img/sqrs/blSqr.png"
};
};

function RsqrG7() {
    if(document.getElementById("aImgSqr157").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr157").src = "img/sqrs/blSqr.png"
};
};

function RsqrG8() {
    if(document.getElementById("aImgSqr158").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr158").src = "img/sqrs/blSqr.png"
};
};

function RsqrG9() {
    if(document.getElementById("aImgSqr159").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr159").src = "img/sqrs/blSqr.png"
};
};

function RsqrG10() {
    if(document.getElementById("aImgSqr160").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr160").src = "img/sqrs/blSqr.png"
};
};

function RsqrG11() {
    if(document.getElementById("aImgSqr161").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr161").src = "img/sqrs/blSqr.png"
};
};

function RsqrG12() {
    if(document.getElementById("aImgSqr162").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr162").src = "img/sqrs/blSqr.png"
};
};

function RsqrG13() {
    if(document.getElementById("aImgSqr163").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr163").src = "img/sqrs/blSqr.png"
};
};

function RsqrG14() {
    if(document.getElementById("aImgSqr164").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr164").src = "img/sqrs/blSqr.png"
};
};

function RsqrG15() {
    if(document.getElementById("aImgSqr165").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr165").src = "img/sqrs/blSqr.png"
};
};

function RsqrG16() {
    if(document.getElementById("aImgSqr166").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr166").src = "img/sqrs/blSqr.png"
};
};

function RsqrG17() {
    if(document.getElementById("aImgSqr167").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr167").src = "img/sqrs/blSqr.png"
};
};

function RsqrG18() {
    if(document.getElementById("aImgSqr168").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr168").src = "img/sqrs/blSqr.png"
};
};

function RsqrG19() {
    if(document.getElementById("aImgSqr169").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr169").src = "img/sqrs/blSqr.png"
};
};

function RsqrG20() {
    if(document.getElementById("aImgSqr170").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr170").src = "img/sqrs/blSqr.png"
};
};

function RsqrG21() {
    if(document.getElementById("aImgSqr171").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr171").src = "img/sqrs/blSqr.png"
};
};

function RsqrG22() {
    if(document.getElementById("aImgSqr172").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr172").src = "img/sqrs/blSqr.png"
};
};

function RsqrG23() {
    if(document.getElementById("aImgSqr173").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr173").src = "img/sqrs/blSqr.png"
};
};

function RsqrG24() {
    if(document.getElementById("aImgSqr174").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr174").src = "img/sqrs/blSqr.png"
};
};

function RsqrG25() {
    if(document.getElementById("aImgSqr175").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr175").src = "img/sqrs/blSqr.png"
 };
};

function RsqrH1() {
    if(document.getElementById("aImgSqr176").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr176").src = "img/sqrs/blSqr.png"
};
};

function RsqrH2() {
    if(document.getElementById("aImgSqr177").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr177").src = "img/sqrs/blSqr.png"
};
};

function RsqrH3() {
    if(document.getElementById("aImgSqr178").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr178").src = "img/sqrs/blSqr.png"
};
};

function RsqrH4() {
    if(document.getElementById("aImgSqr179").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr179").src = "img/sqrs/blSqr.png"
};
};

function RsqrH5() {
    if(document.getElementById("aImgSqr180").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr180").src = "img/sqrs/blSqr.png"
};
};

function RsqrH6() {
    if(document.getElementById("aImgSqr181").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr181").src = "img/sqrs/blSqr.png"
};
};

function RsqrH7() {
    if(document.getElementById("aImgSqr182").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr182").src = "img/sqrs/blSqr.png"
};
};

function RsqrH8() {
    if(document.getElementById("aImgSqr183").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr183").src = "img/sqrs/blSqr.png"
};
};

function RsqrH9() {
    if(document.getElementById("aImgSqr184").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr184").src = "img/sqrs/blSqr.png"
};
};

function RsqrH10() {
    if(document.getElementById("aImgSqr185").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr185").src = "img/sqrs/blSqr.png"
};
};

function RsqrH11() {
    if(document.getElementById("aImgSqr186").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr186").src = "img/sqrs/blSqr.png"
};
};

function RsqrH12() {
    if(document.getElementById("aImgSqr187").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr187").src = "img/sqrs/blSqr.png"
};
};

function RsqrH13() {
    if(document.getElementById("aImgSqr188").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr188").src = "img/sqrs/blSqr.png"
};
};

function RsqrH14() {
    if(document.getElementById("aImgSqr189").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr189").src = "img/sqrs/blSqr.png"
};
};

function RsqrH15() {
    if(document.getElementById("aImgSqr190").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr190").src = "img/sqrs/blSqr.png"
};
};

function RsqrH16() {
    if(document.getElementById("aImgSqr191").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr191").src = "img/sqrs/blSqr.png"
};
};

function RsqrH17() {
    if(document.getElementById("aImgSqr192").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr192").src = "img/sqrs/blSqr.png"
};
};

function RsqrH18() {
    if(document.getElementById("aImgSqr193").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr193").src = "img/sqrs/blSqr.png"
};
};

function RsqrH19() {
    if(document.getElementById("aImgSqr194").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr194").src = "img/sqrs/blSqr.png"
};
};

function RsqrH20() {
    if(document.getElementById("aImgSqr195").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr195").src = "img/sqrs/blSqr.png"
};
};

function RsqrH21() {
    if(document.getElementById("aImgSqr196").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr196").src = "img/sqrs/blSqr.png"
};
};

function RsqrH22() {
    if(document.getElementById("aImgSqr197").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr197").src = "img/sqrs/blSqr.png"
};
};

function RsqrH23() {
    if(document.getElementById("aImgSqr198").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr198").src = "img/sqrs/blSqr.png"
};
};

function RsqrH24() {
    if(document.getElementById("aImgSqr199").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr199").src = "img/sqrs/blSqr.png"
};
};

function RsqrH25() {
    if(document.getElementById("aImgSqr200").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr200").src = "img/sqrs/blSqr.png"
 };
};

function RsqrI1() {
    if(document.getElementById("aImgSqr201").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr201").src = "img/sqrs/blSqr.png"
};
};

function RsqrI2() {
    if(document.getElementById("aImgSqr202").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr202").src = "img/sqrs/blSqr.png"
};
};

function RsqrI3() {
    if(document.getElementById("aImgSqr203").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr203").src = "img/sqrs/blSqr.png"
};
};

function RsqrI4() {
    if(document.getElementById("aImgSqr204").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr204").src = "img/sqrs/blSqr.png"
};
};

function RsqrI5() {
    if(document.getElementById("aImgSqr205").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr205").src = "img/sqrs/blSqr.png"
};
};

function RsqrI6() {
    if(document.getElementById("aImgSqr206").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr206").src = "img/sqrs/blSqr.png"
};
};

function RsqrI7() {
    if(document.getElementById("aImgSqr207").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr207").src = "img/sqrs/blSqr.png"
};
};

function RsqrI8() {
    if(document.getElementById("aImgSqr208").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr208").src = "img/sqrs/blSqr.png"
};
};

function RsqrI9() {
    if(document.getElementById("aImgSqr209").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr209").src = "img/sqrs/blSqr.png"
};
};

function RsqrI10() {
    if(document.getElementById("aImgSqr210").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr210").src = "img/sqrs/blSqr.png"
};
};

function RsqrI11() {
    if(document.getElementById("aImgSqr211").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr211").src = "img/sqrs/blSqr.png"
};
};

function RsqrI12() {
    if(document.getElementById("aImgSqr212").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr212").src = "img/sqrs/blSqr.png"
};
};

function RsqrI13() {
    if(document.getElementById("aImgSqr213").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr213").src = "img/sqrs/blSqr.png"
};
};

function RsqrI14() {
    if(document.getElementById("aImgSqr214").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr214").src = "img/sqrs/blSqr.png"
};
};

function RsqrI15() {
    if(document.getElementById("aImgSqr215").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr215").src = "img/sqrs/blSqr.png"
};
};

function RsqrI16() {
    if(document.getElementById("aImgSqr216").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr216").src = "img/sqrs/blSqr.png"
};
};

function RsqrI17() {
    if(document.getElementById("aImgSqr217").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr217").src = "img/sqrs/blSqr.png"
};
};

function RsqrI18() {
    if(document.getElementById("aImgSqr218").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr218").src = "img/sqrs/blSqr.png"
};
};

function RsqrI19() {
    if(document.getElementById("aImgSqr219").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr219").src = "img/sqrs/blSqr.png"
};
};

function RsqrI20() {
    if(document.getElementById("aImgSqr220").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr220").src = "img/sqrs/blSqr.png"
};
};

function RsqrI21() {
    if(document.getElementById("aImgSqr221").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr221").src = "img/sqrs/blSqr.png"
};
};

function RsqrI22() {
    if(document.getElementById("aImgSqr222").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr222").src = "img/sqrs/blSqr.png"
};
};

function RsqrI23() {
    if(document.getElementById("aImgSqr223").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr223").src = "img/sqrs/blSqr.png"
};
};

function RsqrI24() {
    if(document.getElementById("aImgSqr224").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr224").src = "img/sqrs/blSqr.png"
};
};

function RsqrI25() {
    if(document.getElementById("aImgSqr225").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr225").src = "img/sqrs/blSqr.png"
 };
};

function RsqrJ1() {
    if(document.getElementById("aImgSqr226").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr226").src = "img/sqrs/blSqr.png"
};
};

function RsqrJ2() {
    if(document.getElementById("aImgSqr227").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr227").src = "img/sqrs/blSqr.png"
};
};

function RsqrJ3() {
    if(document.getElementById("aImgSqr228").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr228").src = "img/sqrs/blSqr.png"
};
};

function RsqrJ4() {
    if(document.getElementById("aImgSqr229").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr229").src = "img/sqrs/blSqr.png"
};
};

function RsqrJ5() {
    if(document.getElementById("aImgSqr230").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr230").src = "img/sqrs/blSqr.png"
};
};

function RsqrJ6() {
    if(document.getElementById("aImgSqr231").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr231").src = "img/sqrs/blSqr.png"
};
};

function RsqrJ7() {
    if(document.getElementById("aImgSqr232").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr232").src = "img/sqrs/blSqr.png"
};
};

function RsqrJ8() {
    if(document.getElementById("aImgSqr233").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr233").src = "img/sqrs/blSqr.png"
};
};

function RsqrJ9() {
    if(document.getElementById("aImgSqr234").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr234").src = "img/sqrs/blSqr.png"
};
};

function RsqrJ10() {
    if(document.getElementById("aImgSqr235").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr235").src = "img/sqrs/blSqr.png"
};
};

function RsqrJ11() {
    if(document.getElementById("aImgSqr236").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr236").src = "img/sqrs/blSqr.png"
};
};

function RsqrJ12() {
    if(document.getElementById("aImgSqr237").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr237").src = "img/sqrs/blSqr.png"
};
};

function RsqrJ13() {
    if(document.getElementById("aImgSqr238").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr238").src = "img/sqrs/blSqr.png"
};
};

function RsqrJ14() {
    if(document.getElementById("aImgSqr239").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr239").src = "img/sqrs/blSqr.png"
};
};

function RsqrJ15() {
    if(document.getElementById("aImgSqr240").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr240").src = "img/sqrs/blSqr.png"
};
};

function RsqrJ16() {
    if(document.getElementById("aImgSqr241").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr241").src = "img/sqrs/blSqr.png"
};
};

function RsqrJ17() {
    if(document.getElementById("aImgSqr242").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr242").src = "img/sqrs/blSqr.png"
};
};

function RsqrJ18() {
    if(document.getElementById("aImgSqr243").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr243").src = "img/sqrs/blSqr.png"
};
};

function RsqrJ19() {
    if(document.getElementById("aImgSqr244").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr244").src = "img/sqrs/blSqr.png"
};
};

function RsqrJ20() {
    if(document.getElementById("aImgSqr245").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr245").src = "img/sqrs/blSqr.png"
};
};

function RsqrJ21() {
    if(document.getElementById("aImgSqr246").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr246").src = "img/sqrs/blSqr.png"
};
};

function RsqrJ22() {
    if(document.getElementById("aImgSqr247").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr247").src = "img/sqrs/blSqr.png"
};
};

function RsqrJ23() {
    if(document.getElementById("aImgSqr248").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr248").src = "img/sqrs/blSqr.png"
};
};

function RsqrJ24() {
    if(document.getElementById("aImgSqr249").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr249").src = "img/sqrs/blSqr.png"
};
};

function RsqrJ25() {
    if(document.getElementById("aImgSqr250").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr250").src = "img/sqrs/blSqr.png"
 };
};

function RsqrK1() {
    if(document.getElementById("aImgSqr251").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr251").src = "img/sqrs/blSqr.png"
};
};

function RsqrK2() {
    if(document.getElementById("aImgSqr252").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr252").src = "img/sqrs/blSqr.png"
};
};

function RsqrK3() {
    if(document.getElementById("aImgSqr253").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr253").src = "img/sqrs/blSqr.png"
};
};

function RsqrK4() {
    if(document.getElementById("aImgSqr254").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr254").src = "img/sqrs/blSqr.png"
};
};

function RsqrK5() {
    if(document.getElementById("aImgSqr255").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr255").src = "img/sqrs/blSqr.png"
};
};

function RsqrK6() {
    if(document.getElementById("aImgSqr256").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr256").src = "img/sqrs/blSqr.png"
};
};

function RsqrK7() {
    if(document.getElementById("aImgSqr257").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr257").src = "img/sqrs/blSqr.png"
};
};

function RsqrK8() {
    if(document.getElementById("aImgSqr258").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr258").src = "img/sqrs/blSqr.png"
};
};

function RsqrK9() {
    if(document.getElementById("aImgSqr259").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr259").src = "img/sqrs/blSqr.png"
};
};

function RsqrK10() {
    if(document.getElementById("aImgSqr260").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr260").src = "img/sqrs/blSqr.png"
};
};

function RsqrK11() {
    if(document.getElementById("aImgSqr261").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr261").src = "img/sqrs/blSqr.png"
};
};

function RsqrK12() {
    if(document.getElementById("aImgSqr262").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr262").src = "img/sqrs/blSqr.png"
};
};

function RsqrK13() {
    if(document.getElementById("aImgSqr263").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr263").src = "img/sqrs/blSqr.png"
};
};

function RsqrK14() {
    if(document.getElementById("aImgSqr264").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr264").src = "img/sqrs/blSqr.png"
};
};

function RsqrK15() {
    if(document.getElementById("aImgSqr265").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr265").src = "img/sqrs/blSqr.png"
};
};

function RsqrK16() {
    if(document.getElementById("aImgSqr266").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr266").src = "img/sqrs/blSqr.png"
};
};

function RsqrK17() {
    if(document.getElementById("aImgSqr267").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr267").src = "img/sqrs/blSqr.png"
};
};

function RsqrK18() {
    if(document.getElementById("aImgSqr268").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr268").src = "img/sqrs/blSqr.png"
};
};

function RsqrK19() {
    if(document.getElementById("aImgSqr269").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr269").src = "img/sqrs/blSqr.png"
};
};

function RsqrK20() {
    if(document.getElementById("aImgSqr270").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr270").src = "img/sqrs/blSqr.png"
};
};

function RsqrK21() {
    if(document.getElementById("aImgSqr271").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr271").src = "img/sqrs/blSqr.png"
};
};

function RsqrK22() {
    if(document.getElementById("aImgSqr272").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr272").src = "img/sqrs/blSqr.png"
};
};

function RsqrK23() {
    if(document.getElementById("aImgSqr273").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr273").src = "img/sqrs/blSqr.png"
};
};

function RsqrK24() {
    if(document.getElementById("aImgSqr274").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr274").src = "img/sqrs/blSqr.png"
};
};

function RsqrK25() {
    if(document.getElementById("aImgSqr275").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr275").src = "img/sqrs/blSqr.png"
 };
};

function RsqrL1() {
    if(document.getElementById("aImgSqr276").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr276").src = "img/sqrs/blSqr.png"
};
};

function RsqrL2() {
    if(document.getElementById("aImgSqr277").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr277").src = "img/sqrs/blSqr.png"
};
};

function RsqrL3() {
    if(document.getElementById("aImgSqr278").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr278").src = "img/sqrs/blSqr.png"
};
};

function RsqrL4() {
    if(document.getElementById("aImgSqr279").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr279").src = "img/sqrs/blSqr.png"
};
};

function RsqrL5() {
    if(document.getElementById("aImgSqr280").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr280").src = "img/sqrs/blSqr.png"
};
};

function RsqrL6() {
    if(document.getElementById("aImgSqr281").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr281").src = "img/sqrs/blSqr.png"
};
};

function RsqrL7() {
    if(document.getElementById("aImgSqr282").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr282").src = "img/sqrs/blSqr.png"
};
};

function RsqrL8() {
    if(document.getElementById("aImgSqr283").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr283").src = "img/sqrs/blSqr.png"
};
};

function RsqrL9() {
    if(document.getElementById("aImgSqr284").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr284").src = "img/sqrs/blSqr.png"
};
};

function RsqrL10() {
    if(document.getElementById("aImgSqr285").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr285").src = "img/sqrs/blSqr.png"
};
};

function RsqrL11() {
    if(document.getElementById("aImgSqr286").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr286").src = "img/sqrs/blSqr.png"
};
};

function RsqrL12() {
    if(document.getElementById("aImgSqr287").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr287").src = "img/sqrs/blSqr.png"
};
};

function RsqrL13() {
    if(document.getElementById("aImgSqr288").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr288").src = "img/sqrs/blSqr.png"
};
};

function RsqrL14() {
    if(document.getElementById("aImgSqr289").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr289").src = "img/sqrs/blSqr.png"
};
};

function RsqrL15() {
    if(document.getElementById("aImgSqr290").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr290").src = "img/sqrs/blSqr.png"
};
};

function RsqrL16() {
    if(document.getElementById("aImgSqr291").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr291").src = "img/sqrs/blSqr.png"
};
};

function RsqrL17() {
    if(document.getElementById("aImgSqr292").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr292").src = "img/sqrs/blSqr.png"
};
};

function RsqrL18() {
    if(document.getElementById("aImgSqr293").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr293").src = "img/sqrs/blSqr.png"
};
};

function RsqrL19() {
    if(document.getElementById("aImgSqr294").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr294").src = "img/sqrs/blSqr.png"
};
};

function RsqrL20() {
    if(document.getElementById("aImgSqr295").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr295").src = "img/sqrs/blSqr.png"
};
};

function RsqrL21() {
    if(document.getElementById("aImgSqr296").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr296").src = "img/sqrs/blSqr.png"
};
};

function RsqrL22() {
    if(document.getElementById("aImgSqr297").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr297").src = "img/sqrs/blSqr.png"
};
};

function RsqrL23() {
    if(document.getElementById("aImgSqr298").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr298").src = "img/sqrs/blSqr.png"
};
};

function RsqrL24() {
    if(document.getElementById("aImgSqr299").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr299").src = "img/sqrs/blSqr.png"
};
};

function RsqrL25() {
    if(document.getElementById("aImgSqr300").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr300").src = "img/sqrs/blSqr.png"
 };
};

function RsqrM1() {
    if(document.getElementById("aImgSqr301").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr301").src = "img/sqrs/blSqr.png"
};
};

function RsqrM2() {
    if(document.getElementById("aImgSqr302").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr302").src = "img/sqrs/blSqr.png"
};
};

function RsqrM3() {
    if(document.getElementById("aImgSqr303").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr303").src = "img/sqrs/blSqr.png"
};
};

function RsqrM4() {
    if(document.getElementById("aImgSqr304").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr304").src = "img/sqrs/blSqr.png"
};
};

function RsqrM5() {
    if(document.getElementById("aImgSqr305").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr305").src = "img/sqrs/blSqr.png"
};
};

function RsqrM6() {
    if(document.getElementById("aImgSqr306").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr306").src = "img/sqrs/blSqr.png"
};
};

function RsqrM7() {
    if(document.getElementById("aImgSqr307").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr307").src = "img/sqrs/blSqr.png"
};
};

function RsqrM8() {
    if(document.getElementById("aImgSqr308").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr308").src = "img/sqrs/blSqr.png"
};
};

function RsqrM9() {
    if(document.getElementById("aImgSqr309").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr309").src = "img/sqrs/blSqr.png"
};
};

function RsqrM10() {
    if(document.getElementById("aImgSqr310").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr310").src = "img/sqrs/blSqr.png"
};
};

function RsqrM11() {
    if(document.getElementById("aImgSqr311").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr311").src = "img/sqrs/blSqr.png"
};
};

function RsqrM12() {
    if(document.getElementById("aImgSqr312").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr312").src = "img/sqrs/blSqr.png"
};
};

function RsqrM13() {
    if(document.getElementById("aImgSqr313").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr313").src = "img/sqrs/blSqr.png"
};
};

function RsqrM14() {
    if(document.getElementById("aImgSqr314").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr314").src = "img/sqrs/blSqr.png"
};
};

function RsqrM15() {
    if(document.getElementById("aImgSqr315").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr315").src = "img/sqrs/blSqr.png"
};
};

function RsqrM16() {
    if(document.getElementById("aImgSqr316").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr316").src = "img/sqrs/blSqr.png"
};
};

function RsqrM17() {
    if(document.getElementById("aImgSqr317").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr317").src = "img/sqrs/blSqr.png"
};
};

function RsqrM18() {
    if(document.getElementById("aImgSqr318").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr318").src = "img/sqrs/blSqr.png"
};
};

function RsqrM19() {
    if(document.getElementById("aImgSqr319").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr319").src = "img/sqrs/blSqr.png"
};
};

function RsqrM20() {
    if(document.getElementById("aImgSqr320").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr320").src = "img/sqrs/blSqr.png"
};
};

function RsqrM21() {
    if(document.getElementById("aImgSqr321").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr321").src = "img/sqrs/blSqr.png"
};
};

function RsqrM22() {
    if(document.getElementById("aImgSqr322").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr322").src = "img/sqrs/blSqr.png"
};
};

function RsqrM23() {
    if(document.getElementById("aImgSqr323").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr323").src = "img/sqrs/blSqr.png"
};
};

function RsqrM24() {
    if(document.getElementById("aImgSqr324").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr324").src = "img/sqrs/blSqr.png"
};
};

function RsqrM25() {
    if(document.getElementById("aImgSqr325").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr325").src = "img/sqrs/blSqr.png"
 };
};

function RsqrN1() {
    if(document.getElementById("aImgSqr326").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr326").src = "img/sqrs/blSqr.png"
};
};

function RsqrN2() {
    if(document.getElementById("aImgSqr327").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr327").src = "img/sqrs/blSqr.png"
};
};

function RsqrN3() {
    if(document.getElementById("aImgSqr328").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr328").src = "img/sqrs/blSqr.png"
};
};

function RsqrN4() {
    if(document.getElementById("aImgSqr329").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr329").src = "img/sqrs/blSqr.png"
};
};

function RsqrN5() {
    if(document.getElementById("aImgSqr330").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr330").src = "img/sqrs/blSqr.png"
};
};

function RsqrN6() {
    if(document.getElementById("aImgSqr331").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr331").src = "img/sqrs/blSqr.png"
};
};

function RsqrN7() {
    if(document.getElementById("aImgSqr332").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr332").src = "img/sqrs/blSqr.png"
};
};

function RsqrN8() {
    if(document.getElementById("aImgSqr333").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr333").src = "img/sqrs/blSqr.png"
};
};

function RsqrN9() {
    if(document.getElementById("aImgSqr334").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr334").src = "img/sqrs/blSqr.png"
};
};

function RsqrN10() {
    if(document.getElementById("aImgSqr335").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr335").src = "img/sqrs/blSqr.png"
};
};

function RsqrN11() {
    if(document.getElementById("aImgSqr336").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr336").src = "img/sqrs/blSqr.png"
};
};

function RsqrN12() {
    if(document.getElementById("aImgSqr337").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr337").src = "img/sqrs/blSqr.png"
};
};

function RsqrN13() {
    if(document.getElementById("aImgSqr338").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr338").src = "img/sqrs/blSqr.png"
};
};

function RsqrN14() {
    if(document.getElementById("aImgSqr339").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr339").src = "img/sqrs/blSqr.png"
};
};

function RsqrN15() {
    if(document.getElementById("aImgSqr340").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr340").src = "img/sqrs/blSqr.png"
};
};

function RsqrN16() {
    if(document.getElementById("aImgSqr341").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr341").src = "img/sqrs/blSqr.png"
};
};

function RsqrN17() {
    if(document.getElementById("aImgSqr342").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr342").src = "img/sqrs/blSqr.png"
};
};

function RsqrN18() {
    if(document.getElementById("aImgSqr343").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr343").src = "img/sqrs/blSqr.png"
};
};

function RsqrN19() {
    if(document.getElementById("aImgSqr344").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr344").src = "img/sqrs/blSqr.png"
};
};

function RsqrN20() {
    if(document.getElementById("aImgSqr345").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr345").src = "img/sqrs/blSqr.png"
};
};

function RsqrN21() {
    if(document.getElementById("aImgSqr346").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr346").src = "img/sqrs/blSqr.png"
};
};

function RsqrN22() {
    if(document.getElementById("aImgSqr347").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr347").src = "img/sqrs/blSqr.png"
};
};

function RsqrN23() {
    if(document.getElementById("aImgSqr348").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr348").src = "img/sqrs/blSqr.png"
};
};

function RsqrN24() {
    if(document.getElementById("aImgSqr349").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr349").src = "img/sqrs/blSqr.png"
};
};

function RsqrN25() {
    if(document.getElementById("aImgSqr350").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr350").src = "img/sqrs/blSqr.png"
 };
};

function RsqrO1() {
    if(document.getElementById("aImgSqr351").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr351").src = "img/sqrs/blSqr.png"
};
};

function RsqrO2() {
    if(document.getElementById("aImgSqr352").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr352").src = "img/sqrs/blSqr.png"
};
};

function RsqrO3() {
    if(document.getElementById("aImgSqr353").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr353").src = "img/sqrs/blSqr.png"
};
};

function RsqrO4() {
    if(document.getElementById("aImgSqr354").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr354").src = "img/sqrs/blSqr.png"
};
};

function RsqrO5() {
    if(document.getElementById("aImgSqr355").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr355").src = "img/sqrs/blSqr.png"
};
};

function RsqrO6() {
    if(document.getElementById("aImgSqr356").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr356").src = "img/sqrs/blSqr.png"
};
};

function RsqrO7() {
    if(document.getElementById("aImgSqr357").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr357").src = "img/sqrs/blSqr.png"
};
};

function RsqrO8() {
    if(document.getElementById("aImgSqr358").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr358").src = "img/sqrs/blSqr.png"
};
};

function RsqrO9() {
    if(document.getElementById("aImgSqr359").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr359").src = "img/sqrs/blSqr.png"
};
};

function RsqrO10() {
    if(document.getElementById("aImgSqr360").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr360").src = "img/sqrs/blSqr.png"
};
};

function RsqrO11() {
    if(document.getElementById("aImgSqr361").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr361").src = "img/sqrs/blSqr.png"
};
};

function RsqrO12() {
    if(document.getElementById("aImgSqr362").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr362").src = "img/sqrs/blSqr.png"
};
};

function RsqrO13() {
    if(document.getElementById("aImgSqr363").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr363").src = "img/sqrs/blSqr.png"
};
};

function RsqrO14() {
    if(document.getElementById("aImgSqr364").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr364").src = "img/sqrs/blSqr.png"
};
};

function RsqrO15() {
    if(document.getElementById("aImgSqr365").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr365").src = "img/sqrs/blSqr.png"
};
};

function RsqrO16() {
    if(document.getElementById("aImgSqr366").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr366").src = "img/sqrs/blSqr.png"
};
};

function RsqrO17() {
    if(document.getElementById("aImgSqr367").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr367").src = "img/sqrs/blSqr.png"
};
};

function RsqrO18() {
    if(document.getElementById("aImgSqr368").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr368").src = "img/sqrs/blSqr.png"
};
};

function RsqrO19() {
    if(document.getElementById("aImgSqr369").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr369").src = "img/sqrs/blSqr.png"
};
};

function RsqrO20() {
    if(document.getElementById("aImgSqr370").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr370").src = "img/sqrs/blSqr.png"
};
};

function RsqrO21() {
    if(document.getElementById("aImgSqr371").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr371").src = "img/sqrs/blSqr.png"
};
};

function RsqrO22() {
    if(document.getElementById("aImgSqr372").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr372").src = "img/sqrs/blSqr.png"
};
};

function RsqrO23() {
    if(document.getElementById("aImgSqr373").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr373").src = "img/sqrs/blSqr.png"
};
};

function RsqrO24() {
    if(document.getElementById("aImgSqr374").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr374").src = "img/sqrs/blSqr.png"
};
};

function RsqrO25() {
    if(document.getElementById("aImgSqr375").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr375").src = "img/sqrs/blSqr.png"
 };
};

function RsqrP1() {
    if(document.getElementById("aImgSqr376").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr376").src = "img/sqrs/blSqr.png"
};
};

function RsqrP2() {
    if(document.getElementById("aImgSqr377").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr377").src = "img/sqrs/blSqr.png"
};
};

function RsqrP3() {
    if(document.getElementById("aImgSqr378").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr378").src = "img/sqrs/blSqr.png"
};
};

function RsqrP4() {
    if(document.getElementById("aImgSqr379").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr379").src = "img/sqrs/blSqr.png"
};
};

function RsqrP5() {
    if(document.getElementById("aImgSqr380").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr380").src = "img/sqrs/blSqr.png"
};
};

function RsqrP6() {
    if(document.getElementById("aImgSqr381").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr381").src = "img/sqrs/blSqr.png"
};
};

function RsqrP7() {
    if(document.getElementById("aImgSqr382").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr382").src = "img/sqrs/blSqr.png"
};
};

function RsqrP8() {
    if(document.getElementById("aImgSqr383").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr383").src = "img/sqrs/blSqr.png"
};
};

function RsqrP9() {
    if(document.getElementById("aImgSqr384").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr384").src = "img/sqrs/blSqr.png"
};
};

function RsqrP10() {
    if(document.getElementById("aImgSqr385").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr385").src = "img/sqrs/blSqr.png"
};
};

function RsqrP11() {
    if(document.getElementById("aImgSqr386").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr386").src = "img/sqrs/blSqr.png"
};
};

function RsqrP12() {
    if(document.getElementById("aImgSqr387").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr387").src = "img/sqrs/blSqr.png"
};
};

function RsqrP13() {
    if(document.getElementById("aImgSqr388").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr388").src = "img/sqrs/blSqr.png"
};
};

function RsqrP14() {
    if(document.getElementById("aImgSqr389").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr389").src = "img/sqrs/blSqr.png"
};
};

function RsqrP15() {
    if(document.getElementById("aImgSqr390").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr390").src = "img/sqrs/blSqr.png"
};
};

function RsqrP16() {
    if(document.getElementById("aImgSqr391").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr391").src = "img/sqrs/blSqr.png"
};
};

function RsqrP17() {
    if(document.getElementById("aImgSqr392").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr392").src = "img/sqrs/blSqr.png"
};
};

function RsqrP18() {
    if(document.getElementById("aImgSqr393").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr393").src = "img/sqrs/blSqr.png"
};
};

function RsqrP19() {
    if(document.getElementById("aImgSqr394").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr394").src = "img/sqrs/blSqr.png"
};
};

function RsqrP20() {
    if(document.getElementById("aImgSqr395").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr395").src = "img/sqrs/blSqr.png"
};
};

function RsqrP21() {
    if(document.getElementById("aImgSqr396").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr396").src = "img/sqrs/blSqr.png"
};
};

function RsqrP22() {
    if(document.getElementById("aImgSqr397").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr397").src = "img/sqrs/blSqr.png"
};
};

function RsqrP23() {
    if(document.getElementById("aImgSqr398").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr398").src = "img/sqrs/blSqr.png"
};
};

function RsqrP24() {
    if(document.getElementById("aImgSqr399").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr399").src = "img/sqrs/blSqr.png"
};
};

function RsqrP25() {
    if(document.getElementById("aImgSqr400").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr400").src = "img/sqrs/blSqr.png"
 };
};

function RsqrQ1() {
    if(document.getElementById("aImgSqr401").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr401").src = "img/sqrs/blSqr.png"
};
};

function RsqrQ2() {
    if(document.getElementById("aImgSqr402").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr402").src = "img/sqrs/blSqr.png"
};
};

function RsqrQ3() {
    if(document.getElementById("aImgSqr403").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr403").src = "img/sqrs/blSqr.png"
};
};

function RsqrQ4() {
    if(document.getElementById("aImgSqr404").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr404").src = "img/sqrs/blSqr.png"
};
};

function RsqrQ5() {
    if(document.getElementById("aImgSqr405").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr405").src = "img/sqrs/blSqr.png"
};
};

function RsqrQ6() {
    if(document.getElementById("aImgSqr406").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr406").src = "img/sqrs/blSqr.png"
};
};

function RsqrQ7() {
    if(document.getElementById("aImgSqr407").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr407").src = "img/sqrs/blSqr.png"
};
};

function RsqrQ8() {
    if(document.getElementById("aImgSqr408").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr408").src = "img/sqrs/blSqr.png"
};
};

function RsqrQ9() {
    if(document.getElementById("aImgSqr409").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr409").src = "img/sqrs/blSqr.png"
};
};

function RsqrQ10() {
    if(document.getElementById("aImgSqr410").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr410").src = "img/sqrs/blSqr.png"
};
};

function RsqrQ11() {
    if(document.getElementById("aImgSqr411").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr411").src = "img/sqrs/blSqr.png"
};
};

function RsqrQ12() {
    if(document.getElementById("aImgSqr412").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr412").src = "img/sqrs/blSqr.png"
};
};

function RsqrQ13() {
    if(document.getElementById("aImgSqr413").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr413").src = "img/sqrs/blSqr.png"
};
};

function RsqrQ14() {
    if(document.getElementById("aImgSqr414").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr414").src = "img/sqrs/blSqr.png"
};
};

function RsqrQ15() {
    if(document.getElementById("aImgSqr415").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr415").src = "img/sqrs/blSqr.png"
};
};

function RsqrQ16() {
    if(document.getElementById("aImgSqr416").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr416").src = "img/sqrs/blSqr.png"
};
};

function RsqrQ17() {
    if(document.getElementById("aImgSqr417").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr417").src = "img/sqrs/blSqr.png"
};
};

function RsqrQ18() {
    if(document.getElementById("aImgSqr418").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr418").src = "img/sqrs/blSqr.png"
};
};

function RsqrQ19() {
    if(document.getElementById("aImgSqr419").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr419").src = "img/sqrs/blSqr.png"
};
};

function RsqrQ20() {
    if(document.getElementById("aImgSqr420").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr420").src = "img/sqrs/blSqr.png"
};
};

function RsqrQ21() {
    if(document.getElementById("aImgSqr421").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr421").src = "img/sqrs/blSqr.png"
};
};

function RsqrQ22() {
    if(document.getElementById("aImgSqr422").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr422").src = "img/sqrs/blSqr.png"
};
};

function RsqrQ23() {
    if(document.getElementById("aImgSqr423").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr423").src = "img/sqrs/blSqr.png"
};
};

function RsqrQ24() {
    if(document.getElementById("aImgSqr424").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr424").src = "img/sqrs/blSqr.png"
};
};

function RsqrQ25() {
    if(document.getElementById("aImgSqr425").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr425").src = "img/sqrs/blSqr.png"
 };
};

function RsqrR1() {
    if(document.getElementById("aImgSqr426").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr426").src = "img/sqrs/blSqr.png"
};
};

function RsqrR2() {
    if(document.getElementById("aImgSqr427").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr427").src = "img/sqrs/blSqr.png"
};
};

function RsqrR3() {
    if(document.getElementById("aImgSqr428").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr428").src = "img/sqrs/blSqr.png"
};
};

function RsqrR4() {
    if(document.getElementById("aImgSqr429").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr429").src = "img/sqrs/blSqr.png"
};
};

function RsqrR5() {
    if(document.getElementById("aImgSqr430").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr430").src = "img/sqrs/blSqr.png"
};
};

function RsqrR6() {
    if(document.getElementById("aImgSqr431").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr431").src = "img/sqrs/blSqr.png"
};
};

function RsqrR7() {
    if(document.getElementById("aImgSqr432").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr432").src = "img/sqrs/blSqr.png"
};
};

function RsqrR8() {
    if(document.getElementById("aImgSqr433").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr433").src = "img/sqrs/blSqr.png"
};
};

function RsqrR9() {
    if(document.getElementById("aImgSqr434").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr434").src = "img/sqrs/blSqr.png"
};
};

function RsqrR10() {
    if(document.getElementById("aImgSqr435").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr435").src = "img/sqrs/blSqr.png"
};
};

function RsqrR11() {
    if(document.getElementById("aImgSqr436").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr436").src = "img/sqrs/blSqr.png"
};
};

function RsqrR12() {
    if(document.getElementById("aImgSqr437").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr437").src = "img/sqrs/blSqr.png"
};
};

function RsqrR13() {
    if(document.getElementById("aImgSqr438").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr438").src = "img/sqrs/blSqr.png"
};
};

function RsqrR14() {
    if(document.getElementById("aImgSqr439").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr439").src = "img/sqrs/blSqr.png"
};
};

function RsqrR15() {
    if(document.getElementById("aImgSqr440").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr440").src = "img/sqrs/blSqr.png"
};
};

function RsqrR16() {
    if(document.getElementById("aImgSqr441").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr441").src = "img/sqrs/blSqr.png"
};
};

function RsqrR17() {
    if(document.getElementById("aImgSqr442").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr442").src = "img/sqrs/blSqr.png"
};
};

function RsqrR18() {
    if(document.getElementById("aImgSqr443").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr443").src = "img/sqrs/blSqr.png"
};
};

function RsqrR19() {
    if(document.getElementById("aImgSqr444").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr444").src = "img/sqrs/blSqr.png"
};
};

function RsqrR20() {
    if(document.getElementById("aImgSqr445").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr445").src = "img/sqrs/blSqr.png"
};
};

function RsqrR21() {
    if(document.getElementById("aImgSqr446").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr446").src = "img/sqrs/blSqr.png"
};
};

function RsqrR22() {
    if(document.getElementById("aImgSqr447").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr447").src = "img/sqrs/blSqr.png"
};
};

function RsqrR23() {
    if(document.getElementById("aImgSqr448").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr448").src = "img/sqrs/blSqr.png"
};
};

function RsqrR24() {
    if(document.getElementById("aImgSqr449").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr449").src = "img/sqrs/blSqr.png"
};
};

function RsqrR25() {
    if(document.getElementById("aImgSqr450").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr450").src = "img/sqrs/blSqr.png"
 };
};

function RsqrS1() {
    if(document.getElementById("aImgSqr451").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr451").src = "img/sqrs/blSqr.png"
};
};

function RsqrS2() {
    if(document.getElementById("aImgSqr452").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr452").src = "img/sqrs/blSqr.png"
};
};

function RsqrS3() {
    if(document.getElementById("aImgSqr453").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr453").src = "img/sqrs/blSqr.png"
};
};

function RsqrS4() {
    if(document.getElementById("aImgSqr454").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr454").src = "img/sqrs/blSqr.png"
};
};

function RsqrS5() {
    if(document.getElementById("aImgSqr455").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr455").src = "img/sqrs/blSqr.png"
};
};

function RsqrS6() {
    if(document.getElementById("aImgSqr456").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr456").src = "img/sqrs/blSqr.png"
};
};

function RsqrS7() {
    if(document.getElementById("aImgSqr457").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr457").src = "img/sqrs/blSqr.png"
};
};

function RsqrS8() {
    if(document.getElementById("aImgSqr458").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr458").src = "img/sqrs/blSqr.png"
};
};

function RsqrS9() {
    if(document.getElementById("aImgSqr459").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr459").src = "img/sqrs/blSqr.png"
};
};

function RsqrS10() {
    if(document.getElementById("aImgSqr460").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr460").src = "img/sqrs/blSqr.png"
};
};

function RsqrS11() {
    if(document.getElementById("aImgSqr461").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr461").src = "img/sqrs/blSqr.png"
};
};

function RsqrS12() {
    if(document.getElementById("aImgSqr462").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr462").src = "img/sqrs/blSqr.png"
};
};

function RsqrS13() {
    if(document.getElementById("aImgSqr463").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr463").src = "img/sqrs/blSqr.png"
};
};

function RsqrS14() {
    if(document.getElementById("aImgSqr464").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr464").src = "img/sqrs/blSqr.png"
};
};

function RsqrS15() {
    if(document.getElementById("aImgSqr465").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr465").src = "img/sqrs/blSqr.png"
};
};

function RsqrS16() {
    if(document.getElementById("aImgSqr466").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr466").src = "img/sqrs/blSqr.png"
};
};

function RsqrS17() {
    if(document.getElementById("aImgSqr467").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr467").src = "img/sqrs/blSqr.png"
};
};

function RsqrS18() {
    if(document.getElementById("aImgSqr468").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr468").src = "img/sqrs/blSqr.png"
};
};

function RsqrS19() {
    if(document.getElementById("aImgSqr469").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr469").src = "img/sqrs/blSqr.png"
};
};

function RsqrS20() {
    if(document.getElementById("aImgSqr470").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr470").src = "img/sqrs/blSqr.png"
};
};

function RsqrS21() {
    if(document.getElementById("aImgSqr471").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr471").src = "img/sqrs/blSqr.png"
};
};

function RsqrS22() {
    if(document.getElementById("aImgSqr472").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr472").src = "img/sqrs/blSqr.png"
};
};

function RsqrS23() {
    if(document.getElementById("aImgSqr473").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr473").src = "img/sqrs/blSqr.png"
};
};

function RsqrS24() {
    if(document.getElementById("aImgSqr474").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr474").src = "img/sqrs/blSqr.png"
};
};

function RsqrS25() {
    if(document.getElementById("aImgSqr475").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr475").src = "img/sqrs/blSqr.png"
 };
};

function RsqrT1() {
    if(document.getElementById("aImgSqr476").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr476").src = "img/sqrs/blSqr.png"
};
};

function RsqrT2() {
    if(document.getElementById("aImgSqr477").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr477").src = "img/sqrs/blSqr.png"
};
};

function RsqrT3() {
    if(document.getElementById("aImgSqr478").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr478").src = "img/sqrs/blSqr.png"
};
};

function RsqrT4() {
    if(document.getElementById("aImgSqr479").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr479").src = "img/sqrs/blSqr.png"
};
};

function RsqrT5() {
    if(document.getElementById("aImgSqr480").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr480").src = "img/sqrs/blSqr.png"
};
};

function RsqrT6() {
    if(document.getElementById("aImgSqr481").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr481").src = "img/sqrs/blSqr.png"
};
};

function RsqrT7() {
    if(document.getElementById("aImgSqr482").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr482").src = "img/sqrs/blSqr.png"
};
};

function RsqrT8() {
    if(document.getElementById("aImgSqr483").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr483").src = "img/sqrs/blSqr.png"
};
};

function RsqrT9() {
    if(document.getElementById("aImgSqr484").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr484").src = "img/sqrs/blSqr.png"
};
};

function RsqrT10() {
    if(document.getElementById("aImgSqr485").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr485").src = "img/sqrs/blSqr.png"
};
};

function RsqrT11() {
    if(document.getElementById("aImgSqr486").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr486").src = "img/sqrs/blSqr.png"
};
};

function RsqrT12() {
    if(document.getElementById("aImgSqr487").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr487").src = "img/sqrs/blSqr.png"
};
};

function RsqrT13() {
    if(document.getElementById("aImgSqr488").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr488").src = "img/sqrs/blSqr.png"
};
};

function RsqrT14() {
    if(document.getElementById("aImgSqr489").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr489").src = "img/sqrs/blSqr.png"
};
};

function RsqrT15() {
    if(document.getElementById("aImgSqr490").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr490").src = "img/sqrs/blSqr.png"
};
};

function RsqrT16() {
    if(document.getElementById("aImgSqr491").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr491").src = "img/sqrs/blSqr.png"
};
};

function RsqrT17() {
    if(document.getElementById("aImgSqr492").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr492").src = "img/sqrs/blSqr.png"
};
};

function RsqrT18() {
    if(document.getElementById("aImgSqr493").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr493").src = "img/sqrs/blSqr.png"
};
};

function RsqrT19() {
    if(document.getElementById("aImgSqr494").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr494").src = "img/sqrs/blSqr.png"
};
};

function RsqrT20() {
    if(document.getElementById("aImgSqr495").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr495").src = "img/sqrs/blSqr.png"
};
};

function RsqrT21() {
    if(document.getElementById("aImgSqr496").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr496").src = "img/sqrs/blSqr.png"
};
};

function RsqrT22() {
    if(document.getElementById("aImgSqr497").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr497").src = "img/sqrs/blSqr.png"
};
};

function RsqrT23() {
    if(document.getElementById("aImgSqr498").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr498").src = "img/sqrs/blSqr.png"
};
};

function RsqrT24() {
    if(document.getElementById("aImgSqr499").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr499").src = "img/sqrs/blSqr.png"
};
};

function RsqrT25() {
    if(document.getElementById("aImgSqr500").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr500").src = "img/sqrs/blSqr.png"
 };
};

function RsqrU1() {
    if(document.getElementById("aImgSqr501").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr501").src = "img/sqrs/blSqr.png"
};
};

function RsqrU2() {
    if(document.getElementById("aImgSqr502").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr502").src = "img/sqrs/blSqr.png"
};
};

function RsqrU3() {
    if(document.getElementById("aImgSqr503").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr503").src = "img/sqrs/blSqr.png"
};
};

function RsqrU4() {
    if(document.getElementById("aImgSqr504").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr504").src = "img/sqrs/blSqr.png"
};
};

function RsqrU5() {
    if(document.getElementById("aImgSqr505").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr505").src = "img/sqrs/blSqr.png"
};
};

function RsqrU6() {
    if(document.getElementById("aImgSqr506").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr506").src = "img/sqrs/blSqr.png"
};
};

function RsqrU7() {
    if(document.getElementById("aImgSqr507").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr507").src = "img/sqrs/blSqr.png"
};
};

function RsqrU8() {
    if(document.getElementById("aImgSqr508").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr508").src = "img/sqrs/blSqr.png"
};
};

function RsqrU9() {
    if(document.getElementById("aImgSqr509").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr509").src = "img/sqrs/blSqr.png"
};
};

function RsqrU10() {
    if(document.getElementById("aImgSqr510").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr510").src = "img/sqrs/blSqr.png"
};
};

function RsqrU11() {
    if(document.getElementById("aImgSqr511").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr511").src = "img/sqrs/blSqr.png"
};
};

function RsqrU12() {
    if(document.getElementById("aImgSqr512").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr512").src = "img/sqrs/blSqr.png"
};
};

function RsqrU13() {
    if(document.getElementById("aImgSqr513").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr513").src = "img/sqrs/blSqr.png"
};
};

function RsqrU14() {
    if(document.getElementById("aImgSqr514").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr514").src = "img/sqrs/blSqr.png"
};
};

function RsqrU15() {
    if(document.getElementById("aImgSqr515").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr515").src = "img/sqrs/blSqr.png"
};
};

function RsqrU16() {
    if(document.getElementById("aImgSqr516").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr516").src = "img/sqrs/blSqr.png"
};
};

function RsqrU17() {
    if(document.getElementById("aImgSqr517").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr517").src = "img/sqrs/blSqr.png"
};
};

function RsqrU18() {
    if(document.getElementById("aImgSqr518").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr518").src = "img/sqrs/blSqr.png"
};
};

function RsqrU19() {
    if(document.getElementById("aImgSqr519").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr519").src = "img/sqrs/blSqr.png"
};
};

function RsqrU20() {
    if(document.getElementById("aImgSqr520").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr520").src = "img/sqrs/blSqr.png"
};
};

function RsqrU21() {
    if(document.getElementById("aImgSqr521").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr521").src = "img/sqrs/blSqr.png"
};
};

function RsqrU22() {
    if(document.getElementById("aImgSqr522").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr522").src = "img/sqrs/blSqr.png"
};
};

function RsqrU23() {
    if(document.getElementById("aImgSqr523").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr523").src = "img/sqrs/blSqr.png"
};
};

function RsqrU24() {
    if(document.getElementById("aImgSqr524").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr524").src = "img/sqrs/blSqr.png"
};
};

function RsqrU25() {
    if(document.getElementById("aImgSqr525").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr525").src = "img/sqrs/blSqr.png"
 };
};

function RsqrV1() {
    if(document.getElementById("aImgSqr526").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr526").src = "img/sqrs/blSqr.png"
};
};

function RsqrV2() {
    if(document.getElementById("aImgSqr527").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr527").src = "img/sqrs/blSqr.png"
};
};

function RsqrV3() {
    if(document.getElementById("aImgSqr528").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr528").src = "img/sqrs/blSqr.png"
};
};

function RsqrV4() {
    if(document.getElementById("aImgSqr529").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr529").src = "img/sqrs/blSqr.png"
};
};

function RsqrV5() {
    if(document.getElementById("aImgSqr530").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr530").src = "img/sqrs/blSqr.png"
};
};

function RsqrV6() {
    if(document.getElementById("aImgSqr531").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr531").src = "img/sqrs/blSqr.png"
};
};

function RsqrV7() {
    if(document.getElementById("aImgSqr532").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr532").src = "img/sqrs/blSqr.png"
};
};

function RsqrV8() {
    if(document.getElementById("aImgSqr533").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr533").src = "img/sqrs/blSqr.png"
};
};

function RsqrV9() {
    if(document.getElementById("aImgSqr534").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr534").src = "img/sqrs/blSqr.png"
};
};

function RsqrV10() {
    if(document.getElementById("aImgSqr535").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr535").src = "img/sqrs/blSqr.png"
};
};

function RsqrV11() {
    if(document.getElementById("aImgSqr536").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr536").src = "img/sqrs/blSqr.png"
};
};

function RsqrV12() {
    if(document.getElementById("aImgSqr537").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr537").src = "img/sqrs/blSqr.png"
};
};

function RsqrV13() {
    if(document.getElementById("aImgSqr538").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr538").src = "img/sqrs/blSqr.png"
};
};

function RsqrV14() {
    if(document.getElementById("aImgSqr539").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr539").src = "img/sqrs/blSqr.png"
};
};

function RsqrV15() {
    if(document.getElementById("aImgSqr540").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr540").src = "img/sqrs/blSqr.png"
};
};

function RsqrV16() {
    if(document.getElementById("aImgSqr541").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr541").src = "img/sqrs/blSqr.png"
};
};

function RsqrV17() {
    if(document.getElementById("aImgSqr542").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr542").src = "img/sqrs/blSqr.png"
};
};

function RsqrV18() {
    if(document.getElementById("aImgSqr543").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr543").src = "img/sqrs/blSqr.png"
};
};

function RsqrV19() {
    if(document.getElementById("aImgSqr544").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr544").src = "img/sqrs/blSqr.png"
};
};

function RsqrV20() {
    if(document.getElementById("aImgSqr545").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr545").src = "img/sqrs/blSqr.png"
};
};

function RsqrV21() {
    if(document.getElementById("aImgSqr546").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr546").src = "img/sqrs/blSqr.png"
};
};

function RsqrV22() {
    if(document.getElementById("aImgSqr547").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr547").src = "img/sqrs/blSqr.png"
};
};

function RsqrV23() {
    if(document.getElementById("aImgSqr548").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr548").src = "img/sqrs/blSqr.png"
};
};

function RsqrV24() {
    if(document.getElementById("aImgSqr549").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr549").src = "img/sqrs/blSqr.png"
};
};

function RsqrV25() {
    if(document.getElementById("aImgSqr550").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr550").src = "img/sqrs/blSqr.png"
 };
};

function RsqrW1() {
    if(document.getElementById("aImgSqr551").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr551").src = "img/sqrs/blSqr.png"
};
};

function RsqrW2() {
    if(document.getElementById("aImgSqr552").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr552").src = "img/sqrs/blSqr.png"
};
};

function RsqrW3() {
    if(document.getElementById("aImgSqr553").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr553").src = "img/sqrs/blSqr.png"
};
};

function RsqrW4() {
    if(document.getElementById("aImgSqr554").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr554").src = "img/sqrs/blSqr.png"
};
};

function RsqrW5() {
    if(document.getElementById("aImgSqr555").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr555").src = "img/sqrs/blSqr.png"
};
};

function RsqrW6() {
    if(document.getElementById("aImgSqr556").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr556").src = "img/sqrs/blSqr.png"
};
};

function RsqrW7() {
    if(document.getElementById("aImgSqr557").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr557").src = "img/sqrs/blSqr.png"
};
};

function RsqrW8() {
    if(document.getElementById("aImgSqr558").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr558").src = "img/sqrs/blSqr.png"
};
};

function RsqrW9() {
    if(document.getElementById("aImgSqr559").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr559").src = "img/sqrs/blSqr.png"
};
};

function RsqrW10() {
    if(document.getElementById("aImgSqr560").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr560").src = "img/sqrs/blSqr.png"
};
};

function RsqrW11() {
    if(document.getElementById("aImgSqr561").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr561").src = "img/sqrs/blSqr.png"
};
};

function RsqrW12() {
    if(document.getElementById("aImgSqr562").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr562").src = "img/sqrs/blSqr.png"
};
};

function RsqrW13() {
    if(document.getElementById("aImgSqr563").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr563").src = "img/sqrs/blSqr.png"
};
};

function RsqrW14() {
    if(document.getElementById("aImgSqr564").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr564").src = "img/sqrs/blSqr.png"
};
};

function RsqrW15() {
    if(document.getElementById("aImgSqr565").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr565").src = "img/sqrs/blSqr.png"
};
};

function RsqrW16() {
    if(document.getElementById("aImgSqr566").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr566").src = "img/sqrs/blSqr.png"
};
};

function RsqrW17() {
    if(document.getElementById("aImgSqr567").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr567").src = "img/sqrs/blSqr.png"
};
};

function RsqrW18() {
    if(document.getElementById("aImgSqr568").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr568").src = "img/sqrs/blSqr.png"
};
};

function RsqrW19() {
    if(document.getElementById("aImgSqr569").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr569").src = "img/sqrs/blSqr.png"
};
};

function RsqrW20() {
    if(document.getElementById("aImgSqr570").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr570").src = "img/sqrs/blSqr.png"
};
};

function RsqrW21() {
    if(document.getElementById("aImgSqr571").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr571").src = "img/sqrs/blSqr.png"
};
};

function RsqrW22() {
    if(document.getElementById("aImgSqr572").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr572").src = "img/sqrs/blSqr.png"
};
};

function RsqrW23() {
    if(document.getElementById("aImgSqr573").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr573").src = "img/sqrs/blSqr.png"
};
};

function RsqrW24() {
    if(document.getElementById("aImgSqr574").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr574").src = "img/sqrs/blSqr.png"
};
};

function RsqrW25() {
    if(document.getElementById("aImgSqr575").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr575").src = "img/sqrs/blSqr.png"
 };
};

function RsqrX1() {
    if(document.getElementById("aImgSqr576").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr576").src = "img/sqrs/blSqr.png"
};
};

function RsqrX2() {
    if(document.getElementById("aImgSqr577").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr577").src = "img/sqrs/blSqr.png"
};
};

function RsqrX3() {
    if(document.getElementById("aImgSqr578").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr578").src = "img/sqrs/blSqr.png"
};
};

function RsqrX4() {
    if(document.getElementById("aImgSqr579").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr579").src = "img/sqrs/blSqr.png"
};
};

function RsqrX5() {
    if(document.getElementById("aImgSqr580").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr580").src = "img/sqrs/blSqr.png"
};
};

function RsqrX6() {
    if(document.getElementById("aImgSqr581").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr581").src = "img/sqrs/blSqr.png"
};
};

function RsqrX7() {
    if(document.getElementById("aImgSqr582").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr582").src = "img/sqrs/blSqr.png"
};
};

function RsqrX8() {
    if(document.getElementById("aImgSqr583").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr583").src = "img/sqrs/blSqr.png"
};
};

function RsqrX9() {
    if(document.getElementById("aImgSqr584").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr584").src = "img/sqrs/blSqr.png"
};
};

function RsqrX10() {
    if(document.getElementById("aImgSqr585").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr585").src = "img/sqrs/blSqr.png"
};
};

function RsqrX11() {
    if(document.getElementById("aImgSqr586").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr586").src = "img/sqrs/blSqr.png"
};
};

function RsqrX12() {
    if(document.getElementById("aImgSqr587").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr587").src = "img/sqrs/blSqr.png"
};
};

function RsqrX13() {
    if(document.getElementById("aImgSqr588").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr588").src = "img/sqrs/blSqr.png"
};
};

function RsqrX14() {
    if(document.getElementById("aImgSqr589").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr589").src = "img/sqrs/blSqr.png"
};
};

function RsqrX15() {
    if(document.getElementById("aImgSqr590").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr590").src = "img/sqrs/blSqr.png"
};
};

function RsqrX16() {
    if(document.getElementById("aImgSqr591").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr591").src = "img/sqrs/blSqr.png"
};
};

function RsqrX17() {
    if(document.getElementById("aImgSqr592").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr592").src = "img/sqrs/blSqr.png"
};
};

function RsqrX18() {
    if(document.getElementById("aImgSqr593").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr593").src = "img/sqrs/blSqr.png"
};
};

function RsqrX19() {
    if(document.getElementById("aImgSqr594").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr594").src = "img/sqrs/blSqr.png"
};
};

function RsqrX20() {
    if(document.getElementById("aImgSqr595").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr595").src = "img/sqrs/blSqr.png"
};
};

function RsqrX21() {
    if(document.getElementById("aImgSqr596").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr596").src = "img/sqrs/blSqr.png"
};
};

function RsqrX22() {
    if(document.getElementById("aImgSqr597").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr597").src = "img/sqrs/blSqr.png"
};
};

function RsqrX23() {
    if(document.getElementById("aImgSqr598").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr598").src = "img/sqrs/blSqr.png"
};
};

function RsqrX24() {
    if(document.getElementById("aImgSqr599").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr599").src = "img/sqrs/blSqr.png"
};
};

function RsqrX25() {
    if(document.getElementById("aImgSqr600").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr600").src = "img/sqrs/blSqr.png"
 };
};

function RsqrY1() {
    if(document.getElementById("aImgSqr601").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr601").src = "img/sqrs/blSqr.png"
};
};

function RsqrY2() {
    if(document.getElementById("aImgSqr602").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr602").src = "img/sqrs/blSqr.png"
};
};

function RsqrY3() {
    if(document.getElementById("aImgSqr603").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr603").src = "img/sqrs/blSqr.png"
};
};

function RsqrY4() {
    if(document.getElementById("aImgSqr604").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr604").src = "img/sqrs/blSqr.png"
};
};

function RsqrY5() {
    if(document.getElementById("aImgSqr605").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr605").src = "img/sqrs/blSqr.png"
};
};

function RsqrY6() {
    if(document.getElementById("aImgSqr606").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr606").src = "img/sqrs/blSqr.png"
};
};

function RsqrY7() {
    if(document.getElementById("aImgSqr607").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr607").src = "img/sqrs/blSqr.png"
};
};

function RsqrY8() {
    if(document.getElementById("aImgSqr608").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr608").src = "img/sqrs/blSqr.png"
};
};

function RsqrY9() {
    if(document.getElementById("aImgSqr609").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr609").src = "img/sqrs/blSqr.png"
};
};

function RsqrY10() {
    if(document.getElementById("aImgSqr610").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr610").src = "img/sqrs/blSqr.png"
};
};

function RsqrY11() {
    if(document.getElementById("aImgSqr611").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr611").src = "img/sqrs/blSqr.png"
};
};

function RsqrY12() {
    if(document.getElementById("aImgSqr612").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr612").src = "img/sqrs/blSqr.png"
};
};

function RsqrY13() {
    if(document.getElementById("aImgSqr613").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr613").src = "img/sqrs/blSqr.png"
};
};

function RsqrY14() {
    if(document.getElementById("aImgSqr614").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr614").src = "img/sqrs/blSqr.png"
};
};

function RsqrY15() {
    if(document.getElementById("aImgSqr615").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr615").src = "img/sqrs/blSqr.png"
};
};

function RsqrY16() {
    if(document.getElementById("aImgSqr616").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr616").src = "img/sqrs/blSqr.png"
};
};

function RsqrY17() {
    if(document.getElementById("aImgSqr617").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr617").src = "img/sqrs/blSqr.png"
};
};

function RsqrY18() {
    if(document.getElementById("aImgSqr618").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr618").src = "img/sqrs/blSqr.png"
};
};

function RsqrY19() {
    if(document.getElementById("aImgSqr619").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr619").src = "img/sqrs/blSqr.png"
};
};

function RsqrY20() {
    if(document.getElementById("aImgSqr620").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr620").src = "img/sqrs/blSqr.png"
};
};

function RsqrY21() {
    if(document.getElementById("aImgSqr621").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr621").src = "img/sqrs/blSqr.png"
};
};

function RsqrY22() {
    if(document.getElementById("aImgSqr622").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr622").src = "img/sqrs/blSqr.png"
};
};

function RsqrY23() {
    if(document.getElementById("aImgSqr623").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr623").src = "img/sqrs/blSqr.png"
};
};

function RsqrY24() {
    if(document.getElementById("aImgSqr624").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr624").src = "img/sqrs/blSqr.png"
};
};

function RsqrY25() {
    if(document.getElementById("aImgSqr625").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr625").src = "img/sqrs/blSqr.png"
};
};

function RsqrA1b() {
    if(document.getElementById("aImgSqr1").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr1").src = "img/sqrs/wSqr.png"
};
};

function RsqrA2b() {
    if(document.getElementById("aImgSqr2").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr2").src = "img/sqrs/wSqr.png"
};
};

function RsqrA3b() {
    if(document.getElementById("aImgSqr3").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr3").src = "img/sqrs/wSqr.png"
};
};

function RsqrA4b() {
    if(document.getElementById("aImgSqr4").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr4").src = "img/sqrs/wSqr.png"
};
};

function RsqrA5b() {
    if(document.getElementById("aImgSqr5").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr5").src = "img/sqrs/wSqr.png"
};
};

function RsqrA6b() {
    if(document.getElementById("aImgSqr6").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr6").src = "img/sqrs/wSqr.png"
};
};

function RsqrA7b() {
    if(document.getElementById("aImgSqr7").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr7").src = "img/sqrs/wSqr.png"
};
};

function RsqrA8b() {
    if(document.getElementById("aImgSqr8").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr8").src = "img/sqrs/wSqr.png"
};
};

function RsqrA9b() {
    if(document.getElementById("aImgSqr9").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr9").src = "img/sqrs/wSqr.png"
};
};

function RsqrA10b() {
    if(document.getElementById("aImgSqr10").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr10").src = "img/sqrs/wSqr.png"
};
};

function RsqrA11b() {
    if(document.getElementById("aImgSqr11").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr11").src = "img/sqrs/wSqr.png"
};
};

function RsqrA12b() {
    if(document.getElementById("aImgSqr12").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr12").src = "img/sqrs/wSqr.png"
};
};

function RsqrA13b() {
    if(document.getElementById("aImgSqr13").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr13").src = "img/sqrs/wSqr.png"
};
};

function RsqrA14b() {
    if(document.getElementById("aImgSqr14").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr14").src = "img/sqrs/wSqr.png"
};
};

function RsqrA15b() {
    if(document.getElementById("aImgSqr15").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr15").src = "img/sqrs/wSqr.png"
};
};

function RsqrA16b() {
    if(document.getElementById("aImgSqr16").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr16").src = "img/sqrs/wSqr.png"
};
};

function RsqrA17b() {
    if(document.getElementById("aImgSqr17").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr17").src = "img/sqrs/wSqr.png"
};
};

function RsqrA18b() {
    if(document.getElementById("aImgSqr18").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr18").src = "img/sqrs/wSqr.png"
};
};

function RsqrA19b() {
    if(document.getElementById("aImgSqr19").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr19").src = "img/sqrs/wSqr.png"
};
};

function RsqrA20b() {
    if(document.getElementById("aImgSqr20").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr20").src = "img/sqrs/wSqr.png"
};
};

function RsqrA21b() {
    if(document.getElementById("aImgSqr21").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr21").src = "img/sqrs/wSqr.png"
};
};

function RsqrA22b() {
    if(document.getElementById("aImgSqr22").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr22").src = "img/sqrs/wSqr.png"
};
};

function RsqrA23b() {
    if(document.getElementById("aImgSqr23").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr23").src = "img/sqrs/wSqr.png"
};
};

function RsqrA24b() {
    if(document.getElementById("aImgSqr24").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr24").src = "img/sqrs/wSqr.png"
};
};

function RsqrA25b() {
    if(document.getElementById("aImgSqr25").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr25").src = "img/sqrs/wSqr.png"
 };
};

function RsqrB1b() {
    if(document.getElementById("aImgSqr26").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr26").src = "img/sqrs/wSqr.png"
};
};

function RsqrB2b() {
    if(document.getElementById("aImgSqr27").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr27").src = "img/sqrs/wSqr.png"
};
};

function RsqrB3b() {
    if(document.getElementById("aImgSqr28").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr28").src = "img/sqrs/wSqr.png"
};
};

function RsqrB4b() {
    if(document.getElementById("aImgSqr29").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr29").src = "img/sqrs/wSqr.png"
};
};

function RsqrB5b() {
    if(document.getElementById("aImgSqr30").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr30").src = "img/sqrs/wSqr.png"
};
};

function RsqrB6b() {
    if(document.getElementById("aImgSqr31").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr31").src = "img/sqrs/wSqr.png"
};
};

function RsqrB7b() {
    if(document.getElementById("aImgSqr32").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr32").src = "img/sqrs/wSqr.png"
};
};

function RsqrB8b() {
    if(document.getElementById("aImgSqr33").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr33").src = "img/sqrs/wSqr.png"
};
};

function RsqrB9b() {
    if(document.getElementById("aImgSqr34").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr34").src = "img/sqrs/wSqr.png"
};
};

function RsqrB10b() {
    if(document.getElementById("aImgSqr35").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr35").src = "img/sqrs/wSqr.png"
};
};

function RsqrB11b() {
    if(document.getElementById("aImgSqr36").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr36").src = "img/sqrs/wSqr.png"
};
};

function RsqrB12b() {
    if(document.getElementById("aImgSqr37").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr37").src = "img/sqrs/wSqr.png"
};
};

function RsqrB13b() {
    if(document.getElementById("aImgSqr38").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr38").src = "img/sqrs/wSqr.png"
};
};

function RsqrB14b() {
    if(document.getElementById("aImgSqr39").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr39").src = "img/sqrs/wSqr.png"
};
};

function RsqrB15b() {
    if(document.getElementById("aImgSqr40").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr40").src = "img/sqrs/wSqr.png"
};
};

function RsqrB16b() {
    if(document.getElementById("aImgSqr41").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr41").src = "img/sqrs/wSqr.png"
};
};

function RsqrB17b() {
    if(document.getElementById("aImgSqr42").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr42").src = "img/sqrs/wSqr.png"
};
};

function RsqrB18b() {
    if(document.getElementById("aImgSqr43").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr43").src = "img/sqrs/wSqr.png"
};
};

function RsqrB19b() {
    if(document.getElementById("aImgSqr44").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr44").src = "img/sqrs/wSqr.png"
};
};

function RsqrB20b() {
    if(document.getElementById("aImgSqr45").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr45").src = "img/sqrs/wSqr.png"
};
};

function RsqrB21b() {
    if(document.getElementById("aImgSqr46").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr46").src = "img/sqrs/wSqr.png"
};
};

function RsqrB22b() {
    if(document.getElementById("aImgSqr47").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr47").src = "img/sqrs/wSqr.png"
};
};

function RsqrB23b() {
    if(document.getElementById("aImgSqr48").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr48").src = "img/sqrs/wSqr.png"
};
};

function RsqrB24b() {
    if(document.getElementById("aImgSqr49").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr49").src = "img/sqrs/wSqr.png"
};
};

function RsqrB25b() {
    if(document.getElementById("aImgSqr50").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr50").src = "img/sqrs/wSqr.png"
};
};

function RsqrC1b() {
    if(document.getElementById("aImgSqr51").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr51").src = "img/sqrs/wSqr.png"
};
};

function RsqrC2b() {
    if(document.getElementById("aImgSqr52").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr52").src = "img/sqrs/wSqr.png"
};
};

function RsqrC3b() {
    if(document.getElementById("aImgSqr53").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr53").src = "img/sqrs/wSqr.png"
};
};

function RsqrC4b() {
    if(document.getElementById("aImgSqr54").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr54").src = "img/sqrs/wSqr.png"
};
};

function RsqrC5b() {
    if(document.getElementById("aImgSqr55").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr55").src = "img/sqrs/wSqr.png"
};
};

function RsqrC6b() {
    if(document.getElementById("aImgSqr56").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr56").src = "img/sqrs/wSqr.png"
};
};

function RsqrC7b() {
    if(document.getElementById("aImgSqr57").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr57").src = "img/sqrs/wSqr.png"
};
};

function RsqrC8b() {
    if(document.getElementById("aImgSqr58").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr58").src = "img/sqrs/wSqr.png"
};
};

function RsqrC9b() {
    if(document.getElementById("aImgSqr59").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr59").src = "img/sqrs/wSqr.png"
};
};

function RsqrC10b() {
    if(document.getElementById("aImgSqr60").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr60").src = "img/sqrs/wSqr.png"
};
};

function RsqrC11b() {
    if(document.getElementById("aImgSqr61").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr61").src = "img/sqrs/wSqr.png"
};
};

function RsqrC12b() {
    if(document.getElementById("aImgSqr62").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr62").src = "img/sqrs/wSqr.png"
};
};

function RsqrC13b() {
    if(document.getElementById("aImgSqr63").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr63").src = "img/sqrs/wSqr.png"
};
};

function RsqrC14b() {
    if(document.getElementById("aImgSqr64").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr64").src = "img/sqrs/wSqr.png"
};
};

function RsqrC15b() {
    if(document.getElementById("aImgSqr65").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr65").src = "img/sqrs/wSqr.png"
};
};

function RsqrC16b() {
    if(document.getElementById("aImgSqr66").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr66").src = "img/sqrs/wSqr.png"
};
};

function RsqrC17b() {
    if(document.getElementById("aImgSqr67").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr67").src = "img/sqrs/wSqr.png"
};
};

function RsqrC18b() {
    if(document.getElementById("aImgSqr68").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr68").src = "img/sqrs/wSqr.png"
};
};

function RsqrC19b() {
    if(document.getElementById("aImgSqr69").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr69").src = "img/sqrs/wSqr.png"
};
};

function RsqrC20b() {
    if(document.getElementById("aImgSqr70").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr70").src = "img/sqrs/wSqr.png"
};
};

function RsqrC21b() {
    if(document.getElementById("aImgSqr71").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr71").src = "img/sqrs/wSqr.png"
};
};

function RsqrC22b() {
    if(document.getElementById("aImgSqr72").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr72").src = "img/sqrs/wSqr.png"
};
};

function RsqrC23b() {
    if(document.getElementById("aImgSqr73").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr73").src = "img/sqrs/wSqr.png"
};
};

function RsqrC24b() {
    if(document.getElementById("aImgSqr74").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr74").src = "img/sqrs/wSqr.png"
};
};

function RsqrC25b() {
    if(document.getElementById("aImgSqr75").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr75").src = "img/sqrs/wSqr.png"
 };
};

function RsqrD1b() {
    if(document.getElementById("aImgSqr76").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr76").src = "img/sqrs/wSqr.png"
};
};

function RsqrD2b() {
    if(document.getElementById("aImgSqr77").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr77").src = "img/sqrs/wSqr.png"
};
};

function RsqrD3b() {
    if(document.getElementById("aImgSqr78").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr78").src = "img/sqrs/wSqr.png"
};
};

function RsqrD4b() {
    if(document.getElementById("aImgSqr79").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr79").src = "img/sqrs/wSqr.png"
};
};

function RsqrD5b() {
    if(document.getElementById("aImgSqr80").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr80").src = "img/sqrs/wSqr.png"
};
};

function RsqrD6b() {
    if(document.getElementById("aImgSqr81").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr81").src = "img/sqrs/wSqr.png"
};
};

function RsqrD7b() {
    if(document.getElementById("aImgSqr82").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr82").src = "img/sqrs/wSqr.png"
};
};

function RsqrD8b() {
    if(document.getElementById("aImgSqr83").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr83").src = "img/sqrs/wSqr.png"
};
};

function RsqrD9b() {
    if(document.getElementById("aImgSqr84").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr84").src = "img/sqrs/wSqr.png"
};
};

function RsqrD10b() {
    if(document.getElementById("aImgSqr85").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr85").src = "img/sqrs/wSqr.png"
};
};

function RsqrD11b() {
    if(document.getElementById("aImgSqr86").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr86").src = "img/sqrs/wSqr.png"
};
};

function RsqrD12b() {
    if(document.getElementById("aImgSqr87").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr87").src = "img/sqrs/wSqr.png"
};
};

function RsqrD13b() {
    if(document.getElementById("aImgSqr88").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr88").src = "img/sqrs/wSqr.png"
};
};

function RsqrD14b() {
    if(document.getElementById("aImgSqr89").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr89").src = "img/sqrs/wSqr.png"
};
};

function RsqrD15b() {
    if(document.getElementById("aImgSqr90").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr90").src = "img/sqrs/wSqr.png"
};
};

function RsqrD16b() {
    if(document.getElementById("aImgSqr91").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr91").src = "img/sqrs/wSqr.png"
};
};

function RsqrD17b() {
    if(document.getElementById("aImgSqr92").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr92").src = "img/sqrs/wSqr.png"
};
};

function RsqrD18b() {
    if(document.getElementById("aImgSqr93").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr93").src = "img/sqrs/wSqr.png"
};
};

function RsqrD19b() {
    if(document.getElementById("aImgSqr94").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr94").src = "img/sqrs/wSqr.png"
};
};

function RsqrD20b() {
    if(document.getElementById("aImgSqr95").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr95").src = "img/sqrs/wSqr.png"
};
};

function RsqrD21b() {
    if(document.getElementById("aImgSqr96").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr96").src = "img/sqrs/wSqr.png"
};
};

function RsqrD22b() {
    if(document.getElementById("aImgSqr97").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr97").src = "img/sqrs/wSqr.png"
};
};

function RsqrD23b() {
    if(document.getElementById("aImgSqr98").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr98").src = "img/sqrs/wSqr.png"
};
};

function RsqrD24b() {
    if(document.getElementById("aImgSqr99").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr99").src = "img/sqrs/wSqr.png"
};
};

function RsqrD25b() {
    if(document.getElementById("aImgSqr100").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr100").src = "img/sqrs/wSqr.png"
 };
};

function RsqrE1b() {
    if(document.getElementById("aImgSqr101").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr101").src = "img/sqrs/wSqr.png"
};
};

function RsqrE2b() {
    if(document.getElementById("aImgSqr102").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr102").src = "img/sqrs/wSqr.png"
};
};

function RsqrE3b() {
    if(document.getElementById("aImgSqr103").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr103").src = "img/sqrs/wSqr.png"
};
};

function RsqrE4b() {
    if(document.getElementById("aImgSqr104").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr104").src = "img/sqrs/wSqr.png"
};
};

function RsqrE5b() {
    if(document.getElementById("aImgSqr105").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr105").src = "img/sqrs/wSqr.png"
};
};

function RsqrE6b() {
    if(document.getElementById("aImgSqr106").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr106").src = "img/sqrs/wSqr.png"
};
};

function RsqrE7b() {
    if(document.getElementById("aImgSqr107").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr107").src = "img/sqrs/wSqr.png"
};
};

function RsqrE8b() {
    if(document.getElementById("aImgSqr108").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr108").src = "img/sqrs/wSqr.png"
};
};

function RsqrE9b() {
    if(document.getElementById("aImgSqr109").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr109").src = "img/sqrs/wSqr.png"
};
};

function RsqrE10b() {
    if(document.getElementById("aImgSqr100").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr110").src = "img/sqrs/wSqr.png"
};
};

function RsqrE11b() {
    if(document.getElementById("aImgSqr111").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr111").src = "img/sqrs/wSqr.png"
};
};

function RsqrE12b() {
    if(document.getElementById("aImgSqr112").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr112").src = "img/sqrs/wSqr.png"
};
};

function RsqrE13b() {
    if(document.getElementById("aImgSqr113").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr113").src = "img/sqrs/wSqr.png"
};
};

function RsqrE14b() {
    if(document.getElementById("aImgSqr114").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr114").src = "img/sqrs/wSqr.png"
};
};

function RsqrE15b() {
    if(document.getElementById("aImgSqr115").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr115").src = "img/sqrs/wSqr.png"
};
};

function RsqrE16b() {
    if(document.getElementById("aImgSqr116").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr116").src = "img/sqrs/wSqr.png"
};
};

function RsqrE17b() {
    if(document.getElementById("aImgSqr117").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr117").src = "img/sqrs/wSqr.png"
};
};

function RsqrE18b() {
    if(document.getElementById("aImgSqr118").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr118").src = "img/sqrs/wSqr.png"
};
};

function RsqrE19b() {
    if(document.getElementById("aImgSqr119").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr119").src = "img/sqrs/wSqr.png"
};
};

function RsqrE20b() {
    if(document.getElementById("aImgSqr120").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr120").src = "img/sqrs/wSqr.png"
};
};

function RsqrE21b() {
    if(document.getElementById("aImgSqr121").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr121").src = "img/sqrs/wSqr.png"
};
};

function RsqrE22b() {
    if(document.getElementById("aImgSqr122").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr122").src = "img/sqrs/wSqr.png"
};
};

function RsqrE23b() {
    if(document.getElementById("aImgSqr123").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr123").src = "img/sqrs/wSqr.png"
};
};

function RsqrE24b() {
    if(document.getElementById("aImgSqr124").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr124").src = "img/sqrs/wSqr.png"
};
};

function RsqrE25b() {
    if(document.getElementById("aImgSqr125").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr125").src = "img/sqrs/wSqr.png"
 };
};

function RsqrF1b() {
    if(document.getElementById("aImgSqr126").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr126").src = "img/sqrs/wSqr.png"
};
};

function RsqrF2b() {
    if(document.getElementById("aImgSqr127").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr127").src = "img/sqrs/wSqr.png"
};
};

function RsqrF3b() {
    if(document.getElementById("aImgSqr128").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr128").src = "img/sqrs/wSqr.png"
};
};

function RsqrF4b() {
    if(document.getElementById("aImgSqr129").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr129").src = "img/sqrs/wSqr.png"
};
};

function RsqrF5b() {
    if(document.getElementById("aImgSqr130").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr130").src = "img/sqrs/wSqr.png"
};
};

function RsqrF6b() {
    if(document.getElementById("aImgSqr131").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr131").src = "img/sqrs/wSqr.png"
};
};

function RsqrF7b() {
    if(document.getElementById("aImgSqr132").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr132").src = "img/sqrs/wSqr.png"
};
};

function RsqrF8b() {
    if(document.getElementById("aImgSqr133").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr133").src = "img/sqrs/wSqr.png"
};
};

function RsqrF9b() {
    if(document.getElementById("aImgSqr134").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr134").src = "img/sqrs/wSqr.png"
};
};

function RsqrF10b() {
    if(document.getElementById("aImgSqr135").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr135").src = "img/sqrs/wSqr.png"
};
};

function RsqrF11b() {
    if(document.getElementById("aImgSqr136").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr136").src = "img/sqrs/wSqr.png"
};
};

function RsqrF12b() {
    if(document.getElementById("aImgSqr137").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr137").src = "img/sqrs/wSqr.png"
};
};

function RsqrF13b() {
    if(document.getElementById("aImgSqr138").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr138").src = "img/sqrs/wSqr.png"
};
};

function RsqrF14b() {
    if(document.getElementById("aImgSqr139").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr139").src = "img/sqrs/wSqr.png"
};
};

function RsqrF15b() {
    if(document.getElementById("aImgSqr140").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr140").src = "img/sqrs/wSqr.png"
};
};

function RsqrF16b() {
    if(document.getElementById("aImgSqr141").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr141").src = "img/sqrs/wSqr.png"
};
};

function RsqrF17b() {
    if(document.getElementById("aImgSqr142").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr142").src = "img/sqrs/wSqr.png"
};
};

function RsqrF18b() {
    if(document.getElementById("aImgSqr143").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr143").src = "img/sqrs/wSqr.png"
};
};

function RsqrF19b() {
    if(document.getElementById("aImgSqr144").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr144").src = "img/sqrs/wSqr.png"
};
};

function RsqrF20b() {
    if(document.getElementById("aImgSqr145").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr145").src = "img/sqrs/wSqr.png"
};
};

function RsqrF21b() {
    if(document.getElementById("aImgSqr146").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr146").src = "img/sqrs/wSqr.png"
};
};

function RsqrF22b() {
    if(document.getElementById("aImgSqr147").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr147").src = "img/sqrs/wSqr.png"
};
};

function RsqrF23b() {
    if(document.getElementById("aImgSqr148").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr148").src = "img/sqrs/wSqr.png"
};
};

function RsqrF24b() {
    if(document.getElementById("aImgSqr149").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr149").src = "img/sqrs/wSqr.png"
};
};

function RsqrF25b() {
    if(document.getElementById("aImgSqr150").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr150").src = "img/sqrs/wSqr.png"
 };
};

function RsqrG1b() {
    if(document.getElementById("aImgSqr151").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr151").src = "img/sqrs/wSqr.png"
};
};

function RsqrG2b() {
    if(document.getElementById("aImgSqr152").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr152").src = "img/sqrs/wSqr.png"
};
};

function RsqrG3b() {
    if(document.getElementById("aImgSqr153").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr153").src = "img/sqrs/wSqr.png"
};
};

function RsqrG4b() {
    if(document.getElementById("aImgSqr154").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr154").src = "img/sqrs/wSqr.png"
};
};

function RsqrG5b() {
    if(document.getElementById("aImgSqr155").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr155").src = "img/sqrs/wSqr.png"
};
};

function RsqrG6b() {
    if(document.getElementById("aImgSqr156").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr156").src = "img/sqrs/wSqr.png"
};
};

function RsqrG7b() {
    if(document.getElementById("aImgSqr157").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr157").src = "img/sqrs/wSqr.png"
};
};

function RsqrG8b() {
    if(document.getElementById("aImgSqr158").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr158").src = "img/sqrs/wSqr.png"
};
};

function RsqrG9b() {
    if(document.getElementById("aImgSqr159").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr159").src = "img/sqrs/wSqr.png"
};
};

function RsqrG10b() {
    if(document.getElementById("aImgSqr160").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr160").src = "img/sqrs/wSqr.png"
};
};

function RsqrG11b() {
    if(document.getElementById("aImgSqr161").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr161").src = "img/sqrs/wSqr.png"
};
};

function RsqrG12b() {
    if(document.getElementById("aImgSqr162").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr162").src = "img/sqrs/wSqr.png"
};
};

function RsqrG13b() {
    if(document.getElementById("aImgSqr163").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr163").src = "img/sqrs/wSqr.png"
};
};

function RsqrG14b() {
    if(document.getElementById("aImgSqr164").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr164").src = "img/sqrs/wSqr.png"
};
};

function RsqrG15b() {
    if(document.getElementById("aImgSqr165").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr165").src = "img/sqrs/wSqr.png"
};
};

function RsqrG16b() {
    if(document.getElementById("aImgSqr166").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr166").src = "img/sqrs/wSqr.png"
};
};

function RsqrG17b() {
    if(document.getElementById("aImgSqr167").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr167").src = "img/sqrs/wSqr.png"
};
};

function RsqrG18b() {
    if(document.getElementById("aImgSqr168").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr168").src = "img/sqrs/wSqr.png"
};
};

function RsqrG19b() {
    if(document.getElementById("aImgSqr169").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr169").src = "img/sqrs/wSqr.png"
};
};

function RsqrG20b() {
    if(document.getElementById("aImgSqr170").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr170").src = "img/sqrs/wSqr.png"
};
};

function RsqrG21b() {
    if(document.getElementById("aImgSqr171").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr171").src = "img/sqrs/wSqr.png"
};
};

function RsqrG22b() {
    if(document.getElementById("aImgSqr172").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr172").src = "img/sqrs/wSqr.png"
};
};

function RsqrG23b() {
    if(document.getElementById("aImgSqr173").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr173").src = "img/sqrs/wSqr.png"
};
};

function RsqrG24b() {
    if(document.getElementById("aImgSqr174").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr174").src = "img/sqrs/wSqr.png"
};
};

function RsqrG25b() {
    if(document.getElementById("aImgSqr175").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr175").src = "img/sqrs/wSqr.png"
};
};

function RsqrH1b() {
    if(document.getElementById("aImgSqr176").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr176").src = "img/sqrs/wSqr.png"
};
};

function RsqrH2b() {
    if(document.getElementById("aImgSqr177").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr177").src = "img/sqrs/wSqr.png"
};
};

function RsqrH3b() {
    if(document.getElementById("aImgSqr178").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr178").src = "img/sqrs/wSqr.png"
};
};

function RsqrH4b() {
    if(document.getElementById("aImgSqr179").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr179").src = "img/sqrs/wSqr.png"
};
};

function RsqrH5b() {
    if(document.getElementById("aImgSqr180").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr180").src = "img/sqrs/wSqr.png"
};
};

function RsqrH6b() {
    if(document.getElementById("aImgSqr181").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr181").src = "img/sqrs/wSqr.png"
};
};

function RsqrH7b() {
    if(document.getElementById("aImgSqr182").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr182").src = "img/sqrs/wSqr.png"
};
};

function RsqrH8b() {
    if(document.getElementById("aImgSqr183").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr183").src = "img/sqrs/wSqr.png"
};
};

function RsqrH9b() {
    if(document.getElementById("aImgSqr184").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr184").src = "img/sqrs/wSqr.png"
};
};

function RsqrH10b() {
    if(document.getElementById("aImgSqr185").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr185").src = "img/sqrs/wSqr.png"
};
};

function RsqrH11b() {
    if(document.getElementById("aImgSqr186").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr186").src = "img/sqrs/wSqr.png"
};
};

function RsqrH12b() {
    if(document.getElementById("aImgSqr187").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr187").src = "img/sqrs/wSqr.png"
};
};

function RsqrH13b() {
    if(document.getElementById("aImgSqr188").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr188").src = "img/sqrs/wSqr.png"
};
};

function RsqrH14b() {
    if(document.getElementById("aImgSqr189").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr189").src = "img/sqrs/wSqr.png"
};
};

function RsqrH15b() {
    if(document.getElementById("aImgSqr190").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr190").src = "img/sqrs/wSqr.png"
};
};

function RsqrH16b() {
    if(document.getElementById("aImgSqr191").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr191").src = "img/sqrs/wSqr.png"
};
};

function RsqrH17b() {
    if(document.getElementById("aImgSqr192").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr192").src = "img/sqrs/wSqr.png"
};
};

function RsqrH18b() {
    if(document.getElementById("aImgSqr193").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr193").src = "img/sqrs/wSqr.png"
};
};

function RsqrH19b() {
    if(document.getElementById("aImgSqr194").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr194").src = "img/sqrs/wSqr.png"
};
};

function RsqrH20b() {
    if(document.getElementById("aImgSqr195").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr195").src = "img/sqrs/wSqr.png"
};
};

function RsqrH21b() {
    if(document.getElementById("aImgSqr196").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr196").src = "img/sqrs/wSqr.png"
};
};

function RsqrH22b() {
    if(document.getElementById("aImgSqr197").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr197").src = "img/sqrs/wSqr.png"
};
};

function RsqrH23b() {
    if(document.getElementById("aImgSqr198").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr198").src = "img/sqrs/wSqr.png"
};
};

function RsqrH24b() {
    if(document.getElementById("aImgSqr199").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr199").src = "img/sqrs/wSqr.png"
};
};

function RsqrH25b() {
    if(document.getElementById("aImgSqr200").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr200").src = "img/sqrs/wSqr.png"
 };
};

function RsqrI1b() {
    if(document.getElementById("aImgSqr201").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr201").src = "img/sqrs/wSqr.png"
};
};

function RsqrI2b() {
    if(document.getElementById("aImgSqr202").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr202").src = "img/sqrs/wSqr.png"
};
};

function RsqrI3b() {
    if(document.getElementById("aImgSqr203").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr203").src = "img/sqrs/wSqr.png"
};
};

function RsqrI4b() {
    if(document.getElementById("aImgSqr204").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr204").src = "img/sqrs/wSqr.png"
};
};

function RsqrI5b() {
    if(document.getElementById("aImgSqr205").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr205").src = "img/sqrs/wSqr.png"
};
};

function RsqrI6b() {
    if(document.getElementById("aImgSqr206").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr206").src = "img/sqrs/wSqr.png"
};
};

function RsqrI7b() {
    if(document.getElementById("aImgSqr207").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr207").src = "img/sqrs/wSqr.png"
};
};

function RsqrI8b() {
    if(document.getElementById("aImgSqr208").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr208").src = "img/sqrs/wSqr.png"
};
};

function RsqrI9b() {
    if(document.getElementById("aImgSqr209").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr209").src = "img/sqrs/wSqr.png"
};
};

function RsqrI10b() {
    if(document.getElementById("aImgSqr210").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr210").src = "img/sqrs/wSqr.png"
};
};

function RsqrI11b() {
    if(document.getElementById("aImgSqr211").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr211").src = "img/sqrs/wSqr.png"
};
};

function RsqrI12b() {
    if(document.getElementById("aImgSqr212").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr212").src = "img/sqrs/wSqr.png"
};
};

function RsqrI13b() {
    if(document.getElementById("aImgSqr213").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr213").src = "img/sqrs/wSqr.png"
};
};

function RsqrI14b() {
    if(document.getElementById("aImgSqr214").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr214").src = "img/sqrs/wSqr.png"
};
};

function RsqrI15b() {
    if(document.getElementById("aImgSqr215").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr215").src = "img/sqrs/wSqr.png"
};
};

function RsqrI16b() {
    if(document.getElementById("aImgSqr216").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr216").src = "img/sqrs/wSqr.png"
};
};

function RsqrI17b() {
    if(document.getElementById("aImgSqr217").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr217").src = "img/sqrs/wSqr.png"
};
};

function RsqrI18b() {
    if(document.getElementById("aImgSqr218").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr218").src = "img/sqrs/wSqr.png"
};
};

function RsqrI19b() {
    if(document.getElementById("aImgSqr219").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr219").src = "img/sqrs/wSqr.png"
};
};

function RsqrI20b() {
    if(document.getElementById("aImgSqr220").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr220").src = "img/sqrs/wSqr.png"
};
};

function RsqrI21b() {
    if(document.getElementById("aImgSqr221").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr221").src = "img/sqrs/wSqr.png"
};
};

function RsqrI22b() {
    if(document.getElementById("aImgSqr222").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr222").src = "img/sqrs/wSqr.png"
};
};

function RsqrI23b() {
    if(document.getElementById("aImgSqr223").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr223").src = "img/sqrs/wSqr.png"
};
};

function RsqrI24b() {
    if(document.getElementById("aImgSqr224").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr224").src = "img/sqrs/wSqr.png"
};
};

function RsqrI25b() {
    if(document.getElementById("aImgSqr225").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr225").src = "img/sqrs/wSqr.png"
 };
};

function RsqrJ1b() {
    if(document.getElementById("aImgSqr226").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr226").src = "img/sqrs/wSqr.png"
};
};

function RsqrJ2b() {
    if(document.getElementById("aImgSqr227").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr227").src = "img/sqrs/wSqr.png"
};
};

function RsqrJ3b() {
    if(document.getElementById("aImgSqr228").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr228").src = "img/sqrs/wSqr.png"
};
};

function RsqrJ4b() {
    if(document.getElementById("aImgSqr229").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr229").src = "img/sqrs/wSqr.png"
};
};

function RsqrJ5b() {
    if(document.getElementById("aImgSqr230").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr230").src = "img/sqrs/wSqr.png"
};
};

function RsqrJ6b() {
    if(document.getElementById("aImgSqr231").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr231").src = "img/sqrs/wSqr.png"
};
};

function RsqrJ7b() {
    if(document.getElementById("aImgSqr232").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr232").src = "img/sqrs/wSqr.png"
};
};

function RsqrJ8b() {
    if(document.getElementById("aImgSqr233").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr233").src = "img/sqrs/wSqr.png"
};
};

function RsqrJ9b() {
    if(document.getElementById("aImgSqr234").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr234").src = "img/sqrs/wSqr.png"
};
};

function RsqrJ10b() {
    if(document.getElementById("aImgSqr235").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr235").src = "img/sqrs/wSqr.png"
};
};

function RsqrJ11b() {
    if(document.getElementById("aImgSqr236").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr236").src = "img/sqrs/wSqr.png"
};
};

function RsqrJ12b() {
    if(document.getElementById("aImgSqr237").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr237").src = "img/sqrs/wSqr.png"
};
};

function RsqrJ13b() {
    if(document.getElementById("aImgSqr238").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr238").src = "img/sqrs/wSqr.png"
};
};

function RsqrJ14b() {
    if(document.getElementById("aImgSqr239").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr239").src = "img/sqrs/wSqr.png"
};
};

function RsqrJ15b() {
    if(document.getElementById("aImgSqr240").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr240").src = "img/sqrs/wSqr.png"
};
};

function RsqrJ16b() {
    if(document.getElementById("aImgSqr241").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr241").src = "img/sqrs/wSqr.png"
};
};

function RsqrJ17b() {
    if(document.getElementById("aImgSqr242").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr242").src = "img/sqrs/wSqr.png"
};
};

function RsqrJ18b() {
    if(document.getElementById("aImgSqr243").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr243").src = "img/sqrs/wSqr.png"
};
};

function RsqrJ19b() {
    if(document.getElementById("aImgSqr244").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr244").src = "img/sqrs/wSqr.png"
};
};

function RsqrJ20b() {
    if(document.getElementById("aImgSqr245").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr245").src = "img/sqrs/wSqr.png"
};
};

function RsqrJ21b() {
    if(document.getElementById("aImgSqr246").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr246").src = "img/sqrs/wSqr.png"
};
};

function RsqrJ22b() {
    if(document.getElementById("aImgSqr247").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr247").src = "img/sqrs/wSqr.png"
};
};

function RsqrJ23b() {
    if(document.getElementById("aImgSqr248").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr248").src = "img/sqrs/wSqr.png"
};
};

function RsqrJ24b() {
    if(document.getElementById("aImgSqr249").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr249").src = "img/sqrs/wSqr.png"
};
};

function RsqrJ25b() {
    if(document.getElementById("aImgSqr250").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr250").src = "img/sqrs/wSqr.png"
 };
};

function RsqrK1b() {
    if(document.getElementById("aImgSqr251").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr251").src = "img/sqrs/wSqr.png"
};
};

function RsqrK2b() {
    if(document.getElementById("aImgSqr252").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr252").src = "img/sqrs/wSqr.png"
};
};

function RsqrK3b() {
    if(document.getElementById("aImgSqr253").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr253").src = "img/sqrs/wSqr.png"
};
};

function RsqrK4b() {
    if(document.getElementById("aImgSqr254").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr254").src = "img/sqrs/wSqr.png"
};
};

function RsqrK5b() {
    if(document.getElementById("aImgSqr255").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr255").src = "img/sqrs/wSqr.png"
};
};

function RsqrK6b() {
    if(document.getElementById("aImgSqr256").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr256").src = "img/sqrs/wSqr.png"
};
};

function RsqrK7b() {
    if(document.getElementById("aImgSqr257").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr257").src = "img/sqrs/wSqr.png"
};
};

function RsqrK8b() {
    if(document.getElementById("aImgSqr258").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr258").src = "img/sqrs/wSqr.png"
};
};

function RsqrK9b() {
    if(document.getElementById("aImgSqr259").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr259").src = "img/sqrs/wSqr.png"
};
};

function RsqrK10b() {
    if(document.getElementById("aImgSqr260").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr260").src = "img/sqrs/wSqr.png"
};
};

function RsqrK11b() {
    if(document.getElementById("aImgSqr261").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr261").src = "img/sqrs/wSqr.png"
};
};

function RsqrK12b() {
    if(document.getElementById("aImgSqr262").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr262").src = "img/sqrs/wSqr.png"
};
};

function RsqrK13b() {
    if(document.getElementById("aImgSqr263").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr263").src = "img/sqrs/wSqr.png"
};
};

function RsqrK14b() {
    if(document.getElementById("aImgSqr264").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr264").src = "img/sqrs/wSqr.png"
};
};

function RsqrK15b() {
    if(document.getElementById("aImgSqr265").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr265").src = "img/sqrs/wSqr.png"
};
};

function RsqrK16b() {
    if(document.getElementById("aImgSqr266").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr266").src = "img/sqrs/wSqr.png"
};
};

function RsqrK17b() {
    if(document.getElementById("aImgSqr267").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr267").src = "img/sqrs/wSqr.png"
};
};

function RsqrK18b() {
    if(document.getElementById("aImgSqr268").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr268").src = "img/sqrs/wSqr.png"
};
};

function RsqrK19b() {
    if(document.getElementById("aImgSqr269").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr269").src = "img/sqrs/wSqr.png"
};
};

function RsqrK20b() {
    if(document.getElementById("aImgSqr270").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr270").src = "img/sqrs/wSqr.png"
};
};

function RsqrK21b() {
    if(document.getElementById("aImgSqr271").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr271").src = "img/sqrs/wSqr.png"
};
};

function RsqrK22b() {
    if(document.getElementById("aImgSqr272").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr272").src = "img/sqrs/wSqr.png"
};
};

function RsqrK23b() {
    if(document.getElementById("aImgSqr273").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr273").src = "img/sqrs/wSqr.png"
};
};

function RsqrK24b() {
    if(document.getElementById("aImgSqr274").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr274").src = "img/sqrs/wSqr.png"
};
};

function RsqrK25b() {
    if(document.getElementById("aImgSqr275").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr275").src = "img/sqrs/wSqr.png"
 };
};

function RsqrL1b() {
    if(document.getElementById("aImgSqr276").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr276").src = "img/sqrs/wSqr.png"
};
};

function RsqrL2b() {
    if(document.getElementById("aImgSqr277").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr277").src = "img/sqrs/wSqr.png"
};
};

function RsqrL3b() {
    if(document.getElementById("aImgSqr278").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr278").src = "img/sqrs/wSqr.png"
};
};

function RsqrL4b() {
    if(document.getElementById("aImgSqr279").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr279").src = "img/sqrs/wSqr.png"
};
};

function RsqrL5b() {
    if(document.getElementById("aImgSqr280").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr280").src = "img/sqrs/wSqr.png"
};
};

function RsqrL6b() {
    if(document.getElementById("aImgSqr281").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr281").src = "img/sqrs/wSqr.png"
};
};

function RsqrL7b() {
    if(document.getElementById("aImgSqr282").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr282").src = "img/sqrs/wSqr.png"
};
};

function RsqrL8b() {
    if(document.getElementById("aImgSqr283").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr283").src = "img/sqrs/wSqr.png"
};
};

function RsqrL9b() {
    if(document.getElementById("aImgSqr284").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr284").src = "img/sqrs/wSqr.png"
};
};

function RsqrL10b() {
    if(document.getElementById("aImgSqr285").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr285").src = "img/sqrs/wSqr.png"
};
};

function RsqrL11b() {
    if(document.getElementById("aImgSqr286").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr286").src = "img/sqrs/wSqr.png"
};
};

function RsqrL12b() {
    if(document.getElementById("aImgSqr287").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr287").src = "img/sqrs/wSqr.png"
};
};

function RsqrL13b() {
    if(document.getElementById("aImgSqr288").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr288").src = "img/sqrs/wSqr.png"
};
};

function RsqrL14b() {
    if(document.getElementById("aImgSqr289").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr289").src = "img/sqrs/wSqr.png"
};
};

function RsqrL15b() {
    if(document.getElementById("aImgSqr290").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr290").src = "img/sqrs/wSqr.png"
};
};

function RsqrL16b() {
    if(document.getElementById("aImgSqr291").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr291").src = "img/sqrs/wSqr.png"
};
};

function RsqrL17b() {
    if(document.getElementById("aImgSqr292").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr292").src = "img/sqrs/wSqr.png"
};
};

function RsqrL18b() {
    if(document.getElementById("aImgSqr293").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr293").src = "img/sqrs/wSqr.png"
};
};

function RsqrL19b() {
    if(document.getElementById("aImgSqr294").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr294").src = "img/sqrs/wSqr.png"
};
};

function RsqrL20b() {
    if(document.getElementById("aImgSqr295").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr295").src = "img/sqrs/wSqr.png"
};
};

function RsqrL21b() {
    if(document.getElementById("aImgSqr296").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr296").src = "img/sqrs/wSqr.png"
};
};

function RsqrL22b() {
    if(document.getElementById("aImgSqr297").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr297").src = "img/sqrs/wSqr.png"
};
};

function RsqrL23b() {
    if(document.getElementById("aImgSqr298").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr298").src = "img/sqrs/wSqr.png"
};
};

function RsqrL24b() {
    if(document.getElementById("aImgSqr299").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr299").src = "img/sqrs/wSqr.png"
};
};

function RsqrL25b() {
    if(document.getElementById("aImgSqr300").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr300").src = "img/sqrs/wSqr.png"
 };
};

function RsqrM1b() {
    if(document.getElementById("aImgSqr301").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr301").src = "img/sqrs/wSqr.png"
};
};

function RsqrM2b() {
    if(document.getElementById("aImgSqr302").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr302").src = "img/sqrs/wSqr.png"
};
};

function RsqrM3b() {
    if(document.getElementById("aImgSqr303").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr303").src = "img/sqrs/wSqr.png"
};
};

function RsqrM4b() {
    if(document.getElementById("aImgSqr304").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr304").src = "img/sqrs/wSqr.png"
};
};

function RsqrM5b() {
    if(document.getElementById("aImgSqr305").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr305").src = "img/sqrs/wSqr.png"
};
};

function RsqrM6b() {
    if(document.getElementById("aImgSqr306").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr306").src = "img/sqrs/wSqr.png"
};
};

function RsqrM7b() {
    if(document.getElementById("aImgSqr307").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr307").src = "img/sqrs/wSqr.png"
};
};

function RsqrM8b() {
    if(document.getElementById("aImgSqr308").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr308").src = "img/sqrs/wSqr.png"
};
};

function RsqrM9b() {
    if(document.getElementById("aImgSqr309").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr309").src = "img/sqrs/wSqr.png"
};
};

function RsqrM10b() {
    if(document.getElementById("aImgSqr310").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr310").src = "img/sqrs/wSqr.png"
};
};

function RsqrM11b() {
    if(document.getElementById("aImgSqr311").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr311").src = "img/sqrs/wSqr.png"
};
};

function RsqrM12b() {
    if(document.getElementById("aImgSqr312").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr312").src = "img/sqrs/wSqr.png"
};
};

function RsqrM13b() {
    if(document.getElementById("aImgSqr313").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr313").src = "img/sqrs/wSqr.png"
};
};

function RsqrM14b() {
    if(document.getElementById("aImgSqr314").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr314").src = "img/sqrs/wSqr.png"
};
};

function RsqrM15b() {
    if(document.getElementById("aImgSqr315").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr315").src = "img/sqrs/wSqr.png"
};
};

function RsqrM16b() {
    if(document.getElementById("aImgSqr316").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr316").src = "img/sqrs/wSqr.png"
};
};

function RsqrM17b() {
    if(document.getElementById("aImgSqr317").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr317").src = "img/sqrs/wSqr.png"
};
};

function RsqrM18b() {
    if(document.getElementById("aImgSqr318").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr318").src = "img/sqrs/wSqr.png"
};
};

function RsqrM19b() {
    if(document.getElementById("aImgSqr319").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr319").src = "img/sqrs/wSqr.png"
};
};

function RsqrM20b() {
    if(document.getElementById("aImgSqr320").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr320").src = "img/sqrs/wSqr.png"
};
};

function RsqrM21b() {
    if(document.getElementById("aImgSqr321").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr321").src = "img/sqrs/wSqr.png"
};
};

function RsqrM22b() {
    if(document.getElementById("aImgSqr322").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr322").src = "img/sqrs/wSqr.png"
};
};

function RsqrM23b() {
    if(document.getElementById("aImgSqr323").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr323").src = "img/sqrs/wSqr.png"
};
};

function RsqrM24b() {
    if(document.getElementById("aImgSqr324").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr324").src = "img/sqrs/wSqr.png"
};
};

function RsqrM25b() {
    if(document.getElementById("aImgSqr325").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr325").src = "img/sqrs/wSqr.png"
 };
};

function RsqrN1b() {
    if(document.getElementById("aImgSqr326").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr326").src = "img/sqrs/wSqr.png"
};
};

function RsqrN2b() {
    if(document.getElementById("aImgSqr327").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr327").src = "img/sqrs/wSqr.png"
};
};

function RsqrN3b() {
    if(document.getElementById("aImgSqr328").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr328").src = "img/sqrs/wSqr.png"
};
};

function RsqrN4b() {
    if(document.getElementById("aImgSqr329").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr329").src = "img/sqrs/wSqr.png"
};
};

function RsqrN5b() {
    if(document.getElementById("aImgSqr330").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr330").src = "img/sqrs/wSqr.png"
};
};

function RsqrN6b() {
    if(document.getElementById("aImgSqr331").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr331").src = "img/sqrs/wSqr.png"
};
};

function RsqrN7b() {
    if(document.getElementById("aImgSqr332").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr332").src = "img/sqrs/wSqr.png"
};
};

function RsqrN8b() {
    if(document.getElementById("aImgSqr333").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr333").src = "img/sqrs/wSqr.png"
};
};

function RsqrN9b() {
    if(document.getElementById("aImgSqr334").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr334").src = "img/sqrs/wSqr.png"
};
};

function RsqrN10b() {
    if(document.getElementById("aImgSqr335").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr335").src = "img/sqrs/wSqr.png"
};
};

function RsqrN11b() {
    if(document.getElementById("aImgSqr336").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr336").src = "img/sqrs/wSqr.png"
};
};

function RsqrN12b() {
    if(document.getElementById("aImgSqr337").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr337").src = "img/sqrs/wSqr.png"
};
};

function RsqrN13b() {
    if(document.getElementById("aImgSqr338").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr338").src = "img/sqrs/wSqr.png"
};
};

function RsqrN14b() {
    if(document.getElementById("aImgSqr339").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr339").src = "img/sqrs/wSqr.png"
};
};

function RsqrN15b() {
    if(document.getElementById("aImgSqr340").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr340").src = "img/sqrs/wSqr.png"
};
};

function RsqrN16b() {
    if(document.getElementById("aImgSqr341").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr341").src = "img/sqrs/wSqr.png"
};
};

function RsqrN17b() {
    if(document.getElementById("aImgSqr342").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr342").src = "img/sqrs/wSqr.png"
};
};

function RsqrN18b() {
    if(document.getElementById("aImgSqr343").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr343").src = "img/sqrs/wSqr.png"
};
};

function RsqrN19b() {
    if(document.getElementById("aImgSqr344").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr344").src = "img/sqrs/wSqr.png"
};
};

function RsqrN20b() {
    if(document.getElementById("aImgSqr345").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr345").src = "img/sqrs/wSqr.png"
};
};

function RsqrN21b() {
    if(document.getElementById("aImgSqr346").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr346").src = "img/sqrs/wSqr.png"
};
};

function RsqrN22b() {
    if(document.getElementById("aImgSqr347").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr347").src = "img/sqrs/wSqr.png"
};
};

function RsqrN23b() {
    if(document.getElementById("aImgSqr348").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr348").src = "img/sqrs/wSqr.png"
};
};

function RsqrN24b() {
    if(document.getElementById("aImgSqr349").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr349").src = "img/sqrs/wSqr.png"
};
};

function RsqrN25b() {
    if(document.getElementById("aImgSqr350").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr350").src = "img/sqrs/wSqr.png"
 };
};

function RsqrO1b() {
    if(document.getElementById("aImgSqr351").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr351").src = "img/sqrs/wSqr.png"
};
};

function RsqrO2b() {
    if(document.getElementById("aImgSqr352").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr352").src = "img/sqrs/wSqr.png"
};
};

function RsqrO3b() {
    if(document.getElementById("aImgSqr353").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr353").src = "img/sqrs/wSqr.png"
};
};

function RsqrO4b() {
    if(document.getElementById("aImgSqr354").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr354").src = "img/sqrs/wSqr.png"
};
};

function RsqrO5b() {
    if(document.getElementById("aImgSqr355").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr355").src = "img/sqrs/wSqr.png"
};
};

function RsqrO6b() {
    if(document.getElementById("aImgSqr356").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr356").src = "img/sqrs/wSqr.png"
};
};

function RsqrO7b() {
    if(document.getElementById("aImgSqr357").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr357").src = "img/sqrs/wSqr.png"
};
};

function RsqrO8b() {
    if(document.getElementById("aImgSqr358").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr358").src = "img/sqrs/wSqr.png"
};
};

function RsqrO9b() {
    if(document.getElementById("aImgSqr359").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr359").src = "img/sqrs/wSqr.png"
};
};

function RsqrO10b() {
    if(document.getElementById("aImgSqr360").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr360").src = "img/sqrs/wSqr.png"
};
};

function RsqrO11b() {
    if(document.getElementById("aImgSqr361").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr361").src = "img/sqrs/wSqr.png"
};
};

function RsqrO12b() {
    if(document.getElementById("aImgSqr362").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr362").src = "img/sqrs/wSqr.png"
};
};

function RsqrO13b() {
    if(document.getElementById("aImgSqr363").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr363").src = "img/sqrs/wSqr.png"
};
};

function RsqrO14b() {
    if(document.getElementById("aImgSqr364").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr364").src = "img/sqrs/wSqr.png"
};
};

function RsqrO15b() {
    if(document.getElementById("aImgSqr365").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr365").src = "img/sqrs/wSqr.png"
};
};

function RsqrO16b() {
    if(document.getElementById("aImgSqr366").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr366").src = "img/sqrs/wSqr.png"
};
};

function RsqrO17b() {
    if(document.getElementById("aImgSqr367").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr367").src = "img/sqrs/wSqr.png"
};
};

function RsqrO18b() {
    if(document.getElementById("aImgSqr368").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr368").src = "img/sqrs/wSqr.png"
};
};

function RsqrO19b() {
    if(document.getElementById("aImgSqr369").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr369").src = "img/sqrs/wSqr.png"
};
};

function RsqrO20b() {
    if(document.getElementById("aImgSqr370").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr370").src = "img/sqrs/wSqr.png"
};
};

function RsqrO21b() {
    if(document.getElementById("aImgSqr371").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr371").src = "img/sqrs/wSqr.png"
};
};

function RsqrO22b() {
    if(document.getElementById("aImgSqr372").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr372").src = "img/sqrs/wSqr.png"
};
};

function RsqrO23b() {
    if(document.getElementById("aImgSqr373").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr373").src = "img/sqrs/wSqr.png"
};
};

function RsqrO24b() {
    if(document.getElementById("aImgSqr374").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr374").src = "img/sqrs/wSqr.png"
};
};

function RsqrO25b() {
    if(document.getElementById("aImgSqr375").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr375").src = "img/sqrs/wSqr.png"
 };
};

function RsqrP1b() {
    if(document.getElementById("aImgSqr376").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr376").src = "img/sqrs/wSqr.png"
};
};

function RsqrP2b() {
    if(document.getElementById("aImgSqr377").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr377").src = "img/sqrs/wSqr.png"
};
};

function RsqrP3b() {
    if(document.getElementById("aImgSqr378").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr378").src = "img/sqrs/wSqr.png"
};
};

function RsqrP4b() {
    if(document.getElementById("aImgSqr379").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr379").src = "img/sqrs/wSqr.png"
};
};

function RsqrP5b() {
    if(document.getElementById("aImgSqr380").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr380").src = "img/sqrs/wSqr.png"
};
};

function RsqrP6b() {
    if(document.getElementById("aImgSqr381").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr381").src = "img/sqrs/wSqr.png"
};
};

function RsqrP7b() {
    if(document.getElementById("aImgSqr382").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr382").src = "img/sqrs/wSqr.png"
};
};

function RsqrP8b() {
    if(document.getElementById("aImgSqr383").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr383").src = "img/sqrs/wSqr.png"
};
};

function RsqrP9b() {
    if(document.getElementById("aImgSqr384").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr384").src = "img/sqrs/wSqr.png"
};
};

function RsqrP10b() {
    if(document.getElementById("aImgSqr385").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr385").src = "img/sqrs/wSqr.png"
};
};

function RsqrP11b() {
    if(document.getElementById("aImgSqr386").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr386").src = "img/sqrs/wSqr.png"
};
};

function RsqrP12b() {
    if(document.getElementById("aImgSqr387").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr387").src = "img/sqrs/wSqr.png"
};
};

function RsqrP13b() {
    if(document.getElementById("aImgSqr388").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr388").src = "img/sqrs/wSqr.png"
};
};

function RsqrP14b() {
    if(document.getElementById("aImgSqr389").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr389").src = "img/sqrs/wSqr.png"
};
};

function RsqrP15b() {
    if(document.getElementById("aImgSqr390").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr390").src = "img/sqrs/wSqr.png"
};
};

function RsqrP16b() {
    if(document.getElementById("aImgSqr391").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr391").src = "img/sqrs/wSqr.png"
};
};

function RsqrP17b() {
    if(document.getElementById("aImgSqr392").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr392").src = "img/sqrs/wSqr.png"
};
};

function RsqrP18b() {
    if(document.getElementById("aImgSqr393").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr393").src = "img/sqrs/wSqr.png"
};
};

function RsqrP19b() {
    if(document.getElementById("aImgSqr394").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr394").src = "img/sqrs/wSqr.png"
};
};

function RsqrP20b() {
    if(document.getElementById("aImgSqr395").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr395").src = "img/sqrs/wSqr.png"
};
};

function RsqrP21b() {
    if(document.getElementById("aImgSqr396").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr396").src = "img/sqrs/wSqr.png"
};
};

function RsqrP22b() {
    if(document.getElementById("aImgSqr397").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr397").src = "img/sqrs/wSqr.png"
};
};

function RsqrP23b() {
    if(document.getElementById("aImgSqr398").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr398").src = "img/sqrs/wSqr.png"
};
};

function RsqrP24b() {
    if(document.getElementById("aImgSqr399").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr399").src = "img/sqrs/wSqr.png"
};
};

function RsqrP25b() {
    if(document.getElementById("aImgSqr400").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr400").src = "img/sqrs/wSqr.png"
 };
};

function RsqrQ1b() {
    if(document.getElementById("aImgSqr401").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr401").src = "img/sqrs/wSqr.png"
};
};

function RsqrQ2b() {
    if(document.getElementById("aImgSqr402").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr402").src = "img/sqrs/wSqr.png"
};
};

function RsqrQ3b() {
    if(document.getElementById("aImgSqr403").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr403").src = "img/sqrs/wSqr.png"
};
};

function RsqrQ4b() {
    if(document.getElementById("aImgSqr404").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr404").src = "img/sqrs/wSqr.png"
};
};

function RsqrQ5b() {
    if(document.getElementById("aImgSqr405").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr405").src = "img/sqrs/wSqr.png"
};
};

function RsqrQ6b() {
    if(document.getElementById("aImgSqr406").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr406").src = "img/sqrs/wSqr.png"
};
};

function RsqrQ7b() {
    if(document.getElementById("aImgSqr407").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr407").src = "img/sqrs/wSqr.png"
};
};

function RsqrQ8b() {
    if(document.getElementById("aImgSqr408").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr408").src = "img/sqrs/wSqr.png"
};
};

function RsqrQ9b() {
    if(document.getElementById("aImgSqr409").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr409").src = "img/sqrs/wSqr.png"
};
};

function RsqrQ10b() {
    if(document.getElementById("aImgSqr410").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr410").src = "img/sqrs/wSqr.png"
};
};

function RsqrQ11b() {
    if(document.getElementById("aImgSqr411").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr411").src = "img/sqrs/wSqr.png"
};
};

function RsqrQ12b() {
    if(document.getElementById("aImgSqr412").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr412").src = "img/sqrs/wSqr.png"
};
};

function RsqrQ13b() {
    if(document.getElementById("aImgSqr413").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr413").src = "img/sqrs/wSqr.png"
};
};

function RsqrQ14b() {
    if(document.getElementById("aImgSqr414").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr414").src = "img/sqrs/wSqr.png"
};
};

function RsqrQ15b() {
    if(document.getElementById("aImgSqr415").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr415").src = "img/sqrs/wSqr.png"
};
};

function RsqrQ16b() {
    if(document.getElementById("aImgSqr416").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr416").src = "img/sqrs/wSqr.png"
};
};

function RsqrQ17b() {
    if(document.getElementById("aImgSqr417").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr417").src = "img/sqrs/wSqr.png"
};
};

function RsqrQ18b() {
    if(document.getElementById("aImgSqr418").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr418").src = "img/sqrs/wSqr.png"
};
};

function RsqrQ19b() {
    if(document.getElementById("aImgSqr419").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr419").src = "img/sqrs/wSqr.png"
};
};

function RsqrQ20b() {
    if(document.getElementById("aImgSqr420").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr420").src = "img/sqrs/wSqr.png"
};
};

function RsqrQ21b() {
    if(document.getElementById("aImgSqr421").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr421").src = "img/sqrs/wSqr.png"
};
};

function RsqrQ22b() {
    if(document.getElementById("aImgSqr422").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr422").src = "img/sqrs/wSqr.png"
};
};

function RsqrQ23b() {
    if(document.getElementById("aImgSqr423").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr423").src = "img/sqrs/wSqr.png"
};
};

function RsqrQ24b() {
    if(document.getElementById("aImgSqr424").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr424").src = "img/sqrs/wSqr.png"
};
};

function RsqrQ25b() {
    if(document.getElementById("aImgSqr425").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr425").src = "img/sqrs/wSqr.png"
 };
};

function RsqrR1b() {
    if(document.getElementById("aImgSqr426").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr426").src = "img/sqrs/wSqr.png"
};
};

function RsqrR2b() {
    if(document.getElementById("aImgSqr427").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr427").src = "img/sqrs/wSqr.png"
};
};

function RsqrR3b() {
    if(document.getElementById("aImgSqr428").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr428").src = "img/sqrs/wSqr.png"
};
};

function RsqrR4b() {
    if(document.getElementById("aImgSqr429").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr429").src = "img/sqrs/wSqr.png"
};
};

function RsqrR5b() {
    if(document.getElementById("aImgSqr430").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr430").src = "img/sqrs/wSqr.png"
};
};

function RsqrR6b() {
    if(document.getElementById("aImgSqr431").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr431").src = "img/sqrs/wSqr.png"
};
};

function RsqrR7b() {
    if(document.getElementById("aImgSqr432").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr432").src = "img/sqrs/wSqr.png"
};
};

function RsqrR8b() {
    if(document.getElementById("aImgSqr433").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr433").src = "img/sqrs/wSqr.png"
};
};

function RsqrR9b() {
    if(document.getElementById("aImgSqr434").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr434").src = "img/sqrs/wSqr.png"
};
};

function RsqrR10b() {
    if(document.getElementById("aImgSqr435").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr435").src = "img/sqrs/wSqr.png"
};
};

function RsqrR11b() {
    if(document.getElementById("aImgSqr436").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr436").src = "img/sqrs/wSqr.png"
};
};

function RsqrR12b() {
    if(document.getElementById("aImgSqr437").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr437").src = "img/sqrs/wSqr.png"
};
};

function RsqrR13b() {
    if(document.getElementById("aImgSqr438").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr438").src = "img/sqrs/wSqr.png"
};
};

function RsqrR14b() {
    if(document.getElementById("aImgSqr439").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr439").src = "img/sqrs/wSqr.png"
};
};

function RsqrR15b() {
    if(document.getElementById("aImgSqr440").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr440").src = "img/sqrs/wSqr.png"
};
};

function RsqrR16b() {
    if(document.getElementById("aImgSqr441").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr441").src = "img/sqrs/wSqr.png"
};
};

function RsqrR17b() {
    if(document.getElementById("aImgSqr442").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr442").src = "img/sqrs/wSqr.png"
};
};

function RsqrR18b() {
    if(document.getElementById("aImgSqr443").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr443").src = "img/sqrs/wSqr.png"
};
};

function RsqrR19b() {
    if(document.getElementById("aImgSqr444").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr444").src = "img/sqrs/wSqr.png"
};
};

function RsqrR20b() {
    if(document.getElementById("aImgSqr445").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr445").src = "img/sqrs/wSqr.png"
};
};

function RsqrR21b() {
    if(document.getElementById("aImgSqr446").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr446").src = "img/sqrs/wSqr.png"
};
};

function RsqrR22b() {
    if(document.getElementById("aImgSqr447").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr447").src = "img/sqrs/wSqr.png"
};
};

function RsqrR23b() {
    if(document.getElementById("aImgSqr448").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr448").src = "img/sqrs/wSqr.png"
};
};

function RsqrR24b() {
    if(document.getElementById("aImgSqr449").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr449").src = "img/sqrs/wSqr.png"
};
};

function RsqrR25b() {
    if(document.getElementById("aImgSqr450").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr450").src = "img/sqrs/wSqr.png"
 };
};

function RsqrS1b() {
    if(document.getElementById("aImgSqr451").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr451").src = "img/sqrs/wSqr.png"
};
};

function RsqrS2b() {
    if(document.getElementById("aImgSqr452").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr452").src = "img/sqrs/wSqr.png"
};
};

function RsqrS3b() {
    if(document.getElementById("aImgSqr453").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr453").src = "img/sqrs/wSqr.png"
};
};

function RsqrS4b() {
    if(document.getElementById("aImgSqr454").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr454").src = "img/sqrs/wSqr.png"
};
};

function RsqrS5b() {
    if(document.getElementById("aImgSqr455").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr455").src = "img/sqrs/wSqr.png"
};
};

function RsqrS6b() {
    if(document.getElementById("aImgSqr456").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr456").src = "img/sqrs/wSqr.png"
};
};

function RsqrS7b() {
    if(document.getElementById("aImgSqr457").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr457").src = "img/sqrs/wSqr.png"
};
};

function RsqrS8b() {
    if(document.getElementById("aImgSqr458").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr458").src = "img/sqrs/wSqr.png"
};
};

function RsqrS9b() {
    if(document.getElementById("aImgSqr459").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr459").src = "img/sqrs/wSqr.png"
};
};

function RsqrS10b() {
    if(document.getElementById("aImgSqr460").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr460").src = "img/sqrs/wSqr.png"
};
};

function RsqrS11b() {
    if(document.getElementById("aImgSqr461").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr461").src = "img/sqrs/wSqr.png"
};
};

function RsqrS12b() {
    if(document.getElementById("aImgSqr462").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr462").src = "img/sqrs/wSqr.png"
};
};

function RsqrS13b() {
    if(document.getElementById("aImgSqr463").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr463").src = "img/sqrs/wSqr.png"
};
};

function RsqrS14b() {
    if(document.getElementById("aImgSqr464").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr464").src = "img/sqrs/wSqr.png"
};
};

function RsqrS15b() {
    if(document.getElementById("aImgSqr465").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr465").src = "img/sqrs/wSqr.png"
};
};

function RsqrS16b() {
    if(document.getElementById("aImgSqr466").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr466").src = "img/sqrs/wSqr.png"
};
};

function RsqrS17b() {
    if(document.getElementById("aImgSqr467").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr467").src = "img/sqrs/wSqr.png"
};
};

function RsqrS18b() {
    if(document.getElementById("aImgSqr468").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr468").src = "img/sqrs/wSqr.png"
};
};

function RsqrS19b() {
    if(document.getElementById("aImgSqr469").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr469").src = "img/sqrs/wSqr.png"
};
};

function RsqrS20b() {
    if(document.getElementById("aImgSqr470").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr470").src = "img/sqrs/wSqr.png"
};
};

function RsqrS21b() {
    if(document.getElementById("aImgSqr471").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr471").src = "img/sqrs/wSqr.png"
};
};

function RsqrS22b() {
    if(document.getElementById("aImgSqr472").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr472").src = "img/sqrs/wSqr.png"
};
};

function RsqrS23b() {
    if(document.getElementById("aImgSqr473").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr473").src = "img/sqrs/wSqr.png"
};
};

function RsqrS24b() {
    if(document.getElementById("aImgSqr474").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr474").src = "img/sqrs/wSqr.png"
};
};

function RsqrS25b() {
    if(document.getElementById("aImgSqr475").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr475").src = "img/sqrs/wSqr.png"
 };
};

function RsqrT1b() {
    if(document.getElementById("aImgSqr476").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr476").src = "img/sqrs/wSqr.png"
};
};

function RsqrT2b() {
    if(document.getElementById("aImgSqr477").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr477").src = "img/sqrs/wSqr.png"
};
};

function RsqrT3b() {
    if(document.getElementById("aImgSqr478").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr478").src = "img/sqrs/wSqr.png"
};
};

function RsqrT4b() {
    if(document.getElementById("aImgSqr479").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr479").src = "img/sqrs/wSqr.png"
};
};

function RsqrT5b() {
    if(document.getElementById("aImgSqr480").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr480").src = "img/sqrs/wSqr.png"
};
};

function RsqrT6b() {
    if(document.getElementById("aImgSqr481").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr481").src = "img/sqrs/wSqr.png"
};
};

function RsqrT7b() {
    if(document.getElementById("aImgSqr482").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr482").src = "img/sqrs/wSqr.png"
};
};

function RsqrT8b() {
    if(document.getElementById("aImgSqr483").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr483").src = "img/sqrs/wSqr.png"
};
};

function RsqrT9b() {
    if(document.getElementById("aImgSqr484").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr484").src = "img/sqrs/wSqr.png"
};
};

function RsqrT10b() {
    if(document.getElementById("aImgSqr485").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr485").src = "img/sqrs/wSqr.png"
};
};

function RsqrT11b() {
    if(document.getElementById("aImgSqr486").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr486").src = "img/sqrs/wSqr.png"
};
};

function RsqrT12b() {
    if(document.getElementById("aImgSqr487").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr487").src = "img/sqrs/wSqr.png"
};
};

function RsqrT13b() {
    if(document.getElementById("aImgSqr488").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr488").src = "img/sqrs/wSqr.png"
};
};

function RsqrT14b() {
    if(document.getElementById("aImgSqr489").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr489").src = "img/sqrs/wSqr.png"
};
};

function RsqrT15b() {
    if(document.getElementById("aImgSqr490").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr490").src = "img/sqrs/wSqr.png"
};
};

function RsqrT16b() {
    if(document.getElementById("aImgSqr491").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr491").src = "img/sqrs/wSqr.png"
};
};

function RsqrT17b() {
    if(document.getElementById("aImgSqr492").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr492").src = "img/sqrs/wSqr.png"
};
};

function RsqrT18b() {
    if(document.getElementById("aImgSqr493").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr493").src = "img/sqrs/wSqr.png"
};
};

function RsqrT19b() {
    if(document.getElementById("aImgSqr494").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr494").src = "img/sqrs/wSqr.png"
};
};

function RsqrT20b() {
    if(document.getElementById("aImgSqr495").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr495").src = "img/sqrs/wSqr.png"
};
};

function RsqrT21b() {
    if(document.getElementById("aImgSqr496").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr496").src = "img/sqrs/wSqr.png"
};
};

function RsqrT22b() {
    if(document.getElementById("aImgSqr497").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr497").src = "img/sqrs/wSqr.png"
};
};

function RsqrT23b() {
    if(document.getElementById("aImgSqr498").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr498").src = "img/sqrs/wSqr.png"
};
};

function RsqrT24b() {
    if(document.getElementById("aImgSqr499").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr499").src = "img/sqrs/wSqr.png"
};
};

function RsqrT25b() {
    if(document.getElementById("aImgSqr500").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr500").src = "img/sqrs/wSqr.png"
 };
};

function RsqrU1b() {
    if(document.getElementById("aImgSqr501").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr501").src = "img/sqrs/wSqr.png"
};
};

function RsqrU2b() {
    if(document.getElementById("aImgSqr502").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr502").src = "img/sqrs/wSqr.png"
};
};

function RsqrU3b() {
    if(document.getElementById("aImgSqr503").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr503").src = "img/sqrs/wSqr.png"
};
};

function RsqrU4b() {
    if(document.getElementById("aImgSqr504").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr504").src = "img/sqrs/wSqr.png"
};
};

function RsqrU5b() {
    if(document.getElementById("aImgSqr505").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr505").src = "img/sqrs/wSqr.png"
};
};

function RsqrU6b() {
    if(document.getElementById("aImgSqr506").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr506").src = "img/sqrs/wSqr.png"
};
};

function RsqrU7b() {
    if(document.getElementById("aImgSqr507").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr507").src = "img/sqrs/wSqr.png"
};
};

function RsqrU8b() {
    if(document.getElementById("aImgSqr508").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr508").src = "img/sqrs/wSqr.png"
};
};

function RsqrU9b() {
    if(document.getElementById("aImgSqr509").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr509").src = "img/sqrs/wSqr.png"
};
};

function RsqrU10b() {
    if(document.getElementById("aImgSqr510").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr510").src = "img/sqrs/wSqr.png"
};
};

function RsqrU11b() {
    if(document.getElementById("aImgSqr511").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr511").src = "img/sqrs/wSqr.png"
};
};

function RsqrU12b() {
    if(document.getElementById("aImgSqr512").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr512").src = "img/sqrs/wSqr.png"
};
};

function RsqrU13b() {
    if(document.getElementById("aImgSqr513").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr513").src = "img/sqrs/wSqr.png"
};
};

function RsqrU14b() {
    if(document.getElementById("aImgSqr514").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr514").src = "img/sqrs/wSqr.png"
};
};

function RsqrU15b() {
    if(document.getElementById("aImgSqr515").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr515").src = "img/sqrs/wSqr.png"
};
};

function RsqrU16b() {
    if(document.getElementById("aImgSqr516").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr516").src = "img/sqrs/wSqr.png"
};
};

function RsqrU17b() {
    if(document.getElementById("aImgSqr517").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr517").src = "img/sqrs/wSqr.png"
};
};

function RsqrU18b() {
    if(document.getElementById("aImgSqr518").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr518").src = "img/sqrs/wSqr.png"
};
};

function RsqrU19b() {
    if(document.getElementById("aImgSqr519").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr519").src = "img/sqrs/wSqr.png"
};
};

function RsqrU20b() {
    if(document.getElementById("aImgSqr520").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr520").src = "img/sqrs/wSqr.png"
};
};

function RsqrU21b() {
    if(document.getElementById("aImgSqr521").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr521").src = "img/sqrs/wSqr.png"
};
};

function RsqrU22b() {
    if(document.getElementById("aImgSqr522").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr522").src = "img/sqrs/wSqr.png"
};
};

function RsqrU23b() {
    if(document.getElementById("aImgSqr523").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr523").src = "img/sqrs/wSqr.png"
};
};

function RsqrU24b() {
    if(document.getElementById("aImgSqr524").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr524").src = "img/sqrs/wSqr.png"
};
};

function RsqrU25b() {
    if(document.getElementById("aImgSqr525").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr525").src = "img/sqrs/wSqr.png"
 };
};

function RsqrV1b() {
    if(document.getElementById("aImgSqr526").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr526").src = "img/sqrs/wSqr.png"
};
};

function RsqrV2b() {
    if(document.getElementById("aImgSqr527").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr527").src = "img/sqrs/wSqr.png"
};
};

function RsqrV3b() {
    if(document.getElementById("aImgSqr528").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr528").src = "img/sqrs/wSqr.png"
};
};

function RsqrV4b() {
    if(document.getElementById("aImgSqr529").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr529").src = "img/sqrs/wSqr.png"
};
};

function RsqrV5b() {
    if(document.getElementById("aImgSqr530").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr530").src = "img/sqrs/wSqr.png"
};
};

function RsqrV6b() {
    if(document.getElementById("aImgSqr531").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr531").src = "img/sqrs/wSqr.png"
};
};

function RsqrV7b() {
    if(document.getElementById("aImgSqr532").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr532").src = "img/sqrs/wSqr.png"
};
};

function RsqrV8b() {
    if(document.getElementById("aImgSqr533").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr533").src = "img/sqrs/wSqr.png"
};
};

function RsqrV9b() {
    if(document.getElementById("aImgSqr534").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr534").src = "img/sqrs/wSqr.png"
};
};

function RsqrV10b() {
    if(document.getElementById("aImgSqr535").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr535").src = "img/sqrs/wSqr.png"
};
};

function RsqrV11b() {
    if(document.getElementById("aImgSqr536").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr536").src = "img/sqrs/wSqr.png"
};
};

function RsqrV12b() {
    if(document.getElementById("aImgSqr537").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr537").src = "img/sqrs/wSqr.png"
};
};

function RsqrV13b() {
    if(document.getElementById("aImgSqr538").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr538").src = "img/sqrs/wSqr.png"
};
};

function RsqrV14b() {
    if(document.getElementById("aImgSqr539").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr539").src = "img/sqrs/wSqr.png"
};
};

function RsqrV15b() {
    if(document.getElementById("aImgSqr540").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr540").src = "img/sqrs/wSqr.png"
};
};

function RsqrV16b() {
    if(document.getElementById("aImgSqr541").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr541").src = "img/sqrs/wSqr.png"
};
};

function RsqrV17b() {
    if(document.getElementById("aImgSqr542").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr542").src = "img/sqrs/wSqr.png"
};
};

function RsqrV18b() {
    if(document.getElementById("aImgSqr543").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr543").src = "img/sqrs/wSqr.png"
};
};

function RsqrV19b() {
    if(document.getElementById("aImgSqr544").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr544").src = "img/sqrs/wSqr.png"
};
};

function RsqrV20b() {
    if(document.getElementById("aImgSqr545").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr545").src = "img/sqrs/wSqr.png"
};
};

function RsqrV21b() {
    if(document.getElementById("aImgSqr546").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr546").src = "img/sqrs/wSqr.png"
};
};

function RsqrV22b() {
    if(document.getElementById("aImgSqr547").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr547").src = "img/sqrs/wSqr.png"
};
};

function RsqrV23b() {
    if(document.getElementById("aImgSqr548").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr548").src = "img/sqrs/wSqr.png"
};
};

function RsqrV24b() {
    if(document.getElementById("aImgSqr549").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr549").src = "img/sqrs/wSqr.png"
};
};

function RsqrV25b() {
    if(document.getElementById("aImgSqr550").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr550").src = "img/sqrs/wSqr.png"
 };
};

function RsqrW1b() {
    if(document.getElementById("aImgSqr551").src = "img/sqrs/blSqr.png") {
         document.getElementById("aImgSqr551").src = "img/sqrs/wSqr.png"
};
};

function RsqrW2b() {
    if(document.getElementById("aImgSqr552").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr552").src = "img/sqrs/wSqr.png"
};
};

function RsqrW3b() {
    if(document.getElementById("aImgSqr553").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr553").src = "img/sqrs/wSqr.png"
};
};

function RsqrW4b() {
    if(document.getElementById("aImgSqr554").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr554").src = "img/sqrs/wSqr.png"
};
};

function RsqrW5b() {
    if(document.getElementById("aImgSqr555").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr555").src = "img/sqrs/wSqr.png"
};
};

function RsqrW6b() {
    if(document.getElementById("aImgSqr556").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr556").src = "img/sqrs/wSqr.png"
};
};

function RsqrW7b() {
    if(document.getElementById("aImgSqr557").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr557").src = "img/sqrs/wSqr.png"
};
};

function RsqrW8b() {
    if(document.getElementById("aImgSqr558").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr558").src = "img/sqrs/wSqr.png"
};
};

function RsqrW9b() {
    if(document.getElementById("aImgSqr559").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr559").src = "img/sqrs/wSqr.png"
};
};

function RsqrW10b() {
    if(document.getElementById("aImgSqr560").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr560").src = "img/sqrs/wSqr.png"
};
};

function RsqrW11b() {
    if(document.getElementById("aImgSqr561").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr561").src = "img/sqrs/wSqr.png"
};
};

function RsqrW12b() {
    if(document.getElementById("aImgSqr562").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr562").src = "img/sqrs/wSqr.png"
};
};

function RsqrW13b() {
    if(document.getElementById("aImgSqr563").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr563").src = "img/sqrs/wSqr.png"
};
};

function RsqrW14b() {
    if(document.getElementById("aImgSqr564").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr564").src = "img/sqrs/wSqr.png"
};
};

function RsqrW15b() {
    if(document.getElementById("aImgSqr565").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr565").src = "img/sqrs/wSqr.png"
};
};

function RsqrW16b() {
    if(document.getElementById("aImgSqr566").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr566").src = "img/sqrs/wSqr.png"
};
};

function RsqrW17b() {
    if(document.getElementById("aImgSqr567").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr567").src = "img/sqrs/wSqr.png"
};
};

function RsqrW18b() {
    if(document.getElementById("aImgSqr568").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr568").src = "img/sqrs/wSqr.png"
};
};

function RsqrW19b() {
    if(document.getElementById("aImgSqr569").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr569").src = "img/sqrs/wSqr.png"
};
};

function RsqrW20b() {
    if(document.getElementById("aImgSqr570").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr570").src = "img/sqrs/wSqr.png"
};
};

function RsqrW21b() {
    if(document.getElementById("aImgSqr571").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr571").src = "img/sqrs/wSqr.png"
};
};

function RsqrW22b() {
    if(document.getElementById("aImgSqr572").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr572").src = "img/sqrs/wSqr.png"
};
};

function RsqrW23b() {
    if(document.getElementById("aImgSqr573").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr573").src = "img/sqrs/wSqr.png"
};
};

function RsqrW24b() {
    if(document.getElementById("aImgSqr574").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr574").src = "img/sqrs/wSqr.png"
};
};

function RsqrW25b() {
    if(document.getElementById("aImgSqr575").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr575").src = "img/sqrs/wSqr.png"
 };
};

function RsqrX1b() {
    if(document.getElementById("aImgSqr576").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr576").src = "img/sqrs/wSqr.png"
};
};

function RsqrX2b() {
    if(document.getElementById("aImgSqr577").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr577").src = "img/sqrs/wSqr.png"
};
};

function RsqrX3b() {
    if(document.getElementById("aImgSqr578").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr578").src = "img/sqrs/wSqr.png"
};
};

function RsqrX4b() {
    if(document.getElementById("aImgSqr579").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr579").src = "img/sqrs/wSqr.png"
};
};

function RsqrX5b() {
    if(document.getElementById("aImgSqr580").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr580").src = "img/sqrs/wSqr.png"
};
};

function RsqrX6b() {
    if(document.getElementById("aImgSqr581").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr581").src = "img/sqrs/wSqr.png"
};
};

function RsqrX7b() {
    if(document.getElementById("aImgSqr582").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr582").src = "img/sqrs/wSqr.png"
};
};

function RsqrX8b() {
    if(document.getElementById("aImgSqr583").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr583").src = "img/sqrs/wSqr.png"
};
};

function RsqrX9b() {
    if(document.getElementById("aImgSqr584").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr584").src = "img/sqrs/wSqr.png"
};
};

function RsqrX10b() {
    if(document.getElementById("aImgSqr585").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr585").src = "img/sqrs/wSqr.png"
};
};

function RsqrX11b() {
    if(document.getElementById("aImgSqr586").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr586").src = "img/sqrs/wSqr.png"
};
};

function RsqrX12b() {
    if(document.getElementById("aImgSqr587").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr587").src = "img/sqrs/wSqr.png"
};
};

function RsqrX13b() {
    if(document.getElementById("aImgSqr588").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr588").src = "img/sqrs/wSqr.png"
};
};

function RsqrX14b() {
    if(document.getElementById("aImgSqr589").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr589").src = "img/sqrs/wSqr.png"
};
};

function RsqrX15b() {
    if(document.getElementById("aImgSqr590").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr590").src = "img/sqrs/wSqr.png"
};
};

function RsqrX16b() {
    if(document.getElementById("aImgSqr591").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr591").src = "img/sqrs/wSqr.png"
};
};

function RsqrX17b() {
    if(document.getElementById("aImgSqr592").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr592").src = "img/sqrs/wSqr.png"
};
};

function RsqrX18b() {
    if(document.getElementById("aImgSqr593").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr593").src = "img/sqrs/wSqr.png"
};
};

function RsqrX19b() {
    if(document.getElementById("aImgSqr594").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr594").src = "img/sqrs/wSqr.png"
};
};

function RsqrX20b() {
    if(document.getElementById("aImgSqr595").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr595").src = "img/sqrs/wSqr.png"
};
};

function RsqrX21b() {
    if(document.getElementById("aImgSqr596").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr596").src = "img/sqrs/wSqr.png"
};
};

function RsqrX22b() {
    if(document.getElementById("aImgSqr597").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr597").src = "img/sqrs/wSqr.png"
};
};

function RsqrX23b() {
    if(document.getElementById("aImgSqr598").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr598").src = "img/sqrs/wSqr.png"
};
};

function RsqrX24b() {
    if(document.getElementById("aImgSqr599").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr599").src = "img/sqrs/wSqr.png"
};
};

function RsqrX25b() {
    if(document.getElementById("aImgSqr600").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr600").src = "img/sqrs/wSqr.png"
 };
};

function RsqrY1b() {
    if(document.getElementById("aImgSqr601").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr601").src = "img/sqrs/wSqr.png"
};
};

function RsqrY2b() {
    if(document.getElementById("aImgSqr602").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr602").src = "img/sqrs/wSqr.png"
};
};

function RsqrY3b() {
    if(document.getElementById("aImgSqr603").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr603").src = "img/sqrs/wSqr.png"
};
};

function RsqrY4b() {
    if(document.getElementById("aImgSqr604").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr604").src = "img/sqrs/wSqr.png"
};
};

function RsqrY5b() {
    if(document.getElementById("aImgSqr605").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr605").src = "img/sqrs/wSqr.png"
};
};

function RsqrY6b() {
    if(document.getElementById("aImgSqr606").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr606").src = "img/sqrs/wSqr.png"
};
};

function RsqrY7b() {
    if(document.getElementById("aImgSqr607").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr607").src = "img/sqrs/wSqr.png"
};
};

function RsqrY8b() {
    if(document.getElementById("aImgSqr608").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr608").src = "img/sqrs/wSqr.png"
};
};

function RsqrY9b() {
    if(document.getElementById("aImgSqr609").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr609").src = "img/sqrs/wSqr.png"
};
};

function RsqrY10b() {
    if(document.getElementById("aImgSqr610").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr610").src = "img/sqrs/wSqr.png"
};
};

function RsqrY11b() {
    if(document.getElementById("aImgSqr611").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr611").src = "img/sqrs/wSqr.png"
};
};

function RsqrY12b() {
    if(document.getElementById("aImgSqr612").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr612").src = "img/sqrs/wSqr.png"
};
};

function RsqrY13b() {
    if(document.getElementById("aImgSqr613").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr613").src = "img/sqrs/wSqr.png"
};
};

function RsqrY14b() {
    if(document.getElementById("aImgSqr614").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr614").src = "img/sqrs/wSqr.png"
};
};

function RsqrY15b() {
    if(document.getElementById("aImgSqr615").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr615").src = "img/sqrs/wSqr.png"
};
};

function RsqrY16b() {
    if(document.getElementById("aImgSqr616").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr616").src = "img/sqrs/wSqr.png"
};
};

function RsqrY17b() {
    if(document.getElementById("aImgSqr617").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr617").src = "img/sqrs/wSqr.png"
};
};

function RsqrY18b() {
    if(document.getElementById("aImgSqr618").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr618").src = "img/sqrs/wSqr.png"
};
};

function RsqrY19b() {
    if(document.getElementById("aImgSqr619").src = "img/sqrs/blSqr.png") {
     document.getElementById("aImgSqr619").src = "img/sqrs/wSqr.png"
};
};

function RsqrY20b() {
    if(document.getElementById("aImgSqr620").src = "img/sqrs/blSqr.png") {
    document.getElementById("aImgSqr620").src = "img/sqrs/wSqr.png"
};
};

function RsqrY21b() {
    if(document.getElementById("aImgSqr621").src = "img/sqrs/blSqr.png") {
    document.getElementById("aImgSqr621").src = "img/sqrs/wSqr.png"
};
};

function RsqrY22b() {
    if(document.getElementById("aImgSqr622").src = "img/sqrs/blSqr.png") {
    document.getElementById("aImgSqr622").src = "img/sqrs/wSqr.png"
};
};

function RsqrY23b() {
    if(document.getElementById("aImgSqr623").src = "img/sqrs/blSqr.png") {
    document.getElementById("aImgSqr623").src = "img/sqrs/wSqr.png"
};
};

function RsqrY24b() {
    if(document.getElementById("aImgSqr624").src = "img/sqrs/blSqr.png") {
    document.getElementById("aImgSqr624").src = "img/sqrs/wSqr.png"
};
};

function RsqrY25b() {
    if(document.getElementById("aImgSqr625").src = "img/sqrs/blSqr.png") {
    document.getElementById("aImgSqr625").src = "img/sqrs/wSqr.png"
};
};