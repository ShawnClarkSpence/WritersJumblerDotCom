function RasqrA1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr1").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr1").src = "img/sqrs/blSqr.png"
};};};
function RasqrA2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr2").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr2").src = "img/sqrs/blSqr.png"
};};};
function RasqrA3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr3").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr3").src = "img/sqrs/blSqr.png"
};};};
function RasqrA4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr4").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr4").src = "img/sqrs/blSqr.png"
};};};
function RasqrA5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr5").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr5").src = "img/sqrs/blSqr.png"
};};};
function RasqrA6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr6").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr6").src = "img/sqrs/blSqr.png"
};};};
function RasqrA7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr7").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr7").src = "img/sqrs/blSqr.png"
};};};
function RasqrA8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr8").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr8").src = "img/sqrs/blSqr.png"
};};};
function RasqrA9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr9").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr9").src = "img/sqrs/blSqr.png"
};};};
function RasqrA10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr10").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr10").src = "img/sqrs/blSqr.png"
};};};
function RasqrA11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr11").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr11").src = "img/sqrs/blSqr.png"
};};};
function RasqrA12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr12").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr12").src = "img/sqrs/blSqr.png"
};};};
function RasqrA13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr13").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr13").src = "img/sqrs/blSqr.png"
};};};
function RasqrA14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr14").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr14").src = "img/sqrs/blSqr.png"
};};};
function RasqrA15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr15").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr15").src = "img/sqrs/blSqr.png"
};};};
function RasqrA16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr16").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr16").src = "img/sqrs/blSqr.png"
};};};
function RasqrA17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr17").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr17").src = "img/sqrs/blSqr.png"
};};};
function RasqrA18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr18").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr18").src = "img/sqrs/blSqr.png"
};};};
function RasqrA19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr19").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr19").src = "img/sqrs/blSqr.png"
};};};
function RasqrA20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr20").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr20").src = "img/sqrs/blSqr.png"
};};};
function RasqrA21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr21").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr21").src = "img/sqrs/blSqr.png"
};};};
function RasqrA22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr22").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr22").src = "img/sqrs/blSqr.png"
};};};
function RasqrA23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr23").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr23").src = "img/sqrs/blSqr.png"
};};};
function RasqrA24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr24").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr24").src = "img/sqrs/blSqr.png"
};};};
function RasqrA25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr25").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr25").src = "img/sqrs/blSqr.png"
};};};
function RasqrB1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr26").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr26").src = "img/sqrs/blSqr.png"
};};};
function RasqrB2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr27").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr27").src = "img/sqrs/blSqr.png"
};};};
function RasqrB3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr28").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr28").src = "img/sqrs/blSqr.png"
};};};
function RasqrB4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr29").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr29").src = "img/sqrs/blSqr.png"
};};};
function RasqrB5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr30").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr30").src = "img/sqrs/blSqr.png"
};};};
function RasqrB6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr31").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr31").src = "img/sqrs/blSqr.png"
};};};
function RasqrB7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr32").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr32").src = "img/sqrs/blSqr.png"
};};};
function RasqrB8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr33").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr33").src = "img/sqrs/blSqr.png"
};};};
function RasqrB9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr34").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr34").src = "img/sqrs/blSqr.png"
};};};
function RasqrB10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr35").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr35").src = "img/sqrs/blSqr.png"
};};};
function RasqrB11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr36").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr36").src = "img/sqrs/blSqr.png"
};};};
function RasqrB12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr37").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr37").src = "img/sqrs/blSqr.png"
};};};
function RasqrB13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr38").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr38").src = "img/sqrs/blSqr.png"
};};};
function RasqrB14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr39").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr39").src = "img/sqrs/blSqr.png"
};};};
function RasqrB15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr40").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr40").src = "img/sqrs/blSqr.png"
};};};
function RasqrB16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr41").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr41").src = "img/sqrs/blSqr.png"
};};};
function RasqrB17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr42").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr42").src = "img/sqrs/blSqr.png"
};};};
function RasqrB18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr43").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr43").src = "img/sqrs/blSqr.png"
};};};
function RasqrB19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr44").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr44").src = "img/sqrs/blSqr.png"
};};};
function RasqrB20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr45").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr45").src = "img/sqrs/blSqr.png"
};};};
function RasqrB21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr46").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr46").src = "img/sqrs/blSqr.png"
};};};
function RasqrB22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr47").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr47").src = "img/sqrs/blSqr.png"
};};};
function RasqrB23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr48").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr48").src = "img/sqrs/blSqr.png"
};};};
function RasqrB24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr49").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr49").src = "img/sqrs/blSqr.png"
};};};
function RasqrB25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr50").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr50").src = "img/sqrs/blSqr.png"
};};};
function RasqrC1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr51").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr51").src = "img/sqrs/blSqr.png"
};};};
function RasqrC2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr52").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr52").src = "img/sqrs/blSqr.png"
};};};
function RasqrC3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr53").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr53").src = "img/sqrs/blSqr.png"
};};};
function RasqrC4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr54").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr54").src = "img/sqrs/blSqr.png"
};};};
function RasqrC5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr55").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr55").src = "img/sqrs/blSqr.png"
};};};
function RasqrC6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr56").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr56").src = "img/sqrs/blSqr.png"
};};};
function RasqrC7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr57").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr57").src = "img/sqrs/blSqr.png"
};};};
function RasqrC8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr58").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr58").src = "img/sqrs/blSqr.png"
};};};
function RasqrC9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr59").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr59").src = "img/sqrs/blSqr.png"
};};};
function RasqrC10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr60").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr60").src = "img/sqrs/blSqr.png"
};};};
function RasqrC11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr61").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr61").src = "img/sqrs/blSqr.png"
};};};
function RasqrC12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr62").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr62").src = "img/sqrs/blSqr.png"
};};};
function RasqrC13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr63").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr63").src = "img/sqrs/blSqr.png"
};};};
function RasqrC14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr64").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr64").src = "img/sqrs/blSqr.png"
};};};
function RasqrC15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr65").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr65").src = "img/sqrs/blSqr.png"
};};};
function RasqrC16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr66").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr66").src = "img/sqrs/blSqr.png"
};};};
function RasqrC17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr67").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr67").src = "img/sqrs/blSqr.png"
};};};
function RasqrC18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr68").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr68").src = "img/sqrs/blSqr.png"
};};};
function RasqrC19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr69").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr69").src = "img/sqrs/blSqr.png"
};};};
function RasqrC20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr70").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr70").src = "img/sqrs/blSqr.png"
};};};
function RasqrC21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr71").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr71").src = "img/sqrs/blSqr.png"
};};};
function RasqrC22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr72").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr72").src = "img/sqrs/blSqr.png"
};};};
function RasqrC23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr73").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr73").src = "img/sqrs/blSqr.png"
};};};
function RasqrC24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr74").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr74").src = "img/sqrs/blSqr.png"
};};};
function RasqrC25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr75").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr75").src = "img/sqrs/blSqr.png"
};};};
function RasqrD1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr76").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr76").src = "img/sqrs/blSqr.png"
};};};
function RasqrD2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr77").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr77").src = "img/sqrs/blSqr.png"
};};};
function RasqrD3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr78").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr78").src = "img/sqrs/blSqr.png"
};};};
function RasqrD4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr79").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr79").src = "img/sqrs/blSqr.png"
};};};
function RasqrD5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr80").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr80").src = "img/sqrs/blSqr.png"
};};};
function RasqrD6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr81").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr81").src = "img/sqrs/blSqr.png"
};};};
function RasqrD7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr82").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr82").src = "img/sqrs/blSqr.png"
};};};
function RasqrD8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr83").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr83").src = "img/sqrs/blSqr.png"
};};};
function RasqrD9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr84").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr84").src = "img/sqrs/blSqr.png"
};};};
function RasqrD10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr85").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr85").src = "img/sqrs/blSqr.png"
};};};
function RasqrD11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr86").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr86").src = "img/sqrs/blSqr.png"
};};};
function RasqrD12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr87").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr87").src = "img/sqrs/blSqr.png"
};};};
function RasqrD13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr88").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr88").src = "img/sqrs/blSqr.png"
};};};
function RasqrD14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr89").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr89").src = "img/sqrs/blSqr.png"
};};};
function RasqrD15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr90").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr90").src = "img/sqrs/blSqr.png"
};};};
function RasqrD16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr91").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr91").src = "img/sqrs/blSqr.png"
};};};
function RasqrD17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr92").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr92").src = "img/sqrs/blSqr.png"
};};};
function RasqrD18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr93").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr93").src = "img/sqrs/blSqr.png"
};};};
function RasqrD19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr94").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr94").src = "img/sqrs/blSqr.png"
};};};
function RasqrD20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr95").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr95").src = "img/sqrs/blSqr.png"
};};};
function RasqrD21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr96").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr96").src = "img/sqrs/blSqr.png"
};};};
function RasqrD22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr97").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr97").src = "img/sqrs/blSqr.png"
};};};
function RasqrD23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr98").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr98").src = "img/sqrs/blSqr.png"
};};};
function RasqrD24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr99").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr99").src = "img/sqrs/blSqr.png"
};};};
function RasqrD25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr100").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr100").src = "img/sqrs/blSqr.png"
};};};
function RasqrE1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr101").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr101").src = "img/sqrs/blSqr.png"
};};};
function RasqrE2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr102").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr102").src = "img/sqrs/blSqr.png"
};};};
function RasqrE3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr103").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr103").src = "img/sqrs/blSqr.png"
};};};
function RasqrE4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr104").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr104").src = "img/sqrs/blSqr.png"
};};};
function RasqrE5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr105").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr105").src = "img/sqrs/blSqr.png"
};};};
function RasqrE6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr106").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr106").src = "img/sqrs/blSqr.png"
};};};
function RasqrE7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr107").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr107").src = "img/sqrs/blSqr.png"
};};};
function RasqrE8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr108").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr108").src = "img/sqrs/blSqr.png"
};};};
function RasqrE9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr109").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr109").src = "img/sqrs/blSqr.png"
};};};
function RasqrE10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr110").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr110").src = "img/sqrs/blSqr.png"
};};};
function RasqrE11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr111").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr111").src = "img/sqrs/blSqr.png"
};};};
function RasqrE12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr112").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr112").src = "img/sqrs/blSqr.png"
};};};
function RasqrE13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr113").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr113").src = "img/sqrs/blSqr.png"
};};};
function RasqrE14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr114").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr114").src = "img/sqrs/blSqr.png"
};};};
function RasqrE15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr115").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr115").src = "img/sqrs/blSqr.png"
};};};
function RasqrE16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr116").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr116").src = "img/sqrs/blSqr.png"
};};};
function RasqrE17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr117").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr117").src = "img/sqrs/blSqr.png"
};};};
function RasqrE18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr118").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr118").src = "img/sqrs/blSqr.png"
};};};
function RasqrE19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr119").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr119").src = "img/sqrs/blSqr.png"
};};};
function RasqrE20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr120").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr120").src = "img/sqrs/blSqr.png"
};};};
function RasqrE21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr121").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr121").src = "img/sqrs/blSqr.png"
};};};
function RasqrE22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr122").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr122").src = "img/sqrs/blSqr.png"
};};};
function RasqrE23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr123").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr123").src = "img/sqrs/blSqr.png"
};};};
function RasqrE24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr124").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr124").src = "img/sqrs/blSqr.png"
};};};
function RasqrE25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr125").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr125").src = "img/sqrs/blSqr.png"
};};};
function RasqrF1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr126").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr126").src = "img/sqrs/blSqr.png"
};};};
function RasqrF2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr127").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr127").src = "img/sqrs/blSqr.png"
};};};
function RasqrF3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr128").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr128").src = "img/sqrs/blSqr.png"
};};};
function RasqrF4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr129").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr129").src = "img/sqrs/blSqr.png"
};};};
function RasqrF5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr130").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr130").src = "img/sqrs/blSqr.png"
};};};
function RasqrF6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr131").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr131").src = "img/sqrs/blSqr.png"
};};};
function RasqrF7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr132").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr132").src = "img/sqrs/blSqr.png"
};};};
function RasqrF8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr133").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr133").src = "img/sqrs/blSqr.png"
};};};
function RasqrF9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr134").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr134").src = "img/sqrs/blSqr.png"
};};};
function RasqrF10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr135").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr135").src = "img/sqrs/blSqr.png"
};};};
function RasqrF11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr136").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr136").src = "img/sqrs/blSqr.png"
};};};
function RasqrF12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr137").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr137").src = "img/sqrs/blSqr.png"
};};};
function RasqrF13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr138").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr138").src = "img/sqrs/blSqr.png"
};};};
function RasqrF14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr139").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr139").src = "img/sqrs/blSqr.png"
};};};
function RasqrF15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr140").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr140").src = "img/sqrs/blSqr.png"
};};};
function RasqrF16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr141").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr141").src = "img/sqrs/blSqr.png"
};};};
function RasqrF17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr142").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr142").src = "img/sqrs/blSqr.png"
};};};
function RasqrF18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr143").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr143").src = "img/sqrs/blSqr.png"
};};};
function RasqrF19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr144").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr144").src = "img/sqrs/blSqr.png"
};};};
function RasqrF20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr145").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr145").src = "img/sqrs/blSqr.png"
};};};
function RasqrF21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr146").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr146").src = "img/sqrs/blSqr.png"
};};};
function RasqrF22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr147").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr147").src = "img/sqrs/blSqr.png"
};};};
function RasqrF23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr148").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr148").src = "img/sqrs/blSqr.png"
};};};
function RasqrF24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr149").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr149").src = "img/sqrs/blSqr.png"
};};};
function RasqrF25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr150").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr150").src = "img/sqrs/blSqr.png"
};};};
function RasqrG1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr151").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr151").src = "img/sqrs/blSqr.png"
};};};
function RasqrG2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr152").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr152").src = "img/sqrs/blSqr.png"
};};};
function RasqrG3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr153").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr153").src = "img/sqrs/blSqr.png"
};};};
function RasqrG4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr154").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr154").src = "img/sqrs/blSqr.png"
};};};
function RasqrG5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr155").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr155").src = "img/sqrs/blSqr.png"
};};};
function RasqrG6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr156").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr156").src = "img/sqrs/blSqr.png"
};};};
function RasqrG7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr157").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr157").src = "img/sqrs/blSqr.png"
};};};
function RasqrG8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr158").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr158").src = "img/sqrs/blSqr.png"
};};};
function RasqrG9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr159").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr159").src = "img/sqrs/blSqr.png"
};};};
function RasqrG10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr160").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr160").src = "img/sqrs/blSqr.png"
};};};
function RasqrG11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr161").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr161").src = "img/sqrs/blSqr.png"
};};};
function RasqrG12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr162").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr162").src = "img/sqrs/blSqr.png"
};};};
function RasqrG13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr163").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr163").src = "img/sqrs/blSqr.png"
};};};
function RasqrG14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr164").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr164").src = "img/sqrs/blSqr.png"
};};};
function RasqrG15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr165").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr165").src = "img/sqrs/blSqr.png"
};};};
function RasqrG16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr166").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr166").src = "img/sqrs/blSqr.png"
};};};
function RasqrG17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr167").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr167").src = "img/sqrs/blSqr.png"
};};};
function RasqrG18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr168").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr168").src = "img/sqrs/blSqr.png"
};};};
function RasqrG19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr169").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr169").src = "img/sqrs/blSqr.png"
};};};
function RasqrG20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr170").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr170").src = "img/sqrs/blSqr.png"
};};};
function RasqrG21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr171").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr171").src = "img/sqrs/blSqr.png"
};};};
function RasqrG22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr172").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr172").src = "img/sqrs/blSqr.png"
};};};
function RasqrG23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr173").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr173").src = "img/sqrs/blSqr.png"
};};};
function RasqrG24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr174").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr174").src = "img/sqrs/blSqr.png"
};};};
function RasqrG25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr175").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr175").src = "img/sqrs/blSqr.png"
};};};
function RasqrH1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr176").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr176").src = "img/sqrs/blSqr.png"
};};};
function RasqrH2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr177").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr177").src = "img/sqrs/blSqr.png"
};};};
function RasqrH3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr178").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr178").src = "img/sqrs/blSqr.png"
};};};
function RasqrH4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr179").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr179").src = "img/sqrs/blSqr.png"
};};};
function RasqrH5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr180").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr180").src = "img/sqrs/blSqr.png"
};};};
function RasqrH6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr181").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr181").src = "img/sqrs/blSqr.png"
};};};
function RasqrH7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr182").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr182").src = "img/sqrs/blSqr.png"
};};};
function RasqrH8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr183").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr183").src = "img/sqrs/blSqr.png"
};};};
function RasqrH9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr184").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr184").src = "img/sqrs/blSqr.png"
};};};
function RasqrH10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr185").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr185").src = "img/sqrs/blSqr.png"
};};};
function RasqrH11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr186").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr186").src = "img/sqrs/blSqr.png"
};};};
function RasqrH12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr187").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr187").src = "img/sqrs/blSqr.png"
};};};
function RasqrH13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr188").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr188").src = "img/sqrs/blSqr.png"
};};};
function RasqrH14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr189").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr189").src = "img/sqrs/blSqr.png"
};};};
function RasqrH15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr190").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr190").src = "img/sqrs/blSqr.png"
};};};
function RasqrH16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr191").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr191").src = "img/sqrs/blSqr.png"
};};};
function RasqrH17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr192").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr192").src = "img/sqrs/blSqr.png"
};};};
function RasqrH18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr193").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr193").src = "img/sqrs/blSqr.png"
};};};
function RasqrH19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr194").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr194").src = "img/sqrs/blSqr.png"
};};};
function RasqrH20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr195").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr195").src = "img/sqrs/blSqr.png"
};};};
function RasqrH21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr196").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr196").src = "img/sqrs/blSqr.png"
};};};
function RasqrH22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr197").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr197").src = "img/sqrs/blSqr.png"
};};};
function RasqrH23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr198").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr198").src = "img/sqrs/blSqr.png"
};};};
function RasqrH24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr199").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr199").src = "img/sqrs/blSqr.png"
};};};
function RasqrH25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr200").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr200").src = "img/sqrs/blSqr.png"
};};};
function RasqrI1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr201").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr201").src = "img/sqrs/blSqr.png"
};};};
function RasqrI2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr202").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr202").src = "img/sqrs/blSqr.png"
};};};
function RasqrI3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr203").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr203").src = "img/sqrs/blSqr.png"
};};};
function RasqrI4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr204").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr204").src = "img/sqrs/blSqr.png"
};};};
function RasqrI5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr205").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr205").src = "img/sqrs/blSqr.png"
};};};
function RasqrI6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr206").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr206").src = "img/sqrs/blSqr.png"
};};};
function RasqrI7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr207").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr207").src = "img/sqrs/blSqr.png"
};};};
function RasqrI8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr208").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr208").src = "img/sqrs/blSqr.png"
};};};
function RasqrI9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr209").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr209").src = "img/sqrs/blSqr.png"
};};};
function RasqrI10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr210").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr210").src = "img/sqrs/blSqr.png"
};};};
function RasqrI11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr211").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr211").src = "img/sqrs/blSqr.png"
};};};
function RasqrI12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr212").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr212").src = "img/sqrs/blSqr.png"
};};};
function RasqrI13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr213").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr213").src = "img/sqrs/blSqr.png"
};};};
function RasqrI14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr214").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr214").src = "img/sqrs/blSqr.png"
};};};
function RasqrI15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr215").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr215").src = "img/sqrs/blSqr.png"
};};};
function RasqrI16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr216").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr216").src = "img/sqrs/blSqr.png"
};};};
function RasqrI17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr217").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr217").src = "img/sqrs/blSqr.png"
};};};
function RasqrI18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr218").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr218").src = "img/sqrs/blSqr.png"
};};};
function RasqrI19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr219").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr219").src = "img/sqrs/blSqr.png"
};};};
function RasqrI20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr220").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr220").src = "img/sqrs/blSqr.png"
};};};
function RasqrI21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr221").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr221").src = "img/sqrs/blSqr.png"
};};};
function RasqrI22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr222").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr222").src = "img/sqrs/blSqr.png"
};};};
function RasqrI23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr223").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr223").src = "img/sqrs/blSqr.png"
};};};
function RasqrI24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr224").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr224").src = "img/sqrs/blSqr.png"
};};};
function RasqrI25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr225").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr225").src = "img/sqrs/blSqr.png"
};};};
function RasqrJ1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr226").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr226").src = "img/sqrs/blSqr.png"
};};};
function RasqrJ2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr227").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr227").src = "img/sqrs/blSqr.png"
};};};
function RasqrJ3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr228").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr228").src = "img/sqrs/blSqr.png"
};};};
function RasqrJ4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr229").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr229").src = "img/sqrs/blSqr.png"
};};};
function RasqrJ5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr230").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr230").src = "img/sqrs/blSqr.png"
};};};
function RasqrJ6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr231").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr231").src = "img/sqrs/blSqr.png"
};};};
function RasqrJ7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr232").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr232").src = "img/sqrs/blSqr.png"
};};};
function RasqrJ8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr233").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr233").src = "img/sqrs/blSqr.png"
};};};
function RasqrJ9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr234").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr234").src = "img/sqrs/blSqr.png"
};};};
function RasqrJ10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr235").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr235").src = "img/sqrs/blSqr.png"
};};};
function RasqrJ11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr236").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr236").src = "img/sqrs/blSqr.png"
};};};
function RasqrJ12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr237").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr237").src = "img/sqrs/blSqr.png"
};};};
function RasqrJ13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr238").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr238").src = "img/sqrs/blSqr.png"
};};};
function RasqrJ14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr239").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr239").src = "img/sqrs/blSqr.png"
};};};
function RasqrJ15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr240").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr240").src = "img/sqrs/blSqr.png"
};};};
function RasqrJ16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr241").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr241").src = "img/sqrs/blSqr.png"
};};};
function RasqrJ17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr242").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr242").src = "img/sqrs/blSqr.png"
};};};
function RasqrJ18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr243").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr243").src = "img/sqrs/blSqr.png"
};};};
function RasqrJ19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr244").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr244").src = "img/sqrs/blSqr.png"
};};};
function RasqrJ20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr245").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr245").src = "img/sqrs/blSqr.png"
};};};
function RasqrJ21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr246").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr246").src = "img/sqrs/blSqr.png"
};};};
function RasqrJ22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr247").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr247").src = "img/sqrs/blSqr.png"
};};};
function RasqrJ23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr248").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr248").src = "img/sqrs/blSqr.png"
};};};
function RasqrJ24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr249").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr249").src = "img/sqrs/blSqr.png"
};};};
function RasqrJ25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr250").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr250").src = "img/sqrs/blSqr.png"
};};};
function RasqrK1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr251").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr251").src = "img/sqrs/blSqr.png"
};};};
function RasqrK2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr252").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr252").src = "img/sqrs/blSqr.png"
};};};
function RasqrK3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr253").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr253").src = "img/sqrs/blSqr.png"
};};};
function RasqrK4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr254").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr254").src = "img/sqrs/blSqr.png"
};};};
function RasqrK5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr255").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr255").src = "img/sqrs/blSqr.png"
};};};
function RasqrK6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr256").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr256").src = "img/sqrs/blSqr.png"
};};};
function RasqrK7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr257").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr257").src = "img/sqrs/blSqr.png"
};};};
function RasqrK8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr258").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr258").src = "img/sqrs/blSqr.png"
};};};
function RasqrK9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr259").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr259").src = "img/sqrs/blSqr.png"
};};};
function RasqrK10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr260").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr260").src = "img/sqrs/blSqr.png"
};};};
function RasqrK11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr261").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr261").src = "img/sqrs/blSqr.png"
};};};
function RasqrK12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr262").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr262").src = "img/sqrs/blSqr.png"
};};};
function RasqrK13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr263").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr263").src = "img/sqrs/blSqr.png"
};};};
function RasqrK14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr264").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr264").src = "img/sqrs/blSqr.png"
};};};
function RasqrK15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr265").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr265").src = "img/sqrs/blSqr.png"
};};};
function RasqrK16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr266").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr266").src = "img/sqrs/blSqr.png"
};};};
function RasqrK17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr267").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr267").src = "img/sqrs/blSqr.png"
};};};
function RasqrK18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr268").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr268").src = "img/sqrs/blSqr.png"
};};};
function RasqrK19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr269").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr269").src = "img/sqrs/blSqr.png"
};};};
function RasqrK20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr270").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr270").src = "img/sqrs/blSqr.png"
};};};
function RasqrK21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr271").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr271").src = "img/sqrs/blSqr.png"
};};};
function RasqrK22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr272").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr272").src = "img/sqrs/blSqr.png"
};};};
function RasqrK23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr273").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr273").src = "img/sqrs/blSqr.png"
};};};
function RasqrK24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr274").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr274").src = "img/sqrs/blSqr.png"
};};};
function RasqrK25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr275").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr275").src = "img/sqrs/blSqr.png"
};};};
function RasqrL1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr276").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr276").src = "img/sqrs/blSqr.png"
};};};
function RasqrL2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr277").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr277").src = "img/sqrs/blSqr.png"
};};};
function RasqrL3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr278").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr278").src = "img/sqrs/blSqr.png"
};};};
function RasqrL4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr279").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr279").src = "img/sqrs/blSqr.png"
};};};
function RasqrL5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr280").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr280").src = "img/sqrs/blSqr.png"
};};};
function RasqrL6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr281").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr281").src = "img/sqrs/blSqr.png"
};};};
function RasqrL7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr282").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr282").src = "img/sqrs/blSqr.png"
};};};
function RasqrL8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr283").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr283").src = "img/sqrs/blSqr.png"
};};};
function RasqrL9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr284").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr284").src = "img/sqrs/blSqr.png"
};};};
function RasqrL10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr285").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr285").src = "img/sqrs/blSqr.png"
};};};
function RasqrL11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr286").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr286").src = "img/sqrs/blSqr.png"
};};};
function RasqrL12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr287").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr287").src = "img/sqrs/blSqr.png"
};};};
function RasqrL13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr288").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr288").src = "img/sqrs/blSqr.png"
};};};
function RasqrL14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr289").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr289").src = "img/sqrs/blSqr.png"
};};};
function RasqrL15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr290").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr290").src = "img/sqrs/blSqr.png"
};};};
function RasqrL16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr291").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr291").src = "img/sqrs/blSqr.png"
};};};
function RasqrL17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr292").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr292").src = "img/sqrs/blSqr.png"
};};};
function RasqrL18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr293").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr293").src = "img/sqrs/blSqr.png"
};};};
function RasqrL19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr294").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr294").src = "img/sqrs/blSqr.png"
};};};
function RasqrL20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr295").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr295").src = "img/sqrs/blSqr.png"
};};};
function RasqrL21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr296").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr296").src = "img/sqrs/blSqr.png"
};};};
function RasqrL22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr297").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr297").src = "img/sqrs/blSqr.png"
};};};
function RasqrL23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr298").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr298").src = "img/sqrs/blSqr.png"
};};};
function RasqrL24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr299").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr299").src = "img/sqrs/blSqr.png"
};};};
function RasqrL25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr300").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr300").src = "img/sqrs/blSqr.png"
};};};
function RasqrM1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr301").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr301").src = "img/sqrs/blSqr.png"
};};};
function RasqrM2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr302").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr302").src = "img/sqrs/blSqr.png"
};};};
function RasqrM3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr303").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr303").src = "img/sqrs/blSqr.png"
};};};
function RasqrM4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr304").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr304").src = "img/sqrs/blSqr.png"
};};};
function RasqrM5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr305").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr305").src = "img/sqrs/blSqr.png"
};};};
function RasqrM6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr306").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr306").src = "img/sqrs/blSqr.png"
};};};
function RasqrM7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr307").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr307").src = "img/sqrs/blSqr.png"
};};};
function RasqrM8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr308").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr308").src = "img/sqrs/blSqr.png"
};};};
function RasqrM9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr309").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr309").src = "img/sqrs/blSqr.png"
};};};
function RasqrM10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr310").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr310").src = "img/sqrs/blSqr.png"
};};};
function RasqrM11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr311").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr311").src = "img/sqrs/blSqr.png"
};};};
function RasqrM12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr312").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr312").src = "img/sqrs/blSqr.png"
};};};
function RasqrM13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr313").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr313").src = "img/sqrs/blSqr.png"
};};};
function RasqrM14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr314").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr314").src = "img/sqrs/blSqr.png"
};};};
function RasqrM15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr315").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr315").src = "img/sqrs/blSqr.png"
};};};
function RasqrM16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr316").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr316").src = "img/sqrs/blSqr.png"
};};};
function RasqrM17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr317").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr317").src = "img/sqrs/blSqr.png"
};};};
function RasqrM18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr318").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr318").src = "img/sqrs/blSqr.png"
};};};
function RasqrM19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr319").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr319").src = "img/sqrs/blSqr.png"
};};};
function RasqrM20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr320").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr320").src = "img/sqrs/blSqr.png"
};};};
function RasqrM21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr321").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr321").src = "img/sqrs/blSqr.png"
};};};
function RasqrM22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr322").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr322").src = "img/sqrs/blSqr.png"
};};};
function RasqrM23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr323").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr323").src = "img/sqrs/blSqr.png"
};};};
function RasqrM24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr324").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr324").src = "img/sqrs/blSqr.png"
};};};
function RasqrM25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr325").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr325").src = "img/sqrs/blSqr.png"
};};};
function RasqrN1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr326").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr326").src = "img/sqrs/blSqr.png"
};};};
function RasqrN2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr327").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr327").src = "img/sqrs/blSqr.png"
};};};
function RasqrN3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr328").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr328").src = "img/sqrs/blSqr.png"
};};};
function RasqrN4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr329").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr329").src = "img/sqrs/blSqr.png"
};};};
function RasqrN5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr330").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr330").src = "img/sqrs/blSqr.png"
};};};
function RasqrN6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr331").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr331").src = "img/sqrs/blSqr.png"
};};};
function RasqrN7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr332").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr332").src = "img/sqrs/blSqr.png"
};};};
function RasqrN8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr333").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr333").src = "img/sqrs/blSqr.png"
};};};
function RasqrN9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr334").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr334").src = "img/sqrs/blSqr.png"
};};};
function RasqrN10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr335").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr335").src = "img/sqrs/blSqr.png"
};};};
function RasqrN11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr336").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr336").src = "img/sqrs/blSqr.png"
};};};
function RasqrN12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr337").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr337").src = "img/sqrs/blSqr.png"
};};};
function RasqrN13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr338").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr338").src = "img/sqrs/blSqr.png"
};};};
function RasqrN14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr339").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr339").src = "img/sqrs/blSqr.png"
};};};
function RasqrN15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr340").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr340").src = "img/sqrs/blSqr.png"
};};};
function RasqrN16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr341").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr341").src = "img/sqrs/blSqr.png"
};};};
function RasqrN17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr342").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr342").src = "img/sqrs/blSqr.png"
};};};
function RasqrN18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr343").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr343").src = "img/sqrs/blSqr.png"
};};};
function RasqrN19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr344").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr344").src = "img/sqrs/blSqr.png"
};};};
function RasqrN20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr345").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr345").src = "img/sqrs/blSqr.png"
};};};
function RasqrN21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr346").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr346").src = "img/sqrs/blSqr.png"
};};};
function RasqrN22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr347").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr347").src = "img/sqrs/blSqr.png"
};};};
function RasqrN23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr348").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr348").src = "img/sqrs/blSqr.png"
};};};
function RasqrN24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr349").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr349").src = "img/sqrs/blSqr.png"
};};};
function RasqrN25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr350").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr350").src = "img/sqrs/blSqr.png"
};};};
function RasqrO1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr351").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr351").src = "img/sqrs/blSqr.png"
};};};
function RasqrO2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr352").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr352").src = "img/sqrs/blSqr.png"
};};};
function RasqrO3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr353").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr353").src = "img/sqrs/blSqr.png"
};};};
function RasqrO4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr354").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr354").src = "img/sqrs/blSqr.png"
};};};
function RasqrO5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr355").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr355").src = "img/sqrs/blSqr.png"
};};};
function RasqrO6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr356").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr356").src = "img/sqrs/blSqr.png"
};};};
function RasqrO7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr357").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr357").src = "img/sqrs/blSqr.png"
};};};
function RasqrO8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr358").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr358").src = "img/sqrs/blSqr.png"
};};};
function RasqrO9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr359").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr359").src = "img/sqrs/blSqr.png"
};};};
function RasqrO10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr360").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr360").src = "img/sqrs/blSqr.png"
};};};
function RasqrO11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr361").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr361").src = "img/sqrs/blSqr.png"
};};};
function RasqrO12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr362").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr362").src = "img/sqrs/blSqr.png"
};};};
function RasqrO13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr363").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr363").src = "img/sqrs/blSqr.png"
};};};
function RasqrO14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr364").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr364").src = "img/sqrs/blSqr.png"
};};};
function RasqrO15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr365").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr365").src = "img/sqrs/blSqr.png"
};};};
function RasqrO16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr366").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr366").src = "img/sqrs/blSqr.png"
};};};
function RasqrO17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr367").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr367").src = "img/sqrs/blSqr.png"
};};};
function RasqrO18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr368").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr368").src = "img/sqrs/blSqr.png"
};};};
function RasqrO19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr369").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr369").src = "img/sqrs/blSqr.png"
};};};
function RasqrO20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr370").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr370").src = "img/sqrs/blSqr.png"
};};};
function RasqrO21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr371").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr371").src = "img/sqrs/blSqr.png"
};};};
function RasqrO22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr372").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr372").src = "img/sqrs/blSqr.png"
};};};
function RasqrO23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr373").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr373").src = "img/sqrs/blSqr.png"
};};};
function RasqrO24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr374").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr374").src = "img/sqrs/blSqr.png"
};};};
function RasqrO25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr375").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr375").src = "img/sqrs/blSqr.png"
};};};
function RasqrP1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr376").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr376").src = "img/sqrs/blSqr.png"
};};};
function RasqrP2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr377").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr377").src = "img/sqrs/blSqr.png"
};};};
function RasqrP3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr378").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr378").src = "img/sqrs/blSqr.png"
};};};
function RasqrP4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr379").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr379").src = "img/sqrs/blSqr.png"
};};};
function RasqrP5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr380").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr380").src = "img/sqrs/blSqr.png"
};};};
function RasqrP6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr381").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr381").src = "img/sqrs/blSqr.png"
};};};
function RasqrP7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr382").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr382").src = "img/sqrs/blSqr.png"
};};};
function RasqrP8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr383").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr383").src = "img/sqrs/blSqr.png"
};};};
function RasqrP9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr384").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr384").src = "img/sqrs/blSqr.png"
};};};
function RasqrP10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr385").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr385").src = "img/sqrs/blSqr.png"
};};};
function RasqrP11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr386").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr386").src = "img/sqrs/blSqr.png"
};};};
function RasqrP12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr387").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr387").src = "img/sqrs/blSqr.png"
};};};
function RasqrP13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr388").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr388").src = "img/sqrs/blSqr.png"
};};};
function RasqrP14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr389").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr389").src = "img/sqrs/blSqr.png"
};};};
function RasqrP15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr390").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr390").src = "img/sqrs/blSqr.png"
};};};
function RasqrP16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr391").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr391").src = "img/sqrs/blSqr.png"
};};};
function RasqrP17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr392").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr392").src = "img/sqrs/blSqr.png"
};};};
function RasqrP18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr393").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr393").src = "img/sqrs/blSqr.png"
};};};
function RasqrP19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr394").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr394").src = "img/sqrs/blSqr.png"
};};};
function RasqrP20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr395").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr395").src = "img/sqrs/blSqr.png"
};};};
function RasqrP21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr396").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr396").src = "img/sqrs/blSqr.png"
};};};
function RasqrP22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr397").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr397").src = "img/sqrs/blSqr.png"
};};};
function RasqrP23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr398").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr398").src = "img/sqrs/blSqr.png"
};};};
function RasqrP24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr399").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr399").src = "img/sqrs/blSqr.png"
};};};
function RasqrP25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr400").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr400").src = "img/sqrs/blSqr.png"
};};};
function RasqrQ1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr401").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr401").src = "img/sqrs/blSqr.png"
};};};
function RasqrQ2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr402").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr402").src = "img/sqrs/blSqr.png"
};};};
function RasqrQ3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr403").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr403").src = "img/sqrs/blSqr.png"
};};};
function RasqrQ4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr404").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr404").src = "img/sqrs/blSqr.png"
};};};
function RasqrQ5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr405").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr405").src = "img/sqrs/blSqr.png"
};};};
function RasqrQ6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr406").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr406").src = "img/sqrs/blSqr.png"
};};};
function RasqrQ7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr407").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr407").src = "img/sqrs/blSqr.png"
};};};
function RasqrQ8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr408").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr408").src = "img/sqrs/blSqr.png"
};};};
function RasqrQ9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr409").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr409").src = "img/sqrs/blSqr.png"
};};};
function RasqrQ10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr410").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr410").src = "img/sqrs/blSqr.png"
};};};
function RasqrQ11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr411").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr411").src = "img/sqrs/blSqr.png"
};};};
function RasqrQ12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr412").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr412").src = "img/sqrs/blSqr.png"
};};};
function RasqrQ13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr413").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr413").src = "img/sqrs/blSqr.png"
};};};
function RasqrQ14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr414").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr414").src = "img/sqrs/blSqr.png"
};};};
function RasqrQ15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr415").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr415").src = "img/sqrs/blSqr.png"
};};};
function RasqrQ16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr416").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr416").src = "img/sqrs/blSqr.png"
};};};
function RasqrQ17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr417").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr417").src = "img/sqrs/blSqr.png"
};};};
function RasqrQ18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr418").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr418").src = "img/sqrs/blSqr.png"
};};};
function RasqrQ19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr419").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr419").src = "img/sqrs/blSqr.png"
};};};
function RasqrQ20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr420").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr420").src = "img/sqrs/blSqr.png"
};};};
function RasqrQ21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr421").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr421").src = "img/sqrs/blSqr.png"
};};};
function RasqrQ22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr422").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr422").src = "img/sqrs/blSqr.png"
};};};
function RasqrQ23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr423").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr423").src = "img/sqrs/blSqr.png"
};};};
function RasqrQ24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr424").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr424").src = "img/sqrs/blSqr.png"
};};};
function RasqrQ25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr425").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr425").src = "img/sqrs/blSqr.png"
};};};
function RasqrR1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr426").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr426").src = "img/sqrs/blSqr.png"
};};};
function RasqrR2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr427").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr427").src = "img/sqrs/blSqr.png"
};};};
function RasqrR3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr428").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr428").src = "img/sqrs/blSqr.png"
};};};
function RasqrR4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr429").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr429").src = "img/sqrs/blSqr.png"
};};};
function RasqrR5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr430").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr430").src = "img/sqrs/blSqr.png"
};};};
function RasqrR6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr431").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr431").src = "img/sqrs/blSqr.png"
};};};
function RasqrR7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr432").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr432").src = "img/sqrs/blSqr.png"
};};};
function RasqrR8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr433").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr433").src = "img/sqrs/blSqr.png"
};};};
function RasqrR9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr434").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr434").src = "img/sqrs/blSqr.png"
};};};
function RasqrR10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr435").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr435").src = "img/sqrs/blSqr.png"
};};};
function RasqrR11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr436").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr436").src = "img/sqrs/blSqr.png"
};};};
function RasqrR12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr437").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr437").src = "img/sqrs/blSqr.png"
};};};
function RasqrR13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr438").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr438").src = "img/sqrs/blSqr.png"
};};};
function RasqrR14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr439").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr439").src = "img/sqrs/blSqr.png"
};};};
function RasqrR15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr440").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr440").src = "img/sqrs/blSqr.png"
};};};
function RasqrR16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr441").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr441").src = "img/sqrs/blSqr.png"
};};};
function RasqrR17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr442").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr442").src = "img/sqrs/blSqr.png"
};};};
function RasqrR18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr443").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr443").src = "img/sqrs/blSqr.png"
};};};
function RasqrR19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr444").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr444").src = "img/sqrs/blSqr.png"
};};};
function RasqrR20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr445").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr445").src = "img/sqrs/blSqr.png"
};};};
function RasqrR21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr446").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr446").src = "img/sqrs/blSqr.png"
};};};
function RasqrR22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr447").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr447").src = "img/sqrs/blSqr.png"
};};};
function RasqrR23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr448").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr448").src = "img/sqrs/blSqr.png"
};};};
function RasqrR24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr449").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr449").src = "img/sqrs/blSqr.png"
};};};
function RasqrR25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr450").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr450").src = "img/sqrs/blSqr.png"
};};};
function RasqrS1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr451").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr451").src = "img/sqrs/blSqr.png"
};};};
function RasqrS2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr452").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr452").src = "img/sqrs/blSqr.png"
};};};
function RasqrS3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr453").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr453").src = "img/sqrs/blSqr.png"
};};};
function RasqrS4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr454").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr454").src = "img/sqrs/blSqr.png"
};};};
function RasqrS5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr455").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr455").src = "img/sqrs/blSqr.png"
};};};
function RasqrS6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr456").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr456").src = "img/sqrs/blSqr.png"
};};};
function RasqrS7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr457").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr457").src = "img/sqrs/blSqr.png"
};};};
function RasqrS8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr458").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr458").src = "img/sqrs/blSqr.png"
};};};
function RasqrS9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr459").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr459").src = "img/sqrs/blSqr.png"
};};};
function RasqrS10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr460").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr460").src = "img/sqrs/blSqr.png"
};};};
function RasqrS11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr461").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr461").src = "img/sqrs/blSqr.png"
};};};
function RasqrS12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr462").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr462").src = "img/sqrs/blSqr.png"
};};};
function RasqrS13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr463").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr463").src = "img/sqrs/blSqr.png"
};};};
function RasqrS14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr464").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr464").src = "img/sqrs/blSqr.png"
};};};
function RasqrS15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr465").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr465").src = "img/sqrs/blSqr.png"
};};};
function RasqrS16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr466").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr466").src = "img/sqrs/blSqr.png"
};};};
function RasqrS17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr467").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr467").src = "img/sqrs/blSqr.png"
};};};
function RasqrS18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr468").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr468").src = "img/sqrs/blSqr.png"
};};};
function RasqrS19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr469").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr469").src = "img/sqrs/blSqr.png"
};};};
function RasqrS20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr470").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr470").src = "img/sqrs/blSqr.png"
};};};
function RasqrS21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr471").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr471").src = "img/sqrs/blSqr.png"
};};};
function RasqrS22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr472").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr472").src = "img/sqrs/blSqr.png"
};};};
function RasqrS23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr473").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr473").src = "img/sqrs/blSqr.png"
};};};
function RasqrS24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr474").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr474").src = "img/sqrs/blSqr.png"
};};};
function RasqrS25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr475").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr475").src = "img/sqrs/blSqr.png"
};};};
function RasqrT1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr476").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr476").src = "img/sqrs/blSqr.png"
};};};
function RasqrT2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr477").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr477").src = "img/sqrs/blSqr.png"
};};};
function RasqrT3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr478").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr478").src = "img/sqrs/blSqr.png"
};};};
function RasqrT4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr479").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr479").src = "img/sqrs/blSqr.png"
};};};
function RasqrT5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr480").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr480").src = "img/sqrs/blSqr.png"
};};};
function RasqrT6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr481").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr481").src = "img/sqrs/blSqr.png"
};};};
function RasqrT7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr482").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr482").src = "img/sqrs/blSqr.png"
};};};
function RasqrT8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr483").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr483").src = "img/sqrs/blSqr.png"
};};};
function RasqrT9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr484").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr484").src = "img/sqrs/blSqr.png"
};};};
function RasqrT10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr485").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr485").src = "img/sqrs/blSqr.png"
};};};
function RasqrT11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr486").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr486").src = "img/sqrs/blSqr.png"
};};};
function RasqrT12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr487").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr487").src = "img/sqrs/blSqr.png"
};};};
function RasqrT13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr488").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr488").src = "img/sqrs/blSqr.png"
};};};
function RasqrT14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr489").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr489").src = "img/sqrs/blSqr.png"
};};};
function RasqrT15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr490").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr490").src = "img/sqrs/blSqr.png"
};};};
function RasqrT16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr491").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr491").src = "img/sqrs/blSqr.png"
};};};
function RasqrT17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr492").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr492").src = "img/sqrs/blSqr.png"
};};};
function RasqrT18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr493").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr493").src = "img/sqrs/blSqr.png"
};};};
function RasqrT19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr494").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr494").src = "img/sqrs/blSqr.png"
};};};
function RasqrT20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr495").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr495").src = "img/sqrs/blSqr.png"
};};};
function RasqrT21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr496").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr496").src = "img/sqrs/blSqr.png"
};};};
function RasqrT22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr497").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr497").src = "img/sqrs/blSqr.png"
};};};
function RasqrT23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr498").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr498").src = "img/sqrs/blSqr.png"
};};};
function RasqrT24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr499").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr499").src = "img/sqrs/blSqr.png"
};};};
function RasqrT25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr500").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr500").src = "img/sqrs/blSqr.png"
};};};
function RasqrU1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr501").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr501").src = "img/sqrs/blSqr.png"
};};};
function RasqrU2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr502").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr502").src = "img/sqrs/blSqr.png"
};};};
function RasqrU3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr503").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr503").src = "img/sqrs/blSqr.png"
};};};
function RasqrU4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr504").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr504").src = "img/sqrs/blSqr.png"
};};};
function RasqrU5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr505").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr505").src = "img/sqrs/blSqr.png"
};};};
function RasqrU6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr506").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr506").src = "img/sqrs/blSqr.png"
};};};
function RasqrU7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr507").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr507").src = "img/sqrs/blSqr.png"
};};};
function RasqrU8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr508").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr508").src = "img/sqrs/blSqr.png"
};};};
function RasqrU9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr509").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr509").src = "img/sqrs/blSqr.png"
};};};
function RasqrU10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr510").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr510").src = "img/sqrs/blSqr.png"
};};};
function RasqrU11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr511").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr511").src = "img/sqrs/blSqr.png"
};};};
function RasqrU12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr512").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr512").src = "img/sqrs/blSqr.png"
};};};
function RasqrU13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr513").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr513").src = "img/sqrs/blSqr.png"
};};};
function RasqrU14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr514").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr514").src = "img/sqrs/blSqr.png"
};};};
function RasqrU15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr515").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr515").src = "img/sqrs/blSqr.png"
};};};
function RasqrU16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr516").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr516").src = "img/sqrs/blSqr.png"
};};};
function RasqrU17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr517").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr517").src = "img/sqrs/blSqr.png"
};};};
function RasqrU18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr518").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr518").src = "img/sqrs/blSqr.png"
};};};
function RasqrU19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr519").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr519").src = "img/sqrs/blSqr.png"
};};};
function RasqrU20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr520").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr520").src = "img/sqrs/blSqr.png"
};};};
function RasqrU21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr521").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr521").src = "img/sqrs/blSqr.png"
};};};
function RasqrU22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr522").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr522").src = "img/sqrs/blSqr.png"
};};};
function RasqrU23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr523").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr523").src = "img/sqrs/blSqr.png"
};};};
function RasqrU24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr524").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr524").src = "img/sqrs/blSqr.png"
};};};
function RasqrU25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr525").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr525").src = "img/sqrs/blSqr.png"
};};};
function RasqrV1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr526").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr526").src = "img/sqrs/blSqr.png"
};};};
function RasqrV2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr527").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr527").src = "img/sqrs/blSqr.png"
};};};
function RasqrV3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr528").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr528").src = "img/sqrs/blSqr.png"
};};};
function RasqrV4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr529").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr529").src = "img/sqrs/blSqr.png"
};};};
function RasqrV5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr530").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr530").src = "img/sqrs/blSqr.png"
};};};
function RasqrV6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr531").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr531").src = "img/sqrs/blSqr.png"
};};};
function RasqrV7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr532").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr532").src = "img/sqrs/blSqr.png"
};};};
function RasqrV8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr533").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr533").src = "img/sqrs/blSqr.png"
};};};
function RasqrV9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr534").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr534").src = "img/sqrs/blSqr.png"
};};};
function RasqrV10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr535").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr535").src = "img/sqrs/blSqr.png"
};};};
function RasqrV11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr536").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr536").src = "img/sqrs/blSqr.png"
};};};
function RasqrV12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr537").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr537").src = "img/sqrs/blSqr.png"
};};};
function RasqrV13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr538").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr538").src = "img/sqrs/blSqr.png"
};};};
function RasqrV14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr539").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr539").src = "img/sqrs/blSqr.png"
};};};
function RasqrV15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr540").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr540").src = "img/sqrs/blSqr.png"
};};};
function RasqrV16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr541").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr541").src = "img/sqrs/blSqr.png"
};};};
function RasqrV17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr542").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr542").src = "img/sqrs/blSqr.png"
};};};
function RasqrV18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr543").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr543").src = "img/sqrs/blSqr.png"
};};};
function RasqrV19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr544").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr544").src = "img/sqrs/blSqr.png"
};};};
function RasqrV20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr545").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr545").src = "img/sqrs/blSqr.png"
};};};
function RasqrV21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr546").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr546").src = "img/sqrs/blSqr.png"
};};};
function RasqrV22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr547").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr547").src = "img/sqrs/blSqr.png"
};};};
function RasqrV23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr548").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr548").src = "img/sqrs/blSqr.png"
};};};
function RasqrV24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr549").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr549").src = "img/sqrs/blSqr.png"
};};};
function RasqrV25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr550").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr550").src = "img/sqrs/blSqr.png"
};};};
function RasqrW1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr551").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr551").src = "img/sqrs/blSqr.png"
};};};
function RasqrW2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr552").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr552").src = "img/sqrs/blSqr.png"
};};};
function RasqrW3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr553").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr553").src = "img/sqrs/blSqr.png"
};};};
function RasqrW4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr554").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr554").src = "img/sqrs/blSqr.png"
};};};
function RasqrW5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr555").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr555").src = "img/sqrs/blSqr.png"
};};};
function RasqrW6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr556").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr556").src = "img/sqrs/blSqr.png"
};};};
function RasqrW7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr557").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr557").src = "img/sqrs/blSqr.png"
};};};
function RasqrW8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr558").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr558").src = "img/sqrs/blSqr.png"
};};};
function RasqrW9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr559").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr559").src = "img/sqrs/blSqr.png"
};};};
function RasqrW10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr560").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr560").src = "img/sqrs/blSqr.png"
};};};
function RasqrW11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr561").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr561").src = "img/sqrs/blSqr.png"
};};};
function RasqrW12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr562").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr562").src = "img/sqrs/blSqr.png"
};};};
function RasqrW13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr563").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr563").src = "img/sqrs/blSqr.png"
};};};
function RasqrW14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr564").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr564").src = "img/sqrs/blSqr.png"
};};};
function RasqrW15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr565").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr565").src = "img/sqrs/blSqr.png"
};};};
function RasqrW16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr566").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr566").src = "img/sqrs/blSqr.png"
};};};
function RasqrW17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr567").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr567").src = "img/sqrs/blSqr.png"
};};};
function RasqrW18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr568").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr568").src = "img/sqrs/blSqr.png"
};};};
function RasqrW19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr569").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr569").src = "img/sqrs/blSqr.png"
};};};
function RasqrW20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr570").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr570").src = "img/sqrs/blSqr.png"
};};};
function RasqrW21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr571").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr571").src = "img/sqrs/blSqr.png"
};};};
function RasqrW22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr572").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr572").src = "img/sqrs/blSqr.png"
};};};
function RasqrW23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr573").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr573").src = "img/sqrs/blSqr.png"
};};};
function RasqrW24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr574").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr574").src = "img/sqrs/blSqr.png"
};};};
function RasqrW25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr575").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr575").src = "img/sqrs/blSqr.png"
};};};
function RasqrX1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr576").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr576").src = "img/sqrs/blSqr.png"
};};};
function RasqrX2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr577").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr577").src = "img/sqrs/blSqr.png"
};};};
function RasqrX3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr578").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr578").src = "img/sqrs/blSqr.png"
};};};
function RasqrX4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr579").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr579").src = "img/sqrs/blSqr.png"
};};};
function RasqrX5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr580").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr580").src = "img/sqrs/blSqr.png"
};};};
function RasqrX6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr581").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr581").src = "img/sqrs/blSqr.png"
};};};
function RasqrX7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr582").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr582").src = "img/sqrs/blSqr.png"
};};};
function RasqrX8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr583").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr583").src = "img/sqrs/blSqr.png"
};};};
function RasqrX9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr584").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr584").src = "img/sqrs/blSqr.png"
};};};
function RasqrX10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr585").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr585").src = "img/sqrs/blSqr.png"
};};};
function RasqrX11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr586").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr586").src = "img/sqrs/blSqr.png"
};};};
function RasqrX12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr587").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr587").src = "img/sqrs/blSqr.png"
};};};
function RasqrX13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr588").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr588").src = "img/sqrs/blSqr.png"
};};};
function RasqrX14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr589").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr589").src = "img/sqrs/blSqr.png"
};};};
function RasqrX15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr590").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr590").src = "img/sqrs/blSqr.png"
};};};
function RasqrX16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr591").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr591").src = "img/sqrs/blSqr.png"
};};};
function RasqrX17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr592").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr592").src = "img/sqrs/blSqr.png"
};};};
function RasqrX18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr593").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr593").src = "img/sqrs/blSqr.png"
};};};
function RasqrX19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr594").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr594").src = "img/sqrs/blSqr.png"
};};};
function RasqrX20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr595").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr595").src = "img/sqrs/blSqr.png"
};};};
function RasqrX21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr596").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr596").src = "img/sqrs/blSqr.png"
};};};
function RasqrX22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr597").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr597").src = "img/sqrs/blSqr.png"
};};};
function RasqrX23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr598").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr598").src = "img/sqrs/blSqr.png"
};};};
function RasqrX24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr599").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr599").src = "img/sqrs/blSqr.png"
};};};
function RasqrX25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr600").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr600").src = "img/sqrs/blSqr.png"
};};};
function RasqrY1() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr601").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr601").src = "img/sqrs/blSqr.png"
};};};
function RasqrY2() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr602").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr602").src = "img/sqrs/blSqr.png"
};};};
function RasqrY3() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr603").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr603").src = "img/sqrs/blSqr.png"
};};};
function RasqrY4() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr604").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr604").src = "img/sqrs/blSqr.png"
};};};
function RasqrY5() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr605").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr605").src = "img/sqrs/blSqr.png"
};};};
function RasqrY6() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr606").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr606").src = "img/sqrs/blSqr.png"
};};};
function RasqrY7() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr607").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr607").src = "img/sqrs/blSqr.png"
};};};
function RasqrY8() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr608").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr608").src = "img/sqrs/blSqr.png"
};};};
function RasqrY9() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr609").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr609").src = "img/sqrs/blSqr.png"
};};};
function RasqrY10() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr610").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr610").src = "img/sqrs/blSqr.png"
};};};
function RasqrY11() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr611").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr611").src = "img/sqrs/blSqr.png"
};};};
function RasqrY12() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr612").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr612").src = "img/sqrs/blSqr.png"
};};};
function RasqrY13() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr613").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr613").src = "img/sqrs/blSqr.png"
};};};
function RasqrY14() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr614").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr614").src = "img/sqrs/blSqr.png"
};};};
function RasqrY15() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr615").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr615").src = "img/sqrs/blSqr.png"
};};};
function RasqrY16() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr616").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr616").src = "img/sqrs/blSqr.png"
};};};
function RasqrY17() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr617").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr617").src = "img/sqrs/blSqr.png"
};};};
function RasqrY18() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr618").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr618").src = "img/sqrs/blSqr.png"
};};};
function RasqrY19() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr619").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr619").src = "img/sqrs/blSqr.png"
};};};
function RasqrY20() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr620").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr620").src = "img/sqrs/blSqr.png"
};};};
function RasqrY21() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr621").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr621").src = "img/sqrs/blSqr.png"
};};};
function RasqrY22() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr622").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr622").src = "img/sqrs/blSqr.png"
};};};
function RasqrY23() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr623").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr623").src = "img/sqrs/blSqr.png"
};};};
function RasqrY24() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr624").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr624").src = "img/sqrs/blSqr.png"
};};};
function RasqrY25() {
 if(document.getElementById("check1").checked == true) {
    if(document.getElementById("aImgSqr625").src = "img/sqrs/wSqr.png") {
    document.getElementById("aImgSqr625").src = "img/sqrs/blSqr.png"
};};};