function aBEsqrA1() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr1").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr1").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrA2() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr2").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr2").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrA3() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr3").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr3").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrA4() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr4").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr4").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrA5() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr5").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr5").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrA6() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr6").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr6").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrA7() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr7").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr7").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrA8() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr8").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr8").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrA9() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr9").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr9").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrA10() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr10").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr10").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrA11() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr11").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr11").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrA12() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr12").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr12").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrA13() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr13").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr13").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrA14() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr14").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr14").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrA15() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr15").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr15").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrA16() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr16").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr16").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrA17() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr17").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr17").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrA18() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr18").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr18").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrA19() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr19").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr19").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrA20() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr20").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr20").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrA21() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr21").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr21").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrA22() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr22").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr22").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrA23() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr23").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr23").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrA24() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr24").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr24").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrA25() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr25").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr25").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrB1() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr26").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr26").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrB2() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr27").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr27").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrB3() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr28").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr28").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrB4() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr29").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr29").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrB5() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr30").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr30").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrB6() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr31").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr31").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrB7() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr32").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr32").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrB8() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr33").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr33").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrB9() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr34").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr34").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrB10() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr35").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr35").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrB11() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr36").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr36").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrB12() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr37").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr37").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrB13() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr38").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr38").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrB14() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr39").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr39").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrB15() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr40").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr40").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrB16() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr41").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr41").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrB17() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr42").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr42").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrB18() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr43").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr43").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrB19() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr44").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr44").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrB20() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr45").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr45").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrB21() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr46").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr46").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrB22() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr47").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr47").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrB23() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr48").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr48").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrB24() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr49").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr49").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrB25() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr50").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr50").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrC1() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr51").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr51").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrC2() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr52").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr52").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrC3() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr53").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr53").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrC4() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr54").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr54").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrC5() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr55").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr55").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrC6() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr56").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr56").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrC7() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr57").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr57").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrC8() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr58").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr58").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrC9() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr59").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr59").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrC10() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr60").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr60").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrC11() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr61").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr61").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrC12() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr62").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr62").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrC13() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr63").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr63").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrC14() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr64").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr64").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrC15() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr65").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr65").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrC16() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr66").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr66").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrC17() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr67").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr67").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrC18() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr68").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr68").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrC19() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr69").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr69").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrC20() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr70").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr70").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrC21() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr71").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr71").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrC22() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr72").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr72").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrC23() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr73").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr73").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrC24() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr74").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr74").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrC25() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr75").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr75").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrD1() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr76").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr76").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrD2() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr77").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr77").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrD3() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr78").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr78").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrD4() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr79").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr79").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrD5() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr80").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr80").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrD6() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr81").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr81").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrD7() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr82").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr82").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrD8() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr83").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr83").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrD9() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr84").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr84").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrD10() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr85").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr85").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrD11() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr86").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr86").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrD12() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr87").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr87").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrD13() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr88").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr88").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrD14() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr89").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr89").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrD15() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr90").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr90").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrD16() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr91").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr91").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrD17() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr92").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr92").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrD18() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr93").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr93").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrD19() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr94").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr94").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrD20() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr95").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr95").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrD21() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr96").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr96").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrD22() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr97").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr97").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrD23() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr98").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr98").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrD24() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr99").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr99").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrD25() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr100").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr100").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrE1() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr101").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr101").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrE2() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr102").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr102").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrE3() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr103").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr103").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrE4() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr104").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr104").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrE5() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr105").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr105").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrE6() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr106").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr106").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrE7() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr107").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr107").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrE8() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr108").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr108").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrE9() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr109").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr109").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrE10() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr110").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr110").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrE11() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr111").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr111").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrE12() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr112").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr112").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrE13() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr113").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr113").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrE14() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr114").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr114").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrE15() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr115").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr115").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrE16() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr116").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr116").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrE17() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr117").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr117").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrE18() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr118").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr118").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrE19() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr119").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr119").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrE20() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr120").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr120").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrE21() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr121").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr121").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrE22() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr122").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr122").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrE23() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr123").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr123").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrE24() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr124").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr124").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrE25() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr125").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr125").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrF1() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr126").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr126").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrF2() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr127").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr127").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrF3() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr128").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr128").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrF4() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr129").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr129").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrF5() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr130").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr130").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrF6() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr131").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr131").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrF7() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr132").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr132").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrF8() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr133").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr133").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrF9() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr134").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr134").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrF10() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr135").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr135").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrF11() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr136").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr136").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrF12() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr137").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr137").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrF13() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr138").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr138").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrF14() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr139").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr139").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrF15() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr140").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr140").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrF16() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr141").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr141").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrF17() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr142").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr142").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrF18() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr143").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr143").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrF19() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr144").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr144").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrF20() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr145").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr145").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrF21() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr146").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr146").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrF22() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr147").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr147").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrF23() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr148").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr148").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrF24() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr149").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr149").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrF25() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr150").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr150").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrG1() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr151").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr151").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrG2() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr152").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr152").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrG3() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr153").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr153").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrG4() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr154").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr154").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrG5() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr155").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr155").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrG6() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr156").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr156").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrG7() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr157").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr157").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrG8() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr158").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr158").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrG9() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr159").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr159").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrG10() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr160").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr160").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrG11() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr161").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr161").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrG12() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr162").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr162").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrG13() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr163").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr163").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrG14() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr164").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr164").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrG15() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr165").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr165").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrG16() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr166").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr166").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrG17() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr167").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr167").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrG18() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr168").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr168").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrG19() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr169").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr169").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrG20() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr170").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr170").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrG21() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr171").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr171").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrG22() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr172").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr172").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrG23() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr173").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr173").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrG24() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr174").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr174").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrG25() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr175").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr175").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrH1() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr176").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr176").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrH2() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr177").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr177").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrH3() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr178").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr178").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrH4() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr179").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr179").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrH5() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr180").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr180").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrH6() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr181").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr181").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrH7() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr182").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr182").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrH8() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr183").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr183").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrH9() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr184").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr184").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrH10() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr185").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr185").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrH11() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr186").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr186").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrH12() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr187").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr187").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrH13() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr188").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr188").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrH14() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr189").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr189").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrH15() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr190").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr190").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrH16() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr191").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr191").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrH17() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr192").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr192").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrH18() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr193").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr193").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrH19() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr194").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr194").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrH20() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr195").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr195").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrH21() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr196").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr196").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrH22() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr197").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr197").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrH23() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr198").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr198").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrH24() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr199").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr199").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrH25() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr200").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr200").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrI1() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr201").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr201").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrI2() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr202").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr202").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrI3() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr203").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr203").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrI4() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr204").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr204").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrI5() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr205").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr205").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrI6() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr206").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr206").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrI7() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr207").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr207").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrI8() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr208").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr208").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrI9() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr209").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr209").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrI10() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr210").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr210").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrI11() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr211").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr211").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrI12() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr212").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr212").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrI13() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr213").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr213").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrI14() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr214").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr214").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrI15() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr215").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr215").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrI16() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr216").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr216").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrI17() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr217").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr217").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrI18() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr218").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr218").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrI19() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr219").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr219").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrI20() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr220").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr220").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrI21() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr221").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr221").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrI22() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr222").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr222").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrI23() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr223").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr223").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrI24() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr224").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr224").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrI25() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr225").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr225").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrJ1() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr226").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr226").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrJ2() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr227").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr227").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrJ3() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr228").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr228").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrJ4() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr229").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr229").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrJ5() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr230").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr230").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrJ6() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr231").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr231").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrJ7() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr232").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr232").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrJ8() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr233").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr233").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrJ9() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr234").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr234").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrJ10() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr235").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr235").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrJ11() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr236").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr236").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrJ12() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr237").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr237").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrJ13() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr238").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr238").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrJ14() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr239").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr239").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrJ15() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr240").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr240").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrJ16() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr241").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr241").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrJ17() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr242").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr242").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrJ18() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr243").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr243").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrJ19() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr244").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr244").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrJ20() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr245").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr245").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrJ21() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr246").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr246").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrJ22() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr247").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr247").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrJ23() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr248").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr248").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrJ24() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr249").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr249").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrJ25() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr250").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr250").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrK1() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr251").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr251").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrK2() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr252").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr252").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrK3() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr253").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr253").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrK4() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr254").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr254").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrK5() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr255").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr255").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrK6() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr256").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr256").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrK7() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr257").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr257").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrK8() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr258").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr258").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrK9() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr259").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr259").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrK10() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr260").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr260").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrK11() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr261").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr261").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrK12() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr262").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr262").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrK13() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr263").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr263").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrK14() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr264").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr264").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrK15() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr265").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr265").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrK16() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr266").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr266").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrK17() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr267").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr267").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrK18() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr268").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr268").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrK19() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr269").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr269").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrK20() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr270").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr270").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrK21() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr271").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr271").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrK22() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr272").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr272").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrK23() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr273").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr273").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrK24() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr274").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr274").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrK25() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr275").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr275").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrL1() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr276").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr276").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrL2() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr277").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr277").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrL3() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr278").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr278").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrL4() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr279").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr279").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrL5() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr280").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr280").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrL6() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr281").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr281").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrL7() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr282").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr282").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrL8() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr283").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr283").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrL9() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr284").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr284").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrL10() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr285").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr285").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrL11() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr286").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr286").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrL12() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr287").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr287").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrL13() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr288").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr288").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrL14() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr289").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr289").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrL15() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr290").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr290").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrL16() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr291").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr291").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrL17() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr292").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr292").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrL18() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr293").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr293").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrL19() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr294").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr294").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrL20() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr295").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr295").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrL21() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr296").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr296").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrL22() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr297").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr297").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrL23() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr298").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr298").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrL24() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr299").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr299").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrL25() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr300").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr300").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrM1() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr301").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr301").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrM2() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr302").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr302").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrM3() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr303").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr303").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrM4() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr304").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr304").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrM5() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr305").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr305").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrM6() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr306").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr306").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrM7() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr307").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr307").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrM8() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr308").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr308").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrM9() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr309").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr309").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrM10() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr310").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr310").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrM11() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr311").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr311").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrM12() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr312").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr312").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrM13() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr313").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr313").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrM14() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr314").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr314").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrM15() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr315").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr315").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrM16() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr316").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr316").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrM17() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr317").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr317").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrM18() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr318").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr318").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrM19() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr319").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr319").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrM20() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr320").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr320").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrM21() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr321").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr321").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrM22() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr322").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr322").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrM23() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr323").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr323").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrM24() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr324").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr324").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrM25() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr325").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr325").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrN1() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr326").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr326").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrN2() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr327").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr327").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrN3() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr328").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr328").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrN4() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr329").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr329").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrN5() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr330").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr330").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrN6() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr331").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr331").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrN7() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr332").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr332").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrN8() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr333").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr333").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrN9() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr334").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr334").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrN10() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr335").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr335").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrN11() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr336").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr336").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrN12() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr337").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr337").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrN13() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr338").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr338").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrN14() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr339").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr339").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrN15() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr340").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr340").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrN16() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr341").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr341").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrN17() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr342").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr342").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrN18() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr343").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr343").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrN19() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr344").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr344").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrN20() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr345").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr345").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrN21() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr346").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr346").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrN22() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr347").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr347").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrN23() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr348").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr348").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrN24() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr349").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr349").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrN25() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr350").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr350").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrO1() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr351").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr351").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrO2() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr352").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr352").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrO3() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr353").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr353").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrO4() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr354").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr354").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrO5() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr355").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr355").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrO6() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr356").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr356").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrO7() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr357").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr357").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrO8() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr358").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr358").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrO9() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr359").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr359").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrO10() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr360").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr360").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrO11() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr361").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr361").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrO12() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr362").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr362").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrO13() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr363").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr363").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrO14() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr364").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr364").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrO15() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr365").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr365").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrO16() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr366").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr366").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrO17() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr367").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr367").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrO18() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr368").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr368").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrO19() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr369").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr369").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrO20() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr370").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr370").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrO21() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr371").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr371").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrO22() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr372").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr372").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrO23() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr373").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr373").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrO24() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr374").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr374").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrO25() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr375").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr375").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrP1() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr376").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr376").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrP2() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr377").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr377").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrP3() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr378").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr378").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrP4() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr379").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr379").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrP5() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr380").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr380").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrP6() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr381").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr381").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrP7() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr382").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr382").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrP8() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr383").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr383").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrP9() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr384").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr384").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrP10() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr385").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr385").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrP11() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr386").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr386").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrP12() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr387").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr387").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrP13() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr388").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr388").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrP14() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr389").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr389").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrP15() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr390").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr390").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrP16() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr391").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr391").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrP17() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr392").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr392").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrP18() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr393").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr393").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrP19() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr394").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr394").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrP20() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr395").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr395").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrP21() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr396").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr396").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrP22() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr397").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr397").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrP23() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr398").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr398").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrP24() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr399").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr399").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrP25() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr400").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr400").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrQ1() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr401").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr401").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrQ2() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr402").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr402").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrQ3() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr403").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr403").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrQ4() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr404").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr404").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrQ5() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr405").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr405").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrQ6() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr406").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr406").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrQ7() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr407").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr407").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrQ8() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr408").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr408").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrQ9() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr409").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr409").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrQ10() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr410").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr410").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrQ11() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr411").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr411").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrQ12() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr412").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr412").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrQ13() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr413").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr413").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrQ14() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr414").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr414").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrQ15() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr415").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr415").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrQ16() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr416").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr416").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrQ17() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr417").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr417").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrQ18() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr418").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr418").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrQ19() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr419").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr419").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrQ20() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr420").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr420").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrQ21() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr421").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr421").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrQ22() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr422").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr422").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrQ23() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr423").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr423").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrQ24() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr424").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr424").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrQ25() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr425").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr425").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrR1() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr426").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr426").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrR2() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr427").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr427").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrR3() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr428").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr428").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrR4() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr429").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr429").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrR5() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr430").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr430").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrR6() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr431").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr431").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrR7() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr432").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr432").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrR8() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr433").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr433").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrR9() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr434").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr434").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrR10() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr435").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr435").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrR11() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr436").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr436").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrR12() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr437").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr437").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrR13() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr438").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr438").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrR14() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr439").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr439").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrR15() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr440").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr440").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrR16() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr441").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr441").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrR17() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr442").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr442").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrR18() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr443").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr443").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrR19() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr444").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr444").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrR20() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr445").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr445").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrR21() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr446").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr446").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrR22() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr447").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr447").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrR23() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr448").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr448").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrR24() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr449").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr449").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrR25() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr450").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr450").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrS1() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr451").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr451").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrS2() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr452").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr452").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrS3() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr453").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr453").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrS4() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr454").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr454").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrS5() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr455").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr455").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrS6() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr456").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr456").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrS7() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr457").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr457").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrS8() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr458").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr458").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrS9() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr459").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr459").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrS10() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr460").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr460").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrS11() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr461").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr461").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrS12() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr462").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr462").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrS13() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr463").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr463").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrS14() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr464").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr464").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrS15() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr465").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr465").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrS16() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr466").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr466").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrS17() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr467").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr467").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrS18() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr468").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr468").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrS19() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr469").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr469").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrS20() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr470").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr470").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrS21() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr471").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr471").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrS22() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr472").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr472").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrS23() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr473").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr473").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrS24() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr474").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr474").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrS25() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr475").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr475").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrT1() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr476").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr476").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrT2() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr477").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr477").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrT3() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr478").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr478").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrT4() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr479").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr479").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrT5() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr480").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr480").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrT6() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr481").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr481").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrT7() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr482").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr482").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrT8() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr483").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr483").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrT9() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr484").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr484").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrT10() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr485").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr485").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrT11() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr486").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr486").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrT12() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr487").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr487").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrT13() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr488").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr488").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrT14() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr489").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr489").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrT15() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr490").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr490").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrT16() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr491").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr491").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrT17() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr492").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr492").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrT18() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr493").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr493").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrT19() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr494").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr494").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrT20() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr495").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr495").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrT21() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr496").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr496").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrT22() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr497").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr497").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrT23() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr498").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr498").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrT24() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr499").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr499").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrT25() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr500").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr500").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrU1() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr501").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr501").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrU2() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr502").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr502").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrU3() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr503").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr503").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrU4() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr504").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr504").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrU5() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr505").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr505").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrU6() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr506").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr506").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrU7() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr507").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr507").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrU8() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr508").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr508").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrU9() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr509").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr509").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrU10() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr510").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr510").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrU11() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr511").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr511").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrU12() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr512").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr512").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrU13() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr513").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr513").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrU14() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr514").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr514").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrU15() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr515").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr515").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrU16() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr516").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr516").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrU17() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr517").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr517").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrU18() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr518").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr518").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrU19() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr519").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr519").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrU20() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr520").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr520").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrU21() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr521").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr521").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrU22() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr522").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr522").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrU23() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr523").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr523").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrU24() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr524").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr524").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrU25() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr525").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr525").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrV1() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr526").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr526").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrV2() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr527").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr527").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrV3() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr528").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr528").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrV4() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr529").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr529").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrV5() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr530").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr530").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrV6() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr531").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr531").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrV7() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr532").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr532").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrV8() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr533").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr533").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrV9() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr534").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr534").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrV10() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr535").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr535").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrV11() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr536").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr536").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrV12() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr537").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr537").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrV13() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr538").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr538").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrV14() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr539").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr539").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrV15() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr540").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr540").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrV16() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr541").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr541").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrV17() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr542").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr542").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrV18() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr543").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr543").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrV19() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr544").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr544").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrV20() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr545").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr545").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrV21() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr546").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr546").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrV22() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr547").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr547").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrV23() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr548").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr548").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrV24() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr549").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr549").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrV25() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr550").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr550").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrW1() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr551").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr551").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrW2() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr552").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr552").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrW3() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr553").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr553").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrW4() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr554").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr554").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrW5() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr555").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr555").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrW6() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr556").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr556").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrW7() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr557").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr557").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrW8() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr558").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr558").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrW9() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr559").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr559").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrW10() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr560").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr560").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrW11() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr561").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr561").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrW12() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr562").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr562").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrW13() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr563").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr563").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrW14() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr564").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr564").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrW15() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr565").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr565").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrW16() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr566").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr566").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrW17() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr567").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr567").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrW18() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr568").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr568").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrW19() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr569").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr569").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrW20() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr570").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr570").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrW21() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr571").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr571").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrW22() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr572").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr572").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrW23() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr573").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr573").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrW24() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr574").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr574").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrW25() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr575").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr575").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrX1() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr576").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr576").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrX2() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr577").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr577").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrX3() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr578").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr578").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrX4() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr579").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr579").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrX5() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr580").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr580").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrX6() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr581").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr581").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrX7() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr582").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr582").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrX8() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr583").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr583").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrX9() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr584").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr584").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrX10() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr585").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr585").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrX11() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr586").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr586").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrX12() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr587").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr587").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrX13() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr588").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr588").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrX14() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr589").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr589").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrX15() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr590").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr590").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrX16() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr591").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr591").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrX17() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr592").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr592").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrX18() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr593").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr593").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrX19() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr594").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr594").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrX20() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr595").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr595").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrX21() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr596").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr596").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrX22() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr597").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr597").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrX23() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr598").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr598").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrX24() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr599").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr599").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrX25() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr600").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr600").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrY1() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr601").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr601").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrY2() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr602").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr602").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrY3() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr603").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr603").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrY4() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr604").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr604").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrY5() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr605").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr605").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrY6() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr606").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr606").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrY7() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr607").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr607").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrY8() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr608").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr608").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrY9() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr609").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr609").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrY10() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr610").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr610").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrY11() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr611").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr611").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrY12() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr612").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr612").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrY13() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr613").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr613").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrY14() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr614").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr614").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrY15() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr615").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr615").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrY16() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr616").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr616").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrY17() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr617").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr617").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrY18() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr618").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr618").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrY19() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr619").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr619").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrY20() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr620").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr620").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrY21() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr621").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr621").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrY22() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr622").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr622").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrY23() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr623").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr623").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrY24() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr624").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr624").src = "img/sqrs/wSqr.png"
};};};
function aBEsqrY25() {
 if(document.getElementById("check2").checked == true) {
    if(document.getElementById("imgSqr625").src = "img/sqrs/blSqr.png") {
    document.getElementById("imgSqr625").src = "img/sqrs/wSqr.png"
};};};